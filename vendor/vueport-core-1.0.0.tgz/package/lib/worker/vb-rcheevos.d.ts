/**
 * The RetroAchievements engine, hosted in the emulator worker.
 *
 * Evaluating an achievement set means reading the machine's memory synchronously
 * once per emulated frame, and the worker is the only place that read is
 * synchronous — from the DOM it is a message round trip. So rcheevos runs here,
 * as a second WebAssembly module beside the core, talking to a thin C shim
 * (`../../wasm/rcheevos/shim/vueport-rc.c`) that flattens `rc_client` to functions with
 * only primitive parameters.
 *
 * This module never makes a network request. `rc_client` asks for one through
 * the shim's `vrc_server_call`, which becomes a `serverCall` event; the DOM
 * side makes the call (only the desktop shell can reach the RetroAchievements
 * API) and feeds the answer back with `raProvideResponse`.
 *
 * The rcheevos glue (`rcheevos.js` + `rcheevos.wasm`) is loaded lazily with
 * `importScripts` on the first login, and its absence is not an error: a build
 * that ships neither reports `engineUnavailable` and the panel says so, exactly
 * as the browser reports it cannot reach the API.
 */
import { VesRaEvent, VesRaLeaderboardEntries, VesRaUser } from '../common/vb-protocol';
import { WasmExports } from './vb-wasm';
interface RcModule {
    HEAPU8: Uint8Array;
    _malloc(size: number): number;
    _free(pointer: number): void;
    stringToUTF8(text: string, pointer: number, maxBytes: number): void;
    lengthBytesUTF8(text: string): number;
    /** Hooks the `--js-library` glue calls back into; we set these. */
    vrcReadMemory(address: number, buffer: number, length: number): number;
    vrcServerCall(requestId: number, method: string, url: string, post: string | undefined, contentType: string | undefined): void;
    vrcEmit(json: string): void;
    _vrc_create(): number;
    _vrc_destroy(client: number): void;
    _vrc_begin_login_password(client: number, username: number, password: number): void;
    _vrc_begin_login_token(client: number, username: number, token: number): void;
    _vrc_logout(client: number): void;
    _vrc_begin_load_game(client: number, hash: number): void;
    _vrc_unload_game(client: number): void;
    _vrc_reset(client: number): void;
    /**
     * Absent from a `rcheevos.wasm` built before this export was added — the
     * committed artifact until `build.mjs` is rerun — so every call is guarded
     * with a `typeof` check. Missing, the client stays in its `vrc_create`
     * default (softcore), which is the safe side to fail to.
     */
    _vrc_set_hardcore?(client: number, enabled: number): void;
    _vrc_do_frame(client: number): void;
    _vrc_idle(client: number): void;
    _vrc_provide_response(requestId: number, status: number, body: number): void;
    /**
     * Absent from an `rcheevos.wasm` built before leaderboards were added,
     * and guarded the same way `_vrc_set_hardcore` is. It doubles as the test
     * for whether this engine emits leaderboards at all — both come from the
     * same build — so a stale one is reported rather than leaving the panel
     * waiting forever on a list that is never coming.
     */
    _vrc_begin_fetch_leaderboard_entries?(client: number, fetchId: number, leaderboardId: number, firstEntry: number, count: number, aroundUser: number): void;
}
/** One in-flight `rc_client` request, kept so its answer can be routed back. */
interface PendingLogin {
    resolve: (user: VesRaUser) => void;
    reject: (error: Error) => void;
}
/** The same, for one outstanding page of leaderboard entries. */
interface PendingEntries {
    resolve: (entries: VesRaLeaderboardEntries) => void;
    reject: (error: Error) => void;
}
export declare class RetroAchievements {
    protected readonly moduleUrl: string | undefined;
    protected module: RcModule | undefined;
    protected client: number;
    /** Set once loading has been tried, so a failed load is not retried forever. */
    protected loadAttempted: boolean;
    protected unavailableReason: string | undefined;
    /** Events waiting for the drive loop to flush them to the DOM. */
    protected readonly outbox: VesRaEvent[];
    /** How the current session reads the machine's memory, or undefined when detached. */
    protected read: ((address: number) => number) | undefined;
    protected pendingLogin: PendingLogin | undefined;
    /** Outstanding {@link fetchLeaderboardEntries} calls, by the id sent to the shim. */
    protected readonly pendingEntries: Map<number, PendingEntries>;
    protected nextFetchId: number;
    /**
     * Told about every event the moment it is queued, so the worker can flush
     * it straight to the DOM instead of waiting for the next frame.
     *
     * Needed because a `serverCall` for login or a set load is queued by the
     * shim synchronously, but frames — the only other thing that flushes the
     * outbox — stop while the emulator is paused, e.g. behind the settings
     * dialog. Without this, signing in mid-session while paused hung forever:
     * the request never left the worker for the DOM to answer.
     */
    onPush: (() => void) | undefined;
    /** Whether a set is loaded and `doFrame` should be doing work. */
    protected gameLoaded: boolean;
    protected idleCountdown: number;
    /**
     * The hardcore flag the DOM last asked for, remembered so it can be
     * applied to a client that does not exist yet — `setHardcore` is called
     * before the first login on a fresh session, which is what creates it.
     */
    protected hardcore: boolean;
    /** So the "engine too old for hardcore" warning is logged at most once. */
    protected warnedNoHardcoreExport: boolean;
    constructor(moduleUrl: string | undefined);
    /**
     * Point the engine at a running simulation.
     *
     * `wasm` and `simPointer` belong to the main simulation only — never the
     * profile replay's scratch simulation or a linked peer, which must not feed
     * the achievement client.
     */
    attach(wasm: WasmExports, simPointer: number): void;
    /** Stop reading a simulation that is going away, and drop any loaded set. */
    detach(): void;
    /** Events accumulated since the last call; the worker flushes these. */
    takeEvents(): VesRaEvent[];
    loginPassword(username: string, password: string): Promise<VesRaUser>;
    loginToken(username: string, token: string): Promise<VesRaUser>;
    logout(): void;
    loadGame(hash: string): Promise<void>;
    unloadGame(): void;
    /**
     * Ask RetroAchievements for one page of a leaderboard's entries.
     *
     * Answered by the `lbentries` message the shim emits for this request's
     * own id, so several pages can be in flight without confusing one for
     * another — a "top of the board" and an "around me" request, say, which
     * the panel makes together.
     */
    fetchLeaderboardEntries(leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean): Promise<VesRaLeaderboardEntries>;
    /**
     * Give up on every outstanding page. rc_client answers its own callbacks
     * even when a request fails, so this is for the cases where it never gets
     * the chance — a logout, an unload, or the whole module going away.
     */
    protected failPendingEntries(reason: string): void;
    /** What to say when this `rcheevos.wasm` predates the export being reached for. */
    protected staleEngineMessage(): string;
    reset(): void;
    /**
     * Set the engine's hardcore flag. Kept even when there is no client yet,
     * so `applyHardcore` can arm the one `ensureLoaded` goes on to create.
     */
    setHardcore(enabled: boolean): void;
    protected applyHardcore(): void;
    provideResponse(requestId: number, status: number, body: string): void;
    /**
     * Advance the achievement client by one emulated frame.
     *
     * Called from the drive loop at the same frame break `applyCheats` runs at,
     * for the attached simulation only. Cheap when no set is loaded.
     */
    doFrame(): void;
    protected ensureLoaded(): Promise<boolean>;
    protected markUnavailable(reason: string): void;
    protected login(begin: (client: number) => void): Promise<VesRaUser>;
    protected onReadMemory(address: number, buffer: number, length: number): number;
    /**
     * RetroAchievements' Virtual Boy address space is two regions: `0x000000`
     * onward is WRAM, `0x010000` onward is cartridge RAM. Anything past that is
     * not addressable and reads as nothing.
     */
    protected toRealAddress(raAddress: number): number | undefined;
    protected onEmit(json: string): void;
    protected push(event: VesRaEvent): void;
    /**
     * Copy strings into the rcheevos heap for the duration of one synchronous
     * call, then free them. Every shim entry point that takes text follows this
     * pattern.
     */
    protected withStrings<T>(texts: string[], use: (pointers: number[]) => T): T;
    dispose(): void;
}
export {};
//# sourceMappingURL=vb-rcheevos.d.ts.map