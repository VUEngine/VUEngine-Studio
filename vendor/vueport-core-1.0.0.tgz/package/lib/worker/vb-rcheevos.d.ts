/**
 * The RetroAchievements engine, hosted in the emulator worker, since evaluating a set reads memory
 * synchronously once per frame and only the worker can do that (from the DOM it is a message round trip).
 * rcheevos runs as a second WebAssembly module beside the core, through a thin C shim
 * (../../wasm/rcheevos/shim/vueport-rc.c) that flattens rc_client to functions with primitive parameters.
 * This module makes no network requests: vrc_server_call becomes a serverCall event, the DOM side makes the
 * call (only the desktop shell can reach the RA API) and answers with raProvideResponse.
 * rcheevos.js + rcheevos.wasm are loaded lazily on the first login; a build without them reports
 * engineUnavailable.
 */
import { VesRaEvent, VesRaLeaderboardEntries, VesRaUser } from '../common/vb-protocol';
import { WasmExports } from './vb-wasm';
interface RcModule {
    HEAPU8: Uint8Array;
    _malloc(size: number): number;
    _free(pointer: number): void;
    stringToUTF8(text: string, pointer: number, maxBytes: number): void;
    lengthBytesUTF8(text: string): number;
    vrcReadMemory(address: number, buffer: number, length: number): number;
    vrcServerCall(requestId: number, method: string, url: string, post: string | undefined, contentType: string | undefined): void;
    vrcEmit(json: string): void;
    _vrc_create(): number;
    _vrc_destroy(client: number): void;
    _vrc_begin_login_password(client: number, username: number, password: number): void;
    _vrc_begin_login_token(client: number, username: number, token: number): void;
    _vrc_logout(client: number): void;
    _vrc_begin_load_game(client: number, hash: number): void;
    _vrc_unload_game(client: number): void;
    _vrc_reset(client: number): void;
    _vrc_set_hardcore?(client: number, enabled: number): void;
    _vrc_do_frame(client: number): void;
    _vrc_idle(client: number): void;
    _vrc_provide_response(requestId: number, status: number, body: number): void;
    _vrc_begin_fetch_leaderboard_entries?(client: number, fetchId: number, leaderboardId: number, firstEntry: number, count: number, aroundUser: number): void;
}
interface PendingLogin {
    resolve: (user: VesRaUser) => void;
    reject: (error: Error) => void;
}
interface PendingEntries {
    resolve: (entries: VesRaLeaderboardEntries) => void;
    reject: (error: Error) => void;
}
export declare class RetroAchievements {
    protected readonly moduleUrl: string | undefined;
    protected module: RcModule | undefined;
    protected client: number;
    protected loadAttempted: boolean;
    protected unavailableReason: string | undefined;
    protected readonly outbox: VesRaEvent[];
    protected read: ((address: number) => number) | undefined;
    protected pendingLogin: PendingLogin | undefined;
    protected readonly pendingEntries: Map<number, PendingEntries>;
    protected nextFetchId: number;
    onPush: (() => void) | undefined;
    protected gameLoaded: boolean;
    protected idleCountdown: number;
    protected hardcore: boolean;
    protected warnedNoHardcoreExport: boolean;
    constructor(moduleUrl: string | undefined);
    attach(wasm: WasmExports, simPointer: number): void;
    detach(): void;
    takeEvents(): VesRaEvent[];
    loginPassword(username: string, password: string): Promise<VesRaUser>;
    loginToken(username: string, token: string): Promise<VesRaUser>;
    logout(): void;
    loadGame(hash: string): Promise<void>;
    unloadGame(): void;
    fetchLeaderboardEntries(leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean): Promise<VesRaLeaderboardEntries>;
    protected failPendingEntries(reason: string): void;
    protected staleEngineMessage(): string;
    reset(): void;
    setHardcore(enabled: boolean): void;
    protected applyHardcore(): void;
    provideResponse(requestId: number, status: number, body: string): void;
    doFrame(): void;
    protected ensureLoaded(): Promise<boolean>;
    protected markUnavailable(reason: string): void;
    protected login(begin: (client: number) => void): Promise<VesRaUser>;
    protected onReadMemory(address: number, buffer: number, length: number): number;
    protected toRealAddress(raAddress: number): number | undefined;
    protected onEmit(json: string): void;
    protected push(event: VesRaEvent): void;
    protected withStrings<T>(texts: string[], use: (pointers: number[]) => T): T;
    dispose(): void;
}
export {};
//# sourceMappingURL=vb-rcheevos.d.ts.map