/**
 * The frames before the current one, for a screenshot that blends. The live renderer keeps them as textures nothing
 * else can read, so a screenshot drawn by a second renderer gets them from here: the one before for full, the two
 * before that too for smart. Follows the renderer's rules for what counts as the frame before (see FrameKind).
 * Four buffers take turns; a present costs one copy of a 344 KB frame
 */
import { Frame, FrameKind } from '../common/vb-protocol';
import { FrameBlending } from '../common/vb-constants';
export interface HeldFrame {
    pixels: Uint8Array;
    colorMode: boolean;
}
export declare class FrameHistory {
    protected current: Uint8Array<ArrayBuffer>;
    protected before: Uint8Array<ArrayBuffer>;
    protected earlier: Uint8Array<ArrayBuffer>;
    protected earliest: Uint8Array<ArrayBuffer>;
    protected currentColorMode: boolean;
    protected beforeColorMode: boolean;
    protected earlierColorMode: boolean;
    protected earliestColorMode: boolean;
    protected hasCurrent: boolean;
    protected hasBefore: boolean;
    protected hasEarlier: boolean;
    protected hasEarliest: boolean;
    protected blended: Uint8Array<ArrayBuffer>;
    protected flicker: Uint8Array<ArrayBuffer>;
    protected flickerSpread: Uint8Array<ArrayBuffer>;
    protected flickerBlocks: Uint8Array<ArrayBuffer>;
    protected flickerNear: Uint8Array<ArrayBuffer>;
    record(pixels: Uint8Array, colorMode: boolean, kind: FrameKind): void;
    previous(): Frame[];
    peekPrevious(): HeldFrame[];
    /**
     * The current frame blended as the renderer shows it, for the immersion halo, which reads the picture here; from
     * the raw frame, alternate-frame sprites would come and go in it. Same rules as the renderer (full everywhere,
     * smart where a pixel goes A, B, A, widened by MASK_REACH and mostly-flickering cells), except that legacy frames
     * mix each eye's brightness rather than its palette color and frames in different transports are not mixed at all
     */
    blendedCurrent(blending: FrameBlending): HeldFrame | undefined;
    protected flickerMask(rowStride: number, rightOffset: number, channels: number): Uint8Array;
}
/**
 * The last frames a fast-forwarded audio buffer emulated, for blending. Fast forward shows only the last of several
 * frames per buffer, so alternate-frame sprites would flicker at whatever rhythm the speed makes; the three frames
 * before the shown one go to the renderer ahead of it, so it blends as at normal speed. Only frames run back to back:
 * clear marks a gap
 */
export declare class SkippedFrames {
    protected readonly buffers: Uint8Array<ArrayBuffer>[];
    protected readonly colorModes: boolean[];
    protected count: number;
    protected next: number;
    hold(pixels: Uint8Array, colorMode: boolean): void;
    clear(): void;
    take(): HeldFrame[];
}
//# sourceMappingURL=vb-frame-history.d.ts.map