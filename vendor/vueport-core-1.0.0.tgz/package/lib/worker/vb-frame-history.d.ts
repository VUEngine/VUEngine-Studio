/**
 * The frames shown before the current one, for a screenshot that blends.
 *
 * The live renderer keeps its own frames before, as textures in its own
 * context — which nothing else can read. A screenshot composed to settings of
 * its own is drawn by a second renderer, and to blend it needs the same frames
 * the picture on screen was made of: the one before for `full`, and the two
 * before that too for `smart`, which compares them. So every presented frame
 * is also copied here, following the renderer's rules for what counts as the
 * frame before: see `FrameKind`.
 *
 * Four buffers that take turns, like the renderer's textures; a present costs
 * one copy of a 344 KB frame.
 */
import { Frame, FrameKind } from '../common/vb-protocol';
import { FrameBlending } from '../common/vb-constants';
/** A frame held here, valid until the next `record`. */
export interface HeldFrame {
    pixels: Uint8Array;
    colorMode: boolean;
}
export declare class FrameHistory {
    protected current: Uint8Array<ArrayBuffer>;
    protected before: Uint8Array<ArrayBuffer>;
    protected earlier: Uint8Array<ArrayBuffer>;
    protected earliest: Uint8Array<ArrayBuffer>;
    protected currentColorMode: boolean;
    protected beforeColorMode: boolean;
    protected earlierColorMode: boolean;
    protected earliestColorMode: boolean;
    protected hasCurrent: boolean;
    protected hasBefore: boolean;
    protected hasEarlier: boolean;
    protected hasEarliest: boolean;
    /** The current frame as blending shows it; see `blendedCurrent`. */
    protected blended: Uint8Array<ArrayBuffer>;
    /** Per pixel, bit 0 where the left eye's picture flickers, bit 1 the right's. */
    protected flicker: Uint8Array<ArrayBuffer>;
    protected flickerSpread: Uint8Array<ArrayBuffer>;
    /** Per cell, the same bits where most of it flickers. */
    protected flickerBlocks: Uint8Array<ArrayBuffer>;
    record(pixels: Uint8Array, colorMode: boolean, kind: FrameKind): void;
    /** Copies of the frames before the current one, the most recent first. */
    previous(): Frame[];
    /** The frames before the current one, the most recent first, without copying. */
    peekPrevious(): HeldFrame[];
    /**
     * The current frame mixed with the one before the way the renderer's
     * frame blending shows it, for what reads the picture on this side rather
     * than off the screen: the immersion halo. Without it the halo is made
     * from the raw frame, and anything drawn on alternate frames comes and
     * goes in it while the picture holds it steady.
     *
     * Same rules as the renderer — `full` everywhere, `smart` only where a
     * pixel goes A, B, A in this frame or the one before, widened by
     * MASK_REACH and by the cells that mostly do — with two differences that do
     * not matter to something blurred this far: legacy frames mix each eye's
     * brightness rather than its palette color, and frames in different
     * transports are not mixed at all.
     */
    blendedCurrent(blending: FrameBlending): HeldFrame | undefined;
    /** The renderer's RAW_SHADER, BLOCK_SHADER and MASK_SHADER, over the frames held here. */
    protected flickerMask(rowStride: number, rightOffset: number, channels: number): Uint8Array;
}
/**
 * The last few frames a fast-forwarded audio buffer emulated, for blending.
 *
 * Fast forward runs several frames per buffer and shows only the last, so
 * the frames the renderer blends are not consecutive: a sprite drawn on
 * alternate frames is in some shown frames and not in others, at whatever
 * rhythm the speed makes — and blending, which only knows the frames it was
 * shown, flickers along. Held here, the three frames before the shown one go
 * to the renderer ahead of it, and it blends as at normal speed.
 *
 * Only ever frames run back to back: `clear` marks a gap.
 */
export declare class SkippedFrames {
    protected readonly buffers: Uint8Array<ArrayBuffer>[];
    protected readonly colorModes: boolean[];
    /** Frames held, at most four; the newest is at `(next + 3) % 4`. */
    protected count: number;
    protected next: number;
    hold(pixels: Uint8Array, colorMode: boolean): void;
    clear(): void;
    /**
     * The frames held before the newest, oldest first, and forget them all.
     * The newest is left out: it is the frame about to be shown anyway.
     * Valid until the next `hold`.
     */
    take(): HeldFrame[];
}
//# sourceMappingURL=vb-frame-history.d.ts.map