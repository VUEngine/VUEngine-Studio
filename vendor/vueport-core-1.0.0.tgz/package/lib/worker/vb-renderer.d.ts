/**
 * Presentation for one simulation.
 *
 * Legacy VB frames use one eye-packed texture, where red carries the left
 * eye's brightness and green the right eye's. A VBC-capable core instead
 * supplies RGB888: an image twice the screen's width, the left eye's picture
 * in the left half and the right eye's in the right. The frame textures are
 * that double width; a legacy frame fills their left half. Every display mode
 * is derived from the active transport by the fragment shader below, so
 * switching layouts still never touches emulation.
 *
 * With frame blending on, a frame is shown mixed half and half with the one
 * before it, which is how the picture reads when the eye integrates the
 * display's scanned, flickering image over time: anything drawn on alternate
 * frames — a common trick for transparency and for more sprites than fit —
 * comes out as the steady half-bright shape it was meant to be. `full` mixes
 * every pixel, which also trails everything that moves. `smart` mixes only
 * where the picture flickers: a pixel that differs from the frame before but
 * is back to what it was the frame before that, in this frame or the one
 * before. Something that moves is somewhere else two frames on, and stays
 * sharp. That test is made once per frame at the console's own resolution,
 * into a mask the picture then reads — see RAW_SHADER, BLOCK_SHADER and
 * MASK_SHADER. The frames are four textures that take turns on every
 * present, so none is ever copied.
 *
 * Normally runs on the worker's OffscreenCanvas. Linux Tauri uses the same
 * renderer on an HTMLCanvasElement instead, because WebKitGTK exposes WebGL2
 * on the page but not inside a worker.
 */
import { DisplayMode, DisplayOutput } from '../common/vb-constants';
import { FrameKind } from '../common/vb-protocol';
export declare class VbRenderer {
    protected readonly canvas: OffscreenCanvas | HTMLCanvasElement;
    protected readonly gl: WebGL2RenderingContext;
    /**
     * The frame on show and the three before it. They take turns on every
     * present: the next frame is uploaded over the oldest, so the others are
     * always still there without being copied.
     */
    protected current: WebGLTexture;
    protected previous: WebGLTexture;
    protected earlier: WebGLTexture;
    protected earliest: WebGLTexture;
    /**
     * Where the picture flickers, and the framebuffer it is drawn through;
     * see MASK_SHADER. Drawn from the pixels that flicker and the cells that
     * mostly do, each with a framebuffer of its own; see RAW_SHADER and
     * BLOCK_SHADER.
     */
    protected readonly mask: WebGLTexture;
    protected readonly maskFramebuffer: WebGLFramebuffer;
    protected readonly rawMask: WebGLTexture;
    protected readonly rawMaskFramebuffer: WebGLFramebuffer;
    protected readonly blockMask: WebGLTexture;
    protected readonly blockMaskFramebuffer: WebGLFramebuffer;
    protected readonly drawProgram: WebGLProgram;
    protected readonly rawMaskProgram: WebGLProgram;
    protected readonly blockMaskProgram: WebGLProgram;
    protected readonly maskProgram: WebGLProgram;
    protected readonly maskColorMode: WebGLUniformLocation | null;
    protected readonly maskHasEarliest: WebGLUniformLocation | null;
    /** Whether the mask is out of date with the frames. */
    protected maskStale: boolean;
    /** What uBlend was last set to. */
    protected blend: number;
    protected readonly uniforms: {
        palette: WebGLUniformLocation | null;
        anaglyphLeft: WebGLUniformLocation | null;
        anaglyphRight: WebGLUniformLocation | null;
        anaglyphMatrixLeft: WebGLUniformLocation | null;
        anaglyphMatrixRight: WebGLUniformLocation | null;
        dubois: WebGLUniformLocation | null;
        output: WebGLUniformLocation | null;
        layout: WebGLUniformLocation | null;
        eyes: WebGLUniformLocation | null;
        colorMode: WebGLUniformLocation | null;
        parity: WebGLUniformLocation | null;
        swapEyes: WebGLUniformLocation | null;
        blend: WebGLUniformLocation | null;
        previousColorMode: WebGLUniformLocation | null;
    };
    /** The mode last set; kept for the size it implies. */
    protected mode: DisplayMode;
    /** Where an interleaved picture is really shown, when the page has said. */
    protected output: DisplayOutput | undefined;
    /** Whether the texture contains a frame that a mode change can redraw. */
    protected hasFrame: boolean;
    protected lastColorMode: boolean;
    /** Whether `previous` holds a frame presented before `current`. */
    protected hasPrevious: boolean;
    protected previousColorMode: boolean;
    /** Whether `earlier` holds a frame presented before `previous`. */
    protected hasEarlier: boolean;
    protected earlierColorMode: boolean;
    /** Whether `earliest` holds a frame presented before `earlier`. */
    protected hasEarliest: boolean;
    protected earliestColorMode: boolean;
    constructor(canvas: OffscreenCanvas | HTMLCanvasElement, mode: DisplayMode);
    /**
     * A frame texture, or with a size a smaller one: the flicker mask's cells.
     */
    protected createFrameTexture(width?: number, height?: number): WebGLTexture;
    /** A framebuffer that draws into `texture`. */
    protected createTarget(texture: WebGLTexture): WebGLFramebuffer;
    /**
     * Put the frames and the masks on their units, ending on the frame on show
     * at unit 0 — the one a present uploads into.
     */
    protected bindFrames(): void;
    /**
     * Blend only when asked to and when there is what it takes: a frame before
     * to blend with, and for `smart` one more, in the same transport — a
     * legacy frame and a VBC one cannot be compared byte for byte.
     */
    protected applyBlend(): void;
    /**
     * Draw the flicker mask from the frames, in its three passes, leaving the
     * program, the framebuffer and the viewport as they were found: the
     * headset draws through a framebuffer of its own.
     */
    protected updateMask(): void;
    /** The mode last set. */
    get displayMode(): DisplayMode;
    /**
     * Whether the drawing buffer is the mode's own size, and so a capture of
     * it is the picture as a file would want it. Not so for an interleaved
     * mode drawn at the size it is shown; that is captured by composing the
     * frame again — see the callers of `capture`.
     */
    get atModeSize(): boolean;
    /**
     * Draw an interleaved picture at the size it is shown at, or, with
     * `undefined`, at the mode's own size again. Kept across mode changes and
     * ignored by the modes that do not interleave.
     */
    setDisplayOutput(output: DisplayOutput | undefined): void;
    /** Size the drawing buffer, and tell the shader what it was sized to. */
    protected applySize(): void;
    setDisplayMode(mode: DisplayMode): void;
    present(pixels: Uint8Array, colorMode?: boolean, kind?: FrameKind): void;
    /**
     * Encode the presented frame as a PNG, optionally at a whole multiple of
     * its own size.
     *
     * The enlargement is a nearest-neighbor blit afterwards rather than a
     * bigger render: the shader works in output pixels and maps each straight
     * onto a source one, so a larger drawing buffer would not be a larger
     * picture but a differently-cut one. Blitting keeps the pixels square and
     * leaves the live path's shader alone.
     *
     * Indexed when the frame has no more than 256 colours, which is nearly
     * always; the canvas's own truecolour encoder otherwise.
     */
    capture(scale?: number): Promise<ArrayBuffer>;
    /** The frame as an indexed PNG, or nothing if it has too many colours or cannot be read back. */
    protected captureIndexed(scale: number): Promise<Uint8Array<ArrayBuffer> | undefined>;
    protected createCanvas(width: number, height: number): OffscreenCanvas | HTMLCanvasElement;
    protected draw(): void;
    protected buildProgram(fragmentShader: string): WebGLProgram;
    protected compile(type: number, source: string): WebGLShader;
    dispose(): void;
}
//# sourceMappingURL=vb-renderer.d.ts.map