/**
 * Presentation for one simulation.
 *
 * Legacy VB frames use one eye-packed texture, where red carries the left
 * eye's brightness and green the right eye's. A VBC-capable core instead
 * supplies packed RGB555 (left in R/G, right in B/A). Every display mode is
 * derived from the active transport by the fragment shader below, so switching
 * layouts still never touches emulation.
 *
 * Normally runs on the worker's OffscreenCanvas. Linux Tauri uses the same
 * renderer on an HTMLCanvasElement instead, because WebKitGTK exposes WebGL2
 * on the page but not inside a worker.
 */
import { DisplayMode } from '../common/vb-constants';
export declare class VbRenderer {
    protected readonly canvas: OffscreenCanvas | HTMLCanvasElement;
    protected readonly gl: WebGL2RenderingContext;
    protected readonly texture: WebGLTexture;
    protected readonly uniforms: {
        palette: WebGLUniformLocation | null;
        anaglyphLeft: WebGLUniformLocation | null;
        anaglyphRight: WebGLUniformLocation | null;
        anaglyphMatrixLeft: WebGLUniformLocation | null;
        anaglyphMatrixRight: WebGLUniformLocation | null;
        dubois: WebGLUniformLocation | null;
        output: WebGLUniformLocation | null;
        layout: WebGLUniformLocation | null;
        eyes: WebGLUniformLocation | null;
        colorMode: WebGLUniformLocation | null;
    };
    /** Whether the texture contains a frame that a mode change can redraw. */
    protected hasFrame: boolean;
    protected lastColorMode: boolean;
    constructor(canvas: OffscreenCanvas | HTMLCanvasElement, mode: DisplayMode);
    setDisplayMode(mode: DisplayMode): void;
    present(pixels: Uint8Array, colorMode?: boolean): void;
    /**
     * Encode the presented frame as a PNG, optionally at a whole multiple of
     * its own size.
     *
     * The enlargement is a nearest-neighbor blit afterwards rather than a
     * bigger render: the shader works in output pixels and maps each straight
     * onto a source one, so a larger drawing buffer would not be a larger
     * picture but a differently-cut one. Blitting keeps the pixels square and
     * leaves the live path's shader alone.
     */
    capture(scale?: number): Promise<ArrayBuffer>;
    protected createCanvas(width: number, height: number): OffscreenCanvas | HTMLCanvasElement;
    protected draw(): void;
    protected buildProgram(): WebGLProgram;
    protected compile(type: number, source: string): WebGLShader;
    dispose(): void;
}
//# sourceMappingURL=vb-renderer.d.ts.map