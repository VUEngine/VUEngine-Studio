/**
 * Presentation for one simulation. Legacy VB frames use one eye-packed texture (red the left eye's brightness, green
 * the right's); a VBC-capable core supplies RGB888 at twice the screen's width, left eye in the left half, right eye
 * in the right. The frame textures are that double width, a legacy frame fills their left half. Every display mode
 * is derived from the transport in the fragment shader, so switching layouts never touches emulation.
 * Frame blending mixes a frame half and half with the one before, as the eye integrates the flickering display, so
 * things drawn on alternate frames (transparency, sprite multiplexing) come out steady. `full` mixes every pixel and
 * trails what moves; `smart` mixes only where a pixel goes A, B, A in this frame or the one before, so movement stays
 * sharp. That test runs once per frame at console resolution into a mask (RAW_SHADER, BLOCK_SHADER, MASK_SHADER).
 * The frames are four textures taking turns on every present, so none is ever copied.
 * Normally runs on the worker's OffscreenCanvas; Linux Tauri uses an HTMLCanvasElement, as WebKitGTK exposes WebGL2
 * on the page but not inside a worker.
 */
import { DisplayMode, DisplayOutput } from '../common/vb-constants';
import { FrameKind } from '../common/vb-protocol';
export declare class VbRenderer {
    protected readonly canvas: OffscreenCanvas | HTMLCanvasElement;
    protected readonly gl: WebGL2RenderingContext;
    protected current: WebGLTexture;
    protected previous: WebGLTexture;
    protected earlier: WebGLTexture;
    protected earliest: WebGLTexture;
    protected readonly mask: WebGLTexture;
    protected readonly maskFramebuffer: WebGLFramebuffer;
    protected readonly rawMask: WebGLTexture;
    protected readonly rawMaskFramebuffer: WebGLFramebuffer;
    protected readonly blockMask: WebGLTexture;
    protected readonly blockMaskFramebuffer: WebGLFramebuffer;
    protected readonly drawProgram: WebGLProgram;
    protected readonly rawMaskProgram: WebGLProgram;
    protected readonly blockMaskProgram: WebGLProgram;
    protected readonly maskProgram: WebGLProgram;
    protected readonly maskColorMode: WebGLUniformLocation | null;
    protected readonly maskHasEarliest: WebGLUniformLocation | null;
    protected maskStale: boolean;
    protected blend: number;
    protected readonly uniforms: {
        palette: WebGLUniformLocation | null;
        anaglyphLeft: WebGLUniformLocation | null;
        anaglyphRight: WebGLUniformLocation | null;
        anaglyphMatrixLeft: WebGLUniformLocation | null;
        anaglyphMatrixRight: WebGLUniformLocation | null;
        dubois: WebGLUniformLocation | null;
        output: WebGLUniformLocation | null;
        layout: WebGLUniformLocation | null;
        eyes: WebGLUniformLocation | null;
        colorMode: WebGLUniformLocation | null;
        parity: WebGLUniformLocation | null;
        swapEyes: WebGLUniformLocation | null;
        blend: WebGLUniformLocation | null;
        previousColorMode: WebGLUniformLocation | null;
    };
    protected mode: DisplayMode;
    protected output: DisplayOutput | undefined;
    protected hasFrame: boolean;
    protected lastColorMode: boolean;
    protected hasPrevious: boolean;
    protected previousColorMode: boolean;
    protected hasEarlier: boolean;
    protected earlierColorMode: boolean;
    protected hasEarliest: boolean;
    protected earliestColorMode: boolean;
    constructor(canvas: OffscreenCanvas | HTMLCanvasElement, mode: DisplayMode);
    protected createFrameTexture(width?: number, height?: number): WebGLTexture;
    protected createTarget(texture: WebGLTexture): WebGLFramebuffer;
    protected bindFrames(): void;
    protected applyBlend(): void;
    protected updateMask(): void;
    get displayMode(): DisplayMode;
    get atModeSize(): boolean;
    setDisplayOutput(output: DisplayOutput | undefined): void;
    protected applySize(): void;
    setDisplayMode(mode: DisplayMode): void;
    present(pixels: Uint8Array, colorMode?: boolean, kind?: FrameKind): void;
    /**
     * Encodes the presented frame as a PNG, optionally at a whole multiple of its size. Enlarged by a nearest-neighbor
     * blit afterwards: the shader maps each output pixel to a source one, so a bigger drawing buffer would be a
     * differently cut picture. Indexed when the frame has no more than 256 colours (nearly always), else the canvas's
     * own truecolour encoder.
     */
    capture(scale?: number): Promise<ArrayBuffer>;
    protected captureIndexed(scale: number): Promise<Uint8Array<ArrayBuffer> | undefined>;
    protected createCanvas(width: number, height: number): OffscreenCanvas | HTMLCanvasElement;
    protected draw(): void;
    protected buildProgram(fragmentShader: string): WebGLProgram;
    protected compile(type: number, source: string): WebGLShader;
    dispose(): void;
}
//# sourceMappingURL=vb-renderer.d.ts.map