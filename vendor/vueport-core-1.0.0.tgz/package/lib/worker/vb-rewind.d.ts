/**
 * Reverse delta codec for the rewind history.
 *
 * The simulation state struct is 1.85 MiB but only about 0.2% of it changes
 * per frame, so storing whole snapshots wastes almost all of the memory budget.
 * Encoding just the changed runs measures at roughly 112x smaller on a real
 * game (see scripts/rewind-cost-probe.mjs), which turns a 128 MB budget from
 * barely a second of history into minutes of it.
 *
 * A delta converts the newer state back to the older one, which is the
 * direction rewind walks, so stepping back is one XOR pass over the changed
 * bytes and needs no keyframes.
 *
 * Encoding is a series of runs: [uint32 offset][uint32 length][length bytes].
 */
/**
 * Changed words closer together than this stay in one run rather than paying
 * another 8 byte header. Measured as the sweet spot on a real game.
 */
export declare const REWIND_RUN_GAP_WORDS = 4;
/** Scratch run boundaries, so encoding allocates only its result. */
export interface RunScratch {
    starts: Int32Array;
    ends: Int32Array;
}
export declare function createRunScratch(capacity?: number): RunScratch;
/**
 * Encode how `current` differs from `previous`.
 *
 * Applying the result to `current` yields `previous`. Both must be the same
 * length and a multiple of four bytes; comparison runs a word at a time, which
 * is both faster and how the state is actually laid out.
 */
export declare function encodeDelta(previous: Uint8Array, current: Uint8Array, scratch: RunScratch): Uint8Array;
/** Apply a delta in place, walking the target back one capture. */
export declare function applyDelta(target: Uint8Array, delta: Uint8Array): void;
//# sourceMappingURL=vb-rewind.d.ts.map