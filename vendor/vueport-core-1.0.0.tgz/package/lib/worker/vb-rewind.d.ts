/**
 * Reverse delta codec for the rewind history. The 1.85 MiB state struct changes by about 0.2% per frame; encoding
 * only the changed runs is roughly 112x smaller on a real game (scripts/rewind-cost-probe.mjs), turning a 128 MB
 * budget from barely a second of history into minutes. A delta turns the newer state into the older one, the
 * direction rewind walks, so stepping back is one XOR pass and needs no keyframes.
 * Encoding is a series of runs: [uint32 offset][uint32 length][length bytes].
 */
export declare const REWIND_RUN_GAP_WORDS = 4;
export interface RunScratch {
    starts: Int32Array;
    ends: Int32Array;
}
export declare function createRunScratch(capacity?: number): RunScratch;
export declare function encodeDelta(previous: Uint8Array, current: Uint8Array, scratch: RunScratch): Uint8Array;
export declare function applyDelta(target: Uint8Array, delta: Uint8Array): void;
export declare const REWIND_THUMBNAIL_FRAMES = 50;
/**
 * A presented frame at half size in both directions, for the filmstrip: each pixel the average of a 2x2 block, and of
 * an RGBA pixel only the first `channels` (legacy frames carry the two eyes' brightness in red and green, VBC frames
 * their RGB). `width` is the frame's own, so a VBC frame's two eyes stay apart, as the halves meet on an even column.
 */
export declare function shrinkFrame(pixels: Uint8Array, width: number, height: number, channels: number): Uint8Array;
export declare function growFrame(shrunk: Uint8Array, width: number, height: number, channels: number, out: Uint8Array): void;
//# sourceMappingURL=vb-rewind.d.ts.map