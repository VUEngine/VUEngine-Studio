export {};
//# sourceMappingURL=vb-audio-worklet.d.ts.map