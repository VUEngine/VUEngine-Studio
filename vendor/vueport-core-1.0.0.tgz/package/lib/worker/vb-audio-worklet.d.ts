/**
 * Emulator audio output processor.
 *
 * Drains interleaved stereo buffers produced by the core worker into the audio
 * graph, and returns each emptied buffer to the worker. That return is what
 * clocks emulation, so this processor is the session's timing source: buffers
 * are cycled rather than allocated, and never copied.
 *
 * Bundled as a standalone AudioWorklet entry point, so it must not import
 * anything from Theia.
 */
export {};
//# sourceMappingURL=vb-audio-worklet.d.ts.map