import { ColumnSpread, SpinUpFrame } from '../common/vb-column-geometry';
/**
 * Frames as the column table shapes them: each eye's columns moved to where
 * the mirror put them, see `vb-column-geometry.ts`.
 *
 * In the frame itself rather than in the renderer, so the picture on screen,
 * the frames blending mixes in, screenshots, recordings and the headset all
 * see the same thing without each learning about columns. An eye shown with
 * Nintendo's table — every commercial game — is passed through untouched, and
 * a frame with both such eyes is not copied at all.
 */
export declare class ColumnFrames {
    protected readonly shapes: Map<string, ColumnSpread>;
    protected readonly output: {
        legacy: Uint8Array<ArrayBuffer>;
        color: Uint8Array<ArrayBuffer>;
    };
    /**
     * The frame as shown with these lengths: 96 per eye, left eye first, as
     * `vbGetColumnLengths` hands them over — and, while the display unit is
     * still coming to life, with its mirror as it is then (see
     * `mirrorSpinUp`). Either `pixels` itself or a copy that is only good
     * until the next call.
     */
    shape(pixels: Uint8Array, colorMode: boolean, lengths: Uint8Array, spinUp?: SpinUpFrame): Uint8Array;
    protected spreadOf(lengths: Uint8Array, eye: number): ColumnSpread;
}
//# sourceMappingURL=vb-column-frames.d.ts.map