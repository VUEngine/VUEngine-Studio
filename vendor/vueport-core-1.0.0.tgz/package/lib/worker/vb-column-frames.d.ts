import { ColumnSpread, SpinUpFrame } from '../common/vb-column-geometry';
export declare class ColumnFrames {
    protected readonly shapes: Map<string, ColumnSpread>;
    protected readonly output: {
        legacy: Uint8Array<ArrayBuffer>;
        color: Uint8Array<ArrayBuffer>;
    };
    shape(pixels: Uint8Array, colorMode: boolean, lengths: Uint8Array, spinUp?: SpinUpFrame): Uint8Array;
    protected spreadOf(lengths: Uint8Array, eye: number): ColumnSpread;
}
//# sourceMappingURL=vb-column-frames.d.ts.map