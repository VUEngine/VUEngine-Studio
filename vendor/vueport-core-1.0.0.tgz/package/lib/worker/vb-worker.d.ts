/**
 * Emulator core worker: owns the WebAssembly core and every simulation of one session, and runs the drive loop.
 * Emulation is clocked by audio consumption: each sample buffer the worklet returns emulates exactly
 * VB_CLOCKS_PER_BUFFER clocks and is refilled. Video is paced against the audio backlog, so picture and sound
 * stay in step without a separate timer.
 * MUST NOT import anything from Theia, it is bundled as a standalone worker entry point.
 */
export {};
//# sourceMappingURL=vb-worker.d.ts.map