/**
 * Emulator core worker.
 *
 * Owns the WebAssembly core and every simulation in one emulation session, and
 * runs the drive loop. Emulation is clocked by audio consumption: the audio
 * worklet returns emptied sample buffers, and each returned buffer causes
 * exactly VB_CLOCKS_PER_BUFFER clocks to be emulated and the buffer refilled.
 * Video is paced against the audio backlog so that picture and sound stay in
 * step without a separate timer.
 *
 * This module MUST NOT import anything from Theia; it is bundled as a
 * standalone worker entry point.
 */
export {};
//# sourceMappingURL=vb-worker.d.ts.map