import { VbAnaglyphMatrices, VbAnaglyphPalette } from '../common/vb-constants';
/**
 * Calibration is explicit, never guessed from RGB swatches. Custom filters
 * remain channel masks even when their colors match a calibrated preset:
 * editing a tint must not silently switch algorithms. For Dubois profiles the
 * swatches are only labels, not additional matrix gains.
 */
export declare function duboisMatrices(filters: VbAnaglyphPalette): VbAnaglyphMatrices | undefined;
/** CPU equivalent of the renderer's anaglyph composition, for UI previews and halos. */
export declare function composeAnaglyph(leftColor: number, rightColor: number, filters: VbAnaglyphPalette): number;
//# sourceMappingURL=vb-anaglyph.d.ts.map