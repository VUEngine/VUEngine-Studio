import { VbAnaglyphMatrices, VbAnaglyphPalette } from '../common/vb-constants';
export declare function duboisMatrices(filters: VbAnaglyphPalette): VbAnaglyphMatrices | undefined;
export declare function composeAnaglyph(leftColor: number, rightColor: number, filters: VbAnaglyphPalette): number;
//# sourceMappingURL=vb-anaglyph.d.ts.map