import { WasmExports } from './vb-wasm';
export interface VsuChannelOffsets {
    on: number;
    autoDeactivate: number;
    interval: number;
    left: number;
    right: number;
    frequency: number;
    level: number;
    envelopeGrows: number;
    envelopeStep: number;
    envelopeOn: number;
    envelopeRepeats: number;
    waveform?: number;
}
export interface VsuSweepOffsets {
    clock: number;
    up: number;
    interval: number;
    shift: number;
    on: number;
    repeats: number;
    modulates: number;
}
export interface VsuLayout {
    channels: VsuChannelOffsets[];
    sweep: VsuSweepOffsets;
    noiseTap: number;
    waveforms: number;
    modulation: number;
}
export declare function calibrateVsuLayout(wasm: WasmExports): VsuLayout;
export interface VsuMuteState {
    channels: number;
    levels: Uint8Array;
}
export declare function createVsuMuteState(): VsuMuteState;
/**
 * Holds muted channels at zero for levels that did not arrive as a CPU write (takeVsuLevelWrite handles those): the
 * moment a channel is muted, and a restored or rewound state. The stereo level rather than the enable bit, so a muted
 * channel still plays, steps its envelope and switches itself off as if audible; only nothing comes out. What it takes
 * away is kept for the strip, but only a nonzero level, as its own zero cannot be told from one the machine holds.
 */
export declare function applyVsuMutes(wasm: WasmExports, layout: VsuLayout, sim: number, muted: VsuMuteState): void;
export declare function vsuLevelWriteChannel(address: number): number;
/**
 * Where muting actually happens. Zeroing the register between frames is not enough: a sound driver rewrites SxLRV on
 * every tick (envelopes, fades, panning), so a muted channel would be heard for most of every frame. Catching the
 * write silences it from the instruction on. The game's level is kept, for the panel to show and for unmuting to put
 * back, including a zero it writes itself.
 */
export declare function takeVsuLevelWrite(muted: VsuMuteState, channel: number, value: number): boolean;
export declare function restoreVsuMutes(wasm: WasmExports, layout: VsuLayout, sim: number, muted: VsuMuteState, released: number): void;
export declare function composeVsuMap(wasm: WasmExports, layout: VsuLayout, sim: number, muted?: VsuMuteState | undefined): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=vb-vsu-layout.d.ts.map