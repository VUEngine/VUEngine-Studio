import { WasmExports } from './vb-wasm';
/**
 * One channel's bytes inside the simulation struct, as offsets from its start.
 *
 * Every one of these is the core's own decoded copy of a register field, so
 * reading them is reading the VSU itself rather than a record of what somebody
 * asked for.
 */
export interface VsuChannelOffsets {
    /** SxINT bit 7, as the hardware holds it: it clears this itself when an interval elapses. */
    on: number;
    /** SxINT bit 5. */
    autoDeactivate: number;
    /** SxINT bits 0-4. */
    interval: number;
    left: number;
    right: number;
    /** Eleven bits over two bytes, as it is being played: sweep and modulation move it. */
    frequency: number;
    /** The level as it is now, which the envelope walks up or down. */
    level: number;
    /** SxEV0 bit 3. */
    envelopeGrows: number;
    /** SxEV0 bits 0-2. */
    envelopeStep: number;
    /** SxEV1 bit 0. */
    envelopeOn: number;
    /** SxEV1 bit 1. */
    envelopeRepeats: number;
    /** SxRAM. Absent on Noise, which plays no waveform. */
    waveform?: number;
}
/** Sweep/modulation, which only the fifth channel has. */
export interface VsuSweepOffsets {
    /** S5SWP bit 7. */
    clock: number;
    /** S5SWP bit 3. */
    up: number;
    /** S5SWP bits 4-6. */
    interval: number;
    /** S5SWP bits 0-2. */
    shift: number;
    /** SxEV1 bit 6. */
    on: number;
    /** SxEV1 bit 5. */
    repeats: number;
    /** SxEV1 bit 4. */
    modulates: number;
}
export interface VsuLayout {
    channels: VsuChannelOffsets[];
    sweep: VsuSweepOffsets;
    /** SxEV1 bits 4-6 on the Noise channel. */
    noiseTap: number;
    /** The first of five banks of {@link WAVEFORM_SAMPLES} bytes, one byte per sample. */
    waveforms: number;
    /** {@link WAVEFORM_SAMPLES} bytes, one per modulation step. */
    modulation: number;
}
/**
 * Find the core's VSU state on a throwaway simulation.
 *
 * Throws, with what it was looking for, if the core does not keep its state
 * anywhere this can recognize.
 */
export declare function calibrateVsuLayout(wasm: WasmExports): VsuLayout;
/**
 * Which channels the emulator is holding silent, and what the game last asked
 * them to play at.
 *
 * Two bytes per channel, left then right, and meaningful only for a channel
 * whose bit is set in {@link channels}.
 */
export interface VsuMuteState {
    /** Bit `n` for channel `n`. */
    channels: number;
    levels: Uint8Array;
}
export declare function createVsuMuteState(): VsuMuteState;
/**
 * Hold the muted channels at zero, for levels that did not arrive as a CPU
 * write.
 *
 * {@link takeVsuLevelWrite} is what mutes a channel the game is playing;
 * this is for the two ways a level turns up without anybody writing it —
 * the moment a channel is muted, when whatever it was already playing at has
 * to go, and a state that was restored or rewound, which replaces the whole
 * simulation behind the emulator's back.
 *
 * The stereo level rather than the enable bit, because the panel's whole
 * subject is which channels are sounding: a channel muted here is still
 * playing, still stepping its envelope and still switching itself off when its
 * interval runs out, exactly as it would be if it were audible. Only nothing
 * comes out.
 *
 * What it takes away is kept, so that a muted strip still shows its levels.
 * Only a level that is actually there, though: the zero this itself leaves
 * behind cannot be told from one the machine holds, and overwriting the kept
 * levels with it would lose them.
 */
export declare function applyVsuMutes(wasm: WasmExports, layout: VsuLayout, sim: number, muted: VsuMuteState): void;
/**
 * The channel whose stereo level a CPU write is about to land on, or -1.
 *
 * `SxLRV` and nothing else: it is the one register that says how loud a
 * channel is on each side, and holding it at zero is what a mute is. See
 * {@link takeVsuLevelWrite}.
 */
export declare function vsuLevelWriteChannel(address: number): number;
/**
 * Take a muted channel's level for safe keeping, and say whether the write
 * should be silenced on its way past.
 *
 * This is where muting actually happens. Zeroing the register between frames
 * is not enough on its own: a sound driver rewrites `SxLRV` on every tick —
 * for envelopes, fades and panning — so the level a mute took away would be
 * back a few hundred microseconds later, and a muted channel would be heard
 * for most of every frame. Catching the write instead means a muted channel is
 * silent from the instruction that would have made it loud.
 *
 * What the game asked for is kept rather than thrown away, so the panel can go
 * on showing the level the game thinks it is playing at, and so unmuting can
 * put it back. A zero the game writes itself is kept too: it is what the
 * channel should come back at.
 */
export declare function takeVsuLevelWrite(muted: VsuMuteState, channel: number, value: number): boolean;
/**
 * Give back the levels of channels that are not muted any more.
 *
 * Muting is destructive — it zeroes the core's own copy of the stereo level —
 * and a game does not rewrite that on its own: `SxLRV` is written when a voice
 * is set up, and a channel restarted with `SxINT` alone keeps whatever level it
 * already had. So unmuting has to put back what was taken, or a channel let out
 * of the mix would simply never be heard again.
 *
 * Only where the mute's own zero is still there. A game that wrote a level of
 * its own while the channel was muted has said something newer than this, and
 * keeps it.
 */
export declare function restoreVsuMutes(wasm: WasmExports, layout: VsuLayout, sim: number, muted: VsuMuteState, released: number): void;
/**
 * The VSU as it is right now, in the shape the panel reads: the waveform
 * banks, the modulation table and the six register blocks, `VB_VSU_MAP_BYTES`
 * from `VB_VSU_BASE`.
 *
 * Composed rather than copied, because the core does not keep registers — it
 * keeps what it decoded them into. Where it holds both what a channel was
 * given and what it is doing, what it is doing is what goes in: a panel
 * answering "which channels are playing, and how loudly" wants the machine's
 * present tense, and the two only differ while an envelope or a sweep is
 * running.
 */
export declare function composeVsuMap(wasm: WasmExports, layout: VsuLayout, sim: number, muted?: VsuMuteState | undefined): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=vb-vsu-layout.d.ts.map