/**
 * Typed view of the Shrooms-VB core's WebAssembly exports.
 *
 * The `vb*` functions are the core's public C API. The capitalized ones are the
 * web build's helpers, which wrap allocation, the anaglyph mixer and the
 * multi-simulation emulation entry point.
 *
 * The module has exactly one import (`emscripten_notify_memory_growth`) and is
 * otherwise self-contained.
 */
export interface WasmExports {
    memory: WebAssembly.Memory;
    __indirect_function_table: WebAssembly.Table;
    _initialize(): void;
    Realloc(pointer: number, size: number): number;
    PointerSize(): number;
    vbSizeOf(): number;
    CreateSim(): number;
    vbReset(sim: number): void;
    SetHardwareMode?(sim: number, vbc: number): void;
    GetHardwareMode?(sim: number): number;
    vbGetCartROM(sim: number): number;
    vbSetCartROM(sim: number, pointer: number, size: number): number;
    vbGetCartRAM(sim: number): number;
    vbSetCartRAM(sim: number, pointer: number, size: number): number;
    /**
     * Emulate an array of simulations. `clocks` points at a uint32 holding the
     * number of clocks left to run, which is decremented in place; emulation
     * returns early on a break condition, so callers loop until it reaches 0.
     */
    Emulate(sims: number, count: number, clocks: number): void;
    GetBreaks(sim: number): number;
    GetPixels(sim: number): void;
    GetExtPixels(sim: number): number;
    GetColorPixels?(sim: number): void;
    GetExtColorPixels?(sim: number): number;
    GetVideoFormat?(sim: number): number;
    SetAnaglyph(sim: number, left: number, right: number): void;
    GetExtSamples(sim: number): number;
    vbSetSamples(sim: number, pointer: number, type: number, count: number): void;
    Mix(destination: number, sims: number, count: number): void;
    SetVolume(sim: number, volume: number): void;
    SetPanning(sim: number, panning: number): void;
    vbSetKeys(sim: number, keys: number): void;
    vbGetKeys(sim: number): number;
    vbGetPeer(sim: number): number;
    vbSetPeer(sim: number, peer: number): void;
    vbRead(sim: number, address: number, type: number): number;
    vbWrite(sim: number, address: number, type: number, value: number): void;
    vbGetProgramCounter(sim: number): number;
    vbSetProgramCounter(sim: number, address: number): void;
    vbGetProgramRegister(sim: number, index: number): number;
    vbSetProgramRegister(sim: number, index: number, value: number): void;
    vbGetSystemRegister(sim: number, index: number): number;
    vbSetSystemRegister(sim: number, index: number, value: number): void;
    vbGetOption(sim: number, key: number): number;
    vbSetOption(sim: number, key: number, value: number): void;
    /**
     * Install a callback invoked on every CPU write, or 0 to remove it.
     *
     * The argument is an index into `__indirect_function_table`, not an address.
     * See VB_WRITE_CALLBACK_TYPE for the signature the target must have.
     */
    vbSetWriteCallback(sim: number, callback: number): void;
    vbGetWriteCallback(sim: number): number;
    /**
     * Install a callback invoked on every CPU read, or 0 to remove it.
     *
     * Five arguments, not the write callback's six — see
     * VB_READ_CALLBACK_ARITY. It fires *after* the read, so the value is
     * there to be looked at rather than supplied, and instruction fetches do
     * not come through it: the core reports those through its own fetch
     * callback, which is what makes this affordable to leave installed.
     * Measured, not assumed: see `tests/read-callback-probe.mjs`.
     */
    vbSetReadCallback(sim: number, callback: number): void;
    vbGetReadCallback(sim: number): number;
    /**
     * Install a callback invoked before every instruction, or 0 to remove it.
     *
     * Takes four arguments, not the write callback's six — see
     * VB_EXECUTE_CALLBACK_ARITY. The second is the program counter, and
     * returning non-zero halts `Emulate` *before* that instruction runs,
     * leaving the program counter on it. `GetBreaks` does not report a stop
     * raised this way; the callback's return is the only signal there is.
     */
    vbSetExecuteCallback(sim: number, callback: number): void;
    vbGetExecuteCallback(sim: number): number;
    /**
     * Disassemble `count` instructions from an address, returning a block, or
     * 0 on a memory error. The caller frees it with Realloc.
     *
     * Decodes but does not write any text: every string slot in the block it
     * returns stays null, which is what {@link WasmExports.Disassemble} is
     * for. Kept declared because it is the call the upstream wrapper makes
     * when it wants the structure and nothing else.
     */
    vbuDisassemble(sim: number, address: number, unused: number, count: number, line: number): number;
    /**
     * The same, with the sixteen options that decide how the text is written.
     *
     * The text is the whole point — mnemonics, operands, the formatted
     * address — and this is the only call that produces it. The options are
     * the notation and letter case of each kind of operand; see
     * `DISASSEMBLY_STYLE` in the worker for the ones we ask for and why.
     */
    Disassemble(bcondNotation: number, conditionCase: number, conditionCL: number, conditionEZ: number, conditionNotation: number, hexCase: number, hexNotation: number, immediateNotation: number, memoryNotation: number, mnemonicCase: number, operandOrder: number, programCase: number, programNotation: number, setfNotation: number, systemCase: number, systemNotation: number, sim: number, address: number, count: number, line: number): number;
    /** How many bytes the instruction at an address occupies. */
    vbuCodeSize(sim: number, address: number): number;
    /**
     * Fill `destination` with 17 words per line describing the block: address,
     * code length, up to four code bytes, a program counter flag, and then
     * offsets of *pointer slots* within the block — one for the address text,
     * four for the per-byte text, one mnemonic, an operand count and three
     * operands. Those last ones are offsets to pointers, not to the text, and
     * so need one dereference more than they look like they do.
     */
    GetDasm(destination: number, dasm: number, count: number): void;
}
/**
 * Slots the function table is widened to.
 *
 * The core ships with five, all spoken for, so every callback we install needs
 * one of the spares. Eight is more than the callback kinds the core exposes.
 */
export declare const VB_TABLE_SLOTS = 16;
/**
 * Raise the declared limits of the core's function table.
 *
 * The core was built without table growth, so its table is pinned at exactly
 * the five entries it ships with and `grow` fails — there is nowhere to install
 * a callback. Both limits encode as a single LEB128 byte and element segments
 * use fixed offsets, so raising them is an in-place byte patch that leaves
 * every other offset in the module alone.
 *
 * Verified by `scripts/write-callback-probe.mjs`, which asserts the core's own
 * four entries and its default frame callback survive the patch.
 */
export declare function patchTableLimit(bytes: Uint8Array, slots?: number): Uint8Array;
/**
 * A callback the core can invoke.
 *
 * For writes the arguments are the simulation pointer, the address, the data
 * type, a pointer to the value being written, and two further out-parameters
 * the core leaves at zero. Returning 0 lets the access proceed normally.
 */
/**
 * How many arguments each kind of callback takes.
 *
 * There is no single signature: writes take six, reads five, and execute
 * four. A
 * trampoline of the wrong shape is not a type error anywhere — the core simply
 * throws `null function or function signature mismatch` the first time it
 * calls it. Measured, not assumed: see `tests/emulator/breakpoint-probe.mjs`.
 */
export declare const VB_WRITE_CALLBACK_ARITY = 6;
export declare const VB_READ_CALLBACK_ARITY = 5;
export declare const VB_EXECUTE_CALLBACK_ARITY = 4;
export type VbCallback = (sim: number, address: number, type: number, valuePointer: number, outA: number, outB: number) => number;
/**
 * Put a JS callback in the core's function table and return its index, which is
 * what the core's `vbSet*Callback` functions take as a pointer.
 *
 * Index 0 is the null function pointer and means "no callback" to the core, so
 * it is never handed out.
 */
export declare function installVbCallback(exports: WasmExports, callback: VbCallback, arity: number): number;
export declare function releaseVbCallback(exports: WasmExports, index: number): void;
/**
 * Instantiate the core.
 *
 * The module is always fetched to an ArrayBuffer rather than instantiated from
 * the stream, because its function table has to be widened before compilation
 * for any callback to be installable.
 */
export declare function instantiateWasm(wasmUrl: string): Promise<WasmExports>;
//# sourceMappingURL=vb-wasm.d.ts.map