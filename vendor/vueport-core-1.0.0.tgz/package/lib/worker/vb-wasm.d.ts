import { DisassemblyLine } from '../common/vb-protocol';
export interface WasmExports {
    memory: WebAssembly.Memory;
    __indirect_function_table: WebAssembly.Table;
    _initialize(): void;
    Realloc(pointer: number, size: number): number;
    PointerSize(): number;
    vbSizeOf(): number;
    CreateSim(): number;
    vbReset(sim: number): void;
    SetHardwareMode?(sim: number, vbc: number): void;
    GetHardwareMode?(sim: number): number;
    vbGetCartROM(sim: number): number;
    vbSetCartROM(sim: number, pointer: number, size: number): number;
    vbGetCartRAM(sim: number): number;
    vbSetCartRAM(sim: number, pointer: number, size: number): number;
    Emulate(sims: number, count: number, clocks: number): void;
    GetBreaks(sim: number): number;
    GetPixels(sim: number): void;
    GetExtPixels(sim: number): number;
    GetColorPixels?(sim: number): void;
    GetExtColorPixels?(sim: number): number;
    GetVideoFormat?(sim: number): number;
    vbGetDisplayedBuffer?(sim: number): number;
    vbSetPixelOrigins?(sim: number, origins: number): void;
    vbSizeOfPixelOrigins?(): number;
    vbGetColumnLengths?(sim: number, left: number, right: number): void;
    vbGetCounter?(sim: number, id: number): number;
    vbResetCounters?(sim: number): void;
    SetAnaglyph(sim: number, left: number, right: number): void;
    GetExtSamples(sim: number): number;
    vbSetSamples(sim: number, pointer: number, type: number, count: number): void;
    Mix(destination: number, sims: number, count: number): void;
    SetVolume(sim: number, volume: number): void;
    SetPanning(sim: number, panning: number): void;
    vbSetKeys(sim: number, keys: number): void;
    vbGetKeys(sim: number): number;
    vbGetPeer(sim: number): number;
    vbSetPeer(sim: number, peer: number): void;
    vbRead(sim: number, address: number, type: number): number;
    vbWrite(sim: number, address: number, type: number, value: number): void;
    vbGetProgramCounter(sim: number): number;
    vbSetProgramCounter(sim: number, address: number): void;
    vbGetProgramRegister(sim: number, index: number): number;
    vbSetProgramRegister(sim: number, index: number, value: number): void;
    vbGetSystemRegister(sim: number, index: number): number;
    vbSetSystemRegister(sim: number, index: number, value: number): void;
    vbGetOption(sim: number, key: number): number;
    vbSetOption(sim: number, key: number, value: number): void;
    vbSetWriteCallback(sim: number, callback: number): void;
    vbGetWriteCallback(sim: number): number;
    vbSetReadCallback(sim: number, callback: number): void;
    vbGetReadCallback(sim: number): number;
    vbSetExecuteCallback(sim: number, callback: number): void;
    vbGetExecuteCallback(sim: number): number;
    vbSetExceptionCallback(sim: number, callback: number): void;
    vbuDisassemble(sim: number, address: number, unused: number, count: number, line: number): number;
    Disassemble(bcondNotation: number, conditionCase: number, conditionCL: number, conditionEZ: number, conditionNotation: number, hexCase: number, hexNotation: number, immediateNotation: number, memoryNotation: number, mnemonicCase: number, operandOrder: number, programCase: number, programNotation: number, setfNotation: number, systemCase: number, systemNotation: number, sim: number, address: number, count: number, line: number): number;
    vbuCodeSize(sim: number, address: number): number;
    /**
     * Fills destination with 17 words per line: address, code length, up to four code bytes, a PC flag, then
     * offsets of pointer slots within the block (one for the address text, four for per-byte text, one mnemonic,
     * an operand count and three operands). Those are offsets to pointers, not to the text, so they need one more
     * dereference than they appear to.
     */
    GetDasm(destination: number, dasm: number, count: number): void;
}
export declare const VB_TABLE_SLOTS = 16;
/**
 * Raises the declared limits of the core's function table: it was built without table growth, so the table
 * is pinned at its five entries and grow fails. Both limits encode as a single LEB128 byte and element
 * segments use fixed offsets, so this is an in-place byte patch leaving every other offset alone. Verified by
 * scripts/write-callback-probe.mjs (the core's own entries and default frame callback survive).
 */
export declare function patchTableLimit(bytes: Uint8Array, slots?: number): Uint8Array;
export declare const VB_WRITE_CALLBACK_ARITY = 6;
export declare const VB_READ_CALLBACK_ARITY = 5;
export declare const VB_EXECUTE_CALLBACK_ARITY = 4;
export declare const VB_EXCEPTION_CALLBACK_ARITY = 2;
export type VbCallback = (sim: number, address: number, type: number, valuePointer: number, outA: number, outB: number) => number;
export declare function installVbCallback(exports: WasmExports, callback: VbCallback, arity: number): number;
export declare function releaseVbCallback(exports: WasmExports, index: number): void;
export declare function instantiateWasm(wasmUrl: string): Promise<WasmExports>;
export declare function instantiateWasmBytes(bytes: Uint8Array): Promise<WasmExports>;
export declare function disassemble(wasm: WasmExports, sim: number, address: number, count: number, before?: number): DisassemblyLine[];
export declare function readCString(wasm: WasmExports, pointer: number): string;
//# sourceMappingURL=vb-wasm.d.ts.map