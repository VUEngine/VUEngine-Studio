import { Emitter, Event, Disposable, DisposableCollection } from '../common/emulator-events';
import { VueportNotifications } from '../common/emulator-host';
import { Core, Sim } from './core/vb-core';
import { RaAchievement, VesRaEvent, RaGame, RaLeaderboard, VesRaLeaderboardEntries } from '../common/vb-protocol';
import { AchievementBackup, AchievementBackupGame } from './emulator-achievement-backup';
export declare const RA_SIGN_UP_URL = "https://retroachievements.org/createaccount.php";
export declare function raUserProfileUrl(username: string): string;
export interface RetroAchievementsTransport {
    readonly available: boolean;
    request(method: 'GET' | 'POST', url: string, body: string | undefined, contentType: string | undefined): Promise<{
        status: number;
        body: string;
    }>;
}
export declare const UNAVAILABLE_RA_TRANSPORT: RetroAchievementsTransport;
export interface RetroAchievementsCredentials {
    load(): Promise<{
        username: string;
        token: string;
    } | undefined>;
    save(credentials: {
        username: string;
        token: string;
    }): Promise<void>;
    clear(): Promise<void>;
}
export interface RetroAchievementsAccount {
    username: string;
    token: string;
    score: number;
    softcoreScore: number;
    avatarUrl?: string;
}
export interface RetroAchievementsHardcoreControls {
    isEnabled(): boolean;
    persist(enabled: boolean): void | Promise<void>;
    enter(): void | Promise<void>;
}
export declare function hardcoreConfirmation(): {
    title: string;
    message: string[];
    okLabel: string;
};
export declare function hardcoreOnNotice(): {
    title: string;
    message: string[];
    okLabel: string;
};
export type RetroAchievementsUnavailableReason = 'disabled' | 'transport' | 'engine' | 'not-logged-in' | 'no-rom' | 'not-recognized';
export declare class RetroAchievementsService implements Disposable {
    readonly transport: RetroAchievementsTransport;
    protected readonly credentials: RetroAchievementsCredentials;
    protected readonly notifications: VueportNotifications;
    protected readonly enabled: () => boolean;
    protected account: RetroAchievementsAccount | undefined;
    protected game: RaGame | undefined;
    protected achievements: RaAchievement[];
    protected leaderboards: RaLeaderboard[];
    protected leaderboardsReason: string | undefined;
    protected readonly trackers: Map<number, string>;
    protected loadReason: string | undefined;
    protected engineReason: string | undefined;
    protected achievementsLoaded: boolean;
    protected unsupportedVersion: boolean;
    protected loggingIn: boolean;
    protected core: Core | undefined;
    protected sim: Sim | undefined;
    protected romHash: string | undefined;
    protected readonly sessionDisposables: DisposableCollection;
    protected hardcoreControls: RetroAchievementsHardcoreControls | undefined;
    protected backupLoader: (() => Promise<AchievementBackup | undefined>) | undefined;
    protected backupByHash: Map<string, AchievementBackupGame> | undefined;
    protected backupTried: boolean;
    protected backupGame: AchievementBackupGame | undefined;
    protected backupView: {
        game: RaGame;
        list: RaAchievement[];
    } | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    protected readonly onUnlockedEmitter: Emitter<{
        title: string;
        description: string;
        points: number;
        badgeUrl: string;
    }>;
    readonly onUnlocked: Event<{
        title: string;
        description: string;
        points: number;
        badgeUrl: string;
    }>;
    protected readonly onDidChangeTrackersEmitter: Emitter<void>;
    readonly onDidChangeTrackers: Event<void>;
    protected readonly onLeaderboardAttemptEmitter: Emitter<{
        kind: "leaderboardAttempt";
        id: number;
        title: string;
        description: string;
        state: "started" | "failed" | "submitted";
        value?: string;
    }>;
    readonly onLeaderboardAttempt: Event<{
        kind: "leaderboardAttempt";
        id: number;
        title: string;
        description: string;
        state: "started" | "failed" | "submitted";
        value?: string;
    }>;
    protected readonly onScoreboardEmitter: Emitter<{
        kind: "leaderboardScoreboard";
        id: number;
        submittedScore: string;
        bestScore: string;
        rank: number;
        total: number;
        topEntries: {
            rank: number;
            user: string;
            score: string;
        }[];
    }>;
    readonly onScoreboard: Event<{
        kind: "leaderboardScoreboard";
        id: number;
        submittedScore: string;
        bestScore: string;
        rank: number;
        total: number;
        topEntries: {
            rank: number;
            user: string;
            score: string;
        }[];
    }>;
    constructor(transport: RetroAchievementsTransport, credentials: RetroAchievementsCredentials, notifications: VueportNotifications, enabled: () => boolean);
    restore(): Promise<void>;
    setHardcoreControls(controls: RetroAchievementsHardcoreControls): void;
    setBackupLoader(loader: () => Promise<AchievementBackup | undefined>): void;
    get usingBackup(): boolean;
    protected ensureBackup(): Promise<void>;
    protected resolveBackup(): Promise<void>;
    get hardcoreControlsAvailable(): boolean;
    get hardcore(): boolean;
    setHardcore(enabled: boolean): Promise<void>;
    offerToLeaveHardcore(): Promise<void>;
    applyHardcoreToEngine(): Promise<void>;
    refreshAccount(): Promise<void>;
    get isLoggedIn(): boolean;
    get user(): RetroAchievementsAccount | undefined;
    get currentGame(): RaGame | undefined;
    get list(): ReadonlyArray<RaAchievement>;
    get unsupportedGameVersion(): boolean;
    get listLoaded(): boolean;
    get leaderboardList(): ReadonlyArray<RaLeaderboard>;
    get leaderboardsUnavailableDetail(): string | undefined;
    get leaderboardsActive(): boolean;
    get leaderboardTrackers(): ReadonlyArray<{
        id: number;
        display: string;
    }>;
    fetchLeaderboardEntries(leaderboardId: number, options?: {
        firstEntry?: number;
        count?: number;
        aroundUser?: boolean;
    }): Promise<VesRaLeaderboardEntries>;
    get unavailableReason(): RetroAchievementsUnavailableReason | undefined;
    get unavailableDetail(): string | undefined;
    protected requestLogin2(fields: Record<string, string>): Promise<void>;
    login(username: string, password: string): Promise<void>;
    enabledChanged(): Promise<void>;
    protected stopTracking(): Promise<void>;
    logout(): Promise<void>;
    get isLoggingIn(): boolean;
    setSession(core: Core | undefined, sim: Sim | undefined): Promise<void>;
    loadGame(hash: string | undefined): Promise<void>;
    protected authenticateSession(core: Core): Promise<void>;
    protected onEvent(core: Core, event: VesRaEvent): void;
    protected serviceServerCall(core: Core, call: Extract<VesRaEvent, {
        kind: 'serverCall';
    }>): Promise<void>;
    protected clearLeaderboards(): void;
    protected changed(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-retroachievements.d.ts.map