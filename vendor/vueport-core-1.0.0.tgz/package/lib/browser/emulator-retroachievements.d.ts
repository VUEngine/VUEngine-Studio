/**
 * The RetroAchievements account and the achievement set for whatever ROM is
 * running — the DOM side's half of the integration, the worker's being
 * `vb-rcheevos.ts`.
 *
 * Held by the widget the way {@link CheatStore} is: constructed
 * once, told about the running session as it comes and goes, and read by the
 * Achievements panel through `onDidChange`. Logging in does not need a session
 * — it is a plain call to RetroAchievements' own login endpoint, independent of
 * the worker — so an account can be entered from Settings before any ROM is
 * open; a session only has to know the token to authenticate the achievement
 * engine with once one starts.
 */
import { Emitter, Event, Disposable, DisposableCollection } from '../common/emulator-events';
import { VueportNotifications } from '../common/emulator-host';
import { Core, Sim } from './core/vb-core';
import { RaAchievement, VesRaEvent, RaGame, RaLeaderboard, VesRaLeaderboardEntries } from '../common/vb-protocol';
import { AchievementBackup, AchievementBackupGame } from './emulator-achievement-backup';
/** Where someone without an account goes to make one. */
export declare const RA_SIGN_UP_URL = "https://retroachievements.org/createaccount.php";
/** A RetroAchievements user's public profile page. */
export declare function raUserProfileUrl(username: string): string;
/** One HTTP call a host can make on the engine's or the login flow's behalf. */
export interface RetroAchievementsTransport {
    /**
     * Whether this host can reach RetroAchievements at all.
     *
     * False in a browser: `dorequest.php` sends no CORS headers, so the page
     * cannot read the reply. The desktop shell proxies the request through its
     * own process, which is not subject to that.
     */
    readonly available: boolean;
    request(method: 'GET' | 'POST', url: string, body: string | undefined, contentType: string | undefined): Promise<{
        status: number;
        body: string;
    }>;
}
/** A transport for a host that cannot reach RetroAchievements at all. */
export declare const UNAVAILABLE_RA_TRANSPORT: RetroAchievementsTransport;
/** Where the logged-in account's username and API token are kept. */
export interface RetroAchievementsCredentials {
    load(): Promise<{
        username: string;
        token: string;
    } | undefined>;
    save(credentials: {
        username: string;
        token: string;
    }): Promise<void>;
    clear(): Promise<void>;
}
/** The logged-in account, as much of it as the panel and the settings page want. */
export interface RetroAchievementsAccount {
    username: string;
    token: string;
    score: number;
    softcoreScore: number;
    /** The account's profile picture, on `media.retroachievements.org`, when it has one. */
    avatarUrl?: string;
}
/**
 * What the host does for hardcore mode, and where it keeps the preference.
 *
 * Handed to {@link RetroAchievementsService.setHardcoreControls}; a host that
 * never calls it leaves {@link RetroAchievementsService.hardcoreControlsAvailable}
 * false and the panel's hardcore switch does not appear. The service owns the
 * question the player is asked and the engine flag; the discipline hardcore
 * imposes on the rest of the emulator is the host's, since only it can restart
 * a ROM or move between Play and Debug.
 */
export interface RetroAchievementsHardcoreControls {
    /** The persisted hardcore preference. */
    isEnabled(): boolean;
    /** Persist a new value. */
    persist(enabled: boolean): void | Promise<void>;
    /**
     * Force Play mode, switch every cheat off, stop any running macro and
     * restart the ROM from the beginning. Run once, right after the player
     * confirms turning hardcore on — leaving hardcore needs none of it.
     */
    enter(): void | Promise<void>;
}
/**
 * The question put to the player before hardcore mode goes on.
 *
 * Here rather than in the host so both the panel switch and the command
 * palette ask it in the same words, and it is translated once.
 */
export declare function hardcoreConfirmation(): {
    title: string;
    message: string[];
    okLabel: string;
};
/**
 * Shown when the player reaches for something hardcore mode has taken away —
 * rewind, loading a save state, the cheats or macros panel, Debug mode. Says
 * why, and offers the way out, which is immediate and does not restart.
 */
export declare function hardcoreOnNotice(): {
    title: string;
    message: string[];
    okLabel: string;
};
/** Why RetroAchievements is not doing anything right now, for the panel to say so. */
export type RetroAchievementsUnavailableReason = 'disabled' | 'transport' | 'engine' | 'not-logged-in' | 'no-rom' | 'not-recognized';
export declare class RetroAchievementsService implements Disposable {
    readonly transport: RetroAchievementsTransport;
    protected readonly credentials: RetroAchievementsCredentials;
    protected readonly notifications: VueportNotifications;
    /** Whether the setting that turns the whole feature on is set. */
    protected readonly enabled: () => boolean;
    protected account: RetroAchievementsAccount | undefined;
    protected game: RaGame | undefined;
    protected achievements: RaAchievement[];
    protected leaderboards: RaLeaderboard[];
    /** Why there are no leaderboards, when the engine rather than the game is the reason. */
    protected leaderboardsReason: string | undefined;
    /**
     * The running attempts' values, by tracker id — not by leaderboard id:
     * the engine gives several leaderboards reading the same value one shared
     * tracker, so this is exactly the set of readouts to draw.
     */
    protected readonly trackers: Map<number, string>;
    protected loadReason: string | undefined;
    protected engineReason: string | undefined;
    /**
     * Whether the set's achievements have arrived for the running ROM.
     *
     * The list alone cannot say: an answer carrying nothing but the notices of
     * {@link RA_NOTICE_TITLES} filters down to an empty list, which is a set
     * that is in but has nothing to show rather than one still on its way.
     */
    protected achievementsLoaded: boolean;
    /**
     * Whether RetroAchievements answered with its "unsupported game version"
     * notice for the running ROM — a set exists, but not for this build of it.
     * The notice itself is dropped like the rest of {@link RA_NOTICE_TITLES};
     * this is what is left of it, for the panel to say so in its own words.
     */
    protected unsupportedVersion: boolean;
    protected loggingIn: boolean;
    protected core: Core | undefined;
    protected sim: Sim | undefined;
    /**
     * The running ROM's hash, kept so a set can be (re-)loaded for it — after
     * a late login, in particular: a ROM opened before anyone signed in has
     * nothing to load a set for until now.
     */
    protected romHash: string | undefined;
    protected readonly sessionDisposables: DisposableCollection;
    /** Set by the host; without it the panel's hardcore switch stays hidden. */
    protected hardcoreControls: RetroAchievementsHardcoreControls | undefined;
    /**
     * The offline snapshot of every VB set, and how to get it. The loader is
     * set by the host; it is called at most once, the first time a running ROM
     * has no live set, and its result is indexed by hash into `backupByHash`.
     */
    protected backupLoader: (() => Promise<AchievementBackup | undefined>) | undefined;
    protected backupByHash: Map<string, AchievementBackupGame> | undefined;
    protected backupTried: boolean;
    /** The snapshot's set for the running ROM, when the live one is missing. */
    protected backupGame: AchievementBackupGame | undefined;
    /** Memoized {@link RaGame} / list for {@link backupGame}. */
    protected backupView: {
        game: RaGame;
        list: RaAchievement[];
    } | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires whenever anything the panel or the settings page shows has changed. */
    readonly onDidChange: Event<void>;
    protected readonly onUnlockedEmitter: Emitter<{
        title: string;
        description: string;
        points: number;
        badgeUrl: string;
    }>;
    /** Fires once per earned achievement, for a host to show as a toast. */
    readonly onUnlocked: Event<{
        title: string;
        description: string;
        points: number;
        badgeUrl: string;
    }>;
    protected readonly onDidChangeTrackersEmitter: Emitter<void>;
    /**
     * Fires when a leaderboard attempt's readout changes — many times a
     * second while one is running.
     *
     * Deliberately not folded into `onDidChange`: that one redraws the whole
     * achievements panel, and a running timer would have it doing so every
     * frame. Only the small overlay over the picture listens here.
     */
    readonly onDidChangeTrackers: Event<void>;
    protected readonly onLeaderboardAttemptEmitter: Emitter<{
        kind: "leaderboardAttempt";
        id: number;
        title: string;
        description: string;
        state: "started" | "failed" | "submitted";
        value?: string;
    }>;
    /**
     * Fires when an attempt starts, is abandoned, or is sent in — for a host
     * to show as a toast, the way {@link onUnlocked} is shown.
     */
    readonly onLeaderboardAttempt: Event<{
        kind: "leaderboardAttempt";
        id: number;
        title: string;
        description: string;
        state: "started" | "failed" | "submitted";
        value?: string;
    }>;
    protected readonly onScoreboardEmitter: Emitter<{
        kind: "leaderboardScoreboard";
        id: number;
        submittedScore: string;
        bestScore: string;
        rank: number;
        total: number;
        topEntries: {
            rank: number;
            user: string;
            score: string;
        }[];
    }>;
    /**
     * Fires with the server's answer to a submission: where it put the
     * player, and the top of the board as it now stands. Always preceded by
     * an `onLeaderboardAttempt` for the same board, a round trip earlier.
     */
    readonly onScoreboard: Event<{
        kind: "leaderboardScoreboard";
        id: number;
        submittedScore: string;
        bestScore: string;
        rank: number;
        total: number;
        topEntries: {
            rank: number;
            user: string;
            score: string;
        }[];
    }>;
    constructor(transport: RetroAchievementsTransport, credentials: RetroAchievementsCredentials, notifications: VueportNotifications, 
    /** Whether the setting that turns the whole feature on is set. */
    enabled: () => boolean);
    /** Read a previously saved account back, if there is one. Call once at start-up. */
    restore(): Promise<void>;
    /**
     * Tell the service how to run hardcore mode. Call once at start-up, before
     * the panel is shown. See {@link RetroAchievementsHardcoreControls}.
     */
    setHardcoreControls(controls: RetroAchievementsHardcoreControls): void;
    /**
     * Provide the offline snapshot loader — the shipped fallback for when the
     * live site cannot be reached. Call once at start-up; the loader itself is
     * only invoked the first time a running ROM turns out to have no live set.
     * See {@link emulator-achievement-backup}.
     */
    setBackupLoader(loader: () => Promise<AchievementBackup | undefined>): void;
    /** Whether what the panel is showing right now came from the offline snapshot. */
    get usingBackup(): boolean;
    /** Load and index the snapshot, once. */
    protected ensureBackup(): Promise<void>;
    /**
     * Work out whether the snapshot has a set for the running ROM, and if so
     * build the panel's view of it. Called whenever the live picture changes —
     * a live set arriving takes precedence and clears this again.
     */
    protected resolveBackup(): Promise<void>;
    /** Whether the hardcore switch has a host to act through. */
    get hardcoreControlsAvailable(): boolean;
    /** Whether hardcore mode is on right now. */
    get hardcore(): boolean;
    /**
     * Turn hardcore mode on or off.
     *
     * On: ask first (the prompt spells out what it disables and that it
     * restarts the ROM), then persist, run the host's `enter` — Play mode,
     * cheats off, macros stopped, ROM restarted — and arm the engine. Off:
     * persist and disarm the engine, no prompt and no restart; rc_client keeps
     * the hardcore unlocks already earned.
     */
    setHardcore(enabled: boolean): Promise<void>;
    /**
     * The player reached for something hardcore mode disables. Tell them why
     * and offer the way out — turning it off, which is immediate and does not
     * restart. Does nothing if hardcore is already off, so callers can route
     * every blocked control through this without checking first.
     */
    offerToLeaveHardcore(): Promise<void>;
    /**
     * Re-send the current hardcore flag to the running engine. Call after the
     * setting changes and once a session's engine is up.
     */
    applyHardcoreToEngine(): Promise<void>;
    /**
     * Refresh the current account's score, softcore score and avatar from
     * RetroAchievements — the same plain `login2` call `login` makes, with the
     * saved token standing in for a password.
     */
    refreshAccount(): Promise<void>;
    get isLoggedIn(): boolean;
    get user(): RetroAchievementsAccount | undefined;
    get currentGame(): RaGame | undefined;
    get list(): ReadonlyArray<RaAchievement>;
    /**
     * Whether the running ROM is a build RetroAchievements does not support,
     * so nothing in the set can be earned with it.
     */
    get unsupportedGameVersion(): boolean;
    /**
     * Whether {@link list} is what there is, rather than what has arrived so
     * far — an empty list means "none" once this is true, and "not yet" until.
     */
    get listLoaded(): boolean;
    /**
     * The running game's leaderboards.
     *
     * Live only — the offline snapshot carries achievements and nothing else,
     * and a leaderboard without the server behind it has nothing to show but
     * its own name.
     */
    get leaderboardList(): ReadonlyArray<RaLeaderboard>;
    /** Why the engine, rather than the game, has no leaderboards to give. */
    get leaderboardsUnavailableDetail(): string | undefined;
    /**
     * Whether attempts are being tracked at all right now.
     *
     * RetroAchievements only runs leaderboards in hardcore mode, so in
     * softcore every board reads `inactive` and the panel says why rather
     * than looking broken.
     */
    get leaderboardsActive(): boolean;
    /** The running attempts' readouts, for the overlay over the picture. */
    get leaderboardTrackers(): ReadonlyArray<{
        id: number;
        display: string;
    }>;
    /**
     * Ask RetroAchievements for a page of one leaderboard's entries.
     *
     * `aroundUser` asks for the page the signed-in player sits in the middle
     * of instead of the page beginning at `firstEntry`. Rejects when there is
     * no session, no account, or the engine cannot answer — the panel shows
     * the message.
     */
    fetchLeaderboardEntries(leaderboardId: number, options?: {
        firstEntry?: number;
        count?: number;
        aroundUser?: boolean;
    }): Promise<VesRaLeaderboardEntries>;
    /** Why nothing is showing right now, or undefined when everything is in order. */
    get unavailableReason(): RetroAchievementsUnavailableReason | undefined;
    /** More detail behind `unavailableReason`, when the engine or the server gave one. */
    get unavailableDetail(): string | undefined;
    /**
     * `dorequest.php?r=login2` with either a password or (from {@link restore}
     * and {@link refreshAccount}) a saved token in its place — the same
     * endpoint rcheevos itself would use, independent of any running session,
     * so the account can be set up and kept current before a ROM is ever
     * opened. What a session's engine additionally needs (`raLoginToken`)
     * happens in {@link setSession} once there is a worker to tell.
     */
    protected requestLogin2(fields: Record<string, string>): Promise<void>;
    /** Log in with a RetroAchievements username and password. */
    login(username: string, password: string): Promise<void>;
    logout(): Promise<void>;
    get isLoggingIn(): boolean;
    /**
     * Follow a session's worker: authenticate the engine and wire its events.
     * Call from `stop()` with `undefined` first — a session about to be torn
     * down should not go on delivering achievement events to a set that is
     * about to change under it.
     */
    setSession(core: Core | undefined, sim: Sim | undefined): Promise<void>;
    /**
     * Identify the running ROM and load its set, if RetroAchievements is on and
     * an account is signed in. Silently does nothing otherwise — the panel's
     * `unavailableReason` says why.
     */
    loadGame(hash: string | undefined): Promise<void>;
    protected authenticateSession(core: Core): Promise<void>;
    protected onEvent(core: Core, event: VesRaEvent): void;
    protected serviceServerCall(core: Core, call: Extract<VesRaEvent, {
        kind: 'serverCall';
    }>): Promise<void>;
    /**
     * Forget the leaderboards and any attempt in progress. The overlay is
     * told separately, since it does not listen to `onDidChange`.
     */
    protected clearLeaderboards(): void;
    protected changed(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-retroachievements.d.ts.map