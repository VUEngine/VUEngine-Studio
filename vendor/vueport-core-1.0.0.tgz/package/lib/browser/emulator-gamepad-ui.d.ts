/**
 * The game pad as a way round the interface: d-pad and stick move, one face button chooses, the other backs out,
 * Start starts, the shoulders turn pages, Home opens the command palette. Its own loop, as the library and palette
 * exist without a game, and the emulator stops taking input while the palette is open.
 * A button counts on the frame it goes down, so one already held when a list opens (Home, or the A that chose the
 * command) does nothing until pressed again; directions repeat while held, as keys do. Everything goes through the
 * pad's profile, so a raw pad steers with what it plays with (left cross moves, VB triggers turn pages, Start
 * starts, `commandPalette` is Home), except choosing and backing out, see intentOf.
 * Here rather than in a host, as the rewind filmstrip is steered with it in every host (EmulatorRewindBrowser#steer);
 * the web app routes it on to its library, palette and windows (web-gamepad-ui.ts).
 */
import { GamepadProfileResolver } from './emulator-gamepad';
export type PadDirection = 'up' | 'down' | 'left' | 'right';
export type PadCommand = 'palette' | 'confirm' | 'cancel' | 'start' | 'previous' | 'next' | PadDirection;
export declare function listenToGamepadUi(resolver: () => GamepadProfileResolver, onCommand: (command: PadCommand) => void): () => void;
//# sourceMappingURL=emulator-gamepad-ui.d.ts.map