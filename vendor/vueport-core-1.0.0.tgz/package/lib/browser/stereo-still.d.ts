/**
 * Changing the 3D depth of a still stereo pair. The live picture scales parallax per world in the core
 * (`setStereoDepth`), a still only has the two eye images, so the parallax is measured back out of them: VB
 * layers are flat and shifted by whole pixels per eye, so a horizontal block match measures it well. Then every
 * lit pixel is moved to where it would be drawn at the chosen depth.
 */
export declare function measureDisparity(from: Uint8ClampedArray, to: Uint8ClampedArray, width: number, height: number): Int8Array;
export interface StereoStill {
    width: number;
    height: number;
    left: Uint8ClampedArray;
    right: Uint8ClampedArray;
    leftDisparity: Int8Array;
    rightDisparity: Int8Array;
}
export declare function measureStereoStill(left: Uint8ClampedArray, right: Uint8ClampedArray, width: number, height: number): StereoStill;
/**
 * The console draws a layer at `gx - gp` (left) and `gx + gp` (right), so the disparity `2 * gp` becomes
 * `2 * gp * d` at depth `d` and each eye moves by half of the difference. Nearer layers win on overlap. Unlit
 * pixels are backdrop and stay put; what a moved layer uncovers stays backdrop, as the still holds nothing behind it.
 */
export declare function refocusStereoStill(still: StereoStill, depth: number): {
    left: Uint8ClampedArray;
    right: Uint8ClampedArray;
};
//# sourceMappingURL=stereo-still.d.ts.map