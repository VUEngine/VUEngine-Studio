/**
 * Changing the 3D depth of a still stereo pair.
 *
 * The live picture gets its depth from the core, which scales the parallax of
 * every world and object as it draws them (see `setStereoDepth`). A still has
 * no worlds left to scale — only the two finished eye images — so the parallax
 * is measured back out of them instead: a Virtual Boy picture is flat layers,
 * each shifted sideways by a whole number of pixels per eye, which makes a
 * plain horizontal block match a good measure of it. With the parallax known,
 * every lit pixel is moved to where it would have been drawn at the chosen
 * depth.
 */
/**
 * Where each pixel of `from` is in `to`, as the horizontal offset to add to
 * its x: per pixel, the offset whose surrounding block differs least. Ties go
 * to the smaller offset, so a featureless area stays where it is.
 */
export declare function measureDisparity(from: Uint8ClampedArray, to: Uint8ClampedArray, width: number, height: number): Int8Array;
/** A stereo still with the parallax of both eyes measured, ready to be redrawn at any depth. */
export interface StereoStill {
    width: number;
    height: number;
    left: Uint8ClampedArray;
    right: Uint8ClampedArray;
    /** Per left-eye pixel, how far right of it the same point is in the right eye. */
    leftDisparity: Int8Array;
    /** Per right-eye pixel, how far left of it the same point is in the left eye. */
    rightDisparity: Int8Array;
}
export declare function measureStereoStill(left: Uint8ClampedArray, right: Uint8ClampedArray, width: number, height: number): StereoStill;
/**
 * Both eyes of a still as they would be drawn at `depth` percent of their
 * parallax.
 *
 * The console draws a layer at `gx - gp` for the left eye and `gx + gp` for
 * the right, so the disparity between them is `2 * gp`; at a depth of `d` it
 * is `2 * gp * d`, and each eye moves by half of what is taken away. Nearer
 * layers win where two land on the same pixel. Unlit pixels are the backdrop
 * and are not moved at all, and what a moved layer uncovers stays backdrop —
 * there is nothing in the still to say what was behind it.
 */
export declare function refocusStereoStill(still: StereoStill, depth: number): {
    left: Uint8ClampedArray;
    right: Uint8ClampedArray;
};
//# sourceMappingURL=stereo-still.d.ts.map