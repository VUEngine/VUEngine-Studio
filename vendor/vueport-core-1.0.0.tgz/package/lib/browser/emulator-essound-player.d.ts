import { Disposable, Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { EsSoundKind, EsSoundMessage } from '../common/emulator-essound';
import { Sim } from './core/vb-core';
export interface EsSoundTrack {
    id: number;
    kind: EsSoundKind;
    name: string;
    path: string;
    size: number;
    seconds?: number;
    title?: string;
}
export interface EsSoundNowPlaying {
    track: EsSoundTrack;
    position: number;
    loop: boolean;
    manual: boolean;
    waiting: boolean;
}
export interface EsSoundHistoryEntry {
    time: number;
    message: EsSoundMessage;
    description: string;
    problem?: string;
}
export interface EsSoundSnapshot {
    playing: {
        kind: EsSoundKind;
        track: number;
        position: number;
        loop: boolean;
    }[];
    volumes: [number, number][];
    balances: [number, number][];
}
export declare const ES_SOUND_HISTORY_LENGTH = 20;
interface EsSoundBuffer {
    buffer: AudioBuffer;
    start: number;
    end: number;
}
interface EsSoundSlot {
    track: number;
    loop: boolean;
    manual: boolean;
    gain: GainNode;
    panner: StereoPannerNode;
    audio?: EsSoundBuffer;
    source?: AudioBufferSourceNode;
    position: number;
    since: number;
    rate: number;
}
export declare class EsSoundPlayer {
    protected readonly storage: VueportStorage;
    protected tracks: EsSoundTrack[];
    protected history: EsSoundHistoryEntry[];
    protected sim: Sim | undefined;
    protected restartWatch: Disposable | undefined;
    protected muted: boolean;
    protected paused: boolean;
    protected rewinding: boolean;
    protected speed: number;
    protected rewound: number;
    protected scanned: boolean;
    protected directory: string | undefined;
    protected failure: string | undefined;
    protected titlesFailure: string | undefined;
    protected readonly volumes: Map<number, number>;
    protected readonly balances: Map<number, number>;
    protected context: AudioContext | undefined;
    protected readonly slots: Map<EsSoundKind, EsSoundSlot>;
    protected readonly decoded: Map<number, EsSoundBuffer>;
    protected readonly decoding: Map<number, Promise<EsSoundBuffer>>;
    protected tap: MediaStreamAudioDestinationNode | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage);
    get list(): ReadonlyArray<EsSoundTrack>;
    get commands(): ReadonlyArray<EsSoundHistoryEntry>;
    get isScanned(): boolean;
    get lookedIn(): string | undefined;
    get scanFailure(): string | undefined;
    get titlesProblem(): string | undefined;
    get hasTracks(): boolean;
    get playing(): number[];
    get nowPlaying(): EsSoundNowPlaying[];
    audition(id: number): void;
    seek(id: number, seconds: number): void;
    stopTrack(id: number): void;
    scan(romPath: string): Promise<void>;
    scanDirectory(directory: string): Promise<void>;
    protected readTitles(path: string): Promise<void>;
    protected measure(tracks: EsSoundTrack[]): Promise<void>;
    setSim(sim: Sim | undefined): Promise<void>;
    setMuted(muted: boolean): void;
    setSpeed(speed: number): void;
    setRewinding(rewinding: boolean): void;
    rewind(seconds: number): void;
    setPaused(paused: boolean): void;
    protected get running(): boolean;
    snapshot(): EsSoundSnapshot;
    restore(snapshot: EsSoundSnapshot): void;
    handle(raw: number): void;
    protected apply(message: EsSoundMessage): string | undefined;
    protected play(track: number, kind: EsSoundKind, loop: boolean, position?: number, manual?: boolean): string | undefined;
    protected prepare(track: number): void;
    protected startSource(kind: EsSoundKind, slot: EsSoundSlot, audio: EsSoundBuffer): void;
    protected positionOf(slot: EsSoundSlot): number;
    protected stop(kind: EsSoundKind, track?: number): void;
    protected dropSource(slot: EsSoundSlot): void;
    protected stopAll(): void;
    protected powerOn(): void;
    protected applyContextState(): void;
    protected isHeld(slot: EsSoundSlot): boolean;
    protected applySpeed(slot: EsSoundSlot): void;
    protected applyPosition(slot: EsSoundSlot, seconds: number): void;
    protected refresh(track: number): void;
    protected applyLevels(slot: EsSoundSlot): void;
    openTap(): MediaStream;
    closeTap(): void;
    protected audioContext(): AudioContext;
    protected decode(track: EsSoundTrack): Promise<EsSoundBuffer>;
    protected touch(id: number, audio: EsSoundBuffer): void;
    protected releaseDecoded(): void;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-essound-player.d.ts.map