import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { EsSoundKind, EsSoundMessage } from '../common/emulator-essound';
import { Sim } from './core/vb-core';
/** One audio file found beside the ROM. */
export interface EsSoundTrack {
    id: number;
    kind: EsSoundKind;
    name: string;
    path: string;
    /** Bytes, for the panel to show. */
    size: number;
}
/** One halfword the game sent, kept for the history list. */
export interface EsSoundHistoryEntry {
    time: number;
    message: EsSoundMessage;
    description: string;
    /** Why nothing happened, when nothing did. */
    problem?: string;
}
/**
 * ESSound's part of a save state: what is playing, where, and the levels the
 * game has set.
 *
 * Kept as plain data so it can go into the save state file as JSON beside the
 * core's own state — the audio is played on this side, so the core knows
 * nothing about it and restoring a state would otherwise leave whatever was
 * playing before running on.
 */
export interface EsSoundSnapshot {
    playing: {
        kind: EsSoundKind;
        track: number;
        position: number;
        loop: boolean;
    }[];
    volumes: [number, number][];
    balances: [number, number][];
}
/** How many commands the history keeps. */
export declare const ES_SOUND_HISTORY_LENGTH = 20;
/**
 * One slot of the hardware: the MP3 player or the WAV player.
 *
 * ESSound can play one of each at a time, so a second PLAY on the same slot
 * replaces what it was playing rather than joining it.
 */
interface EsSoundSlot {
    track: number;
    element: HTMLAudioElement;
    gain: GainNode;
    panner: StereoPannerNode;
}
/**
 * ESSound playback for one emulator: the files beside the ROM, the commands
 * the game sends, and the audio they produce.
 *
 * Held by the widget rather than by the ESSound panel, because a game's audio
 * has to keep playing whether or not anyone has that panel open — the panel
 * only shows what this is doing.
 *
 * Files are read through the file service and played as blob URLs rather than
 * from `file://` directly, which the renderer will not load; each is read once
 * and kept, since a game asks for the same handful of tracks over and over.
 */
export declare class EsSoundPlayer {
    protected readonly storage: VueportStorage;
    protected tracks: EsSoundTrack[];
    protected history: EsSoundHistoryEntry[];
    protected sim: Sim | undefined;
    protected muted: boolean;
    protected paused: boolean;
    protected rewinding: boolean;
    protected speed: number;
    /** Emulated seconds given up by the rewind currently in progress. */
    protected rewound: number;
    /** Set once the ROM has been looked at, so the panel can tell "none" from "not yet". */
    protected scanned: boolean;
    /**
     * The folder the last scan looked in, and why it could not.
     *
     * Kept so the panel can say both. "No files found" is the same sentence
     * whether the folder was empty, whether the files in it are named
     * something the hardware would never ask for, or whether the folder could
     * not be read at all — and told apart only by naming the folder and
     * repeating the reason.
     */
    protected directory: string | undefined;
    protected failure: string | undefined;
    /** Per-track volume and balance, as set before or during playback. */
    protected readonly volumes: Map<number, number>;
    protected readonly balances: Map<number, number>;
    protected context: AudioContext | undefined;
    protected readonly slots: Map<EsSoundKind, EsSoundSlot>;
    protected readonly sources: Map<number, string>;
    /**
     * Where a video recording listens, when one is running.
     *
     * A second destination beside the speakers rather than in place of them,
     * and in this player's own context — an audio graph cannot reach across
     * contexts, so what leaves here is a `MediaStream` and it is the recorder
     * that mixes it with the emulator's own sound. See
     * {@link EsSoundPlayer.openTap}.
     */
    protected tap: MediaStreamAudioDestinationNode | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires when the files, the history or what is playing change. */
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage);
    get list(): ReadonlyArray<EsSoundTrack>;
    get commands(): ReadonlyArray<EsSoundHistoryEntry>;
    get isScanned(): boolean;
    /** Where the last scan looked, for the panel to name. */
    get lookedIn(): string | undefined;
    /** Why that folder could not be read, when it could not. */
    get scanFailure(): string | undefined;
    /** Whether anything is worth watching the port for. */
    get hasTracks(): boolean;
    /** The track each slot is playing, for the panel to mark. */
    get playing(): number[];
    /**
     * Find the audio files beside a ROM.
     *
     * Which files exist is the whole configuration for now: a track id names a
     * file, and a file that is not there is a command that does nothing. A
     * later iteration will take the list from the project instead, and ignore
     * whatever happens to sit next to the ROM.
     */
    scan(romPath: string): Promise<void>;
    /**
     * The same, for a host that knows the folder rather than a file in it.
     *
     * Which is not always the ROM's own: a browser cannot see the folder a ROM
     * came from, so the tracks that arrive zipped with it are unpacked into
     * the emulator's storage and looked for there. See
     * `EmulatorCompanionFiles.sounds`, which is what decides.
     */
    scanDirectory(directory: string): Promise<void>;
    /**
     * The simulation to listen to, or undefined once it is gone.
     *
     * Watching the port costs the core a callback on every CPU write, so it is
     * only asked for when the ROM has files ESSound could play.
     */
    setSim(sim: Sim | undefined): Promise<void>;
    /** Follows the emulator's own mute, since this plays alongside it. */
    setMuted(muted: boolean): void;
    /**
     * Follows the emulator's speed, pitch and all.
     *
     * Fast forward and slow motion change how fast the machine runs, so its
     * own audio comes out higher or lower; a track played at the same rate
     * does the same thing, which is why the pitch is deliberately not
     * preserved. Rates outside what browsers will play are clamped rather
     * than left to silence the track.
     */
    setSpeed(speed: number): void;
    /**
     * Follows the emulator's rewind.
     *
     * Audio cannot be played backwards, so the tracks hold while the machine
     * walks back through its history and are then wound back by as much
     * emulated time as it gave up — one seek at the end rather than one per
     * step, since nothing is audible in between and seeking an MP3 sixty
     * times a second is not free.
     */
    setRewinding(rewinding: boolean): void;
    /** Emulated seconds the core has just walked back through. */
    rewind(seconds: number): void;
    /**
     * Follows the emulator's own pause, for the same reason.
     *
     * Paused rather than stopped: the track keeps its position, so resuming
     * carries on where the game left off — and a track a paused emulator asks
     * for is made ready but not started, since nothing else about the machine
     * is running either.
     */
    setPaused(paused: boolean): void;
    /** Whether a track should be running: only when the machine is. */
    protected get running(): boolean;
    /** What is playing and at what levels, for a save state to hold. */
    snapshot(): EsSoundSnapshot;
    /**
     * Put playback back as a snapshot found it.
     *
     * Restoring a state the game made before a track started is what stops the
     * previous track: everything currently playing goes first, whether or not
     * the snapshot has anything to put in its place.
     */
    restore(snapshot: EsSoundSnapshot): void;
    /**
     * Put a restored track back where it was.
     *
     * The element has no source until its file has been read, and seeking one
     * that has nothing loaded throws, so this waits for the metadata.
     */
    protected seekWhenReady(kind: EsSoundKind, position: number): void;
    /** Take one halfword the game wrote to the port. */
    handle(raw: number): void;
    /** Act on one message, and say why if it could not be acted on. */
    protected apply(message: EsSoundMessage): string | undefined;
    protected play(track: number, kind: EsSoundKind, loop: boolean): string | undefined;
    /** Stop a slot, optionally only when it is playing one particular track. */
    protected stop(kind: EsSoundKind, track?: number): void;
    protected stopAll(): void;
    /**
     * Start or hold a slot, according to whether the emulator is running.
     *
     * Autoplay is allowed here: the user started the emulator, and a failure
     * is worth reporting rather than swallowing.
     */
    protected applyPlayState(slot: EsSoundSlot): void;
    protected applySpeed(slot: EsSoundSlot): void;
    /**
     * Wind one track back, wrapping round rather than sticking at the start
     * when it is looping — a rewind through a loop point should land where the
     * loop actually was.
     */
    protected applyPosition(slot: EsSoundSlot, seconds: number): void;
    /** Push a track's levels to it, if it happens to be the one playing. */
    protected refresh(track: number): void;
    protected applyLevels(slot: EsSoundSlot): void;
    /**
     * Listen in on what ESSound is playing, for a recording to mix in.
     *
     * The levels the game has set are already in it — the tap hangs off each
     * slot's panner, downstream of the volume and balance the cartridge
     * commands — so what is recorded is what is heard, mute included. Tracks
     * that start later join by themselves.
     *
     * Opening one builds this player's audio context if a game has not played
     * anything yet, so that a recording started before the first sound still
     * has somewhere to take it from.
     */
    openTap(): MediaStream;
    /** Stop recording ESSound. The speakers are untouched either way. */
    closeTap(): void;
    protected audioContext(): AudioContext;
    /** The blob URL for a track's bytes, read once and kept. */
    protected sourceFor(track: EsSoundTrack): Promise<string>;
    protected releaseSources(): void;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-essound-player.d.ts.map