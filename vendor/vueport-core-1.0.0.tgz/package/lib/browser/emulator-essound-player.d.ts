import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { EsSoundKind, EsSoundMessage } from '../common/emulator-essound';
import { Sim } from './core/vb-core';
/** One audio file found beside the ROM. */
export interface EsSoundTrack {
    id: number;
    kind: EsSoundKind;
    name: string;
    path: string;
    /** Bytes, for the panel to show. */
    size: number;
    /**
     * How long the music runs, in seconds: from the file's headers once they
     * have been read, and exact once the track has been decoded.
     */
    seconds?: number;
    /**
     * The title from `essound.json`, or else from the file's tags, when
     * either has one.
     */
    title?: string;
}
/** What one slot is playing, for the panel. */
export interface EsSoundNowPlaying {
    track: EsSoundTrack;
    /** Seconds into the music. */
    position: number;
    loop: boolean;
    /** Started from the panel rather than by the game. */
    manual: boolean;
    /** Not sounding: still being decoded, or held while the emulator is. */
    waiting: boolean;
}
/** One halfword the game sent, kept for the history list. */
export interface EsSoundHistoryEntry {
    time: number;
    message: EsSoundMessage;
    description: string;
    /** Why nothing happened, when nothing did. */
    problem?: string;
}
/**
 * ESSound's part of a save state: what is playing, where, and the levels the
 * game has set.
 *
 * Kept as plain data so it can go into the save state file as JSON beside the
 * core's own state — the audio is played on this side, so the core knows
 * nothing about it and restoring a state would otherwise leave whatever was
 * playing before running on.
 */
export interface EsSoundSnapshot {
    playing: {
        kind: EsSoundKind;
        track: number;
        position: number;
        loop: boolean;
    }[];
    volumes: [number, number][];
    balances: [number, number][];
}
/** How many commands the history keeps. */
export declare const ES_SOUND_HISTORY_LENGTH = 20;
/** A track decoded, and where its music lies in it. */
interface EsSoundBuffer {
    buffer: AudioBuffer;
    /** The audible part, in seconds: MP3s carry encoder silence at both ends. */
    start: number;
    end: number;
}
/**
 * One slot of the hardware: the MP3 player or the WAV player.
 *
 * ESSound can play one of each at a time, so a second PLAY on the same slot
 * replaces what it was playing rather than joining it.
 *
 * Played from decoded audio rather than through a media element: an element
 * seeks back to the start of its file for every loop and starts each file
 * with a load, and both are audible gaps in music. A buffer source loops on
 * the sample and starts at once.
 */
interface EsSoundSlot {
    track: number;
    loop: boolean;
    /**
     * Started from the panel. Such a track plays while the emulator is paused
     * — that is when it is usually asked for — and the game's own tracks are
     * held meanwhile.
     */
    manual: boolean;
    gain: GainNode;
    panner: StereoPannerNode;
    /** The decoded track, once it is; until then the slot waits silently. */
    audio?: EsSoundBuffer;
    /** What plays it. A source node plays once, so each start makes a new one. */
    source?: AudioBufferSourceNode;
    /** Position in the music, in seconds, at context time `since`, moving at `rate`. */
    position: number;
    since: number;
    rate: number;
}
/**
 * ESSound playback for one emulator: the files beside the ROM, the commands
 * the game sends, and the audio they produce.
 *
 * Held by the widget rather than by the ESSound panel, because a game's audio
 * has to keep playing whether or not anyone has that panel open — the panel
 * only shows what this is doing.
 *
 * Files are read through the file service and decoded into audio buffers,
 * which keep their place for as long as the memory budget allows, since a
 * game asks for the same handful of tracks over and over.
 */
export declare class EsSoundPlayer {
    protected readonly storage: VueportStorage;
    protected tracks: EsSoundTrack[];
    protected history: EsSoundHistoryEntry[];
    protected sim: Sim | undefined;
    protected muted: boolean;
    protected paused: boolean;
    protected rewinding: boolean;
    protected speed: number;
    /** Emulated seconds given up by the rewind currently in progress. */
    protected rewound: number;
    /** Set once the ROM has been looked at, so the panel can tell "none" from "not yet". */
    protected scanned: boolean;
    /**
     * The folder the last scan looked in, and why it could not.
     *
     * Kept so the panel can say both. "No files found" is the same sentence
     * whether the folder was empty, whether the files in it are named
     * something the hardware would never ask for, or whether the folder could
     * not be read at all — and told apart only by naming the folder and
     * repeating the reason.
     */
    protected directory: string | undefined;
    protected failure: string | undefined;
    /** Why `essound.json` could not be used, when it is there and could not. */
    protected titlesFailure: string | undefined;
    /** Per-track volume and balance, as set before or during playback. */
    protected readonly volumes: Map<number, number>;
    protected readonly balances: Map<number, number>;
    protected context: AudioContext | undefined;
    protected readonly slots: Map<EsSoundKind, EsSoundSlot>;
    /** Decoded tracks, least recently used first, and those being decoded. */
    protected readonly decoded: Map<number, EsSoundBuffer>;
    protected readonly decoding: Map<number, Promise<EsSoundBuffer>>;
    /**
     * Where a video recording listens, when one is running.
     *
     * A second destination beside the speakers rather than in place of them,
     * and in this player's own context — an audio graph cannot reach across
     * contexts, so what leaves here is a `MediaStream` and it is the recorder
     * that mixes it with the emulator's own sound. See
     * {@link EsSoundPlayer.openTap}.
     */
    protected tap: MediaStreamAudioDestinationNode | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires when the files, the history or what is playing change. */
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage);
    get list(): ReadonlyArray<EsSoundTrack>;
    get commands(): ReadonlyArray<EsSoundHistoryEntry>;
    get isScanned(): boolean;
    /** Where the last scan looked, for the panel to name. */
    get lookedIn(): string | undefined;
    /** Why that folder could not be read, when it could not. */
    get scanFailure(): string | undefined;
    /** Why the titles file was passed over, for the panel to repeat. */
    get titlesProblem(): string | undefined;
    /** Whether anything is worth watching the port for. */
    get hasTracks(): boolean;
    /** The track each slot is playing, for the panel to mark. */
    get playing(): number[];
    /** What each slot is playing, and how far in. */
    get nowPlaying(): EsSoundNowPlaying[];
    /**
     * Play a track from the panel, once and from the start, in place of
     * whatever its slot is playing — just as if the game had asked for it.
     */
    audition(id: number): void;
    /**
     * Move a playing track to `seconds` into its music, from the panel.
     *
     * A track still being decoded starts there once it is; one held while
     * the emulator is paused waits there.
     */
    seek(id: number, seconds: number): void;
    /** Stop a track from the panel, whoever started it. */
    stopTrack(id: number): void;
    /**
     * Find the audio files beside a ROM.
     *
     * Which files exist is the whole configuration for now: a track id names a
     * file, and a file that is not there is a command that does nothing. A
     * later iteration will take the list from the project instead, and ignore
     * whatever happens to sit next to the ROM.
     */
    scan(romPath: string): Promise<void>;
    /**
     * The same, for a host that knows the folder rather than a file in it.
     *
     * Which is not always the ROM's own: a browser cannot see the folder a ROM
     * came from, so the tracks that arrive zipped with it are unpacked into
     * the emulator's storage and looked for there. See
     * `EmulatorCompanionFiles.sounds`, which is what decides.
     */
    scanDirectory(directory: string): Promise<void>;
    /** Name the tracks `essound.json` has titles for. */
    protected readTitles(path: string): Promise<void>;
    /**
     * Read each track's length and title from its headers, one file at a
     * time, behind the scan. Reading is cheap next to decoding, and what is
     * read is let go of at once.
     */
    protected measure(tracks: EsSoundTrack[]): Promise<void>;
    /**
     * The simulation to listen to, or undefined once it is gone.
     *
     * Watching the port costs the core a callback on every CPU write, so it is
     * only asked for when the ROM has files ESSound could play.
     */
    setSim(sim: Sim | undefined): Promise<void>;
    /** Follows the emulator's own mute, since this plays alongside it. */
    setMuted(muted: boolean): void;
    /**
     * Follows the emulator's speed, pitch and all.
     *
     * Fast forward and slow motion change how fast the machine runs, so its
     * own audio comes out higher or lower; a track played at the same rate
     * does the same thing, which is why the pitch is deliberately not
     * preserved. Rates outside what browsers will play are clamped rather
     * than left to silence the track.
     */
    setSpeed(speed: number): void;
    /**
     * Follows the emulator's rewind.
     *
     * Audio cannot be played backwards, so the tracks hold while the machine
     * walks back through its history and are then wound back by as much
     * emulated time as it gave up — one seek at the end rather than one per
     * step, since nothing is audible in between and seeking an MP3 sixty
     * times a second is not free.
     */
    setRewinding(rewinding: boolean): void;
    /** Emulated seconds the core has just walked back through. */
    rewind(seconds: number): void;
    /**
     * Follows the emulator's own pause, for the same reason.
     *
     * Paused rather than stopped: the track keeps its position, so resuming
     * carries on where the game left off — and a track a paused emulator asks
     * for is made ready but not started, since nothing else about the machine
     * is running either.
     */
    setPaused(paused: boolean): void;
    /** Whether a track should be running: only when the machine is. */
    protected get running(): boolean;
    /** What is playing and at what levels, for a save state to hold. */
    snapshot(): EsSoundSnapshot;
    /**
     * Put playback back as a snapshot found it.
     *
     * Restoring a state the game made before a track started is what stops the
     * previous track: everything currently playing goes first, whether or not
     * the snapshot has anything to put in its place.
     */
    restore(snapshot: EsSoundSnapshot): void;
    /** Take one halfword the game wrote to the port. */
    handle(raw: number): void;
    /** Act on one message, and say why if it could not be acted on. */
    protected apply(message: EsSoundMessage): string | undefined;
    /**
     * Start a track on its slot, at `position` seconds into its music.
     *
     * A track not decoded yet starts once it is, from where it was asked to
     * start: late rather than with its beginning cut off.
     */
    protected play(track: number, kind: EsSoundKind, loop: boolean, position?: number, manual?: boolean): string | undefined;
    /**
     * Have a track decoded before it is played.
     *
     * A game that sets the levels of a track it is not playing is about to
     * play it — ESSound keeps levels per track for that very use — so this is
     * the moment to decode it: by the time PLAY comes, it starts on the spot.
     */
    protected prepare(track: number): void;
    /** (Re)start a slot's source at the slot's current position. */
    protected startSource(kind: EsSoundKind, slot: EsSoundSlot, audio: EsSoundBuffer): void;
    /**
     * Where a slot is in its music, in seconds.
     *
     * Counted on the context's clock, which stands still while the context is
     * suspended — for a pause or a rewind — just as the track does.
     */
    protected positionOf(slot: EsSoundSlot): number;
    /** Stop a slot, optionally only when it is playing one particular track. */
    protected stop(kind: EsSoundKind, track?: number): void;
    protected dropSource(slot: EsSoundSlot): void;
    protected stopAll(): void;
    /**
     * Hold the whole audio graph while the machine is held.
     *
     * Suspending the context stops every source where it is and its clock
     * with it, so a pause or a rewind resumes exactly where it left off.
     *
     * Unless a track started from the panel is playing: then the context has
     * to run for it, and the game's tracks are held one by one instead —
     * their sources dropped, keeping the position, and started again when
     * they may sound.
     */
    protected applyContextState(): void;
    /** Whether a slot has to wait for the machine to run. */
    protected isHeld(slot: EsSoundSlot): boolean;
    protected applySpeed(slot: EsSoundSlot): void;
    /**
     * Wind one track back, wrapping round rather than sticking at the start
     * when it is looping — a rewind through a loop point should land where the
     * loop actually was.
     */
    protected applyPosition(slot: EsSoundSlot, seconds: number): void;
    /** Push a track's levels to it, if it happens to be the one playing. */
    protected refresh(track: number): void;
    protected applyLevels(slot: EsSoundSlot): void;
    /**
     * Listen in on what ESSound is playing, for a recording to mix in.
     *
     * The levels the game has set are already in it — the tap hangs off each
     * slot's panner, downstream of the volume and balance the cartridge
     * commands — so what is recorded is what is heard, mute included. Tracks
     * that start later join by themselves.
     *
     * Opening one builds this player's audio context if a game has not played
     * anything yet, so that a recording started before the first sound still
     * has somewhere to take it from.
     */
    openTap(): MediaStream;
    /** Stop recording ESSound. The speakers are untouched either way. */
    closeTap(): void;
    protected audioContext(): AudioContext;
    /** A track decoded, read and decoded once and kept within the budget. */
    protected decode(track: EsSoundTrack): Promise<EsSoundBuffer>;
    /** Mark a track used now, and make room by letting go of the oldest. */
    protected touch(id: number, audio: EsSoundBuffer): void;
    protected releaseDecoded(): void;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-essound-player.d.ts.map