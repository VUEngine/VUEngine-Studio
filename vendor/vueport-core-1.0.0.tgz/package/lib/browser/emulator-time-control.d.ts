import { Core } from './core/vb-core';
export interface EmulatorTimeSettings {
    fastForwardRatio: number;
    slowMotionRatio: number;
    rewindEnabled: boolean;
    rewindGranularity: number;
    rewindBufferBytes: number;
}
export interface EmulatorTimeAudio {
    setSpeed(speed: number): void;
    setRewinding(rewinding: boolean): void;
    rewind(seconds: number): void;
}
export interface EmulatorTimeControlHost {
    readonly core?: Core;
    readonly esSound: EmulatorTimeAudio;
    /**
     * False before the ROM has booted. Not `loaded`, which is Theia's: every BaseWidget answers getPreviewNode,
     * so Theia takes any of them for a PreviewableWidget and assigns `loaded = true` when it becomes the active tab,
     * and the studio's emulator is such a widget.
     */
    readonly romLoaded: boolean;
    readonly paused: boolean;
    readonly fastForward: boolean;
    readonly slowMotion: boolean;
    readonly isDisposed: boolean;
    timeSettings(): EmulatorTimeSettings;
    onDidChange(): void;
    onError(message: string): void;
}
export declare class EmulatorTimeControl {
    protected readonly host: EmulatorTimeControlHost;
    static readonly DEFAULT_FAST_FORWARD_RATIO = 4;
    static readonly DEFAULT_SLOW_MOTION_RATIO = 3;
    static readonly REWIND_MAX_CATCHUP_MS = 100;
    rewinding: boolean;
    protected rewindHandle?: number;
    protected rewindLastTick: number;
    protected rewindOwed: number;
    protected coreTransition: Promise<void>;
    constructor(host: EmulatorTimeControlHost);
    isRewindEnabled(): boolean;
    applySpeed(): Promise<void>;
    applyRewindSettings(): Promise<void>;
    startRewinding(): void;
    stopRewinding(): void;
    protected rewindTick(now: number): Promise<void>;
    /**
     * Serializes transitions between running and suspended. VbCore#run and #suspend touch the audio context as well
     * as the worker, so overlapping them (rewind pressed and released faster than a suspend completes) can leave the
     * context suspended while the worker believes it is emulating, which stalls it, as the audio graph clocks it.
     * The action is skipped if the session was torn down or rebuilt since queueing, so a release cannot resume a
     * disposed or fresh core.
     */
    queueCoreTransition(action: (core: Core) => Promise<void>): void;
}
//# sourceMappingURL=emulator-time-control.d.ts.map