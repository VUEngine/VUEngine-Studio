import { Core } from './core/vb-core';
/**
 * Everything the time controls read out of the emulator's settings, gathered
 * once so this has no opinion about where settings come from.
 */
export interface EmulatorTimeSettings {
    /** How many times real time fast forward runs at. */
    fastForwardRatio: number;
    /** The divisor slow motion runs at. */
    slowMotionRatio: number;
    rewindEnabled: boolean;
    /** Frames of emulation covered by one entry of rewind history. */
    rewindGranularity: number;
    rewindBufferBytes: number;
}
/** The part of ESSound playback that has to follow the machine's clock. */
export interface EmulatorTimeAudio {
    setSpeed(speed: number): void;
    setRewinding(rewinding: boolean): void;
    /** Wind the tracks back by however much emulated time was given up. */
    rewind(seconds: number): void;
}
/** What the time controls need from the emulator they pace. */
export interface EmulatorTimeControlHost {
    readonly core?: Core;
    readonly esSound: EmulatorTimeAudio;
    /**
     * False before the ROM has booted.
     *
     * Not `loaded`, which is Theia's: every `BaseWidget` answers
     * `getPreviewNode`, so Theia takes any of them for a `PreviewableWidget`
     * and assigns `loaded = true` when it becomes the active tab. A host that
     * is a widget would have to choose between answering this honestly and
     * being assignable, and the studio's emulator is exactly that host.
     */
    readonly romLoaded: boolean;
    readonly paused: boolean;
    readonly fastForward: boolean;
    readonly slowMotion: boolean;
    /** True once the emulator is being torn down, so nothing should redraw. */
    readonly isDisposed: boolean;
    timeSettings(): EmulatorTimeSettings;
    /** Something changed that the chrome should show. */
    onDidChange(): void;
    onError(message: string): void;
}
/**
 * Speed, rewind, and the ordering of the transitions between running and
 * suspended.
 *
 * Kept together because they are the same concern seen three ways: all three
 * decide how fast emulated time passes, and all three do it by talking to the
 * core rather than to any simulation. Reading settings through
 * `EmulatorTimeSettings` rather than a preference service is what lets this
 * move to a host that has no such thing.
 */
export declare class EmulatorTimeControl {
    protected readonly host: EmulatorTimeControlHost;
    /** Fallbacks for settings that are unset or meaningless. */
    static readonly DEFAULT_FAST_FORWARD_RATIO = 4;
    static readonly DEFAULT_SLOW_MOTION_RATIO = 3;
    /** How much history a single rewind tick may make up for after a stall. */
    static readonly REWIND_MAX_CATCHUP_MS = 100;
    /** True from the moment rewind input is pressed until it is released. */
    rewinding: boolean;
    protected rewindHandle?: number;
    /** Timestamp of the last rewind tick, for pacing playback by the wall clock. */
    protected rewindLastTick: number;
    /** History entries owed from earlier ticks, kept fractional so pacing does not drift. */
    protected rewindOwed: number;
    /** Serializes run/suspend, so a release can never overtake its own press. */
    protected coreTransition: Promise<void>;
    constructor(host: EmulatorTimeControlHost);
    isRewindEnabled(): boolean;
    applySpeed(): Promise<void>;
    applyRewindSettings(): Promise<void>;
    /**
     * Rewinding suspends normal emulation and walks the history backwards for as
     * long as the input is held.
     *
     * Whether it is held is tracked in a flag rather than in the animation frame
     * handle, because both the suspend and every step are round trips to the
     * worker: a release landing while one is in flight would otherwise be lost,
     * and the loop would keep running until it had eaten the entire history.
     */
    startRewinding(): void;
    stopRewinding(): void;
    /**
     * Play the history back at the speed it was recorded at.
     *
     * Pacing is by elapsed time rather than one entry per animation frame: the
     * machine runs at VB_FRAME_RATE and an entry covers `granularity` frames of
     * it, so a 120 Hz display would otherwise rewind at more than twice speed and
     * tear through a minute of history in seconds.
     */
    protected rewindTick(now: number): Promise<void>;
    /**
     * Serialize transitions between running and suspended.
     *
     * Both VbCore#run and #suspend touch the audio context as well as the
     * worker, so overlapping them can leave the context suspended while the
     * worker believes it is emulating — which stalls emulation outright, since it
     * is the audio graph that clocks it. Pressing and releasing rewind faster
     * than a suspend completes is exactly that case.
     *
     * The action is bound to the core that was current when it was queued and is
     * skipped if the session has been torn down or rebuilt since, so a release
     * queued on the way out cannot resume a disposed core or a fresh one.
     */
    queueCoreTransition(action: (core: Core) => Promise<void>): void;
}
//# sourceMappingURL=emulator-time-control.d.ts.map