/**
 * Playing a game in a headset whose computer cannot drive one (macOS, a PC without a runtime, VUEngine Studio): the
 * computer shares the running game in the local network, served by its host (LanShareShell: the desktop's Tauri shell,
 * the studio's backend), and VUEPort Web in the headset's browser finds it and plays it, from the start or from the
 * moment it was shared.
 * A page cannot look around its network (no mDNS, no broadcast, WebRTC hides the local address), so the two meet at
 * api.vueport.net: the computer says where its share is, the headset asks what is shared in its own network, which
 * the server knows by the public address both come from (packages/server/src/lan_shares.php). Only where to find a
 * share passes through there; the game goes straight from the computer to the headset, over plain http from an https
 * page, which Chrome allows for private IP literals behind its Local Network Access prompt.
 */
import { Emitter, Event } from '../common/emulator-events';
import { VesEmulatorSaveStateIdentity } from '../common/emulator-save-state';
import { Sim } from './core/vb-core';
export declare const LAN_SHARES_URL = "https://api.vueport.net/lan-shares";
export declare const VUEPORT_WEB_URL = "https://play.vueport.net/";
export interface LanShareServerInfo {
    token: string;
    port: number;
    addresses: string[];
    device: string;
}
/**
 * The host's side: a server on every private address of the computer, plain http, serving the one share under a
 * random token (GET /<token>/, /rom/<name>, /state, /thumbnail.png, and / redirecting to VUEPort Web for it). See
 * packages/desktop/src-tauri/src/lan_share.rs for the desktop's, which the studio's backend follows.
 */
export interface LanShareShell {
    start(name: string, rom: Uint8Array, web: string): Promise<LanShareServerInfo>;
    attach(kind: 'state' | 'thumbnail', bytes: Uint8Array | undefined): Promise<void>;
    info(): Promise<LanShareServerInfo | undefined>;
    stop(): Promise<void>;
    fetch?(url: string): Promise<Uint8Array>;
}
export interface LanShare {
    id: string;
    device: string;
    title: string;
    name: string;
    token: string;
    addresses: string[];
    state: boolean;
    romId?: string;
    since: number;
}
interface LanShareManifest {
    name: string;
    size: number;
    state: boolean;
    thumbnail: boolean;
}
export interface ReachedLanShare {
    share: LanShare;
    base: string;
    manifest: LanShareManifest;
}
export declare function listLanShares(signal?: AbortSignal): Promise<LanShare[]>;
/**
 * Asks every address of the share at once and keeps the first that answers. Rejects when none does: the computer has
 * gone, sits in another network after all (a guest Wi-Fi with the same public address), or the browser was not
 * allowed into the local network.
 */
export declare function reachLanShare(share: LanShare, via?: LanShareShell, signal?: AbortSignal): Promise<ReachedLanShare>;
export declare function lanShareThumbnail(reached: ReachedLanShare, via?: LanShareShell, signal?: AbortSignal): Promise<string | undefined>;
export declare function lanShareRomUrl(reached: ReachedLanShare): string;
export declare function downloadLanShare(reached: ReachedLanShare, withState: boolean, via?: LanShareShell, signal?: AbortSignal, onProgress?: (received: number, total: number) => void): Promise<{
    name: string;
    rom: Uint8Array;
    state?: Uint8Array;
}>;
export interface LanShareSource {
    readonly name: string;
    readonly data: Uint8Array;
    readonly title: string;
    readonly romId?: string;
}
export interface LanShareMoment {
    state: Uint8Array;
    thumbnail?: Uint8Array;
}
/**
 * A save state file of right now and its picture, as a manual state would be made, labelled with the computer it
 * came from. The identity is the ROM as it came off disk, as for the host's own states; the headset takes it as this
 * game's either way.
 */
export declare function takeLanShareMoment(sim: Sim, identity: VesEmulatorSaveStateIdentity, esSoundSnapshot: unknown, device: string, romName?: string): Promise<LanShareMoment>;
export interface LanShareStatus {
    readonly id: string;
    readonly title: string;
    readonly info: LanShareServerInfo;
    readonly stateAt?: number;
    readonly registered: boolean;
}
/**
 * The computer's share: one at a time, of the running game. Starting hands the host the ROM and the moment, then
 * tells api.vueport.net and keeps telling it every thirty seconds; stopping takes it back from both.
 */
export declare class LanSharing {
    readonly shell: LanShareShell;
    protected current: LanShareStatus | undefined;
    protected secret: string;
    protected name: string;
    protected romId: string | undefined;
    protected renewTimer: ReturnType<typeof setInterval> | undefined;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    protected readonly onPageHide: () => void;
    constructor(shell: LanShareShell);
    get status(): LanShareStatus | undefined;
    start(source: LanShareSource, takeMoment: (device: string) => Promise<LanShareMoment | undefined>): Promise<void>;
    retake(moment: LanShareMoment | undefined): Promise<void>;
    stop(): Promise<void>;
    protected renew(): Promise<void>;
    protected withdraw(leaving: boolean): void;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-lan-share.d.ts.map