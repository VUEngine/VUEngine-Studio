import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { CheatDatabaseEntry } from '../common/emulator-cheat-database';
import { Cheat } from '../common/emulator-cheats';
import { Sim } from './core/vb-core';
import { VbCheatWrite } from '../common/vb-protocol';
import { browserStateStorage } from './emulator-browser-state';
/**
 * One emulator's cheats: the list, the file it lives in, and pushing the
 * enabled ones into the core.
 *
 * Held by the widget rather than by the Cheats panel, for two reasons: cheats
 * stay in effect while that panel is closed, and the file has to be loaded as
 * soon as the ROM is, whether or not anyone has opened the panel. The panel
 * edits through this and redraws on onDidChange.
 *
 * The file is `<rom>.cht` beside the ROM, the same convention save RAM
 * follows, in the format `vueport-cheats.ts` documents — so cheats
 * written by RetroArch, or by hand from gamehacking.org, are picked up as they
 * are. It exists only while there are cheats to put in it: the first one
 * creates it and removing the last one deletes it, rather than leaving a file
 * saying there are none beside every ROM that was ever run.
 */
export declare class CheatStore {
    protected readonly storage: VueportStorage;
    /**
     * The cheats to ship. Defaults to the emulator's own, and is a
     * parameter so a host can add to them — and so this can be given a
     * fixture rather than whatever happens to be in the database today.
     */
    protected readonly database: CheatDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    /** The player's own, which is what the `.cht` file beside the ROM holds. */
    protected custom: Cheat[];
    /** What the emulator ships for this ROM, if it knows it. */
    protected builtIn: Cheat[];
    /** The old companion file used before switch state moved into the browser. */
    protected legacyStatePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected sim: Sim | undefined;
    /** Set while a link session owns where these writes go. See `setScheduler`. */
    protected scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined;
    protected uri: string | undefined;
    /** Set once a file has been read, so a first save cannot precede a load. */
    protected loaded: boolean;
    /**
     * Saves run one after another rather than at once: an edit and the edit
     * undoing it are a write and a delete, and the wrong order would leave the
     * file behind.
     */
    protected persisting: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires whenever the list changes, whatever changed it. */
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, 
    /**
     * The cheats to ship. Defaults to the emulator's own, and is a
     * parameter so a host can add to them — and so this can be given a
     * fixture rather than whatever happens to be in the database today.
     */
    database?: CheatDatabaseEntry[], stateStorage?: browserStateStorage | undefined);
    /**
     * Every cheat, the shipped ones first.
     *
     * One list rather than two, because a player looking for a cheat does not
     * care where it came from — only the few operations that would change a
     * built-in care, and they check `builtIn` (see `remove` and `update`).
     */
    get list(): ReadonlyArray<Cheat>;
    /** Where a list index falls: a shipped cheat, or one of the player's. */
    protected at(index: number): {
        cheat: Cheat;
        custom: number;
    } | undefined;
    /** Where the cheats are stored, once a ROM is known. */
    get filePath(): string | undefined;
    /** The file's name, for the panel to show. */
    get fileName(): string | undefined;
    get isLoaded(): boolean;
    /**
     * Read what belongs to a ROM, replacing whatever was loaded before.
     *
     * Three things, from three places: the player's definitions from the
     * `.cht` file beside the ROM, the shipped ones from the database, and the
     * current switches from browser storage. Older companion-file switches
     * are migrated once, then removed from disk.
     *
     * `romId` is the ROM's CRC32; without one the database is simply not
     * consulted, which is the ordinary case for homebrew and for a build in
     * progress.
     */
    load(romPath: string, romId?: string): Promise<void>;
    /** The shipped cheats for a ROM, as cheats, with their state restored. */
    protected readBuiltIn(romId: string | undefined, enabled: Set<string>): Cheat[];
    /** Read the state companion used by older builds, for one-time migration. */
    protected readLegacyEnabledBuiltIns(): Promise<Set<string>>;
    /** Stable-enough identities for user entries without adding ids to `.cht`. */
    protected stateIds(): string[];
    protected legacyEnabledIds(builtIns: Set<string>): Set<string>;
    protected restoreEnabled(enabled: Set<string>): void;
    protected saveBrowserState(): boolean;
    protected removeLegacyState(): Promise<void>;
    /** The simulation the enabled cheats apply to, or undefined once it is gone. */
    setSim(sim: Sim | undefined): void;
    /**
     * Route the writes through a link session instead of straight into the
     * machine, for as long as there is one.
     *
     * A cheat is a change nobody in the emulated program made, so in a linked
     * session it has to reach the other window's mirror of this machine as
     * well — and land on the same frame there, or the two are running
     * different games from that frame on. The session knows how to arrange
     * that and this does not, so it is handed the codes and says whether it
     * took them; false, and they go straight in as they always did.
     *
     * Undefined to go back to writing directly, which is what leaving a
     * session does.
     */
    setScheduler(scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined): void;
    /**
     * The writes the enabled cheats amount to.
     *
     * What `apply` pushes, exposed because a link session has to send the same
     * list to the other window when a run starts — see `standingEdits` in
     * `link-session.ts`.
     */
    get writes(): VbCheatWrite[];
    add(description: string): number;
    /**
     * Add a set of cheats read from a `.cht` file, on top of what is loaded.
     *
     * They come in as the player's own — a built-in flag or id from the file is
     * dropped — and off, whatever the file said: an import should not switch
     * writes on without the player choosing to. Returns how many were added.
     */
    importCheats(cheats: readonly Cheat[]): number;
    /**
     * Take one of the player's cheats away.
     *
     * A shipped cheat is not the player's to remove — the next release may
     * correct it, and a copy deleted here would come back anyway — so this
     * quietly does nothing for one. The panel does not offer it either; this
     * is the guard behind that, not the whole of it.
     */
    remove(index: number): void;
    /**
     * Change one cheat: its name, whether it is on, or its codes.
     *
     * On a shipped cheat only `enabled` takes effect: what it is called and
     * what it writes are the database's to say.
     */
    update(index: number, patch: Partial<Cheat>): void;
    /**
     * Switch every enabled cheat off at once.
     *
     * Hardcore mode calls this: a cheat still on would make the unlocks that
     * follow unearned. One `changed()` for the lot rather than one per cheat.
     */
    disableAll(): void;
    /**
     * Push the enabled writes into the core, replacing whatever was there.
     *
     * The core repeats them at every frame break for as long as they are set,
     * so this is the only call needed — there is no per-frame work on this
     * side at all.
     */
    protected apply(): void;
    /**
     * Write the definitions back, or take the file away once the last cheat
     * is gone. The current switches are deliberately neutralized here and
     * written to browser storage by `changed`.
     *
     * Saving on every edit is deliberate: a cheat is a few bytes of text, and
     * a list that quietly failed to outlive the window it was typed in would
     * be worse than a rare redundant write. A load that failed does not save,
     * so a file that could not be read is neither overwritten from an empty
     * list nor deleted.
     */
    protected saveDefinitions(): Promise<void>;
    protected changed(persistDefinitions?: boolean, persistState?: boolean): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-cheat-store.d.ts.map