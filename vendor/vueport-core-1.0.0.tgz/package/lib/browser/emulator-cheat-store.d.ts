import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { CheatDatabaseEntry } from '../common/emulator-cheat-database';
import { Cheat } from '../common/emulator-cheats';
import { Sim } from './core/vb-core';
import { VbCheatWrite } from '../common/vb-protocol';
import { browserStateStorage } from './emulator-browser-state';
/**
 * One emulator's cheats: the list, its file, and pushing enabled ones into the core. Held by the widget, not
 * the Cheats panel, as cheats stay active while it is closed and load with the ROM; the panel edits through
 * this. The file is `<rom>.cht` beside the ROM (like save RAM) in the format emulator-cheats.ts documents, so
 * RetroArch and gamehacking.org cheats work as they are. It only exists while there are cheats: the first one
 * creates it, removing the last deletes it
 */
export declare class CheatStore {
    protected readonly storage: VueportStorage;
    protected readonly database: CheatDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected custom: Cheat[];
    protected builtIn: Cheat[];
    protected browserStateKey: string | undefined;
    protected sim: Sim | undefined;
    protected scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined;
    protected uri: string | undefined;
    protected loaded: boolean;
    protected persisting: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, database?: CheatDatabaseEntry[], stateStorage?: browserStateStorage | undefined);
    get list(): ReadonlyArray<Cheat>;
    protected at(index: number): {
        cheat: Cheat;
        custom: number;
    } | undefined;
    get filePath(): string | undefined;
    get fileName(): string | undefined;
    get isLoaded(): boolean;
    /**
     * Reads what belongs to a ROM, replacing what was loaded: definitions from the `.cht` beside it, shipped ones from
     * the database, switches from browser storage. A `cheatN_enable` in the file is not taken as a switch, so a
     * cheat without a remembered switch starts off. `romId` is the CRC32; without it the database is skipped
     * (homebrew, builds in progress). `romSize` is the unpatched ROM's length, so shipped ROM writes still land when
     * a patch has grown the ROM (see anchorCheatCodeToRomTop)
     */
    load(romPath: string, romId?: string, romSize?: number): Promise<void>;
    protected readBuiltIn(romId: string | undefined, romSize?: number): Cheat[];
    protected stateIds(): string[];
    protected restoreEnabled(enabled: Set<string>): void;
    protected saveBrowserState(): boolean;
    setSim(sim: Sim | undefined): void;
    /**
     * Routes the writes through a link session while there is one: a cheat must reach the other window's mirror
     * machine on the same frame, or the two diverge. The session books it and returns whether it took them; on
     * false they go straight in. Undefined goes back to writing directly, as when leaving a session
     */
    setScheduler(scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined): void;
    get writes(): VbCheatWrite[];
    add(description: string): number;
    importCheats(cheats: readonly Cheat[]): number;
    remove(index: number): void;
    update(index: number, patch: Partial<Cheat>): void;
    disableAll(): void;
    protected apply(): void;
    /**
     * Writes the definitions back, or removes the file after the last cheat; switches are neutralized here and kept
     * in browser storage by changed. Saved on every edit, as a few bytes of text beat a list lost with the window.
     * A failed load does not save, so an unreadable file is neither overwritten nor deleted
     */
    protected saveDefinitions(): Promise<void>;
    protected changed(persistDefinitions?: boolean, persistState?: boolean): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-cheat-store.d.ts.map