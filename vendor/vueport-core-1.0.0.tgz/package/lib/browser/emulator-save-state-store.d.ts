import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { SaveStateKind, VesEmulatorSaveStateIdentity } from '../common/emulator-save-state';
import { CompanionRom, EmulatorCompanionFiles } from './emulator-companion-files';
/**
 * One state in the running ROM's library, as the browser shows it.
 *
 * Everything here but `path` comes out of the file itself — see
 * `VesEmulatorSaveStateMeta`. The megabyte of machine it was read alongside is
 * dropped again immediately: the browser shows a picture and a date, and
 * holding twenty snapshots of a Virtual Boy in memory to draw twenty
 * thumbnails would be paying for the states twice.
 */
export interface SaveStateEntry {
    /** What {@link EmulatorCompanionFiles.saveState} names the file with. */
    id: string;
    path: string;
    kind: SaveStateKind;
    /** When it was taken, or 0 for a file that does not say. */
    created: number;
    label?: string;
    /** A PNG `data:` URL of the moment, when the file carries one. */
    thumbnail?: string;
    /** How many machines it holds: two for a state of a linked pair. */
    machines: number;
    size: number;
    /**
     * True for a state written before the container carried metadata — a
     * numbered slot from an older VUEPort, or a raw snapshot.
     *
     * Still loadable, and still worth listing: somebody's playthrough is in
     * there. It simply has no picture and no date to show.
     */
    legacy: boolean;
}
/**
 * What the store needs from whatever is running the game.
 *
 * Declared here rather than imported from the widget, so that the store
 * depends on nothing above it: both hosts satisfy this structurally, and a
 * test can satisfy it with a handful of lines. It is deliberately about
 * *machines* rather than about a session — a linked pair is two of them, and
 * a state of that pair is one file holding both.
 */
export interface SaveStateMachine {
    /** How many machines are running: 1 alone, 2 while linked. */
    readonly machineCount: number;
    /** Every machine's snapshot, in player order, or nothing if none is running. */
    snapshot(): Promise<ArrayBuffer[] | undefined>;
    /** Put them all back, in the same order. */
    restore(states: ArrayBuffer[]): Promise<void>;
    /** A PNG of what is on screen right now, for the thumbnail. */
    thumbnail(): Promise<Uint8Array | undefined>;
    /** What the state is stamped with, so it cannot be loaded into another game. */
    identity(): VesEmulatorSaveStateIdentity | undefined;
    /** What ESSound is playing, which the core knows nothing about. */
    esSoundSnapshot(): unknown;
    /** And putting it back as the state found it. */
    esSoundRestore(snapshot: unknown): void;
}
/** The one state a ROM is put away with; always this id, so it is overwritten. */
export declare const SUSPEND_STATE_ID = "suspend";
/**
 * The running ROM's save states: what there are, and making, loading, naming
 * and throwing away one.
 *
 * ## No slots
 *
 * There were twenty-six numbered slots here once, and the number in the
 * transport was a thing to keep track of: which one this run was in, which one
 * that boss fight was in, whether the one being written over was the one
 * somebody still wanted. Saving now always makes a new state and never
 * replaces one, and the browser beside the screen is where they are told
 * apart — by their picture and their time, which is what a person actually
 * remembers a moment by.
 *
 * ## The library is the folder
 *
 * There is no index file. A state's id is in its name and everything else
 * about it is in the file, so the list is a directory listing and a state
 * copied in by hand is simply there the next time the folder is read. That
 * costs a read of every state to build the list, which is why the descriptions
 * are cached by path and size and only a file that is new or has changed is
 * read again.
 *
 * ## Three kinds
 *
 * Manual states are the person's and are never removed by the emulator. Auto
 * states are taken on a timer and rotate: the oldest falls out when a new one
 * arrives, which makes them a very coarse rewind that survives a crash. The
 * suspend state is a single file, overwritten whenever a ROM is put away and
 * offered back on the next launch. See `SaveStateKind`.
 */
export declare class SaveStateStore {
    protected readonly storage: VueportStorage;
    protected readonly companions: EmulatorCompanionFiles;
    protected rom: CompanionRom | undefined;
    protected machine: SaveStateMachine | undefined;
    protected entries: SaveStateEntry[];
    /** Descriptions kept between refreshes, by path and size — see the class comment. */
    protected described: Map<string, SaveStateEntry>;
    /** Refreshes run one after another, so two of them cannot interleave their lists. */
    protected refreshing: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires whenever the list changes, for the browser to redraw on. */
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, companions: EmulatorCompanionFiles);
    /** Newest first; the suspended game, if there is one, at the top. */
    get list(): readonly SaveStateEntry[];
    /** True once a ROM's folder has been read, which is what the panel waits for. */
    get attached(): boolean;
    /**
     * Point the store at the ROM that is now running, and at the machines
     * running it.
     *
     * Both may be undefined, which is what closing a ROM does: the list empties
     * and nothing can be saved or loaded until another one opens.
     */
    attach(rom: CompanionRom | undefined, machine: SaveStateMachine | undefined): Promise<void>;
    /** Read the folder again. Cheap after the first time — see the class comment. */
    refresh(): Promise<void>;
    protected readFolder(): Promise<void>;
    /** One file, read for what it says about itself and then let go of. */
    protected describe(id: string, path: string, size: number): Promise<SaveStateEntry | undefined>;
    /** The newest state somebody asked for, which is what Load State loads. */
    get latestManual(): SaveStateEntry | undefined;
    /** The state the ROM was last put away with, if it was. */
    get suspended(): SaveStateEntry | undefined;
    get autoStates(): SaveStateEntry[];
    /**
     * Take a state of what is running now.
     *
     * Always a new file for a manual or automatic state — nothing is ever
     * written over, which is the point of there being no slots. The suspend
     * state is the one exception: it has a fixed id, so every launch finds one
     * state to offer rather than a pile of them.
     */
    create(kind: SaveStateKind, label?: string): Promise<SaveStateEntry | undefined>;
    /**
     * `base`, or `base-2`, `base-3`… — whichever is not taken.
     *
     * The id is the moment the state was taken down to the millisecond, which
     * two states can share: an automatic state and one somebody asked for can
     * land in the same tick, and time can be put back. Saving must never
     * silently write over a state, so a taken name is not used.
     */
    protected freeId(rom: CompanionRom, base: string): Promise<string>;
    /**
     * Put the machines back to a state.
     *
     * The identity check in `unwrapSaveState` is what keeps a state of another
     * game — or of a linked pair, in a window playing alone — from restoring
     * convincing nonsense. A file with no container at all is a raw snapshot
     * from an older VUEPort, and is loaded as one: there is nothing in it to
     * check, and refusing it would strand states people already have.
     */
    restore(entry: SaveStateEntry): Promise<void>;
    remove(entry: SaveStateEntry): Promise<void>;
    /**
     * Give a state a name, or take one away.
     *
     * The whole file is written again, because the name lives inside it — see
     * `VesEmulatorSaveStateMeta`. That is a megabyte for a word, and it is
     * still the right trade: the alternative is a name that an exported state
     * arrives without.
     *
     * Naming an automatic state, or the suspended game, makes it one of the
     * person's own. Both of those are states the emulator will overwrite or
     * drop on its own, and somebody who has just called one "Before the boss"
     * is saying they want it — watching it disappear a minute later because
     * of what took it is not an answer. The badge on the row changes with it,
     * so the promotion says so rather than happening invisibly.
     */
    rename(entry: SaveStateEntry, label: string): Promise<void>;
    /** The file itself, handed to the person — a download in a browser. */
    exportState(entry: SaveStateEntry): Promise<void>;
    /**
     * Take a state file in, as a state of this ROM.
     *
     * Checked before it is kept rather than when it is loaded, so that a file
     * that belongs to another game is refused while somebody is still looking
     * at the file picker, rather than months later from a row in the browser.
     * Imported states are filed as manual whatever they were: an automatic
     * state somebody thought worth carrying to another machine has stopped
     * being one of the rotating ones.
     */
    importState(fileName: string, bytes: Uint8Array): Promise<SaveStateEntry | undefined>;
    /**
     * Drop the automatic states past the newest `keep` of them.
     *
     * Only the automatic ones, ever: what makes them safe to take every minute
     * is that they are the only states that go away on their own.
     */
    pruneAuto(keep: number): Promise<void>;
    /** Throw the suspended game away — what declining to resume does. */
    clearSuspended(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=emulator-save-state-store.d.ts.map