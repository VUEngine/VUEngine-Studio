import { Emitter, Event } from '../common/emulator-events';
import { VueportNotifications, VueportStorage } from '../common/emulator-host';
import { SaveStateKind, VesEmulatorSaveStateIdentity } from '../common/emulator-save-state';
import { CompanionRom, EmulatorCompanionFiles } from './emulator-companion-files';
export interface SaveStateEntry {
    id: string;
    path: string;
    kind: SaveStateKind;
    created: number;
    label?: string;
    thumbnail?: string;
    machines: number;
    size: number;
}
export interface SaveStateMachine {
    readonly machineCount: number;
    snapshot(): Promise<ArrayBuffer[] | undefined>;
    restore(states: ArrayBuffer[], options?: {
        clearCaches?: boolean;
    }): Promise<void>;
    thumbnail(): Promise<Uint8Array | undefined>;
    identity(): VesEmulatorSaveStateIdentity | undefined;
    esSoundSnapshot(): unknown;
    esSoundRestore(snapshot: unknown): void;
}
export declare const SUSPEND_STATE_ID = "suspend";
/**
 * The running ROM's save states. No slots: saving always makes a new state, never replacing one, and the
 * browser tells them apart by picture and time. No index file either: the id is in the name and the rest in
 * the file, so the list is a directory listing and hand-copied states just appear; descriptions are cached by
 * path and size so only new or changed files are read again. Three kinds (SaveStateKind): manual ones are never
 * removed by the emulator; auto ones are taken on a timer and rotate, a coarse rewind that survives a crash; the
 * suspend state is one file, overwritten whenever a ROM is put away and offered on the next launch
 */
export declare class SaveStateStore {
    protected readonly storage: VueportStorage;
    protected readonly companions: EmulatorCompanionFiles;
    protected rom: CompanionRom | undefined;
    protected machine: SaveStateMachine | undefined;
    protected entries: SaveStateEntry[];
    protected described: Map<string, SaveStateEntry>;
    protected refreshing: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, companions: EmulatorCompanionFiles);
    get list(): readonly SaveStateEntry[];
    get attached(): boolean;
    attach(rom: CompanionRom | undefined, machine: SaveStateMachine | undefined): Promise<void>;
    refresh(): Promise<void>;
    protected readFolder(): Promise<void>;
    protected describe(id: string, path: string, size: number): Promise<SaveStateEntry | undefined>;
    get latestManual(): SaveStateEntry | undefined;
    get suspended(): SaveStateEntry | undefined;
    get autoStates(): SaveStateEntry[];
    create(kind: SaveStateKind, label?: string): Promise<SaveStateEntry | undefined>;
    protected freeId(rom: CompanionRom, base: string): Promise<string>;
    /**
     * The identity check in unwrapSaveState keeps a state of another game, or of a linked pair in a solo window,
     * from restoring nonsense, and refuses non-state files. Another ROM's state throws SaveStateOtherRomError unless
     * `otherRom` says to take it anyway, so a host can warn and let a new build of the same game go on
     */
    restore(entry: SaveStateEntry, options?: {
        otherRom?: boolean;
    }): Promise<void>;
    remove(entry: SaveStateEntry): Promise<void>;
    /**
     * Names a state or removes its name. The whole file is rewritten, as the name lives inside it
     * (VesEmulatorSaveStateMeta), so exported states keep it. Naming an automatic or suspend state makes it a manual
     * one, as the emulator would otherwise drop or overwrite it; the row's badge changes to show it
     */
    rename(entry: SaveStateEntry, label: string): Promise<void>;
    exportState(entry: SaveStateEntry): Promise<void>;
    importState(fileName: string, bytes: Uint8Array, options?: {
        otherRom?: boolean;
    }): Promise<SaveStateEntry | undefined>;
    pruneAuto(keep: number): Promise<void>;
    clearSuspended(): Promise<void>;
    dispose(): void;
}
export declare function withOtherRomOffer(notifications: VueportNotifications, action: 'load' | 'import', run: (options: {
    otherRom?: boolean;
}) => Promise<unknown>): Promise<boolean>;
//# sourceMappingURL=emulator-save-state-store.d.ts.map