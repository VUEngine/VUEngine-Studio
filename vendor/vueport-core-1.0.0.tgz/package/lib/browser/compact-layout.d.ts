/**
 * Whether the page is laid out for a phone, and which way round it is held. `portrait` is a narrow screen held
 * upright: the picture goes to the top, the transport below it and the on-screen controller under that, panels and
 * windows come up from the bottom edge. `landscape` is a phone on its side: the picture fills the height, the
 * controller sits beside it. Undefined is every other screen, desktop, tablet and studio alike, which keep the
 * ordinary layout.
 *
 * Opt-in (allowCompactLayout), as only the standalone build is ever opened on a phone; the studio's panels can be
 * narrow without being one. While allowed, <html> carries the classes below, so stylesheets follow the same answer
 * as the components instead of repeating the queries.
 */
export type CompactLayout = 'portrait' | 'landscape';
export declare const COMPACT_CLASS = "vp-compact";
export declare const COMPACT_PORTRAIT_CLASS = "vp-compact-portrait";
export declare const COMPACT_LANDSCAPE_CLASS = "vp-compact-landscape";
export declare function allowCompactLayout(): void;
export declare function compactLayout(): CompactLayout | undefined;
export declare function onDidChangeCompactLayout(listener: () => void): () => void;
export declare function useCompactLayout(): CompactLayout | undefined;
export declare function canGoFullscreen(): boolean;
export declare function usePageFullscreen(): boolean;
//# sourceMappingURL=compact-layout.d.ts.map