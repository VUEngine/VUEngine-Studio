/**
 * Where the page is on the display, for a host that knows better than the
 * page does.
 *
 * The interleaved rendering modes need to know which line of the display the
 * picture starts on — see `DisplayOutput` — and a page can only estimate it:
 * it is told where its window is in whole CSS pixels, which at a display
 * scaling of 125 or 150 per cent is not a whole number of the display's own,
 * so the estimate is a line off at some places on the screen. A host with a
 * native side, such as the desktop application, can say exactly; it hands
 * that in here and the screen uses it instead.
 */
import { Event } from '../common/emulator-events';
export interface ScreenOriginSource {
    /** The page's top-left corner, in physical pixels of the display; undefined while not known. */
    origin(): {
        x: number;
        y: number;
    } | undefined;
    /** Fires whenever {@link origin} has a new answer. */
    readonly onDidChange: Event<void>;
}
/** Hand in a better answer than the page's own, or take it away again. */
export declare function setScreenOriginSource(source: ScreenOriginSource | undefined): void;
/** The page's top-left corner on the display, when a host has said. */
export declare function screenOrigin(): {
    x: number;
    y: number;
} | undefined;
/** Fires when a source is set or the one that is set has a new answer. */
export declare const onDidChangeScreenOrigin: Event<void>;
//# sourceMappingURL=screen-origin.d.ts.map