/**
 * Where the page is on the display, for a host that knows better than the page does. The interleaved rendering
 * modes need the display line the picture starts on (see DisplayOutput); a page only knows its window position in
 * whole CSS pixels, which at 125 or 150 % scaling is a line off at some places. A host with a native side, such
 * as the desktop application, can hand in the exact answer here.
 */
import { Event } from '../common/emulator-events';
export interface ScreenOriginSource {
    origin(): {
        x: number;
        y: number;
    } | undefined;
    readonly onDidChange: Event<void>;
}
export declare function setScreenOriginSource(source: ScreenOriginSource | undefined): void;
export declare function screenOrigin(): {
    x: number;
    y: number;
} | undefined;
export declare const onDidChangeScreenOrigin: Event<void>;
//# sourceMappingURL=screen-origin.d.ts.map