/**
 * The small, synchronous browser store used for per-ROM UI state.
 *
 * Kept structural rather than typed as DOM `Storage`, so tests and hosts can
 * provide the few operations without pretending to be a complete browser.
 */
export interface browserStateStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
/** One namespaced localStorage key for one kind of state and one ROM. */
export declare function browserStateKey(kind: string, romPath: string): string;
/** A compact deterministic identity for a user definition kept elsewhere. */
export declare function browserStateId(value: string): string;
/** Read JSON without allowing a damaged browser preference to stop a ROM. */
export declare function readVesBrowserState<T>(storage: browserStateStorage | undefined, key: string): T | undefined;
/**
 * Write JSON, removing an empty state instead of accumulating one key for
 * every ROM that has merely been opened.
 */
export declare function writeVesBrowserState(storage: browserStateStorage | undefined, key: string | undefined, value: object, empty: boolean): boolean;
//# sourceMappingURL=emulator-browser-state.d.ts.map