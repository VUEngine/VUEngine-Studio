export interface browserStateStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export declare function browserStateKey(kind: string, romPath: string): string;
export declare function browserStateId(value: string): string;
export declare function readVesBrowserState<T>(storage: browserStateStorage | undefined, key: string): T | undefined;
export declare function writeVesBrowserState(storage: browserStateStorage | undefined, key: string | undefined, value: object, empty: boolean): boolean;
//# sourceMappingURL=emulator-browser-state.d.ts.map