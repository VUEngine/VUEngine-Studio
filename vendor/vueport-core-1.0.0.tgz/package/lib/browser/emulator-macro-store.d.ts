import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { Macro, MacroStep } from '../common/emulator-macros';
import { browserStateStorage } from './emulator-browser-state';
export interface EmulatorMacroInput {
    readonly playerKeys: number;
    setMacroKeys(keys: number): void;
    focus(): void;
}
export declare enum MacroActivity {
    IDLE = "idle",
    RECORDING = "recording",
    PLAYING = "playing"
}
/**
 * One emulator's macros: the list, its file, recording and playback. Held by the widget, not the Macros panel,
 * like the cheats: macros play on with the panel closed and load with the ROM. The file is
 * `<rom>.vueport-macros.json` next to the saves, holding definitions only (no published format to match); repeat
 * flags live in browser state. Recording and playback use a clock advanced in tick only while running, so pauses
 * and menus are not recorded as waits. It counts seconds, not frames (the worker reports none per frame), so fast
 * forward plays against a faster game; Play mode, where macros are used, runs at one speed
 */
export declare class MacroStore {
    protected readonly storage: VueportStorage;
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected readonly resolveGlobalUri?: (() => string | undefined) | undefined;
    protected macros: Macro[];
    protected globals: Macro[];
    protected combined: ReadonlyArray<Macro>;
    protected uri: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded: boolean;
    protected globalsLoaded: boolean;
    protected input: EmulatorMacroInput | undefined;
    protected running: boolean;
    protected clock: number;
    protected clockReadAt: number | undefined;
    protected recording: {
        steps: MacroStep[];
        from: number;
    } | undefined;
    protected playback: {
        index: number;
        from: number;
        keys: number;
    } | undefined;
    protected persisting: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, stateStorage?: browserStateStorage | undefined, resolveGlobalUri?: (() => string | undefined) | undefined);
    protected get globalUri(): string | undefined;
    get list(): ReadonlyArray<Macro>;
    get supportsGlobal(): boolean;
    protected locate(index: number): {
        list: Macro[];
        at: number;
        global: boolean;
    } | undefined;
    protected recombine(): void;
    get isLoaded(): boolean;
    get filePath(): string | undefined;
    setInput(input: EmulatorMacroInput | undefined): void;
    load(romPath: string): Promise<void>;
    protected loadGlobals(): Promise<void>;
    protected readMacroFile(uri: string, stateKey: string): Promise<Macro[]>;
    protected saveBrowserState(): boolean;
    protected saveGlobalBrowserState(): boolean;
    protected saveDefinitions(): Promise<void>;
    protected saveGlobalDefinitions(): Promise<void>;
    protected writeMacroFile(uri: string | undefined, macros: ReadonlyArray<Macro>): Promise<void>;
    setSlot(index: number, slot: number | undefined): void;
    protected freeSlot(list: Macro[], slot: number): void;
    slotIndex(slot: number): number | undefined;
    playSlot(slot: number): void;
    update(index: number, patch: Partial<Pick<Macro, 'name' | 'loop'>>): void;
    remove(index: number): void;
    setGlobal(index: number, global: boolean): void;
    importMacros(macros: readonly Macro[]): number;
    setRunning(running: boolean): void;
    protected readClock(): number;
    get activity(): MacroActivity;
    get isRecording(): boolean;
    get playingIndex(): number | undefined;
    get elapsed(): number;
    startRecording(): void;
    stopRecording(name: string): number | undefined;
    cancelRecording(): void;
    recordKeys(keys: number): void;
    play(index: number): void;
    stop(): void;
    tick(): void;
    protected changed(persistDefinitions?: boolean, persistState?: boolean): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-macro-store.d.ts.map