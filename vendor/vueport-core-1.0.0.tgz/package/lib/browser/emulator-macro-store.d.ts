import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { Macro, MacroStep } from '../common/emulator-macros';
import { browserStateStorage } from './emulator-browser-state';
/**
 * What the store needs from the thing that owns the key masks.
 *
 * Declared here rather than imported from `emulator-input`, so that neither
 * module depends on the other: the input controller satisfies this
 * structurally, and a test can satisfy it with four lines.
 */
export interface EmulatorMacroInput {
    /** The buttons a person is holding right now, as a VbKey mask. */
    readonly playerKeys: number;
    /**
     * Hold exactly these buttons on the macro's behalf.
     *
     * Kept apart from the player's own, and combined with them, so that
     * playing a macro does not take the controller away — pressing something
     * while one runs adds to it rather than fighting it.
     */
    setMacroKeys(keys: number): void;
    /** Make sure the keyboard is being heard; see `startRecording`. */
    focus(): void;
}
/** What the store is doing, which is the one thing the chrome shows about it. */
export declare enum MacroActivity {
    IDLE = "idle",
    RECORDING = "recording",
    PLAYING = "playing"
}
/**
 * One emulator's macros: the list, the file it lives in, and the recording and
 * playback that fill and use it.
 *
 * Held by the widget rather than by the Macros panel, for the same two reasons
 * the cheats are: a macro plays on with that panel closed, and the file has to
 * be read as soon as the ROM is, whether or not anyone has opened it. The panel
 * edits through this and redraws on `onDidChange`.
 *
 * The file is `<rom>.vueport-macros.json` in the same place a ROM's saves go.
 * It holds the recorded definitions only; whether each macro repeats is UI
 * state and lives in the browser. JSON is the emulator's own format because,
 * unlike cheats, there is no published one to be compatible with.
 *
 * ## The clock
 *
 * Both recording and playback measure time with a clock this object advances
 * itself, out of `tick`, and only while the machine is actually running. Wall
 * time would have been simpler and wrong in the case that matters most:
 * somebody pausing in the middle of a recording, or opening a menu over the
 * game, would have that gap written into the macro and played back as a wait.
 *
 * It still measures real seconds rather than frames, so a macro recorded at
 * normal speed and played under fast forward runs against a game moving at a
 * different rate. Frames would be the exact unit, but nothing reports them
 * frame by frame from the worker; this is the accurate-where-it-counts
 * approximation, and Play mode — where macros are used — runs at one speed.
 */
export declare class MacroStore {
    protected readonly storage: VueportStorage;
    protected readonly stateStorage?: browserStateStorage | undefined;
    /**
     * Where the macros that belong to every game are kept — see
     * `EmulatorCompanionFiles#globalMacros`. A host that leaves it out gets
     * per-ROM macros only, and nothing offers to make one global.
     *
     * A function rather than the path itself, because a host may not know
     * it yet when it builds this: the studio's is under a configuration
     * directory its application only hands out asynchronously, and the
     * store is built before that answer arrives. Read on every use, and
     * only when a global macro is actually read or written.
     */
    protected readonly resolveGlobalUri?: (() => string | undefined) | undefined;
    /**
     * The running ROM's own macros, and the ones that belong to every game.
     *
     * Two lists and two files, presented as one list: see {@link list} for the
     * order and {@link locate} for how an index reaches the right one. Kept
     * apart rather than in one list with a flag because they are not one thing
     * — they are written to different files, survive different events, and
     * marking a macro global is exactly the act of moving it between them.
     */
    protected macros: Macro[];
    protected globals: Macro[];
    /** {@link list}'s answer, rebuilt on change rather than on every read. */
    protected combined: ReadonlyArray<Macro>;
    protected uri: string | undefined;
    protected browserStateKey: string | undefined;
    /** Set once a file has been read, so a first save cannot precede a load. */
    protected loaded: boolean;
    /** The same, for the shared file, which is read once and not per ROM. */
    protected globalsLoaded: boolean;
    protected input: EmulatorMacroInput | undefined;
    /** Whether the machine is running, which is what makes the clock advance. */
    protected running: boolean;
    /** Milliseconds of running time since this object was made. */
    protected clock: number;
    /** When the clock was last advanced, on `performance.now`'s scale. */
    protected clockReadAt: number | undefined;
    protected recording: {
        steps: MacroStep[];
        from: number;
    } | undefined;
    protected playback: {
        index: number;
        from: number;
        keys: number;
    } | undefined;
    /**
     * Saves run one after another, for the reason the cheat store gives: an
     * edit and the edit undoing it are a write and a delete, and the wrong
     * order would leave the file behind.
     */
    protected persisting: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /**
     * Fires when the list, or what the store is doing with it, changes.
     *
     * Not on every tick: recording and playing are continuous, and a panel that
     * redrew sixty times a second to move a stopwatch would cost more than
     * everything else here put together. What is running is said once when it
     * starts and once when it stops; whoever wants the seconds counting up asks
     * for them on a timer of its own.
     */
    readonly onDidChange: Event<void>;
    constructor(storage: VueportStorage, stateStorage?: browserStateStorage | undefined, 
    /**
     * Where the macros that belong to every game are kept — see
     * `EmulatorCompanionFiles#globalMacros`. A host that leaves it out gets
     * per-ROM macros only, and nothing offers to make one global.
     *
     * A function rather than the path itself, because a host may not know
     * it yet when it builds this: the studio's is under a configuration
     * directory its application only hands out asynchronously, and the
     * store is built before that answer arrives. Read on every use, and
     * only when a global macro is actually read or written.
     */
    resolveGlobalUri?: (() => string | undefined) | undefined);
    /** Where global macros are kept, if the host knows yet. */
    protected get globalUri(): string | undefined;
    /**
     * Every macro on offer for the running ROM: its own first, then the ones
     * marked global.
     *
     * One list because that is what a person has — a row of macros they can
     * play — and because everything that addresses a macro does so by its
     * place in this list. Its own first, so that recording a macro puts it
     * where the eye already is and a shared set does not push a game's own
     * work down the panel.
     */
    get list(): ReadonlyArray<Macro>;
    /** Whether this store was given anywhere to keep global macros. */
    get supportsGlobal(): boolean;
    /**
     * Which list an index falls in, and where in it.
     *
     * The one place the two lists are joined, so that `play`, `update`,
     * `remove` and the rest each work in the combined index space without
     * knowing there are two.
     */
    protected locate(index: number): {
        list: Macro[];
        at: number;
        global: boolean;
    } | undefined;
    /**
     * Rebuild {@link list}, marking the shared ones on the way out.
     *
     * The two lists themselves never carry the flag — which list a macro is in
     * is the whole of the answer — so it is stamped on here, where the two
     * become one and the distinction would otherwise be lost.
     */
    protected recombine(): void;
    get isLoaded(): boolean;
    /** Where the macros are stored, once a ROM is known. */
    get filePath(): string | undefined;
    /** The keyboard and pad, once the host has introduced the two. */
    setInput(input: EmulatorMacroInput | undefined): void;
    /**
     * Read the macros belonging to a ROM, replacing whatever was loaded.
     *
     * `romPath` is the ROM as the companion files see it — the same argument
     * the cheat store takes — and the macros land beside its saves. The global
     * ones are read alongside, once: they do not belong to this ROM, so they
     * are not re-read when another is opened, and a failure to read them
     * leaves the ROM's own working.
     */
    load(romPath: string): Promise<void>;
    /** The shared file, read the first time any ROM is opened. */
    protected loadGlobals(): Promise<void>;
    /**
     * One macro file, with the repeat switches remembered for it applied.
     *
     * `hadLegacyState` says the file itself carried `loop`, which belongs in
     * browser storage now — the caller writes the file back to shed it.
     */
    protected readMacroFile(uri: string, stateKey: string): Promise<{
        macros: Macro[];
        hadLegacyState: boolean;
    }>;
    protected saveBrowserState(): boolean;
    protected saveGlobalBrowserState(): boolean;
    /**
     * Write the definitions back, or take the file away once the last macro
     * is gone. Repeat switches are kept separately in browser storage.
     *
     * Saving on every edit, for the reason the cheat store saves on every edit:
     * a recording somebody made and then lost to a closed tab is worse than a
     * few kilobytes written more often than they strictly had to be.
     */
    protected saveDefinitions(): Promise<void>;
    protected saveGlobalDefinitions(): Promise<void>;
    protected writeMacroFile(uri: string | undefined, macros: ReadonlyArray<Macro>): Promise<void>;
    /** Take one macro's name, or its loop flag. Returns nothing for a bad index. */
    update(index: number, patch: Partial<Pick<Macro, 'name' | 'loop'>>): void;
    remove(index: number): void;
    /**
     * Move a macro between this ROM's file and the shared one.
     *
     * Moved rather than copied or flagged: a macro is offered for every game
     * or for this one, and a copy in both places would drift into two macros
     * that were once the same and now quietly differ. Its repeat switch goes
     * with it — the switch is remembered against the macro's own identity, so
     * writing both sides' state after the move is all it takes.
     *
     * Whatever is playing stops first, for `remove`'s reason: the index of
     * every macro after this one is about to mean a different macro, and the
     * one being moved is about to be somewhere else entirely.
     */
    setGlobal(index: number, global: boolean): void;
    /**
     * Add macros read from a file, on top of what is loaded.
     *
     * The same shape as the cheat store's import: anything with nothing to play
     * is dropped, a legacy loop flag is adopted into browser state, and the
     * number actually added is returned. Names are left as they are — a macro is
     * addressed by its place in the list, not its name, so a repeat is harmless.
     */
    importMacros(macros: readonly Macro[]): number;
    /**
     * Whether the machine is running — which is whether time passes.
     *
     * The host calls this whenever it pauses, resumes, loads or stops a ROM.
     * Reading the clock first is what makes the switch lossless: the time up to
     * this moment is banked before it stops counting.
     */
    setRunning(running: boolean): void;
    /**
     * The clock, brought up to date.
     *
     * Advanced on demand rather than on a timer, so it is correct whoever asks
     * and whenever — the frame loop, a key press between two frames, or the
     * panel drawing a stopwatch.
     */
    protected readClock(): number;
    get activity(): MacroActivity;
    get isRecording(): boolean;
    /** Which macro is playing, or undefined when none is. */
    get playingIndex(): number | undefined;
    /**
     * How far the current recording or playback has got, in milliseconds.
     *
     * Zero when neither is running. Read rather than pushed, since it changes
     * continuously and only whatever is drawing a stopwatch cares — see
     * `onDidChange`.
     */
    get elapsed(): number;
    /**
     * Start writing down what the controller does.
     *
     * Whatever is playing stops first: a macro recorded with another one
     * pressing buttons underneath it would contain both, and the one that
     * comes back would be neither.
     */
    startRecording(): void;
    /**
     * Stop, keep what was recorded, and return where it landed in the list.
     *
     * Undefined when there was nothing to keep — the recording was canceled,
     * or no button was pressed during it. A macro of nothing is not worth a row
     * in the panel, and dropping it is kinder than making somebody delete it.
     */
    stopRecording(name: string): number | undefined;
    /** Stop and throw away what was recorded. */
    cancelRecording(): void;
    /**
     * The player's buttons changed. Called by the input controller.
     *
     * Only theirs — what a macro is holding is deliberately not fed back in, or
     * recording while one plays would copy it into the new macro.
     */
    recordKeys(keys: number): void;
    /**
     * Play one macro from the top.
     *
     * Playing a second replaces the first rather than layering onto it: two
     * macros holding the same button, one letting go while the other still
     * wants it, is a knot with no correct answer. Playing the one that is
     * already playing stops it, which is what the panel's button means.
     */
    play(index: number): void;
    /** Let go of whatever a macro was holding, and stop it. */
    stop(): void;
    /**
     * Advance playback. Called once per animation frame by the input
     * controller, which already runs a loop for the game pad.
     *
     * Nothing happens here while the machine is stopped, because the clock does
     * not move — a macro paused mid-sequence resumes where it was rather than
     * having run on without the game.
     */
    tick(): void;
    protected changed(persistDefinitions?: boolean, persistState?: boolean): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-macro-store.d.ts.map