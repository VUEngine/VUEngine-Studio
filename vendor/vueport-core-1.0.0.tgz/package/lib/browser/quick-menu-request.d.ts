/**
 * A way for something outside the Emulator component to open the phone's game menu (EmulatorQuickMenu), which is the
 * component's own state: the standalone build's swipe up from the bottom edge (web-edge-swipes.ts). Heard only while
 * the menu can be shown at all, a game running on a phone.
 */
export declare function requestQuickMenu(): void;
export declare function onDidRequestQuickMenu(listener: () => void): () => void;
//# sourceMappingURL=quick-menu-request.d.ts.map