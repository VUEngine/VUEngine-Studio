/**
 * Playing in a headset: an immersive WebXR session showing each eye its own picture. The game runs as on the page;
 * this takes a second copy of every frame through the video tap a recording uses (see setVideoTap), as WebXR exists
 * on the page's thread only and the worker's canvas cannot be shared with it. Each frame is composed once, side by
 * side, by the ordinary renderer (palette, VB Color, frame blending) into a texture of the page's own, then reaches
 * the headset as a quad layer where offered (the compositor places it, sharper and steadier, each eye given its half,
 * enlarged by a whole multiple so its filtering does not blur pixels), or else a projection layer drawn per eye with a
 * sharp-but-stable filter. Both eyes see the screen at one place; the depth is the game's own parallax, scaled by 3D
 * Depth. Controllers are read here too, as a headset browser stops the page's animation frames during a session and
 * never lists its controllers to the Gamepad API; their two sticks are the two D-pads (see readControllers).
 * Around the screen, the page's own interface (emulator-xr-ui.ts), shown and hidden with a stick click or the menu
 * button; while it shows, the controllers point at it instead of playing.
 * In parts: emulator-xr-webxr.ts (declarations), emulator-xr-input.ts (controllers), emulator-xr-render.ts (drawing),
 * emulator-xr-panel.ts (questions, news), emulator-xr-ui.ts with -dom and -keyboard (the page's interface)
 */
import { DisplayMode } from '../common/vb-constants';
import { Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import { XrButtons, XrControllerReading } from './emulator-xr-input';
import { XrPanel, XrPanelRow } from './emulator-xr-panel';
import { XrFrameRenderer, XrOverlay } from './emulator-xr-render';
import { XrRay, XrUi } from './emulator-xr-ui';
import { XrFrame, XrProjectionLayer, XrQuadLayer, XrSession, XrSpace, XrWebGlBinding, XrWebGlLayer } from './emulator-xr-webxr';
export interface XrScreen {
    width: number;
    depth: number;
}
export declare const XR_DEFAULT_SCREEN: XrScreen;
export declare const XR_MIN_WIDTH = 0.6;
export declare const XR_MAX_WIDTH = 4;
export declare const XR_MAX_DEPTH = 200;
export declare function clampXrScreen(view: Partial<XrScreen>): XrScreen;
export declare function pickXrFrameRate(rates: readonly number[]): number | undefined;
export interface XrDiagnostics {
    stage: XrStage;
    timeline?: Partial<Record<XrStage, number>>;
    path: 'quad' | 'projection' | 'none';
    frameRate?: number;
    xrFrames: number;
    gameFrames: number;
    error?: string;
    glError?: number;
    glErrorAt?: string;
    quadLayout?: string;
    contextLost?: boolean;
    posesMissing: number;
    inputError?: string;
}
export type XrMode = 'vr' | 'ar';
export type XrAvailability = 'headset' | 'none' | 'unavailable';
export type XrBackdrop = 'black' | 'passthrough' | 'hologram';
export type XrStage = 'session' | 'context' | 'space' | 'layer' | 'loop' | 'machine' | 'running';
export interface EmulatorXrHost {
    readonly sim: Sim | undefined;
    readonly input: EmulatorInputController;
    displayMode(): DisplayMode;
    onXrEnded(diagnostics: XrDiagnostics): void;
    resumeAudio?(): void;
    quadLayers?: boolean;
    mode?: XrMode;
    backdrop?: XrBackdrop;
    view?: XrScreen;
    onXrViewChanged?(view: XrScreen): void;
    onXrUiShown?(shown: boolean): void;
    pageUi?: boolean;
    debug?: boolean;
    offer?: boolean;
}
export declare class EmulatorXrSession {
    protected readonly host: EmulatorXrHost;
    protected readonly granted: XrMode;
    protected readonly session: XrSession;
    protected readonly renderer: XrFrameRenderer;
    protected readonly space: XrSpace;
    protected readonly stats: XrDiagnostics;
    protected readonly reach: (stage: XrStage) => void;
    static isSupported(mode?: XrMode): Promise<boolean>;
    static canOffer(): boolean;
    static availability(): Promise<XrAvailability>;
    static onDeviceChange(listener: () => void): {
        dispose(): void;
    };
    protected static looping: number;
    protected looping: boolean;
    static start(host: EmulatorXrHost): Promise<EmulatorXrSession>;
    protected readonly gl: WebGL2RenderingContext;
    protected readonly image: WebGLTexture;
    protected readonly imageFramebuffer: WebGLFramebuffer;
    protected readonly layerFramebuffer: WebGLFramebuffer;
    protected quad: {
        binding: XrWebGlBinding;
        layer: XrQuadLayer;
        program: WebGLProgram;
        viewport: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        overlayProgram: WebGLProgram;
        overlayViewport: WebGLUniformLocation | null;
        hologram: WebGLUniformLocation | null;
        cover: XrProjectionLayer | XrQuadLayer | undefined;
        coverIsSphere?: boolean;
        coverDrawn?: boolean;
    } | undefined;
    protected projection: {
        layer: XrWebGlLayer;
        program: WebGLProgram;
        size: WebGLUniformLocation | null;
        viewProjection: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        hologram: WebGLUniformLocation | null;
        overlayProgram: WebGLProgram;
        overlayViewProjection: WebGLUniformLocation | null;
        overlayCenter: WebGLUniformLocation | null;
        overlaySize: WebGLUniformLocation | null;
        overlayYaw: WebGLUniformLocation | null;
    } | undefined;
    protected sim: Sim | undefined;
    protected backdropShown: XrBackdrop;
    protected readonly tapOwner: string;
    protected view: XrScreen;
    protected viewReportedAt: number;
    protected lastFrameTime: number | undefined;
    protected adjusting: boolean;
    protected panel: {
        panel: XrPanel;
        cursor: number;
    } | undefined;
    protected readonly panelOverlay: XrOverlay;
    protected readonly toastOverlay: XrOverlay;
    protected toastUntil: number;
    protected readonly waitOverlay: XrOverlay;
    protected waiting: string | undefined;
    protected readonly ui: XrUi | undefined;
    protected uiWanted: boolean;
    protected uiPress: keyof XrButtons | undefined;
    protected panelRows: XrPanelRow[];
    protected readonly pointerOverlay: XrOverlay;
    protected pointingHand: 'left' | 'right';
    protected pointingAt: 'item' | 'panel' | 'nothing';
    protected previousButtons: XrButtons;
    protected repeat: {
        step: number;
        at: number;
    } | undefined;
    protected heldBack: boolean;
    protected dirty: boolean;
    protected frameHandle: number | undefined;
    protected readonly squeezing: Set<string>;
    protected exitTimer: ReturnType<typeof setTimeout> | undefined;
    protected ended: boolean;
    protected started: boolean;
    protected constructor(host: EmulatorXrHost, granted: XrMode, session: XrSession, renderer: XrFrameRenderer, canvas: HTMLCanvasElement, space: XrSpace, stats: XrDiagnostics, reach: (stage: XrStage) => void);
    protected clearImage(): void;
    protected begin(): Promise<void>;
    setSim(sim: Sim | undefined): Promise<void>;
    protected createQuadLayer(): boolean;
    protected createProjectionLayer(): void;
    get mode(): XrMode;
    get backdrop(): XrBackdrop;
    setBackdrop(backdrop: XrBackdrop): void;
    get running(): boolean;
    get diagnostics(): XrDiagnostics;
    setDisplayMode(mode: DisplayMode): void;
    end(): Promise<void>;
    protected readonly onFrame: (time: number, frame: XrFrame) => void;
    protected checkGl(where: string): void;
    protected pollInput(time: number, frame: XrFrame): void;
    protected point(frame: XrFrame): void;
    protected rays(frame: XrFrame): XrRay[];
    protected showPointer(visible: boolean): void;
    get uiShown(): boolean;
    setUiShown(shown: boolean): void;
    protected toggleUi(): void;
    protected applyUi(): void;
    protected driveUi(reading: XrControllerReading, pressed: (name: keyof XrButtons) => boolean, elapsed: number, frame: XrFrame): void;
    protected drivePanel(reading: XrControllerReading, pressed: (name: keyof XrButtons) => boolean, time: number): void;
    showPanel(panel: XrPanel): void;
    setView(view: XrScreen): void;
    resetScreen(): void;
    closePanel(): void;
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean>;
    setWaiting(text: string | undefined): void;
    protected showWaiting(): void;
    toast(text: string, error?: boolean): void;
    protected placeAround(): void;
    protected get overlays(): XrOverlay[];
    protected get screenShown(): boolean;
    protected drawPanel(): void;
    protected updateLayers(): void;
    protected adjustView(reading: XrControllerReading, elapsed: number, time: number): void;
    protected clicked: {
        left: boolean;
        right: boolean;
    };
    protected depthInProgress: number | undefined;
    protected applyScreenSize(): void;
    protected readonly onSqueezeStart: (event: Event) => void;
    protected readonly onSqueezeEnd: (event: Event) => void;
    protected drawQuad(frame: XrFrame): void;
    protected drawScreenQuad(frame: XrFrame, quad: NonNullable<EmulatorXrSession['quad']>): void;
    protected drawSphere(frame: XrFrame, quad: NonNullable<EmulatorXrSession['quad']>): void;
    protected drawCover(frame: XrFrame, binding: XrWebGlBinding, cover: XrProjectionLayer): void;
    protected drawProjection(frame: XrFrame): void;
    protected readonly onGesture: () => void;
    protected readonly onEnd: () => void;
}
//# sourceMappingURL=emulator-xr.d.ts.map