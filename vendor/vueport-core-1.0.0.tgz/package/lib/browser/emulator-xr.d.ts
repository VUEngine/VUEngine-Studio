/**
 * Playing in a headset: an immersive WebXR session that shows each eye its own
 * picture, which is what the Virtual Boy was built around.
 *
 * The game keeps running exactly as it does on the page. The worker still
 * draws the page's canvas; this takes a second copy of every frame through the
 * same video tap a recording uses (see `setVideoTap`), because WebXR exists on
 * the page's thread only and the worker's canvas cannot be shared with it.
 *
 * Each frame is composed once, side by side, by the ordinary renderer and its
 * shader — palette, VB Color and frame blending all come along — into a small
 * texture of the page's own. From there it reaches the headset one of two ways:
 *
 * - A quad layer, where the browser offers them. The headset's compositor
 *   puts the picture on a screen in space itself, which keeps it sharper and
 *   steadier than anything drawn into the eye buffers could be, and lets each
 *   eye be given its half of one texture. Enlarged by a whole multiple first,
 *   so the compositor's own filtering does not blur the pixels.
 * - Otherwise a projection layer, into which the screen is drawn per eye, with
 *   a filter that keeps pixel edges sharp without shimmering.
 *
 * Both eyes see the screen at the same place. The depth is the game's own:
 * the parallax between the two pictures puts things in front of or behind it,
 * as the console did, and the 3D Depth setting scales it as it always does.
 *
 * The headset's controllers are read here too, since a headset browser stops
 * the page's animation frames while a session lasts and never lists its
 * controllers to the Gamepad API. Their two sticks are the Virtual Boy's two
 * D-pads; see `readControllers`.
 *
 * In parts: the WebXR declarations in `emulator-xr-webxr.ts`, the controllers
 * in `emulator-xr-input.ts`, the drawing in `emulator-xr-render.ts`, and what
 * is drawn on menus and around the screen in `emulator-xr-panel.ts`.
 */
import { DisplayMode } from '../common/vb-constants';
import { Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import { XrButtons, XrControllerReading } from './emulator-xr-input';
import { XrHud, XrPanel, XrPanelRow } from './emulator-xr-panel';
import { XrFrameRenderer, XrOverlay } from './emulator-xr-render';
import { XrFrame, XrProjectionLayer, XrQuadLayer, XrSession, XrSpace, XrWebGlBinding, XrWebGlLayer } from './emulator-xr-webxr';
/** How the screen is shown in a headset; adjustable from inside it. */
export interface XrScreen {
    /** How wide the screen is, in meters, at the distance it stands at. */
    width: number;
    /**
     * The stereo depth to play at in the headset, in percent, as
     * `stereoDepth` is — but of half the real console's: see
     * {@link XR_DEPTH_SCALE}. Its own setting, because how deep a picture
     * looks depends on how big it is, and in a headset it is big.
     */
    depth: number;
}
/**
 * What the headset's depth is worth in the machine's own terms. A screen in a
 * headset is so much bigger than the console's that its full depth was too
 * strong to sit through, on a Quest 3; so 100 % there is half the console's,
 * and the setting still reads 100 % when it is where it starts out.
 */
export declare const XR_DEPTH_SCALE = 0.5;
/** The stereo depth a headset's setting comes to, for the machine. */
export declare function xrStereoDepth(screen: XrScreen): number;
/**
 * About 44 degrees across at the distance above, roughly how much of the view
 * the console's own screen fills; and the headset's full depth.
 */
export declare const XR_DEFAULT_SCREEN: XrScreen;
/** The narrowest and widest the screen can be made, in meters. */
export declare const XR_MIN_WIDTH = 0.6;
export declare const XR_MAX_WIDTH = 4;
/** The deepest the headset's depth goes, in percent; see {@link XrScreen.depth}. */
export declare const XR_MAX_DEPTH = 200;
/** A view brought into the ranges a headset can show. */
export declare function clampXrScreen(view: Partial<XrScreen>): XrScreen;
/**
 * The display rate to ask the headset for.
 *
 * A whole multiple of the machine's own 50 Hz shows every frame for the same
 * number of refreshes, so motion in the game is even; the highest such rate
 * wins. Without one, the highest rate at all, because the more often the
 * display refreshes, the less a frame can be shown too early or too late.
 */
export declare function pickXrFrameRate(rates: readonly number[]): number | undefined;
/** How the session went, for telling a headset that showed nothing why. */
export interface XrDiagnostics {
    /**
     * How far starting it got: the last step begun. A session that showed
     * nothing at all is most often one whose start never finished.
     */
    stage: XrStage;
    /** How the picture reached the headset. */
    path: 'quad' | 'projection' | 'none';
    /** The display rate asked for, if one was. */
    frameRate?: number;
    /** Headset frames drawn. */
    xrFrames: number;
    /** Frames the machine presented while the session lasted. */
    gameFrames: number;
    /** The first thing that went wrong, if anything did. */
    error?: string;
    /** The first WebGL error seen, as its code. */
    glError?: number;
    /** Where it was seen: the step it surfaced after. */
    glErrorAt?: string;
    /** What the browser said each eye's part of the quad layer was, on the first frame. */
    quadLayout?: string;
    /** Whether the context was lost along the way. */
    contextLost?: boolean;
    /** Headset frames that came without a pose to draw from. */
    posesMissing: number;
    /** The first thing that went wrong reading the controllers, apart from drawing. */
    inputError?: string;
}
/**
 * What kind of session to ask for: `vr`, for a headset that can only show a
 * room of its own; `ar`, for one that can also show the room it is in. An
 * `ar` session shows that room only as its backdrop says — see
 * {@link EmulatorXrSession.setBackdrop} — and covers it in black otherwise,
 * so that it can go between them without being asked for again: a browser
 * grants a session only to a gesture, and switching from inside one has none.
 */
export type XrMode = 'vr' | 'ar';
/**
 * What this browser can do with a headset: play in one (`headset`), speak
 * WebXR with none to offer just now (`none`), or not speak it at all
 * (`unavailable`) — the last is a webview or browser that never will, however
 * many headsets are plugged in.
 */
export type XrAvailability = 'headset' | 'none' | 'unavailable';
/**
 * What is around the screen: black, a room of its own; the player's room,
 * passthrough; or the player's room through the screen too — its black made
 * see-through, so that only what the game lights up floats in the room, a
 * hologram. Anything but black wants an `ar` session.
 */
export type XrBackdrop = 'black' | 'passthrough' | 'hologram';
/** The steps of starting a session, in order; see {@link XrDiagnostics.stage}. */
export type XrStage = 'session' | 'context' | 'space' | 'layer' | 'loop' | 'machine' | 'running';
/** What a session needs from the emulator it shows. */
export interface EmulatorXrHost {
    /** The machine to show, if one is running yet; see {@link EmulatorXrSession.setSim}. */
    readonly sim: Sim | undefined;
    /** The controls to drive it with. */
    readonly input: EmulatorInputController;
    /** The display settings; the headset takes their palette and blending. */
    displayMode(): DisplayMode;
    /** The session is over, whoever ended it, and this is how it went. */
    onXrEnded(diagnostics: XrDiagnostics): void;
    /**
     * Ask for the machine's audio again. The machine is clocked by its audio,
     * so a headset that stops the page's sound on the way in would freeze it;
     * called on the way in and on every trigger pressed in the headset, which
     * the browser counts as a gesture as it would a click.
     */
    resumeAudio?(): void;
    /**
     * False to draw into the eye buffers even where the browser offers a quad
     * layer — for telling a layer problem from any other.
     */
    quadLayers?: boolean;
    /** What kind of session to ask for; `vr` without one. */
    mode?: XrMode;
    /** What an `ar` session starts out with around the screen; black without one. */
    backdrop?: XrBackdrop;
    /** How to show the screen, as last left; {@link XR_DEFAULT_SCREEN} without one. */
    view?: XrScreen;
    /**
     * The screen's size or depth has been adjusted from inside the headset.
     * The depth is the host's to apply — it is the machine's, not the
     * picture's — and both are the host's to keep for next time.
     */
    onXrViewChanged?(view: XrScreen): void;
    /**
     * The menu a stick click opens, built fresh each time it opens. Absent,
     * or answering nothing, leaves the click alone.
     */
    quickMenu?(): XrPanel | undefined;
    /**
     * What the page shows around its picture — badges, status bar — to show
     * around the screen. Asked a few times a second; drawn again only when
     * the answer changes.
     */
    hud?(): XrHud | undefined;
}
/**
 * One immersive session. Start one with {@link EmulatorXrSession.start} from a
 * click or a key press — a browser grants a headset to nothing else, and only
 * for a few seconds after it, so a game can be started into a session that is
 * already showing: the screen is a dim red until there is a machine to show.
 */
export declare class EmulatorXrSession {
    protected readonly host: EmulatorXrHost;
    protected readonly session: XrSession;
    protected readonly renderer: XrFrameRenderer;
    protected readonly space: XrSpace;
    protected readonly stats: XrDiagnostics;
    protected readonly reach: (stage: XrStage) => void;
    /** Whether this browser has a headset to offer — for passthrough, one that can show the room. */
    static isSupported(mode?: XrMode): Promise<boolean>;
    /** See {@link XrAvailability}. */
    static availability(): Promise<XrAvailability>;
    /**
     * Calls `listener` whenever a headset comes or goes. A standalone one is
     * there from the start, but a PC's arrives when Link or a streamer such as
     * Virtual Desktop connects, which is usually after the page has asked.
     */
    static onDeviceChange(listener: () => void): {
        dispose(): void;
    };
    static start(host: EmulatorXrHost): Promise<EmulatorXrSession>;
    protected readonly gl: WebGL2RenderingContext;
    /** The side-by-side picture, composed once per frame that arrives. */
    protected readonly image: WebGLTexture;
    protected readonly imageFramebuffer: WebGLFramebuffer;
    /** Where a layer's texture is attached to be drawn into. */
    protected readonly layerFramebuffer: WebGLFramebuffer;
    /** The quad layer, its binding, and the program that fills it. */
    protected quad: {
        binding: XrWebGlBinding;
        layer: XrQuadLayer;
        program: WebGLProgram;
        viewport: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        /** Copies a menu or a line of news into its own quad layer. */
        overlayProgram: WebGLProgram;
        overlayViewport: WebGLUniformLocation | null;
        /** Dark see-through, for the hologram backdrop. */
        hologram: WebGLUniformLocation | null;
        /**
         * Black over the whole view, under everything, for an `ar` session
         * whose backdrop is black — where the browser has projection layers.
         */
        cover: XrProjectionLayer | undefined;
    } | undefined;
    /** Otherwise, the projection layer and the program that draws the screen into it. */
    protected projection: {
        layer: XrWebGlLayer;
        program: WebGLProgram;
        size: WebGLUniformLocation | null;
        viewProjection: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        hologram: WebGLUniformLocation | null;
        /** Draws a menu or a line of news over the screen. */
        overlayProgram: WebGLProgram;
        overlayViewProjection: WebGLUniformLocation | null;
        overlayCenter: WebGLUniformLocation | null;
        overlaySize: WebGLUniformLocation | null;
    } | undefined;
    /** The machine shown, if there is one; see {@link setSim}. */
    protected sim: Sim | undefined;
    /** What is around the screen; see {@link setBackdrop}. */
    protected backdropShown: XrBackdrop;
    /**
     * What this session's copy of the frames is asked for under. Its own, not
     * one every session shares, so that a session letting go of its copy can
     * never take another's with it, whichever order one ends and the next
     * starts in.
     */
    protected readonly tapOwner: string;
    /** How the screen is shown, as adjusted from inside the headset. */
    protected view: XrScreen;
    /** When the view was last passed on, and the frame time before this one. */
    protected viewReportedAt: number;
    protected lastFrameTime: number | undefined;
    /** Whether an adjustment is under way, so its end can be passed on. */
    protected adjusting: boolean;
    /** The menu or question in front of the screen, and where its cursor is. */
    protected panel: {
        panel: XrPanel;
        cursor: number;
    } | undefined;
    protected readonly panelOverlay: XrOverlay;
    /** The line of news beneath the screen, and until when it stays. */
    protected readonly toastOverlay: XrOverlay;
    protected toastUntil: number;
    /** The badges over the screen and the status strip beneath it. */
    protected readonly badgesOverlay: XrOverlay;
    protected readonly statusOverlay: XrOverlay;
    /** When they were last read, and what they said, so unchanged ones are not drawn again. */
    protected hudReadAt: number;
    protected hudShown: string | undefined;
    /** Where each item of the panel up was drawn, for what a controller points at. */
    protected panelRows: XrPanelRow[];
    /** The dot where a controller's ray meets the panel. */
    protected readonly pointerOverlay: XrOverlay;
    /** The hand that points, which is the one that last pulled its trigger. */
    protected pointingHand: 'left' | 'right';
    /** What the ray is on: an item, which a trigger then takes; the panel around them; or nothing. */
    protected pointingAt: 'item' | 'panel' | 'nothing';
    /** The buttons held on the frame before, for telling a press from a hold. */
    protected previousButtons: XrButtons;
    /** The direction a stick is moving the cursor in, and when it moves it next. */
    protected repeat: {
        step: number;
        at: number;
    } | undefined;
    /**
     * Whether the game is kept from the controllers until they are let go:
     * the press that closed a menu must not reach the game as well.
     */
    protected heldBack: boolean;
    /** Whether a frame has arrived since the picture was last composed. */
    protected dirty: boolean;
    protected frameHandle: number | undefined;
    /** Which hands are holding their grip, by the session's own events. */
    protected readonly squeezing: Set<string>;
    /** Ends the session once both grips have been held long enough. */
    protected exitTimer: ReturnType<typeof setTimeout> | undefined;
    protected ended: boolean;
    /** Whether {@link begin} got all the way, and the host is owed an `onXrEnded`. */
    protected started: boolean;
    protected constructor(host: EmulatorXrHost, session: XrSession, renderer: XrFrameRenderer, canvas: HTMLCanvasElement, space: XrSpace, stats: XrDiagnostics, reach: (stage: XrStage) => void);
    /**
     * A red screen, until a frame is composed, rather than the texture's
     * transparent black: a screen that is there but has nothing on it reads
     * differently from one that is not there at all.
     */
    protected clearImage(): void;
    protected begin(): Promise<void>;
    /**
     * Show this machine, or none — a game being opened, closed, or built again
     * underneath the session, which outlives all three.
     */
    setSim(sim: Sim | undefined): Promise<void>;
    /** Put the screen in a quad layer, if this browser has them. */
    protected createQuadLayer(): boolean;
    /** Draw the screen into the eye buffers instead. */
    protected createProjectionLayer(): void;
    /** What kind of session this is. */
    get mode(): XrMode;
    /** What is around the screen. */
    get backdrop(): XrBackdrop;
    /**
     * Show the player's room around the screen — and through it, for a
     * hologram — or cover it in black: at once, in the session as it is.
     * Only an `ar` session has a room to show.
     */
    setBackdrop(backdrop: XrBackdrop): void;
    /** Whether the session is under way: started, and not ended since. */
    get running(): boolean;
    /** How the session has gone so far. */
    get diagnostics(): XrDiagnostics;
    /** Follow a change to the display settings. */
    setDisplayMode(mode: DisplayMode): void;
    /** Leave the headset. The host hears of it through `onXrEnded`. */
    end(): Promise<void>;
    protected readonly onFrame: (time: number, frame: XrFrame) => void;
    /** Note the first WebGL error, and where it surfaced. */
    protected checkGl(where: string): void;
    protected pollInput(time: number): void;
    /**
     * Follow the pointing hand's ray onto the panel, if one is up: the dot
     * goes where it meets it, and the cursor onto the item it is on.
     */
    protected point(frame: XrFrame): void;
    /** Where the pointing hand's ray meets the panel — or, where it misses, the other hand's. */
    protected pointerHit(frame: XrFrame): ReturnType<XrOverlay['hit']>;
    protected showPointer(visible: boolean): void;
    /** Open the host's menu, if it has one to offer. */
    protected openQuickMenu(): boolean;
    /**
     * The sticks move the cursor, repeating while held; A or a trigger takes
     * the line under it, B or a stick click closes the panel.
     */
    protected drivePanel(reading: XrControllerReading, pressed: (name: keyof XrButtons) => boolean, time: number): void;
    /**
     * Show a menu or a question in front of the screen, in place of any that
     * is up. The controllers drive it, and not the game, until it closes.
     */
    showPanel(panel: XrPanel): void;
    /**
     * Take a size and depth set from outside the headset — the settings pane,
     * with a tethered headset showing the page at the same time. Not passed
     * back through `onXrViewChanged`: whoever set it has it already.
     */
    setView(view: XrScreen): void;
    /** Put the screen's size and depth back to how they start out. */
    resetScreen(): void;
    /** Take the menu or question away, if one is up. */
    closePanel(): void;
    /**
     * Ask something in the headset, with the two answers as a menu. Backing
     * out of it, or the session ending, is the second answer.
     */
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean>;
    /** A line of news beneath the screen, for a few seconds. */
    toast(text: string, error?: boolean): void;
    /**
     * Put what goes around the screen where it goes, for the screen's size:
     * the badges over it, the status strip under it, and the news under that.
     * As wide as the screen, as the page's are as wide as its window.
     */
    protected placeAround(): void;
    /** Read what goes around the screen again, now and then, and draw what changed. */
    protected refreshHud(time: number): void;
    /** Everything shown in front of or around the screen, in the order it stacks. */
    protected get overlays(): XrOverlay[];
    protected drawPanel(): void;
    /** Give a session with quad layers the overlays that are showing, over the screen. */
    protected updateLayers(): void;
    /**
     * A grip held, and the sticks pushed: the left one makes the screen bigger
     * or smaller, the right one the picture deeper or flatter. Right or up is
     * more of either, left or down less; clicking a stick puts its own back
     * to how it started out.
     */
    protected adjustView(reading: XrControllerReading, elapsed: number, time: number): void;
    /** Whether each stick was pressed in on the frame before, for telling a click from a hold. */
    protected clicked: {
        left: boolean;
        right: boolean;
    };
    /** The unrounded depth while it is being adjusted. */
    protected depthInProgress: number | undefined;
    /** Size the screen as the view says. */
    protected applyScreenSize(): void;
    /**
     * Both grips held for a second leave the headset.
     *
     * Kept by the session's own events rather than read off the controllers
     * with the buttons, so that the way out works whatever else does not: a
     * headset showing nothing must still let somebody out without reaching
     * for the system menu.
     */
    protected readonly onSqueezeStart: (event: Event) => void;
    protected readonly onSqueezeEnd: (event: Event) => void;
    /** Draw each eye's half into the quad layer, enlarged. */
    protected drawQuad(frame: XrFrame): void;
    /** Black, all over each eye's view: the room of its own an `ar` session gives the screen. */
    protected drawCover(frame: XrFrame, binding: XrWebGlBinding, cover: XrProjectionLayer): void;
    /** Draw the screen into each eye's view, in a dark room. */
    protected drawProjection(frame: XrFrame): void;
    /** Something done in the headset, which the audio may have been waiting for. */
    protected readonly onGesture: () => void;
    protected readonly onEnd: () => void;
}
//# sourceMappingURL=emulator-xr.d.ts.map