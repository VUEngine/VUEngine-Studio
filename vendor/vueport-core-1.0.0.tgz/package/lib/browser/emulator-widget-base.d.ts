import { Message } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import * as React from 'react';
import { Root } from 'react-dom/client';
import { DisposableCollection } from '../common/emulator-events';
export declare class VueportWidget extends Widget {
    protected readonly toDispose: DisposableCollection;
    protected readonly toDisposeOnDetach: DisposableCollection;
    dispose(): void;
    protected onBeforeDetach(msg: Message): void;
}
/**
 * A widget whose content is React, rendered from onUpdateRequest, so a panel redraws by calling update().
 * Unlike Theia's ReactWidget there is no PerfectScrollbar: it fought the panels' own `overflow: auto`, showing two
 * scrollbars at once, and blocked horizontal scrolling, which the wide tables (VSU, Memory) need.
 */
export declare abstract class VueportReactWidget extends VueportWidget {
    protected readonly nodeRoot: Root;
    constructor();
    protected renderGeneration: number;
    protected readonly afterCommit: {
        generation: number;
        callback: () => void;
    }[];
    protected onUpdateRequest(msg: Message): void;
    /**
     * Runs `callback` once React has put a tree built after this call into the DOM, so it sees the state changed just
     * before. A bare requestAnimationFrame is too early: Lumino runs the update in a frame of its own and React commits
     * later still, so whatever it looked up was still the old state (a selection scrolled to the tile being left).
     */
    protected whenRendered(callback: () => void): void;
    protected committed(generation: number): void;
    protected abstract render(): React.ReactNode;
}
//# sourceMappingURL=emulator-widget-base.d.ts.map