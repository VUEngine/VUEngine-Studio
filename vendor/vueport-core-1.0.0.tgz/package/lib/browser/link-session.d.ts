import { Disposable, DisposableCollection, Emitter, Event } from '../common/emulator-events';
import { LinkChannel, LinkMessage, LinkSeat } from '../common/link-channel';
import { ScheduledEdit } from '../common/vb-protocol';
import { Sim } from './core/vb-core';
import { EmulatorSession } from './emulator-core-service';
/** How a link session is getting on, for the chrome to show. */
export declare enum LinkState {
    /** Announcing ourselves, with nobody answering yet. */
    Waiting = "waiting",
    /** Both windows are present and playing. */
    Connected = "connected",
    /** Connected, but stopped because the other window's input has not arrived. */
    Stalled = "stalled",
    /**
     * The session is over and will not resume: the other window closed, or the
     * two could never have played together.
     *
     * Not where an ordinary unlink leads. A player who unlinks is still there,
     * so this window goes back to {@link Waiting} with its end of the cable
     * plugged in, and the next hello picks the session straight back up.
     */
    Closed = "closed"
}
/**
 * Why a session ended or refused to start, in words a person can act on.
 *
 * `left` is the one that is not a failure: the other player unlinked, and both
 * windows are still sitting there with the game open. It is the reason this
 * window goes back to {@link LinkState.Waiting} rather than to
 * {@link LinkState.Closed} — see {@link LinkSession.peerGone}. `closed` is the
 * same message from a window that is going away, which there is no waiting for.
 */
export interface LinkRefusal {
    reason: 'protocol' | 'rom' | 'core' | 'seat' | 'left' | 'closed' | 'desync' | 'edit';
    message: string;
}
export interface LinkSessionOptions {
    session: EmulatorSession;
    channel: LinkChannel;
    seat: LinkSeat;
    /** The cartridge both windows must be running, as its CRC32 string. */
    rom: string;
    /**
     * The cartridge itself, for the mirror.
     *
     * Read when the mirror is built rather than held here, because the bytes
     * are up to sixteen megabytes and the session has no other use for them.
     */
    romData(): ArrayBuffer | undefined;
    /** The core's state struct size, as a build check. */
    core: number;
    /**
     * Frames between pressing a button and the machines acting on it.
     *
     * Only the window that answers a hello decides this; the joining window
     * takes whatever it is told, so both sides always agree.
     */
    delay?: number;
    /**
     * The changes this window's own machine is already under, for the other
     * window's mirror of it to match.
     *
     * A session starts both machines from power-on, but not from *nothing*: a
     * player who switched a cheat on before inviting anybody has a machine
     * that is not the one a fresh mirror would be, and the two would come
     * apart on the first frame the cheat touched. So whatever standing edits
     * this window is running under travel once, at the start of every run.
     *
     * In practice this is the enabled cheats. Called rather than held because
     * they can change between a session being built and it beginning.
     */
    standingEdits?(): ScheduledEdit[];
}
export declare class LinkSession implements Disposable {
    /**
     * How far ahead of the machines input is booked, when nobody says
     * otherwise.
     *
     * Three frames is 60 ms, which is far more than a BroadcastChannel needs
     * and enough that neither window has to stall over an ordinary hiccup.
     * Netplay over a wire will want to negotiate this rather than assume it.
     */
    static readonly DEFAULT_DELAY_FRAMES = 3;
    /** How often a window with nobody to talk to says hello again. */
    static readonly HELLO_INTERVAL_MS = 500;
    /**
     * How long a window will stand still waiting for the other one.
     *
     * A window that is closed says goodbye on its way out, but one that
     * crashed, was killed, or lost its connection says nothing at all — and
     * without this its partner would sit at a frozen picture for ever, under
     * lockstep, waiting for input that is never coming. Long enough to sit
     * through a slow tab being woken up, short enough that a person does not
     * conclude the emulator has hung.
     */
    static readonly PEER_TIMEOUT_MS = 10000;
    /** How much early remote input is held while this window sets up. */
    static readonly MAX_PENDING_REMOTE = 600;
    /**
     * How often the two windows check that they still agree.
     *
     * Every second or so. Two machines running the same cartridge from the
     * same inputs *should* stay identical for ever — that is what
     * `tests/determinism-probe.mjs` measures — but "should" is not something
     * to leave unchecked in a session someone is playing: a desync that goes
     * unnoticed is two people playing different games and blaming each other.
     */
    static readonly DIGEST_PERIOD_FRAMES = 60;
    /**
     * How many of our mirror's digests are kept while their counterpart is in
     * flight. A couple of seconds' worth; anything older is of no use.
     */
    static readonly MAX_KEPT_DIGESTS = 8;
    /** How many booked writes are held while this window sets up. */
    static readonly MAX_PENDING_EDITS = 64;
    protected readonly toDispose: DisposableCollection;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /** Fires whenever {@link state} changes, for the chrome to redraw. */
    readonly onDidChange: Event<void>;
    protected readonly channel: LinkChannel;
    protected readonly emulatorSession: EmulatorSession;
    readonly seat: LinkSeat;
    protected readonly rom: string;
    protected readonly romData: () => ArrayBuffer | undefined;
    protected readonly coreBuild: number;
    protected mirror: Sim | undefined;
    protected delay: number;
    state: LinkState;
    refusal: LinkRefusal | undefined;
    /**
     * The mask the player is holding right now.
     *
     * Booked against frames as they come up rather than when it changes: under
     * lockstep every frame needs an entry, so a session is a producer that
     * keeps the schedule filled, not a reporter of changes.
     */
    protected heldKeys: number;
    /** The next frame this window has not yet booked its own input for. */
    protected nextFrame: number;
    /** The last frame the machines reported reaching. */
    protected machineFrame: number;
    protected helloTimer: ReturnType<typeof setInterval> | undefined;
    protected stallTimer: ReturnType<typeof setTimeout> | undefined;
    protected disposed: boolean;
    /**
     * Set the moment this window commits to starting, before any of the
     * setting up has happened.
     *
     * The joining window says hello until it hears back, so a second hello can
     * easily arrive while the answer to the first is still being acted on.
     * Without this flag that second hello starts the whole session over —
     * resetting machines that had just been reset, and leaving the two windows
     * booking input against different frames.
     */
    protected beginning: boolean;
    /**
     * Remote input that arrived before there was a machine to put it in.
     *
     * The other window starts booking the moment it begins, which may be
     * before this one has its mirror up. Dropping those frames looks harmless
     * and is fatal: under lockstep nothing re-sends them, so the mirror waits
     * for frame zero for ever and both windows stop.
     */
    protected readonly pendingRemote: {
        epoch: number;
        frame: number;
        keys: number;
    }[];
    /**
     * Booked writes that arrived before there was a machine to put them in.
     *
     * Held for the same reason the input above is, and it matters more here:
     * the standing cheats travel once, at frame 0 of every run, and a window
     * that dropped them because its mirror was a moment late would play the
     * whole session against a machine the other window is not running.
     */
    protected readonly pendingEdits: {
        epoch: number;
        seat: LinkSeat;
        frame: number;
        edits: ScheduledEdit[];
    }[];
    /** See {@link LinkSessionOptions.standingEdits}. */
    protected readonly standingEdits: () => ScheduledEdit[];
    /**
     * What our copy of the other player's machine looked like, by frame.
     *
     * Held until their own digest for that frame arrives, which is what it is
     * compared against.
     */
    protected readonly mirrorDigests: Map<number, number>;
    /**
     * Which run of the session this is. See `epoch` in `link-channel.ts`.
     *
     * Zero for the first, one more for every save state loaded into it.
     */
    protected epoch: number;
    constructor(options: LinkSessionOptions);
    /** The other player's machine, once there is one. For the debugger to offer. */
    get mirrorSim(): Sim | undefined;
    get connected(): boolean;
    /**
     * Start waiting for the other window.
     *
     * Only player 2's window says hello, and player 1's only answers. Letting
     * both do both would leave which of them is the authority to a race, and
     * the authority is what decides where the session starts from — see
     * `begin` in `link-channel.ts`.
     *
     * The hello is repeated rather than sent once: the two windows come up in
     * whatever order the browser feels like, and a hello that arrived before
     * anyone was listening is indistinguishable from one that was never sent.
     */
    start(): void;
    /** True for the window that decides where the session starts from. */
    protected get authority(): boolean;
    /**
     * Take the mask the player is holding.
     *
     * Not applied here: it is booked against the frames still to come, so that
     * the same press lands on the same frame in both windows however long the
     * message took to cross.
     */
    setKeys(keys: number): void;
    protected sayHello(): void;
    /**
     * A message that could not be acted on.
     *
     * Acting on one means telling machines things — `begin` alone makes a
     * dozen awaited calls — and a machine can go away while that is happening:
     * the other window closes, this window's session ends, the ROM is closed.
     * The call then rejects, and because messages arrive in a listener there
     * is nobody holding the promise, so the rejection went to the page as an
     * uncaught error. It is not one: a session whose machines have gone is
     * over, which is the only thing to say about it.
     *
     * Ended rather than ignored where the session still believes it is
     * running, because something that cannot be told to the machines has been
     * missed, and carrying on from there is exactly the silent disagreement
     * the digests exist to catch.
     */
    protected receiveFailed(error: unknown): void;
    protected receive(message: LinkMessage): Promise<void>;
    protected onHello(seat: LinkSeat, message: {
        protocol: number;
        rom: string;
        core: number;
    }): Promise<void>;
    protected onWelcome(message: {
        seat: LinkSeat;
        protocol: number;
        rom: string;
        core: number;
        delay: number;
    }): Promise<void>;
    /** Everything that has to match before two windows can play together. */
    protected checkCompatible(seat: LinkSeat, message: {
        protocol: number;
        rom: string;
        core: number;
    }): LinkRefusal | undefined;
    /**
     * Put all of this window's machines back to power-on and start the session
     * at frame zero.
     *
     * Both windows do this from the same save RAM at what is, for them, the
     * same moment — which is the only way two independently running emulators
     * can be said to be in step at all. It restarts the game, and that is not
     * a side effect to apologize for: it is what putting a cable between two
     * Virtual Boys amounts to.
     *
     * From here neither machine runs a frame it has not been given input for,
     * which is what keeps the two windows identical from then on.
     */
    protected begin(cartRam: ArrayBuffer, cartRamWindow?: number): Promise<void>;
    /**
     * Book this window's input for every frame up to the horizon, and tell the
     * other window about each one.
     *
     * The horizon moves with the machines rather than with the wall clock, so
     * this cannot drift: fall behind and the machines wait for us, run ahead
     * and there is simply nothing left to book.
     */
    protected fillSchedule(): void;
    /**
     * Change one of the two machines, in both windows, on the same frame.
     *
     * The write side of the session, and the reason it exists: switching a
     * cheat on, or poking a value the Cheat Finder turned up, is a change
     * nothing in the emulated program knows about — so unlike a button press
     * it has no route from one window to the other. Made in one window only,
     * the two machines are running different games from that moment, which
     * the digest check ends the session over a second later without being
     * able to say why.
     *
     * `seat` names the machine being changed rather than the window asking,
     * so a debugger can aim at either: our own seat is our own machine here
     * and the mirror there, and the other seat the other way round.
     *
     * ## The frame
     *
     * Far enough ahead that both windows can still book it. Neither window
     * can be more than {@link delay} frames from the other — each only runs
     * on input booked at most that far ahead, and under lockstep it runs on
     * nothing else — so `nextFrame`, which is already a full delay past our
     * own machine, is past theirs too. A second delay on top is the message's
     * travel time, and 60 ms of it is a great deal more than a
     * BroadcastChannel takes.
     *
     * Not a promise of anything: the booking goes in as the frame is chosen
     * and the message leaves at once, because the other window has to hear
     * about it before its own machine reaches that frame.
     */
    scheduleEdits(seat: LinkSeat, edits: ScheduledEdit[]): boolean;
    /**
     * Put booked writes into whichever of this window's machines they name.
     *
     * A booking the core refuses is a frame that has already been emulated —
     * which means this window has applied a change the other one applied
     * somewhere else, or not at all. That is a desync that has already
     * happened; saying so beats letting the digest report it a second later
     * as an unexplained one.
     */
    protected bookEdits(seat: LinkSeat, frame: number, edits: ScheduledEdit[]): void;
    /**
     * The other window changed one of the machines.
     *
     * Held rather than dropped when there is nowhere to put it yet — see
     * {@link pendingEdits}, and `onRemoteInput` for the same reasoning about
     * input.
     */
    protected onRemoteEdits(epoch: number, seat: LinkSeat, frame: number, edits: ScheduledEdit[]): void;
    /**
     * Tell the other window what this window's machine is already running
     * under, so its mirror of us starts the run the same way.
     *
     * At frame zero, and sent before the first input is booked: the channel
     * delivers in order, so a cheat sent first is in force before the frame
     * it would otherwise have missed.
     */
    protected sendStandingEdits(): void;
    /**
     * One of this window's machines reached a frame its digest was due at.
     *
     * Ours goes to the other window, to be checked against their copy of this
     * machine. Our copy of *their* machine is kept until their own digest for
     * that frame arrives.
     */
    protected onLocalDigest(sim: number, frame: number, digest: number): void;
    /**
     * The other window's account of its own machine at one frame.
     *
     * Compared against our copy of it. A frame we have nothing for is not a
     * disagreement — the two windows do not reach a frame at the same instant,
     * so one side's digest routinely arrives before or after ours was taken;
     * only two digests of the same frame that differ mean anything.
     */
    protected onRemoteDigest(frame: number, digest: number): void;
    /**
     * A snapshot of both machines, for saving.
     *
     * Named by player rather than by whose window they came from, because that
     * is the only naming both windows agree on. Either window can take one:
     * they are running the same pair, so the two snapshots are the same.
     */
    snapshot(): Promise<{
        p1: ArrayBuffer;
        p2: ArrayBuffer;
    } | undefined>;
    /**
     * Put both windows back to a saved moment.
     *
     * Sent before it is applied here, so the other window starts its own
     * restart at about the same time rather than a round trip later.
     */
    resume(p1: ArrayBuffer, p2: ArrayBuffer): Promise<void>;
    protected applyResume(epoch: number, p1: ArrayBuffer, p2: ArrayBuffer): Promise<void>;
    protected onRemoteInput(epoch: number, frame: number, keys: number): void;
    /**
     * Book whatever the other window sent while this one was setting up.
     *
     * Only for the run we are now on: anything older named frames that have
     * been played already, and anything newer is for a restart still to come.
     */
    protected drainPendingRemote(mirror: Sim): void;
    protected setState(state: LinkState): void;
    /**
     * Start or stop counting how long we have been standing still.
     *
     * Standing still is ordinary — it is what happens whenever the other
     * window is a few frames behind — so this only gives up after long enough
     * that the other window is not coming back. See {@link PEER_TIMEOUT_MS}.
     */
    protected armStallTimeout(armed: boolean): void;
    /**
     * The other player is not there any more.
     *
     * Which of two things that means depends on whether their window is still
     * open, and the difference is the whole of what this decides. An unlink is
     * not a failure — both windows still have the game, and the natural next
     * thing either player does is link again — so this window lets the
     * machines go, forgets the run, and goes back to waiting with the channel
     * still open. Seat 2 starts saying hello again by itself, because its
     * hello timer only ever asked whether the state was `Waiting`; seat 1 goes
     * on listening for one. So re-linking is one press, in one window.
     *
     * A window that closed is gone, and a session waiting for it would be a
     * session waiting for nobody: that ends properly, and the chrome offers to
     * invite somebody new.
     */
    protected peerGone(refusal: LinkRefusal): void;
    /** End the session for good, leaving this window's own machine running alone. */
    protected close(refusal: LinkRefusal): void;
    /**
     * Put the machines back to running on their own.
     *
     * Lockstep comes off first and the mirror goes second: a machine left
     * under lockstep with nothing booking for it never runs another frame.
     */
    protected releaseMachines(): Promise<void>;
    /**
     * Leave the session.
     *
     * `leaving` is what the other window is told, and it decides what happens
     * there: `session` leaves it waiting, with the game still open in both
     * windows and one press between them and playing again; `window` ends it,
     * because this window is going away. See {@link LinkGoodbye}.
     */
    dispose(leaving?: 'session' | 'window'): void;
}
//# sourceMappingURL=link-session.d.ts.map