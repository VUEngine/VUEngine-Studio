import { Disposable, DisposableCollection, Emitter, Event } from '../common/emulator-events';
import { LinkChannel, LinkMachine, LinkMessage, LinkSeat } from '../common/link-channel';
import { LinkJournalEntry, ScheduledEdit } from '../common/vb-protocol';
import { Sim } from './core/vb-core';
import { EmulatorSession } from './emulator-core-service';
export declare enum LinkState {
    Waiting = "waiting",
    Connected = "connected",
    Stalled = "stalled",
    Closed = "closed"
}
export interface LinkRefusal {
    reason: 'protocol' | 'rom' | 'core' | 'seat' | 'left' | 'closed' | 'timeout' | 'failed' | 'ended' | 'desync' | 'edit';
    message: string;
}
export interface LinkReport {
    reason: 'desync' | 'stalled';
    seat: LinkSeat;
    rom: string;
    delay: number;
    epoch: number;
    frame: number;
    mismatch?: {
        frame: number;
        mirror: number;
        theirs: number;
    };
    cartRam?: string;
    cartRamWindow?: number;
    journals: {
        p1: LinkJournalEntry[];
        p2: LinkJournalEntry[];
    };
}
export interface LinkSessionOptions {
    session: EmulatorSession;
    channel: LinkChannel;
    seat: LinkSeat;
    rom: string;
    romData(): ArrayBuffer | undefined;
    core: number;
    delay?: number;
    standingEdits?(): ScheduledEdit[];
    onReport?(report: LinkReport): void;
    cartridge?(): LinkCartridge | undefined;
    onPeerPaused?(paused: boolean): void;
    calling?: boolean;
    rejoin?: boolean;
}
export interface LinkCartridge {
    image?: ArrayBuffer;
    vbc: boolean;
    esSound: boolean;
}
export declare class LinkSession implements Disposable {
    static readonly DEFAULT_DELAY_FRAMES = 3;
    static readonly HELLO_INTERVAL_MS = 500;
    static readonly PEER_TIMEOUT_MS = 10000;
    static readonly MAX_PENDING_REMOTE = 600;
    static readonly DIGEST_PERIOD_FRAMES = 60;
    static readonly MAX_KEPT_DIGESTS = 8;
    static readonly MAX_PENDING_EDITS = 64;
    protected readonly toDispose: DisposableCollection;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    protected readonly channel: LinkChannel;
    protected readonly emulatorSession: EmulatorSession;
    readonly seat: LinkSeat;
    protected readonly rom: string;
    protected readonly romData: () => ArrayBuffer | undefined;
    protected readonly coreBuild: number;
    protected mirror: Sim | undefined;
    protected delay: number;
    state: LinkState;
    refusal: LinkRefusal | undefined;
    protected heldKeys: number;
    protected turboKeys: number;
    protected turboRate: number;
    protected nextFrame: number;
    protected machineFrame: number;
    protected helloTimer: ReturnType<typeof setInterval> | undefined;
    protected stallTimer: ReturnType<typeof setTimeout> | undefined;
    protected disposed: boolean;
    protected beginning: boolean;
    protected readonly pendingRemote: {
        epoch: number;
        frame: number;
        keys: number;
    }[];
    protected readonly pendingEdits: {
        epoch: number;
        seat: LinkSeat;
        frame: number;
        edits: ScheduledEdit[];
    }[];
    protected readonly standingEdits: () => ScheduledEdit[];
    protected readonly mirrorDigests: Map<number, number>;
    protected readonly remoteDigests: Map<number, number>;
    protected epoch: number;
    protected startCartRam: {
        data: Uint8Array;
        window: number;
    } | undefined;
    protected reporting: boolean;
    protected readonly onReport: ((report: LinkReport) => void) | undefined;
    protected readonly cartridge: () => LinkCartridge | undefined;
    protected readonly onPeerPaused: ((paused: boolean) => void) | undefined;
    protected readonly calling: boolean;
    protected everConnected: boolean;
    protected peerPaused: boolean;
    protected ownPaused: boolean;
    protected readonly rejoin: boolean;
    protected awaitingHandover: {
        mine: LinkMachine;
        setup: LinkCartridge;
    } | undefined;
    constructor(options: LinkSessionOptions);
    get mirrorSim(): Sim | undefined;
    get connected(): boolean;
    /**
     * Only player 2's window says hello and player 1's only answers, or which one is the authority (deciding where the
     * session starts, see `begin` in link-channel.ts) would be a race. The hello repeats, as the windows come up in any
     * order and a hello sent before anyone listened is lost.
     */
    start(): void;
    protected get authority(): boolean;
    setKeys(keys: number): void;
    setTurbo(keys: number, rate: number): void;
    protected sayHello(): void;
    protected get rejoining(): boolean;
    protected freezeOwn(): Promise<LinkMachine>;
    protected canPickUp(hello: {
        running?: string;
        rejoin?: boolean;
    }, setup: LinkCartridge): boolean;
    /**
     * A message that could not be acted on. Acting means awaited calls to machines (`begin` alone makes a dozen), and
     * a machine can go away meanwhile; as messages arrive in a listener, nobody holds the promise and the rejection
     * went to the page as uncaught. Ended rather than ignored while the session thinks it runs, as a missed change is
     * exactly the silent disagreement the digests exist to catch.
     */
    protected receiveFailed(error: unknown): void;
    protected receive(message: LinkMessage): Promise<void>;
    protected onHello(seat: LinkSeat, message: {
        protocol: number;
        rom: string;
        core: number;
        running?: string;
        rejoin?: boolean;
    }): Promise<void>;
    protected pickUp(theirs: LinkMachine, setup: LinkCartridge): Promise<void>;
    protected onWelcome(message: {
        seat: LinkSeat;
        protocol: number;
        rom: string;
        core: number;
        delay: number;
    }): Promise<void>;
    protected checkCompatible(seat: LinkSeat, message: {
        protocol: number;
        rom: string;
        core: number;
    }): LinkRefusal | undefined;
    /**
     * Puts all machines back to power-on and starts the session at frame zero. Both windows do this from the same
     * save RAM at the same moment, the only way two independent emulators can be in step; restarting the game is what
     * a cable between two VBs amounts to. Except `hot` (see LinkBegin.hot): a relink running the same code keeps its
     * games, each machine back where it was held, each mirror from the other window's. From here no machine runs a
     * frame without input.
     */
    protected begin(cartRam: ArrayBuffer, cartRamWindow: number, setup: LinkCartridge, hot?: {
        mine: LinkMachine;
        theirs: LinkMachine;
    }): Promise<void>;
    protected fillSchedule(): void;
    /**
     * Changes one of the two machines, in both windows, on the same frame: a cheat or a Cheat Finder poke has no
     * route between windows like a button press, and made in one window only, the digest check ends the session a
     * second later without being able to say why. `seat` names the machine, not the window asking, so a debugger can
     * aim at either. The frame: neither window can be more than `delay` frames from the other, so `nextFrame` (a full
     * delay past our machine) is past theirs too; a second delay on top covers the message's travel. The booking is
     * made and the message sent at once, as the other window must hear about it before its machine reaches that
     * frame.
     */
    scheduleEdits(seat: LinkSeat, edits: ScheduledEdit[]): boolean;
    protected bookEdits(seat: LinkSeat, frame: number, edits: ScheduledEdit[]): void;
    protected onRemoteEdits(epoch: number, seat: LinkSeat, frame: number, edits: ScheduledEdit[]): void;
    protected sendStandingEdits(): void;
    protected onLocalDigest(sim: number, frame: number, digest: number): void;
    protected static keep(digests: Map<number, number>, frame: number, digest: number): void;
    protected onRemoteDigest(frame: number, digest: number): void;
    protected compareDigests(frame: number, ours: number, theirs: number): void;
    protected report(what: {
        reason: LinkReport['reason'];
        mismatch?: LinkReport['mismatch'];
    }): Promise<void>;
    snapshot(): Promise<{
        p1: ArrayBuffer;
        p2: ArrayBuffer;
    } | undefined>;
    resume(p1: ArrayBuffer, p2: ArrayBuffer): Promise<void>;
    protected applyResume(epoch: number, p1: ArrayBuffer, p2: ArrayBuffer): Promise<void>;
    restart(): Promise<void>;
    protected applyRestart(epoch: number): Promise<void>;
    protected startRun(epoch: number, states: {
        mine: ArrayBuffer;
        theirs: ArrayBuffer;
    } | undefined): Promise<void>;
    setPaused(paused: boolean): void;
    protected onPeerPause(paused: boolean): void;
    protected onRemoteInput(epoch: number, frame: number, keys: number): void;
    protected drainPendingRemote(mirror: Sim): void;
    protected setState(state: LinkState): void;
    protected armStallTimeout(armed: boolean): void;
    /**
     * The other player is gone. An unlink is not a failure: both windows still have the game, so this window lets the
     * machines go, forgets the run and goes back to waiting with the channel open. Seat 2's hello timer starts again by
     * itself (it only checks for `Waiting`), seat 1 listens, so relinking is one press in one window. A window that
     * closed is gone for good: the session ends and the chrome offers to invite somebody new.
     */
    protected peerGone(refusal: LinkRefusal): void;
    protected close(refusal: LinkRefusal): void;
    protected releaseMachines(): Promise<void>;
    dispose(leaving?: 'session' | 'window' | 'ended'): void;
}
//# sourceMappingURL=link-session.d.ts.map