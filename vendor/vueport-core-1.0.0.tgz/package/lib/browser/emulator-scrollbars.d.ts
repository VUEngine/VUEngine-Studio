import PerfectScrollbar from 'perfect-scrollbar';
import { Disposable } from '../common/emulator-events';
export declare const VUEPORT_SCROLL_MARKER = "vp-scroll";
/**
 * Perfect Scrollbar on every scrolling container, as on the dock's tab bar (see `TabBar`): same look on
 * every platform and no layout width, so content does not reflow once it grows tall enough to scroll.
 * It watches the tree, as the containers are elements React creates and throws away.
 * Two past traps: two scrollbars at once, as `.vp-panel` says `overflow: auto !important` to beat Lumino
 * (answered by a `.ps` rule in the scrollbars section of `emulator-widget.css`), and no horizontal scrolling
 * from Theia's `ReactWidget` using `suppressScrollX`, which the wide VSU and Memory tables cannot live with
 */
export declare class VueportScrollbars implements Disposable {
    protected readonly bars: Map<Element, PerfectScrollbar>;
    protected readonly watched: Map<Element, Set<Element>>;
    protected sizes: ResizeObserver | undefined;
    protected tree: MutationObserver | undefined;
    protected readonly stale: Set<Element>;
    protected frame: number | undefined;
    install(root: Element): void;
    protected scan(root: Element): void;
    protected attach(element: Element): void;
    protected scrolls(element: Element): boolean;
    protected detach(element: Element): void;
    /**
     * Watches the content too, as a panel with a fixed share of the dock does not resize when its content grows.
     * Catches what the tree observer cannot (an image loading, a font reflowing a table). Diffed against what is
     * already watched: `ResizeObserver.observe` on a watched element schedules another callback, and doing that
     * on every mutation forced a layout per keystroke and frame, enough to starve a WebView's main thread
     */
    protected observeContent(element: Element): void;
    protected onMutations(records: MutationRecord[]): void;
    protected schedule(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-scrollbars.d.ts.map