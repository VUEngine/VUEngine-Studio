import PerfectScrollbar from 'perfect-scrollbar';
import { Disposable } from '../common/emulator-events';
/**
 * What marks a container as one that scrolls its own content.
 *
 * Written on the element itself — in its `className`, or by `addClass` for the
 * dock's Lumino panels — rather than kept as a list of selectors here. A new
 * scrolling surface is then one word next to the element that scrolls, in the
 * same place as the CSS that makes it scroll, and nothing has to remember to
 * add it to a register somewhere else.
 *
 * Deliberately not `ps`: that is perfect-scrollbar's own class, which it adds
 * to a container once it has taken it over, so marking a container with it
 * would leave no way to tell the two apart.
 */
export declare const VUEPORT_SCROLL_MARKER = "vp-scroll";
/**
 * Perfect Scrollbar on every scrolling container in the interface.
 *
 * The dock's tab bar has had one since it was written (see `TabBar`)
 * and this is the same library and the same behavior everywhere else: the
 * native scrollbar hidden, a rail drawn over the content rather than taking a
 * strip of it, fading in on hover and while scrolling. What it buys is a
 * scrollbar that looks the same on every platform and costs no layout width —
 * a panel's content no longer reflows by ten pixels the moment it grows tall
 * enough to scroll.
 *
 * Attached from here rather than by each panel because the containers are not
 * the panels: they are elements React creates and throws away as its output
 * changes, and there is no one lifecycle to hang twenty scrollbars on. So this
 * watches the tree instead — a container that appears gets a scrollbar, one
 * that goes takes its scrollbar with it, and anything that changes inside one
 * makes it measure again.
 *
 * Two things went wrong the last time this library was pointed at the panels,
 * and both are settled here rather than left to be rediscovered:
 *
 * - Two scrollbars at once. Perfect Scrollbar pins its container to
 *   `overflow: hidden` and draws over it, which does nothing if the container's
 *   own CSS says `overflow: auto !important` — as `.vp-panel` does, to beat
 *   Lumino. The stylesheet answers that with a `.ps` rule of its own; see the
 *   scrollbars section of `emulator-widget.css`.
 * - No horizontal scrolling. That was Theia's `ReactWidget` attaching it with
 *   `suppressScrollX`, which the wide tables (VSU, Memory) cannot live with.
 *   Nothing is suppressed here; both axes scroll wherever the content is bigger
 *   than the box in that direction.
 */
export declare class VueportScrollbars implements Disposable {
    protected readonly bars: Map<Element, PerfectScrollbar>;
    /** What the size observer is already watching for each container: its own children, minus the rails. */
    protected readonly watched: Map<Element, Set<Element>>;
    /** Watches each container's own box and its content's, for a size that changed without the DOM doing. */
    protected sizes: ResizeObserver | undefined;
    /** Watches the whole tree, for containers arriving and leaving and for content changing inside one. */
    protected tree: MutationObserver | undefined;
    /** Containers whose measurements are stale, updated together on the next frame. */
    protected readonly stale: Set<Element>;
    protected frame: number | undefined;
    /**
     * Take over every container under `root`, now and as they come and go.
     *
     * Called once, with the document the application renders into: the dock's
     * panels, the strips beside the screen and the host's own windows are all
     * in the same document, and one observer over the lot is cheaper than one
     * per surface.
     */
    install(root: Element): void;
    /** Look through a freshly added subtree for containers to take over. */
    protected scan(root: Element): void;
    protected attach(element: Element): void;
    /**
     * Whether this container's CSS actually scrolls it, here.
     *
     * The mark says a container scrolls; the stylesheet says where. A few of
     * these only scroll under a particular parent — `.vp-detail` is a
     * scrolling column inside a split panel and an ordinary block anywhere
     * else — and the element carrying the mark cannot know which it is. Read
     * before the library touches it, since taking a container over is what
     * pins it to `overflow: hidden`, and pinning a box that was never meant to
     * be one would clip content its parent was going to scroll for it.
     */
    protected scrolls(element: Element): boolean;
    protected detach(element: Element): void;
    /**
     * Watch what a container holds, not only the container.
     *
     * A panel that is a fixed share of the dock does not change size when its
     * content grows — the content does, and that is what the scrollbar has to
     * be told about. Content that changes by DOM is caught by the tree
     * observer; this catches the rest, an image finishing loading or a font
     * arriving and reflowing a table.
     *
     * Written as a difference against what is already watched, and never as a
     * blind re-observe: `ResizeObserver.observe` delivers an observation for
     * an element it is already watching, so observing the same children again
     * is not a no-op — it schedules another callback, which marks the
     * container stale, which measures it again. Called on every mutation, as
     * this once was, that is a forced layout on every keystroke and every
     * frame the emulator paints, which is enough to starve a WebView of the
     * main thread entirely.
     */
    protected observeContent(element: Element): void;
    protected onMutations(records: MutationRecord[]): void;
    /**
     * Measure once a frame at most.
     *
     * A React render is a burst of mutations describing one new picture, and
     * `update` reads layout — doing it per record would lay the page out
     * dozens of times to answer a single change.
     */
    protected schedule(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-scrollbars.d.ts.map