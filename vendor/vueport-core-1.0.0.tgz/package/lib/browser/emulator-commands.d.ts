import { Command } from '../common/emulator-command';
import { EmulatorAction, EmulatorGamePadKeyCode } from './emulator-types';
export declare const EMULATOR_FOCUS_CONTEXT = "emulatorFocus";
export declare namespace EmulatorCommands {
    const INPUT_L_UP: Command;
    const INPUT_L_RIGHT: Command;
    const INPUT_L_DOWN: Command;
    const INPUT_L_LEFT: Command;
    const INPUT_START: Command;
    const INPUT_SELECT: Command;
    const INPUT_L_TRIGGER: Command;
    const INPUT_R_UP: Command;
    const INPUT_R_RIGHT: Command;
    const INPUT_R_DOWN: Command;
    const INPUT_R_LEFT: Command;
    const INPUT_B: Command;
    const INPUT_A: Command;
    const INPUT_R_TRIGGER: Command;
    const INPUT_SAVE_STATE: Command;
    const INPUT_LOAD_STATE: Command;
    const INPUT_TOGGLE_FAST_FORWARD: Command;
    const INPUT_PAUSE_TOGGLE: Command;
    const INPUT_TOGGLE_SLOWMOTION: Command;
    const INPUT_TOGGLE_LOW_POWER: Command;
    const INPUT_REWIND: Command;
    const INPUT_FRAME_ADVANCE: Command;
    const INPUT_RESET: Command;
    const INPUT_AUDIO_MUTE: Command;
    const INPUT_FULLSCREEN: Command;
    const INPUT_TOGGLE_CONTROLS_OVERLAY: Command;
    const INPUT_SCREENSHOT: Command;
    const INPUT_VIDEO_RECORD: Command;
    const ADD_PANEL: Command;
    const RESET_LAYOUT: Command;
    const PLAY_MOVIE: Command;
    const STOP_MOVIE: Command;
    const PROFILE_START: Command;
    const PROFILE_STOP: Command;
    const LINK_SECOND_PLAYER: Command;
    const UNLINK_PLAYERS: Command;
    const INSPECT_OTHER_PLAYER: Command;
    const INSPECT_OWN_PLAYER: Command;
    const RELINK_PLAYERS: Command;
    const TOGGLE_CHEATS: Command;
    const TOGGLE_MACROS: Command;
    const TOGGLE_PATCHES: Command;
    const TOGGLE_SAVE_STATES: Command;
    const TOGGLE_ACHIEVEMENTS: Command;
    const TOGGLE_VBC_SUPPORT: Command;
    const SET_HARDWARE_MODE: Command;
    const SET_SAVE_SLOT: Command;
    const TOGGLE_DEBUG_MODE: Command;
    const EXPORT_SAVE: Command;
    const IMPORT_SAVE: Command;
    const EXPORT_SAVE_STATE: Command;
    const IMPORT_SAVE_STATE: Command;
    /**
     * Erases the cartridge save in the slot being played (only that one) and restarts on the empty one.
     * Deliberately not an action command, no key mapping or toolbar button, as it throws away progress: the palette is
     * its only surface, the confirmation dialog the rest of its safety. The id stays `emulator.deleteSram` though the
     * label no longer says SRAM, as hosts' key bindings and menus are written against it.
     */
    const DELETE_SRAM: Command;
}
export type EmulatorGamePadButton = 'lUp' | 'lRight' | 'lDown' | 'lLeft' | 'rUp' | 'rRight' | 'rDown' | 'rLeft' | 'a' | 'b' | 'start' | 'select' | 'lTrigger' | 'rTrigger';
export interface EmulatorGamePadInput {
    key: EmulatorGamePadKeyCode;
    command: Command;
    player2: Command;
}
export declare const EMULATOR_GAMEPAD_INPUTS: Record<EmulatorGamePadButton, EmulatorGamePadInput>;
export declare const EMULATOR_GAMEPAD_BUTTONS: EmulatorGamePadButton[];
export declare function emulatorGamePadCommand(button: EmulatorGamePadButton, player: number): Command;
export declare const EMULATOR_TURBO_BUTTONS: readonly EmulatorGamePadButton[];
export declare function emulatorTurboCommand(button: EmulatorGamePadButton, player: number): Command;
export declare const EMULATOR_MACRO_SLOT_COUNT = 8;
export declare const EMULATOR_MACRO_SLOTS: readonly number[];
export declare const EMULATOR_MACRO_SLOT_COMMANDS: readonly Command[];
export declare const EMULATOR_ACTION_COMMANDS: Record<EmulatorAction, Command>;
export declare const EMULATOR_ACTIONS: EmulatorAction[];
export declare function resetLayoutConfirmation(): {
    title: string;
    message: string;
    okLabel: string;
};
//# sourceMappingURL=emulator-commands.d.ts.map