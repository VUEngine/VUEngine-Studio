import { Command } from '../common/emulator-command';
import { EmulatorAction, EmulatorGamePadKeyCode } from './emulator-types';
/**
 * The `when` clause every emulator input mapping is scoped to.
 *
 * Deliberately never true — the widget reads key presses itself so that it can
 * see releases as well, and a mapping that actually fired through the host's
 * dispatcher would only give it the press.
 */
export declare const EMULATOR_FOCUS_CONTEXT = "emulatorFocus";
export declare namespace EmulatorCommands {
    const INPUT_L_UP: Command;
    const INPUT_L_RIGHT: Command;
    const INPUT_L_DOWN: Command;
    const INPUT_L_LEFT: Command;
    const INPUT_START: Command;
    const INPUT_SELECT: Command;
    const INPUT_L_TRIGGER: Command;
    const INPUT_R_UP: Command;
    const INPUT_R_RIGHT: Command;
    const INPUT_R_DOWN: Command;
    const INPUT_R_LEFT: Command;
    const INPUT_B: Command;
    const INPUT_A: Command;
    const INPUT_R_TRIGGER: Command;
    const INPUT_SAVE_STATE: Command;
    /**
     * Put the game back to the newest state somebody made.
     *
     * Named for what it does now that there are no slots: there is no state
     * *selected* to load, so the key takes the last one — choosing among them is
     * what the browser beside the screen is for.
     */
    const INPUT_LOAD_STATE: Command;
    const INPUT_TOGGLE_FAST_FORWARD: Command;
    const INPUT_PAUSE_TOGGLE: Command;
    const INPUT_TOGGLE_SLOWMOTION: Command;
    const INPUT_TOGGLE_LOW_POWER: Command;
    const INPUT_REWIND: Command;
    const INPUT_FRAME_ADVANCE: Command;
    const INPUT_RESET: Command;
    const INPUT_AUDIO_MUTE: Command;
    const INPUT_FULLSCREEN: Command;
    /**
     * Opens the input settings — where the mappings are, and where the overlay
     * of the controller that names them is drawn.
     *
     * A new key rather than the old `toggleControlsOverlayCommand`: what it says
     * has changed, not just how it is worded, and a translation of the old
     * sentence would be a wrong answer rather than a stale one.
     */
    const INPUT_TOGGLE_CONTROLS_OVERLAY: Command;
    const INPUT_SCREENSHOT: Command;
    /**
     * Starts a recording, and stops the one that is running — one command
     * rather than two, unlike profiling, because this is a thing somebody does
     * while playing and reaches for by the same key both times.
     */
    const INPUT_VIDEO_RECORD: Command;
    const ADD_PANEL: Command;
    const RESET_LAYOUT: Command;
    /**
     * Profiling, as two commands rather than one toggle.
     *
     * Which of the two applies is decided by whether a recording is running, and
     * only that one is offered — a palette entry meaning opposite things at
     * different times is worse than two that each say what they do.
     */
    const PLAY_MOVIE: Command;
    const STOP_MOVIE: Command;
    const PROFILE_START: Command;
    const PROFILE_STOP: Command;
    const LINK_SECOND_PLAYER: Command;
    const UNLINK_PLAYERS: Command;
    /**
     * Point the debugger at the other player's machine, or back at this one.
     *
     * This window runs both — see `emulator-core-service.ts` — so what the
     * inspectors show of the other player's is what their own debugger would
     * show, frame for frame, and a poke aimed at it lands in both windows.
     */
    const INSPECT_OTHER_PLAYER: Command;
    const INSPECT_OWN_PLAYER: Command;
    const RELINK_PLAYERS: Command;
    /**
     * Showing the cheats beside the screen.
     *
     * Not one of the panels: the cheats are not docked in either mode, so this
     * is not "open the Cheats panel" but "show them there".
     */
    const TOGGLE_CHEATS: Command;
    /**
     * Showing the macros beside the screen.
     *
     * The macros' counterpart of TOGGLE_CHEATS, and there for the same reason:
     * they are not docked in either mode, so this is not "open the Macros
     * panel" but "show them there".
     */
    const TOGGLE_MACROS: Command;
    /** Show the VB Color editor beside the screen. */
    const TOGGLE_COLORS: Command;
    const TOGGLE_PATCHES: Command;
    /**
     * Showing the save-state browser beside the screen.
     *
     * The cheats' arrangement exactly — see TOGGLE_CHEATS — and the control that
     * replaced the slot number in the transport: with every save making a new
     * state, the list of them is the thing worth a button.
     */
    const TOGGLE_SAVE_STATES: Command;
    /**
     * Showing the RetroAchievements list beside the screen.
     *
     * TOGGLE_CHEATS' and TOGGLE_MACROS' counterpart, and there for the same
     * reason: it is not docked in either mode. Only one of the five strips is
     * open at a time.
     */
    const TOGGLE_ACHIEVEMENTS: Command;
    /** Enable or completely suppress VB Color hardware support. */
    const TOGGLE_VBC_SUPPORT: Command;
    /** Choose which physical Virtual Boy model the core should emulate. */
    const SET_HARDWARE_MODE: Command;
    /**
     * Choose which save file the game plays on.
     *
     * A slot rather than a state: see `EMULATOR_SAVE_SLOTS`. Named "Save Game"
     * because that is what it holds — the game's own saved progress — and
     * because "save slot" on its own reads as the save *state* slot beside it.
     */
    const SET_SAVE_SLOT: Command;
    /** Switching between Play mode and Debug mode. */
    const TOGGLE_DEBUG_MODE: Command;
    /**
     * Taking saved progress out of the application, and putting it back.
     *
     * A browser keeps cartridge RAM and save states where the person cannot
     * reach them — the origin-private file system, which has no path they could
     * type and which a cleared site goes away with. Progress somebody spent
     * hours on should not be hostage to that, and a save they made on one
     * machine should be playable on another.
     */
    const EXPORT_SAVE: Command;
    const IMPORT_SAVE: Command;
    /**
     * The newest state somebody made, as a file they keep.
     *
     * One state rather than a chosen one, because choosing is what the browser
     * beside the screen is for — and every state in it has an Export of its own.
     * This is the command-palette shortcut for "the one I just made".
     */
    const EXPORT_SAVE_STATE: Command;
    const IMPORT_SAVE_STATE: Command;
    /**
     * Erase the cartridge save in the slot being played, and restart on the
     * empty one. Only that slot: the other twenty-five are somebody else's
     * playthrough and are left alone.
     *
     * Not one of the action commands: it has no key mapping and no toolbar
     * button, because it throws away saved progress and wants to be reached
     * deliberately rather than by a stray click. The palette is the whole of its
     * surface; the confirmation dialog is the rest of its safety.
     *
     * The id stays `emulator.deleteSram` though the label no longer says SRAM:
     * a command id is what a host's key bindings and menus are written against,
     * and renaming it would break them for the sake of a word nobody sees.
     */
    const DELETE_SRAM: Command;
}
/**
 * The controller's own buttons, as the emulator's state and its on-screen
 * reference both name them.
 */
export type EmulatorGamePadButton = 'lUp' | 'lRight' | 'lDown' | 'lLeft' | 'rUp' | 'rRight' | 'rDown' | 'rLeft' | 'a' | 'b' | 'start' | 'select' | 'lTrigger' | 'rTrigger';
export interface EmulatorGamePadInput {
    /** What the emulator presses when one of the mapped keys is. */
    key: EmulatorGamePadKeyCode;
    /** The command the mapping hangs off, per player. */
    command: Command;
    player2: Command;
}
/**
 * Every game pad button, with the commands that carry its key mappings.
 *
 * The order is the one the on-screen reference reads in, top to bottom of the
 * left half and then the right.
 */
export declare const EMULATOR_GAMEPAD_INPUTS: Record<EmulatorGamePadButton, EmulatorGamePadInput>;
export declare const EMULATOR_GAMEPAD_BUTTONS: EmulatorGamePadButton[];
/** The command a button's mapping hangs off, for one player. */
export declare function emulatorGamePadCommand(button: EmulatorGamePadButton, player: number): Command;
/**
 * The emulator's actions, and the commands they are invoked through.
 *
 * Everything that acts on a running emulator goes through one of these,
 * whether it came from the toolbar, the command palette, or a key. The key
 * mappings still reach the widget directly rather than through Theia's
 * dispatcher — see `EMULATOR_FOCUS_CONTEXT`, which is deliberately never true
 * so that the widget can see key releases as well as presses — but they now
 * end up in the same place everything else does.
 *
 * Keyed by the action, which is the emulator's own name for what it does; the
 * keys it answers to are whatever the keybinding registry says, and the
 * defaults for those live in `registerKeybindings`.
 */
export declare const EMULATOR_ACTION_COMMANDS: Record<EmulatorAction, Command>;
export declare const EMULATOR_ACTIONS: EmulatorAction[];
/**
 * What to ask before putting the panels back.
 *
 * Here rather than in either host: the question is about the emulator's own
 * layout, so both hosts should ask it in the same words and it should be
 * translated once. Built on call, not at import, because the host installs its
 * localization during start-up.
 */
export declare function resetLayoutConfirmation(): {
    title: string;
    message: string;
    okLabel: string;
};
//# sourceMappingURL=emulator-commands.d.ts.map