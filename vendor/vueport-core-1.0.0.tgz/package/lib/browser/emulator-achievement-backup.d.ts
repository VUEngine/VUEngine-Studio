/**
 * The shipped offline snapshot of every Virtual Boy achievement set.
 *
 * `RetroAchievementsService` falls back to this when the live site cannot be
 * reached — a browser build with no relay, the desktop build when the site is
 * down — so the Achievements panel can still show a game's set: its titles,
 * descriptions, points, badges and how rare each one is. It cannot show *your*
 * progress and it cannot unlock anything; that needs the real connection.
 *
 * The data is `packages/core/src/data/retroachievements-vb.json`, produced by
 * `packages/core/scripts/fetch-achievement-sets.mjs`. It is deliberately not
 * imported here: a host that wants the fallback loads that file itself (a
 * static asset fetched on demand) and hands it in through
 * {@link RetroAchievementsService.setBackupLoader}, so the ~40 KB never weighs
 * on a build or a session that does not need it.
 */
import { RaAchievement, RaGame } from '../common/vb-protocol';
/** One achievement in the snapshot, as the fetch script writes it (`--slim`). */
export interface AchievementBackupAchievement {
    id: number;
    title: string;
    description: string;
    points: number;
    /** RetroAchievements' own classification, absent for an ordinary achievement. */
    type?: 'progression' | 'win_condition' | 'missable' | string;
    displayOrder: number;
    /** The badge image id — `${RA_MEDIA}/Badge/${badgeName}.png`. */
    badgeName: string;
    numAwarded: number;
    numAwardedHardcore: number;
}
/** One game's set in the snapshot. */
export interface AchievementBackupGame {
    id: number;
    title: string;
    /** A site-relative path, e.g. `/Images/073200.png`. */
    imageIcon: string;
    developer?: string;
    publisher?: string;
    genre?: string;
    released?: string;
    /** Sum of the set's points, as the site reports it. */
    points: number;
    /** How many accounts have played the game at all — the denominator for rarity. */
    numDistinctPlayers: number;
    /** Every RetroAchievements ROM hash (whole-file MD5, lower-case) this set is for. */
    hashes: string[];
    achievements: AchievementBackupAchievement[];
}
/** The whole snapshot file. */
export interface AchievementBackup {
    source: string;
    console: {
        id: number;
        name: string;
    };
    /** ISO 8601, when the snapshot was taken. */
    generatedAt: string;
    slim: boolean;
    gameCount: number;
    achievementCount: number;
    games: AchievementBackupGame[];
}
/** Absolute URL for a game's icon. */
export declare function achievementBackupIconUrl(game: AchievementBackupGame): string;
/** The snapshot's game shape as the panel's {@link RaGame}. */
export declare function achievementBackupToRaGame(game: AchievementBackupGame): RaGame;
/**
 * The snapshot's achievements as the panel's {@link RaAchievement} list.
 *
 * Every one is `locked` with no unlock time: the snapshot carries the set, not
 * this account's progress. `rarity` is the site's own "how many players have
 * this" — `numAwarded` over the game's player count — so the sort and the
 * detail view still have something real to show.
 */
export declare function achievementBackupToRaList(game: AchievementBackupGame): RaAchievement[];
/** Index a snapshot by ROM hash, so a running ROM can be looked up in one step. */
export declare function achievementBackupByHash(backup: AchievementBackup): Map<string, AchievementBackupGame>;
//# sourceMappingURL=emulator-achievement-backup.d.ts.map