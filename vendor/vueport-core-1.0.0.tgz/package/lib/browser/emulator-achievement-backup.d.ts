/**
 * Shipped offline snapshot of every Virtual Boy achievement set, which RetroAchievementsService falls back
 * to when the site cannot be reached (browser without relay, site down): titles, descriptions, points,
 * badges and rarity, but no own progress and no unlocks. Data is packages/core/src/data/retroachievements-vb.json
 * from scripts/fetch-achievement-sets.mjs; not imported here, a host loads it on demand and hands it to
 * RetroAchievementsService.setBackupLoader, so the ~40 KB only weighs on sessions that need it
 */
import { RaAchievement, RaGame } from '../common/vb-protocol';
export interface AchievementBackupAchievement {
    id: number;
    title: string;
    description: string;
    points: number;
    type?: 'progression' | 'win_condition' | 'missable' | string;
    displayOrder: number;
    badgeName: string;
    numAwarded: number;
    numAwardedHardcore: number;
}
export interface AchievementBackupGame {
    id: number;
    title: string;
    imageIcon: string;
    developer?: string;
    publisher?: string;
    genre?: string;
    released?: string;
    points: number;
    numDistinctPlayers: number;
    hashes: string[];
    achievements: AchievementBackupAchievement[];
}
export interface AchievementBackup {
    source: string;
    console: {
        id: number;
        name: string;
    };
    generatedAt: string;
    slim: boolean;
    gameCount: number;
    achievementCount: number;
    games: AchievementBackupGame[];
}
export declare function achievementBackupIconUrl(game: AchievementBackupGame): string;
export declare function achievementBackupToRaGame(game: AchievementBackupGame): RaGame;
export declare function achievementBackupToRaList(game: AchievementBackupGame): RaAchievement[];
export declare function achievementBackupByHash(backup: AchievementBackup): Map<string, AchievementBackupGame>;
//# sourceMappingURL=emulator-achievement-backup.d.ts.map