/**
 * What is kept about playing in a headset between sittings — the screen's
 * size and depth, and what is around it — and how a click that may start one
 * is told apart. See `EmulatorXrController`.
 *
 * In the browser's own storage rather than among the settings: it is mostly
 * set from inside a headset, and it is the same for every host on a machine.
 */
import { XrBackdrop, XrScreen } from './emulator-xr';
export declare function loadXrScreen(): XrScreen;
export declare function saveXrScreen(screen: XrScreen): void;
/**
 * Whether the person has just done something the browser counts as asking —
 * a click, a key — which is what it grants a headset to. Browsers without the
 * User Activation API are given the benefit of the doubt: the worst a wrong
 * guess costs is a refusal, which the VR button in the title bar then makes up for.
 */
export declare function userActivationIsActive(): boolean;
/** Every choice of what is around the screen, in the order a menu goes round them. */
export declare const XR_BACKDROPS: readonly XrBackdrop[];
/** What a backdrop is called, in the headset's menu and in the settings pane alike. */
export declare function xrBackdropLabel(backdrop: XrBackdrop): string;
/** What was last wanted around the screen. */
export declare function loadXrBackdrop(): XrBackdrop;
export declare function saveXrBackdrop(backdrop: XrBackdrop): void;
/** The one after it, for a menu that goes round them. */
export declare function nextXrBackdrop(backdrop: XrBackdrop): XrBackdrop;
//# sourceMappingURL=emulator-xr-storage.d.ts.map