import { XrBackdrop, XrScreen } from './emulator-xr';
export declare function loadXrScreen(): XrScreen;
export declare function saveXrScreen(screen: XrScreen): void;
export declare function userActivationIsActive(): boolean;
export declare const XR_BACKDROPS: readonly XrBackdrop[];
export declare function xrBackdropLabel(backdrop: XrBackdrop): string;
export declare function loadXrBackdrop(): XrBackdrop;
export declare function saveXrBackdrop(backdrop: XrBackdrop): void;
export declare function nextXrBackdrop(backdrop: XrBackdrop): XrBackdrop;
//# sourceMappingURL=emulator-xr-storage.d.ts.map