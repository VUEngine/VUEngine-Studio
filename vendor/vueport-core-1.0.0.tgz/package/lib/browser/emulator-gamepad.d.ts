/**
 * Physical controller input.
 *
 * Reads connected gamepads through the Gamepad API and folds them into one
 * Virtual Boy key mask, through whatever profile each pad resolves to. What a
 * profile is, and why the mapping is per device rather than fixed, is in
 * `emulator-gamepad-profiles.ts`; this module is the part that touches the
 * browser.
 *
 * Which pads feed a machine is a separate question from what their buttons do.
 * Solo, every pad drives the same machine, so a second controller is a second
 * pair of hands. A linked pair asks for player 1 and 2, and then each side gets
 * the pads assigned to it — by the person, in the Game Pads settings, or by
 * connection order when they have not said.
 */
import { GamepadDatabase, GamepadProfile, GamepadUiAction, gamepadName } from '../common/emulator-gamepad-profiles';
import { EmulatorAction } from './emulator-types';
export { gamepadName };
/**
 * Read pads from here rather than from `navigator.getGamepads()`.
 *
 * Everything that reads a pad goes through {@link connectedGamepadList}, so
 * this is the one switch: the emulator's input, the settings, the rumble and
 * the interface steering all follow. A source also has to announce pads coming
 * and going the way the browser does, with `gamepadconnected` and
 * `gamepaddisconnected` on `window` — see {@link onGamepadsChanged}.
 */
export declare function setGamepadSource(source: (() => (Gamepad | null)[]) | undefined): void;
/** The connected pads, in the order the Gamepad API reports them. */
export declare function connectedGamepadList(): Gamepad[];
/**
 * How a caller says which pads feed the machine being driven, and what each
 * one's buttons do.
 *
 * An interface rather than two arguments because both answers come from the
 * same settings and change at the same time — a pad being assigned to player 2
 * and a pad's mapping being edited are both "the input settings changed".
 */
export interface GamepadProfileResolver {
    /** The mapping in force for one pad. */
    profileFor(pad: Gamepad): GamepadProfile;
    /**
     * Whether this pad drives the machine asking.
     *
     * `player` is what the host asked for: 1 or 2 for a linked session, and
     * undefined for a solo one, where every pad counts.
     */
    drivesPlayer(pad: Gamepad, player: number | undefined): boolean;
}
/** What every connected pad is contributing this frame. */
export interface GamepadFrame {
    /** The Virtual Boy key mask, every driving pad folded together. */
    keys: number;
    /** Emulator actions whose bound control is held on any driving pad. */
    actions: Set<EmulatorAction>;
    /** The host's own actions held on any driving pad — see `GamepadUiAction`. */
    uiActions: Set<GamepadUiAction>;
}
/**
 * Read every pad that drives this machine, through its own profile.
 *
 * One pass for both the mask and the actions, because they come off the same
 * reading and this runs once per animation frame: two passes would poll the
 * pads twice for no gain.
 */
export declare function readGamepadFrame(resolver: GamepadProfileResolver, player?: number): GamepadFrame;
/**
 * Which controls are held on one pad right now, as source ids.
 *
 * What the Game Pads settings read: to notice the button somebody just pressed
 * while a mapping is being recorded, and to light the picture up while a
 * mapped control is held, which is how a person checks a mapping is right
 * without starting a game.
 *
 * `hats` is which of the pad's axes are hat switches; keep it across calls and
 * this fills it in (see `pressedGamepadSources`).
 */
export declare function readPressedSources(pad: Gamepad, deadZone: number, hats?: Set<number>): Set<string>;
/**
 * The controllers the page can see, by the name the browser gives them.
 *
 * A caveat worth knowing before showing this to anyone: a pad that is plugged
 * in but has not been touched does not exist as far as a page is concerned.
 * The Gamepad API withholds it until a button is pressed, deliberately — the
 * list of devices attached to a machine is a fingerprint. So "nothing
 * connected" here means "nothing has been used", which is the honest thing for
 * a readout to say and the reason this one is worded the way it is.
 */
export declare function connectedGamepads(): string[];
/**
 * Fires when a controller is plugged in or unplugged. Returns the unsubscribe.
 *
 * Events rather than polling: the emulator already reads the pads every frame
 * for their buttons, but a profile only has to be resolved again when the set
 * of pads changes, and that happens twice an hour rather than sixty times a
 * second.
 */
export declare function onGamepadsChanged(listener: () => void): () => void;
/**
 * A resolver over stored profiles and stored player assignments.
 *
 * The one implementation both the emulator and the settings page use, so that
 * what the settings show a pad doing is what the game will do with it.
 *
 * Assignment is by device, which means two pads of the same model share an
 * assignment — there is nothing in a browser's id to tell them apart. Ties are
 * broken by connection order, so a pair of identical pads still lands one on
 * each player rather than both on the same one.
 */
export declare class StoredGamepadProfiles implements GamepadProfileResolver {
    protected stored: () => GamepadProfile[];
    /** Which player a device drives, by device key. Absent means either. */
    protected players: () => Record<string, number>;
    protected database?: (() => GamepadDatabase | undefined) | undefined;
    /** Resolved profiles, by device key, rebuilt when the settings change. */
    protected cache: Map<string, GamepadProfile>;
    constructor(stored: () => GamepadProfile[], 
    /** Which player a device drives, by device key. Absent means either. */
    players: () => Record<string, number>, database?: (() => GamepadDatabase | undefined) | undefined);
    /** Drop the cache, so the next frame resolves against the new settings. */
    invalidate(): void;
    profileFor(pad: Gamepad): GamepadProfile;
    drivesPlayer(pad: Gamepad, player: number | undefined): boolean;
}
//# sourceMappingURL=emulator-gamepad.d.ts.map