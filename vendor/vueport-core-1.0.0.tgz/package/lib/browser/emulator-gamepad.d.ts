/**
 * Physical controller input: reads pads through the Gamepad API and folds them into one VB key mask through each
 * pad's profile (see emulator-gamepad-profiles.ts for why mapping is per device). Solo, every pad drives the same
 * machine. A linked pair asks for player 1 or 2, and each side gets the pads assigned to it in the Game Pads
 * settings, or by connection order.
 */
import { GamepadDatabase, GamepadProfile, GamepadUiAction, gamepadName } from '../common/emulator-gamepad-profiles';
import { EmulatorAction } from './emulator-types';
export { gamepadName };
export declare function setGamepadSource(source: (() => (Gamepad | null)[]) | undefined): void;
export declare function connectedGamepadList(): Gamepad[];
export interface GamepadProfileResolver {
    profileFor(pad: Gamepad): GamepadProfile;
    drivesPlayer(pad: Gamepad, player: number | undefined): boolean;
}
export interface GamepadFrame {
    keys: number;
    actions: Set<EmulatorAction>;
    uiActions: Set<GamepadUiAction>;
    turboKeys: number;
    macroSlots: Set<number>;
}
export declare function readGamepadFrame(resolver: GamepadProfileResolver, player?: number): GamepadFrame;
export declare function readPressedSources(pad: Gamepad, deadZone: number, hats?: Set<number>): Set<string>;
export declare function connectedGamepads(): string[];
export declare function onGamepadsChanged(listener: () => void): () => void;
export declare class StoredGamepadProfiles implements GamepadProfileResolver {
    protected stored: () => GamepadProfile[];
    protected players: () => Record<string, number>;
    protected database?: (() => GamepadDatabase | undefined) | undefined;
    protected cache: Map<string, GamepadProfile>;
    constructor(stored: () => GamepadProfile[], players: () => Record<string, number>, database?: (() => GamepadDatabase | undefined) | undefined);
    invalidate(): void;
    profileFor(pad: Gamepad): GamepadProfile;
    drivesPlayer(pad: Gamepad, player: number | undefined): boolean;
}
//# sourceMappingURL=emulator-gamepad.d.ts.map