import { Emitter, Event } from '../common/emulator-events';
import { DisplayMode } from '../common/vb-constants';
import { Frame } from '../common/vb-protocol';
import { Core, Sim } from './core/vb-core';
import { EsSoundPlayer } from './emulator-essound-player';
import { VbRenderer } from '../worker/vb-renderer';
/** Bit rates the quality names stand for, for a picture this size. */
export declare const VIDEO_BIT_RATES: Record<VideoQuality, number>;
export declare const AUDIO_BIT_RATE = 128000;
/**
 * Sample rates an AAC encoder will take.
 *
 * AAC carries its rate as an index into a table rather than as a number, so
 * this is not a quality threshold a browser may choose to be generous about:
 * a rate that is not in the table cannot be written down, and the encoder can
 * only refuse. The machine's own 41700 Hz is not in it, and neither — for
 * Chrome's encoder, whatever the table says — is 32000.
 */
export declare const AAC_SAMPLE_RATES: number[];
/**
 * What a recording's audio is resampled to when it has to be.
 *
 * 48 kHz because it is what the hardware is almost always running at anyway,
 * and what Opus works in internally whatever it is given — so this is rarely
 * an extra conversion, more often the one that was going to happen regardless,
 * done somewhere we can see it.
 */
export declare const RECORDING_SAMPLE_RATE = 48000;
/**
 * The rate a recording's audio has to be resampled to, or undefined for a
 * context already running at one an encoder will take.
 */
export declare function bridgeSampleRateFor(rate: number): number | undefined;
export type VideoQuality = 'low' | 'medium' | 'high';
/**
 * Which container to prefer. A preference and not a promise: what a browser
 * can encode is the browser's business, so the other container is still used
 * rather than refusing to record.
 */
export type VideoFormat = 'auto' | 'webm' | 'mp4';
/** A stored setting read back as one of the three, defaulting to automatic. */
export declare function videoFormatOf(value: string | undefined): VideoFormat;
/** A stored setting read back as one of the three, defaulting in the middle. */
export declare function videoQualityOf(value: string | undefined): VideoQuality;
export interface VideoRecorderOptions {
    core: Core;
    sim: Sim;
    /**
     * ESSound's playback, mixed in when the running ROM has any.
     *
     * Left out for a ROM with no tracks beside it: opening the tap builds the
     * player's audio context, and there is no reason to build one for silence.
     */
    esSound?: EsSoundPlayer;
    /** How the frames are composed — need not be the mode being played in. */
    mode: DisplayMode;
    /** Whole-number multiple of the mode's own size to record at. */
    scale?: number;
    /** One of {@link VideoQuality}; anything else is read as the middle one. */
    quality?: string;
    /** One of {@link VideoFormat}; anything else is read as automatic. */
    format?: string;
}
/** A finished recording, ready to be handed to whoever asked for it. */
export interface VideoRecording {
    blob: Blob;
    /** `webm` or `mp4`, whichever the browser could encode. */
    extension: string;
    /** How many of the machine's frames went in. */
    frames: number;
    /** How long it runs, in seconds, pauses excluded. */
    seconds: number;
    /** The container and codecs it was actually encoded with. */
    mimeType: string;
    /** Why the encoder gave up, for a recording that ended by itself. */
    failure?: string;
}
export declare class VideoRecorder {
    /**
     * Every container and codec set this browser says it can encode, in the
     * order they should be tried for the requested format.
     *
     * The preferred container comes first and the other one after it, because
     * a file in the container somebody did not ask for is a better answer than
     * no recording at all — Safari has no WebM encoder and Firefox no MP4 one,
     * and neither of those should mean a button that does nothing.
     *
     * Bear in mind that this list is what a browser says it can mux, which is
     * not what it can encode; see the note on sample rates at the top of this
     * file for how far apart those two answers can be.
     */
    static mimeTypes(format?: string): string[];
    /** The first of those, or undefined for a browser that will encode none. */
    static mimeType(format?: string): string | undefined;
    /**
     * Whether this browser can record at all.
     *
     * Three things have to be there, and a WebKitGTK build of the desktop
     * wrapper is the case where they are not: the encoder, a canvas that can
     * be captured, and a canvas track that takes its frames when it is told
     * to rather than on a clock of its own.
     */
    static isSupported(): boolean;
    /**
     * Start recording. Resolves once the encoder is running.
     *
     * The mode is settled here and held for the life of the recording: the
     * stereo layouts present at different geometries, and a stream whose
     * frames change size halfway through is not a file most players will open.
     */
    static start(options: VideoRecorderOptions): Promise<VideoRecorder>;
    protected readonly core: Core;
    protected readonly sim: Sim;
    protected readonly esSound: EsSoundPlayer | undefined;
    protected readonly mode: DisplayMode;
    protected readonly scale: number;
    protected readonly quality: VideoQuality;
    /**
     * The containers still worth trying, current one first.
     *
     * Shrinks rather than being indexed into: a candidate that has failed is
     * gone, so nothing can go back round to it.
     */
    protected candidates: string[];
    /** Where the frames are composed, and where they are captured from. */
    protected canvas: HTMLCanvasElement | undefined;
    protected renderer: VbRenderer | undefined;
    protected output: HTMLCanvasElement | undefined;
    protected outputContext: CanvasRenderingContext2D | undefined;
    protected track: CanvasCaptureMediaStreamTrack | undefined;
    protected mix: MediaStreamAudioDestinationNode | undefined;
    protected esSoundSource: MediaStreamAudioSourceNode | undefined;
    /** The context the mix is resampled in, where it has to be. */
    protected bridge: AudioContext | undefined;
    protected bridgeSource: MediaStreamAudioSourceNode | undefined;
    protected recorder: MediaRecorder | undefined;
    protected chunks: Blob[];
    /** The stream both encoders are fed from; it outlives any one of them. */
    protected stream: MediaStream | undefined;
    /** Why the encoder gave up, once none of the candidates has worked. */
    protected failure: string | undefined;
    protected readonly onDidFailEmitter: Emitter<string>;
    /**
     * The encoder gave up and the recording has ended itself.
     *
     * Nothing else says so: a `MediaRecorder` that fails stops on the spot,
     * and a host that was not listening would go on showing a record light
     * over a machine nobody is recording. Whatever was encoded before the
     * failure is still there to be saved — see {@link VideoRecorder.stop}.
     */
    readonly onDidFail: Event<string>;
    protected frames: number;
    /** Wall-clock milliseconds spent recording, pauses excluded. */
    protected elapsed: number;
    protected since: number;
    protected paused: boolean;
    protected stopped: boolean;
    protected constructor(options: VideoRecorderOptions, candidates: string[]);
    /** What this recording is being encoded as, which a failure can change. */
    get mimeType(): string;
    /** How long it has been running, in seconds, for a badge to count up. */
    get seconds(): number;
    get frameCount(): number;
    get isRecording(): boolean;
    /** What the file will be called at the end, without its stem. */
    get extension(): string;
    /**
     * Build everything the recording needs, and start it.
     *
     * Every failure on the way in releases what was built first. Without that
     * a recording that could not be started would leave the machine mirroring
     * its frames to a handler that no longer exists — invisible, and paid for
     * on every frame until the ROM is closed.
     */
    protected begin(): Promise<void>;
    protected build(): Promise<void>;
    /**
     * Put an encoder on the stream and start it, using the current candidate.
     *
     * Separate from everything else the recording holds, because this is the
     * one part that may have to be built twice: a `MediaRecorder` that fails
     * stops for good, so trying the next candidate means a new one — on the
     * same canvas, the same tap and the same audio mix, all of which carry on
     * undisturbed through the swap.
     */
    protected startEncoder(): void;
    /**
     * The encoder raised an error. Try the next candidate, or give up.
     *
     * Trying the next one is only right while nothing has been encoded yet:
     * that is the failure this exists for — a browser that accepts a container
     * it has no encoder for and says so on the first frame — and it costs a
     * fraction of a second of the recording. Once bytes have been written they
     * are a file in one particular container, and starting a second encoder
     * would be starting a second file, so a later failure ends the recording
     * instead and keeps what there is.
     */
    protected encoderFailed(name: string | undefined): void;
    /**
     * Both sources, mixed into the one track a recording can carry.
     *
     * In the core's own audio context, which is where the machine's sound
     * already is: taking it out through a `MediaStream` as well would put a
     * resampling bridge in front of the one thing that must not glitch.
     * ESSound is on the other side of such a bridge because it has no choice —
     * it plays media elements in a context of its own.
     */
    protected openAudio(): Promise<MediaStreamTrack[]>;
    /**
     * The mix at a rate an encoder will take.
     *
     * The machine runs its audio at 41700 Hz and the recording is the one
     * place that cannot follow it there, because AAC has no such rate: handed
     * the mix as it is, Chrome fails the whole `avc1,mp4a.40.2` container on
     * the first frame and the recording falls back to AV1 and Opus. So the
     * mix is carried through a second context running at a rate AAC knows,
     * and a `MediaStream` is what carries it, since that is the only way
     * audio crosses between contexts.
     *
     * The resampling the header warns about is real but lands where it can be
     * afforded: behind the tap, so playback never goes through it, and in a
     * conversion the hardware was going to perform anyway a moment later.
     *
     * A context that cannot be built is not a reason to refuse to record. The
     * unbridged mix is returned instead, and the recording ends up in the
     * container that will have it — which is what would have happened before
     * any of this existed.
     */
    protected resampled(stream: MediaStream): Promise<MediaStream>;
    /** Let go of the second context, which the browser will not collect. */
    protected closeBridge(): void;
    /**
     * One frame of the machine, composed and handed to the encoder.
     *
     * Synchronous throughout: the buffer goes straight back to the worker when
     * this returns, so the upload to the texture has to have happened by then.
     */
    protected present(frame: Frame): void;
    /**
     * Hold the recording while the machine is not running.
     *
     * A paused emulator presents nothing and its audio context is suspended,
     * so a recorder left running would write a silent still for as long as the
     * pause lasted. Held instead, the file carries on where the game does.
     */
    setPaused(paused: boolean): void;
    /**
     * Stop, and hand back what was recorded.
     *
     * The tap is closed first so that no frame arrives after the encoder has
     * been told there are no more, and the encoder's last chunk is waited for
     * — a file assembled before `onstop` is a file missing its end.
     */
    stop(): Promise<VideoRecording>;
    /** Give up on a recording without assembling it — a ROM being closed. */
    cancel(): Promise<void>;
    /** Everything this holds that the browser will not collect by itself. */
    protected release(): void;
}
//# sourceMappingURL=emulator-video-recorder.d.ts.map