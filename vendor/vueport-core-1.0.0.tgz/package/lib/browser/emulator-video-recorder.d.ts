import { Emitter, Event } from '../common/emulator-events';
import { DisplayMode } from '../common/vb-constants';
import { Frame } from '../common/vb-protocol';
import { Core, Sim } from './core/vb-core';
import { EsSoundPlayer } from './emulator-essound-player';
import { VbRenderer } from '../worker/vb-renderer';
export declare const VIDEO_BIT_RATES: Record<VideoQuality, number>;
export declare const AUDIO_BIT_RATE = 128000;
export declare const AAC_SAMPLE_RATES: number[];
export declare const RECORDING_SAMPLE_RATE = 48000;
export declare function bridgeSampleRateFor(rate: number): number | undefined;
export type VideoQuality = 'low' | 'medium' | 'high';
export type VideoFormat = 'auto' | 'webm' | 'mp4';
export declare function videoFormatOf(value: string | undefined): VideoFormat;
export declare function videoQualityOf(value: string | undefined): VideoQuality;
export interface VideoRecorderOptions {
    core: Core;
    sim: Sim;
    esSound?: EsSoundPlayer;
    mode: DisplayMode;
    scale?: number;
    quality?: string;
    format?: string;
}
export interface VideoRecording {
    blob: Blob;
    extension: string;
    frames: number;
    seconds: number;
    mimeType: string;
    failure?: string;
}
export declare class VideoRecorder {
    static mimeTypes(format?: string): string[];
    static mimeType(format?: string): string | undefined;
    static isSupported(): boolean;
    static start(options: VideoRecorderOptions): Promise<VideoRecorder>;
    protected readonly core: Core;
    protected readonly sim: Sim;
    protected readonly esSound: EsSoundPlayer | undefined;
    protected readonly mode: DisplayMode;
    protected readonly scale: number;
    protected readonly quality: VideoQuality;
    protected candidates: string[];
    protected canvas: HTMLCanvasElement | undefined;
    protected renderer: VbRenderer | undefined;
    protected output: HTMLCanvasElement | undefined;
    protected outputContext: CanvasRenderingContext2D | undefined;
    protected track: CanvasCaptureMediaStreamTrack | undefined;
    protected mix: MediaStreamAudioDestinationNode | undefined;
    protected esSoundSource: MediaStreamAudioSourceNode | undefined;
    protected bridge: AudioContext | undefined;
    protected bridgeSource: MediaStreamAudioSourceNode | undefined;
    protected recorder: MediaRecorder | undefined;
    protected chunks: Blob[];
    protected stream: MediaStream | undefined;
    protected failure: string | undefined;
    protected readonly onDidFailEmitter: Emitter<string>;
    readonly onDidFail: Event<string>;
    protected frames: number;
    protected elapsed: number;
    protected since: number;
    protected paused: boolean;
    protected stopped: boolean;
    protected constructor(options: VideoRecorderOptions, candidates: string[]);
    get mimeType(): string;
    get seconds(): number;
    get frameCount(): number;
    get isRecording(): boolean;
    get extension(): string;
    protected begin(): Promise<void>;
    protected build(): Promise<void>;
    protected startEncoder(): void;
    /**
     * Tries the next candidate only while nothing has been encoded yet (a browser accepting a container it has no encoder
     * for fails on the first frame). Once bytes were written they are a file in one container, so a later failure ends the
     * recording and keeps what there is.
     */
    protected encoderFailed(name: string | undefined): void;
    protected openAudio(): Promise<MediaStreamTrack[]>;
    /**
     * The mix at a rate an encoder will take. Handed 41700 Hz, Chrome fails the whole `avc1,mp4a.40.2` container on the
     * first frame and the recording falls back to AV1 and Opus. So the mix is carried through a second context at a rate
     * AAC knows, via a MediaStream, the only way audio crosses contexts; behind the tap, so playback never goes through it.
     * A context that cannot be built returns the unbridged mix, and the recording ends up in whichever container takes it.
     */
    protected resampled(stream: MediaStream): Promise<MediaStream>;
    protected closeBridge(): void;
    protected present(frame: Frame): void;
    setPaused(paused: boolean): void;
    stop(): Promise<VideoRecording>;
    cancel(): Promise<void>;
    protected release(): void;
}
//# sourceMappingURL=emulator-video-recorder.d.ts.map