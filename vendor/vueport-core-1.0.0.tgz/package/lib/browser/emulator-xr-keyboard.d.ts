export declare const XR_KEYBOARD_PIXELS: {
    width: number;
    height: number;
};
type KeyAction = {
    kind: 'text';
    text: string;
} | {
    kind: 'backspace';
} | {
    kind: 'enter';
} | {
    kind: 'shift';
} | {
    kind: 'symbols';
} | {
    kind: 'left';
} | {
    kind: 'right';
} | {
    kind: 'close';
};
interface Key {
    label: string;
    action: KeyAction;
    width: number;
}
interface PlacedKey extends Key {
    x: number;
    y: number;
    w: number;
    h: number;
}
export declare class XrKeyboard {
    protected shift: boolean;
    protected symbols: boolean;
    protected placed: PlacedKey[];
    hovered: number | undefined;
    protected down: number | undefined;
    protected rows(): Key[][];
    draw(canvas: HTMLCanvasElement): void;
    keyAt(x: number, y: number): number | undefined;
    hover(index: number | undefined): boolean;
    press(): void;
    release(): void;
    protected act(action: KeyAction): void;
}
export {};
//# sourceMappingURL=emulator-xr-keyboard.d.ts.map