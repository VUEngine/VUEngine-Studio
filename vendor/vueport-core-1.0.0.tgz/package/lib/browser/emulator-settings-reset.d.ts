import { VueportConfig, VueportSettings } from '../common/emulator-settings';
export declare function modifiedSettings(settings: VueportSettings, keys: readonly (keyof VueportConfig)[]): (keyof VueportConfig)[];
export declare function resetSettings(settings: VueportSettings, keys: readonly (keyof VueportConfig)[]): Promise<void>;
export declare function resetAllSettingsConfirmation(): {
    title: string;
    message: string;
    okLabel: string;
};
//# sourceMappingURL=emulator-settings-reset.d.ts.map