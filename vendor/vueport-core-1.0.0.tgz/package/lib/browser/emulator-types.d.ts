import { VbAnaglyphMatrices, VbAnaglyphPalette, VbDuboisProfileSelection, VbPalette, VbRenderingMode } from '../common/vb-constants';
import { EmulatorResumeStart } from '../common/emulator-save-state';
import { EmulatorCompanionLocation, EmulatorSramInit, EmulatorSramWindow } from '../common/emulator-sram';
export declare enum VbLinkStatus {
    idle = 0,
    connect = 1,
    initiate = 2,
    transfer = 3
}
export interface VbLinkStatusData {
    status: VbLinkStatus;
    done: number;
    data?: Buffer;
}
/** Which physical console model VUEPort should emulate. */
export declare enum VbHardwareMode {
    AUTO = "auto",
    VIRTUAL_BOY = "vb",
    VB_COLOR = "vbc"
}
/** VBC support byte stored in the first reserved byte of the 32-byte ROM header. */
export declare enum VbColorSupport {
    LEGACY = 0,
    ENHANCED = 128,
    ONLY = 192
}
export declare function emulatorHardwareModeLabels(): Record<VbHardwareMode, string>;
/** Resolve Auto without changing any emulated reset-state register. */
export declare function resolveVbHardwareMode(mode: string, support: number): VbHardwareMode.VIRTUAL_BOY | VbHardwareMode.VB_COLOR;
export declare function vbColorSupportLabel(support: number): string;
export interface RomHeader {
    name: string;
    maker: string;
    code: string;
    version: number;
    /** VBC support classification byte at header offset +0x14. */
    vbcSupport: number;
    /**
     * Whether the 32 bytes read actually look like a cartridge header.
     *
     * A Virtual Boy has nowhere to record that a ROM has no header, so every
     * dump parses and one without a header parses into noise. See
     * {@link parseRomHeader} for what is checked and why it is only the codes.
     */
    valid: boolean;
}
export declare const EMPTY_ROM_HEADER: RomHeader;
/**
 * How far from the end of a ROM its header sits.
 *
 * The Virtual Boy's header lives at a fixed offset from the *end* of the
 * cartridge rather than the start, so it is found by counting back — which is
 * why a padded dump still parses.
 */
export declare const ROM_HEADER_OFFSET_FROM_END = 544;
/** How many bytes make one MBit, which is the unit ROM sizes are quoted in. */
export declare const BYTES_PER_MBIT = 131072;
/**
 * Read a ROM's header.
 *
 * The name is Shift_JIS: these are Japanese cartridges, and several commercial
 * titles have kana in the name that any other decoding turns to mojibake. A
 * browser that cannot decode it falls back to Latin-1, which is wrong for those
 * titles but readable for the rest, rather than failing to show a header at all.
 */
export declare function parseRomHeader(rom: Uint8Array): RomHeader;
/** A ROM's size in MBit, which is how cartridges are described. */
export declare function romSizeInMBit(rom: Uint8Array): number;
export declare const ROM_HEADER_MAKERS: {
    [key: string]: string;
};
export interface EmulatorConfig {
    name: string;
    path: string;
    args: string;
}
/**
 * Built on first use, not at import: the host installs its localization
 * during start-up, and a table built while this module loaded would be
 * English for the life of the process. See `setLocalization`.
 */
export declare function emulationRenderingModes(): Record<VbRenderingMode, string>;
/**
 * The modes' names spelt out, for the line under the control.
 *
 * A card has room for `HLI` and not for what it stands for; the line below it
 * has room for both the words and a sentence about them. Only the
 * abbreviations are respelt here — every other mode's card label already *is*
 * its name, and is taken from `emulationRenderingModes` rather than handed to
 * a translator a second time.
 */
export declare function emulationRenderingModeNames(): Record<VbRenderingMode, string>;
export declare function emulationRenderingModeDescriptions(): Record<VbRenderingMode, string>;
/**
 * Built on first use, not at import: the host installs its localization
 * during start-up, and a table built while this module loaded would be
 * English for the life of the process. See `setLocalization`.
 */
export declare function emulationPalettes(): Record<string, string>;
/**
 * Built on first use, not at import: the host installs its localization
 * during start-up, and a table built while this module loaded would be
 * English for the life of the process. See `setLocalization`.
 */
export declare function emulationAnaglyphPalettes(): Record<string, string>;
export interface CustomPalette {
    name: string;
    colors: string[];
}
export interface CustomAnaglyphPalette {
    name: string;
    left: string;
    right: string;
    duboisProfile?: VbDuboisProfileSelection;
    duboisMatrices?: VbAnaglyphMatrices;
}
export declare const CUSTOM_PALETTE_PREFIX = "custom:";
export declare const getCustomPaletteId: (name: string) => string;
export declare const parseColor: (color: string) => number;
export declare const formatColor: (color: number) => string;
export declare const toVbPalette: (colors: string[]) => VbPalette;
/** A stored palette id, under the name this build knows it by. */
export declare const paletteId: (stored: string) => string;
export declare const resolvePalette: (stored: string, custom: CustomPalette[]) => VbPalette;
/** Fill malformed or incomplete hand-edited matrices from a known-safe calibration. */
export declare const normalizeAnaglyphMatrices: (matrices: VbAnaglyphMatrices | undefined, fallback?: VbAnaglyphMatrices) => VbAnaglyphMatrices;
export declare const resolveAnaglyphPalette: (id: string, custom: CustomAnaglyphPalette[]) => VbAnaglyphPalette;
/**
 * The halo color a theme stands in with where no one palette color is the
 * answer, with enough contrast against either a dark or a light surface.
 *
 * A host that does not set `--vp-ambient-color` — and anywhere there is no
 * document to read it from — gets white.
 */
export declare const neutralDecorationColor: () => string;
/**
 * What the Ambient halo's color is when `decorationColorFromPalette` is on, in
 * place of `decorationColor`.
 *
 * The palette's fully-lit level, the same color the brightest pixel the
 * picture can show is drawn in — so the halo reads as an extension of the
 * image rather than a color picked apart from it. Anaglyph has no one such
 * color because the two eyes are tinted oppositely, and VB Color draws from
 * CRAM rather than the selected four-level palette; both fall back to
 * {@link neutralDecorationColor}.
 */
export declare const paletteDecorationColor: (renderingMode: string, palette: VbPalette, 
/** VB Color hardware is driving the picture, so the palette is not what is on screen. */
vbcHardwareActive?: boolean) => string;
/** Whether the ROM this emulator was opened on is actually there yet. */
export declare enum EmulatorRomStatus {
    CHECKING = "checking",
    EXISTS = "exists",
    NOT_EXISTS = "not_exists"
}
export declare enum EmulatorMode {
    PLAY = "play",
    DEBUG = "debug"
}
export declare enum EmulatorScale {
    AUTO = "auto",
    FIT = "fit",
    X1 = "x1",
    X2 = "x2",
    X3 = "x3",
    X4 = "x4",
    X5 = "x5",
    X6 = "x6"
}
export interface EmulatorScaleOption {
    value: EmulatorScale;
    label: string;
    /** What this scale does to the picture, for the line under the control. */
    description: string;
}
/**
 * Built on first use, not at import: the host installs its localization
 * during start-up, and a table built while this module loaded would be
 * English for the life of the process. See `setLocalization`.
 */
export declare function emulatorScaleOptions(): EmulatorScaleOption[];
/**
 * What is drawn around the picture where it does not fill the view.
 *
 * `NONE` leaves the surface the interface's own. `BLACK` fills it, which is
 * what a real Virtual Boy shows around its image and the truer backdrop for
 * one. `AMBIENT` is a soft halo in a color of the person's choosing. `IMMERSION`
 * is that halo driven by the picture itself, the outer pixels bleeding into the
 * space around them.
 */
export declare enum EmulatorDecoration {
    NONE = "none",
    BLACK = "black",
    AMBIENT = "ambient",
    IMMERSION = "immersion"
}
/** Built on first use, for the reason `emulatorSramInitLabels` explains. */
export declare function emulatorDecorationLabels(): Record<EmulatorDecoration, string>;
/**
 * What each decoration fills the view with, in a sentence — shown under the
 * control for whichever one is chosen. Built on first use, for the reason
 * `emulatorSramInitLabels` explains.
 */
export declare function emulatorDecorationDescriptions(): Record<EmulatorDecoration, string>;
/**
 * How much a recording is allowed to spend on its picture, in words.
 *
 * Named rather than given as a bit rate, because the number that matters
 * depends on the rendering mode and the scale — the same setting has to serve
 * a 384x224 single eye and a 512x448 Cyberscope blown up four times. See
 * `VIDEO_BIT_RATES`, which is where the words become numbers.
 *
 * Built on first use, for the reason `emulatorSramInitLabels` explains.
 */
export declare function emulatorVideoQualityLabels(): Record<string, string>;
/**
 * Which container a recording should be written in.
 *
 * A preference rather than a promise, which is why the automatic choice is
 * named for what it does instead of for a format: what a browser can encode is
 * the browser's business — Safari has no WebM encoder, Firefox no MP4 one —
 * and asking for one it does not have gets the other rather than nothing.
 *
 * Built on first use, for the reason `emulatorSramInitLabels` explains.
 */
export declare function emulatorVideoFormatLabels(): Record<string, string>;
export declare enum EmulatorGamePadKeyCode {
    A = "KeyM",
    B = "KeyN",
    Start = "KeyB",
    Select = "KeyV",
    LUp = "KeyE",
    LRight = "KeyF",
    LDown = "KeyD",
    LLeft = "KeyA",// KeyS is "Low Power"
    RUp = "KeyI",
    RRight = "KeyL",
    RDown = "KeyK",
    RLeft = "KeyJ",
    LT = "KeyG",
    RT = "KeyH"
}
/**
 * Something the emulator can be told to do, as opposed to a button held on its
 * game pad.
 *
 * These identify an action and nothing else. They used to be key codes, which
 * they no longer are anywhere: a key reaches an action through the keybinding
 * registry, so what an action is bound to is whatever the user has mapped, and
 * an enum claiming otherwise could only ever be out of date. The default
 * mappings live where they belong, in `registerKeybindings`.
 */
export declare enum EmulatorAction {
    Fullscreen = "fullscreen",
    ToggleControlsOverlay = "toggleControlsOverlay",
    SaveState = "saveState",
    LoadState = "loadState",
    ToggleFastForward = "toggleFastForward",
    PauseToggle = "pauseToggle",
    ToggleSlowmotion = "toggleSlowmotion",
    ToggleLowPower = "toggleLowPower",
    Rewind = "rewind",
    FrameAdvance = "frameAdvance",
    Reset = "reset",
    AudioMute = "audioMute",
    Screenshot = "screenshot",
    VideoRecord = "videoRecord"
}
export { EmulatorCompanionLocation, EmulatorSramInit, EmulatorSramWindow };
/** Built on first use, for the reason `emulatorSramInitLabels` explains. */
export declare function emulatorCompanionLocationLabels(): Record<EmulatorCompanionLocation, string>;
/**
 * Built on first use, not at import: the host installs its localization
 * during start-up, and a table built while this module loaded would be
 * English for the life of the process. See `setLocalization`.
 */
export declare function emulatorSramInitLabels(): Record<EmulatorSramInit, string>;
/**
 * What each save window is called. Built on first use, for the reason
 * `emulatorSramInitLabels` explains.
 *
 * The sizes name themselves and are left untranslated; only the two that say
 * something go through nls. "Full" rather than a number because 16 MB is not
 * a cartridge anybody will build — it is the whole region, handed over so that
 * no game can run out.
 */
export declare function emulatorSramWindowLabels(): Record<EmulatorSramWindow, string>;
export { EmulatorResumeStart };
/** Built on first use, for the reason `emulatorSramInitLabels` explains. */
export declare function emulatorResumeStartLabels(): Record<EmulatorResumeStart, string>;
//# sourceMappingURL=emulator-types.d.ts.map