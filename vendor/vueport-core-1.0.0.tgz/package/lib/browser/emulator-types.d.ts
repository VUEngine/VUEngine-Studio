import { VbAnaglyphMatrices, VbAnaglyphPalette, VbDuboisProfileSelection, VbPalette, VbRenderingMode } from '../common/vb-constants';
import { EmulatorResumeStart } from '../common/emulator-save-state';
import { EmulatorCompanionLocation, EmulatorSramInit, EmulatorSramWindow } from '../common/emulator-sram';
export declare enum VbLinkStatus {
    idle = 0,
    connect = 1,
    initiate = 2,
    transfer = 3
}
export interface VbLinkStatusData {
    status: VbLinkStatus;
    done: number;
    data?: Buffer;
}
export declare enum VbHardwareMode {
    AUTO = "auto",
    VIRTUAL_BOY = "vb",
    VB_COLOR = "vbc"
}
export declare enum VbColorSupport {
    LEGACY = 0,
    ENHANCED = 128,
    ONLY = 192
}
export declare function emulatorHardwareModeLabels(): Record<VbHardwareMode, string>;
export declare function resolveVbHardwareMode(mode: string, support: number): VbHardwareMode.VIRTUAL_BOY | VbHardwareMode.VB_COLOR;
export declare function vbColorSupportLabel(support: number): string;
export interface RomHeader {
    name: string;
    maker: string;
    code: string;
    version: number;
    vbcSupport: number;
    valid: boolean;
}
export declare const EMPTY_ROM_HEADER: RomHeader;
export declare const ROM_HEADER_OFFSET_FROM_END = 544;
export declare const STRIP_IDLE_DELAY = 6000;
export declare const STRIP_WAKE_DISTANCE = 24;
export declare const BYTES_PER_MBIT = 131072;
export declare function parseRomHeader(rom: Uint8Array): RomHeader;
export declare function romSizeInMBit(rom: Uint8Array): number;
export declare const ROM_HEADER_MAKERS: {
    [key: string]: string;
};
export interface EmulatorConfig {
    name: string;
    path: string;
    args: string;
}
export declare function emulationRenderingModes(): Record<VbRenderingMode, string>;
export declare function emulationRenderingModeNames(): Record<VbRenderingMode, string>;
export declare function emulationRenderingModeDescriptions(): Record<VbRenderingMode, string>;
export declare function emulationPalettes(): Record<string, string>;
export declare function emulationAnaglyphPalettes(): Record<string, string>;
export interface CustomPalette {
    name: string;
    colors: string[];
}
export interface CustomAnaglyphPalette {
    name: string;
    left: string;
    right: string;
    duboisProfile?: VbDuboisProfileSelection;
    duboisMatrices?: VbAnaglyphMatrices;
}
export declare const CUSTOM_PALETTE_PREFIX = "custom:";
export declare const getCustomPaletteId: (name: string) => string;
export declare const parseColor: (color: string) => number;
export declare const formatColor: (color: number) => string;
export declare const toVbPalette: (colors: string[]) => VbPalette;
export declare const resolvePalette: (id: string, custom: CustomPalette[]) => VbPalette;
export declare const normalizeAnaglyphMatrices: (matrices: VbAnaglyphMatrices | undefined, fallback?: VbAnaglyphMatrices) => VbAnaglyphMatrices;
export declare const resolveAnaglyphPalette: (id: string, custom: CustomAnaglyphPalette[]) => VbAnaglyphPalette;
export declare const neutralDecorationColor: () => string;
export declare const paletteDecorationColor: (renderingMode: string, palette: VbPalette, vbcHardwareActive?: boolean) => string;
export declare enum EmulatorRomStatus {
    CHECKING = "checking",
    EXISTS = "exists",
    NOT_EXISTS = "not_exists"
}
export declare enum EmulatorMode {
    PLAY = "play",
    DEBUG = "debug"
}
export declare enum EmulatorScale {
    AUTO = "auto",
    FIT = "fit",
    X1 = "x1",
    X2 = "x2",
    X3 = "x3",
    X4 = "x4",
    X5 = "x5",
    X6 = "x6"
}
export interface EmulatorScaleOption {
    value: EmulatorScale;
    label: string;
    description: string;
}
export declare function emulatorScaleOptions(): EmulatorScaleOption[];
export declare enum EmulatorDecoration {
    NONE = "none",
    BLACK = "black",
    AMBIENT = "ambient",
    IMMERSION = "immersion"
}
export declare function emulatorDecorationLabels(): Record<EmulatorDecoration, string>;
export declare function emulatorDecorationDescriptions(): Record<EmulatorDecoration, string>;
export declare function emulatorVideoQualityLabels(): Record<string, string>;
export declare function emulatorVideoFormatLabels(): Record<string, string>;
export declare enum EmulatorGamePadKeyCode {
    A = "KeyM",
    B = "KeyN",
    Start = "KeyB",
    Select = "KeyV",
    LUp = "KeyE",
    LRight = "KeyF",
    LDown = "KeyD",
    LLeft = "KeyA",// KeyS is "Low Power"
    RUp = "KeyI",
    RRight = "KeyL",
    RDown = "KeyK",
    RLeft = "KeyJ",
    LT = "KeyG",
    RT = "KeyH"
}
export declare enum EmulatorAction {
    Fullscreen = "fullscreen",
    ToggleControlsOverlay = "toggleControlsOverlay",
    SaveState = "saveState",
    LoadState = "loadState",
    ToggleFastForward = "toggleFastForward",
    PauseToggle = "pauseToggle",
    ToggleSlowmotion = "toggleSlowmotion",
    ToggleLowPower = "toggleLowPower",
    Rewind = "rewind",
    FrameAdvance = "frameAdvance",
    Reset = "reset",
    AudioMute = "audioMute",
    Screenshot = "screenshot",
    VideoRecord = "videoRecord"
}
export { EmulatorCompanionLocation, EmulatorSramInit, EmulatorSramWindow };
export declare function emulatorCompanionLocationLabels(): Record<EmulatorCompanionLocation, string>;
export declare function emulatorSramInitLabels(): Record<EmulatorSramInit, string>;
export declare function emulatorSramWindowLabels(): Record<EmulatorSramWindow, string>;
export { EmulatorResumeStart };
export declare function emulatorResumeStartLabels(): Record<EmulatorResumeStart, string>;
//# sourceMappingURL=emulator-types.d.ts.map