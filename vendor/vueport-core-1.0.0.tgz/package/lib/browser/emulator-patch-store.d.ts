import { Emitter, Event } from '../common/emulator-events';
import { VesColorPatchChoice } from '../common/emulator-color-patches';
import { VueportStorage } from '../common/emulator-host';
import { BuiltInRomPatch, RomPatchDatabaseEntry } from '../common/emulator-patch-database';
import { RomPatch } from '../common/emulator-rom-patches';
import { browserStateStorage } from './emulator-browser-state';
/** Fields the player may edit on an imported patch. */
export type RomPatchMetadata = Pick<RomPatch, 'name' | 'description' | 'author' | 'type'>;
/**
 * What the patch store needs to offer a game's VB Color colorizations.
 *
 * Both are the host's, because what they read and write are settings: a
 * colorization is on when the colorization settings say so, not when the
 * patch switches beside the ROM do.
 */
export interface PatchStoreColorizations {
    /**
     * Whether auto-apply is on, and which colorizations are switched off — and
     * also where hardcore mode says no: a colorization is a ROM patch, and must
     * not come on by itself in a hardcore session.
     */
    choice(): VesColorPatchChoice;
    /**
     * Remember whether a colorization should be applied, so that its switch
     * means something the next time the game is opened.
     */
    remember(id: string, apply: boolean): void;
}
/** Why listeners are redrawing; ROM-affecting changes require a restart. */
export interface PatchStoreChange {
    affectsRom: boolean;
}
/**
 * Registered built-in and imported patches for the current original ROM.
 * Imported definitions live in the companion JSON; current switches live in
 * browser storage and never make built-ins appear in that file. The game's VB
 * Color colorizations are shipped patches as well, listed first; whether one is
 * on lives in the colorization settings — see `PatchStoreColorizations`.
 */
export declare class PatchStore {
    protected readonly storage: VueportStorage;
    protected readonly database: readonly RomPatchDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected readonly loadFile?: ((file: string) => Promise<Uint8Array>) | undefined;
    protected readonly colorizations?: PatchStoreColorizations | undefined;
    /**
     * The game's VB Color colorizations, in catalog order. A list of their
     * own because at most one of them is on, and because whether it is is not
     * the patch switches' business.
     */
    protected color: RomPatch[];
    protected builtIn: RomPatch[];
    protected custom: RomPatch[];
    protected sourceRom: Uint8Array | undefined;
    protected statePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded: boolean;
    protected persisting: Promise<void>;
    /** Why the running ROM may not change at the moment, if it may not. */
    protected lockReason: string | undefined;
    protected readonly onDidChangeEmitter: Emitter<PatchStoreChange>;
    readonly onDidChange: Event<PatchStoreChange>;
    /**
     * `loadFile` reads a shipped patch's `file`, relative to where the host
     * serves its assets. A host that passes none offers no shipped patches, and
     * one that passes no `colorizations` offers no colorizations.
     */
    constructor(storage: VueportStorage, database?: readonly RomPatchDatabaseEntry[], stateStorage?: browserStateStorage | undefined, loadFile?: ((file: string) => Promise<Uint8Array>) | undefined, colorizations?: PatchStoreColorizations | undefined);
    /**
     * Refuse every change that would alter the running ROM, saying why — or,
     * with no reason, allow them again.
     *
     * For a linked session: every machine in both windows runs the image the
     * first player's window started it with, and a patch switched on in one
     * window mid-session would be one copy of a machine running different
     * code from the other.
     */
    setLocked(reason: string | undefined): void;
    get locked(): string | undefined;
    protected refuseIfLocked(): void;
    get list(): ReadonlyArray<RomPatch>;
    get active(): number;
    /**
     * How many patches are on, not counting the colorizations — what the badge
     * over the picture shows.
     */
    get activeOutsideColor(): number;
    /**
     * The patch at a list index, and where it lives: which of the three lists,
     * and its index in that one.
     */
    protected at(index: number): {
        patch: RomPatch;
        list: 'color' | 'builtIn' | 'custom';
        at: number;
    } | undefined;
    load(romPath: string, romId: string | undefined, sourceRom: Uint8Array): Promise<void>;
    /**
     * The shipped patches for this ROM, with their bytes in hand.
     *
     * Read up front rather than when one is switched on, because applying is
     * synchronous: the ROM is rebuilt the moment a switch flips, and there is
     * no point at which to wait for a file. It is one game's patches, read
     * from beside the page. One that cannot be read is left out with a
     * warning rather than listed with nothing behind its switch.
     */
    protected readBuiltIns(patches: BuiltInRomPatch[]): Promise<RomPatch[]>;
    /**
     * The game's colorizations, with their bytes in hand and the first one the
     * colorization settings leave on switched on.
     *
     * Read up front for the reason `readBuiltIns` gives. One that cannot be
     * read is left out with a warning, and the next one the settings leave on
     * comes on in its place.
     */
    protected readColorizations(romId: string | undefined): Promise<RomPatch[]>;
    unload(): void;
    /** Import one recognized patch, disabled until the player opts in. */
    importPatch(fileName: string, data: Uint8Array): number;
    /** Change descriptive fields on one of the player's imported patches. */
    updateMetadata(index: number, metadata: Partial<RomPatchMetadata>): void;
    /**
     * Enable or disable one patch, validating the entire resulting chain.
     *
     * Switching a colorization on switches the game's other one off in the
     * same change — they are alternatives, each made against the original
     * ROM — and either way the choice is remembered in the colorization
     * settings rather than with the patch switches.
     */
    setEnabled(index: number, enabled: boolean): void;
    remove(index: number): void;
    disableAll(): void;
    apply(source: Uint8Array): Uint8Array;
    /** The Virtual Boy core accepts cartridge images in power-of-two sizes. */
    protected validateResult(result: Uint8Array): Uint8Array;
    /** Wait until all state changes made so far have reached storage. */
    whenSaved(): Promise<void>;
    protected changed(persistDefinitions: boolean, persistState: boolean, affectsRom: boolean): void;
    /** The patch switches; a colorization's is in the colorization settings instead. */
    protected saveBrowserState(): boolean;
    protected saveDefinitions(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=emulator-patch-store.d.ts.map