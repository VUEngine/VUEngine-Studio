import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { RomPatchDatabaseEntry } from '../common/emulator-patch-database';
import { RomPatch } from '../common/emulator-rom-patches';
import { browserStateStorage } from './emulator-browser-state';
/** Fields the player may edit on an imported patch. */
export type RomPatchMetadata = Pick<RomPatch, 'name' | 'description' | 'author' | 'type' | 'screenshot'>;
/** Why listeners are redrawing; ROM-affecting changes require a restart. */
export interface PatchStoreChange {
    affectsRom: boolean;
}
export declare class PatchStore {
    protected readonly storage: VueportStorage;
    protected readonly database: readonly RomPatchDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected builtIn: RomPatch[];
    /**
     * Patches VUEPort generated itself this session — currently the VB Color
     * colorizations, built from a shipped patch document, the player's palette
     * edits and the running ROM.
     *
     * A list of their own, and deliberately not part of `custom`: `custom` is
     * what gets written to the patch file beside the ROM, and a generated patch
     * has no business being persisted. It is rebuilt from its document
     * whenever it is needed, so persisting it could only ever produce a stale
     * copy.
     */
    protected generated: RomPatch[];
    protected custom: RomPatch[];
    protected sourceRom: Uint8Array | undefined;
    protected statePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded: boolean;
    protected persisting: Promise<void>;
    protected readonly onDidChangeEmitter: Emitter<PatchStoreChange>;
    readonly onDidChange: Event<PatchStoreChange>;
    constructor(storage: VueportStorage, database?: readonly RomPatchDatabaseEntry[], stateStorage?: browserStateStorage | undefined);
    get list(): ReadonlyArray<RomPatch>;
    /**
     * The unmodified ROM the patches apply to, for whoever has to build one.
     *
     * The VB Color build needs it: a BPS is a delta, so generating one means
     * having the source it is a delta against.
     */
    get rom(): Uint8Array | undefined;
    /**
     * Add or replace a patch VUEPort generated, by id.
     *
     * Replacing rather than appending, because the color editor rebuilds its
     * patch behind every edit and the list must not grow a copy each time.
     *
     * Returns whether the running ROM is affected, which is true when the patch
     * is enabled and either was not before or its bytes changed. `restart` is
     * how the caller says whether that is worth restarting the game for, and
     * while somebody is editing colors it is not: the edit is already on
     * screen and already in the running ROM's palette table, and the new bytes
     * only have to be in place for the next restart. Passing false still
     * replaces the patch and still tells listeners to redraw — it withholds
     * only the ROM-affecting flag the restart hangs off.
     */
    setGeneratedPatch(patch: RomPatch, restart?: boolean): boolean;
    /** Take a generated patch away again. */
    removeGeneratedPatch(id: string): void;
    get active(): number;
    /**
     * The patch at a list index, and where it lives.
     *
     * `custom` is its index in the player's own patches, or -1 for one of the
     * two lists VUEPort owns — the shipped ones and the generated ones — which
     * are addressed through `at`'s own return value instead.
     */
    protected at(index: number): {
        patch: RomPatch;
        custom: number;
        generated: number;
    } | undefined;
    load(romPath: string, romId: string | undefined, sourceRom: Uint8Array): Promise<void>;
    unload(): void;
    /** Import one recognized patch, disabled until the player opts in. */
    importPatch(fileName: string, data: Uint8Array): number;
    /** Change descriptive fields on one of the player's imported patches. */
    updateMetadata(index: number, metadata: Partial<RomPatchMetadata>): void;
    /** Enable or disable one patch, validating the entire resulting chain. */
    setEnabled(index: number, enabled: boolean): void;
    remove(index: number): void;
    disableAll(): void;
    apply(source: Uint8Array): Uint8Array;
    /** The Virtual Boy core accepts cartridge images in power-of-two sizes. */
    protected validateResult(result: Uint8Array): Uint8Array;
    /** Wait until all state changes made so far have reached storage. */
    whenSaved(): Promise<void>;
    protected changed(persistDefinitions: boolean, persistState: boolean, affectsRom: boolean): void;
    protected saveBrowserState(): boolean;
    protected saveDefinitions(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=emulator-patch-store.d.ts.map