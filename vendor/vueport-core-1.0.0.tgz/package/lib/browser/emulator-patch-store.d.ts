import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { BuiltInRomPatch, RomPatchDatabaseEntry } from '../common/emulator-patch-database';
import { RomPatch } from '../common/emulator-rom-patches';
import { browserStateStorage } from './emulator-browser-state';
/** Fields the player may edit on an imported patch. */
export type RomPatchMetadata = Pick<RomPatch, 'name' | 'description' | 'author' | 'type'>;
/** Both settings that decide whether a colorization comes on when its game is opened. */
export interface ColorPatchChoice {
    /** The master switch, `vbcAutoApplyColorPatches`. */
    autoApply: boolean;
    /** The ids turned off individually, `vbcColorPatchesDisabled`. */
    disabled: readonly string[];
}
/**
 * What the patch store needs to offer a game's VB Color colorizations.
 *
 * Both are the host's, because what they read and write are settings: a
 * colorization is on when the colorization settings say so, not when the
 * patch switches beside the ROM do. The two settings nest: off, the master
 * switch keeps every colorization off; on, each one answers for itself, so a
 * player who wants color everywhere but in one game turns that one off rather
 * than the feature. Neither decides whether a colorization is listed: one
 * that is switched off is still offered, so it can be switched on again.
 */
export interface PatchStoreColorizations {
    /**
     * Whether auto-apply is on, and which colorizations are switched off — and
     * also where hardcore mode says no: a colorization is a ROM patch, and must
     * not come on by itself in a hardcore session.
     */
    choice(): ColorPatchChoice;
    /**
     * Remember whether a colorization should be applied, so that its switch
     * means something the next time the game is opened.
     */
    remember(id: string, apply: boolean): void;
}
/** Why listeners are redrawing; ROM-affecting changes require a restart. */
export interface PatchStoreChange {
    affectsRom: boolean;
}
/**
 * Registered built-in and imported patches for the current original ROM.
 * Imported definitions live in the companion JSON; current switches live in
 * browser storage and never make built-ins appear in that file. The game's VB
 * Color colorizations are shipped patches as well, listed first; whether one is
 * on lives in the colorization settings — see `PatchStoreColorizations`.
 */
export declare class PatchStore {
    protected readonly storage: VueportStorage;
    protected readonly database: readonly RomPatchDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected readonly loadFile?: ((file: string) => Promise<Uint8Array>) | undefined;
    protected readonly colorizations?: PatchStoreColorizations | undefined;
    /** The shipped patches, colorizations first, otherwise in catalog order. */
    protected builtIn: RomPatch[];
    protected custom: RomPatch[];
    protected sourceRom: Uint8Array | undefined;
    protected statePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded: boolean;
    protected persisting: Promise<void>;
    /** Why the running ROM may not change at the moment, if it may not. */
    protected lockReason: string | undefined;
    protected readonly onDidChangeEmitter: Emitter<PatchStoreChange>;
    readonly onDidChange: Event<PatchStoreChange>;
    /**
     * `loadFile` reads a shipped patch's `file`, relative to where the host
     * serves its assets. A host that passes none offers no shipped patches, and
     * one that passes no `colorizations` offers no colorizations.
     */
    constructor(storage: VueportStorage, database?: readonly RomPatchDatabaseEntry[], stateStorage?: browserStateStorage | undefined, loadFile?: ((file: string) => Promise<Uint8Array>) | undefined, colorizations?: PatchStoreColorizations | undefined);
    /**
     * Refuse every change that would alter the running ROM, saying why — or,
     * with no reason, allow them again.
     *
     * For a linked session: every machine in both windows runs the image the
     * first player's window started it with, and a patch switched on in one
     * window mid-session would be one copy of a machine running different
     * code from the other.
     */
    setLocked(reason: string | undefined): void;
    get locked(): string | undefined;
    protected refuseIfLocked(): void;
    get list(): ReadonlyArray<RomPatch>;
    get active(): number;
    /**
     * How many patches are on, not counting the colorizations — what the badge
     * over the picture shows.
     */
    get activeOutsideColor(): number;
    /**
     * The patch at a list index, and where it lives: which of the two lists,
     * and its index in that one.
     */
    protected at(index: number): {
        patch: RomPatch;
        list: 'builtIn' | 'custom';
        at: number;
    } | undefined;
    load(romPath: string, romId: string | undefined, sourceRom: Uint8Array): Promise<void>;
    /**
     * The shipped patches for this ROM, with their bytes in hand.
     *
     * Read up front rather than when one is switched on, because applying is
     * synchronous: the ROM is rebuilt the moment a switch flips, and there is
     * no point at which to wait for a file. It is one game's patches, read
     * from beside the page. One that cannot be read is left out with a
     * warning rather than listed with nothing behind its switch. The
     * colorizations come first, as the panel lists them.
     */
    protected readBuiltIns(patches: BuiltInRomPatch[]): Promise<RomPatch[]>;
    unload(): void;
    /** Import one recognized patch, disabled until the player opts in. */
    importPatch(fileName: string, data: Uint8Array): number;
    /**
     * Change descriptive fields on one of the player's imported patches.
     *
     * Only the type can touch the ROM: a patch that is on and becomes, or
     * stops being, a colorization is applied differently from then on, so that
     * change is validated and restarts the game like a switch.
     */
    updateMetadata(index: number, metadata: Partial<RomPatchMetadata>): void;
    /**
     * Enable or disable one patch, validating the entire resulting chain.
     *
     * Switching a colorization on switches the game's others off in the same
     * change — see `replace`. A shipped one's choice is remembered in the
     * colorization settings rather than with the patch switches.
     */
    setEnabled(index: number, enabled: boolean): void;
    /**
     * Put `changed` in the place of `patch`, validating the entire resulting
     * chain.
     *
     * When that leaves a colorization on, every other one goes off: they are
     * alternatives, each made against the original ROM. Switching one on is
     * also saying "not the others": the next launch applies the first shipped
     * one the settings leave on, so the shipped others are recorded as off or
     * an earlier one in the catalog would win.
     */
    protected replace(patch: RomPatch, changed: RomPatch): void;
    remove(index: number): void;
    disableAll(): void;
    apply(source: Uint8Array): Uint8Array;
    /** The Virtual Boy core accepts cartridge images in power-of-two sizes. */
    protected validateResult(result: Uint8Array): Uint8Array;
    /** Wait until all state changes made so far have reached storage. */
    whenSaved(): Promise<void>;
    protected changed(persistDefinitions: boolean, persistState: boolean, affectsRom: boolean): void;
    /** The patch switches; a shipped colorization's is in the colorization settings instead. */
    protected saveBrowserState(): boolean;
    protected saveDefinitions(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=emulator-patch-store.d.ts.map