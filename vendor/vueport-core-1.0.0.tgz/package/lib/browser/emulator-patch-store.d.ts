import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { BuiltInRomPatch, RomPatchDatabaseEntry } from '../common/emulator-patch-database';
import { RomPatch } from '../common/emulator-rom-patches';
import { browserStateStorage } from './emulator-browser-state';
export type RomPatchMetadata = Pick<RomPatch, 'name' | 'description' | 'author' | 'type'>;
export interface ColorPatchChoice {
    autoApply: boolean;
    disabled: readonly string[];
}
/**
 * What the patch store needs to offer a game's VB Color colorizations; the host's, as they are settings, not the
 * patch switches beside the ROM. They nest: master off keeps all off; on, each answers for itself, so one game
 * can be turned off rather than the feature. A switched-off colorization is still listed, to switch on again
 */
export interface PatchStoreColorizations {
    choice(): ColorPatchChoice;
    remember(id: string, apply: boolean): void;
}
export interface PatchStoreChange {
    affectsRom: boolean;
}
export declare class PatchStore {
    protected readonly storage: VueportStorage;
    protected readonly database: readonly RomPatchDatabaseEntry[];
    protected readonly stateStorage?: browserStateStorage | undefined;
    protected readonly loadFile?: ((file: string) => Promise<Uint8Array>) | undefined;
    protected readonly colorizations?: PatchStoreColorizations | undefined;
    protected builtIn: RomPatch[];
    protected custom: RomPatch[];
    protected sourceRom: Uint8Array | undefined;
    protected statePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded: boolean;
    protected persisting: Promise<void>;
    protected lockReason: string | undefined;
    protected readonly onDidChangeEmitter: Emitter<PatchStoreChange>;
    readonly onDidChange: Event<PatchStoreChange>;
    constructor(storage: VueportStorage, database?: readonly RomPatchDatabaseEntry[], stateStorage?: browserStateStorage | undefined, loadFile?: ((file: string) => Promise<Uint8Array>) | undefined, colorizations?: PatchStoreColorizations | undefined);
    setLocked(reason: string | undefined): void;
    get locked(): string | undefined;
    protected refuseIfLocked(): void;
    get list(): ReadonlyArray<RomPatch>;
    get active(): number;
    get activeOutsideColor(): number;
    protected at(index: number): {
        patch: RomPatch;
        list: 'builtIn' | 'custom';
        at: number;
    } | undefined;
    load(romPath: string, romId: string | undefined, sourceRom: Uint8Array): Promise<void>;
    protected readBuiltIns(patches: BuiltInRomPatch[]): Promise<RomPatch[]>;
    unload(): void;
    importPatch(fileName: string, data: Uint8Array): number;
    updateMetadata(index: number, metadata: Partial<RomPatchMetadata>): void;
    setEnabled(index: number, enabled: boolean): void;
    protected replace(patch: RomPatch, changed: RomPatch): void;
    remove(index: number): void;
    disableAll(): void;
    apply(source: Uint8Array): Uint8Array;
    protected validateResult(result: Uint8Array): Uint8Array;
    whenSaved(): Promise<void>;
    protected changed(persistDefinitions: boolean, persistState: boolean, affectsRom: boolean): void;
    protected saveBrowserState(): boolean;
    protected saveDefinitions(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=emulator-patch-store.d.ts.map