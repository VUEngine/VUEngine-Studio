/**
 * The page's own interface in a headset (see emulator-xr-ui.ts), done with the page's own elements: a part of the
 * page is copied into an SVG image (foreignObject), which the browser decodes and draws into a canvas that becomes a
 * texture; and a controller's pointing becomes the events a mouse would cause on the real elements.
 * Why a copy: a headset browser stops painting the page during a session (on the Quest neither animation frames nor
 * HTML-in-Canvas paint events come), but decoding an image still works. The copy keeps what CSS needs to look the
 * same: the part's ancestors as empty shells, the rules that can apply, every element's laid-out size (so text and
 * grids break where the page's do, which pointing relies on), scroll positions, typed values, and the hover, press
 * and focus states the pointer gives it.
 */
export declare const XR_HOVER_CLASS = "vp-xr-hover";
export declare const XR_ACTIVE_CLASS = "vp-xr-active";
export declare const XR_FOCUS_CLASS = "vp-xr-focus";
export declare const XR_FOCUS_VISIBLE_CLASS = "vp-xr-focus-visible";
export declare const XR_FOCUS_WITHIN_CLASS = "vp-xr-focus-within";
export declare const XR_LAYOUT_CLASS = "vp-xr-layout";
export interface XrDomState {
    hovered?: Element;
    pressed?: Element;
}
interface PictureClip {
    rect: DOMRect;
    radius: number;
}
/**
 * A picture the canvas draws itself rather than the copy (see XrDomSnapshot.drawsItself): drawn after the copy, in
 * place and clipped as the page shows it, and then whatever lies over it (a card's buttons over its cover) drawn
 * again from a second copy that shows only that
 */
interface Picture {
    page: DOMRect;
    clips: PictureClip[];
    place: DOMRect;
    bitmap?: ImageBitmap;
}
type CssNode = {
    kind: 'style';
    text: string;
    needs: string[][];
} | {
    kind: 'group';
    head: string;
    children: CssNode[];
} | {
    kind: 'always';
    text: string;
};
declare class PageRules {
    protected readonly data: (address: string) => Promise<string>;
    protected nodes: CssNode[];
    protected count: number;
    protected reading: Promise<void> | undefined;
    protected readonly written: Map<string, string>;
    constructor(data: (address: string) => Promise<string>);
    for(present: Set<string>): Promise<string>;
    protected read(): Promise<void>;
}
/**
 * The page's own :hover and :active rules once more, for the classes the pointer puts on the real elements (see
 * XrDomPointer), so the page itself takes the states a mouse would give: what a hover brings up (a cheat's eye button)
 * is then there to be pointed at and pressed, not only drawn. A sheet of its own, adopted, so the copy's reading of
 * the page's sheets passes it by
 */
export declare class XrStateSheet {
    protected readonly sheet: CSSStyleSheet;
    protected count: number;
    protected text: string;
    constructor();
    refresh(): void;
    dispose(): void;
}
export declare function isTextEntry(element: Element | null | undefined): element is HTMLInputElement | HTMLTextAreaElement;
export declare class XrDomSnapshot {
    protected readonly images: Map<string, string>;
    protected readonly rules: PageRules;
    protected serial: number;
    timings: {
        copy: number;
        serialize: number;
        decode: number;
        raster: number;
        css: number;
        svg: number;
        pictures: number;
        drawn: number;
    } | undefined;
    protected pictureChars: number;
    protected readonly bitmaps: Map<string, Promise<ImageBitmap>>;
    /**
     * Draws `element` as the page lays it out into `canvas`, `scale` canvas pixels to a CSS pixel; the canvas takes
     * the size. Resolves to the part's size in CSS pixels, or undefined where it has none (gone, hidden)
     */
    draw(element: HTMLElement, state: XrDomState, scale: number, canvas: HTMLCanvasElement, hidden?: ReadonlySet<Element>): Promise<{
        width: number;
        height: number;
    } | undefined>;
    protected copy(element: HTMLElement, box: DOMRect, state: XrDomState, scale: number, hidden: ReadonlySet<Element>): Promise<{
        root: HTMLElement;
        overRoot?: HTMLElement;
        present: Set<string>;
        pictures: Picture[];
    }>;
    protected wrap(element: HTMLElement, part: HTMLElement, width: number, height: number, present: Set<string>): HTMLElement;
    protected fixUp(original: HTMLElement, originals: Element[], clones: Element[], unseen: Set<Element>, box: DOMRect, state: XrDomState, present: Set<string>, scale: number): Promise<{
        pictures: Picture[];
        overs: {
            from: Element;
            to: HTMLElement;
        }[];
    }>;
    /**
     * Whether a picture can be drawn by the canvas itself instead of going into the copy, and if so, sets it up: a
     * cover in the copy is tens of kilobytes the browser decodes again on every drawing, which scrolling a library
     * makes many times a second; drawn here it is a bitmap made once. Only for a picture nothing transforms, fades or
     * filters on the way to the part, as drawing it here knows only rectangles, rounded corners and object-fit
     */
    protected drawsItself(image: HTMLImageElement, part: HTMLElement, box: DOMRect, scale: number, pictures: Picture[], pending: Promise<void>[]): boolean;
    protected bitmap(image: HTMLImageElement, width: number, height: number): Promise<ImageBitmap>;
    protected svg(root: HTMLElement, css: string, width: number, height: number): string;
    protected pictureData(image: HTMLImageElement, scale: number): Promise<string>;
    protected dataUrl(address: string): Promise<string>;
}
/**
 * What a pointer at (x, y) in the page's coordinates is over, within `root`. Worked out from the layout rather than
 * by the browser (elementFromPoint), as in a session the page's parts are laid out on top of each other and partly
 * outside the window, and only the part pointed at in the headset counts
 */
export declare function xrDomTarget(root: Element, x: number, y: number, skip?: ReadonlySet<Element>): Element;
export declare function setControlValue(control: HTMLInputElement | HTMLTextAreaElement, value: string): void;
/**
 * A mouse made of a controller: moves, presses and releases on page coordinates become the pointer and mouse events
 * a real one causes, so React's handlers run as they would on the page. Focus follows a press, a range input follows
 * the pointer while pressed, and the stick scrolls whatever scrolls under it
 */
export declare class XrDomPointer {
    hovered: Element | undefined;
    pressed: Element | undefined;
    protected dragging: HTMLInputElement | undefined;
    protected pressedAt: {
        x: number;
        y: number;
    };
    protected movedTo: {
        x: number;
        y: number;
    };
    protected scrollRemainder: number;
    move(target: Element | undefined, x: number, y: number): boolean;
    press(target: Element, x: number, y: number): void;
    release(target: Element | undefined, x: number, y: number): void;
    leave(): void;
    scroll(within: Element, pixels: number): boolean;
}
export declare function pressXrKey(key: string): boolean;
export {};
//# sourceMappingURL=emulator-xr-dom.d.ts.map