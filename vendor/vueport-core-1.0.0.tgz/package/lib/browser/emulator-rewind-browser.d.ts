import { Disposable, Emitter, Event } from '../common/emulator-events';
import { RewindHistory } from '../common/vb-protocol';
import { Sim } from './core/vb-core';
import { PadCommand } from './emulator-gamepad-ui';
import { EmulatorTimeAudio, EmulatorTimeControl } from './emulator-time-control';
export interface EmulatorRewindBrowserHost {
    readonly sim?: Sim;
    readonly paused: boolean;
    readonly esSound: EmulatorTimeAudio;
    onNothingToRewind(): void;
    restoreInput(): Promise<void>;
}
/**
 * The rewind history as a filmstrip, the way the console makers' classics collections do it: the machine stops, a strip
 * of thumbnails about a second apart lays out the last minutes, and the screen shows whichever moment is picked. Going
 * back and forth costs nothing (see RewindStore in vb-worker.ts); playing on from a moment gives up what came after it,
 * backing out returns to where the strip was opened. The Rewind key opens it like the button; held rewind
 * (EmulatorTimeControl) is left to hosts without the strip.
 * The cursor here runs ahead of the worker: it moves at once, and the worker follows to wherever it is by then, so a
 * held arrow key never queues up seeks.
 */
export declare class EmulatorRewindBrowser implements Disposable {
    protected readonly host: EmulatorRewindBrowserHost;
    protected readonly time: EmulatorTimeControl;
    protected _history?: RewindHistory;
    protected _cursor: number;
    protected landed: number;
    protected opening: boolean;
    protected seeking: boolean;
    protected readonly thumbnailUrls: Map<number, string>;
    protected generation: number;
    protected changePending: boolean;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    constructor(host: EmulatorRewindBrowserHost, time: EmulatorTimeControl);
    get isOpen(): boolean;
    get history(): RewindHistory | undefined;
    get cursor(): number;
    thumbnailUrl(capture: number): string | undefined;
    get secondsBack(): number;
    open(): void;
    seek(capture: number): void;
    step(captures: number): void;
    stepThumbnail(direction: number): void;
    steer(command: PadCommand): void;
    resume(): void;
    cancel(): void;
    /**
     * Closes the strip where the machine is, for something about to replace its state anyway (a loaded state, changed
     * rewind settings, which drop the history in the worker). `resume` false for a session being torn down, which has
     * nothing left to run.
     */
    abandon(resume?: boolean): void;
    protected close(back: boolean): void;
    protected letGo(): void;
    protected loadThumbnails(sim: Sim, history: RewindHistory, generation: number): Promise<void>;
    protected fireChange(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-rewind-browser.d.ts.map