import { VueportRumblePack } from '../common/emulator-rumble';
import { Speed } from '../common/vb-protocol';
import { EsSoundPlayer } from './emulator-essound-player';
export interface EmulatorStatusSource {
    readonly hasRom: boolean;
    readonly emulationSpeed: Speed | undefined;
    readonly esSound: EsSoundPlayer;
    readonly rumblePack: VueportRumblePack;
    readonly vbcSupportEnabled: boolean;
    readonly vbcHardwareActive: boolean;
    readonly selectedHardwareMode: string;
}
export declare const STATUS_NONE = "\u2014";
export declare function formatEmulationSpeed(source: EmulatorStatusSource): string;
export declare function formatHardwareMode(source: EmulatorStatusSource): string;
export declare function formatEsSound(source: EmulatorStatusSource, withPlaying?: boolean): string;
export declare function formatRumblePack(source: EmulatorStatusSource): string;
export declare function formatController(): string;
export declare function formatProgramCounter(pc: number | undefined): string;
export declare function formatSymbolCount(classes: number | undefined): string;
//# sourceMappingURL=emulator-status.d.ts.map