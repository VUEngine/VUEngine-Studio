import { VueportRumblePack } from '../common/emulator-rumble';
import { Speed } from '../common/vb-protocol';
import { EsSoundPlayer } from './emulator-essound-player';
/** What a host has to be able to answer for the readouts below. */
export interface EmulatorStatusSource {
    /** Whether there is a cartridge in the machine. */
    readonly hasRom: boolean;
    readonly paused: boolean;
    /** The measured rate, as the worker last reported it. */
    readonly emulationSpeed: Speed | undefined;
    readonly esSound: EsSoundPlayer;
    readonly rumblePack: VueportRumblePack;
    /** Whether VB Color is switched on at all. */
    readonly vbcSupportEnabled: boolean;
    /** Whether the running machine actually is one. */
    readonly vbcHardwareActive: boolean;
    /** What the setting says, which may be `auto`. */
    readonly selectedHardwareMode: string;
}
/** Shown wherever a reading has nothing to report. */
export declare const STATUS_NONE = "\u2014";
/**
 * What the speed reads as.
 *
 * The measured rate rather than the requested one: a fast forward ratio the
 * machine cannot sustain is clamped, so the two disagree exactly when knowing
 * the difference matters.
 */
export declare function formatEmulationSpeed(source: EmulatorStatusSource): string;
/** Both the physical model and whether Auto chose it. */
export declare function formatHardwareMode(source: EmulatorStatusSource): string;
/**
 * What the ESSound entry reads as.
 *
 * The expansion plays audio files kept beside the cartridge. A browser cannot
 * reach the folder a ROM was opened from, so the only way they arrive is
 * zipped with it — which is what "no tracks" usually means there.
 */
export declare function formatEsSound(source: EmulatorStatusSource): string;
/**
 * The pack's own name where it gives one, or that there is simply one there.
 *
 * A pack the link cable has taken the port from says so instead of its name:
 * the name would read as "working", and the whole point of the reading is that
 * it is not. See `applyRumbleForwarding`.
 */
export declare function formatRumblePack(source: EmulatorStatusSource): string;
/** The first controller the browser has named, or that there is none. */
export declare function formatController(): string;
/** A program counter, as the debugger spells one. */
export declare function formatProgramCounter(pc: number | undefined): string;
/** How many classes the symbol table describes. */
export declare function formatSymbolCount(classes: number | undefined): string;
//# sourceMappingURL=emulator-status.d.ts.map