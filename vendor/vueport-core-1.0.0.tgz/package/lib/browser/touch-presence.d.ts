export declare function notePhysicalInput(): void;
export declare function isTouching(): boolean;
export declare function useTouchPresence(): boolean;
//# sourceMappingURL=touch-presence.d.ts.map