/**
 * Drawing for a headset — see `emulator-xr.ts`: the game's picture, composed
 * by the ordinary renderer into a texture of the page's own, and the things
 * shown around it, each copied into a quad layer of its own or drawn into the
 * eye buffers.
 */
import { DisplayMode } from '../common/vb-constants';
import { FrameKind } from '../common/vb-protocol';
import { VbRenderer } from '../worker/vb-renderer';
import { XrFrame, XrQuadLayer, XrSpace, XrSubImage, XrViewport, XrWebGlBinding } from './emulator-xr-webxr';
/**
 * What a quad layer's size has to be multiplied by to come out the size asked
 * for. The Quest Browser shows a quad layer twice the width and height it was
 * given — measured against the same screen drawn into the eye buffers, which
 * comes out as asked — so it is given half.
 */
export declare function quadSizeFactor(): number;
/**
 * The ordinary renderer, drawing into a framebuffer of the caller's choosing
 * rather than onto its canvas.
 *
 * Its canvas is never shown; its context is the one the headset is given. The
 * base class assumes its program stays bound and its frames and mask stay on
 * units 0, 1, 4 and 5, so everything else drawn in this context binds its own
 * program and texture unit and puts unit 0 back afterwards.
 */
export declare class XrFrameRenderer extends VbRenderer {
    protected program: WebGLProgram | undefined;
    /** Only draw when asked to: a frame arriving merely uploads. */
    protected drawing: boolean;
    constructor(canvas: HTMLCanvasElement, mode: DisplayMode);
    get context(): WebGL2RenderingContext;
    setDisplayMode(mode: DisplayMode): void;
    present(pixels: Uint8Array, colorMode?: boolean, kind?: FrameKind): void;
    /** Compose the frame on show, side by side, into a framebuffer of the mode's size. */
    renderTo(framebuffer: WebGLFramebuffer): void;
    protected draw(): void;
}
export declare const SCREEN_VERTEX_SHADER = "#version 300 es\n// The screen as a strip of four corners, generated from the vertex id.\nuniform mat4 uViewProjection;\nuniform vec3 uCenter;\nuniform vec2 uSize;\nout vec2 vUv;\nvoid main() {\n    vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));\n    vUv = corner;\n    gl_Position = uViewProjection * vec4(uCenter + vec3((corner - 0.5) * uSize, 0.0), 1.0);\n}\n";
export declare const SCREEN_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// Both eyes, side by side, as the renderer composed them.\nuniform sampler2D uImage;\n// 0 for the left eye's half, 1 for the right's.\nuniform float uEye;\n// 1 to make dark see-through: each pixel as opaque as it is bright, the way\n// the console's LEDs only ever added light. Premultiplied, as a compositor\n// takes it \u2014 the colour is already no brighter than its own alpha.\nuniform int uHologram;\nin vec2 vUv;\nout vec4 fragColor;\nconst vec2 SIZE = vec2(384.0, 224.0);\nvoid main() {\n    // Sharp bilinear: nearest within a pixel, blended across the one display\n    // pixel its edge falls in. Nearest alone shimmers as the head moves;\n    // bilinear alone blurs every edge.\n    vec2 texel = vUv * SIZE;\n    vec2 nearest = floor(texel + 0.5);\n    vec2 width = max(fwidth(texel), vec2(1e-5));\n    texel = nearest + clamp((texel - nearest) / width, -0.5, 0.5);\n    // Kept off the outer half texel, so the left eye never blends in the\n    // right eye's first column at the seam between them.\n    texel = clamp(texel, vec2(0.5), SIZE - 0.5);\n    vec2 uv = texel / SIZE;\n    fragColor = texture(uImage, vec2((uv.x + uEye) * 0.5, uv.y));\n    if (uHologram != 0) {\n        fragColor.a = max(fragColor.r, max(fragColor.g, fragColor.b));\n    }\n}\n";
export declare const COPY_VERTEX_SHADER = "#version 300 es\n// Fullscreen triangle; the viewport cuts it down to one eye's region.\nvoid main() {\n    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n";
export declare const COPY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// Both eyes, side by side, as the renderer composed them.\nuniform highp sampler2D uImage;\n// The eye's region of the layer: x, y, width, height.\nuniform vec4 uViewport;\n// 0 for the left eye's half, 1 for the right's.\nuniform int uEye;\n// See the screen's own shader: dark see-through, for the hologram backdrop.\nuniform int uHologram;\nout vec4 fragColor;\nconst vec2 SIZE = vec2(384.0, 224.0);\nvoid main() {\n    // Each layer texel takes exactly one source pixel: an enlargement by a\n    // whole multiple, so every pixel stays square and sharp.\n    vec2 at = floor((gl_FragCoord.xy - uViewport.xy) / uViewport.zw * SIZE);\n    ivec2 source = ivec2(clamp(at, vec2(0.0), SIZE - 1.0));\n    fragColor = texelFetch(uImage, source + ivec2(uEye * 384, 0), 0);\n    if (uHologram != 0) {\n        fragColor.a = max(fragColor.r, max(fragColor.g, fragColor.b));\n    }\n}\n";
export declare const OVERLAY_COPY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// A menu or a line of news, the size of the layer it is copied into.\nuniform sampler2D uImage;\n// The layer's region: x, y, width, height.\nuniform vec4 uViewport;\nout vec4 fragColor;\nvoid main() {\n    fragColor = texture(uImage, (gl_FragCoord.xy - uViewport.xy) / uViewport.zw);\n}\n";
export declare const OVERLAY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// A menu or a line of news, drawn into the eye buffers.\nuniform sampler2D uImage;\nin vec2 vUv;\nout vec4 fragColor;\nvoid main() {\n    fragColor = texture(uImage, vUv);\n}\n";
/** Compile and link a program, or say exactly why not. */
export declare function buildProgram(gl: WebGL2RenderingContext, vertex: string, fragment: string): WebGLProgram;
/** Column-major 4×4 product, `a` applied after `b`. */
export declare function multiply(a: Float32Array, b: Float32Array): Float32Array;
/** The texture unit the screen samples on, clear of the renderer's 0, 1, 4 and 5. */
export declare const SCREEN_UNIT = 2;
/** And the one a menu or a line of news samples on. */
export declare const OVERLAY_UNIT = 3;
export interface Point3 {
    x: number;
    y: number;
    z: number;
}
/**
 * Something shown in front of the game: a menu, a line of news.
 *
 * Drawn on a 2D canvas, uploaded as a texture when it changes, and shown the
 * way the screen is — in a quad layer of its own where the session has them,
 * otherwise drawn into the eye buffers over the screen. Opaque, so that
 * neither way has to agree with the other about blending.
 */
export declare class XrOverlay {
    protected readonly gl: WebGL2RenderingContext;
    readonly pixels: {
        width: number;
        height: number;
    };
    /** Its width in the room, in meters. */
    width: number;
    /**
     * Whether it is see-through where nothing is drawn — the badges, which
     * stand over the room on their own. Kept premultiplied, as a
     * compositor blends a layer.
     */
    readonly transparent: boolean;
    readonly canvas: HTMLCanvasElement;
    protected readonly texture: WebGLTexture;
    /** Its quad layer, once it has been shown in a session that has them. */
    layer: XrQuadLayer | undefined;
    visible: boolean;
    /** Where its middle is, in the session's space. */
    protected center: {
        x: number;
        y: number;
        z: number;
    };
    constructor(gl: WebGL2RenderingContext, pixels: {
        width: number;
        height: number;
    }, 
    /** Its width in the room, in meters. */
    width: number, 
    /**
     * Whether it is see-through where nothing is drawn — the badges, which
     * stand over the room on their own. Kept premultiplied, as a
     * compositor blends a layer.
     */
    transparent?: boolean);
    get height(): number;
    /** Take what has been drawn on the canvas since. */
    upload(): void;
    /** Make it this wide, in meters, its layer with it. */
    resize(width: number): void;
    /** Put its middle here, moving its layer with it. */
    place(x: number, y: number, z: number): void;
    /**
     * Where a ray meets it, if it does: the point in the session's space, and
     * the same point in the canvas' pixels from the top left. It faces the
     * player square on, as everything here does.
     */
    hit(origin: Point3, direction: Point3): {
        point: Point3;
        x: number;
        y: number;
    } | undefined;
    /** Make its quad layer, the first time it is shown in a session that has them. */
    ensureLayer(binding: XrWebGlBinding, space: XrSpace): XrQuadLayer;
    /** Copy it into its quad layer, with the copy program bound. */
    drawLayer(binding: XrWebGlBinding, frame: XrFrame, framebuffer: WebGLFramebuffer, viewport: WebGLUniformLocation | null): void;
    /** Draw it into the eye buffer bound, with the overlay program bound and the view set. */
    drawProjection(center: WebGLUniformLocation | null, size: WebGLUniformLocation | null): void;
    dispose(): void;
}
/** Where each eye's picture goes in a side-by-side quad layer; see {@link quadEyeRegions}. */
export interface QuadEyeRegion {
    texture: WebGLTexture;
    viewport: XrViewport;
}
/**
 * Where each eye's picture goes in a side-by-side quad layer, from what the
 * browser says of each eye's part of it.
 *
 * As the Layers module has it, each eye is given its own half of one texture.
 * A Quest gives both eyes the same part instead — the left half — so taking
 * it at its word draws the right eye over the left and leaves the right half,
 * and the right eye, black. Where both eyes are told the same part of one
 * texture wide enough for two, the halves are worked out here. Separate
 * textures, one per eye, are taken as they come.
 */
export declare function quadEyeRegions(left: XrSubImage, right: XrSubImage): {
    eyes: [QuadEyeRegion | undefined, QuadEyeRegion | undefined];
    description: string;
};
//# sourceMappingURL=emulator-xr-render.d.ts.map