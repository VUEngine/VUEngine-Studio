import { DisplayMode } from '../common/vb-constants';
import { FrameKind } from '../common/vb-protocol';
import { VbRenderer } from '../worker/vb-renderer';
import { XrFrame, XrQuadLayer, XrSpace, XrSubImage, XrViewport, XrWebGlBinding } from './emulator-xr-webxr';
export declare function quadSizeFactor(): number;
export declare class XrFrameRenderer extends VbRenderer {
    protected program: WebGLProgram | undefined;
    protected drawing: boolean;
    constructor(canvas: HTMLCanvasElement, mode: DisplayMode);
    get context(): WebGL2RenderingContext;
    setDisplayMode(mode: DisplayMode): void;
    present(pixels: Uint8Array, colorMode?: boolean, kind?: FrameKind): void;
    renderTo(framebuffer: WebGLFramebuffer): void;
    protected draw(): void;
}
export declare const SCREEN_VERTEX_SHADER = "#version 300 es\n// The screen as a strip of four corners, generated from the vertex id.\nuniform mat4 uViewProjection;\nuniform vec3 uCenter;\nuniform vec2 uSize;\n// Turned about the vertical axis through its center, in radians; 0 faces\n// the player square on.\nuniform float uYaw;\nout vec2 vUv;\nvoid main() {\n    vec2 corner = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1));\n    vUv = corner;\n    vec2 offset = (corner - 0.5) * uSize;\n    vec3 turned = vec3(offset.x * cos(uYaw), offset.y, -offset.x * sin(uYaw));\n    gl_Position = uViewProjection * vec4(uCenter + turned, 1.0);\n}\n";
export declare const SCREEN_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// Both eyes, side by side, as the renderer composed them.\nuniform sampler2D uImage;\n// 0 for the left eye's half, 1 for the right's.\nuniform float uEye;\n// 1 to make dark see-through: each pixel as opaque as it is bright, the way\n// the console's LEDs only ever added light. Premultiplied, as a compositor\n// takes it \u2014 the colour is already no brighter than its own alpha.\nuniform int uHologram;\nin vec2 vUv;\nout vec4 fragColor;\nconst vec2 SIZE = vec2(384.0, 224.0);\nvoid main() {\n    // Sharp bilinear: nearest within a pixel, blended across the one display\n    // pixel its edge falls in. Nearest alone shimmers as the head moves;\n    // bilinear alone blurs every edge.\n    vec2 texel = vUv * SIZE;\n    vec2 nearest = floor(texel + 0.5);\n    vec2 width = max(fwidth(texel), vec2(1e-5));\n    texel = nearest + clamp((texel - nearest) / width, -0.5, 0.5);\n    // Kept off the outer half texel, so the left eye never blends in the\n    // right eye's first column at the seam between them.\n    texel = clamp(texel, vec2(0.5), SIZE - 0.5);\n    vec2 uv = texel / SIZE;\n    fragColor = texture(uImage, vec2((uv.x + uEye) * 0.5, uv.y));\n    if (uHologram != 0) {\n        fragColor.a = max(fragColor.r, max(fragColor.g, fragColor.b));\n    }\n}\n";
export declare const COPY_VERTEX_SHADER = "#version 300 es\n// Fullscreen triangle; the viewport cuts it down to one eye's region.\nvoid main() {\n    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));\n    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);\n}\n";
export declare const COPY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// Both eyes, side by side, as the renderer composed them.\nuniform highp sampler2D uImage;\n// The eye's region of the layer: x, y, width, height.\nuniform vec4 uViewport;\n// 0 for the left eye's half, 1 for the right's.\nuniform int uEye;\n// See the screen's own shader: dark see-through, for the hologram backdrop.\nuniform int uHologram;\nout vec4 fragColor;\nconst vec2 SIZE = vec2(384.0, 224.0);\nvoid main() {\n    // Each layer texel takes exactly one source pixel: an enlargement by a\n    // whole multiple, so every pixel stays square and sharp.\n    vec2 at = floor((gl_FragCoord.xy - uViewport.xy) / uViewport.zw * SIZE);\n    ivec2 source = ivec2(clamp(at, vec2(0.0), SIZE - 1.0));\n    fragColor = texelFetch(uImage, source + ivec2(uEye * 384, 0), 0);\n    if (uHologram != 0) {\n        fragColor.a = max(fragColor.r, max(fragColor.g, fragColor.b));\n    }\n}\n";
export declare const OVERLAY_COPY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// A menu or a line of news, the size of the layer it is copied into.\nuniform sampler2D uImage;\n// The layer's region: x, y, width, height.\nuniform vec4 uViewport;\nout vec4 fragColor;\nvoid main() {\n    fragColor = texture(uImage, (gl_FragCoord.xy - uViewport.xy) / uViewport.zw);\n}\n";
export declare const OVERLAY_FRAGMENT_SHADER = "#version 300 es\nprecision highp float;\n// A menu or a line of news, drawn into the eye buffers.\nuniform sampler2D uImage;\nin vec2 vUv;\nout vec4 fragColor;\nvoid main() {\n    fragColor = texture(uImage, vUv);\n}\n";
export declare function buildProgram(gl: WebGL2RenderingContext, vertex: string, fragment: string): WebGLProgram;
export declare function multiply(a: Float32Array, b: Float32Array): Float32Array;
export declare const SCREEN_UNIT = 2;
export declare const OVERLAY_UNIT = 3;
export interface Point3 {
    x: number;
    y: number;
    z: number;
}
export declare function yawAxes(yaw: number): {
    x: Point3;
    normal: Point3;
};
export interface XrOverlayHit {
    point: Point3;
    x: number;
    y: number;
    distance: number;
}
export declare class XrOverlay {
    protected readonly gl: WebGL2RenderingContext;
    readonly pixels: {
        width: number;
        height: number;
    };
    width: number;
    readonly transparent: boolean;
    readonly canvas: HTMLCanvasElement;
    protected readonly texture: WebGLTexture;
    layer: XrQuadLayer | undefined;
    visible: boolean;
    protected center: {
        x: number;
        y: number;
        z: number;
    };
    protected yaw: number;
    constructor(gl: WebGL2RenderingContext, pixels: {
        width: number;
        height: number;
    }, width: number, transparent?: boolean);
    get height(): number;
    get position(): Readonly<Point3>;
    get turn(): number;
    upload(): void;
    resize(width: number): void;
    place(x: number, y: number, z: number, yaw?: number): void;
    hit(origin: Point3, direction: Point3): XrOverlayHit | undefined;
    ensureLayer(binding: XrWebGlBinding, space: XrSpace): XrQuadLayer;
    drawLayer(binding: XrWebGlBinding, frame: XrFrame, framebuffer: WebGLFramebuffer, viewport: WebGLUniformLocation | null): void;
    drawProjection(center: WebGLUniformLocation | null, size: WebGLUniformLocation | null, yaw: WebGLUniformLocation | null): void;
    dispose(): void;
}
export interface QuadEyeRegion {
    texture: WebGLTexture;
    viewport: XrViewport;
}
export declare function quadEyeRegions(left: XrSubImage, right: XrSubImage): {
    eyes: [QuadEyeRegion | undefined, QuadEyeRegion | undefined];
    description: string;
};
//# sourceMappingURL=emulator-xr-render.d.ts.map