import { VesStruct } from './emulator-dwarf';
import { ElfImage, ElfSymbol } from './emulator-elf';
export interface SymbolExtent {
    address: number;
    size: number;
}
export declare enum MemoryAreaKind {
    CODE = "code",
    READ_ONLY = "readOnly",
    DATA = "data",
    ZEROED = "zeroed",
    POOL = "pool"
}
export interface MemoryArea {
    name: string;
    kind: MemoryAreaKind;
    bytes: number;
}
export interface MemoryFootprint {
    rom: MemoryArea[];
    wram: MemoryArea[];
}
export interface SymbolIndex {
    footprint: MemoryFootprint;
    memoryPool?: SymbolExtent;
    vTables: Map<number, string>;
    rumbleSpecPointer?: number;
    rumbleSpecNames: Map<number, string>;
    classes: Map<string, string>;
    structs: Map<string, VesStruct>;
    dataSymbols: ElfSymbol[];
    codeSymbols: ElfSymbol[];
}
/**
 * The function an address is inside. Unlike findSymbolAt the address need not fall within the recorded size, as
 * profiler addresses land mid-function and the linker does not always record a size: the last function starting
 * at or before the address, bounded by its size when there is one. Compared as ROM offsets, since a program
 * counter may come through the cartridge window or the mirror at the top of memory.
 */
export declare function findFunctionAt(index: SymbolIndex, address: number, romSize: number): ElfSymbol | undefined;
export declare function functionDisplayName(index: SymbolIndex, symbol: string): string;
export declare function findSymbolAt(index: SymbolIndex, address: number): {
    symbol: ElfSymbol;
    offset: number;
} | undefined;
export declare function structNameOf(className: string): string;
export declare const MEMORY_POOL_AREA = "MemoryPool";
export declare function indexElfSymbols(image: ElfImage): SymbolIndex;
//# sourceMappingURL=emulator-symbols.d.ts.map