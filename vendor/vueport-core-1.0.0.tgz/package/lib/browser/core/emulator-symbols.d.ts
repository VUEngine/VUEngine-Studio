/**
 * What the emulator's inspectors want out of a build's symbol table.
 *
 * Reading the table means pulling a whole `.elf` — tens of megabytes on a
 * real project — so it happens once per ROM and everything that needs a
 * symbol takes it from here rather than reading again. The index keeps only
 * the handful of things panels actually look up, so the symbol list itself
 * can be dropped as soon as this has been built from it.
 */
import { VesStruct } from './emulator-dwarf';
import { ElfImage, ElfSymbol } from './emulator-elf';
/** A symbol's address and the size the linker gave it. */
export interface SymbolExtent {
    address: number;
    size: number;
}
/**
 * What kind of thing a run of bytes is, which is all a budget needs to know
 * about it. Finer than the two the linker distinguishes, because "how much of
 * this cartridge is code" and "how much of it is artwork" are different
 * questions to a developer with a full ROM.
 */
export declare enum MemoryAreaKind {
    CODE = "code",
    READ_ONLY = "readOnly",
    DATA = "data",
    /** Zeroed at startup, so it stands in RAM and costs no ROM. */
    ZEROED = "zeroed",
    /** VUEngine's heap, carved out of whichever section holds it. */
    POOL = "pool"
}
/** One run of bytes a build claimed, named as the linker named it. */
export interface MemoryArea {
    /** The section it came from, or `MemoryPool` for the engine's heap. */
    name: string;
    kind: MemoryAreaKind;
    bytes: number;
}
/**
 * How much of each memory a build claimed before it ever ran.
 *
 * Both lists are in the order the linker laid them out, and both are what the
 * `.elf` says rather than what the machine is doing: this is the fixed cost of
 * the build, the part a developer can only change by building again.
 */
export interface MemoryFootprint {
    /** Bytes the cartridge has to carry, `.data`'s initializers included. */
    rom: MemoryArea[];
    /** Bytes standing in WRAM once the machine has started. */
    wram: MemoryArea[];
}
export interface SymbolIndex {
    /**
     * What the build costs the cartridge and WRAM before it runs — see
     * {@link MemoryFootprint}. Empty lists for an image whose sections say
     * nothing, which is not a state any real build is in.
     */
    footprint: MemoryFootprint;
    /**
     * MemoryPool's singleton, which is the whole of the engine's heap: the
     * pools themselves and the bookkeeping that describes them, in one struct.
     */
    memoryPool?: SymbolExtent;
    /**
     * Every class' virtual table, by address, named as the project names the
     * class. This is what turns an allocated block back into the kind of
     * object sitting in it — see `readMemoryPoolUsage`.
     */
    vTables: Map<number, string>;
    /** Address of `Rumble.c`'s `_rumbleEffectSpec`. */
    rumbleSpecPointer?: number;
    /** Every RumbleEffectSpec in the ROM, by the address the linker gave it. */
    rumbleSpecNames: Map<number, string>;
    /**
     * Every class mapped to the one it inherits from, which is what lets an
     * object of some project's own class be recognized as, say, an Actor.
     * `Object` is its own base and ends the chain.
     */
    classes: Map<string, string>;
    /**
     * Field layouts, by the name the engine's class macro gives the struct —
     * `Actor_str` for class `Actor`. Empty for a build with no debug sections,
     * which costs field-level inspection but nothing else.
     */
    structs: Map<string, VesStruct>;
    /**
     * Every data symbol, ordered by address, so a pointer read out of the
     * running machine can be named — see `findSymbolAt`. This is what turns an
     * actor's `actorSpec` back into the spec the project wrote.
     */
    dataSymbols: ElfSymbol[];
    /**
     * Every function, ordered by address, for naming code rather than data —
     * see `findFunctionAt`. This is what turns a profiled address back into
     * the method the developer wrote.
     */
    codeSymbols: ElfSymbol[];
}
/**
 * The function an address is inside.
 *
 * Unlike `findSymbolAt` this does not require the address to fall within the
 * symbol's recorded size: a profiler's addresses land in the middle of a
 * function, and a linker does not always record a size. So the search is for
 * the last function beginning at or before the address, bounded by the size
 * when there is one.
 *
 * Addresses are compared as offsets into the ROM, because a program counter
 * may arrive through the cartridge window or through the mirror at the top of
 * memory while the symbol table only ever names the former.
 */
export declare function findFunctionAt(index: SymbolIndex, address: number, romSize: number): ElfSymbol | undefined;
/**
 * What the developer calls a function, from what the linker calls it.
 *
 * The preprocessor turns `Class::method` into `Class_method` on its way to C,
 * and the linker adds the ABI's underscore on top. Undoing both makes a flame
 * graph read in the language the code was written in. The class list is what
 * makes this safe: only a prefix that really is a class becomes a `::`, so an
 * ordinary function with an underscore in its name is left alone.
 */
export declare function functionDisplayName(index: SymbolIndex, symbol: string): string;
/**
 * The symbol a pointer falls in, and how far into it.
 *
 * A spec is usually pointed at by its start, but not always: one embedded in a
 * larger structure — an array of them, or a subclass' spec whose first member
 * is the base one — is pointed at from within the symbol that contains it. So
 * the search is for the symbol whose extent covers the address rather than for
 * one that begins at it, and the offset comes back for the caller to show.
 *
 * A symbol the linker gave no size to can only be matched exactly, since there
 * is nothing to say where it ends.
 */
export declare function findSymbolAt(index: SymbolIndex, address: number): {
    symbol: ElfSymbol;
    offset: number;
} | undefined;
/** The struct a class' instances are laid out by. */
export declare function structNameOf(className: string): string;
/** What the heap is called where it appears as an area of its own. */
export declare const MEMORY_POOL_AREA = "MemoryPool";
/** Reduce a build's image to what the inspectors can use. */
export declare function indexElfSymbols(image: ElfImage): SymbolIndex;
//# sourceMappingURL=emulator-symbols.d.ts.map