/**
 * The line table a build carries, as a two-way index.
 *
 * A debugger needs both directions: a line to put a breakpoint at, and an
 * address to name in a stack frame. Two ways in are offered because two
 * situations call for them. {@link parseDwarfLineTable} reads `.debug_line`
 * out of the `.elf` itself, which is what a host that already has the image
 * should use — it needs no toolchain, and it is the only one that knows about
 * `is_stmt` and where a sequence ends. {@link parseDecodedLineTable} reads
 * what `v810-objdump --dwarf=decodedline` prints, for a host that has the
 * tool but not the image. `v810-addr2line` is the wrong tool for either: it
 * only goes one way, and costs a process per lookup.
 */
/** One row: an address, and the source line that generated it. */
export interface VesLineEntry {
    /** Offset into the ROM, not an address — see `romOffsetOf`. */
    offset: number;
    file: string;
    line: number;
    /**
     * True for the row that closes a sequence rather than opening a line.
     *
     * `.debug_line` is a series of sequences, each ending with a row that
     * marks the first address *past* the code it described. Without it an
     * address in a gap between two functions would be attributed to whatever
     * line happened to come last, which is how a debugger ends up pointing at
     * a line that has nothing to do with where the machine is.
     */
    end?: boolean;
}
export interface VesLineTable {
    /** Every source file the table mentions, as mapped. */
    readonly files: string[];
    /** Rows, ordered by address, for resolving a program counter. */
    readonly entries: VesLineEntry[];
    /**
     * Where to put a breakpoint for a line: the lowest address generated for
     * it, or for the next line below it that generated any code at all.
     *
     * The fallback is what makes a breakpoint on a blank line, a comment or a
     * declaration land somewhere sensible instead of being rejected.
     */
    resolve(file: string, line: number): VesLineEntry | undefined;
    /** The source line an address belongs to, for naming a stack frame. */
    locate(offset: number): VesLineEntry | undefined;
}
/** A line table with nothing in it, for a build that carries no line data. */
export declare const EMPTY_LINE_TABLE: VesLineTable;
/**
 * Where in the ROM an address points, whichever window it came through.
 *
 * @param romSize the ROM's size in bytes, which is what it mirrors at
 */
export declare function romOffsetOf(address: number, romSize: number): number;
/**
 * Read `v810-objdump --dwarf=decodedline` output into an index.
 *
 * @param text the tool's stdout
 * @param romSize the ROM's size, for keying rows by offset
 * @param mapPath turns the path the build recorded into the one the user edits
 */
export declare function parseDecodedLineTable(text: string, romSize: number, mapPath?: (recorded: string) => string): VesLineTable;
/**
 * Read `.debug_line` out of a build's own image.
 *
 * The section is not a table but a bytecode program: a little state machine
 * with an address and a line, run once per compilation unit, emitting a row
 * wherever the two are true together. Interpreting it rather than reading a
 * tool's printout is what makes this available to a host that has the `.elf`
 * and nothing else — and it is the only way to see where a sequence ends,
 * which is what keeps an address between two functions from being blamed on
 * whichever line came last.
 *
 * Rows from a unit whose version this does not understand are skipped rather
 * than guessed at; the unit length is in the header, so one unreadable unit
 * costs only itself.
 *
 * @param romSize the cartridge's size, since rows are kept as ROM offsets
 * @param mapPath rewrites a recorded path into one that can be opened
 */
export declare function parseDwarfLineTable(section: Uint8Array, romSize: number, mapPath?: (recorded: string) => string): VesLineTable;
/**
 * Where a recorded source path might actually be, best guess first.
 *
 * DWARF records a path as the compiler saw it, which for this toolchain is
 * relative to the directory the build ran in — `build/working/objects/...`
 * and nothing to say where that begins. The compilation directory is in
 * `.debug_info` rather than `.debug_line`, and reading it would mean decoding
 * abbreviations and attribute forms for one string.
 *
 * So the candidates are worked out from the one absolute path already in
 * hand: the ROM's own. A VUEngine build puts the ROM in `build/` and runs
 * from the project above it, which is what the two relative candidates are.
 * A host tries them in order and takes the first that opens; an absolute path
 * is already the answer and stands alone.
 *
 * @param romDirectory the folder the ROM sits in, with no trailing slash
 */
export declare function sourcePathCandidates(recorded: string, romDirectory: string): string[];
/** A part of a build — the game, the engine, or a plugin — and its sources. */
export interface VesSourceRoot {
    /** As the build names it, which is what appears in the generated path. */
    name: string;
    /** Absolute path the component's own `source/` sits under. */
    root: string;
}
/**
 * Turn the path a build recorded into the file someone can actually open.
 *
 * Note what this does *not* do, and no longer has to: the line number.
 * VUEngine compiles the preprocessor's output, so DWARF counts lines in the
 * generated file — and that file now has the same numbering as the source it
 * came from. It did not always: seven of the engine's eighty sources used to
 * drift, because the preprocessor left its folding marks in the prototypes it
 * injects ahead of the code and each one spent a newline the source never
 * had. That is fixed in the preprocessor, where it belongs, and kept fixed by
 * a test of its own; see its `readme.md` under "Deviations".
 *
 * A ROM built before that fix still has the old generated files, so an
 * address can still resolve to a line that is a little off. Nothing here
 * tries to make up the difference — aligning the two files by their content
 * was tried and got four line numbers in five to five in six, which is not
 * enough to be worth a heuristic that would have to be maintained. Rebuilding
 * is the answer, and it is the same answer for anything else stale in a
 * build's debug information.
 *
 * DWARF names the *generated* file — the Virtual C preprocessor's output under
 * `build/working` — rather than the source it came from. The same rewrite the
 * build already applies to compiler diagnostics (`processGCCOutput.sh`) undoes
 * it: everything up to and including `build/working/objects/<mode>/<component>`
 * or `build/working/headers/<component>` is replaced by that component's root.
 *
 * A build whose preprocessor emits `#line` directives records the original path
 * already, and those fall through this untouched — nothing matches.
 */
export declare function makeSourcePathMapper(roots: VesSourceRoot[]): (recorded: string) => string;
/**
 * The recorded path a source file was compiled as, going the other way.
 *
 * {@link makeSourcePathMapper} turns what the build recorded into a file
 * somebody can open, which is the direction a listing needs. A host with
 * editors needs the reverse: it has the path of the file somebody set a
 * breakpoint in, and the line table only knows the compiled one. Rather than
 * invert the rewrite — which is not invertible, since several components can
 * end up under one root — this maps every path the table knows and looks for
 * the one that lands on the file in hand.
 *
 * Linear over the table's files, which is a hundred or so for a real build,
 * and only on the rare occasion that a breakpoint moves.
 */
export declare function recordedPathFor(table: VesLineTable, mapPath: (recorded: string) => string, source: string): string | undefined;
/** Whether a build's paths still need mapping, or already name their sources. */
export declare function needsSourcePathMapping(text: string): boolean;
//# sourceMappingURL=emulator-line-table.d.ts.map