/**
 * A build's line table as a two-way index: a line to break at, and an address to name in a stack frame.
 * parseDwarfLineTable reads `.debug_line` from the `.elf` (no toolchain, and the only one that knows `is_stmt` and
 * sequence ends); parseDecodedLineTable reads `v810-objdump --dwarf=decodedline` output, for a host with the tool
 * but not the image. `v810-addr2line` only goes one way and costs a process per lookup
 */
export interface VesLineEntry {
    offset: number;
    file: string;
    line: number;
    end?: boolean;
}
export interface VesLineTable {
    readonly files: string[];
    readonly entries: VesLineEntry[];
    resolve(file: string, line: number): VesLineEntry | undefined;
    locate(offset: number): VesLineEntry | undefined;
}
export declare const EMPTY_LINE_TABLE: VesLineTable;
export declare function romOffsetOf(address: number, romSize: number): number;
export declare function parseDecodedLineTable(text: string, romSize: number, mapPath?: (recorded: string) => string): VesLineTable;
/**
 * Reads `.debug_line` from a build's own image. The section is a bytecode program, a small state machine run per
 * compilation unit emitting rows; interpreting it serves hosts with only the `.elf` and is the only way to see
 * where sequences end. Units of unknown versions are skipped rather than guessed at, costing only themselves.
 * romSize is the cartridge size (rows are ROM offsets), mapPath rewrites recorded paths into openable ones
 */
export declare function parseDwarfLineTable(section: Uint8Array, romSize: number, mapPath?: (recorded: string) => string): VesLineTable;
/**
 * Where a recorded source path might be, best guess first. DWARF paths are relative to where the build ran
 * (`build/working/objects/...`); the compilation directory is in `.debug_info`, which would mean decoding
 * abbreviations for one string. So candidates come from the ROM's own path: a VUEngine build puts the ROM in
 * `build/` and runs from the project above it. Hosts take the first that opens; an absolute path stands alone.
 * romDirectory has no trailing slash
 */
export declare function sourcePathCandidates(recorded: string, romDirectory: string): string[];
export interface VesSourceRoot {
    name: string;
    root: string;
}
/**
 * Turns the recorded path into a file someone can open. DWARF names the Virtual C preprocessor's output under
 * `build/working`; the rewrite the build applies to compiler diagnostics (processGCCOutput.sh) undoes it,
 * replacing everything up to `build/working/objects/<mode>/<component>` or `build/working/headers/<component>`
 * with that component's root. Paths from `#line` directives match nothing and pass through.
 * Line numbers need no fixing: generated files now number like their sources (the preprocessor's folding marks
 * once shifted seven of eighty engine sources; fixed there and tested, see its readme.md "Deviations"). ROMs built
 * before that may be slightly off; aligning by content only got 5 in 6 right, so rebuilding is the answer
 */
export declare function makeSourcePathMapper(roots: VesSourceRoot[]): (recorded: string) => string;
export declare function recordedPathFor(table: VesLineTable, mapPath: (recorded: string) => string, source: string): string | undefined;
export declare function needsSourcePathMapping(text: string): boolean;
//# sourceMappingURL=emulator-line-table.d.ts.map