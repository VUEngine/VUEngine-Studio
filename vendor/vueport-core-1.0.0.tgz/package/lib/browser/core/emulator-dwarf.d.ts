/**
 * Enough DWARF to know where a class keeps its fields.
 *
 * Reading an object out of a pool block needs the offset of every field in it,
 * and nothing in the symbol table says where they are — a struct is one opaque
 * run of bytes as far as `.symtab` is concerned. The debug sections do say,
 * and the toolchain emits them in every build mode, so this is available
 * wherever the `.elf` itself is.
 *
 * Only what a value inspector needs is read: named struct definitions, their
 * members' offsets, and enough of each member's type to decode the bytes
 * there. Everything else in the tree is walked past.
 *
 * VUEngine's class macro flattens inheritance, so `Actor_str` carries the
 * fields of `Container`, `Entity` and the rest inline, in that order — there
 * is no base-class link to follow, and a subclass' own struct describes the
 * whole object.
 */
import { ElfImage } from './emulator-elf';
/** How a member's bytes should be read. */
export declare enum VesTypeKind {
    SIGNED = "signed",
    UNSIGNED = "unsigned",
    BOOL = "bool",
    FLOAT = "float",
    POINTER = "pointer",
    /** A nested struct, whose own members are spliced in by the reader. */
    STRUCT = "struct",
    ARRAY = "array",
    /** Anything this does not decode — shown as raw bytes. */
    OPAQUE = "opaque"
}
export interface VesType {
    kind: VesTypeKind;
    /** The name the source gave it, for display: `int16`, `Vector3D`. */
    name: string;
    byteSize: number;
    /** For STRUCT, the definition to descend into. */
    struct?: VesStruct;
}
export interface VesStructMember {
    name: string;
    /** Bytes from the start of the struct. */
    offset: number;
    type: VesType;
    /** Width in bits for a bitfield. Absent for an ordinary member. */
    bitSize?: number;
    /**
     * Where the bitfield's low bit sits, counted in bits from the start of the
     * struct with the target's little-endian byte order already applied — so
     * the value is `(bits >> bitOffset) & mask` over the whole struct. The two
     * ways DWARF describes a bitfield are both normalized to this; see
     * `bitPosition`.
     */
    bitOffset?: number;
}
export interface VesStruct {
    name: string;
    byteSize: number;
    members: VesStructMember[];
}
/**
 * Every named struct a build defines, by name.
 *
 * Returns an empty map for an image with no debug sections, which is an
 * ordinary state rather than a failure: it only means field-level inspection
 * is unavailable for that ROM.
 */
export declare function readDwarfStructs(image: ElfImage): Map<string, VesStruct>;
/** One field of a struct, decoded from an object's bytes. */
export interface VesFieldValue {
    /** The member's name, as the source calls it. */
    name: string;
    /** Qualified by its parents for a nested member: `transformation.position.x`. */
    path: string;
    /** How far in it is nested, for indenting a listing. */
    depth: number;
    /** Bytes from the start of the object. */
    offset: number;
    type: VesType;
    /** The decoded number, where the type decodes to one. */
    value?: number;
    /** What to show, always set. */
    text: string;
}
/**
 * Decode an object, field by field, flattening nested structs into the list.
 *
 * A struct member is spliced in rather than summarized, so a `Transformation`
 * becomes `transformation.position.x` and so on: those leaves are the part
 * anyone reading an actor is actually after, and a line saying `position` is a
 * `Vector3D` says nothing they did not already know.
 *
 * @param bytes a window containing the object
 * @param at where the object starts within it
 */
export declare function readStructFields(struct: VesStruct, bytes: Uint8Array, at: number, depth?: number, prefix?: string): VesFieldValue[];
/** The member a byte inside an object belongs to. */
export interface VesMemberAt {
    /** Qualified by its parents, the way {@link VesFieldValue.path} is. */
    path: string;
    type: VesType;
    /** Where the member starts, in bytes from the start of the whole object. */
    offset: number;
    /** How far into the member the byte asked about is. */
    within: number;
}
/**
 * Which field a byte of an object is part of.
 *
 * The counterpart to {@link readStructFields} for a caller holding an address
 * rather than an object: a hex dump knows only that some byte is inside some
 * struct, and wants the name of the thing it is inside.
 *
 * Offsets come back absolute, unlike the ones on `VesFieldValue` — those are
 * relative to the member's immediate parent, which is all an indented listing
 * needs, and is the wrong answer to "how far into the object is this".
 *
 * Nested structs are descended into so the answer is a leaf, `position.x`
 * rather than `transformation`. An array is not: its element type is not kept,
 * so the honest answer is the array itself and how far into it the byte is.
 */
export declare function findStructMemberAt(struct: VesStruct, offset: number, base?: number, prefix?: string, depth?: number): VesMemberAt | undefined;
//# sourceMappingURL=emulator-dwarf.d.ts.map