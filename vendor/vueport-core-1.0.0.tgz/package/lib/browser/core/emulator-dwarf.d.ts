/**
 * Enough DWARF to know where a class keeps its fields: `.symtab` treats a struct as one opaque run of bytes, the
 * debug sections (emitted in every build mode) have the member offsets and types. Everything else is walked past.
 * VUEngine's class macro flattens inheritance, so `Actor_str` carries the fields of `Container`, `Entity` etc. inline,
 * in that order: there is no base-class link to follow, a subclass' own struct describes the whole object.
 */
import { ElfImage } from './emulator-elf';
export declare enum VesTypeKind {
    SIGNED = "signed",
    UNSIGNED = "unsigned",
    BOOL = "bool",
    FLOAT = "float",
    POINTER = "pointer",
    STRUCT = "struct",
    ARRAY = "array",
    OPAQUE = "opaque"
}
export interface VesType {
    kind: VesTypeKind;
    name: string;
    byteSize: number;
    struct?: VesStruct;
    element?: VesType;
    count?: number;
}
export interface VesStructMember {
    name: string;
    offset: number;
    type: VesType;
    bitSize?: number;
    bitOffset?: number;
}
export interface VesStruct {
    name: string;
    byteSize: number;
    members: VesStructMember[];
}
export declare function readDwarfStructs(image: ElfImage): Map<string, VesStruct>;
export declare function readDwarfVariables(image: ElfImage): Map<string, VesType>;
export interface VesFieldValue {
    name: string;
    path: string;
    depth: number;
    offset: number;
    type: VesType;
    value?: number;
    text: string;
}
export declare function readStructFields(struct: VesStruct, bytes: Uint8Array, at: number, depth?: number, prefix?: string): VesFieldValue[];
export interface VesMemberAt {
    path: string;
    type: VesType;
    offset: number;
    within: number;
}
/**
 * Which field a byte of an object is part of, for a caller holding an address, e.g. a hex dump. Offsets come back
 * absolute, unlike VesFieldValue's, which are relative to the immediate parent. Nested structs are descended into so
 * the answer is a leaf (`position.x`). Arrays are not: their element type is not kept, so the answer is the array
 * itself and how far into it the byte is.
 */
export declare function findStructMemberAt(struct: VesStruct, offset: number, base?: number, prefix?: string, depth?: number): VesMemberAt | undefined;
//# sourceMappingURL=emulator-dwarf.d.ts.map