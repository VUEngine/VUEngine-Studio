/**
 * Just enough ELF32 to read what a build knows about itself.
 *
 * The `.map` a build leaves beside its ROM lists global symbols only, and much
 * of what the inspectors want is not global — `Rumble.c`'s `_rumbleEffectSpec`
 * and `MemoryPool`'s singleton are file-scope statics, which appear only in the
 * `.elf`. The same file also carries the sections behind those symbols, so
 * anything the linker laid out can be read back without the machine running:
 * a class' `getBaseClass` stub, or the DWARF describing its fields.
 *
 * Reading it here rather than shelling out to `v810-nm` or `objdump` keeps
 * this on the frontend, where the ROM is already being loaded.
 */
/** A symbol, with the address and size the linker gave it. */
export interface ElfSymbol {
    /** As the linker recorded it, including the ABI's leading underscore. */
    name: string;
    address: number;
    size: number;
    /** Code rather than data. Both are kept: the class table needs code. */
    isFunction: boolean;
}
/** A section, as the linker placed it. */
export interface ElfSection {
    /** As it appears in the section table: `.text`, `.sdata`, `.bss`. */
    name: string;
    /** The address it stands at while the machine runs; 0 for one never loaded. */
    address: number;
    size: number;
    /** Whether it occupies memory at runtime at all, i.e. `SHF_ALLOC`. */
    allocated: boolean;
    /** Whether it holds instructions rather than data, i.e. `SHF_EXECINSTR`. */
    executable: boolean;
    /** Whether the program may write it, i.e. `SHF_WRITE`. */
    writable: boolean;
    /**
     * Whether its bytes are in the file rather than zeroed at startup.
     *
     * This is also what says whether the cartridge has to carry them: `.bss`
     * stands in RAM but costs no ROM, while `.data` costs both — it stands in
     * RAM and its initial contents are copied there out of the ROM.
     */
    hasContents: boolean;
}
/** A build's image: its symbols, and the bytes the linker placed. */
export interface ElfImage {
    symbols: ElfSymbol[];
    /** Every section the linker wrote, in the order it wrote them. */
    sections: ElfSection[];
    /** A named section's contents, or undefined if it has none. */
    section(name: string): Uint8Array | undefined;
    /**
     * Bytes at a runtime address, from whichever section covers it. Undefined
     * for an address in no section, or in one with no contents of its own
     * (`.bss`, whose bytes only exist once the machine has zeroed them).
     */
    read(address: number, length: number): Uint8Array | undefined;
}
/**
 * Read an ELF32 image, or undefined if it is not one this can read — which is
 * not worth an error, since it only means the features built on it stay off.
 */
export declare function readElf(bytes: Uint8Array): ElfImage | undefined;
/**
 * The `.elf` a build's `.map` file says it produced.
 *
 * A map sits beside the ROM it belongs to and names its own image on a line
 * like `OUTPUT(build/working/output-beta.elf elf32-v810)`, which is what makes
 * it possible to find the symbols for `build/output.vb` — a copy whose own
 * name says nothing about which build mode produced it. The path is relative
 * to the directory the build ran in, which is the project root.
 */
export declare function readElfPathFromMap(map: string): string | undefined;
/**
 * The build modes VUEngine produces.
 *
 * A copy of VES's `BuildMode`, so that reading one out of a ROM does not
 * reach into the build machinery — the emulator only ever compares a name it
 * found against these, and a ROM built elsewhere matches none of them.
 */
export declare enum BuildMode {
    Shipping = "Shipping",
    Release = "Release",
    Beta = "Beta",
    Tools = "Tools",
    Debug = "Debug"
}
/**
 * Which build mode produced a `.map`, from the image it says it made.
 *
 * The mode is a set of `-D` flags rather than anything recorded in the output
 * — DWARF's producer string carries the compiler's switches but not its
 * defines, so two modes are identical there — but the build gives each mode an
 * image of its own, `output-beta.elf` beside `output-release.elf`. That name
 * is the one durable trace of which one ran.
 *
 * Returns the mode as the build names it, lower case; the caller decides
 * whether it is one it knows.
 */
export declare function readBuildModeFromMap(map: string): string | undefined;
//# sourceMappingURL=emulator-elf.d.ts.map