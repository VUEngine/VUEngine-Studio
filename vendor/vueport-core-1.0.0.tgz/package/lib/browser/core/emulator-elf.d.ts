export interface ElfSymbol {
    name: string;
    address: number;
    size: number;
    isFunction: boolean;
}
export interface ElfSection {
    name: string;
    address: number;
    size: number;
    allocated: boolean;
    executable: boolean;
    writable: boolean;
    hasContents: boolean;
}
export interface ElfImage {
    symbols: ElfSymbol[];
    sections: ElfSection[];
    section(name: string): Uint8Array | undefined;
    read(address: number, length: number): Uint8Array | undefined;
}
export declare function readElf(bytes: Uint8Array): ElfImage | undefined;
export declare function readElfPathFromMap(map: string): string | undefined;
export declare enum BuildMode {
    Shipping = "Shipping",
    Release = "Release",
    Beta = "Beta",
    Tools = "Tools",
    Debug = "Debug"
}
export declare function readBuildModeFromMap(map: string): string | undefined;
//# sourceMappingURL=emulator-elf.d.ts.map