/**
 * Reading VUEngine's heap out of a running machine. MemoryPool is the engine's whole dynamic allocator: a fixed set
 * of pools of equally sized blocks inside one singleton struct in WRAM. Pool count and sizes are per project
 * (__MEMORY_POOLS and __MEMORY_POOL_ARRAYS in Config.h), so the struct is read whole and made to describe itself
 * via its bookkeeping arrays, which hold the pools' own addresses. See parseMemoryPoolLayout
 */
export declare const BLOCK_HEADER_BYTES = 4;
export interface VesMemoryPool {
    address: number;
    blockSize: number;
    poolSize: number;
    blocks: number;
    overflows: number;
}
export interface VesMemoryPoolLayout {
    base: number;
    pools: VesMemoryPool[];
    totalBytes: number;
    instanceVTable: number;
}
export interface VesMemoryPoolUsage {
    usedBlocks: number;
    usedBytes: number;
    classes: VesMemoryPoolOccupant[];
    unidentified: number;
}
export interface VesMemoryPoolOccupant {
    name: string;
    count: number;
}
/**
 * Recovers how a build carved up its heap from the struct's own contents. MemoryPool::reset points poolLocation[0] at
 * the first block, the word right after the struct header, so the bookkeeping arrays are found by looking for that
 * known address. The pool count follows from the bytes left (12N plus N padded to a word), and the reading has to
 * agree with itself: adjacent pools, whole numbers of blocks, together filling the space ahead of the arrays. A
 * candidate that fails is a coincidence in block data, and the scan moves on.
 * Returns undefined for a struct that describes nothing yet, the normal state before MemoryPool::reset ran ("not up
 * yet", not an error). base is the address of the singleton wrapper, region the whole wrapper as the linker sized it
 */
export declare function parseMemoryPoolLayout(base: number, region: Uint8Array): VesMemoryPoolLayout | undefined;
/**
 * Symbols come from the .elf the .map beside the ROM points at, which may not be the build that is running (a rebuild
 * not reloaded, a ROM copied over older output). Wrong pool addresses make parseMemoryPoolLayout fail, but a moved
 * vTable still lands on some class, so stale symbols silently name the wrong one. The singleton's own vTable must be
 * MemoryPool's; if the symbols disagree about that one address, every other name is suspect too
 */
export declare function symbolsMatchRunningBuild(layout: VesMemoryPoolLayout, vTables: Map<number, string>): boolean;
export declare function describesMemoryPool(region: Uint8Array, vTables: Map<number, string>): boolean;
/**
 * MemoryPool::allocate stamps a block's first halfword with __MEMORY_USED_BLOCK_FLAG and the next with its pool, and
 * MemoryPool::free resets the word to __MEMORY_FREE_BLOCK_FLAG (zero), so non-zero means occupied, the same test as
 * MemoryPool::printDetailedUsage. The object starts behind the header (__NEW hands out block + __DYNAMIC_STRUCT_PAD)
 * with its vTable pointer, which names the class. Only exact matches count, as __NEW_BASIC structs hold plain data
 * there. region is read from layout.base, vTables maps vTable addresses to class names from the ROM's symbols
 */
export declare function readMemoryPoolUsage(layout: VesMemoryPoolLayout, region: Uint8Array, vTables: Map<number, string>): VesMemoryPoolUsage[];
export interface VesMemoryPoolBlock {
    address: number;
    objectAddress: number;
    objectOffset: number;
    vTable: number;
    blockSize: number;
}
export declare function readMemoryPoolBlocks(layout: VesMemoryPoolLayout, region: Uint8Array): VesMemoryPoolBlock[];
//# sourceMappingURL=emulator-memory-pool.d.ts.map