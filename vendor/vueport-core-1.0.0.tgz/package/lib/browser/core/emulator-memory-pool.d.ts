/**
 * Reading VUEngine's heap out of a running machine.
 *
 * `MemoryPool` is the engine's whole dynamic allocator: a fixed set of pools,
 * each a flat array of equally sized blocks, all of them living inside one
 * singleton struct in WRAM. How many pools there are and how they are carved
 * up is a per-project decision (`__MEMORY_POOLS` and `__MEMORY_POOL_ARRAYS` in
 * the project's `Config.h`), so nothing here may assume either — instead the
 * struct is read whole and made to describe itself, which is possible because
 * its bookkeeping arrays are the pools' own addresses. See
 * `parseMemoryPoolLayout`.
 */
/**
 * Bytes of block header, behind which the object itself begins. `__NEW` asks
 * for `sizeof(ClassName_str) + __DYNAMIC_STRUCT_PAD`, so this is also how much
 * less than its block an object has to fit in.
 */
export declare const BLOCK_HEADER_BYTES = 4;
/** One pool: a run of equally sized blocks, and how the engine sees it. */
export interface VesMemoryPool {
    /** Address of the pool's first block. */
    address: number;
    blockSize: number;
    /** Total bytes, always a whole number of blocks. */
    poolSize: number;
    blocks: number;
    /**
     * How often the engine failed to find a free block here and had to fall
     * back to a larger pool. A `uint8` that the engine never clears, so a busy
     * run can wrap it — read a high value as "overflowing", not as a count.
     */
    overflows: number;
}
export interface VesMemoryPoolLayout {
    /** Address of the singleton wrapper the pools live in. */
    base: number;
    pools: VesMemoryPool[];
    /** Bytes given over to blocks, across every pool. */
    totalBytes: number;
    /**
     * The singleton's own vTable pointer, as the running machine has it. This
     * is what a build's symbols are checked against — see
     * `symbolsMatchRunningBuild`.
     */
    instanceVTable: number;
}
/** What is sitting in one pool right now. */
export interface VesMemoryPoolUsage {
    usedBlocks: number;
    usedBytes: number;
    /** Occupants by class, most numerous first. */
    classes: VesMemoryPoolOccupant[];
    /**
     * Used blocks whose first word matches no known vTable. Plain structs
     * allocated with `__NEW_BASIC` have no vTable and always land here.
     */
    unidentified: number;
}
export interface VesMemoryPoolOccupant {
    name: string;
    count: number;
}
/**
 * Work out how a build carved up its heap, from the struct's own contents.
 *
 * The project's pool table is a compile-time decision this cannot see, so the
 * layout is recovered instead of assumed. `poolLocation[0]` is what makes that
 * possible: `MemoryPool::reset` points it at the first block, which is the
 * word right after the struct header, so the position of the bookkeeping
 * arrays can be found by looking for an address the caller already knows. From
 * there the pool count follows from how many bytes are left — the four arrays
 * take `12N` bytes plus `N` padded to a word — and the whole reading then has
 * to agree with itself: consecutive pools must be adjacent, every pool must be
 * a whole number of blocks, and together they must fill the space ahead of the
 * arrays. A candidate that fails any of that is a coincidence in block data
 * rather than the array, and the scan moves on to the next one.
 *
 * Returns undefined for a struct that describes nothing yet, which is the
 * ordinary state of a machine that has not reached `MemoryPool::reset` — the
 * caller should read that as "not up yet" rather than as an error.
 *
 * @param base address the region was read from, i.e. of the singleton wrapper
 * @param region the whole wrapper, as long as the linker said it is
 */
export declare function parseMemoryPoolLayout(base: number, region: Uint8Array): VesMemoryPoolLayout | undefined;
/**
 * Whether a build's symbols describe the machine they were read against.
 *
 * Symbols come from the `.elf` a `.map` beside the ROM points at, and nothing
 * guarantees that file is still the one the running ROM was built from — a
 * rebuild that was not reloaded, or a ROM copied over an older build's output,
 * leaves a table whose addresses have quietly moved. Where the pools
 * themselves are concerned that is harmless, because reading them at a wrong
 * address makes `parseMemoryPoolLayout` fail rather than return something
 * plausible. Occupant names have no such protection: a vTable that moved
 * still lands on *some* class, so stale symbols name the wrong one with no
 * outward sign.
 *
 * The singleton being read is a `MemoryPool`, and its vTable pointer says so.
 * If the symbols agree about that one address they were built alongside this
 * ROM; if they do not, every other name they would give is suspect too.
 */
export declare function symbolsMatchRunningBuild(layout: VesMemoryPoolLayout, vTables: Map<number, string>): boolean;
/**
 * Whether what was read really is the `MemoryPool` singleton.
 *
 * The same check as `symbolsMatchRunningBuild`, but on the bytes alone, so it
 * can be asked when the parse has *failed* — which is the case that most
 * needs telling apart. A struct that has not been initialized yet and one read
 * from the wrong address both fail to parse, and they mean opposite things:
 * the first clears on its own once the game boots, the second never does.
 * The singleton's vTable pointer separates them, because a wrong address
 * lands on something that is not a `MemoryPool` at all.
 */
export declare function describesMemoryPool(region: Uint8Array, vTables: Map<number, string>): boolean;
/**
 * Who is holding each block, pool by pool.
 *
 * `MemoryPool::allocate` stamps a block's first halfword with
 * `__MEMORY_USED_BLOCK_FLAG` and the next with the pool it came from, and
 * `MemoryPool::free` puts the whole word back to `__MEMORY_FREE_BLOCK_FLAG`,
 * which is zero — so a non-zero header means occupied, the same test the
 * engine's own `MemoryPool::printDetailedUsage` makes.
 *
 * The object begins right behind that header (`__NEW` hands out
 * `block + __DYNAMIC_STRUCT_PAD`) and every engine class starts with its
 * vTable pointer, so the word there names the class — which is the part the
 * engine's own printout cannot tell you. Only an exact match against a vTable
 * the build declared counts, since blocks holding `__NEW_BASIC` structs have
 * ordinary data in that position.
 *
 * @param region the wrapper, read from `layout.base`
 * @param vTables class names by vTable address, from the ROM's symbols
 */
export declare function readMemoryPoolUsage(layout: VesMemoryPoolLayout, region: Uint8Array, vTables: Map<number, string>): VesMemoryPoolUsage[];
/** An occupied block, and where the object inside it begins. */
export interface VesMemoryPoolBlock {
    /** The block itself, header included. */
    address: number;
    /** The object in it, which is where its fields start. */
    objectAddress: number;
    /** That object's position within the region the layout was read from. */
    objectOffset: number;
    /** Its vTable pointer, which is what names its class. */
    vTable: number;
    /** The size of the pool it came out of, which is what it costs. */
    blockSize: number;
}
/**
 * Every occupied block, in pool order.
 *
 * `readMemoryPoolUsage` answers how full the pools are; this answers what is
 * in them, for a caller that wants to go and read the objects themselves.
 */
export declare function readMemoryPoolBlocks(layout: VesMemoryPoolLayout, region: Uint8Array): VesMemoryPoolBlock[];
//# sourceMappingURL=emulator-memory-pool.d.ts.map