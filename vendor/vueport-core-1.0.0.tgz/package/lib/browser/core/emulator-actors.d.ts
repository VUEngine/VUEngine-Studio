import { VbCellArea, VbCharacterSpan, VbPixelSource } from '../../common/vb-pixel-origin';
import { VesScreenRect } from '../panels/emulator-screen-panel';
import { VesFieldValue } from './emulator-dwarf';
import { SymbolIndex } from './emulator-symbols';
import { Sim } from './vb-core';
/** Why there are no actors to show, when there are none. */
export declare enum VesActorsStatus {
    OK = "ok",
    NO_SYMBOLS = "noSymbols",
    NO_LAYOUTS = "noLayouts",
    NOT_INITIALIZED = "notInitialized",
    STALE_SYMBOLS = "staleSymbols"
}
/** One component attached to an actor. */
export interface VesActorComponent {
    address: number;
    className: string;
    /** Set for a sprite: where the engine last drew it. */
    rect?: VesScreenRect;
    /** Sprites only: whether it is being shown and was rendered. */
    shown?: boolean;
    /** Sprites only: the DRAM block it configures, or -1 when unassigned. */
    index?: number;
    /** The worlds it is drawn into: a BG map sprite's one, while it has one. */
    worlds: number[];
    /** The objects it is drawn with: an object sprite's run of them. */
    objects: number[];
    /**
     * Where its picture is kept: a BG map sprite's texture cells, an object
     * sprite's characters. What it is told by on the picture, since unlike
     * its world or objects these stay its own from one frame to the next.
     */
    cells?: VbCellArea;
    characters?: VbCharacterSpan;
}
/** One live actor, as read out of the block it occupies. */
export interface VesActor {
    objectAddress: number;
    blockAddress: number;
    blockSize: number;
    className: string;
    /** The class this was read as, which is a base when the exact one is unknown. */
    readAs: string;
    /** The class and everything above it, for saying what it is. */
    ancestry: string[];
    components: VesActorComponent[];
    fields: VesFieldValue[];
    namePointer?: number;
    /** The spec it was built from, as the project named it. */
    spec?: string;
    /** Where in that spec the pointer landed, which is normally its start. */
    specOffset?: number;
    specAddress?: number;
    internalId?: number;
    hidden?: boolean;
    position: (number | undefined)[];
    /** The container it is a child of, or 0 for none. */
    parent: number;
}
export interface VesActorsRead {
    status: VesActorsStatus;
    actors: VesActor[];
    /**
     * The class of every object in the pools, by address — what names a
     * parent that is not an actor, which the stage never is.
     */
    classes: Map<number, string>;
}
/**
 * What to call a spec, from the symbol the linker recorded.
 *
 * The ABI's leading underscore goes, and so does the generated suffix that is
 * on every one of them — `_PlayerRacerActorSpec` is the project's `PlayerRacer`.
 * A name that is nothing but the suffix keeps it, since an empty column would
 * say less than an ugly one.
 */
export declare function specDisplayName(symbol: string): string;
/** Read the actors out of the machine's pools, or say why there are none to read. */
export declare function readActors(sim: Sim, symbols: SymbolIndex | undefined): Promise<VesActorsRead>;
/** What an actor drew: everything its sprites did. */
export declare function actorPixelSource(actor: VesActor): VbPixelSource | undefined;
/** What one component drew. */
export declare function componentPixelSource(component: VesActorComponent): VbPixelSource | undefined;
/**
 * The actor that drew a pixel, from the two words the core keeps of it and
 * where on which eye it is: the one whose sprite's cells or characters drew
 * it — see {@link VbPixelSource} for why not its world or objects.
 */
export declare function actorDrawing(actors: VesActor[], what: number, where: number, x: number, y: number, eye: 0 | 1): VesActor | undefined;
/**
 * The actor whose sprite rectangle a point of one eye falls in, the smallest
 * where several do — what the picture says when the core does not, as for a
 * pixel nothing has drawn since Debug mode came on.
 */
export declare function actorAtPoint(actors: VesActor[], x: number, y: number, eye: 0 | 1): VesActor | undefined;
/**
 * What identifies an actor in a list: its spec, which nearly every actor has
 * and which is stable across runs, or else its class — an actor built from a
 * spec made at runtime is better known by what it is than by an address.
 */
export declare function actorLabel(actor: VesActor): string;
//# sourceMappingURL=emulator-actors.d.ts.map