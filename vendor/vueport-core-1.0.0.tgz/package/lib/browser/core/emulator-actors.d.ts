import { VbCellArea, VbCharacterSpan, VbPixelSource } from '../../common/vb-pixel-origin';
import { VesScreenRect } from '../panels/emulator-screen-panel';
import { VesFieldValue } from './emulator-dwarf';
import { SymbolIndex } from './emulator-symbols';
import { Sim } from './vb-core';
export declare enum VesActorsStatus {
    OK = "ok",
    NO_SYMBOLS = "noSymbols",
    NO_LAYOUTS = "noLayouts",
    NOT_INITIALIZED = "notInitialized",
    STALE_SYMBOLS = "staleSymbols"
}
export interface VesActorComponent {
    address: number;
    className: string;
    rect?: VesScreenRect;
    shown?: boolean;
    index?: number;
    worlds: number[];
    objects: number[];
    cells?: VbCellArea;
    characters?: VbCharacterSpan;
}
export interface VesActor {
    objectAddress: number;
    blockAddress: number;
    blockSize: number;
    className: string;
    readAs: string;
    ancestry: string[];
    components: VesActorComponent[];
    fields: VesFieldValue[];
    namePointer?: number;
    spec?: string;
    specOffset?: number;
    specAddress?: number;
    internalId?: number;
    hidden?: boolean;
    position: (number | undefined)[];
    parent: number;
}
export interface VesActorsRead {
    status: VesActorsStatus;
    actors: VesActor[];
    classes: Map<number, string>;
}
export declare function specDisplayName(symbol: string): string;
export declare function readActors(sim: Sim, symbols: SymbolIndex | undefined): Promise<VesActorsRead>;
export declare function actorPixelSource(actor: VesActor): VbPixelSource | undefined;
export declare function componentPixelSource(component: VesActorComponent): VbPixelSource | undefined;
export declare function actorDrawing(actors: VesActor[], what: number, where: number, x: number, y: number, eye: 0 | 1): VesActor | undefined;
export declare function actorAtPoint(actors: VesActor[], x: number, y: number, eye: 0 | 1): VesActor | undefined;
export declare function actorLabel(actor: VesActor): string;
//# sourceMappingURL=emulator-actors.d.ts.map