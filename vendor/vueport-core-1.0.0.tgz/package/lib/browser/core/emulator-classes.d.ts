/**
 * VUEngine's class hierarchy, recovered from a build. The engine identifies a class by the address of
 * its getBaseClass function (`typeofclass(X)` is `&X_getBaseClass`), and each stub just returns
 * `&Base_getBaseClass`. On the V810 that is three regular instructions (movhi, movea, return), so reading
 * them back turns ~200 stubs into the inheritance chain, which lets a pool block of a project's own class
 * be recognized as an Actor
 */
import { ElfImage } from './emulator-elf';
export declare function readClassHierarchy(image: ElfImage): Map<string, string>;
export declare function isSubclassOf(hierarchy: Map<string, string>, name: string, ancestor: string): boolean;
export declare function ancestryOf(hierarchy: Map<string, string>, name: string): string[];
//# sourceMappingURL=emulator-classes.d.ts.map