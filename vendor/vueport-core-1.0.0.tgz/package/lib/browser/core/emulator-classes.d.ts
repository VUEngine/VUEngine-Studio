/**
 * VUEngine's class hierarchy, recovered from a build.
 *
 * The engine identifies a class by the address of its `getBaseClass` function
 * rather than by a name — `typeofclass(X)` is `&X_getBaseClass`, and a cast
 * walks upwards by calling it. That makes the hierarchy something the image
 * already contains, but only as code: `X_getBaseClass` is a stub that returns
 * `&Base_getBaseClass` and nothing else.
 *
 * On the V810 a function returning a constant address is three instructions —
 * load the high half, add the low half, return — which is regular enough to
 * read back without disassembling anything. Doing so turns 200 stubs into the
 * inheritance chain, which is what lets a pool block holding some project's
 * own class be recognized as an Actor.
 */
import { ElfImage } from './emulator-elf';
/**
 * Every class in a build, mapped to the class it inherits from.
 *
 * `Object` is its own base, which is how the engine marks the top of the
 * chain, and this keeps that: a walk upwards has to stop somewhere, and a
 * self-reference is the same terminator the engine uses.
 */
export declare function readClassHierarchy(image: ElfImage): Map<string, string>;
/**
 * Whether a class is the named one or descends from it.
 *
 * The walk is bounded by the number of classes rather than by reaching
 * `Object`, so a hierarchy that somehow forms a cycle cannot hang the caller.
 */
export declare function isSubclassOf(hierarchy: Map<string, string>, name: string, ancestor: string): boolean;
/** A class and everything above it, nearest first, for showing what it is. */
export declare function ancestryOf(hierarchy: Map<string, string>, name: string): string[];
//# sourceMappingURL=emulator-classes.d.ts.map