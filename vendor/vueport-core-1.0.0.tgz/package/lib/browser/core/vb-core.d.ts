import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { LiveProfileSnapshot } from '../../common/emulator-live-profile';
import { DisplayMode } from '../../common/vb-constants';
import { VbCheatWrite, ScheduledEdit, CommandName, Backdrop, DisassemblyLine, Frame, ProfileResult, Recording, Registers, Outbound, Params, Result, SimHandle, Speed, SramRun, StopReason, VesRaEvent, VesRaLeaderboardEntries, VesRaUser, VsuReading } from '../../common/vb-protocol';
import { VbRenderer } from '../../worker/vb-renderer';
export interface CoreOptions {
    /** URL of the bundled core worker. */
    workerUrl: string;
    /** URL of the bundled audio worklet. */
    audioWorkletUrl: string;
    /** URL the core's WebAssembly binary is served from. */
    wasmUrl: string;
    /**
     * URL of the RetroAchievements engine's Emscripten module, if this build
     * carries one. See {@link VbCommands.init}.
     */
    rcheevosModuleUrl?: string;
    /** Keep WebGL on the page and transfer frames out of the worker. */
    mainThreadVideo?: boolean;
}
export declare class Core implements Disposable {
    protected readonly worker: Worker;
    protected readonly audioContext: AudioContext;
    protected readonly audioNode: AudioWorkletNode;
    readonly mainThreadVideo: boolean;
    protected readonly mainThreadRenderers: Map<number, {
        presentation: number;
        renderer: VbRenderer;
    }>;
    protected nextPresentation: number;
    /**
     * The renderer screenshots taken on this thread are composed with.
     *
     * Only ever built where presentation lives on the page, and built once:
     * see {@link captureMainThread}.
     */
    protected screenshotRenderer: VbRenderer | undefined;
    /**
     * Who wants a copy of every frame, by simulation — a video recording.
     *
     * Separate from the renderers above: a tap is opened on a machine that is
     * being presented in the worker, which is the ordinary arrangement, as
     * readily as on one presented here. See `setVideoTap` in `vb-protocol.ts`.
     */
    protected readonly videoTaps: Map<number, {
        presentation: number;
        handle: (frame: Frame) => void;
    }>;
    /** Stops waiting for the gesture that would start the audio, if one is armed. */
    protected audioUnlock: (() => void) | undefined;
    /** The last attempt to start the audio, for {@link audioStillBlocked} to wait on. */
    protected audioResume: Promise<void> | undefined;
    /** How long a context is given to suspend before {@link driveAudio} moves on. */
    protected static readonly AUDIO_TRANSITION_TIMEOUT_MS = 500;
    /** Whether the audio graph should be producing: what run and suspend want. */
    protected audioWanted: boolean;
    /** What the context was last actually asked for. See {@link settleAudio}. */
    protected audioApplied: boolean;
    /** The transition in flight, so that only one is ever under way. */
    protected audioSettling: Promise<void> | undefined;
    protected readonly onDidUnblockAudioEmitter: Emitter<void>;
    /** Fires when audio the browser was holding back has been let through. */
    readonly onDidUnblockAudio: Event<void>;
    protected readonly pending: Map<number, {
        resolve: (result: unknown) => void;
        reject: (error: Error) => void;
    }>;
    protected nextRequestId: number;
    protected readonly onErrorEmitter: Emitter<string>;
    readonly onError: Event<string>;
    protected readonly onTerminalEmitter: Emitter<{
        sim: SimHandle;
        text: string;
    }>;
    /** Text a simulation wrote to the terminal port, once capture is enabled. */
    readonly onTerminal: Event<{
        sim: SimHandle;
        text: string;
    }>;
    protected readonly onLinkEmitter: Emitter<{
        sim: SimHandle;
        bytes: number[];
    }>;
    /** Bytes a simulation sent over the link port, once capture is enabled. */
    readonly onLink: Event<{
        sim: SimHandle;
        bytes: number[];
    }>;
    protected readonly onEsSoundEmitter: Emitter<{
        sim: SimHandle;
        commands: number[];
    }>;
    /** Halfwords a simulation wrote to the ESSound port, once capture is enabled. */
    readonly onEsSound: Event<{
        sim: SimHandle;
        commands: number[];
    }>;
    protected readonly onSramEmitter: Emitter<{
        sim: SimHandle;
        runs: SramRun[];
    }>;
    /** Touches of a simulation's save region, once capture is enabled. */
    readonly onSram: Event<{
        sim: SimHandle;
        runs: SramRun[];
    }>;
    protected readonly onSpeedEmitter: Emitter<Speed>;
    /**
     * How fast emulation is actually running, about once a second and once
     * more when it suspends. Not the requested speed: an unaffordable fast
     * forward is clamped, so this is the only reliable account of it.
     */
    readonly onSpeed: Event<Speed>;
    protected readonly onPointerWriteEmitter: Emitter<{
        sim: SimHandle;
        address: number;
        values: number[];
    }>;
    /** Values written to the address a simulation is watching, if any. */
    readonly onPointerWrite: Event<{
        sim: SimHandle;
        address: number;
        values: number[];
    }>;
    protected readonly onDigestEmitter: Emitter<{
        sim: SimHandle;
        frame: number;
        digest: number;
    }>;
    /**
     * A machine's digest, taken at a frame boundary because
     * {@link Sim.setDigestPeriod} asked for one.
     *
     * On the core rather than the simulation because the listener — a link
     * session — wants both of its machines' digests in one place, and has to
     * tell them apart by handle anyway.
     */
    readonly onDigest: Event<{
        sim: SimHandle;
        frame: number;
        digest: number;
    }>;
    protected readonly onProgressEmitter: Emitter<{
        frame: number;
    }>;
    /**
     * How far the machines have got, a few times a frame's worth apart.
     *
     * Only sent while something is under lockstep — see `progress` in
     * `vb-protocol.ts`. A link session schedules against this.
     */
    readonly onProgress: Event<{
        frame: number;
    }>;
    protected readonly onAwaitingInputEmitter: Emitter<{
        waiting: boolean;
        frame: number;
        sims: SimHandle[];
    }>;
    /**
     * The drive loop started or stopped waiting for scheduled input.
     *
     * Only fires for a session running under lockstep — see `queueKeys` in
     * `vb-protocol.ts` — and only on the change, so it can drive a "waiting
     * for the other player" state directly.
     */
    readonly onAwaitingInput: Event<{
        waiting: boolean;
        frame: number;
        sims: SimHandle[];
    }>;
    protected readonly onStoppedEmitter: Emitter<{
        sim: SimHandle;
        address: number;
        reason: StopReason;
    }>;
    /**
     * A simulation stopped on an instruction, and emulation was suspended.
     *
     * Not something the host asked for, which is why it is an event: a
     * breakpoint suspends the machine from underneath whoever thought it was
     * running, and anything showing whether the game is paused has to hear
     * about it or start lying.
     */
    readonly onStopped: Event<{
        sim: SimHandle;
        address: number;
        reason: StopReason;
    }>;
    protected readonly onStalledEmitter: Emitter<{
        frames: number;
    }>;
    /**
     * The core stopped advancing and emulation was suspended by the worker.
     *
     * Rare and not an error — see `stalled` in `vb-protocol.ts`. A listener
     * should say so and offer a reset; the picture is frozen either way.
     */
    readonly onStalled: Event<{
        frames: number;
    }>;
    protected readonly onRetroAchievementsEmitter: Emitter<VesRaEvent>;
    /**
     * One message at a time from the achievement engine, unpacked from the
     * batches the worker sends. The RetroAchievements service is the only
     * listener; see `emulator-retroachievements.ts`.
     */
    readonly onRetroAchievements: Event<VesRaEvent>;
    protected disposed: boolean;
    protected constructor(worker: Worker, audioContext: AudioContext, audioNode: AudioWorkletNode, mainThreadVideo: boolean);
    static create(options: CoreOptions): Promise<Core>;
    /**
     * The size of this core build's state struct, as a build fingerprint.
     *
     * See `stateSize` in `vb-protocol.ts`; a link session compares it before
     * agreeing to play.
     */
    stateSize(): Promise<number>;
    createSim(): Promise<Sim>;
    /** Attach either the ordinary worker renderer or the WebKitGTK page renderer. */
    attachCanvas(sim: SimHandle, canvas: HTMLCanvasElement, mode: DisplayMode): Promise<void>;
    setMainThreadDisplayMode(sim: SimHandle, mode: DisplayMode): void;
    captureMainThread(sim: SimHandle, mode?: DisplayMode, scale?: number): Promise<ArrayBuffer>;
    detachCanvas(sim: SimHandle): void;
    /**
     * Take a copy of every frame a machine presents, or pass nothing to stop.
     *
     * What a video recording is built on. The handler is called with the same
     * uncomposited buffer a main-thread renderer would be given and must be
     * done with it when it returns — the buffer goes straight back to the
     * worker to be filled again, so anything worth keeping has to be uploaded
     * or copied there and then.
     */
    setVideoTap(sim: SimHandle, handle?: (frame: Frame) => void): Promise<void>;
    /**
     * The graph the emulator's own sound is played into.
     *
     * Exposed so that a recording can tap it — and so that anything else
     * playing alongside the machine can be mixed into the same context, which
     * is the only way two sources ever reach one recorded track. Nothing here
     * may retune it: it runs at the core's sample rate on purpose (see
     * {@link Core.create}), and its state follows emulation.
     */
    get audio(): AudioContext;
    /**
     * Send what the machine is playing to somewhere else as well.
     *
     * Additional to the speakers, never instead of them, and free: the worklet
     * is asked for its quantum once however many things are listening.
     */
    connectAudio(node: AudioNode): void;
    disconnectAudio(node: AudioNode): void;
    /**
     * Start emulating every simulation in this session.
     *
     * The audio is asked to start but never waited for. A page nobody has
     * touched yet may not play sound, and Firefox says so by leaving the
     * promise from `resume()` pending until someone does touch it — so
     * awaiting it here left the machine unstarted, and the picture black, in
     * the one window that is never clicked first: the second player's, which
     * the first player's window opens. The picture does not depend on the
     * audio, so it no longer waits for it; {@link armAudioUnlock} lets the
     * gesture that does arrive bring the sound with it.
     */
    run(): Promise<void>;
    suspend(): Promise<void>;
    /**
     * Put the audio graph where the last caller of {@link run} or
     * {@link suspend} asked for it.
     *
     * Both of those cross the worker before they are done, and the context is
     * the thing on the far side of that wait — so a pause and the resume that
     * follows it a moment later used to reach the context in whichever order
     * their round trips happened to finish in. Lose that race and the graph
     * ends up suspended while the worker emulates, which is not a quiet
     * mismatch: the drive loop is clocked by the worklet asking for samples
     * (see the head of `vb-worker.ts`), so the machine is frozen solid with
     * every control insisting it is running. Only the next pause and resume
     * put it back, which is exactly how long it looks like the emulator has
     * died.
     *
     * So the two say what they want and this applies it, one transition at a
     * time, re-reading the wish on the way out — the last word wins, whichever
     * transition is in flight when it is said.
     */
    protected settleAudio(): Promise<void>;
    protected driveAudio(): Promise<void>;
    /**
     * Whether the browser is still holding the audio back, and with it the
     * machine.
     *
     * Not a sound problem: the drive loop is clocked by the audio worklet
     * asking for samples — see the head of `vb-worker.ts` — so a context that
     * is not really producing emulates nothing at all. A window nobody has
     * touched is exactly that, which is why the second player's window shows a
     * black picture until they touch it.
     *
     * Asked of the clock, because `state` cannot answer it: Firefox reports
     * `running` for a context the autoplay policy is still holding back, and
     * `currentTime` standing still is the only thing that gives it away. Two
     * waits, because `resume()` is asynchronous even when it is allowed — the
     * first for the attempt to settle, or for `within` to pass if it never
     * does, and the second for the clock to have had a chance to move.
     */
    audioStillBlocked(within?: number): Promise<boolean>;
    /**
     * Start the audio again on the next thing the person does.
     *
     * Armed whenever the machine starts, without first asking whether the
     * audio needs it: `state` is not to be trusted for that — see
     * {@link audioStillBlocked} — and resuming a context that is already
     * producing costs nothing. One listener at a time, taken down by the first
     * gesture, because a second player pressing a button to play has made
     * exactly the gesture the browser was holding out for.
     */
    protected armAudioUnlock(): void;
    protected disarmAudioUnlock(): void;
    /**
     * Set the emulation rate, where 1 is real time. Above 1 fast forwards,
     * below 1 runs in slow motion.
     */
    setSpeed(speed: number): Promise<void>;
    /** Advance every simulation by one frame. Only useful while suspended. */
    stepFrame(): Promise<void>;
    /**
     * Configure the rewind history.
     *
     * Snapshots are stored uncompressed, so the budget divided by the state
     * size is how many are kept, and granularity trades resolution for
     * duration.
     */
    setRewind(enabled: boolean, granularity: number, budgetBytes: number): Promise<void>;
    /**
     * Step back up to `count` entries of history at once.
     *
     * Returns how many were applied, so a caller pacing playback can tell that
     * the history is exhausted. Stepping several entries in one call keeps the
     * intermediate states off the screen and costs a single round trip.
     */
    rewindStep(count?: number): Promise<number>;
    /** Log in with a password; resolves to the account and its API token. */
    raLoginPassword(username: string, password: string): Promise<VesRaUser>;
    /** Log in with a stored API token. */
    raLoginToken(username: string, token: string): Promise<VesRaUser>;
    raLogout(): Promise<void>;
    /** Feed the engine the answer to a server call it asked for. */
    raProvideResponse(requestId: number, status: number, body: string): Promise<void>;
    /** Unload the current set, keeping the account. */
    raUnloadGame(): Promise<void>;
    /** Tell the engine the machine was reset. */
    raReset(): Promise<void>;
    /**
     * Turn the achievement engine's hardcore flag on or off. Set before
     * {@link Sim.raLoadGame} so a set loads in the right mode.
     */
    raSetHardcore(enabled: boolean): Promise<void>;
    /**
     * One page of a leaderboard's entries. `firstEntry` is 1-based and
     * ignored when `aroundUser` asks for the page the player is in instead.
     */
    raFetchLeaderboardEntries(leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean): Promise<VesRaLeaderboardEntries>;
    request<K extends CommandName>(command: K, params: Params<K>, transfer?: Transferable[]): Promise<Result<K>>;
    protected onWorkerMessage(message: Outbound): void;
    dispose(): void;
}
/** One emulated Virtual Boy, belonging to a {@link Core} session. */
export declare class Sim implements Disposable {
    protected readonly core: Core;
    readonly handle: SimHandle;
    protected disposed: boolean;
    /** What this DOM-side handle last asked the worker to emulate. */
    protected vbcHardware: boolean;
    /** Mirrored so a page-side renderer can be configured before attachment. */
    protected displayMode: DisplayMode;
    protected readonly onRestartEmitter: Emitter<void>;
    /**
     * The machine has started over: reset, or a different cartridge in it.
     *
     * A simulation outlives both, so nothing downstream can tell either of
     * them from the machine simply carrying on — and anything holding a
     * picture of what this machine has done since it started needs to know,
     * because none of it is true any more. Fired here rather than in the
     * worker because both are requests made through this object.
     */
    readonly onRestart: Event<void>;
    constructor(core: Core, handle: SimHandle);
    /**
     * Attach the presentation canvas.
     *
     * Ordinarily control is transferred to the worker. On the Linux desktop
     * the element stays on this thread and receives transferred frame buffers,
     * because WebKitGTK cannot create the worker's WebGL context.
     */
    attachCanvas(canvas: HTMLCanvasElement): Promise<void>;
    setCartRom(rom: ArrayBuffer): Promise<void>;
    setCartRam(ram: ArrayBuffer): Promise<void>;
    /**
     * Cartridge save RAM, or the first `length` bytes of it.
     *
     * Ask for a length wherever one is known: the window is the whole 16 MiB
     * of Game Pak RAM, and this copies what it is asked for across a worker
     * boundary. {@link cartRamInfo} is how a caller finds out what to ask for.
     */
    getCartRam(length?: number): Promise<ArrayBuffer>;
    /** How big the save window is, and how far into it the game has written. */
    cartRamInfo(): Promise<{
        size: number;
        used: number;
    }>;
    reset(): Promise<void>;
    /** Select original Virtual Boy or VB Color hardware; activation remains software-controlled. */
    setHardwareMode(vbc: boolean): Promise<void>;
    get isVbcHardware(): boolean;
    /** Set the currently pressed buttons as a VbKey bitmask. */
    /**
     * Book a controller mask against a future frame.
     *
     * The frame-numbered counterpart of {@link setKeys}, for a session where
     * two machines have to see the same press on the same frame. See
     * `queueKeys` in `vb-protocol.ts`.
     */
    queueKeys(frame: number, keys: number): Promise<void>;
    /**
     * Book writes against a future frame.
     *
     * The frame-numbered counterpart of {@link setCheats} and
     * {@link writeMemory}, for a session where two machines have to see the
     * same change on the same frame. See `queueEdits` in `vb-protocol.ts`.
     */
    queueEdits(frame: number, edits: ScheduledEdit[]): Promise<void>;
    /** Refuse to run past the input booked with {@link queueKeys}. */
    setLockstep(enabled: boolean): Promise<void>;
    /**
     * A digest of everything the emulated program can see, with the frame it
     * was taken at. For telling two machines that should agree apart.
     */
    stateDigest(): Promise<{
        frame: number;
        digest: number;
    }>;
    /**
     * Report that digest every `frames` frames, or stop, with zero.
     *
     * Taken on a frame number rather than on request, so that two machines
     * that should be identical produce theirs at the same point in the run and
     * can be compared at all. Arrives as {@link Core.onDigest}.
     */
    setDigestPeriod(frames: number): Promise<void>;
    /** This machine's handle, for telling its events from another's. */
    get id(): SimHandle;
    setKeys(keys: number): Promise<void>;
    /**
     * Select the display mode. This also resizes the presentation surface,
     * since the stereo layouts present at different geometries.
     */
    setDisplayMode(mode: DisplayMode): Promise<void>;
    /**
     * Encode the currently presented frame as a PNG.
     *
     * With no `mode` this is what is on screen, at its own size. With one, the
     * frame is composed again to it — a screenshot need not be the mode, the
     * palette or the size the game is being played in.
     */
    capture(mode?: DisplayMode, scale?: number): Promise<ArrayBuffer>;
    /**
     * Take a copy of every frame this machine presents, for a recording.
     *
     * Pass nothing to stop. See {@link Core.setVideoTap} for what the handler
     * may and may not do with the buffer it is given.
     */
    setVideoTap(handle?: (frame: Frame) => void): Promise<void>;
    /** Snapshot the entire machine. */
    saveState(): Promise<ArrayBuffer>;
    /** Restore a snapshot. The buffer is transferred. */
    loadState(state: ArrayBuffer): Promise<void>;
    /**
     * Start recording this session so it can be profiled afterwards.
     *
     * Costs a snapshot now and a few bytes per frame after — the input, not
     * the execution. What makes that enough is that emulation is
     * deterministic: replaying the same input from the same state reproduces
     * the run exactly, so the profile can be collected later and exhaustively
     * rather than sampled while the game is trying to run.
     */
    startProfileRecording(): Promise<void>;
    /** Stop recording and take what was recorded. */
    stopProfileRecording(): Promise<Recording>;
    /**
     * Replay a recording and collect a call tree from every instruction in it.
     *
     * Runs on a simulation of its own, so this one carries on undisturbed, but
     * it occupies the worker until it finishes — roughly a sixth of the time
     * that was recorded.
     */
    replayProfile(recording: Recording): Promise<ProfileResult>;
    /**
     * Follow every instruction as it runs, keeping a per-frame profile.
     *
     * The other kind of profiling: `startProfileRecording` writes down input
     * now and collects the answer afterwards, this measures the run as it
     * happens so a panel can show where the current frame is going. It costs a
     * callback on every instruction, so whoever switches it on owns switching
     * it off again.
     */
    setLiveProfiler(enabled: boolean, window?: number): Promise<void>;
    /**
     * The last window of profiled frames, or undefined if none is being kept.
     *
     * @param pin a frame to unpack alongside the aggregate, by its number. It
     *     comes back only while that frame is still in the window.
     */
    readLiveProfile(pin?: number): Promise<LiveProfileSnapshot | undefined>;
    /**
     * Wire this simulation to another over the link port, or pass null to
     * disconnect. The peer must belong to the same session.
     *
     * `order` is which end of the cable *this* simulation is, and the peer
     * takes the other. Both windows of a link session name the same end for
     * the same player's machine, which is what makes them emulate the pair
     * identically — see `setPeer` in `vb-protocol.ts`.
     */
    setPeer(peer: Sim | undefined, order?: 1 | 2): Promise<void>;
    /** Read a window of the address space as the CPU sees it. */
    /**
     * Read a rectangle of the composited framebuffer as RGBA bytes.
     *
     * The core composites eye-packed, so the red channel is the left eye's
     * brightness and the green channel the right eye's.
     */
    readPixels(x: number, y: number, width: number, height: number): Promise<ArrayBuffer>;
    /**
     * The framebuffer averaged into a stereo grid — legacy brightness or VBC
     * RGB555, as identified by the result. See the protocol for why it is
     * averaged over there rather than here.
     */
    readBackdrop(columns: number, rows: number): Promise<Backdrop>;
    /**
     * Recomposite and present this simulation's current video state.
     *
     * Costs one frame's worth of compositing and changes nothing else. Only
     * worth asking for while the machine is paused: running, the next frame
     * break does it anyway.
     */
    refreshFrame(): Promise<void>;
    readMemory(address: number, length: number): Promise<ArrayBuffer>;
    /** Write bytes into the address space. The buffer is transferred. */
    writeMemory(address: number, data: ArrayBuffer): Promise<void>;
    readRegisters(): Promise<Registers>;
    /**
     * Disassemble from an address, or from `before` instructions earlier.
     *
     * Going backwards is the core's job rather than ours: instructions here
     * are two or four bytes and nothing in the bytes before an address says
     * which, so only something that decodes forwards from a known point can
     * say where the previous instruction began.
     */
    disassemble(address: number, count: number, before?: number): Promise<DisassemblyLine[]>;
    /**
     * Arm this simulation's breakpoints, as the whole set.
     *
     * An empty list disarms them and takes the per-instruction callback back
     * off the core, which is where the cost of having any lives.
     */
    setBreakpoints(addresses: number[]): Promise<void>;
    /** Run one instruction and stop on the next. Only while suspended. */
    stepInstruction(): Promise<void>;
    /**
     * Arm a one-shot stop at an address. The caller resumes into it.
     *
     * Two calls rather than one because starting the machine belongs to
     * whoever owns the pause — see `runTo` in `vb-protocol.ts`.
     */
    runTo(address: number): Promise<void>;
    /** This simulation stopping on an instruction; see {@link Core.onStopped}. */
    onStopped(listener: (stop: {
        address: number;
        reason: StopReason;
    }) => void): Disposable;
    /**
     * Start or stop watching the terminal port for this simulation.
     *
     * Capturing costs a callback on every CPU write, so it should only be on
     * while something is displaying the output.
     */
    setTerminalCapture(enabled: boolean): Promise<void>;
    /** Terminal output from this simulation, ignoring any others in the session. */
    onTerminal(listener: (text: string) => void): Disposable;
    /**
     * Start or stop watching the link port for bytes sent over it.
     *
     * Costs a callback on every CPU write while it is on, so it belongs on
     * only while something is on the other end of the cable to receive them.
     */
    setLinkCapture(enabled: boolean): Promise<void>;
    /** Link port traffic from this simulation, ignoring any others in the session. */
    onLink(listener: (bytes: number[]) => void): Disposable;
    /**
     * Watch the ESSound port, or stop watching it. Costs the same callback on
     * every CPU write the captures above do, so it is left off unless the ROM
     * has audio files for it to play.
     */
    setEsSoundCapture(enabled: boolean): Promise<void>;
    /** Halfwords this simulation wrote to the ESSound port, once watched. */
    onEsSound(listener: (commands: number[]) => void): Disposable;
    /**
     * Watch the cartridge's save region, or stop watching it.
     *
     * Costs a call out of the core on every access to it, so — like the
     * captures above — it is on only while something is looking, and the two
     * directions are asked for separately because a game reads its save far
     * more often than it writes one. Both false is off.
     */
    setSramCapture(writes: boolean, reads: boolean): Promise<void>;
    /** Touches of this simulation's save region, once watched. */
    onSram(listener: (runs: SramRun[]) => void): Disposable;
    /**
     * Follow a pointer variable, reporting each 32-bit value stored to it, or
     * pass 0 to stop. One address at a time, and it costs the same callback on
     * every CPU write that the captures above do.
     */
    /**
     * Repeat these writes at every frame break, or none to stop.
     *
     * The core applies them itself rather than the caller writing on a timer;
     * see the protocol's setCheats.
     */
    setCheats(codes: VbCheatWrite[]): Promise<void>;
    setPointerWatch(address: number): Promise<void>;
    /** Values stored to the watched address by this simulation. */
    onPointerWrite(listener: (values: number[]) => void): Disposable;
    /**
     * The VSU as it stands: its map (VB_VSU_BASE, VB_VSU_MAP_BYTES bytes — the
     * waveform banks, the modulation table and the six channel register
     * blocks) and how loud its last frame of sound was.
     *
     * Composed by the worker from the core's own state rather than read out of
     * the VSU's address range, which real hardware and this core both refuse.
     * Rejects, with what it was looking for, on a core whose VSU state cannot
     * be found. See readVsu in `vb-protocol.ts`.
     */
    readVsu(): Promise<VsuReading>;
    /**
     * Silence channels of this machine's VSU without the game knowing, or
     * — with no bits set — let them all sound again.
     *
     * The emulator's own mixer rather than a write to the VSU, so the game's
     * state is left exactly as it was and the panel goes on showing what each
     * muted channel is playing. See setVsuMutes in `vb-protocol.ts`.
     */
    setVsuMutes(channels: number): Promise<void>;
    /**
     * Start or stop noting which palettes are painting the picture.
     *
     * Costs the same callback on every CPU write the captures above do, so it
     * is on only while somebody is looking at the answer — the color editor,
     * which is the only thing that asks.
     */
    setDrawnPaletteCapture(enabled: boolean): Promise<void>;
    /**
     * The palettes drawn since the last call, as a 256-bit set; taking it
     * clears it. All zero until setDrawnPaletteCapture(true).
     */
    takeDrawnPalettes(): Promise<ArrayBuffer>;
    /**
     * Identify this simulation's ROM by its RetroAchievements hash and load its
     * achievement set.
     *
     * Returns as soon as the request is in flight; the outcome arrives on
     * {@link Core.onRetroAchievements}.
     */
    raLoadGame(hash: string): Promise<void>;
    /** Output volume, 0 to 10. */
    setVolume(volume: number): Promise<void>;
    /** Stereo panning, -1 to +1. */
    setPanning(panning: number): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=vb-core.d.ts.map