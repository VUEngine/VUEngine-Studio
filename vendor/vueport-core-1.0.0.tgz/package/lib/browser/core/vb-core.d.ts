import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { LiveProfileSnapshot } from '../../common/emulator-live-profile';
import { DisplayMode, DisplayOutput } from '../../common/vb-constants';
import { VbCheatWrite, ScheduledEdit, LinkJournalEntry, CommandName, Backdrop, DisassemblyLine, Frame, ProfileResult, Recording, Registers, Outbound, Params, Result, RewindHistory, SimHandle, Speed, SramRun, StopReason, StopWrite, VesRaEvent, VesRaLeaderboardEntries, VesRaUser, VsuReading } from '../../common/vb-protocol';
import { VbRenderer } from '../../worker/vb-renderer';
export interface CoreOptions {
    workerUrl: string;
    audioWorkletUrl: string;
    wasmUrl: string;
    rcheevosModuleUrl?: string;
    mainThreadVideo?: boolean;
}
export declare class Core implements Disposable {
    protected readonly worker: Worker;
    protected readonly audioContext: AudioContext;
    protected readonly audioNode: AudioWorkletNode;
    readonly mainThreadVideo: boolean;
    protected readonly mainThreadRenderers: Map<number, {
        presentation: number;
        renderer: VbRenderer;
    }>;
    protected nextPresentation: number;
    protected screenshotRenderer: VbRenderer | undefined;
    protected readonly videoTapHandlers: Map<number, Map<string, (frame: Frame) => void>>;
    protected readonly videoTaps: Map<number, number>;
    protected videoTapSync: Promise<void>;
    protected readonly pageHolders: Map<number, Set<string>>;
    protected readonly pagesHeld: Set<number>;
    protected audioUnlock: (() => void) | undefined;
    protected audioResume: Promise<void> | undefined;
    protected static readonly AUDIO_TRANSITION_TIMEOUT_MS = 500;
    protected audioWanted: boolean;
    protected audioApplied: boolean;
    protected audioSettling: Promise<void> | undefined;
    protected readonly onDidUnblockAudioEmitter: Emitter<void>;
    readonly onDidUnblockAudio: Event<void>;
    protected readonly pending: Map<number, {
        resolve: (result: unknown) => void;
        reject: (error: Error) => void;
    }>;
    protected nextRequestId: number;
    protected readonly onErrorEmitter: Emitter<string>;
    readonly onError: Event<string>;
    protected readonly onTerminalEmitter: Emitter<{
        sim: SimHandle;
        text: string;
    }>;
    readonly onTerminal: Event<{
        sim: SimHandle;
        text: string;
    }>;
    protected readonly onLinkEmitter: Emitter<{
        sim: SimHandle;
        bytes: number[];
    }>;
    readonly onLink: Event<{
        sim: SimHandle;
        bytes: number[];
    }>;
    protected readonly onEsSoundEmitter: Emitter<{
        sim: SimHandle;
        commands: number[];
    }>;
    readonly onEsSound: Event<{
        sim: SimHandle;
        commands: number[];
    }>;
    protected readonly onSramEmitter: Emitter<{
        sim: SimHandle;
        runs: SramRun[];
    }>;
    readonly onSram: Event<{
        sim: SimHandle;
        runs: SramRun[];
    }>;
    protected readonly onSpeedEmitter: Emitter<Speed>;
    readonly onSpeed: Event<Speed>;
    protected readonly onPointerWriteEmitter: Emitter<{
        sim: SimHandle;
        address: number;
        values: number[];
    }>;
    readonly onPointerWrite: Event<{
        sim: SimHandle;
        address: number;
        values: number[];
    }>;
    protected readonly onDigestEmitter: Emitter<{
        sim: SimHandle;
        frame: number;
        digest: number;
    }>;
    readonly onDigest: Event<{
        sim: SimHandle;
        frame: number;
        digest: number;
    }>;
    protected readonly onProgressEmitter: Emitter<{
        frame: number;
    }>;
    readonly onProgress: Event<{
        frame: number;
    }>;
    protected readonly onAwaitingInputEmitter: Emitter<{
        waiting: boolean;
        frame: number;
        sims: SimHandle[];
    }>;
    readonly onAwaitingInput: Event<{
        waiting: boolean;
        frame: number;
        sims: SimHandle[];
    }>;
    protected readonly onPixelOriginsEmitter: Emitter<{
        sim: SimHandle;
        runs: ArrayBuffer;
    }>;
    readonly onPixelOrigins: Event<{
        sim: SimHandle;
        runs: ArrayBuffer;
    }>;
    protected readonly onStoppedEmitter: Emitter<{
        sim: SimHandle;
        address: number;
        reason: StopReason;
        write?: StopWrite;
    }>;
    readonly onStopped: Event<{
        sim: SimHandle;
        address: number;
        reason: StopReason;
        write?: StopWrite;
    }>;
    protected readonly onStalledEmitter: Emitter<{
        frames: number;
    }>;
    readonly onStalled: Event<{
        frames: number;
    }>;
    protected readonly onRetroAchievementsEmitter: Emitter<VesRaEvent>;
    readonly onRetroAchievements: Event<VesRaEvent>;
    protected disposed: boolean;
    protected constructor(worker: Worker, audioContext: AudioContext, audioNode: AudioWorkletNode, mainThreadVideo: boolean);
    static create(options: CoreOptions): Promise<Core>;
    stateSize(): Promise<number>;
    createSim(): Promise<Sim>;
    attachCanvas(sim: SimHandle, canvas: HTMLCanvasElement, mode: DisplayMode, output?: DisplayOutput): Promise<void>;
    setMainThreadDisplayMode(sim: SimHandle, mode: DisplayMode): void;
    setMainThreadDisplayOutput(sim: SimHandle, output: DisplayOutput | undefined): void;
    captureMainThread(sim: SimHandle, mode?: DisplayMode, scale?: number): Promise<ArrayBuffer>;
    detachCanvas(sim: SimHandle): void;
    setVideoTap(sim: SimHandle, handle?: (frame: Frame) => void, owner?: string, replacesPage?: boolean): Promise<void>;
    forgetPageHold(sim: SimHandle): void;
    protected syncPageHold(sim: SimHandle): Promise<void>;
    protected syncVideoTap(sim: SimHandle): Promise<void>;
    get audio(): AudioContext;
    connectAudio(node: AudioNode): void;
    disconnectAudio(node: AudioNode): void;
    /**
     * The audio is asked to start but never waited for. Firefox leaves the promise from `resume()` pending until
     * an untouched page is touched, so awaiting it left the machine unstarted and the picture black in the window
     * that is never clicked first: the second player's. armAudioUnlock lets the gesture bring the sound later.
     */
    run(): Promise<void>;
    protected traceAudioClock(): Promise<void>;
    suspend(): Promise<void>;
    /**
     * Put the audio graph where the last caller of run or suspend asked for it, one transition at a time,
     * re-reading the wish on the way out so the last word wins. Both cross the worker first, so a pause and a quick
     * resume used to reach the context in either order; losing that race left the graph suspended while the worker
     * emulates, and since the drive loop is clocked by the worklet asking for samples (see vb-worker.ts), the
     * machine froze with every control saying it was running.
     */
    protected settleAudio(): Promise<void>;
    protected driveAudio(): Promise<void>;
    /**
     * Whether the browser is still holding the audio back, and with it the machine: the drive loop is clocked by
     * the worklet asking for samples (see vb-worker.ts), so an untouched window emulates nothing and stays black.
     * Asked of the clock, because Firefox reports `running` for a context the autoplay policy still holds back.
     * Two waits, as resume() is asynchronous even when allowed: for the attempt to settle (or `within`), then for
     * the clock to have had a chance to move.
     */
    audioStillBlocked(within?: number): Promise<boolean>;
    resumeAudio(): void;
    /**
     * Suspend and resume the audio if the machine should run but its clock stands still; says whether it had to.
     * For a host that just moved the audio into or out of a headset: a Quest switches the output device, and a
     * context made before the switch can keep reporting `running` with a frozen clock. resume() does nothing for a
     * running context; a suspend first makes the browser open the output afresh.
     */
    restartStalledAudio(): Promise<boolean>;
    protected armAudioUnlock(): void;
    protected disarmAudioUnlock(): void;
    setSpeed(speed: number): Promise<void>;
    setStereoDepth(depth: number): Promise<void>;
    setColumnGeometry(enabled: boolean): Promise<void>;
    setMirrorSpinUp(enabled: boolean, fullDelay: boolean): Promise<void>;
    stepFrame(): Promise<void>;
    setRewind(enabled: boolean, granularity: number, budgetBytes: number): Promise<void>;
    rewindStep(count?: number): Promise<number>;
    rewindSeek(index: number): Promise<number>;
    rewindThumbnailMainThread(sim: SimHandle, index: number): Promise<ArrayBuffer | undefined>;
    raLoginPassword(username: string, password: string): Promise<VesRaUser>;
    raLoginToken(username: string, token: string): Promise<VesRaUser>;
    raLogout(): Promise<void>;
    raProvideResponse(requestId: number, status: number, body: string): Promise<void>;
    raUnloadGame(): Promise<void>;
    raReset(): Promise<void>;
    raSetHardcore(enabled: boolean): Promise<void>;
    raFetchLeaderboardEntries(leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean): Promise<VesRaLeaderboardEntries>;
    request<K extends CommandName>(command: K, params: Params<K>, transfer?: Transferable[]): Promise<Result<K>>;
    protected onWorkerMessage(message: Outbound): void;
    dispose(): void;
}
export declare class Sim implements Disposable {
    protected readonly core: Core;
    readonly handle: SimHandle;
    protected disposed: boolean;
    protected vbcHardware: boolean;
    protected displayMode: DisplayMode;
    protected displayOutput: DisplayOutput | undefined;
    protected cartRomDigest: number | undefined;
    protected esSoundCapture: boolean;
    protected readonly onRestartEmitter: Emitter<void>;
    readonly onRestart: Event<void>;
    constructor(core: Core, handle: SimHandle);
    attachCanvas(canvas: HTMLCanvasElement): Promise<void>;
    setCartRom(rom: ArrayBuffer): Promise<void>;
    setCartRam(ram: ArrayBuffer): Promise<void>;
    getCartRam(length?: number): Promise<ArrayBuffer>;
    cartRamInfo(): Promise<{
        size: number;
        used: number;
    }>;
    reset(): Promise<void>;
    setHardwareMode(vbc: boolean): Promise<void>;
    get isVbcHardware(): boolean;
    queueKeys(frame: number, keys: number): Promise<void>;
    queueEdits(frame: number, edits: ScheduledEdit[]): Promise<void>;
    setLockstep(enabled: boolean): Promise<void>;
    stateDigest(): Promise<{
        frame: number;
        digest: number;
    }>;
    setDigestPeriod(frames: number): Promise<void>;
    linkJournal(): Promise<LinkJournalEntry[]>;
    get id(): SimHandle;
    setKeys(keys: number): Promise<void>;
    setTurbo(keys: number, rate: number): Promise<void>;
    setDisplayMode(mode: DisplayMode): Promise<void>;
    setDisplayOutput(output: DisplayOutput | undefined): Promise<void>;
    capture(mode?: DisplayMode, scale?: number): Promise<ArrayBuffer>;
    rewindHistory(): Promise<RewindHistory>;
    rewindThumbnail(index: number): Promise<ArrayBuffer | undefined>;
    readFrame(): Promise<Frame & {
        previous: Frame[];
    }>;
    setVideoTap(handle?: (frame: Frame) => void, owner?: string, replacesPage?: boolean): Promise<void>;
    saveState(): Promise<ArrayBuffer>;
    loadState(state: ArrayBuffer, options?: {
        clearCaches?: boolean;
    }): Promise<void>;
    startProfileRecording(): Promise<void>;
    stopProfileRecording(): Promise<Recording>;
    replayProfile(recording: Recording): Promise<ProfileResult>;
    setLiveProfiler(enabled: boolean, window?: number): Promise<void>;
    readLiveProfile(pin?: number): Promise<LiveProfileSnapshot | undefined>;
    setPeer(peer: Sim | undefined, order?: 1 | 2): Promise<void>;
    readPixels(x: number, y: number, width: number, height: number): Promise<ArrayBuffer>;
    readBackdrop(columns: number, rows: number): Promise<Backdrop>;
    refreshFrame(): Promise<void>;
    readMemory(address: number, length: number): Promise<ArrayBuffer>;
    writeMemory(address: number, data: ArrayBuffer): Promise<void>;
    readRegisters(): Promise<Registers>;
    disassemble(address: number, count: number, before?: number): Promise<DisassemblyLine[]>;
    setBreakpoints(addresses: number[]): Promise<void>;
    stepInstruction(): Promise<void>;
    runTo(address: number): Promise<void>;
    onStopped(listener: (stop: {
        address: number;
        reason: StopReason;
        write?: StopWrite;
    }) => void): Disposable;
    setTerminalCapture(enabled: boolean): Promise<void>;
    onTerminal(listener: (text: string) => void): Disposable;
    setLinkCapture(enabled: boolean): Promise<void>;
    onLink(listener: (bytes: number[]) => void): Disposable;
    setEsSoundCapture(enabled: boolean): Promise<void>;
    isRunning(image: ArrayBuffer): boolean;
    get runningCartridge(): string | undefined;
    onEsSound(listener: (commands: number[]) => void): Disposable;
    setSramCapture(writes: boolean, reads: boolean): Promise<void>;
    onSram(listener: (runs: SramRun[]) => void): Disposable;
    setCheats(codes: VbCheatWrite[]): Promise<void>;
    setPixelOrigins(enabled: boolean): Promise<void>;
    readPixelOrigins(): Promise<Uint32Array | undefined>;
    streamPixelOrigins(enabled: boolean): Promise<void>;
    onPixelOrigins(listener: (origins: Uint32Array) => void): Disposable;
    setWriteStop(ranges: {
        address: number;
        length: number;
    }[]): Promise<void>;
    setPointerWatch(address: number): Promise<void>;
    onPointerWrite(listener: (values: number[]) => void): Disposable;
    readVsu(): Promise<VsuReading>;
    setVsuMutes(channels: number): Promise<void>;
    raLoadGame(hash: string): Promise<void>;
    setVolume(volume: number): Promise<void>;
    setPanning(panning: number): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=vb-core.d.ts.map