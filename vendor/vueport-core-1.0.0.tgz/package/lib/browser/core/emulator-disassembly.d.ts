import { DisassemblyLine } from '../../common/vb-protocol';
import { VesLineTable } from './emulator-line-table';
import { SymbolIndex } from './emulator-symbols';
export interface DisassemblyOwner {
    name: string;
    address: number;
    size: number;
}
export interface DisassemblyRow {
    line: DisassemblyLine;
    header?: DisassemblyOwner;
    owner?: DisassemblyOwner;
    targets: Map<number, {
        address: number;
        label: string;
    }>;
    loaded?: {
        address: number;
        label: string;
    };
    /**
     * True where this line begins inside the instruction before it. Never with a core that sizes instructions right;
     * one built before vbuCodeSize was corrected sizes a conditional branch at four bytes instead of two and lists the
     * second halfword after every branch, a seventh of a real build. Kept as a check so a non-instruction is never
     * drawn as one, whichever core is loaded.
     */
    adrift?: boolean;
    source?: {
        file: string;
        line: number;
    };
}
export declare function registerOf(operand: string): number | undefined;
export declare function targetOf(operand: string): number | undefined;
export declare function immediateOf(operand: string): number | undefined;
/**
 * Everything the panel can say about a listing, in one pass, as two of the answers need the surrounding lines: a
 * header appears where the routine changes, and a pointer is built by a movhi and finished by a movea some
 * instructions later. `romBytes` is the cartridge's size, which turns a program counter in the mirror at the top
 * of memory back into a ROM offset.
 */
export declare function annotateDisassembly(lines: DisassemblyLine[], symbols: SymbolIndex | undefined, romBytes: number): DisassemblyRow[];
/**
 * Marks the rows where the source line changes. Apart from annotateDisassembly as it needs a build's .debug_line
 * rather than its symbol table. Modifies the rows in place, so a panel can add this when the line table turns up
 * without disassembling again. `romBytes` turns a program counter in the top mirror back into a row's offset.
 */
export declare function attachSourceLines(rows: DisassemblyRow[], lines: VesLineTable | undefined, romBytes: number): DisassemblyRow[];
//# sourceMappingURL=emulator-disassembly.d.ts.map