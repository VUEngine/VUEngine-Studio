import { DisassemblyLine } from '../../common/vb-protocol';
import { VesLineTable } from './emulator-line-table';
import { SymbolIndex } from './emulator-symbols';
/**
 * What a listing can be told about itself, given the build's symbols.
 *
 * Apart from the panel that draws it because it is the part worth checking
 * without a browser: everything here is a pure function of the lines and the
 * symbol index, and the only way to know it is right is to run it over a real
 * build and read the result.
 */
/** The routine a line belongs to, and what a header says about it. */
export interface DisassemblyOwner {
    name: string;
    address: number;
    /** As the linker recorded it; zero where it recorded none. */
    size: number;
}
/** One line of the listing, with everything that could be worked out about it. */
export interface DisassemblyRow {
    line: DisassemblyLine;
    /** Drawn above the line where the routine changes. */
    header?: DisassemblyOwner;
    /** The routine this instruction is in. */
    owner?: DisassemblyOwner;
    /** Operands that are addresses, by operand index, with what to call them. */
    targets: Map<number, {
        address: number;
        label: string;
    }>;
    /** What a `movhi`/`movea` pair built, once it turns out to name something. */
    loaded?: {
        address: number;
        label: string;
    };
    /**
     * True where the listing is out of step: this line begins inside the
     * instruction before it.
     *
     * Never, with a core that sizes instructions right. A core built before
     * `vbuCodeSize` was corrected sizes a conditional branch at four bytes
     * where its own CPU executes two, and then skips the instruction after
     * every branch and lists the second halfword of it instead — a seventh of
     * a real build. Kept as a check rather than dropped with the bug: a line
     * that is not an instruction must not be drawn as one, whichever core
     * happens to be loaded.
     */
    adrift?: boolean;
    /**
     * The source line this instruction came from, where it differs from the
     * line before it.
     *
     * Only where it differs, because that is what makes a mixed listing
     * readable: one line of C followed by the handful of instructions it
     * produced, rather than the same line repeated beside each of them.
     */
    source?: {
        file: string;
        line: number;
    };
}
/** The register an operand names, or undefined for anything else. */
export declare function registerOf(operand: string): number | undefined;
/**
 * A branch or call target: eight bare hex digits.
 *
 * Bare because that is how the worker asks for them — an immediate carries
 * `0x` and an address does not, which is what tells the two apart without
 * knowing the instruction.
 */
export declare function targetOf(operand: string): number | undefined;
/** A `0xNNNN` immediate's value, sign-extended the way the machine reads it. */
export declare function immediateOf(operand: string): number | undefined;
/**
 * Everything the panel can say about a listing, in one pass.
 *
 * One pass rather than one lookup per line because two of the three answers
 * need the lines around them: a header appears where the routine changes from
 * the line before, and a pointer is built by a `movhi` and finished by a
 * `movea` some instructions later, so what the registers hold has to be
 * carried along.
 *
 * @param romBytes the cartridge's size, which is what turns a program counter
 *   running in the mirror at the top of memory back into a ROM offset
 */
export declare function annotateDisassembly(lines: DisassemblyLine[], symbols: SymbolIndex | undefined, romBytes: number): DisassemblyRow[];
/**
 * Mark the rows where the source line changes.
 *
 * Separate from `annotateDisassembly` because it depends on something else
 * being available — a build's `.debug_line` rather than its symbol table —
 * and a listing that has the one and not the other should still get what it
 * can. The rows are modified in place, which is what lets a panel add this
 * when the line table turns up without disassembling again.
 *
 * @param romBytes the cartridge's size, which turns a program counter running
 *   in the mirror at the top of memory back into the offset a row is kept at
 */
export declare function attachSourceLines(rows: DisassemblyRow[], lines: VesLineTable | undefined, romBytes: number): DisassemblyRow[];
//# sourceMappingURL=emulator-disassembly.d.ts.map