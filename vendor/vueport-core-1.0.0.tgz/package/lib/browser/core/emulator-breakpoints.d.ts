import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { VesLineTable } from './emulator-line-table';
/**
 * Where the machine should stop, kept in one place for everything that sets
 * one.
 *
 * The Disassembly panel's gutter is one way in and not the only one: a host
 * with editors — VUEngine Studio — sets breakpoints on source lines, and both
 * have to mean the same thing to the machine. So the set lives here rather
 * than in the panel that happens to draw it, and whatever arms the core reads
 * it from here.
 *
 * Everything is keyed by address, because that is what the machine can stop
 * at. A breakpoint that came from a line remembers the line it came from, and
 * {@link VesBreakpoints.reresolve} is what carries it across a rebuild, when
 * the same line is at a different address.
 */
/** The source line a breakpoint was set on, for one that was. */
export interface VesBreakpointOrigin {
    /** As the line table names it, which is the file the compiler read. */
    file: string;
    line: number;
}
export interface VesBreakpoint {
    /** Where the machine stops. */
    address: number;
    /**
     * Off without being forgotten.
     *
     * An editor lets a breakpoint be disabled rather than removed, and losing
     * that distinction on the way here would make disabling one the same as
     * deleting it.
     */
    enabled: boolean;
    /** The line it was set on, for one that was set on a line. */
    origin?: VesBreakpointOrigin;
}
/** A line a host wants stopped at, before anything has resolved it. */
export interface VesLineBreakpoint {
    line: number;
    /** Left out for one that is simply on. */
    enabled?: boolean;
}
export declare class VesBreakpoints implements Disposable {
    protected readonly points: Map<number, VesBreakpoint>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    /**
     * Something about the set changed.
     *
     * Fired once per change rather than per breakpoint, because the only two
     * listeners either redraw a gutter or hand the core a whole new set —
     * neither is interested in which one moved.
     */
    readonly onDidChange: Event<void>;
    /** Every breakpoint, in address order, enabled or not. */
    all(): VesBreakpoint[];
    at(address: number): VesBreakpoint | undefined;
    /** The addresses the core should be stopping at, which is the enabled ones. */
    armed(): number[];
    has(address: number): boolean;
    /**
     * Put one at an address, or leave the one already there alone.
     *
     * Leaves it alone rather than replacing it so that a host re-sending its
     * editor breakpoints cannot quietly re-enable one somebody switched off
     * in the gutter.
     */
    add(address: number, origin?: VesBreakpointOrigin): void;
    remove(address: number): void;
    /** What clicking a gutter does. */
    toggle(address: number, origin?: VesBreakpointOrigin): void;
    setEnabled(address: number, enabled: boolean): void;
    clear(): void;
    /**
     * Take a whole file's breakpoints, as an editor has them.
     *
     * The whole file rather than one at a time, because that is the shape an
     * editor reports them in and because removals are otherwise invisible:
     * what is sent is what that file has, and anything this held for it and
     * did not hear about again is gone.
     *
     * Breakpoints from other files, and ones set on an address in the gutter,
     * are left alone — a file's editor has no business removing those.
     *
     * A line that generated no code resolves to the next one that did, which
     * is {@link VesLineTable.resolve}'s doing and what makes a breakpoint on
     * a blank line or a comment land somewhere sensible. Two lines resolving
     * to the same address collapse into one breakpoint, which is also what
     * the machine can do about them.
     */
    setForFile(file: string, lines: VesLineBreakpoint[], table: VesLineTable): void;
    /**
     * Point every line breakpoint at where its line is now.
     *
     * For a rebuild: the source did not move but the code did, and a
     * breakpoint still aimed at the old address would stop somewhere
     * arbitrary — or, worse, nowhere, and look like a debugger that ignores
     * you. Address-set breakpoints are left alone; nobody but the person who
     * typed one knows what it meant.
     */
    reresolve(table: VesLineTable): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-breakpoints.d.ts.map