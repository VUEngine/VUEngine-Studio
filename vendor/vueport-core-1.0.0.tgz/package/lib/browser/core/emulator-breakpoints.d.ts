import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { VesLineTable } from './emulator-line-table';
/**
 * Where the machine should stop, shared by the Disassembly panel's gutter and a host with editors (VUEngine
 * Studio) that sets breakpoints on source lines. Keyed by address, as that is what the machine stops at; a
 * breakpoint from a line remembers it, and VesBreakpoints.reresolve carries it across a rebuild.
 */
export interface VesBreakpointOrigin {
    file: string;
    line: number;
}
export interface VesBreakpoint {
    address: number;
    enabled: boolean;
    origin?: VesBreakpointOrigin;
}
export interface VesLineBreakpoint {
    line: number;
    enabled?: boolean;
}
export declare class VesBreakpoints implements Disposable {
    protected readonly points: Map<number, VesBreakpoint>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    all(): VesBreakpoint[];
    at(address: number): VesBreakpoint | undefined;
    armed(): number[];
    has(address: number): boolean;
    add(address: number, origin?: VesBreakpointOrigin): void;
    remove(address: number): void;
    toggle(address: number, origin?: VesBreakpointOrigin): void;
    setEnabled(address: number, enabled: boolean): void;
    clear(): void;
    /**
     * Takes a whole file's breakpoints as an editor has them, so removals become visible: anything held for that file
     * and not sent again is gone. Other files' and address-set ones are left alone.
     * A line without code resolves to the next one that has (VesLineTable.resolve); two lines resolving to the same
     * address collapse into one breakpoint.
     */
    setForFile(file: string, lines: VesLineBreakpoint[], table: VesLineTable): void;
    reresolve(table: VesLineTable): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-breakpoints.d.ts.map