import * as React from 'react';
import { Root } from 'react-dom/client';
import { VbPixelOrigin, VbPixelSource } from '../../common/vb-pixel-origin';
import { StopWrite } from '../../common/vb-protocol';
import { Disposable } from '../../common/emulator-events';
import { VesActor } from '../core/emulator-actors';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { ScreenPanel, VesScreenRect } from './emulator-screen-panel';
/**
 * The screen inspector: what drew each pixel of the picture, asked of the
 * picture itself.
 *
 * The core keeps, beside every pixel it draws, where the pixel came from —
 * the world, the BG map cell or object, the character and which of its
 * pixels, the palette, or the instruction that wrote it into the frame buffer
 * (see `vb-pixel-origin.ts`). This turns that into three things over the
 * Screen panel, all of them Debug mode's alone:
 *
 * - Picking: hovering the picture says what drew the pixel under the pointer
 *   and lights every pixel the same cell or object drew; a click pins the
 *   answer, with the way to it in the panels that show it.
 * - Views: the picture washed over by world, by what kind of thing drew it,
 *   by palette, or by VB Color palette.
 * - Whatever a panel points at — an object, a world, a cell, a character —
 *   lit pixel for pixel rather than as a box round it.
 *
 * The dock owns it, since the dock is what knows whether Debug mode is on and
 * which machine is being inspected; this only reads what it is handed.
 */
/** What the picture is washed over with, if anything. */
export type ScreenInspectorView = 'picture' | 'worlds' | 'kinds' | 'palettes' | 'vbc';
/** What the inspector needs of whoever owns it. */
export interface ScreenInspectorHost {
    /** The machine being inspected, or undefined before one has booted. */
    sim(): Sim | undefined;
    vbcHardwareActive(): boolean;
    /** The ROM's size in MBit, for naming code by the build's symbols. */
    romSize(): number;
    getSymbols(): Promise<SymbolIndex | undefined>;
    /** Show something in the panel that shows it, opening that if need be. */
    reveal(target: ScreenInspectorTarget): void;
    /** The view last chosen, kept across sessions. */
    rememberedView(): ScreenInspectorView;
    rememberView(view: ScreenInspectorView): void;
}
/**
 * What the inspector can send somebody to: a source of pixels, the code that
 * wrote some, an engine actor, or bytes to look at.
 */
export type ScreenInspectorTarget = VbPixelSource | {
    kind: 'code';
    address: number;
} | {
    kind: 'actor';
    address: number;
} | {
    kind: 'memory';
    address: number;
};
/** A point of the picture: which eye, and which of its pixels. */
interface ScreenPoint {
    eye: 0 | 1;
    x: number;
    y: number;
}
/** A point asked about, and where on the page the pointer was. */
interface Inspected extends ScreenPoint {
    origin: VbPixelOrigin;
    clientX: number;
    clientY: number;
}
export declare class ScreenInspector {
    protected readonly screen: ScreenPanel;
    protected readonly host: ScreenInspectorHost;
    /** Whether Debug mode is on, which is the only time any of this is. */
    protected enabled: boolean;
    protected picking: boolean;
    protected view: ScreenInspectorView;
    /** Two words a pixel, left eye then right, from the last read. */
    protected origins?: Uint32Array;
    protected hovered?: Inspected;
    protected pinned?: Inspected;
    /** What a panel is pointing at; see {@link setPanelSource}. */
    protected panelSource?: VbPixelSource;
    /** What a button on the pinned card is pointing at, while the pointer is on it. */
    protected cardSource?: VbPixelSource;
    protected symbols?: SymbolIndex;
    /** What a write stop is waiting on, while one is. */
    protected armed?: {
        label: string;
    };
    /** The write a stop caught, until it is put away. */
    protected caught?: {
        label: string;
        write: StopWrite;
    };
    /** A write stop that could not be laid, and why. */
    protected refused?: string;
    protected stopWatch?: Disposable;
    protected watchedSim?: Sim;
    /** The machine sending what drew each picture, while one is; see {@link stream}. */
    protected streamSim?: Sim;
    protected streamWatch?: Disposable;
    protected paintPending: boolean;
    protected readonly root: Root;
    /** Picking actors off the picture rather than pixels; see {@link renderActorCard}. */
    protected pickingActors: boolean;
    /** The actors as last read, while they are being picked. */
    protected actors?: VesActor[];
    protected actorTimer?: ReturnType<typeof setInterval>;
    protected readingActors: boolean;
    /** The actor under the pointer, the point it was found at, and where the pointer was. */
    protected hoveredActor?: {
        actor: VesActor;
        point: ScreenPoint;
        clientX: number;
        clientY: number;
    };
    /** Whether the game is one actors can be read out of: a VUEngine build with its debug sections. */
    protected actorsAvailable: boolean;
    /**
     * Whether what the Actors panel has selected is marked on the picture.
     * Not remembered, as it was not on the panel: it is about the actor in
     * front of you.
     */
    protected markingSelection: boolean;
    /** What the Actors panel has selected, as the rectangles its sprites were last drawn at. */
    protected selectionRects: VesScreenRect[];
    constructor(screen: ScreenPanel, host: ScreenInspectorHost);
    /** Kept up by the pin, whatever the pointer does. */
    protected barPinned: boolean;
    /** Up because the pointer has moved over the screen panel lately. */
    protected awake: boolean;
    /** The pointer is resting on the tools, which holds the countdown. */
    protected overTools: boolean;
    protected idleTimer?: ReturnType<typeof setTimeout>;
    /** Where a pointer that is not a mouse last counted as moving; see `STRIP_WAKE_DISTANCE`. */
    protected restingAt?: {
        x: number;
        y: number;
    };
    /** Whether anything of the tools' is on: picking, a view, a pinned card, a write stop or its answer. */
    protected busy(): boolean;
    protected readonly onPanelMove: (event: PointerEvent) => void;
    protected readonly wake: () => void;
    protected scheduleIdle(): void;
    protected sleep(): void;
    /** A mouse leaving the panel takes the tools with it; any other pointer leaves after every press, and the delay decides. */
    protected readonly onPanelLeave: (event: PointerEvent) => void;
    protected setBarPinned(pinned: boolean): void;
    /** On with Debug mode and off with it; off forgets everything that was being shown. */
    setEnabled(enabled: boolean): void;
    /**
     * What the Actors panel has selected, as the rectangles its sprites were
     * drawn at, or nothing — marked on the picture while marking is on.
     */
    setSelectionRects(rects: VesScreenRect[]): void;
    protected applySelection(): void;
    /** Light what a panel points at, pixel for pixel, or nothing. */
    setPanelSource(source: VbPixelSource | undefined): void;
    /** A different machine, or a new session: what was read was about the old one. */
    simChanged(): void;
    /** Find out whether this game has actors to pick, and drop the tools for it if not. */
    protected checkActors(): void;
    dispose(): void;
    protected readonly onPointerMove: (event: PointerEvent) => void;
    protected readonly onPointerLeave: () => void;
    /**
     * A click while picking pins what is under it, and is kept from the
     * picture: it is the inspector's, not a click on the game.
     */
    protected readonly onClick: (event: MouseEvent) => void;
    /** Escape lets go of a pinned answer, and then of picking. */
    protected readonly onKey: (event: KeyboardEvent) => void;
    protected inspect(point: ScreenPoint, clientX: number, clientY: number): Inspected;
    protected originAt(point: ScreenPoint): VbPixelOrigin;
    /** The two words the core keeps of a point, both zero (`unknown`) before any were read. */
    protected wordsAt(point: ScreenPoint): [number, number];
    protected setPicking(picking: boolean): void;
    /** Pick actors rather than pixels, or stop; the one turns the other off. */
    protected setActorPicking(on: boolean): void;
    /**
     * The actor that drew a point of the picture.
     *
     * Asked of the picture first: the object or world the core says drew the
     * pixel, and whose sprite that is — exact, transparent pixels and overlaps
     * included. Only where the core has nothing to say, as for a pixel no
     * sprite drew, is it asked of the rectangles the sprites were drawn at.
     */
    protected actorHit(point: ScreenPoint, clientX: number, clientY: number): {
        actor: VesActor;
        point: ScreenPoint;
        clientX: number;
        clientY: number;
    } | undefined;
    /** Read the actors while they are being picked: a running game moves them, and frees and builds them. */
    protected startActorReads(): void;
    protected stopActorReads(): void;
    /** What is under a pointer that has not moved, which a running game changes. */
    protected refreshHoveredActor(): void;
    protected setView(view: ScreenInspectorView): void;
    /** Whether anything shown needs the origins. */
    protected wanted(): boolean;
    protected sync(): void;
    /**
     * Have what drew each picture sent with the picture by the machine that
     * shows it, or stop. Sent rather than asked for, because asked for it
     * would be some frames behind a game in motion and the marks would trail
     * what they mark; and taken where the picture is taken, so that the two
     * are the same frame.
     */
    protected stream(sim: Sim | undefined): void;
    protected takeOrigins(sim: Sim, origins: Uint32Array | undefined): void;
    /** What is lit, pixel for pixel: a panel's pick before the pointer's. */
    protected litSource(): VbPixelSource | undefined;
    protected paint(): void;
    /** The wash and the lit pixels, an image per eye; undefined when there is neither. */
    protected layer(): {
        left: ImageData;
        right: ImageData;
    } | undefined;
    protected render(): void;
    protected button(id: string, label: string, on: boolean, icon: React.ReactNode, onClick: () => void): React.ReactNode;
    /** A write stop waiting, refused, or what it caught. */
    protected renderWriteNote(): React.ReactNode;
    /** What the colors of a view mean, where they mean something fixed. */
    protected renderLegend(): React.ReactNode;
    /** The last answer of {@link usedInView}, kept for as long as the origins and the view it was for. */
    protected usedCache?: {
        origins: Uint32Array;
        view: ScreenInspectorView;
        used: number[];
    };
    /**
     * The worlds, or the VB Color palettes, the picture is drawn with now, by
     * how many pixels each has — both eyes.
     */
    protected usedInView(): number[];
    /** Where a card goes for a pointer: away from it, on whichever side has the room. */
    protected cardStyle(clientX: number, clientY: number): React.CSSProperties;
    /** The actor under the pointer, while actors are being picked. */
    protected renderActorCard(hit: {
        actor: VesActor;
        clientX: number;
        clientY: number;
    }): React.ReactNode;
    /** What drew one pixel, following the pointer or pinned where it was clicked. */
    protected renderCard(at: Inspected, pinned: boolean): React.ReactNode;
    /** The way from a pinned answer to the panels that show what it names. */
    protected renderLinks(origin: VbPixelOrigin): React.ReactNode;
    /** Hear the inspected machine's stops while in Debug mode, for the write stops laid here. */
    protected watchStops(): void;
    /** Stop the machine after the next write to what drew a pixel. */
    protected armWriteStop(source: VbPixelSource): void;
    protected cancelWriteStop(): void;
    protected setCardSource(source: VbPixelSource | undefined): void;
    /** An instruction's address, with the function the build says it is in. */
    protected codeName(address: number): string;
}
export {};
//# sourceMappingURL=emulator-screen-inspector.d.ts.map