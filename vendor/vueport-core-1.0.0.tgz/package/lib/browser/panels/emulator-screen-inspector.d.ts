import * as React from 'react';
import { Root } from 'react-dom/client';
import { VbPixelOrigin, VbPixelSource } from '../../common/vb-pixel-origin';
import { StopWrite } from '../../common/vb-protocol';
import { Disposable } from '../../common/emulator-events';
import { VesActor } from '../core/emulator-actors';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { ScreenPanel, VesScreenRect } from './emulator-screen-panel';
/**
 * Screen inspector, Debug mode only: what drew each pixel, from the origin the core keeps beside every pixel
 * (world, BG map cell or object, character pixel, palette, or the writing instruction; see vb-pixel-origin.ts).
 * Picking: hover says what drew the pixel and lights everything the same cell or object drew, a click pins it
 * with links to the panels. Views: the picture washed by world, kind, palette or VB Color palette. And whatever
 * a panel points at is lit pixel for pixel. Owned by the dock, which knows the mode and the inspected machine
 */
export type ScreenInspectorView = 'picture' | 'worlds' | 'kinds' | 'palettes' | 'vbc';
export interface ScreenInspectorHost {
    sim(): Sim | undefined;
    vbcHardwareActive(): boolean;
    romSize(): number;
    getSymbols(): Promise<SymbolIndex | undefined>;
    reveal(target: ScreenInspectorTarget): void;
    rememberedView(): ScreenInspectorView;
    rememberView(view: ScreenInspectorView): void;
}
export type ScreenInspectorTarget = VbPixelSource | {
    kind: 'code';
    address: number;
} | {
    kind: 'actor';
    address: number;
} | {
    kind: 'memory';
    address: number;
};
interface ScreenPoint {
    eye: 0 | 1;
    x: number;
    y: number;
}
interface Inspected extends ScreenPoint {
    origin: VbPixelOrigin;
    clientX: number;
    clientY: number;
}
export declare class ScreenInspector {
    protected readonly screen: ScreenPanel;
    protected readonly host: ScreenInspectorHost;
    protected enabled: boolean;
    protected picking: boolean;
    protected view: ScreenInspectorView;
    protected origins?: Uint32Array;
    protected hovered?: Inspected;
    protected pinned?: Inspected;
    protected panelSource?: VbPixelSource;
    protected cardSource?: VbPixelSource;
    protected symbols?: SymbolIndex;
    protected armed?: {
        label: string;
    };
    protected caught?: {
        label: string;
        write: StopWrite;
    };
    protected refused?: string;
    protected stopWatch?: Disposable;
    protected watchedSim?: Sim;
    protected streamSim?: Sim;
    protected streamWatch?: Disposable;
    protected paintPending: boolean;
    protected readonly root: Root;
    protected pickingActors: boolean;
    protected actors?: VesActor[];
    protected actorTimer?: ReturnType<typeof setInterval>;
    protected readingActors: boolean;
    protected hoveredActor?: {
        actor: VesActor;
        point: ScreenPoint;
        clientX: number;
        clientY: number;
    };
    protected actorsAvailable: boolean;
    protected markingSelection: boolean;
    protected selectionRects: VesScreenRect[];
    constructor(screen: ScreenPanel, host: ScreenInspectorHost);
    protected barPinned: boolean;
    protected awake: boolean;
    protected overTools: boolean;
    protected idleTimer?: ReturnType<typeof setTimeout>;
    protected restingAt?: {
        x: number;
        y: number;
    };
    protected busy(): boolean;
    protected readonly onPanelMove: (event: PointerEvent) => void;
    protected readonly wake: () => void;
    protected scheduleIdle(): void;
    protected sleep(): void;
    protected readonly onPanelLeave: (event: PointerEvent) => void;
    protected setBarPinned(pinned: boolean): void;
    setEnabled(enabled: boolean): void;
    setSelectionRects(rects: VesScreenRect[]): void;
    protected applySelection(): void;
    setPanelSource(source: VbPixelSource | undefined): void;
    simChanged(): void;
    protected checkActors(): void;
    dispose(): void;
    protected readonly onPointerMove: (event: PointerEvent) => void;
    protected readonly onPointerLeave: () => void;
    protected readonly onClick: (event: MouseEvent) => void;
    protected readonly onKey: (event: KeyboardEvent) => void;
    protected inspect(point: ScreenPoint, clientX: number, clientY: number): Inspected;
    protected originAt(point: ScreenPoint): VbPixelOrigin;
    protected wordsAt(point: ScreenPoint): [number, number];
    protected setPicking(picking: boolean): void;
    protected setActorPicking(on: boolean): void;
    protected actorHit(point: ScreenPoint, clientX: number, clientY: number): {
        actor: VesActor;
        point: ScreenPoint;
        clientX: number;
        clientY: number;
    } | undefined;
    protected startActorReads(): void;
    protected stopActorReads(): void;
    protected refreshHoveredActor(): void;
    protected setView(view: ScreenInspectorView): void;
    protected wanted(): boolean;
    protected sync(): void;
    protected stream(sim: Sim | undefined): void;
    protected takeOrigins(sim: Sim, origins: Uint32Array | undefined): void;
    protected litSource(): VbPixelSource | undefined;
    protected paint(): void;
    protected layer(): {
        left: ImageData;
        right: ImageData;
    } | undefined;
    protected render(): void;
    protected button(id: string, label: string, on: boolean, icon: React.ReactNode, onClick: () => void): React.ReactNode;
    protected renderWriteNote(): React.ReactNode;
    protected renderLegend(): React.ReactNode;
    protected usedCache?: {
        origins: Uint32Array;
        view: ScreenInspectorView;
        used: number[];
    };
    protected usedInView(): number[];
    protected cardStyle(clientX: number, clientY: number): React.CSSProperties;
    protected renderActorCard(hit: {
        actor: VesActor;
        clientX: number;
        clientY: number;
    }): React.ReactNode;
    protected renderCard(at: Inspected, pinned: boolean): React.ReactNode;
    protected renderLinks(origin: VbPixelOrigin): React.ReactNode;
    protected watchStops(): void;
    protected armWriteStop(source: VbPixelSource): void;
    protected cancelWriteStop(): void;
    protected setCardSource(source: VbPixelSource | undefined): void;
    protected codeName(address: number): string;
}
export {};
//# sourceMappingURL=emulator-screen-inspector.d.ts.map