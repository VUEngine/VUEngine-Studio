import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Debounced } from '../components/kit/Utils';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
/**
 * One of the eight places the bus decodes to, and how much of it answers.
 *
 * Every region is {@link VB_REGION_BYTES} wide — that is what the three
 * decoded bits mean, and the list says so. What sits behind one is usually far
 * smaller and repeats across the rest: 64 KB of WRAM across the whole of
 * region 5, a handful of registers across the whole of region 2. `mapped` is
 * that part, and it is what the list walks, because scrolling 16 MB of WRAM
 * would be 256 passes over the same 64 KB — not browsing memory, browsing a
 * repeat.
 *
 * Both numbers are shown, because they answer different questions and a
 * caption giving only the second would be claiming region 2 is 64 bytes long,
 * which is not what any memory map of this machine says.
 */
export interface VbMemoryRegion {
    /** What the region is, spelled out. */
    label: string;
    /** What the map bar calls it. */
    short: string;
    /** Where it begins; it runs for {@link VB_REGION_BYTES} from here. */
    address: number;
    /**
     * How much of it answers with something of its own, before the mirrors
     * start. Zero for the one only the running machine knows — the cartridge
     * ROM, whose extent is the size of the ROM that was loaded.
     */
    mapped: number;
}
/**
 * The VCU aperture, offered only while a VB Color is running.
 *
 * Kept out of {@link VB_MEMORY_REGIONS} rather than grayed out in it: on an
 * original Virtual Boy there is nothing at `0x03000000` to jump to, and a
 * button that lands on a page of open bus is worse than no button.
 */
export declare const VCU_MEMORY_REGION: VbMemoryRegion;
export declare const VB_MEMORY_REGIONS: VbMemoryRegion[];
/** A region placed in the scrollable list. */
interface MappedRegion {
    region: VbMemoryRegion;
    /**
     * What answers, with the ROM's resolved from the ROM that is loaded. The
     * region itself is always {@link VB_REGION_BYTES}; this is the part of it
     * the list walks.
     */
    mapped: number;
    /** Data rows it contributes. */
    rows: number;
    /** Index of its caption row; the data rows follow it. */
    firstRow: number;
}
/** What is at a row of the list. */
interface MemoryRow {
    entry: MappedRegion;
    /** Absent for the caption row a region begins with. */
    address?: number;
}
/** A run of bytes that has been read, and where from. */
interface MemoryChunk {
    address: number;
    bytes: Uint8Array;
}
/** What the symbols say the selected byte is part of. */
interface MemoryWhere {
    /** The symbol, function or class it belongs to. */
    owner: string;
    /** How far into that it is. */
    offset: number;
    /** The field itself, where a layout was found for the object. */
    field?: string;
}
/** What a search is looking for, and how its bytes are compared. */
interface MemoryNeedle {
    bytes: Uint8Array;
    /**
     * Whether a letter matches either case. Set for a needle that was typed
     * as text, where {@link bytes} is already folded to lower case and the
     * memory being searched is folded a byte at a time to match it.
     */
    folded: boolean;
}
/**
 * Hex view of the address space.
 *
 * One list over the whole memory map rather than a page at a time: the regions
 * are laid end to end, each behind a caption saying what it is, and the list is
 * virtualized so that only what is on screen is ever read or rendered. Which
 * region the view is in drives the map bar above it, and picking one there
 * scrolls to it — the two are the same control read in both directions.
 *
 * Reads go through the CPU's view of memory rather than the state struct, so
 * mirroring and mapped hardware registers read exactly as the running program
 * sees them. Writes go out through {@link DebugSource.write} for the same
 * reason the VIP editors do: in a linked session a poke has to reach both
 * machines or the two stop running the same game.
 */
export declare class MemoryPanel extends Panel {
    /** Where the view was left, so reopening the panel returns to it. */
    protected address: number;
    /** The byte the inspector strip is reading, if any. */
    protected selected?: number;
    /** The regions as they are currently laid out, and what built that. */
    protected map: MappedRegion[];
    protected totalRows: number;
    protected mapSignature?: string;
    /** What has been read for the rows on screen. */
    protected chunks: MemoryChunk[];
    /** The four bytes at the selection, which the inspector strip decodes. */
    protected selectedBytes?: Uint8Array;
    /** Read for the watch list, coalesced into as few reads as it allows. */
    protected watchChunks: MemoryChunk[];
    /** When each byte on screen last changed, for the mark that fades. */
    protected readonly changedAt: Map<number, number>;
    /** Addresses pinned to the watch list, in the order they were pinned. */
    protected watches: number[];
    /** What the symbols say about {@link selected}, and which address it is for. */
    protected where?: MemoryWhere;
    protected whereFor?: number;
    /**
     * What will be searched for, which lags the box by {@link SEARCH_SETTLE_MS}.
     *
     * The box itself is uncontrolled, like the address box and for the same
     * reason: what is being typed lives in the DOM, where a redraw ten times a
     * second cannot reach it.
     */
    protected search: string;
    /** Set when the last search ran out without finding anything. */
    protected searchMissed: boolean;
    protected searching: boolean;
    protected readonly searchInput: React.RefObject<HTMLInputElement>;
    protected readonly settleSearch: Debounced<[string]>;
    /** The first nibble of a byte being typed over, before the second arrives. */
    protected pending?: {
        address: number;
        nibble: number;
    };
    protected scroller?: HTMLDivElement;
    protected scrollTop: number;
    protected viewportHeight: number;
    protected resize?: ResizeObserver;
    /**
     * The region scrubber's width, measured rather than expressed in percent.
     *
     * Its thumb has a minimum size, so where it sits is not a share of the
     * track but a position along what is left of the track once the thumb is
     * taken out of it — which is a length, and needs one to work from.
     */
    protected locatorWidth: number;
    protected locatorResize?: ResizeObserver;
    /** A scroll position to apply once the rows behind it have been rendered. */
    protected pendingScrollTop?: number;
    /**
     * Where in its thumb each scrollbar was taken hold of, while it is being
     * dragged. Undefined for one nobody has hold of.
     */
    protected railGrab?: number;
    protected locatorGrab?: number;
    /**
     * The region the locator is scrubbing.
     *
     * Held for the length of the drag rather than read from the view each
     * time: the point of the control is to move within one region, and a
     * rounding that put the top row a byte outside it would otherwise hand the
     * rest of the drag to its neighbour.
     */
    protected locatorEntry?: MappedRegion;
    /** Guards the poll against a read it has not finished yet. */
    protected reading: boolean;
    protected readAgain: boolean;
    /**
     * The address box, which is uncontrolled so that polling cannot overwrite
     * a half-typed address. Its value therefore lives in the DOM rather than
     * here, and is put back in step after each render — but only while nobody
     * is typing into it. See {@link onUpdateRequest}.
     */
    protected readonly addressInput: React.RefObject<HTMLInputElement>;
    constructor(source: DebugSource, instanceId: string);
    /**
     * Lay the regions out, if what they are made of has changed.
     *
     * The ROM's extent is the only part that moves, and it moves when a ROM is
     * loaded; the VCU appears and disappears with the hardware gate. Anything
     * else would rebuild this ten times a second for nothing.
     */
    protected rebuildMap(): void;
    /** The placed region an address falls in, by the three bits the bus decodes. */
    protected entryOf(address: number): MappedRegion | undefined;
    /**
     * An address as the list holds it.
     *
     * Every region is mirrored across its 16 MB, so an address anywhere in one
     * names a byte the list already shows once — the interrupt vectors at
     * `0xFFFFFE00` are the top of the cartridge seen through region 7's mirror,
     * and typing them should land on those ROM bytes rather than on nothing.
     * Undefined for a region with nothing in it, which is the honest answer for
     * `0x03000000` on a machine that is not a VB Color.
     */
    protected canonical(address: number): number | undefined;
    /** What is at a row of the list. */
    protected rowAt(index: number): MemoryRow | undefined;
    /** The row holding an address, which has to be one the map places. */
    protected rowOf(address: number): number;
    protected rowsInView(): number;
    protected firstRenderedRow(): number;
    protected renderedRows(): number;
    /** The first address actually on screen, which is what the map bar reads. */
    protected topAddress(): number | undefined;
    protected scrollToRow(row: number): void;
    /** Bring a row into view without moving if it is already there. */
    protected revealRow(row: number): void;
    /** Put a row directly under the ruler, which is where a scrubber aims. */
    protected pinRowToTop(row: number): void;
    /** The region the view is currently in, which both scrollbars read. */
    protected currentEntry(): MappedRegion | undefined;
    /** Where the map rail's thumb sits, in pixels down a rail of `height`. */
    protected railThumb(height: number): {
        top: number;
        size: number;
        span: number;
    };
    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubRail(box: DOMRect, clientY: number): void;
    /**
     * Where the region scrubber's thumb sits, in pixels across a track of
     * `width`, and how far it can travel.
     */
    protected locatorThumb(width: number, entry: MappedRegion): {
        left: number;
        size: number;
        span: number;
        scrollable: number;
    };
    protected grabLocator(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubLocator(box: DOMRect, clientX: number): void;
    /** Let go of whichever scrollbar was being dragged. */
    protected releaseDrag(event: React.PointerEvent<HTMLDivElement>): void;
    protected readonly setScroller: (element: HTMLDivElement | null) => void;
    protected readonly setLocator: (element: HTMLDivElement | null) => void;
    protected onScrolled(element: HTMLDivElement): void;
    protected onUpdateRequest(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected refresh(): Promise<void>;
    protected read(sim: Sim): Promise<void>;
    /** The rows on screen, as the fewest contiguous reads that cover them. */
    protected visibleRuns(): {
        address: number;
        length: number;
    }[];
    /**
     * The watched addresses as reads.
     *
     * Coalesced, because watching half a dozen fields of one struct is the
     * usual case and six round trips a tick for bytes that are next to each
     * other would be six times the traffic for the same answer.
     */
    protected watchRuns(): {
        address: number;
        length: number;
    }[];
    protected byteAt(address: number, chunks?: MemoryChunk[]): number | undefined;
    /** Stamp the bytes that differ from what was on screen a tick ago. */
    protected noteChanges(next: MemoryChunk[]): void;
    /**
     * What the build calls the byte under the cursor.
     *
     * Three answers, in the order they are worth having: the function it is
     * inside, for the cartridge; the data symbol it is inside, for everything
     * the linker named; and, for an address in WRAM that is neither, the live
     * object holding it and which of that object's fields it is. The last one
     * is the only one that has to read the machine, and the only reason this
     * is not run on every tick.
     */
    protected describe(sim: Sim, address: number): Promise<MemoryWhere | undefined>;
    /** The object in a pool block holding an address, and the field it is in. */
    protected describeOccupant(sim: Sim, symbols: SymbolIndex, address: number): Promise<MemoryWhere | undefined>;
    protected goto(address: number, select?: boolean): void;
    /**
     * Jump to whatever the address box holds, ignoring anything that is not an
     * address. Typing is how it is edited, so most of what passes through here
     * is half-finished and silently doing nothing is the useful response.
     */
    protected gotoTypedAddress(): void;
    /**
     * Go to the top of a region, which is what the map bar asks for.
     *
     * Its caption row rather than its first byte, and pinned to the top
     * rather than set a third of the way down the way {@link goto} places an
     * address. A third of the way down is right for an address — what is
     * before it is context — but for the start of a region it would put the
     * top of the view in the region *above*, and the map bar reads the top of
     * the view. Pressing WRAM would light up Game Pak Expansion.
     */
    protected gotoRegion(region: VbMemoryRegion): void;
    protected select(address: number): void;
    /** Move the selection by bytes, stopping at the ends of its region. */
    protected moveSelection(by: number): void;
    /**
     * Type over the selected byte, a nibble at a time.
     *
     * Two digits make a byte, so the first is held and shown in place of the
     * low nibble until the second arrives — which is what makes it clear a
     * write is half-entered rather than already made.
     */
    protected typeNibble(digit: number): Promise<void>;
    protected onRowsKeyDown(event: React.KeyboardEvent): void;
    protected readWatches(): number[];
    protected setWatches(watches: number[]): void;
    protected toggleWatch(address: number): void;
    /**
     * What to look for, read as bytes where it can be and as text otherwise.
     *
     * Hex wins a tie: in a hex dump `2A` is far more often the byte than the
     * two letters. Quotes force the other reading.
     *
     * Text is matched without regard to case, which is what somebody typing a
     * word into a search box means by it — and the only reading that is any
     * use against a machine where the same string turns up shouted in a ROM
     * header and in mixed case in a message. Bytes are matched exactly: `41`
     * asked for that byte, not for either letter it might spell.
     */
    protected parseNeedle(text: string): MemoryNeedle | undefined;
    /**
     * The whole map once round, starting just past where the cursor is.
     *
     * Regions are not contiguous, so a search is a walk over segments rather
     * than one range — and the segment it started in has to come round again
     * at the end, for the part of it that was behind the cursor.
     */
    protected searchSegments(from: number): {
        address: number;
        end: number;
    }[];
    /** Empty the box, which is the one thing that writes to it from here. */
    protected clearSearch(): void;
    protected findNext(): Promise<void>;
    /** One segment, read a window at a time with the needle's overlap kept. */
    protected scan(sim: Sim, segment: {
        address: number;
        end: number;
    }, needle: MemoryNeedle): Promise<number | undefined>;
    protected render(): React.ReactNode;
    /** Which region the view is in, and how far through it. */
    /**
     * Which region the view is in, and a scrubber for moving within it.
     *
     * The horizontal counterpart to the map rail: that one covers the whole
     * machine, this one covers the region under it, which is the distance a
     * megabyte of cartridge makes awkward to cross any other way.
     */
    protected renderMapBar(): React.ReactNode;
    /**
     * The map rail: the whole address space as one bar, the regions as bands
     * in it, and a thumb for the part on screen.
     */
    protected renderRail(): React.ReactNode;
    protected renderToolbar(): React.ReactNode;
    protected renderRows(): React.ReactNode;
    /**
     * The column ruler, which stays at the top of the list.
     *
     * Built out of the same three parts a row is, so the digits sit over the
     * columns they number without either side knowing a width.
     */
    protected renderRuler(): React.ReactNode;
    protected renderRow(row: number): React.ReactNode;
    /** The selected byte, read every way it might have been meant. */
    protected renderInspector(): React.ReactNode;
    protected renderWatches(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-memory-panel.d.ts.map