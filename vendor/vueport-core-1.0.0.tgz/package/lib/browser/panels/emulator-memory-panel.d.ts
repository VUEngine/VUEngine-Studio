import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Debounced } from '../components/kit/Utils';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
/**
 * One of the eight places the bus decodes to. Every region is VB_REGION_BYTES wide, but what answers is usually far
 * smaller and mirrored (64 KB of WRAM across region 5, a few registers across region 2). `mapped` is that part,
 * which the list walks, as scrolling 16 MB of WRAM would be 256 passes over the same 64 KB. Both sizes are shown,
 * as either alone would misstate the map
 */
export interface VbMemoryRegion {
    label: string;
    short: string;
    address: number;
    mapped: number;
}
export declare const VCU_MEMORY_REGION: VbMemoryRegion;
export declare const VB_MEMORY_REGIONS: VbMemoryRegion[];
type MemoryUnit = 1 | 2 | 4;
interface MappedRegion {
    region: VbMemoryRegion;
    mapped: number;
    rows: number;
    firstRow: number;
}
interface MemoryRow {
    entry: MappedRegion;
    address?: number;
}
interface MemoryChunk {
    address: number;
    bytes: Uint8Array;
}
interface MemoryWhere {
    owner: string;
    offset: number;
    field?: string;
}
interface MemoryNeedle {
    bytes: Uint8Array;
    folded: boolean;
}
/**
 * Hex view of the address space: one virtualized list over the whole memory map, regions end to end behind
 * captions, reading only what is on screen. The region in view drives the map bar, and picking one there scrolls
 * to it. Reads go through the CPU's view, so mirrors and registers read as the program sees them; writes go
 * through DebugSource.write, as in the VIP editors, so a poke reaches both machines in a linked session
 */
export declare class MemoryPanel extends Panel {
    protected address: number;
    protected selected?: number;
    protected unit: MemoryUnit;
    protected map: MappedRegion[];
    protected totalRows: number;
    protected mapSignature?: string;
    protected chunks: MemoryChunk[];
    protected selectedBytes?: Uint8Array;
    protected watchChunks: MemoryChunk[];
    protected readonly changedAt: Map<number, number>;
    protected watches: number[];
    protected where?: MemoryWhere;
    protected whereFor?: number;
    protected search: string;
    protected searchMissed: boolean;
    protected searching: boolean;
    protected readonly searchInput: React.RefObject<HTMLInputElement>;
    protected readonly settleSearch: Debounced<[string]>;
    protected pending?: {
        address: number;
        value: number;
        digits: number;
    };
    protected scroller?: HTMLDivElement;
    protected scrollTop: number;
    protected viewportHeight: number;
    protected resize?: ResizeObserver;
    protected locatorWidth: number;
    protected locatorResize?: ResizeObserver;
    protected pendingScrollTop?: number;
    protected railGrab?: number;
    protected locatorGrab?: number;
    protected locatorEntry?: MappedRegion;
    protected reading: boolean;
    protected readAgain: boolean;
    protected readonly addressInput: React.RefObject<HTMLInputElement>;
    constructor(source: DebugSource, instanceId: string);
    protected rebuildMap(): void;
    protected entryOf(address: number): MappedRegion | undefined;
    protected canonical(address: number): number | undefined;
    protected rowAt(index: number): MemoryRow | undefined;
    protected rowOf(address: number): number;
    protected rowsInView(): number;
    protected firstRenderedRow(): number;
    protected renderedRows(): number;
    protected topAddress(): number | undefined;
    protected scrollToRow(row: number): void;
    protected revealRow(row: number): void;
    protected pinRowToTop(row: number): void;
    protected currentEntry(): MappedRegion | undefined;
    protected railThumb(height: number): {
        top: number;
        size: number;
        span: number;
    };
    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubRail(box: DOMRect, clientY: number): void;
    protected locatorThumb(width: number, entry: MappedRegion): {
        left: number;
        size: number;
        span: number;
        scrollable: number;
    };
    protected grabLocator(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubLocator(box: DOMRect, clientX: number): void;
    protected releaseDrag(event: React.PointerEvent<HTMLDivElement>): void;
    protected readonly setScroller: (element: HTMLDivElement | null) => void;
    protected readonly setLocator: (element: HTMLDivElement | null) => void;
    protected onScrolled(element: HTMLDivElement): void;
    protected onUpdateRequest(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected refresh(): Promise<void>;
    protected read(sim: Sim): Promise<void>;
    protected visibleRuns(): {
        address: number;
        length: number;
    }[];
    protected watchRuns(): {
        address: number;
        length: number;
    }[];
    protected byteAt(address: number, chunks?: MemoryChunk[]): number | undefined;
    protected noteChanges(next: MemoryChunk[]): void;
    protected describe(sim: Sim, address: number): Promise<MemoryWhere | undefined>;
    protected describeOccupant(sim: Sim, symbols: SymbolIndex, address: number): Promise<MemoryWhere | undefined>;
    protected goto(address: number, select?: boolean): void;
    protected gotoTypedAddress(): void;
    protected gotoRegion(region: VbMemoryRegion): void;
    reveal(target: ScreenInspectorTarget): void;
    protected select(address: number): void;
    protected cellOf(address: number): number;
    protected setUnit(unit: MemoryUnit): void;
    protected moveSelection(by: number): void;
    protected typeNibble(digit: number): Promise<void>;
    protected onRowsKeyDown(event: React.KeyboardEvent): void;
    protected readWatches(): number[];
    protected setWatches(watches: number[]): void;
    protected toggleWatch(address: number): void;
    /**
     * Read as bytes where possible, else text; hex wins a tie (`2A` is far more often a byte), quotes force text.
     * Text matches case-insensitively, as the same string appears shouted in a ROM header and mixed-case in a message;
     * bytes match exactly
     */
    protected parseNeedle(text: string): MemoryNeedle | undefined;
    protected searchSegments(from: number): {
        address: number;
        end: number;
    }[];
    protected clearSearch(): void;
    protected findNext(): Promise<void>;
    protected scan(sim: Sim, segment: {
        address: number;
        end: number;
    }, needle: MemoryNeedle): Promise<number | undefined>;
    protected render(): React.ReactNode;
    protected renderMapBar(): React.ReactNode;
    protected renderRail(): React.ReactNode;
    protected renderUnitSelect(): React.ReactNode;
    protected renderToolbar(): React.ReactNode;
    protected renderRows(): React.ReactNode;
    protected renderRuler(): React.ReactNode;
    protected endsGroup(column: number): boolean;
    protected cellAt(address: number): number | undefined;
    protected changedSince(address: number, now: number): boolean;
    protected renderRow(row: number): React.ReactNode;
    protected renderInspector(): React.ReactNode;
    protected renderWatches(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-memory-panel.d.ts.map