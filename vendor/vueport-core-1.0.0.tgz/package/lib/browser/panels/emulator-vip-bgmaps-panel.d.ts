import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { Sim } from '../core/vb-core';
import { VipBgMapCell, VipBgMapSegmentUse, VipCharacters, VipIntensityWatcher, VipWorld } from './emulator-vip-memory';
import { VcuColors, VcuPlacement } from './emulator-vcu-colors';
import { VbcState, VcuColorAttr, VcuPixelAttr } from './emulator-vcu-memory';
/** One line of Used by: which world, what it takes, and what it draws. */
interface UsedByWorld {
    index: number;
    /** BGMap, HBias or Affine — how it reads the map. */
    mode: string;
    /** Map, Params, or both. */
    takes: string;
    image?: ImageData;
}
/**
 * The fourteen BGMap segments, and the selected one rasterized as one 512x512
 * bitmap beside its fields — which inspect, and for the character, palette
 * and flips edit, one cell at a time.
 *
 * Three columns, the shape the Worlds panel has: the segments as tiles, the
 * fields of the one picked, and the map itself. Reads the selected segment's
 * cells plus the character memory they reference each refresh, and
 * re-rasterizes only when the pixels or the shading actually changed — see
 * the Characters panel, whose caching this mirrors. The tiles cost one more
 * read, of world attribute memory, since what a segment is being used for is
 * a fact about the worlds pointing at it rather than about the segment
 * itself.
 */
export declare class BgMapsPanel extends Panel {
    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    protected cells?: Uint8Array;
    /** The segment being shown, and those the Used by previews read from. */
    protected bgMapSegments: (Uint8Array | undefined)[];
    /** The param tables of the worlds under Used by, by world index. */
    protected paramTables: (Uint8Array | undefined)[];
    /** What Used by shows, rebuilt when the maps or the worlds move. */
    protected usedBy: UsedByWorld[];
    protected worldBytes?: Uint8Array;
    /** Only while a VB Color game has unlocked the VCU; see `readVbcState`. */
    protected vbc?: VbcState;
    /**
     * The shown segment's Cell Color Attribute bytes and Cell Pixel Color
     * Attribute halfwords, and the color RAM they point into — read only
     * while `vbc` is there, for the selected cell's VB Color group. What
     * the pictures are drawn with is `colors`, so none of this marks the
     * image dirty.
     */
    protected cellColors?: Uint8Array;
    protected cellPixelAttrs?: DataView;
    protected cram?: DataView;
    /**
     * The Color Attribute byte and Pixel Color Attribute halfword of the
     * selected cell's character, which stand in for the cell's own under
     * CHRSEL and CCEN. Read for that one character rather than the 16 KiB of
     * both tables, and tagged with it, so that a selection which has moved on
     * is not shown the previous cell's.
     */
    protected characterColor?: {
        char: number;
        color: number;
        pixel: number;
    };
    protected segment: number;
    protected selected: number;
    protected zoom: number;
    protected showGrid: boolean;
    /**
     * Whether the map is shaded with an even ramp instead of the palette
     * registers the game has set up. Off: the previews resolve the brightness
     * registers the way the core does, so the real palettes look like the
     * picture on screen. The even ramp is for reading the tile data itself.
     */
    protected showGenericPalette: boolean;
    /**
     * Whether the pictures are drawn in the colors a VB Color shows rather
     * than the VIP's red. On by default, but only ever in effect while the
     * game has switched color on — see `colorMode` — so a plain Virtual Boy
     * game is drawn as it always was whatever this says.
     */
    protected vbColorPreview: boolean;
    /**
     * The VCU tables the pictures are colored from, read only in color mode
     * and for the segments drawn — see `readPreviewColors`.
     */
    protected colors?: VcuColors;
    /**
     * The world whose read area is outlined on the map: the one the pointer
     * is over in Used by, or — once a row has been clicked — the one pinned
     * there. Hovering another previews it and leaving falls back to the
     * pinned one. Both are dropped when another segment is picked, since the
     * outline is about the map being shown.
     */
    protected hoveredWorld?: number;
    protected pinnedWorld?: number;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /**
     * The BGMap memory the panel draws from: the segment being shown, and
     * the maps and param tables of the worlds listed under Used by, which
     * their previews are made of.
     *
     * A world's map can span segments other than the one being looked at, so
     * this is the union rather than the one segment — but still only what
     * the list needs, rather than all fourteen every poll.
     */
    protected readMaps(sim: Sim): Promise<number[]>;
    /** Whether the pictures are drawn in VB Color: the option, and color switched on. */
    protected colorMode(): boolean;
    /**
     * The VCU tables drawing the pictures in color takes, for the segments
     * they are drawn from — plus those the overplane cells of the worlds
     * under Used by sit in, whose Color Attributes the core takes from there.
     *
     * The pictures are drawn again only when something in them changed, the
     * way the map's cells and characters are compared; leaving color mode
     * drops the tables and redraws in red.
     */
    protected readPreviewColors(sim: Sim, segments: number[]): Promise<void>;
    /**
     * The VB Color side of the shown segment: its cells' Color and Pixel
     * Color Attributes, and color RAM for the swatches of the palette the
     * selected one ends up with.
     *
     * The whole segment's entries rather than the selected cell's, the way
     * the cells themselves are read, so that walking the map shows each
     * cell's at once instead of a poll later; with CRAM that is 16 KiB a
     * poll, and nothing at all on a game that has not switched color on.
     */
    protected readColors(sim: Sim): Promise<void>;
    protected clearColors(): void;
    /**
     * The selected cell's character's own color entries — only when they
     * are what the cell is drawn with, its CHRSEL set and CCEN on, since
     * otherwise nothing here shows them.
     */
    protected readCharacterColor(sim: Sim): Promise<void>;
    /** How many bits of a cell name its character: twelve with CHREXT. */
    protected charMask(): number;
    /** How many characters a cell can name: 2048, or 4096 with CHREXT. */
    protected charCount(): number;
    protected setSegment(segment: number): void;
    protected selectCell(cell: number): void;
    protected setShowGenericPalette(value: boolean): void;
    /** Draw in VB Color or in red; the refresh reads or drops the tables. */
    protected setVbColorPreview(value: boolean): void;
    /**
     * Patch the selected cell — its character and/or its palette/flip bits —
     * and write the result back to VRAM. Callers are trusted to have already
     * clamped `char` to a valid character index; palette and the flip flags
     * come from a bounded dropdown and checkboxes respectively, so need no
     * clamping of their own.
     */
    protected writeCell(patch: Partial<VipBgMapCell>): Promise<void>;
    /**
     * Patch the selected cell's Cell Color Attribute byte, keeping the bit
     * the encoder does not name as it was.
     */
    protected writeColorAttr(patch: Partial<VcuColorAttr>): Promise<void>;
    /** The same for its Cell Pixel Color Attribute halfword. */
    protected writePixelAttr(patch: Partial<VcuPixelAttr>): Promise<void>;
    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][];
    /**
     * The color counterpart of `palettes`: the shade each BGMap palette gives
     * each pixel value — the two bits of its GPLT register the value picks,
     * which is the CRAM entry within the cell's palette — or, with the
     * generic palette, the value itself, as the even ramp is.
     */
    protected shades(registers: DataView): number[][];
    /** The tables to draw in color with, or nothing while the pictures are red. */
    protected previewColors(): VcuColors | undefined;
    /**
     * One cell's character in VB Color, where `drawVipChar` draws it in red:
     * flipped the same way, and with a pixel the hardware leaves out drawn
     * black, as the red pictures draw pixel value 0. `charX`/`charY` are the
     * character's own coordinates, since a Pixel Color Slot is laid out in
     * those rather than the flipped ones.
     */
    protected drawColorChar(target: Uint8ClampedArray, targetWidth: number, destX: number, destY: number, characters: VipCharacters, colors: VcuColors, placement: VcuPlacement, cell: VipBgMapCell, shades: number[][]): void;
    protected rasterize(registers: DataView): ImageData | undefined;
    /**
     * What the worlds currently being drawn do with each segment: which of
     * them read their map out of it, and whose param table is sitting in it.
     * A segment under neither is free.
     */
    protected segmentUses(): VipBgMapSegmentUse[];
    /** Every world, decoded out of the last read of world attribute memory. */
    protected worlds(): VipWorld[];
    /** The worlds Used by lists: those reading this segment, or kept in it. */
    protected usedByWorlds(): VipWorld[];
    /**
     * What Used by shows: a line per world, and under it a picture of what
     * that world draws, with the pixels it reads out of this segment picked
     * out.
     *
     * Rebuilt here rather than while rendering, because the panel re-renders
     * whenever the pointer moves over the list and these are rasterized.
     */
    protected buildUsedBy(registers: DataView): UsedByWorld[];
    /**
     * One world as it is actually drawn, with the part of it that comes out
     * of this segment picked out — red for this segment, faded gray for
     * whatever the world reads from its other ones. In VB Color, the colors
     * it is shown in, with the other segments' part darkened instead.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one. The three properties that place the finished
     * rectangle on the screen — GX, GY, GP — are the only ones dropped, since
     * the preview is the rectangle. Copied in spirit from the Characters
     * panel, which marks the selected character in its own Used by the same
     * way.
     */
    protected drawWorldPreview(registers: DataView, world: VipWorld): ImageData | undefined;
    /**
     * The area the hovered world reads out of this segment, for the outline
     * over the map, or undefined while nothing is hovered.
     */
    protected hoveredExtents(): {
        x: number;
        y: number;
        width: number;
        height: number;
    } | undefined;
    protected setHoveredWorld(index: number | undefined): void;
    /** Keep the outline of one world up, or take it down again. */
    protected togglePinnedWorld(index: number): void;
    /**
     * A click in Used by that lands on none of its worlds — the space between
     * and under them — lets go of the pinned one, as a second click on it
     * does.
     */
    protected onUsedByClick(event: React.MouseEvent): void;
    /**
     * The fourteen segments as tiles: the number and the worlds reading it on
     * one line, its address and — where one sits in it — Param under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next segment does not mean leaving the one being read.
     */
    protected renderTiles(uses: VipBgMapSegmentUse[]): React.ReactNode;
    /** What a tile's count stands for, spelled out on hover. */
    protected static segmentTitle(use: VipBgMapSegmentUse): string | undefined;
    /**
     * Walk the segments with the keyboard, from inside the tiles.
     *
     * Stopped rather than only defaulted: the emulator listens for keys on
     * the node this panel sits inside and would otherwise read an arrow as
     * the D-pad and move the game.
     */
    protected onTilesKey(event: React.KeyboardEvent): void;
    /**
     * Walk the cells of the map with the keyboard, from anywhere else in the
     * panel: a cell at a time sideways, a row at a time up and down, a
     * screenful with Page keys, and the ends of the map with Home and End.
     */
    protected onPanelKey(event: React.KeyboardEvent): void;
    /** Keep the picked segment's tile in view, and the ring on it. */
    protected revealSegment(): void;
    /** Keep the picked cell in view as the keys walk off the visible map. */
    protected revealCell(): void;
    /**
     * Just the selected cell's character, for the sidebar preview — in the
     * colors its cell gives it, in color mode, CHRSEL and slot included.
     */
    protected rasterizePreview(registers: DataView, characters: VipCharacters, cell: VipBgMapCell): ImageData;
    protected render(): React.ReactNode;
    /** The segment itself: where it is, and what is reading it. */
    protected renderSegmentGroup(use: VipBgMapSegmentUse): React.ReactNode;
    /**
     * The worlds this segment is part of, and what each of them takes from
     * it: the cells of its map, the param table it steps its rows with, or
     * both — with a picture of what each one draws, the part of it coming
     * out of this segment in red and the rest faded.
     *
     * The group that gives way when the sidebar is taller than the panel —
     * it is the only one here whose length depends on the game, and a list
     * scrolling inside itself is better than the groups under it going off
     * the bottom.
     */
    protected renderUsedByGroup(): React.ReactNode;
    /** The one cell, at a size worth looking at. */
    protected renderCharacterGroup(preview: ImageData): React.ReactNode;
    /**
     * Everything one cell holds, in a grid three fields wide: where it is,
     * what it draws, and how.
     *
     * This is the group that gives way when the sidebar is taller than the
     * panel — the others are a few lines each and nothing in them can be cut
     * short.
     */
    protected renderCellGroup(cell: VipBgMapCell, address: number): React.ReactNode;
    /**
     * What a VB Color draws the selected cell with: its Cell Color Attribute
     * (palette group, CHRSEL), its Cell Pixel Color Attribute (slot, PCE,
     * OPQ), and the CRAM palette the two come to — the cell's group above its
     * two palette bits, as the core resolves it.
     *
     * Only there while the game has switched color on; see `readVbcState`.
     * A bit that is set but switched off in CXCTRL gets a line under the
     * fields saying so, since what the cell holds and what it is drawn with
     * then part ways, and that is exactly what is easy to miss.
     */
    protected renderColorGroup(vbc: VbcState, cell: VipBgMapCell): React.ReactNode;
    /**
     * The four colors of one CRAM palette, the way the VCU panel shows the
     * backdrop's: a number alone sends you counting into its CRAM grid.
     */
    protected renderPaletteSwatches(palette: number): React.ReactNode;
    /**
     * How the map is drawn, under it rather than as a group in the sidebar —
     * the Objects panel's arrangement: the scale on a line of its own, the
     * switches under it in two columns, to the right.
     */
    protected renderDisplayControls(): React.ReactNode;
    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips are, that is the only full name it has. `hint`,
     * where there is one, says more on hover than the name can.
     */
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-bgmaps-panel.d.ts.map