import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { Sim } from '../core/vb-core';
import { VipBgMapCell, VipBgMapSegmentUse, VipCharacters, VipIntensityWatcher, VipWorld } from './emulator-vip-memory';
/** One line of Used by: which world, what it takes, and what it draws. */
interface UsedByWorld {
    index: number;
    /** BGMap, HBias or Affine — how it reads the map. */
    mode: string;
    /** Map, Params, or both. */
    takes: string;
    image?: ImageData;
}
/**
 * The fourteen BGMap segments, and the selected one rasterized as one 512x512
 * bitmap beside its fields — which inspect, and for the character, palette
 * and flips edit, one cell at a time.
 *
 * Three columns, the shape the Worlds panel has: the segments as tiles, the
 * fields of the one picked, and the map itself. Reads the selected segment's
 * cells plus the character memory they reference each refresh, and
 * re-rasterizes only when the pixels or the shading actually changed — see
 * the Characters panel, whose caching this mirrors. The tiles cost one more
 * read, of world attribute memory, since what a segment is being used for is
 * a fact about the worlds pointing at it rather than about the segment
 * itself.
 */
export declare class BgMapsPanel extends Panel {
    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    protected cells?: Uint8Array;
    /** The segment being shown, and those the Used by previews read from. */
    protected bgMapSegments: (Uint8Array | undefined)[];
    /** The param tables of the worlds under Used by, by world index. */
    protected paramTables: (Uint8Array | undefined)[];
    /** What Used by shows, rebuilt when the maps or the worlds move. */
    protected usedBy: UsedByWorld[];
    protected worldBytes?: Uint8Array;
    protected segment: number;
    protected selected: number;
    protected zoom: number;
    protected showGrid: boolean;
    /**
     * Whether the map is shaded with an even ramp instead of the palette
     * registers the game has set up. Off: the previews resolve the brightness
     * registers the way the core does, so the real palettes look like the
     * picture on screen. The even ramp is for reading the tile data itself.
     */
    protected showGenericPalette: boolean;
    /**
     * The world whose read area is outlined on the map: the one the pointer
     * is over in Used by, or — once a row has been clicked — the one pinned
     * there. Hovering another previews it and leaving falls back to the
     * pinned one. Both are dropped when another segment is picked, since the
     * outline is about the map being shown.
     */
    protected hoveredWorld?: number;
    protected pinnedWorld?: number;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /**
     * The BGMap memory the panel draws from: the segment being shown, and
     * the maps and param tables of the worlds listed under Used by, which
     * their previews are made of.
     *
     * A world's map can span segments other than the one being looked at, so
     * this is the union rather than the one segment — but still only what
     * the list needs, rather than all fourteen every poll.
     */
    protected readMaps(sim: Sim): Promise<void>;
    protected setSegment(segment: number): void;
    protected selectCell(cell: number): void;
    protected setShowGenericPalette(value: boolean): void;
    /**
     * Patch the selected cell — its character and/or its palette/flip bits —
     * and write the result back to VRAM. Callers are trusted to have already
     * clamped `char` to a valid character index; palette and the flip flags
     * come from a bounded dropdown and checkboxes respectively, so need no
     * clamping of their own.
     */
    protected writeCell(patch: Partial<VipBgMapCell>): Promise<void>;
    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][];
    protected rasterize(registers: DataView): ImageData | undefined;
    /**
     * What the worlds currently being drawn do with each segment: which of
     * them read their map out of it, and whose param table is sitting in it.
     * A segment under neither is free.
     */
    protected segmentUses(): VipBgMapSegmentUse[];
    /** Every world, decoded out of the last read of world attribute memory. */
    protected worlds(): VipWorld[];
    /** The worlds Used by lists: those reading this segment, or kept in it. */
    protected usedByWorlds(): VipWorld[];
    /**
     * What Used by shows: a line per world, and under it a picture of what
     * that world draws, with the pixels it reads out of this segment picked
     * out.
     *
     * Rebuilt here rather than while rendering, because the panel re-renders
     * whenever the pointer moves over the list and these are rasterized.
     */
    protected buildUsedBy(registers: DataView): UsedByWorld[];
    /**
     * One world as it is actually drawn, with the part of it that comes out
     * of this segment picked out — red for this segment, faded gray for
     * whatever the world reads from its other ones.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one. The three properties that place the finished
     * rectangle on the screen — GX, GY, GP — are the only ones dropped, since
     * the preview is the rectangle. Copied in spirit from the Characters
     * panel, which marks the selected character in its own Used by the same
     * way.
     */
    protected drawWorldPreview(registers: DataView, world: VipWorld): ImageData | undefined;
    /**
     * The area the hovered world reads out of this segment, for the outline
     * over the map, or undefined while nothing is hovered.
     */
    protected hoveredExtents(): {
        x: number;
        y: number;
        width: number;
        height: number;
    } | undefined;
    protected setHoveredWorld(index: number | undefined): void;
    /** Keep the outline of one world up, or take it down again. */
    protected togglePinnedWorld(index: number): void;
    /**
     * The fourteen segments as tiles: the number and the worlds reading it on
     * one line, its address and — where one sits in it — Param under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next segment does not mean leaving the one being read.
     */
    protected renderTiles(uses: VipBgMapSegmentUse[]): React.ReactNode;
    /** What a tile's count stands for, spelled out on hover. */
    protected static segmentTitle(use: VipBgMapSegmentUse): string | undefined;
    /**
     * Walk the segments with the keyboard, from inside the tiles.
     *
     * Stopped rather than only defaulted: the emulator listens for keys on
     * the node this panel sits inside and would otherwise read an arrow as
     * the D-pad and move the game.
     */
    protected onTilesKey(event: React.KeyboardEvent): void;
    /**
     * Walk the cells of the map with the keyboard, from anywhere else in the
     * panel: a cell at a time sideways, a row at a time up and down, a
     * screenful with Page keys, and the ends of the map with Home and End.
     */
    protected onPanelKey(event: React.KeyboardEvent): void;
    /** Keep the picked segment's tile in view, and the ring on it. */
    protected revealSegment(): void;
    /** Keep the picked cell in view as the keys walk off the visible map. */
    protected revealCell(): void;
    /** Just the selected cell's character, for the sidebar preview. */
    protected rasterizePreview(characters: VipCharacters, palettes: number[][], cell: VipBgMapCell): ImageData;
    protected render(): React.ReactNode;
    /** The segment itself: where it is, and what is reading it. */
    protected renderSegmentGroup(use: VipBgMapSegmentUse): React.ReactNode;
    /**
     * The worlds this segment is part of, and what each of them takes from
     * it: the cells of its map, the param table it steps its rows with, or
     * both — with a picture of what each one draws, the part of it coming
     * out of this segment in red and the rest faded.
     *
     * The group that gives way when the sidebar is taller than the panel —
     * it is the only one here whose length depends on the game, and a list
     * scrolling inside itself is better than the groups under it going off
     * the bottom.
     */
    protected renderUsedByGroup(): React.ReactNode;
    /** The one cell, at a size worth looking at. */
    protected renderCharacterGroup(preview: ImageData): React.ReactNode;
    /**
     * Everything one cell holds, in a grid three fields wide: where it is,
     * what it draws, and how.
     *
     * This is the group that gives way when the sidebar is taller than the
     * panel — the others are a few lines each and nothing in them can be cut
     * short.
     */
    protected renderCellGroup(cell: VipBgMapCell, address: number): React.ReactNode;
    protected renderDisplayGroup(): React.ReactNode;
    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips are, that is the only full name it has.
     */
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-bgmaps-panel.d.ts.map