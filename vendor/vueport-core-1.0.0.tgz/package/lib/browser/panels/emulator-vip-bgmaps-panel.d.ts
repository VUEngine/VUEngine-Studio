import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { Sim } from '../core/vb-core';
import { VipBgMapCell, VipBgMapSegmentUse, VipCharacters, VipIntensityWatcher, VipWorld } from './emulator-vip-memory';
import { VcuColors, VcuPlacement } from './emulator-vcu-colors';
import { VbcState, VcuColorAttr, VcuPixelAttr } from './emulator-vcu-memory';
interface UsedByWorld {
    index: number;
    mode: string;
    takes: string;
    image?: ImageData;
}
/**
 * The fourteen BGMap segments, and the selected one rasterized as one 512x512 bitmap beside its fields, which
 * inspect and, for character, palette and flips, edit one cell at a time. Three columns like the Worlds panel. Reads
 * the segment's cells and the characters they reference each refresh, re-rasterizing only on change (as in the
 * Characters panel); the tiles also read world attribute memory, as a segment's use is a fact about the worlds
 */
export declare class BgMapsPanel extends Panel {
    protected readonly exportFile?: VipExportFile | undefined;
    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    protected cells?: Uint8Array;
    protected bgMapSegments: (Uint8Array | undefined)[];
    protected paramTables: (Uint8Array | undefined)[];
    protected usedBy: UsedByWorld[];
    protected worldBytes?: Uint8Array;
    protected vbc?: VbcState;
    protected cellColors?: Uint8Array;
    protected cellPixelAttrs?: DataView;
    protected cram?: DataView;
    protected characterColor?: {
        char: number;
        color: number;
        pixel: number;
    };
    protected segment: number;
    protected selected: number;
    protected zoom: number;
    protected showGrid: boolean;
    protected showGenericPalette: boolean;
    protected vbColorPreview: boolean;
    protected colors?: VcuColors;
    protected hoveredWorld?: number;
    protected pinnedWorld?: number;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string, exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected readMaps(sim: Sim): Promise<number[]>;
    protected colorMode(): boolean;
    protected readPreviewColors(sim: Sim, segments: number[]): Promise<void>;
    protected readColors(sim: Sim): Promise<void>;
    protected clearColors(): void;
    protected readCharacterColor(sim: Sim): Promise<void>;
    protected charMask(): number;
    protected charCount(): number;
    protected setSegment(segment: number): void;
    reveal(target: ScreenInspectorTarget): void;
    protected selectCell(cell: number): void;
    protected setShowGenericPalette(value: boolean): void;
    protected setVbColorPreview(value: boolean): void;
    protected writeCell(patch: Partial<VipBgMapCell>): Promise<void>;
    protected writeColorAttr(patch: Partial<VcuColorAttr>): Promise<void>;
    protected writePixelAttr(patch: Partial<VcuPixelAttr>): Promise<void>;
    protected palettes(registers: DataView): number[][];
    protected shades(registers: DataView): number[][];
    protected previewColors(): VcuColors | undefined;
    protected drawColorChar(target: Uint8ClampedArray, targetWidth: number, destX: number, destY: number, characters: VipCharacters, colors: VcuColors, placement: VcuPlacement, cell: VipBgMapCell, shades: number[][]): void;
    protected rasterize(registers: DataView): ImageData | undefined;
    protected segmentUses(): VipBgMapSegmentUse[];
    protected worlds(): VipWorld[];
    protected usedByWorlds(): VipWorld[];
    protected buildUsedBy(registers: DataView): UsedByWorld[];
    /**
     * One world as drawn: red for this segment's part, faded gray for its other segments (in VB Color, its colors with
     * the rest darkened). The world's own W+1 by H+1 window onto its map from MX/MY, shifted per row by its param
     * table; only GX, GY and GP, which place it on screen, are dropped. Copied in spirit from the Characters panel's
     * Used by
     */
    protected drawWorldPreview(registers: DataView, world: VipWorld): ImageData | undefined;
    protected hoveredExtents(): {
        x: number;
        y: number;
        width: number;
        height: number;
    } | undefined;
    protected setHoveredWorld(index: number | undefined): void;
    protected togglePinnedWorld(index: number): void;
    protected onUsedByClick(event: React.MouseEvent): void;
    protected renderTiles(uses: VipBgMapSegmentUse[]): React.ReactNode;
    protected static segmentTitle(use: VipBgMapSegmentUse): string | undefined;
    protected onTilesKey(event: React.KeyboardEvent): void;
    protected onPanelKey(event: React.KeyboardEvent): void;
    protected revealSegment(): void;
    protected revealCell(): void;
    protected rasterizePreview(registers: DataView, characters: VipCharacters, cell: VipBgMapCell): ImageData;
    protected render(): React.ReactNode;
    protected renderSegmentGroup(use: VipBgMapSegmentUse): React.ReactNode;
    protected renderUsedByGroup(): React.ReactNode;
    protected renderCharacterGroup(preview: ImageData): React.ReactNode;
    protected renderCellGroup(cell: VipBgMapCell, address: number): React.ReactNode;
    /**
     * What a VB Color draws the selected cell with: Cell Color Attribute (palette group, CHRSEL), Cell Pixel Color
     * Attribute (slot, PCE, OPQ), and the CRAM palette they come to, the group above the cell's two palette bits as the
     * core resolves it. Only while color is on (see readVbcState). A bit set but switched off in CXCTRL gets a line
     * saying so, as what the cell holds and what it is drawn with then part ways
     */
    protected renderColorGroup(vbc: VbcState, cell: VipBgMapCell): React.ReactNode;
    protected renderPaletteSwatches(palette: number): React.ReactNode;
    protected exportPng(): Promise<void>;
    protected renderDisplayControls(): React.ReactNode;
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-bgmaps-panel.d.ts.map