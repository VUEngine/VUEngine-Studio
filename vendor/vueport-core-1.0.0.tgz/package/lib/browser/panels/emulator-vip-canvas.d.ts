import * as React from 'react';
/**
 * How a finished file reaches the person, from the host that knows where
 * files go — a download in the browser, a file in the project in VES. Left
 * out by a host that cannot take one, and then a panel simply has no Export
 * button. See `VueportDockHost.exportFile`.
 */
export type VipExportFile = (name: string, data: Uint8Array) => Promise<void>;
/**
 * Hand an ImageData to the host as a PNG, at one file pixel per source pixel.
 *
 * Shared by every VIP inspector with an Export PNG button: they differ in
 * what they draw, not in how a drawn picture becomes a file.
 */
export declare function exportVipImage(exportFile: VipExportFile, name: string, image: ImageData): Promise<void>;
/**
 * Draws an ImageData at an integer zoom.
 *
 * The canvas stays at the source resolution and is scaled by CSS so that the
 * pixels stay crisp and a redraw does not have to repaint the scaled area.
 * Shared by the Characters and BGMaps panels, the two VIP inspectors that
 * rasterize VRAM to a bitmap rather than a table. Both put their own zoom
 * control in their Display group rather than sharing one, since the two
 * differ (a slider vs. the sidebar's single-cell preview zoom).
 *
 * `cellSize` opts into two overlays, both no-ops without it: grid lines every
 * `cellSize` source pixels (`showGrid`), and a highlight border around one
 * cell (`selected`, in cell rather than pixel units). `extents` is a third,
 * independent of `cellSize`: a border around an arbitrary rectangle given in
 * source pixels, which the Worlds panel uses to outline where on the screen a
 * world lands. `around` is a fainter border of the same kind, for what the
 * outlined thing is part of — the figure the Objects panel's selected object
 * belongs to. All of them are separate absolutely-positioned elements rather
 * than drawn into the bitmap itself, so none has to survive being scaled up
 * with the rest of the pixel data.
 */
export declare function VipCanvas(props: {
    image: ImageData;
    zoom: number;
    onPick?: (x: number, y: number) => void;
    /** The source pixel the pointer is over, as it moves; undefined as it leaves. */
    onHover?: (point: {
        x: number;
        y: number;
    } | undefined) => void;
    title?: string;
    cellSize?: number;
    showGrid?: boolean;
    selected?: {
        x: number;
        y: number;
    };
    extents?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    around?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}): React.JSX.Element;
//# sourceMappingURL=emulator-vip-canvas.d.ts.map