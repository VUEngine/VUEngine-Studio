import * as React from 'react';
export type VipExportFile = (name: string, data: Uint8Array) => Promise<void>;
export declare function exportVipImage(exportFile: VipExportFile, name: string, image: ImageData): Promise<void>;
/**
 * Draws an ImageData at an integer zoom. The canvas stays at source resolution and is scaled by CSS, so pixels stay
 * crisp and a redraw does not repaint the scaled area. Overlays are separate absolutely-positioned elements, so none
 * is scaled with the bitmap: with `cellSize`, grid lines (`showGrid`) and a border around the `selected` cell (in cell
 * units); `extents`, a border around a rectangle in source pixels (where a world lands, for Worlds); `around`, a
 * fainter one for what that is part of (the figure an Objects panel object belongs to).
 */
export declare function VipCanvas(props: {
    image: ImageData;
    zoom: number;
    onPick?: (x: number, y: number) => void;
    onHover?: (point: {
        x: number;
        y: number;
    } | undefined) => void;
    title?: string;
    cellSize?: number;
    showGrid?: boolean;
    selected?: {
        x: number;
        y: number;
    };
    extents?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    around?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}): React.JSX.Element;
//# sourceMappingURL=emulator-vip-canvas.d.ts.map