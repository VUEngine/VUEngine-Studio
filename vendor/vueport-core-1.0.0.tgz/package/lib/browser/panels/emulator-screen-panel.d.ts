import { VueportWidget } from '../emulator-widget-base';
import { Message } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import { Emitter, Event } from '../../common/emulator-events';
import { DisplayMode, DisplayOutput } from '../../common/vb-constants';
import { EmulatorPanelType } from './emulator-panel';
import { StereoStill } from '../stereo-still';
export type EmulatorDecorationSpec = {
    readonly kind: 'black';
} | {
    readonly kind: 'ambient';
    readonly color: string;
    readonly intensity: number;
} | {
    readonly kind: 'immersion';
    readonly intensity: number;
};
export interface VesScreenRect {
    x: number;
    y: number;
    width: number;
    height: number;
    parallax: number;
}
export declare const BACKDROP_COLUMNS = 48;
export declare const BACKDROP_ROWS = 30;
export declare class ScreenPanel extends VueportWidget {
    readonly kind = EmulatorPanelType.SCREEN;
    protected readonly frame: HTMLDivElement;
    protected readonly picture: HTMLDivElement;
    protected readonly prompt: HTMLDivElement;
    protected canvasElement?: HTMLCanvasElement;
    protected placeholderCanvas?: HTMLCanvasElement;
    protected placeholderLeft?: Uint8ClampedArray;
    protected placeholderRight?: Uint8ClampedArray;
    protected placeholderShown: boolean;
    protected stereoDepth: number;
    protected placeholderStill?: StereoStill;
    protected placeholderAtDepth?: {
        depth: number;
        left: Uint8ClampedArray;
        right: Uint8ClampedArray;
    };
    protected liveBackdrop?: {
        pixels: Uint8ClampedArray;
        width: number;
        height: number;
        colorMode: boolean;
    };
    protected readonly glow: HTMLCanvasElement;
    protected decoration?: EmulatorDecorationSpec;
    protected overlayCanvas?: HTMLCanvasElement;
    protected highlights: VesScreenRect[];
    protected pixelLayer?: {
        left?: ImageData;
        right?: ImageData;
    };
    protected readonly layerCanvases: HTMLCanvasElement[];
    protected pictureBox: {
        width: number;
        height: number;
    };
    protected glowSpread: {
        x: number;
        y: number;
    };
    protected displayMode: DisplayMode;
    protected scale: string;
    protected output: DisplayOutput | undefined;
    protected placementWatch: ReturnType<typeof setInterval> | undefined;
    protected placementSeen: string;
    protected readonly originWatch: import("../../common/emulator-events").Disposable;
    protected readonly onDidChangeOutputEmitter: Emitter<DisplayOutput | undefined>;
    readonly onDidChangeOutput: Event<DisplayOutput | undefined>;
    get displayOutput(): DisplayOutput | undefined;
    protected borrower?: HTMLElement;
    protected borrowerResize?: ResizeObserver;
    protected borrowerFit: boolean;
    protected borrowerDecorate: boolean;
    constructor(instanceId: string);
    readonly tools: HTMLDivElement;
    readonly badges: HTMLDivElement;
    readonly stateBadges: HTMLDivElement;
    readonly strip: HTMLDivElement;
    takeCanvas(): HTMLCanvasElement;
    /**
     * Shows the running picture elsewhere (the Display settings) until it is given back. The canvas cannot be
     * copied, as the worker owns its presentation, so the frame moves whole with its overlay and the panel is
     * left empty. `fit` (default true) fills the borrower instead of using the dock's whole-number scale;
     * `decorate` (default false) keeps decoration and halo. The Display preview passes `{ fit: false, decorate: true }`
     */
    lendPicture(host: HTMLElement, opts?: {
        fit?: boolean;
        decorate?: boolean;
    }): void;
    get pictureSize(): {
        width: number;
        height: number;
    };
    returnPicture(): void;
    setDisplayMode(mode: DisplayMode): void;
    setHighlights(rects: VesScreenRect[]): void;
    setPixelLayer(layer: {
        left?: ImageData;
        right?: ImageData;
    } | undefined): void;
    get pictureElement(): HTMLElement;
    pointAt(clientX: number, clientY: number): {
        eye: 0 | 1;
        x: number;
        y: number;
    } | undefined;
    protected eyeSlots(): {
        eye: 0 | 1;
        x: number;
        y: number;
        width: number;
        height: number;
    }[];
    protected drawPixelLayer(context: CanvasRenderingContext2D): void;
    protected devicePixelAuto: boolean;
    protected insets: {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    /**
     * Keeps the picture clear of what lies over the panel's edges, while the panel itself, and so the halo and the
     * backdrop, still reaches them: a phone's on-screen controller beside the picture or under it, and the badges'
     * band above it. The picture is fitted to and centred in what is left, the halo follows it. Set by the Emulator
     * component, nothing elsewhere. Not applied while the picture is lent (the Display preview)
     */
    setPictureInsets(insets: {
        top: number;
        right: number;
        bottom: number;
        left: number;
    }): void;
    protected applyInsets(): void;
    /**
     * On a phone's few CSS pixels a whole-number scale wastes half the screen (×1 where ×1.7 would fit), while its
     * three device pixels per CSS pixel keep any multiple of a third square. So there Auto takes the largest scale
     * that lands on whole device pixels, or simply fills it where those steps are too coarse. Set by the Emulator
     * component while the layout is a phone's
     */
    setDevicePixelAuto(on: boolean): void;
    setScale(scale: string): void;
    setDecoration(spec: EmulatorDecorationSpec | undefined): void;
    setPlaceholder(src: string | undefined): Promise<void>;
    setStereoDepth(depth: number): void;
    protected placeholderEyes(left: Uint8ClampedArray, right: Uint8ClampedArray): {
        left: Uint8ClampedArray;
        right: Uint8ClampedArray;
    };
    protected readPlane(bitmap: ImageBitmap, sourceX: number, sourceWidth: number): Uint8ClampedArray | undefined;
    setPrompt(text: string | undefined): void;
    showPlaceholder(show: boolean): void;
    protected renderPlaceholder(): void;
    /**
     * A reduced stereo frame from Sim.readBackdrop for the `immersion` halo: legacy cells carry two eye
     * brightnesses mapped through the palette, VBC cells two RGB888 colors (two RGBA quads). Ignored unless
     * `immersion` is on and the picture is here or with a decorating borrower. While the still stands in, frames
     * are kept but not painted, as the game runs on behind the Display preview and would overwrite the still's halo
     */
    pushBackdrop(pixels: ArrayBuffer, width: number, height: number, colorMode?: boolean): void;
    protected repaintBackdrop(): void;
    protected applyDecoration(): void;
    protected paintBackdrop(source: Uint8ClampedArray, width: number, height: number, colorMode?: boolean): void;
    protected sizeGlow(): void;
    protected onResize(msg: Widget.ResizeMessage): void;
    protected onAfterShow(msg: Message): void;
    protected onAfterAttach(msg: Message): void;
    /**
     * Only decides how large the picture appears; integer scales keep the pixels square. `known` comes from
     * `onResize`'s `ResizeMessage`, what Lumino just wrote to `style.width`/`style.height`; other callers measure
     * the DOM. This panel is sized by a bare `ResizeObserver` (see `Emulator.tsx`) and Lumino only re-sends when
     * its cached size differs, so a DOM read of a stale intermediate value could stick and leave a gap below the
     * picture
     */
    protected relayout(known?: {
        width: number;
        height: number;
    }): void;
    /**
     * Lines an interleaved picture up with the display's pixels: the size is rounded to whole device pixels and
     * the position nudged onto one, as a line straddling two is seen by both eyes. The starting line is measured
     * from the screen top via the window's place, its chrome (assumed all at the top) and the picture's place in
     * the page. Exact in fullscreen, a good guess in a window (`swapEyes` covers the rest). Other modes use CSS
     */
    protected placeOnDevicePixels(canvas: HTMLCanvasElement, cssWidth: number, cssHeight: number): {
        width: number;
        height: number;
    };
    /**
     * The page's top (HLI) or left edge (VLI) on the display, in physical pixels. Exact when the host says (see
     * `screen-origin.ts`); otherwise worked out from the window, exact in fullscreen and at 100/200 % scaling,
     * possibly a line off at 125/150 %, as the browser rounds the window's place to CSS pixels. Firefox alone
     * reports the page's own place to a fraction and is asked first
     */
    protected pageStart(horizontal: boolean, ratio: number): number;
    protected watchPlacement(on: boolean): void;
    protected placement(): string;
    dispose(): void;
    protected announceOutput(output: DisplayOutput | undefined): void;
    protected drawHighlights(): void;
    protected strokeEye(context: CanvasRenderingContext2D, rect: VesScreenRect, eye: 0 | 1): void;
}
//# sourceMappingURL=emulator-screen-panel.d.ts.map