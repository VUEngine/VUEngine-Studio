import { VueportWidget } from '../emulator-widget-base';
import { Message } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import { DisplayMode } from '../../common/vb-constants';
import { EmulatorPanelType } from './emulator-panel';
/**
 * What is drawn around the picture where it does not fill the panel.
 *
 * `black` fills the panel behind the picture, the backdrop a real Virtual Boy
 * shows. `ambient` and `immersion` both cast a blurred halo out from the
 * picture's footprint — `ambient` in one fixed color, `immersion` from the
 * picture itself, fed frame by frame through {@link ScreenPanel.pushBackdrop}.
 * Both take an `intensity` from 0 to 1, applied as the halo's opacity — the
 * flat `ambient` fill at a fraction of it, so that the same number means about
 * the same strength either way. See `AMBIENT_INTENSITY_SCALE`.
 * `undefined` leaves the panel plain.
 */
export type EmulatorDecorationSpec = {
    readonly kind: 'black';
} | {
    readonly kind: 'ambient';
    readonly color: string;
    readonly intensity: number;
} | {
    readonly kind: 'immersion';
    readonly intensity: number;
};
/**
 * A rectangle in the Virtual Boy's own screen space, as the engine drew it.
 *
 * `parallax` is the sprite's, and is what separates the two eyes: the left is
 * drawn that far to the left of `x` and the right that far to the right, the
 * same way the VIP reads a world's `gp`.
 */
export interface VesScreenRect {
    x: number;
    y: number;
    width: number;
    height: number;
    parallax: number;
}
/**
 * How finely the frame's edge is read for the immersion halo.
 *
 * The picture is averaged into `COLUMNS x ROWS` cells; only the cells on the
 * border are ever used, one lamp each. This decides how closely the light can
 * follow the picture — the way the number of lamps does on a real Ambilight —
 * and nothing else. How the light is then laid out is `HALO_FIELD_*`.
 */
export declare const BACKDROP_COLUMNS = 48;
export declare const BACKDROP_ROWS = 30;
/**
 * The emulator's picture, in a panel of its own so it can be docked, resized
 * and rearranged alongside the debug views.
 *
 * The canvas is built imperatively rather than rendered by React: presentation
 * is transferred to the worker with transferControlToOffscreen, which can only
 * happen once per element, so an element that React might recreate would take
 * the picture with it.
 */
export declare class ScreenPanel extends VueportWidget {
    readonly kind = EmulatorPanelType.SCREEN;
    protected readonly frame: HTMLDivElement;
    /**
     * The box that clips the picture to its rounded corners.
     *
     * `border-radius` on the `<canvas>` itself is not reliably honored once the
     * browser gives the canvas its own compositing layer — the rounding shows
     * on the element box but not on the pixels. `overflow: hidden` on a plain
     * wrapper around it is. The overlay canvas goes in here too, so a highlight
     * drawn to the very edge is clipped the same way the picture is; the halo
     * stays outside, since it is meant to spill past the picture's footprint.
     */
    protected readonly picture: HTMLDivElement;
    /**
     * A line over the picture, for when the picture alone cannot say what is
     * going on. See {@link setPrompt}.
     */
    protected readonly prompt: HTMLDivElement;
    protected canvasElement?: HTMLCanvasElement;
    /**
     * A stand-in for the picture when no game is running — a still, run through
     * the current palette so a palette can be chosen with nothing loaded. Sits
     * in the picture beside the game canvas; only one of the two is shown.
     */
    protected placeholderCanvas?: HTMLCanvasElement;
    /**
     * The still's brightness, one byte per pixel at 384x224, one plane per eye
     * — the same plane twice for a one-eye screenshot. Undefined until a still
     * is set. Kept per eye so the stereo layouts can arrange them the way the
     * live renderer arranges the real picture.
     */
    protected placeholderLeft?: Uint8ClampedArray;
    protected placeholderRight?: Uint8ClampedArray;
    protected placeholderShown: boolean;
    /**
     * The last picture the worker sent for the `immersion` halo, kept so the
     * halo can be put back when the still stops standing in for it.
     *
     * The two feed the halo at very different rates: the still paints once,
     * when it is chosen, where a live frame arrives on a poll that stops the
     * moment the game is paused. Without a copy to repaint from, coming back
     * from the still to a paused picture would leave the still's halo behind
     * it. See {@link repaintBackdrop}.
     */
    protected liveBackdrop?: {
        pixels: Uint8ClampedArray;
        width: number;
        height: number;
        colorMode: boolean;
    };
    /**
     * The halo behind the picture; see {@link setDecoration}. Its own canvas,
     * drawn at a low resolution and blurred wide by CSS — a flat fill for
     * `ambient`, the picture's own pixels for `immersion`.
     */
    protected readonly glow: HTMLCanvasElement;
    protected decoration?: EmulatorDecorationSpec;
    /**
     * A second canvas over the picture, for marking things on it without
     * touching the frame the worker owns — that one has been transferred and
     * cannot be drawn to from here at all.
     */
    protected overlayCanvas?: HTMLCanvasElement;
    protected highlights: VesScreenRect[];
    /** The picture's displayed size in CSS pixels, from the last layout. */
    protected pictureBox: {
        width: number;
        height: number;
    };
    /**
     * How much larger than the picture the halo's box is, per axis. The
     * `immersion` grid carries its own ring of extruded edge color and so
     * wants the room to show it; a flat `ambient` fill only has to spill a
     * little before the blur takes over.
     */
    protected glowSpread: {
        x: number;
        y: number;
    };
    protected displayMode: DisplayMode;
    protected scale: string;
    /**
     * Where the picture is while it is somewhere other than this panel.
     *
     * Set by {@link lendPicture}; it is what the picture is sized against for
     * as long as it is away.
     */
    protected borrower?: HTMLElement;
    /**
     * The borrower is not a Lumino widget, so no resize message arrives when
     * it changes size. Watching it is what stands in for one.
     */
    protected borrowerResize?: ResizeObserver;
    /** Whether the borrowed picture fills its box; see {@link lendPicture}. */
    protected borrowerFit: boolean;
    /**
     * Whether the borrower wants the decoration and the scale kept, rather than
     * the plain fitted picture a palette window used to lend. The Display
     * preview does — its whole point is seeing them at work.
     */
    protected borrowerDecorate: boolean;
    constructor(instanceId: string);
    /**
     * A corner of the picture for the chrome to put things in.
     *
     * Empty, and stays empty as far as this panel is concerned: everything in
     * it is rendered by whoever owns the emulator, through a React portal.
     * This panel is imperative DOM — the canvas has to keep its identity
     * across renders, which is the whole reason — so it offers a place rather
     * than trying to draw what belongs to the chrome.
     *
     * Over the picture rather than beside it: what goes here says something
     * about what is running, and follows the picture wherever the dock puts
     * it.
     */
    readonly badges: HTMLDivElement;
    /**
     * The opposite corner, for what the machine is doing.
     *
     * Two slots rather than one because the two say different kinds of thing.
     * `badges` is the session: cheats somebody switched on, a macro recording,
     * a profile being taken — all of them things a person set up and might
     * forget. This is the machine: paused, muted, fast-forwarding. They wear
     * the same pill and behave the same way — press one to put a stop to what
     * it is announcing; which corner it is in is what says which kind it is.
     *
     * It earns its place when the chrome hides itself. With a toolbar on
     * screen the lit buttons say all of this already, and a host using that
     * chrome puts nothing here.
     */
    readonly stateBadges: HTMLDivElement;
    /**
     * Where the floating transport lives — see `EmulatorControlStrip` and the
     * `immersive` chrome on `Emulator`.
     *
     * A third slot beside the two above, and for the same reason: anything
     * put here follows the picture wherever the dock puts it. That matters
     * more here than for the badges, because the transport is meant to be
     * usable rather than just legible — a strip positioned against the whole
     * window would float over whatever panel happened to be in front in
     * Debug mode, one tile among several rather than the screen's own. Tabbed
     * out of view, this node is hidden along with the rest of the panel, and
     * so is whatever is portalled into it: no screen visible, no floating
     * controls for it either.
     */
    readonly strip: HTMLDivElement;
    /**
     * Hand out a fresh canvas for a new emulation session.
     *
     * Any previous one has already given up control to a worker that is going
     * away, so it is replaced rather than reused.
     */
    takeCanvas(): HTMLCanvasElement;
    /**
     * Show the running picture somewhere other than the dock, until it is
     * given back.
     *
     * The canvas cannot be copied: presentation belongs to the worker, and one
     * element holds it. So a second view of what the machine is drawing means
     * moving the one that exists — the frame goes whole, keeping the overlay
     * with it, and is sized against its new home instead of this panel.
     *
     * For something that covers the dock while it is up, since the panel is
     * left empty meanwhile: the Display settings, where seeing the picture is
     * how a palette is chosen.
     *
     * `fit` (default true) fills the borrower rather than following the scale
     * the dock is set to — the whole-number scales that keep the machine's
     * pixels square would otherwise leave it a small picture in a large box.
     * `decorate` (default false) keeps the decoration classes and the halo the
     * dock shows, rather than the plain picture a borrower usually wants; the
     * Display preview passes `{ fit: false, decorate: true }` so both the scale
     * and the decoration can be seen at work.
     */
    lendPicture(host: HTMLElement, opts?: {
        fit?: boolean;
        decorate?: boolean;
    }): void;
    /**
     * The picture's shape, in the machine's own pixels.
     *
     * For a borrower that has to give the picture a box of its own: the frame
     * fills whatever holds it, so a container sized by its content would
     * measure nothing and the picture would never be laid out at all. An
     * aspect ratio breaks that circle — see `EmulatorScreenPreview`. Which
     * shape it is depends on the display mode: the stereo layouts present two
     * eyes at once and are correspondingly wider or taller.
     */
    get pictureSize(): {
        width: number;
        height: number;
    };
    /** Put a lent picture back in the panel. Does nothing if it is here. */
    returnPicture(): void;
    setDisplayMode(mode: DisplayMode): void;
    /**
     * Mark rectangles on the picture, or clear it with an empty list.
     *
     * The rectangles are in the Virtual Boy's screen space; placing them is
     * this panel's job, since only it knows how the current mode arranges the
     * two eyes.
     */
    setHighlights(rects: VesScreenRect[]): void;
    setScale(scale: string): void;
    /**
     * Choose what fills the panel around the picture, or `undefined` for
     * nothing. `immersion` also needs the picture's pixels — see
     * {@link pushBackdrop} — and shows no halo until the first frame arrives.
     */
    setDecoration(spec: EmulatorDecorationSpec | undefined): void;
    /**
     * Give the panel a still to show when there is no game — a screenshot the
     * host points to, read once into a brightness plane so the current palette
     * can recolor it. `undefined` forgets it.
     */
    setPlaceholder(src: string | undefined): Promise<void>;
    /** One eye of the still: a slice of the bitmap as a 384x224 brightness plane. */
    protected readPlane(bitmap: ImageBitmap, sourceX: number, sourceWidth: number): Uint8ClampedArray | undefined;
    /**
     * Put a line over the picture, or take it away again with `undefined`.
     *
     * For the one thing a black picture cannot explain about itself: a window
     * the browser will not let start. Emulation is clocked by the audio, and a
     * page nobody has touched may not produce any — so the second player's
     * window, which its opener rather than a person brought into being, shows
     * nothing until it is clicked. See `audioStillBlocked` in `vb-core.ts`.
     *
     * Deliberately not a button. Any pointer or key event in the window is the
     * gesture the browser is waiting for, so there is nothing here to hit; the
     * prompt only has to be read.
     */
    setPrompt(text: string | undefined): void;
    /**
     * Show the still instead of the game canvas, or the other way round.
     *
     * The game keeps rendering in its worker either way — one canvas is just
     * hidden — which costs nothing worth avoiding for a picture this small.
     */
    showPlaceholder(show: boolean): void;
    /**
     * Paint the still through the current palette, laid out the way the current
     * rendering mode would lay out a live picture: one eye on its own, the two
     * mixed for Anaglyph, or the split and interleaved arrangements the stereo
     * modes present. The same brightness-to-color mapping {@link paintBackdrop}
     * does for the halo, drawn sharp into the picture instead of blurred behind.
     */
    protected renderPlaceholder(): void;
    /**
     * Hand the panel a frame of the picture for the `immersion` halo.
     *
     * A reduced stereo frame from {@link Sim.readBackdrop}. Legacy cells
     * carry the two eye brightnesses and are mapped through the palette; VBC
     * cells carry two RGB555 colors and bypass it. Ignored unless `immersion`
     * is the decoration and the picture is here or lent to a borrower that
     * keeps the decoration.
     *
     * Kept but not painted while the still stands in for the picture: the halo
     * belongs to what is on show, and the game goes on running behind the
     * Display preview, so painting every frame it sends would throw the still's
     * own halo away a few times a second. Kept rather than dropped so the live
     * halo is current again the moment the still steps aside.
     */
    pushBackdrop(pixels: ArrayBuffer, width: number, height: number, colorMode?: boolean): void;
    /**
     * Put the halo back in step with whichever picture is on show — the still
     * when it stands in, the last frame the worker sent otherwise.
     *
     * For the moments where the halo's own source changes rather than the
     * picture: switching the Display preview between the still and the live
     * image, or turning `immersion` on while the game is paused and no frame is
     * coming. Does nothing for the other decorations, which
     * {@link applyDecoration} draws in full.
     */
    protected repaintBackdrop(): void;
    /**
     * Put the decoration on the frame: the classes CSS keys off, and the flat
     * fill the `ambient` halo is. A borrowed picture wears none of it — the
     * halo belongs behind the picture where it plays, not in the small box a
     * palette window lends it — unless the borrower asked to keep it, which the
     * Display preview does.
     */
    protected applyDecoration(): void;
    /**
     * Draw the light the frame's border casts.
     *
     * The frame is averaged into cells and its border cells become lamps, each
     * mapped through the palette. Every point outside the picture then sums
     * what all of them throw at it, falling off with distance — so the light
     * dims outward, fans out from a bright spot instead of running straight,
     * and rounds off round the corners. The area behind the picture is never
     * seen; it is filled from the nearest lit point so that the blur over the
     * top has something continuous to work with rather than an edge.
     *
     * Any frame size is accepted: what the worker sends is already the grid,
     * what the still feeds it is a whole 384x224, and both average the same way.
     */
    protected paintBackdrop(source: Uint8ClampedArray, width: number, height: number, colorMode?: boolean): void;
    /**
     * The halo's box: the picture's, grown by whatever spread the last paint
     * wants — and a blur to match.
     *
     * The blur has to follow the box. The grid is a fixed number of cells but
     * the box it is stretched over is not, so a fixed radius smooths away most
     * of the grid at a small scale and leaves the cells showing at a large one.
     * Sized from the cell instead, the halo looks the same at every scale.
     */
    protected sizeGlow(): void;
    protected onResize(msg: Widget.ResizeMessage): void;
    protected onAfterShow(msg: Message): void;
    /** The panel has a size only once it is in the document. */
    protected onAfterAttach(msg: Message): void;
    /**
     * Size the picture within the panel.
     *
     * The backing store is whatever the display mode presents at; this only
     * decides how large it appears. Integer scales are preferred so that the
     * pixels stay square and sharp.
     *
     * `known` is the box to lay out against, when the caller already has it —
     * `onResize` passes Lumino's own `ResizeMessage` dimensions, which is what
     * Lumino itself just wrote to this node's `style.width`/`style.height` as
     * the authoritative answer. Every other caller here has no such message,
     * and measures the DOM directly instead, same as always. The two normally
     * agree, but do not have to: this panel is sized by a bare `ResizeObserver`
     * with no Lumino layout above it (see `Emulator.tsx`), and Lumino only
     * re-applies `style.height` — and sends the message this reads — when its
     * own cached size differs from what it just computed; a DOM read landing
     * on a stale intermediate value at the wrong moment would otherwise stick
     * until some unrelated resize happened to correct it, which is what left
     * a gap at the bottom of the picture every so often.
     */
    protected relayout(known?: {
        width: number;
        height: number;
    }): void;
    /**
     * Paint the marked rectangles, once per eye the current mode shows.
     *
     * Where those eyes end up on the canvas is the inverse of what the
     * renderer's shader does to get from a canvas pixel back to a source one,
     * so the two have to agree: side by side puts the right eye a screen
     * width along, Cyberscope squeezes each eye into 256 columns, and the
     * interleaved modes double one axis and offset the right eye by a line.
     */
    protected drawHighlights(): void;
    /** One rectangle, placed for one eye under the current layout. */
    protected strokeEye(context: CanvasRenderingContext2D, rect: VesScreenRect, eye: 0 | 1): void;
}
//# sourceMappingURL=emulator-screen-panel.d.ts.map