import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { VipIntensityWatcher } from './emulator-vip-memory';
/**
 * The two eyes' frame buffers, overlaid as a red/blue anaglyph — red for the
 * left eye, blue for the right, the same pairing the Anaglyph rendering mode
 * offers as "Red / Blue".
 *
 * A frame buffer's pixels are already resolved brightness levels rather than
 * palette indices (see VipFrameBuffer), so unlike the Characters and BGMaps
 * panels there is no palette to pick — only whether to read the levels from
 * the real BRTA/BRTB/BRTC registers or the flat generic ramp.
 */
export declare class FrameBuffersPanel extends Panel {
    protected error?: string;
    protected registers?: DataView;
    protected leftBytes?: Uint8Array;
    protected rightBytes?: Uint8Array;
    protected index: number;
    protected zoom: number;
    protected showLeft: boolean;
    protected showRight: boolean;
    protected showGenericColors: boolean;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected setIndex(index: number): void;
    protected rasterize(registers: DataView): ImageData;
    protected render(): React.ReactNode;
}
//# sourceMappingURL=emulator-vip-framebuffers-panel.d.ts.map