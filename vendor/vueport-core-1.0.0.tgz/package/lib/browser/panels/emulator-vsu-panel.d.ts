import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { VsuChannel } from './emulator-vsu-memory';
import { Sim } from '../core/vb-core';
/**
 * The VSU as a mixer: one strip per channel, and the waveform banks they play
 * from underneath.
 *
 * This was a ten-column table, which is the shape of the register map rather
 * than the shape of what the register map is doing. Music moves, and a table
 * refreshed ten times a second only ever shows where it happens to be — six
 * rows of changing numbers, with nothing saying which of them is the loud one.
 * A strip says it by being drawn: a waveform, a note name, two level bars, and
 * a channel that is silent has nothing on it.
 *
 * Polled like every other inspector, but not from memory: real hardware never
 * lets the VSU's registers be read back and this core matches that (see
 * VB_VSU_BASE's own comment), so readVsu composes the map out of the core's
 * own decoded copy of the VSU instead. That copy is the machine's present
 * tense — a channel switched on before this panel existed reads as on, and one
 * the hardware switched off itself when its interval elapsed reads as off —
 * and where the core keeps both what a channel was given and what it is
 * playing, what it is playing is what arrives here. Bit layouts for the map
 * are decoded in emulator-vsu-memory.ts; see there for sourcing, and
 * worker/vb-vsu-layout.ts for how the core's copy is found.
 *
 * Muting and soloing are the emulator's, not the game's: the worker holds a
 * muted channel's stereo level at zero at every frame break and hands back
 * what the game asked for, so isolating one instrument neither writes to the
 * VSU nor changes what this panel says the machine is doing. Both are given up
 * when the panel closes — a silenced channel with nothing on screen to explain
 * it would be a bug report.
 */
export declare class VsuPanel extends Panel {
    protected channels?: VsuChannel[];
    protected waveforms: (number[] | undefined)[];
    protected modulation?: number[];
    /** Peak of the machine's last frame of sound, per side, 0 to 1. */
    protected peakLeft: number;
    protected peakRight: number;
    protected error?: string;
    /**
     * When each waveform bank last changed, by bank; the modulation table is
     * the entry after them.
     *
     * Banks are not boot-time furniture. A driver rewrites one between notes
     * to change instrument, and a game with more than five voices' worth of
     * sounds reuses them constantly — so what they hold is polled like
     * everything else here, and one that has just changed is marked for
     * {@link CHANGED_MS} so that a rewrite is something you see happen rather
     * than something you notice afterwards.
     */
    protected changedAt: number[];
    /** Channels muted by hand, by index. */
    protected readonly muted: Set<number>;
    /** The one channel being listened to alone, if any. */
    protected soloed?: number;
    /** The mask last sent to the worker, so an unchanged one is not re-sent. */
    protected sentMask?: number;
    /** The machine that mask was sent to, so a new one is told again. */
    protected sentTo?: Sim;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    /**
     * The waveform banks and the modulation table, noting which have moved
     * since the last poll.
     *
     * The first reading of a table is not a change: everything would be marked
     * the moment the panel opened, which says nothing about the game.
     */
    protected readTables(map: Uint8Array): void;
    /** Whether a table was written recently enough to still be marked. */
    protected justChanged(table: number): boolean;
    /**
     * Which channels the mixer is holding silent: what was muted by hand, or,
     * while a channel is soloed, every other channel.
     */
    protected muteMask(): number;
    /** Tell the machine what to hold silent, if that is not what it was told. */
    protected pushMutes(mask?: number): Promise<void>;
    protected toggleMute(index: number): void;
    /**
     * Listen to one channel alone, or hand the mixer back to the mute buttons.
     *
     * One at a time: soloing another channel moves the solo rather than adding
     * to it, which is the question this button is pressed to answer — which of
     * the six is making that sound. The mutes are left alone underneath, so
     * dropping the solo brings back exactly the mixer that was there before.
     */
    protected toggleSolo(index: number): void;
    protected clearMutes(): void;
    /**
     * Everything audible again when the panel goes away.
     *
     * Through the machine directly rather than {@link pushMutes}, which would
     * have nothing to send to by the time the panel is disposed of.
     */
    protected releaseMutes(): void;
    /**
     * A closed panel leaves nothing muted.
     *
     * On detach rather than only on dispose: closing a tab takes the panel out
     * of the dock without disposing of it — the dock does that later, when the
     * panel is opened again — so a mute released only in `dispose` would
     * outlive the panel that explains it, and a channel would simply be missing
     * from the music with nothing on screen saying why.
     */
    protected onBeforeDetach(msg: Message): void;
    dispose(): void;
    protected render(): React.ReactNode;
    /**
     * What the six of them come to, measured off the machine's own last frame
     * of sound.
     *
     * The one thing in the panel that is not a register: registers say what
     * each channel was asked for, and this says what actually left the VSU.
     * A game whose music has stopped, or whose master volume is down, is
     * silent here while its channels still read as playing.
     */
    protected renderOutput(): React.ReactNode;
    protected renderStrip(channel: VsuChannel): React.ReactNode;
    /**
     * The shape the channel is playing, where there is one.
     *
     * Noise has no waveform to draw — it is an LFSR, and a picture of one
     * would be a picture of whatever the panel invented — so it says its
     * period instead, which is the thing that makes one tap sound different
     * from another.
     */
    protected renderStripWave(channel: VsuChannel): React.ReactNode;
    /**
     * The note, because a sound driver was written in notes.
     *
     * The frequency is there too, and both are what the channel is playing
     * right now rather than what it was started at: a swept channel's note
     * walks while you watch it. Noise is a rate and not a pitch — it steps a
     * shift register rather than a waveform — so it is only ever shown as one.
     */
    protected renderStripNote(channel: VsuChannel): React.ReactNode;
    /**
     * The level the channel is at, and where it is going.
     *
     * The arrow and the step time say nothing about a channel whose envelope
     * is switched off: the level simply stays where SxEV0 put it, which is the
     * common case and what most sound drivers do.
     */
    protected renderEnvelope(channel: VsuChannel): React.ReactNode;
    /** Sweep or modulation, which only the fifth channel has. */
    protected renderSweep(channel: VsuChannel): React.ReactNode;
    /**
     * The five waveform banks and the modulation table, drawn together.
     *
     * Together, because which bank a channel plays is a number in its strip
     * and means nothing without the shape behind it — and because the banks
     * are shared: two channels on the same bank change instrument together
     * whether anybody meant them to or not, which is visible here and nowhere
     * else. They are read on every poll like the rest of the panel, since a
     * driver rewrites them while the game plays.
     */
    protected renderTables(channels: VsuChannel[]): React.ReactNode;
}
//# sourceMappingURL=emulator-vsu-panel.d.ts.map