import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { VsuChannel } from './emulator-vsu-memory';
import { Sim } from '../core/vb-core';
/**
 * The VSU as a mixer: one strip per channel, the waveform banks underneath.
 * Real hardware never lets the VSU's registers be read back and this core matches that (see VB_VSU_BASE), so
 * readVsu composes the map from the core's own decoded VSU copy: what a channel is playing, not what it was given.
 * Bit layouts are decoded in emulator-vsu-memory.ts, worker/vb-vsu-layout.ts finds the core's copy.
 * Muting and soloing are the emulator's: the worker holds a muted channel's stereo level at zero at every frame
 * break and hands back what the game asked for, so the VSU is not written. Both are given up when the panel closes.
 */
export declare class VsuPanel extends Panel {
    protected channels?: VsuChannel[];
    protected waveforms: (number[] | undefined)[];
    protected modulation?: number[];
    protected peakLeft: number;
    protected peakRight: number;
    protected error?: string;
    protected changedAt: number[];
    protected readonly muted: Set<number>;
    protected soloed?: number;
    protected sentMask?: number;
    protected sentTo?: Sim;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected readTables(map: Uint8Array): void;
    protected justChanged(table: number): boolean;
    protected muteMask(): number;
    protected pushMutes(mask?: number): Promise<void>;
    protected toggleMute(index: number): void;
    protected toggleSolo(index: number): void;
    protected clearMutes(): void;
    protected releaseMutes(): void;
    protected onBeforeDetach(msg: Message): void;
    dispose(): void;
    protected render(): React.ReactNode;
    protected renderOutput(): React.ReactNode;
    protected renderStrip(channel: VsuChannel): React.ReactNode;
    protected renderStripWave(channel: VsuChannel): React.ReactNode;
    protected renderStripNote(channel: VsuChannel): React.ReactNode;
    protected renderEnvelope(channel: VsuChannel): React.ReactNode;
    protected renderSweep(channel: VsuChannel): React.ReactNode;
    protected renderTables(channels: VsuChannel[]): React.ReactNode;
}
//# sourceMappingURL=emulator-vsu-panel.d.ts.map