import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { VipCharacters, VipEye, VipIntensityWatcher, VipObject, VipWorld, VipWorldField } from './emulator-vip-memory';
import { VipWorldSources } from './emulator-vip-world-sources';
import { VbcState } from './emulator-vcu-memory';
import { VcuColors, VcuPlacement } from './emulator-vcu-colors';
type WorldPreviewMode = 'solo' | 'context';
export declare class WorldsPanel extends Panel {
    protected readonly exportFile?: VipExportFile | undefined;
    protected error?: string;
    protected registers?: DataView;
    protected worldBytes?: Uint8Array;
    protected charSegments: (Uint8Array | undefined)[];
    protected readonly sources: VipWorldSources;
    protected oamBytes?: Uint8Array;
    protected vbc?: VbcState;
    protected worldAttrBytes?: Uint8Array;
    protected vbColorPreview: boolean;
    protected colors?: VcuColors;
    protected selected: number;
    protected hbiasRow: number;
    protected eye: VipEye;
    protected previewMode: WorldPreviewMode;
    protected zoom: number;
    protected showGenericPalette: boolean;
    protected showOnlyDrawn: boolean;
    protected showExtents: boolean;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string, exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected allWorlds(): VipWorld[];
    protected listedWorlds(): VipWorld[];
    protected drawnWorlds(): VipWorld[];
    protected sourceWorlds(): VipWorld[];
    protected readSources(sim: Sim): Promise<void>;
    protected colorPreview(): boolean;
    protected readColors(sim: Sim): Promise<void>;
    protected world(): VipWorld | undefined;
    protected params(): DataView | undefined;
    protected paramsFor(index: number): DataView | undefined;
    protected selectWorld(index: number): void;
    protected setShowOnlyDrawn(value: boolean): void;
    protected setShowGenericPalette(value: boolean): void;
    protected setPreviewMode(mode: WorldPreviewMode): void;
    protected setVbColorPreview(value: boolean): void;
    protected setEye(eye: VipEye): void;
    protected palettes(registers: DataView): number[][];
    protected writeHalfword(address: number, value: number): Promise<void>;
    protected writeField(worldField: VipWorldField, value: number): void;
    protected writeHead(patch: Partial<VipWorld>): void;
    protected writePaletteOffset(value: number): void;
    protected writeHBias(world: VipWorld, row: number, eye: VipEye, value: number): void;
    /**
     * A screen-sized bitmap of the preview. Solo: the selected world alone. Context: every world the VIP would draw,
     * 31 downwards, stopping at End, all but the selected one faded and gray; uncovered area stays opaque black (the
     * Frame Buffers panel shows the hardware's own composite). A pixel whose palette entry is black is left alone,
     * the hardware's transparency for index 0. OBJECT worlds draw nothing here (their objects are in the Objects
     * panel). In color each pixel is its CRAM color (see VcuColors), the pixels the hardware leaves out are left
     * alone, and a faded world is grayed by its luma. `alone` draws that world only, for the exported file: cut to
     * its W+1 by H+1 rectangle as the BGMaps panel's Used by draws it, transparent where it draws nothing. An OBJECT
     * world has no rectangle and keeps the screen.
     */
    protected rasterize(registers: DataView, alone?: VipWorld): ImageData;
    protected drawObjects(registers: DataView, world: VipWorld, characters: VipCharacters, width: number, height: number, paint: (destX: number, destY: number, intensity: number) => void): void;
    protected drawObjectsInColor(registers: DataView, world: VipWorld, characters: VipCharacters, colors: VcuColors, width: number, height: number, put: (destX: number, destY: number, placement: VcuPlacement, value: number, charX: number, charY: number, shade: number) => void): void;
    protected drawnObjects(registers: DataView, world: VipWorld, characters: VipCharacters): VipObject[];
    protected paletteRegister(registers: DataView, register: number): number;
    protected objectGroupFor(index: number): number | undefined;
    protected objectPalette(registers: DataView, palette: number): number[];
    protected render(): React.ReactNode;
    protected renderList(worlds: VipWorld[]): React.ReactNode;
    protected onPanelKey(event: React.KeyboardEvent): void;
    reveal(target: ScreenInspectorTarget): void;
    protected revealSelected(behavior?: ScrollBehavior): void;
    protected renderWorldGroup(world: VipWorld): React.ReactNode;
    protected renderPropertiesGroup(world: VipWorld): React.ReactNode;
    protected renderToggle(label: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    protected segmentCountInput(value: number, commit: (value: number) => void): React.JSX.Element;
    protected renderHBiasGroup(world: VipWorld): React.ReactNode;
    protected renderColorGroup(world: VipWorld, vbc: VbcState, attrBytes: Uint8Array): React.ReactNode;
    protected exportPng(): Promise<void>;
    protected renderDisplayControls(): React.ReactNode;
    protected objectWorldNote(world: VipWorld): string;
    protected renderPreview(world: VipWorld): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-worlds-panel.d.ts.map