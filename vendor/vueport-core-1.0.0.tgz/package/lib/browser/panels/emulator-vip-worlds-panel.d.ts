import * as React from 'react';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
import { VipCharacters, VipEye, VipIntensityWatcher, VipObject, VipWorld, VipWorldField } from './emulator-vip-memory';
import { VipWorldSources } from './emulator-vip-world-sources';
import { VbcState } from './emulator-vcu-memory';
import { VcuColors, VcuPlacement } from './emulator-vcu-colors';
/**
 * What the preview draws: the selected world on its own, or the frame it is
 * part of.
 *
 * Solo answers "what is in this world", Context answers "where is it in the
 * picture, and what is in front of it" — the second of which is what a world
 * that cannot be found on screen needs, since the preview then shows it being
 * covered rather than showing nothing at all.
 */
type WorldPreviewMode = 'solo' | 'context';
/**
 * The VIP's 32 world attribute entries.
 *
 * Three columns, all decoded straight out of world attribute memory: the
 * thirty-two worlds in drawing order, the selected one's fields to read and
 * edit, and a preview of what that world alone puts on screen. Rendering that
 * preview is what makes this panel read character and BGMap memory too; the
 * list and the fields need neither. On a VB Color, once the game has switched
 * color on, the selected world's VCU palette offset is shown under its fields.
 */
export declare class WorldsPanel extends Panel {
    protected error?: string;
    protected registers?: DataView;
    protected worldBytes?: Uint8Array;
    protected charSegments: (Uint8Array | undefined)[];
    /** The BGMap segments and param tables of the worlds being drawn. */
    protected readonly sources: VipWorldSources;
    /** Object attribute memory, read only while an OBJECT world is drawn. */
    protected oamBytes?: Uint8Array;
    /**
     * What the VB Color game has switched on, and nothing while it has not:
     * every color field the panel shows is gated on this, so on a plain
     * Virtual Boy — or before the game unlocks the VCU — the panel is the
     * same one it always was. See `readVbcState`.
     */
    protected vbc?: VbcState;
    /**
     * The VCU's World Color Attribute RAM, a halfword per world, read only
     * while {@link vbc} is there. Not part of the preview, which is drawn in
     * the VIP's red, so a change to it does not mark the picture dirty.
     */
    protected worldAttrBytes?: Uint8Array;
    /**
     * Whether the preview is drawn in the colors the VB Color shows rather
     * than the VIP's red — only while {@link vbc} is there; see
     * {@link colorPreview}. On by default, since a VB Color game's picture in
     * red is a picture of something the player never sees.
     */
    protected vbColorPreview: boolean;
    /** The VCU's color tables the previewed worlds draw with, read only for a color preview. */
    protected colors?: VcuColors;
    /**
     * The world the fields and the preview describe. There is always one:
     * drawing starts at world 31, so that is where the panel opens.
     */
    protected selected: number;
    protected hbiasRow: number;
    protected eye: VipEye;
    protected previewMode: WorldPreviewMode;
    protected zoom: number;
    /**
     * Whether the preview shades the pixel values with an even ramp instead
     * of the palette registers the game has set up.
     *
     * Off: the preview now resolves the brightness registers the way the core
     * does, so with the real palettes it looks like the picture on screen —
     * which is what the world is being compared against. The even ramp is for
     * reading the tile data itself, palettes and fades taken out of it.
     */
    protected showGenericPalette: boolean;
    /**
     * Whether the panel keeps to the worlds the VIP actually draws: the list
     * stops before the world that ends the frame, and Context leaves out
     * that world, everything past it, and whatever is switched off for the
     * eye being shown.
     *
     * On, because the question the panel usually answers is what the
     * hardware puts on screen. Turning it off is for the times the answer is
     * that it puts nothing there.
     */
    protected showOnlyDrawn: boolean;
    protected showExtents: boolean;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /**
     * All thirty-two worlds, in the order the VIP draws them: 31 first, since
     * that is the first one the hardware considers.
     */
    protected allWorlds(): VipWorld[];
    /**
     * The worlds the list shows: all of them, or the ones before the world
     * that ends the frame.
     *
     * That world is left out with the rest: the End flag stops drawing at it
     * rather than after it, so the VIP never draws the world carrying it,
     * and from there down there is nothing on screen to look at unless it is
     * being looked for.
     */
    protected listedWorlds(): VipWorld[];
    /**
     * The worlds the preview draws, in the order the VIP draws them.
     *
     * Solo is the selected world alone, whether or not the hardware would
     * draw it — a world switched off is exactly the one worth looking at.
     * Context is what the list holds, which is the same question asked of
     * the same switch.
     */
    protected drawnWorlds(): VipWorld[];
    /**
     * The worlds whose memory has to be read: the ones the preview draws, and
     * the selected one whether or not it is among them.
     *
     * A world past the one that ends the frame is not drawn in Context, but
     * its fields are still what the panel is showing — the H-bias table
     * beside them would otherwise read as zeros.
     */
    protected sourceWorlds(): VipWorld[];
    /** Read the character, BGMap, param and object memory the preview draws from. */
    protected readSources(sim: Sim): Promise<void>;
    /** Whether the preview is drawn in VB Color: the game has switched it on, and so has the panel. */
    protected colorPreview(): boolean;
    /**
     * Read the VCU's color tables for the worlds the preview draws, or let
     * go of them when the preview is not in color.
     *
     * After {@link readSources}, since which BGMap segments' Color Attributes
     * are needed is which segments those worlds map from — plus the ones
     * their overplane cells are in, whose attributes the overplane draws
     * with. Object tables only when an OBJECT world is among them.
     */
    protected readColors(sim: Sim): Promise<void>;
    /** The selected world, decoded out of the last read of world memory. */
    protected world(): VipWorld | undefined;
    /** The selected world's param table, as a view, or undefined when it has none. */
    protected params(): DataView | undefined;
    /** One world's param table, as a view, or undefined when none was read. */
    protected paramsFor(index: number): DataView | undefined;
    protected selectWorld(index: number): void;
    protected setShowOnlyDrawn(value: boolean): void;
    protected setShowGenericPalette(value: boolean): void;
    /**
     * Whether the preview is of the one world or of the frame around it.
     *
     * Context draws from more of VRAM than Solo does — every drawn world's
     * map segments and param table — so the sources are read again rather
     * than only the picture being drawn again.
     */
    protected setPreviewMode(mode: WorldPreviewMode): void;
    protected setVbColorPreview(value: boolean): void;
    protected setEye(eye: VipEye): void;
    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][];
    /** Write one halfword of VRAM and pick the change straight back up. */
    protected writeHalfword(address: number, value: number): Promise<void>;
    /** One field of the selected world's attribute entry. */
    protected writeField(worldField: VipWorldField, value: number): void;
    /**
     * Everything the head halfword packs together, which has to be rewritten
     * whole: the mode, the map size and base, and the four flags.
     */
    protected writeHead(patch: Partial<VipWorld>): void;
    /**
     * The selected world's palette offset in World Color Attribute RAM.
     *
     * Only the low byte of the halfword is the offset; the high one is
     * written back as it was read, so editing the one does not clear
     * whatever a game keeps in the other.
     */
    protected writePaletteOffset(value: number): void;
    /** One eye's shift on one row of an H-bias world's param table. */
    protected writeHBias(world: VipWorld, row: number, eye: VipEye, value: number): void;
    /**
     * A screen-sized bitmap of what the preview shows.
     *
     * In Solo that is the selected world alone. In Context it is every world
     * the VIP would draw, in the order it draws them — 31 downwards, over one
     * another, stopping at the world that ends the frame — with everything
     * but the selected one faded and gray. The area nothing covers stays
     * opaque black; the Frame Buffers panel is the view that shows what the
     * hardware itself composited, objects and column table included.
     *
     * A pixel whose palette entry is black is left alone rather than painted,
     * which is the transparency the hardware gives palette index 0. Worlds in
     * OBJECT mode draw nothing here: their objects come out of OAM, which the
     * Objects panel lists.
     *
     * In a color preview each pixel is the CRAM color the VB Color gives it
     * — see VcuColors — and the pixels the hardware leaves out are the ones
     * left alone; a faded world is grayed by its luma, the same treatment
     * the red one gets.
     */
    protected rasterize(registers: DataView): ImageData;
    /**
     * The objects one OBJECT world puts on screen.
     *
     * Which of the four groups it draws is not in the world entry but in the
     * drawing order — see {@link objectGroupFor} — and within a group the
     * objects are drawn from the last index down to the first, so a lower
     * index lands on top. An object carries its own eye bits, which are what
     * decide whether it is in this eye's picture; the world's decide only
     * whether the world is drawn at all. Both of those are measured against
     * the core in `tests/object-group-probe.mjs`.
     */
    protected drawObjects(registers: DataView, world: VipWorld, characters: VipCharacters, width: number, height: number, paint: (destX: number, destY: number, intensity: number) => void): void;
    /**
     * The same objects in VB Color: each colored by its own OBJ Color
     * Attribute, through `put`, which adds the world's palette offset.
     *
     * Its own pixel loop rather than forEachVipObjectPixel, because coloring
     * a pixel takes where in the character it is — a Pixel Color Slot is laid
     * out in the character's own coordinates — and that loop only says what
     * value it found.
     */
    protected drawObjectsInColor(registers: DataView, world: VipWorld, characters: VipCharacters, colors: VcuColors, width: number, height: number, put: (destX: number, destY: number, placement: VcuPlacement, value: number, charX: number, charY: number, shade: number) => void): void;
    /**
     * The objects an OBJECT world puts in this eye's picture, in the order
     * they are drawn: its group's, from the last index down.
     */
    protected drawnObjects(registers: DataView, world: VipWorld, characters: VipCharacters): VipObject[];
    /**
     * A GPLT or JPLT register's byte, which is what a color pixel's shade is
     * read out of — or, with Generic Palette, one that gives each value its
     * own shade.
     */
    protected paletteRegister(registers: DataView, register: number): number;
    /** Which object group the given world draws, over the whole world list. */
    protected objectGroupFor(index: number): number | undefined;
    /** One object palette's shading, or the generic ramp in its place. */
    protected objectPalette(registers: DataView, palette: number): number[];
    protected render(): React.ReactNode;
    /**
     * The thirty-two worlds in drawing order, boiled down to what tells them
     * apart at a glance: the index, the mode, which eyes they are drawn to,
     * and the one that ends the frame.
     *
     * Tiles rather than table rows. There are four things to say about a
     * world and only one of them is a number, so a row of columns spent most
     * of its width on padding between them; a tile stacks the four and is
     * read as one thing. A column of its own rather than a table above the
     * fields, so that picking another world does not mean leaving the world
     * being looked at: the list, that world's fields and its preview are all
     * on screen at once.
     */
    protected renderList(worlds: VipWorld[]): React.ReactNode;
    /**
     * Walk the worlds with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by world index, so that the keys
     * reach exactly what the list shows and stop at its ends — with only the
     * drawn worlds listed, the ones from End down are not there to be walked
     * into.
     * The event is stopped rather than only defaulted, because the emulator
     * listens for keys on the node this panel sits inside and would otherwise
     * read an arrow as the D-pad and move the game while the panel is being
     * read — the Characters panel's sheet is walked the same way.
     */
    protected onPanelKey(event: React.KeyboardEvent): void;
    /**
     * Scroll the picked world's tile into view and put focus on it, so that
     * the ring and the selection are the same tile and the next arrow key
     * carries on from there.
     */
    protected revealSelected(): void;
    protected renderWorldGroup(world: VipWorld): React.ReactNode;
    /**
     * Everything the head halfword and the position registers hold, in a grid
     * three fields wide.
     *
     * The registers come in sets — the two segment counts, the three G and
     * the three M coordinates, the size pair, the param register and where it
     * points — and each set is a row of the grid, so the shape of the entry
     * is legible before a single value is read. Names sit above their
     * controls; beside them they would cost more width than the column has.
     */
    protected renderPropertiesGroup(world: VipWorld): React.ReactNode;
    /**
     * One of the panel's settings, as a switch.
     *
     * A switch rather than a checkbox because these take effect the moment
     * they are thrown — see the kit component, and the Characters panel's
     * toggles, which are laid out the same way: the control, then the name
     * beside it.
     */
    protected renderToggle(label: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    /** A picker for one of the four map sizes a world can have per axis. */
    protected segmentCountInput(value: number, commit: (value: number) => void): React.JSX.Element;
    protected renderHBiasGroup(world: VipWorld): React.ReactNode;
    /**
     * What the VB Color's VCU adds to the selected world: its entry in World
     * Color Attribute RAM.
     *
     * A group of its own rather than more fields in Properties, since it is
     * not part of the world entry — it lives in the VCU, at another address —
     * and is only there at all while the game has switched color on. The
     * offset is added to the CRAM palette of everything the world draws,
     * cells and, for an Object world, its objects; but only under CXCTRL's
     * WCEN, so with that off the value is shown as what it is — stored, not
     * used — rather than hidden, since a game that sets the offsets before
     * switching WCEN on is a thing worth seeing.
     */
    protected renderColorGroup(world: VipWorld, vbc: VbcState, attrBytes: Uint8Array): React.ReactNode;
    /**
     * How the preview is drawn, under it rather than as a group in the
     * sidebar — the Objects panel's arrangement: the scale on a line of its
     * own, which eye and how much of the frame on one line, the switches
     * under them in two columns, all to the right.
     */
    protected renderDisplayControls(): React.ReactNode;
    /**
     * What an OBJECT world is drawing, which the world entry itself does not
     * say: the group it takes is decided by how many OBJECT worlds the VIP
     * drew before reaching it.
     */
    protected objectWorldNote(world: VipWorld): string;
    protected renderPreview(world: VipWorld): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-worlds-panel.d.ts.map