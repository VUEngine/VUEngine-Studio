/**
 * The VSU's memory map and register decoders, all pure. Base addresses and block layout come from libgccvb's
 * audio.h; its bit tables are hedged ("for the most part untested"), so the per-bit layout follows the encoder the
 * studio ships for these registers (SoundEditor/Other/templating.ts, SxINT/SxLRV/SxEV0/SxEV1/S5SWP), its LSB-up
 * packing order reproduced as unpacking.
 * "Channel is sounding" is SxINT bit 7, settled against the core (tests/vsu-decode-probe.mjs). SxEV1 bit 0 only
 * says whether the envelope steps: a channel with a flat envelope and that bit clear plays perfectly loudly.
 */
export declare const VSU_WAVEFORM_BASES: number[];
export declare const VSU_WAVEFORM_COUNT: number;
export declare const VSU_WAVEFORM_SAMPLES = 32;
export declare const VSU_WAVEFORM_SAMPLE_STRIDE = 4;
export declare const VSU_WAVEFORM_BYTES: number;
export declare const VSU_MODULATION_BASE = 16777856;
export declare const VSU_MODULATION_SAMPLES = 32;
export declare const VSU_MODULATION_BYTES: number;
export declare const VSU_REGISTER_BASE = 16778240;
export declare const VSU_CHANNEL_STRIDE = 64;
export declare const VSU_CHANNEL_COUNT = 6;
export declare const VSU_REGISTER_BLOCK_BYTES: number;
export declare const VSU_SSTOP = 16778624;
export declare function vsuChannelAddress(index: number): number;
export declare enum VsuChannelRegister {
    SxINT = 0,
    SxLRV = 4,
    SxFQL = 8,
    SxFQH = 12,
    SxEV0 = 16,
    SxEV1 = 20,
    SxRAM = 24,
    S5SWP = 28
}
export declare enum VsuChannelKind {
    WAVE1 = 0,
    WAVE2 = 1,
    WAVE3 = 2,
    WAVE4 = 3,
    SWEEP = 4,
    NOISE = 5
}
export declare const VSU_CHANNEL_NAMES: Record<VsuChannelKind, string>;
export declare const VSU_CHANNEL_SHORT_NAMES: Record<VsuChannelKind, string>;
export declare enum VsuEnvelopeDirection {
    DECAY = 0,
    GROW = 1
}
export declare enum VsuSweepModulationFunction {
    SWEEP = 0,
    MODULATION = 1
}
export declare enum VsuSweepDirection {
    DOWN = 0,
    UP = 1
}
export declare const VSU_ENVELOPE_STEP_TIME_MS: number[];
export declare const VSU_INTERVAL_DURATION_MS: number[];
export declare const VSU_SWEEP_MODULATION_INTERVAL_MS: number[];
export declare const VSU_NOISE_TAP: ReadonlyArray<readonly [number, number]>;
export interface VsuChannelInterval {
    enabled: boolean;
    value: number;
    durationMs: number;
}
export interface VsuChannelEnvelope {
    enabled: boolean;
    repeat: boolean;
    direction: VsuEnvelopeDirection;
    initialValue: number;
    stepTime: number;
    stepMs: number;
}
export interface VsuChannelSweepModulation {
    enabled: boolean;
    repeat: boolean;
    function: VsuSweepModulationFunction;
    direction: VsuSweepDirection;
    shift: number;
    interval: number;
    intervalMs: number;
}
export interface VsuChannelNoise {
    tap: number;
    tapBit: number;
    period: number;
}
export interface VsuChannel {
    index: number;
    kind: VsuChannelKind;
    name: string;
    /**
     * SxINT bit 7: the channel is sounding; the core multiplies its sample by zero otherwise. The last thing a driver
     * writes when starting a note, as writing SxINT also reloads the interval and envelope counters. The hardware
     * clears it itself when a channel with an interval reaches its end; this decodes the core's own copy of the bit
     * rather than the last value written (see worker/vb-vsu-layout.ts).
     */
    enabled: boolean;
    frequencyRaw: number;
    frequencyHz: number;
    stepRateHz: number;
    left: number;
    right: number;
    interval: VsuChannelInterval;
    envelope: VsuChannelEnvelope;
    waveform?: number;
    sweepModulation?: VsuChannelSweepModulation;
    noise?: VsuChannelNoise;
    raw: {
        SxINT: number;
        SxLRV: number;
        SxFQL: number;
        SxFQH: number;
        SxEV0: number;
        SxEV1: number;
        SxRAM: number;
        S5SWP: number;
    };
}
export interface VsuNote {
    name: string;
    cents: number;
    midi: number;
}
export declare function vsuNoteOf(hz: number): VsuNote | undefined;
export declare function vsuNoteName(hz: number): string | undefined;
export declare function decodeVsuChannel(view: DataView, index: number): VsuChannel;
export declare function vsuChannelLevel(channel: VsuChannel, side: 'left' | 'right'): number;
export declare function vsuWaveformSamples(bytes: Uint8Array): number[];
export declare function vsuModulationSamples(bytes: Uint8Array): number[];
export declare function vsuSamplesEqual(a: number[] | undefined, b: number[] | undefined): boolean;
//# sourceMappingURL=emulator-vsu-memory.d.ts.map