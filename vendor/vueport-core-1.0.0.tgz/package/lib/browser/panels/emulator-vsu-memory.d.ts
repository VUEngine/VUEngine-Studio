/**
 * The VSU's (Virtual Sound Unit) memory map, and decoders for the registers
 * living in it.
 *
 * Base addresses and the register block's layout are transcribed from
 * `applications/electron/vb/libgccvb/source/audio.h`. That header's own bit
 * tables are hedged ("this table is for the most part untested, but looks to
 * be accurate"), so the per-bit layout below instead follows the more
 * trustworthy source: the encoder this project already ships for these same
 * registers, `.../editors/browser/components/SoundEditor/Other/templating.ts`
 * (the SxINT/SxLRV/SxEV0/SxEV1/S5SWP functions), which real ROMs are built
 * with and is therefore exercised on every VSU sound they play. Its packing
 * order, read from LSB up, is reproduced here as unpacking, from bit 0 up.
 *
 * Which bit of which register means "this channel is sounding" was settled
 * against the core itself rather than against either table — see
 * `tests/vsu-decode-probe.mjs`, which programs one channel two ways and
 * listens to what comes out. It is `SxINT` bit 7. `SxEV1` bit 0, which is
 * easily mistaken for it, only says whether the *envelope* steps: a channel
 * with a flat envelope and that bit clear plays perfectly loudly.
 *
 * Everything in this module is pure so it can be reasoned about, and reused,
 * without a running emulator.
 */
/**
 * Five waveform banks, each 32 samples. Like the VIP's VRAM, the VSU's bus is
 * wider than the eight-bit values it stores, so only every fourth byte holds
 * a sample; the rest is unused padding.
 */
export declare const VSU_WAVEFORM_BASES: number[];
export declare const VSU_WAVEFORM_COUNT: number;
export declare const VSU_WAVEFORM_SAMPLES = 32;
export declare const VSU_WAVEFORM_SAMPLE_STRIDE = 4;
export declare const VSU_WAVEFORM_BYTES: number;
/** Modulation data: the one channel in Modulation mode reads its frequency deltas from here. Same layout as a waveform bank. */
export declare const VSU_MODULATION_BASE = 16777856;
export declare const VSU_MODULATION_SAMPLES = 32;
export declare const VSU_MODULATION_BYTES: number;
/** Six channel register blocks, 0x40 bytes apart, starting here. */
export declare const VSU_REGISTER_BASE = 16778240;
export declare const VSU_CHANNEL_STRIDE = 64;
export declare const VSU_CHANNEL_COUNT = 6;
export declare const VSU_REGISTER_BLOCK_BYTES: number;
/**
 * Write-only: any write here with bit 0 set silences every channel at once.
 *
 * Nothing is stored here to display, and nothing has to be: it does that by
 * clearing the enable bits inside the core, which is where this module's
 * `enabled` is read from anyway.
 */
export declare const VSU_SSTOP = 16778624;
export declare function vsuChannelAddress(index: number): number;
/** Register offsets in bytes, from a channel's own base. */
export declare enum VsuChannelRegister {
    /** Channel enable (bit 7), auto-deactivate (bit 5), interval (bits 0-4). */
    SxINT = 0,
    SxLRV = 4,
    SxFQL = 8,
    SxFQH = 12,
    SxEV0 = 16,
    SxEV1 = 20,
    /** Waveform bank select. Channels 0-4 (every channel but Noise) only. */
    SxRAM = 24,
    /** Sweep/Modulation control. Channel 4 (Sweep/Modulation) only. */
    S5SWP = 28
}
export declare enum VsuChannelKind {
    WAVE1 = 0,
    WAVE2 = 1,
    WAVE3 = 2,
    WAVE4 = 3,
    SWEEP = 4,
    NOISE = 5
}
export declare const VSU_CHANNEL_NAMES: Record<VsuChannelKind, string>;
/**
 * The same, as a strip in the mixer names it: the channel's number says which
 * one it is, so the name only has to say what kind it is.
 */
export declare const VSU_CHANNEL_SHORT_NAMES: Record<VsuChannelKind, string>;
export declare enum VsuEnvelopeDirection {
    DECAY = 0,
    GROW = 1
}
export declare enum VsuSweepModulationFunction {
    SWEEP = 0,
    MODULATION = 1
}
export declare enum VsuSweepDirection {
    DOWN = 0,
    UP = 1
}
/** Milliseconds per envelope step, indexed by SxEV0's three-bit step time. */
export declare const VSU_ENVELOPE_STEP_TIME_MS: number[];
/** Milliseconds per interval, indexed by SxINT's five-bit interval value. */
export declare const VSU_INTERVAL_DURATION_MS: number[];
/**
 * Sweep/Modulation interval durations in milliseconds: the first seven for
 * the slow clock (S5SWP's "frequency" bit clear), the next seven for the fast
 * one (set), indexed by the three-bit interval field minus one (zero disables
 * sweep/modulation entirely).
 */
export declare const VSU_SWEEP_MODULATION_INTERVAL_MS: number[];
/** Noise channel taps, indexed by SxEV1's three-bit tap select: [tap bit, LFSR period]. */
export declare const VSU_NOISE_TAP: ReadonlyArray<readonly [number, number]>;
export interface VsuChannelInterval {
    enabled: boolean;
    /** Five-bit register value. */
    value: number;
    durationMs: number;
}
/**
 * The envelope: `SxEV0` for its shape, `SxEV1`'s low two bits for whether it
 * runs at all.
 *
 * `enabled` is *not* whether the channel sounds — that is `VsuChannel.enabled`,
 * from a different register. With the envelope switched off the level simply
 * stays at {@link initialValue}, which is a perfectly ordinary way to play a
 * note at a fixed volume, and is what most sound drivers do.
 */
export interface VsuChannelEnvelope {
    /** SxEV1 bit 0: the level steps towards its end. Off, it stays put. */
    enabled: boolean;
    /** SxEV1 bit 1: on reaching its end the level reloads instead of stopping there. */
    repeat: boolean;
    direction: VsuEnvelopeDirection;
    /**
     * The level the channel is playing at, 0-15.
     *
     * Named for the register field it occupies, which holds the level a note
     * is *loaded* with; what arrives here is the level the envelope has since
     * walked it to, which is the same number until the envelope starts
     * running. See `readVsu` in `vb-protocol.ts`.
     */
    initialValue: number;
    /** Three-bit register value. */
    stepTime: number;
    stepMs: number;
}
/** Channel 4 (Sweep/Modulation) only. */
export interface VsuChannelSweepModulation {
    enabled: boolean;
    repeat: boolean;
    function: VsuSweepModulationFunction;
    direction: VsuSweepDirection;
    /** Three-bit register value, 0-7. */
    shift: number;
    /** Zero disables sweep/modulation outright, regardless of `enabled`. */
    interval: number;
    intervalMs: number;
}
/** Channel 5 (Noise) only. */
export interface VsuChannelNoise {
    /** Three-bit register value, 0-7. */
    tap: number;
    tapBit: number;
    period: number;
}
export interface VsuChannel {
    index: number;
    kind: VsuChannelKind;
    name: string;
    /**
     * SxINT bit 7: the channel is sounding.
     *
     * The one bit that decides whether the channel contributes anything at
     * all — the core multiplies its sample by zero otherwise. It is the last
     * thing a sound driver writes when it starts a note, because writing
     * SxINT also reloads the interval and envelope counters.
     *
     * The hardware also clears it on its own, when a channel given an interval
     * reaches the end of it. That is in here too: what this decodes is the
     * core's own copy of the bit rather than the last value written to it —
     * see `worker/vb-vsu-layout.ts`.
     */
    enabled: boolean;
    /** Eleven-bit register value. */
    frequencyRaw: number;
    /**
     * What the channel is heard at: the note, for everything but Noise, which
     * has none. See `vsuFrequencyHz`.
     */
    frequencyHz: number;
    /**
     * The rate the register itself sets — 32 samples of a waveform, or one
     * step of the noise generator. Noise's {@link frequencyHz} is this.
     */
    stepRateHz: number;
    /** Four-bit register values, 0-15 each. */
    left: number;
    right: number;
    interval: VsuChannelInterval;
    envelope: VsuChannelEnvelope;
    /** Three-bit register value, 0-7; only banks 0-4 exist. Channels 0-4 only. */
    waveform?: number;
    sweepModulation?: VsuChannelSweepModulation;
    noise?: VsuChannelNoise;
    raw: {
        SxINT: number;
        SxLRV: number;
        SxFQL: number;
        SxFQH: number;
        SxEV0: number;
        SxEV1: number;
        SxRAM: number;
        S5SWP: number;
    };
}
/** A frequency as a musician reads it. */
export interface VsuNote {
    /** The note and its octave, written the way a tracker writes it: `A#4`. */
    name: string;
    /** How far the frequency is from that note, -50 to 50 cents. */
    cents: number;
    /** The MIDI note number, for anything that would rather have the number. */
    midi: number;
}
/**
 * The note a frequency is, or undefined for a frequency that is not one.
 *
 * Equal temperament against concert A, which is what every tracker and every
 * sound driver this emulator will ever meet is tuned to. The cents are kept
 * rather than rounded away because they are the interesting half while a
 * channel is sweeping: the note holds still and the error walks.
 */
export declare function vsuNoteOf(hz: number): VsuNote | undefined;
/** Just the name, for somewhere with no room to say how far off it is. */
export declare function vsuNoteName(hz: number): string | undefined;
/** Decode one channel's registers out of the full register block (VSU_REGISTER_BASE, VSU_REGISTER_BLOCK_BYTES). */
export declare function decodeVsuChannel(view: DataView, index: number): VsuChannel;
/**
 * How loud one side of a channel is, 0 to 1, or 0 for a channel that is off.
 *
 * The core's own level, `(volume * envelope >> 3) + (volume && envelope)`,
 * normalized — which is why a channel at full volume with its envelope at zero
 * is silent, and why one whose stereo level is zero on a side contributes
 * nothing to it however loud the envelope is.
 *
 * The core's own level, so this is what is being played rather than what the
 * note was started at — the two differ exactly while an envelope is running.
 */
export declare function vsuChannelLevel(channel: VsuChannel, side: 'left' | 'right'): number;
/** Every fourth byte holds a sample; six-bit unsigned (0-63). */
export declare function vsuWaveformSamples(bytes: Uint8Array): number[];
/**
 * The modulation table's steps, as the signed frequency offsets they are.
 *
 * Same one-sample-every-four-bytes layout as a waveform bank, but the values
 * are eight-bit two's complement: the channel in Modulation mode adds one of
 * these to its frequency at every modulation interval, so half of them pull
 * the pitch down.
 */
export declare function vsuModulationSamples(bytes: Uint8Array): number[];
/** Whether two readings of a table hold the same samples. */
export declare function vsuSamplesEqual(a: number[] | undefined, b: number[] | undefined): boolean;
//# sourceMappingURL=emulator-vsu-memory.d.ts.map