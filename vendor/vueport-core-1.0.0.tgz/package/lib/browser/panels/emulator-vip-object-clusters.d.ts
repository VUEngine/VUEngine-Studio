import { VipCharacters, VipEye, VipObject } from './emulator-vip-memory';
export interface VipObjectCluster {
    objects: number[];
    x: number;
    y: number;
    width: number;
    height: number;
}
/**
 * Groups the drawn objects into the figures they most likely make up. OAM is a flat list of 8×8 cells, so this
 * guesses from what a figure's objects nearly always share: their cells touch or overlap, corners included; they sit
 * at about one depth and are drawn to the same eyes (Wario Land draws its hero as one set per eye); and they are one
 * run of OAM in one group, so a gap of more than a few slots or an SPT boundary ends a figure.
 * With previous, the objects at the last look, a figure whose objects clearly moved in different ways is split
 * (see splitByMotion), with care, as it compares slots rather than objects and Wario Land rearranges its hero's slots
 * every animation frame.
 * Linking is transitive. Objects the VIP does not draw (off for both eyes, past the last group) and objects with a
 * blank character are left out, as games park unused objects that way next to figures
 */
export declare function vipObjectClusters(objects: readonly VipObject[], registers: DataView, characters: VipCharacters, eye: VipEye, previous?: readonly VipObject[]): VipObjectCluster[];
export declare function vipObjectClusterOf(clusters: readonly VipObjectCluster[], index: number): VipObjectCluster | undefined;
//# sourceMappingURL=emulator-vip-object-clusters.d.ts.map