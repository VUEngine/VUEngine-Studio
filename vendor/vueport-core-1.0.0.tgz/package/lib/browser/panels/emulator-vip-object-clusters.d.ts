import { VipCharacters, VipEye, VipObject } from './emulator-vip-memory';
/**
 * One guess at a figure the game has put together out of objects: which of
 * them it is made of, and the screen rectangle they cover for one eye.
 */
export interface VipObjectCluster {
    /** The objects' indexes, lowest first. */
    objects: number[];
    x: number;
    y: number;
    width: number;
    height: number;
}
/**
 * Group the drawn objects into the figures they most likely make up.
 *
 * The hardware has no such thing — OAM is a flat list of 8×8 cells — so this
 * is a guess from three things a figure's objects nearly always share:
 *
 * - They sit next to each other on screen: two of them are linked when their
 *   cells touch or overlap, corners included.
 * - They sit at about the same depth, since a figure whose parts had very
 *   different parallax would come apart in 3D, and they are drawn to the
 *   same eyes: Wario Land, for one, draws its hero as two sets of objects,
 *   one per eye. This is what separates two figures that merely touch on
 *   screen.
 * - They are one run of OAM, in one object group: a sprite's objects are
 *   written together, so a run that breaks — a gap of more than a few slots,
 *   or an SPT boundary — ends one figure even where the next one touches it.
 *
 * Given `previous` — the objects as they were at the last look — there is a
 * fourth, since a figure moves as one: a figure whose objects clearly moved
 * in two or more different ways is split along them. That is what tells two
 * figures apart that touch, at one depth, in one run of OAM, which the other
 * three cannot. It is applied with care, because what it compares is slots
 * rather than objects: Wario Land rearranges its hero's slots with every
 * frame of animation, so a figure is only split when nearly all of its
 * motion is known and nearly all of that falls into a few clear groups, well
 * apart — see splitByMotion.
 *
 * Linking is transitive, so a figure only needs each of its cells to touch
 * one other. Objects the VIP does not draw — switched off for both eyes, or
 * past the last group — are left out, and so are objects whose character is
 * blank: games park unused objects that way, often right next to a figure,
 * and one of those would join two figures that have nothing to do with each
 * other. An object that touches nothing is a figure of one.
 */
export declare function vipObjectClusters(objects: readonly VipObject[], registers: DataView, characters: VipCharacters, eye: VipEye, previous?: readonly VipObject[]): VipObjectCluster[];
/** The figure the given object is part of, if it is drawn at all. */
export declare function vipObjectClusterOf(clusters: readonly VipObjectCluster[], index: number): VipObjectCluster | undefined;
//# sourceMappingURL=emulator-vip-object-clusters.d.ts.map