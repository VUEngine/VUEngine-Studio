/** VB Color VCU aperture and its memory-mapped control block. */
export declare const VCU_MEMORY_BASE = 50331648;
/** 128 BG and 128 OBJ palettes of four packed RGB555 colors. */
export declare const VCU_CRAM_BASE = 50827264;
export declare const VCU_CRAM_COLORS = 1024;
export declare const VCU_CRAM_BYTES: number;
export declare const VCU_REGISTER_BASE = 50853888;
/**
 * The whole block, not just the part with names on it.
 *
 * VBC 1.1 reserves `0x0307F800`-`0x0307F8FF` — see `VBC_STATUS.md` — while
 * only the first sixteen bytes are documented registers. Reading the lot costs
 * one 256-byte fetch and is what lets the panel show the rest as it stands,
 * rather than leaving fifteen sixteenths of the block invisible because
 * nothing here has a name for it yet.
 */
export declare const VCU_REGISTER_BLOCK_BYTES = 256;
/** How much of the block above is named registers. */
export declare const VCU_NAMED_REGISTER_BYTES = 16;
export declare enum VcuRegister {
    VBCID0 = 0,
    VBCID1 = 2,
    VBCVER = 4,
    VBCCTRL = 6,
    CPUSPD = 8,
    COLCTRL = 10,
    CBKPAL = 12,
    LNKCTRL = 14
}
export declare const VBC_ID0_VALUE = 16982;
export declare const VBC_ID1_VALUE = 8515;
export declare const VBC_VERSION_VALUE = 257;
/** How many CRAM entries make one palette — four, as on the VIP. */
export declare const VCU_CRAM_PALETTE_SIZE = 4;
/** BG palettes come first in CRAM, then the same number of OBJ palettes. */
export declare const VCU_CRAM_BG_PALETTES = 128;
/** Convert the VCU's low-to-high R5G5B5 word into a CSS color. */
export declare function vcuRgb555(value: number): {
    css: string;
    dark: boolean;
};
//# sourceMappingURL=emulator-vcu-memory.d.ts.map