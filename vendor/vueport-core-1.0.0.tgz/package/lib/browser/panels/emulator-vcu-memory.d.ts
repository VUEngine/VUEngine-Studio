import type { Sim } from '../core/vb-core';
import type { DebugSource } from './emulator-panel';
/** VB Color VCU aperture and its memory-mapped control block. */
export declare const VCU_MEMORY_BASE = 50331648;
/** The VCU decodes 1 MiB, mirrored across the rest of region 3. */
export declare const VCU_APERTURE_BYTES = 1048576;
/** 256 palettes of four RGB888 colors (32-bit entries, red in the low byte), shared by BG cells and OBJs. */
export declare const VCU_CRAM_BASE = 50827264;
export declare const VCU_CRAM_COLORS = 1024;
export declare const VCU_CRAM_ENTRY_BYTES = 4;
export declare const VCU_CRAM_BYTES: number;
export declare const VCU_REGISTER_BASE = 50853888;
/**
 * The whole block, not just the part with names on it.
 *
 * VBC 1.0 reserves `0x0307F800`-`0x0307F8FF` — see `VBC_STATUS.md` — while
 * only the first 44 bytes are documented registers. Reading the lot costs
 * one 256-byte fetch and is what lets the panel show the rest as it stands,
 * rather than leaving most of the block invisible because nothing here has a
 * name for it yet.
 */
export declare const VCU_REGISTER_BLOCK_BYTES = 256;
/** How much of the block above is named registers. */
export declare const VCU_NAMED_REGISTER_BYTES = 44;
/**
 * Cell Color Attribute RAM: one byte per BGMap cell, in the same order as
 * BGMap memory. Bits 5-0 pick the palette group — the cell's CRAM palette is
 * that times four plus its GPLTS — and bit 7 (CHRSEL) hands palette and pixel
 * attribute over to its Character's entries while CXCTRL.CCEN is set.
 */
export declare const VCU_CELL_COLOR_BASE = 50724864;
export declare const VCU_CELL_COLOR_BYTES = 65536;
/** OBJ Color Attribute RAM: the same byte, one per object. */
export declare const VCU_OBJ_COLOR_BASE = 50790400;
export declare const VCU_OBJ_COLOR_BYTES = 1024;
/**
 * Character RAM Extension: Characters 2048-4095, sixteen bytes each and laid
 * out as four more segments of 512 — reachable by cells and objects while
 * CHRCTRL.CHREXT widens their character field to twelve bits.
 */
export declare const VCU_CHAR_EXT_BASE = 50794496;
export declare const VCU_CHAR_EXT_BYTES = 32768;
/** Cell Pixel Color Attribute RAM: one halfword per BG-map cell (PCE, OPQ, SLOT). */
export declare const VCU_CELL_PIXEL_ATTR_BASE = 50855936;
export declare const VCU_CELL_PIXEL_ATTR_BYTES = 131072;
/** OBJ Pixel Color Attribute RAM: one halfword per object. */
export declare const VCU_OBJ_PIXEL_ATTR_BASE = 50987008;
export declare const VCU_OBJ_PIXEL_ATTR_BYTES = 2048;
/** World Color Attribute RAM: one halfword per World, bits 7-0 the palette offset. */
export declare const VCU_WORLD_ATTR_BASE = 50989056;
export declare const VCU_WORLD_ATTR_BYTES = 64;
/** Backdrop Row Table: four RGB888 colors (one per shade, 32-bit entries) per frame-buffer row, shown where the Color Frame Buffer holds the Backdrop Marker 0xFF. */
export declare const VCU_BACKDROP_ROW_BASE = 50991104;
export declare const VCU_BACKDROP_ROW_BYTES = 4096;
/** Character Color Attribute RAM: per Character a Cell palette byte and an OBJ palette byte, used by placements whose Color Attribute carries CHRSEL (bit 7) while CXCTRL.CCEN is set. */
export declare const VCU_CHARACTER_COLOR_BASE = 50995200;
export declare const VCU_CHARACTER_COLOR_BYTES = 8192;
/** Character Pixel Color Attribute RAM: one Pixel Color Attribute halfword per Character, for the same placements. */
export declare const VCU_CHARACTER_PIXEL_ATTR_BASE = 51003392;
export declare const VCU_CHARACTER_PIXEL_ATTR_BYTES = 8192;
/** Pixel Color Slot RAM: 64-byte palette maps shared by cells and objects. */
export declare const VCU_PIXEL_SLOT_BASE = 51052544;
export declare const VCU_PIXEL_SLOT_BYTES = 64;
export declare const VCU_PIXEL_SLOT_COUNT = 1024;
export declare enum VcuRegister {
    VBCID0 = 0,
    VBCID1 = 2,
    VBCVER = 4,
    VBCCTRL = 6,
    CPUSPD = 8,
    COLCTRL = 10,
    CBKPAL = 12,
    LNKCTRL = 14,
    CHRCTRL = 16,
    MEMCTRL = 18,
    CBRTRA = 20,
    CBRTRB = 22,
    CBRTRC = 24,
    CXCTRL = 26,
    PCCAP = 28,
    DMASRCL = 32,
    DMASRCH = 34,
    DMADSTL = 36,
    DMADSTH = 38,
    DMALEN = 40,
    DMACTRL = 42
}
export declare const VBC_ID0_VALUE = 16982;
export declare const VBC_ID1_VALUE = 8515;
export declare const VBC_VERSION_VALUE = 256;
/** How many CRAM entries make one palette — four, as on the VIP. */
export declare const VCU_CRAM_PALETTE_SIZE = 4;
/** Tool convention only (the hardware has one palette space): BG palettes at 0-127, OBJ palettes at 128-255. */
export declare const VCU_CRAM_BG_PALETTES = 128;
/** Convert the VCU's RGB888 entry (red in the low byte, bits 31-24 ignored) into a CSS color. */
export declare function vcuRgb888(value: number): {
    css: string;
    dark: boolean;
};
/** CXCTRL's enables. */
export declare const VCU_CXCTRL_PCEN = 1;
export declare const VCU_CXCTRL_WCEN = 2;
export declare const VCU_CXCTRL_BKREN = 4;
export declare const VCU_CXCTRL_CCEN = 8;
/**
 * What a running VB Color game has switched on, read once per poll.
 *
 * Only there once the game has unlocked the VCU — VBCCTRL reads VBCEN after
 * the keyed write — since until then every other register reads zero and
 * every VCU memory read comes back empty: an inspector showing color fields
 * then would show a column of zeroes that says nothing.
 */
export interface VbcState {
    registers: DataView;
    /** CHRCTRL.CHREXT: cells and objects name twelve-bit characters. */
    chrext: boolean;
    /** COLCTRL.COLEN: the display is in color. */
    colen: boolean;
    pcen: boolean;
    wcen: boolean;
    bkren: boolean;
    ccen: boolean;
    /** CBKPAL: the backdrop's palette. */
    cbkpal: number;
}
/**
 * The VBC state of the inspected machine, or nothing when it is not a VB
 * Color or the game has not switched color on.
 *
 * Which is the one test every inspector's color fields go by, so they come
 * and go together.
 */
export declare function readVbcState(source: DebugSource, sim?: Sim | undefined): Promise<VbcState | undefined>;
/** The mask of a cell's or object's character field: twelve bits with CHREXT, eleven without. */
export declare function vbcCharMask(vbc: VbcState | undefined): number;
/** A Cell or OBJ Color Attribute byte. */
export interface VcuColorAttr {
    /** Bits 5-0: the palette group, a CRAM palette being group * 4 + GPLTS/JPLTS. */
    group: number;
    /** Bit 7: palette and pixel attribute come from the Character's entries (with CCEN). */
    chrsel: boolean;
}
export declare function decodeVcuColorAttr(byte: number): VcuColorAttr;
export declare function encodeVcuColorAttr(attr: VcuColorAttr, previous?: number): number;
/** A Pixel Color Attribute halfword: per cell, per object, or per Character. */
export interface VcuPixelAttr {
    /** Bit 15 (PCE): the pixels take their palettes from a Pixel Color Slot (with PCEN). */
    enabled: boolean;
    /** Bit 14 (OPQ): pixel value 0 is drawn rather than transparent. */
    opaque: boolean;
    /** Bits 9-0: which of the 1024 slots. */
    slot: number;
}
export declare function decodeVcuPixelAttr(halfword: number): VcuPixelAttr;
export declare function encodeVcuPixelAttr(attr: VcuPixelAttr, previous?: number): number;
/** The CRAM palette a placement draws with: its group above its two VIP palette bits, plus the World offset. */
export declare function vcuPlacementPalette(group: number, vipPalette: number, worldOffset?: number): number;
//# sourceMappingURL=emulator-vcu-memory.d.ts.map