import type { Sim } from '../core/vb-core';
import type { DebugSource } from './emulator-panel';
export declare const VCU_MEMORY_BASE = 50331648;
export declare const VCU_APERTURE_BYTES = 1048576;
export declare const VCU_CRAM_BASE = 50827264;
export declare const VCU_CRAM_COLORS = 1024;
export declare const VCU_CRAM_ENTRY_BYTES = 4;
export declare const VCU_CRAM_BYTES: number;
export declare const VCU_REGISTER_BASE = 50853888;
export declare const VCU_REGISTER_BLOCK_BYTES = 256;
export declare const VCU_NAMED_REGISTER_BYTES = 44;
export declare const VCU_CELL_COLOR_BASE = 50724864;
export declare const VCU_CELL_COLOR_BYTES = 65536;
export declare const VCU_OBJ_COLOR_BASE = 50790400;
export declare const VCU_OBJ_COLOR_BYTES = 1024;
export declare const VCU_CHAR_EXT_BASE = 50794496;
export declare const VCU_CHAR_EXT_BYTES = 32768;
export declare const VCU_CELL_PIXEL_ATTR_BASE = 50855936;
export declare const VCU_CELL_PIXEL_ATTR_BYTES = 131072;
export declare const VCU_OBJ_PIXEL_ATTR_BASE = 50987008;
export declare const VCU_OBJ_PIXEL_ATTR_BYTES = 2048;
export declare const VCU_WORLD_ATTR_BASE = 50989056;
export declare const VCU_WORLD_ATTR_BYTES = 64;
export declare const VCU_BACKDROP_ROW_BASE = 50991104;
export declare const VCU_BACKDROP_ROW_BYTES = 4096;
export declare const VCU_CHARACTER_COLOR_BASE = 50995200;
export declare const VCU_CHARACTER_COLOR_BYTES = 8192;
export declare const VCU_CHARACTER_PIXEL_ATTR_BASE = 51003392;
export declare const VCU_CHARACTER_PIXEL_ATTR_BYTES = 8192;
export declare const VCU_PIXEL_SLOT_BASE = 51052544;
export declare const VCU_PIXEL_SLOT_BYTES = 64;
export declare const VCU_PIXEL_SLOT_COUNT = 1024;
export declare enum VcuRegister {
    VBCID0 = 0,
    VBCID1 = 2,
    VBCVER = 4,
    VBCCTRL = 6,
    CPUSPD = 8,
    COLCTRL = 10,
    CBKPAL = 12,
    LNKCTRL = 14,
    CHRCTRL = 16,
    MEMCTRL = 18,
    CBRTRA = 20,
    CBRTRB = 22,
    CBRTRC = 24,
    CXCTRL = 26,
    PCCAP = 28,
    DMASRCL = 32,
    DMASRCH = 34,
    DMADSTL = 36,
    DMADSTH = 38,
    DMALEN = 40,
    DMACTRL = 42
}
export declare const VBC_ID0_VALUE = 16982;
export declare const VBC_ID1_VALUE = 8515;
export declare const VBC_VERSION_VALUE = 256;
export declare const VCU_CRAM_PALETTE_SIZE = 4;
export declare const VCU_CRAM_BG_PALETTES = 128;
export declare function vcuRgb888(value: number): {
    css: string;
    dark: boolean;
};
export declare const VCU_CXCTRL_PCEN = 1;
export declare const VCU_CXCTRL_WCEN = 2;
export declare const VCU_CXCTRL_BKREN = 4;
export declare const VCU_CXCTRL_CCEN = 8;
export interface VbcState {
    registers: DataView;
    chrext: boolean;
    colen: boolean;
    pcen: boolean;
    wcen: boolean;
    bkren: boolean;
    ccen: boolean;
    cbkpal: number;
}
export declare function readVbcState(source: DebugSource, sim?: Sim | undefined): Promise<VbcState | undefined>;
export declare function vbcCharMask(vbc: VbcState | undefined): number;
export interface VcuColorAttr {
    group: number;
    chrsel: boolean;
}
export declare function decodeVcuColorAttr(byte: number): VcuColorAttr;
export declare function encodeVcuColorAttr(attr: VcuColorAttr, previous?: number): number;
export interface VcuPixelAttr {
    enabled: boolean;
    opaque: boolean;
    slot: number;
}
export declare function decodeVcuPixelAttr(halfword: number): VcuPixelAttr;
export declare function encodeVcuPixelAttr(attr: VcuPixelAttr, previous?: number): number;
export declare function vcuPlacementPalette(group: number, vipPalette: number, worldOffset?: number): number;
//# sourceMappingURL=emulator-vcu-memory.d.ts.map