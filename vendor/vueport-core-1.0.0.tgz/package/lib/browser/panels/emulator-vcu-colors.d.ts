import type { Sim } from '../core/vb-core';
import { VbcState } from './emulator-vcu-memory';
export interface VcuPlacement {
    palette: number;
    slot?: Uint8Array;
    opaque: boolean;
}
export interface VcuColorParts {
    segments?: Iterable<number>;
    objects?: boolean;
    worlds?: boolean;
}
export declare function vipShade(paletteRegister: number, value: number): number;
/**
 * The VCU's color tables, for debugger previews in a VB Color game's colors instead of the VIP's red.
 * Follows the core's vipCellColor and vipDrawCell: a placement's palette is its Color Attribute's group above its
 * two VIP palette bits (or, with CHRSEL and CCEN, its Character's group), plus the World's offset under WCEN;
 * a Pixel Color Slot then picks a palette per pixel (0 keeps the placement's, 0xFF leaves the pixel out); the color is
 * the CRAM entry of that palette and the pixel's shade. Brightness is left out: a preview shows the colors set up,
 * not how bright a fade has them right now.
 */
export declare class VcuColors {
    readonly vbc: VbcState;
    protected readonly cram: Uint8Array;
    protected readonly slots: Uint8Array | undefined;
    protected readonly charColors: Uint8Array | undefined;
    protected readonly charPixels: DataView | undefined;
    protected readonly cellColors: ReadonlyMap<number, Uint8Array>;
    protected readonly cellPixels: ReadonlyMap<number, DataView>;
    protected readonly objectColors: Uint8Array | undefined;
    protected readonly objectPixels: DataView | undefined;
    protected readonly worldAttrs: Uint8Array | undefined;
    protected constructor(vbc: VbcState, cram: Uint8Array, slots: Uint8Array | undefined, charColors: Uint8Array | undefined, charPixels: DataView | undefined, cellColors: ReadonlyMap<number, Uint8Array>, cellPixels: ReadonlyMap<number, DataView>, objectColors: Uint8Array | undefined, objectPixels: DataView | undefined, worldAttrs: Uint8Array | undefined);
    static read(sim: Sim, vbc: VbcState, parts: VcuColorParts): Promise<VcuColors>;
    static readSync(read: (address: number, length: number) => Uint8Array, vbc: VbcState, parts: VcuColorParts): VcuColors;
    protected static ranges(vbc: VbcState, parts: VcuColorParts): ([number, number] | undefined)[];
    protected static assemble(vbc: VbcState, parts: VcuColorParts, tables: (Uint8Array | undefined)[]): VcuColors;
    character(char: number, layer: 0 | 1, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    cell(segment: number, cell: number, char: number, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    object(index: number, char: number, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    worldOffset(world: number): number;
    put(target: Uint8ClampedArray, offset: number, placement: VcuPlacement, value: number, charX: number, charY: number, shade: number, worldOffset?: number): boolean;
    same(other: VcuColors | undefined): boolean;
    protected fill(into: VcuPlacement, group: number, vipPalette: number, pixel: number): VcuPlacement;
}
export declare function vcuPlacement(): VcuPlacement;
//# sourceMappingURL=emulator-vcu-colors.d.ts.map