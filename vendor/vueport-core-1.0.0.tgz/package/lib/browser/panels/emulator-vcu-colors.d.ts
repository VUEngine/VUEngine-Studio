import type { Sim } from '../core/vb-core';
import { VbcState } from './emulator-vcu-memory';
/**
 * How one placement — a BGMap cell, an object, or a character on its own —
 * is colored: the CRAM palette it draws with, before any World offset, and
 * the Pixel Color Slot that overrides that pixel by pixel, if one applies.
 */
export interface VcuPlacement {
    palette: number;
    /** The slot's 64 bytes, in the character's own coordinates; only with PCE and PCEN. */
    slot?: Uint8Array;
    /** OPQ: pixel value 0 is drawn too — only while a slot applies. */
    opaque: boolean;
}
/** What a view wants colored, so that only those tables are read. */
export interface VcuColorParts {
    /** BGMap segments whose cells are drawn. */
    segments?: Iterable<number>;
    objects?: boolean;
    worlds?: boolean;
}
/**
 * The shade a VIP palette register gives a pixel value: the two bits of it the
 * value selects.
 *
 * Value 0 included, unlike the VIP's own shading, which hardwires it to black:
 * on a VB Color it is drawn with the register's low two bits under OPQ.
 */
export declare function vipShade(paletteRegister: number, value: number): number;
/**
 * The VCU's color tables, as a debugger view needs them to draw a preview in
 * the colors a VB Color game shows instead of the VIP's red.
 *
 * Follows the core's `vipCellColor` and `vipDrawCell`: a placement's palette
 * is its Color Attribute's group above its two VIP palette bits — or, with
 * CHRSEL and CCEN, its Character's group — plus the World's offset under
 * WCEN; a Pixel Color Slot then picks a palette per pixel (0 keeps the
 * placement's, 0xFF leaves the pixel out); and the color is the CRAM entry of
 * that palette and the pixel's shade. What the brightness references do to it
 * on the way to the screen is left out: a preview shows the colors the game
 * set up, not how bright a fade has them at this moment.
 */
export declare class VcuColors {
    readonly vbc: VbcState;
    protected readonly cram: Uint8Array;
    protected readonly slots: Uint8Array | undefined;
    protected readonly charColors: Uint8Array | undefined;
    protected readonly charPixels: DataView | undefined;
    protected readonly cellColors: ReadonlyMap<number, Uint8Array>;
    protected readonly cellPixels: ReadonlyMap<number, DataView>;
    protected readonly objectColors: Uint8Array | undefined;
    protected readonly objectPixels: DataView | undefined;
    protected readonly worldAttrs: Uint8Array | undefined;
    protected constructor(vbc: VbcState, cram: Uint8Array, slots: Uint8Array | undefined, charColors: Uint8Array | undefined, charPixels: DataView | undefined, cellColors: ReadonlyMap<number, Uint8Array>, cellPixels: ReadonlyMap<number, DataView>, objectColors: Uint8Array | undefined, objectPixels: DataView | undefined, worldAttrs: Uint8Array | undefined);
    /**
     * Read what drawing `parts` in color takes, and nothing more: the slots
     * only while PCEN makes them count, the Character entries only while CCEN
     * does, the World offsets only under WCEN.
     */
    static read(sim: Sim, vbc: VbcState, parts: VcuColorParts): Promise<VcuColors>;
    /**
     * The same, from memory that can be read on the spot — what a machine
     * driven from a script has, see `vueport-probe`.
     */
    static readSync(read: (address: number, length: number) => Uint8Array, vbc: VbcState, parts: VcuColorParts): VcuColors;
    /** What to read for `parts`, in the order `assemble` takes it; undefined for a table not wanted. */
    protected static ranges(vbc: VbcState, parts: VcuColorParts): ([number, number] | undefined)[];
    protected static assemble(vbc: VbcState, parts: VcuColorParts, tables: (Uint8Array | undefined)[]): VcuColors;
    /**
     * The Character's entries for a placement of it on `layer` — 0 for cells,
     * 1 for objects — or for the character on its own, as the Characters
     * panel draws it.
     */
    character(char: number, layer: 0 | 1, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    /** A BGMap cell's coloring: `cell` 0-4095 within `segment`. */
    cell(segment: number, cell: number, char: number, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    /** An object's coloring. */
    object(index: number, char: number, vipPalette: number, into?: VcuPlacement): VcuPlacement;
    /** What a World adds to the palettes of everything it draws: its offset under WCEN, else 0. */
    worldOffset(world: number): number;
    /**
     * Write the color one pixel of a placement comes out as, and say whether
     * there was one: false for a pixel the hardware leaves out — value 0
     * without OPQ, or a slot byte of 0xFF — which the caller fills however its
     * view shows nothing.
     *
     * `charX`/`charY` are in the character's own coordinates, flips already
     * undone, and `shade` is the pixel's shade — see {@link vipShade}.
     */
    put(target: Uint8ClampedArray, offset: number, placement: VcuPlacement, value: number, charX: number, charY: number, shade: number, worldOffset?: number): boolean;
    /**
     * Whether `other` would draw everything the same: the same switches and
     * the same bytes in every table. What a view caching its picture checks
     * before drawing it again.
     */
    same(other: VcuColors | undefined): boolean;
    protected fill(into: VcuPlacement, group: number, vipPalette: number, pixel: number): VcuPlacement;
}
/** A placement to reuse between pixels, so drawing a world does not allocate per pixel. */
export declare function vcuPlacement(): VcuPlacement;
//# sourceMappingURL=emulator-vcu-colors.d.ts.map