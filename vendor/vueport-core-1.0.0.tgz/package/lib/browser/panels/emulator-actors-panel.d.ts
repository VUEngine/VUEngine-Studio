import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Sim } from '../core/vb-core';
import { VesActor, VesActorsRead } from '../core/emulator-actors';
import { VesFieldValue } from '../core/emulator-dwarf';
import { SymbolIndex } from '../core/emulator-symbols';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
declare enum ActorsStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    NO_SYMBOLS = "noSymbols",
    NO_LAYOUTS = "noLayouts",
    NOT_INITIALIZED = "notInitialized",
    STALE_SYMBOLS = "staleSymbols"
}
type DetailTab = 'fields' | 'components';
type ComponentSortColumn = 'class' | 'rectangle' | 'parallax' | 'index' | 'address';
interface TreeRow {
    key: string;
    depth: number;
    kind: 'actor' | 'group' | 'container';
    label: string;
    className: string;
    actor?: VesActor;
    members?: VesActor[];
    expandable: boolean;
    open: boolean;
}
interface FieldGroup {
    className: string;
    fields: VesFieldValue[];
}
/**
 * Every live actor as the scene tree it makes (found by readActors), and everything the selected one holds. Each
 * actor records its container, so the list is a tree under the stage, with runs of identical siblings folded.
 * The inspector reads the selected actor using the layout the build's debug sections give for its exact class,
 * with fields sorted under the class that declared them. The screen inspector picks actors off the picture.
 */
export declare class ActorsPanel extends Panel {
    protected static readonly ACTORS_POLL_HZ = 4;
    protected status: ActorsStatus;
    protected read?: VesActorsRead;
    protected symbols?: SymbolIndex;
    protected error?: string;
    protected reading: boolean;
    protected componentSort: TableSort<ComponentSortColumn>;
    protected selected?: number;
    protected readonly names: Map<number, string>;
    protected filter: string;
    protected fieldFilter: string;
    protected showHidden: boolean;
    protected tab: DetailTab;
    protected readonly closed: Set<string>;
    protected readonly opened: Set<string>;
    protected readonly flippedGroups: Set<string>;
    protected trackedActor?: number;
    protected readonly lastTexts: Map<string, string>;
    protected readonly changedAt: Map<string, number>;
    protected scrollPending: boolean;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected onUpdateRequest(msg: Message): void;
    protected refresh(): Promise<void>;
    protected noteChanges(): void;
    protected resolveNames(sim: Sim): Promise<void>;
    protected reset(status: ActorsStatus): void;
    protected actors(): VesActor[];
    protected actorAt(address: number): VesActor | undefined;
    protected selectedActor(): VesActor | undefined;
    protected select(objectAddress: number): void;
    reveal(target: ScreenInspectorTarget): void;
    protected applyHighlights(): void;
    protected ownNameOf(actor: VesActor): string;
    protected labelOf(actor: VesActor): string;
    protected parentKey(parent: number): string;
    protected groupKey(actor: VesActor): string;
    protected treeRows(): TreeRow[];
    protected toggle(row: TreeRow): void;
    protected render(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    protected renderTree(selected: VesActor): React.ReactNode;
    protected renderInspector(actor: VesActor): React.ReactNode;
    protected tabButton(tab: DetailTab, label: string, count: number): React.ReactNode;
    protected facts(actor: VesActor): [string, React.ReactNode, string?][];
    protected fieldGroups(actor: VesActor): FieldGroup[];
    protected renderFields(groups: FieldGroup[]): React.ReactNode;
    protected fieldValue(field: VesFieldValue, name: string): React.ReactNode;
    protected renderComponents(actor: VesActor): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-actors-panel.d.ts.map