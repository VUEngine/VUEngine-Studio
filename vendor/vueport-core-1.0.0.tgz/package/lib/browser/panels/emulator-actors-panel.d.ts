import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Sim } from '../core/vb-core';
import { VesFieldValue, VesStruct } from '../core/emulator-dwarf';
import { readMemoryPoolBlocks, VesMemoryPoolLayout } from '../core/emulator-memory-pool';
import { VesScreenRect } from './emulator-screen-panel';
import { SymbolIndex } from '../core/emulator-symbols';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
/** Why the panel has nothing to show, when it has nothing to show. */
declare enum ActorsStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    NO_SYMBOLS = "noSymbols",
    NO_LAYOUTS = "noLayouts",
    NOT_INITIALIZED = "notInitialized",
    STALE_SYMBOLS = "staleSymbols"
}
/** One component attached to an actor. */
interface ActorComponentEntry {
    address: number;
    className: string;
    /** Set for a sprite: where the engine last drew it. */
    rect?: VesScreenRect;
    /** Sprites only: whether it is being shown and was rendered. */
    shown?: boolean;
    /** Sprites only: the DRAM block it configures, or -1 when unassigned. */
    index?: number;
}
/** One live actor, as read out of the block it occupies. */
interface ActorEntry {
    objectAddress: number;
    blockAddress: number;
    blockSize: number;
    className: string;
    /** The class this was read as, which is a base when the exact one is unknown. */
    readAs: string;
    /** The class and everything above it, for saying what it is. */
    ancestry: string[];
    components: ActorComponentEntry[];
    fields: VesFieldValue[];
    namePointer?: number;
    /** The spec it was built from, as the project named it. */
    spec?: string;
    /** Where in that spec the pointer landed, which is normally its start. */
    specOffset?: number;
    specAddress?: number;
    internalId?: number;
    hidden?: boolean;
    position: (number | undefined)[];
}
type ActorSortColumn = 'spec' | 'class' | 'id' | 'x' | 'y' | 'z' | 'block' | 'address';
type ComponentSortColumn = 'class' | 'rectangle' | 'parallax' | 'address';
/**
 * Every actor currently alive, and everything one of them holds.
 *
 * Actors are what a VUEngine game is made of, and they live in the same memory
 * pools everything else does — so the engine has no list of them, only blocks
 * that happen to hold one. Finding them means three things the build already
 * knows: which blocks are occupied, which class each occupant is (its vTable
 * pointer), and whether that class descends from `Actor` (the chain of
 * `getBaseClass` stubs). A project's own `PlayerRacer` is therefore found the
 * same way the engine's own classes are, without knowing anything about it.
 *
 * The detail view reads the selected actor field by field, using the layout
 * the build's debug sections give for its exact class — so a subclass shows
 * its own fields under the inherited ones, again without this knowing what
 * they are.
 */
export declare class ActorsPanel extends Panel {
    /** As for the pools: a whole-heap read, and every block in it walked. */
    protected static readonly ACTORS_POLL_HZ = 4;
    protected status: ActorsStatus;
    protected actors: ActorEntry[];
    protected error?: string;
    protected reading: boolean;
    protected actorSort: TableSort<ActorSortColumn>;
    protected componentSort: TableSort<ComponentSortColumn>;
    /** The selected actor, by the address of the object rather than its row. */
    protected selected?: number;
    /** Resolved `char*` names, which do not change once an actor has one. */
    protected readonly names: Map<number, string>;
    /**
     * Whether the selected actor is marked on the picture.
     *
     * Deliberately just a field: it belongs to this panel while it is open and
     * is meant to go away with it, so it stays out of both the saved layout
     * and any preference.
     */
    protected highlighting: boolean;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected refresh(): Promise<void>;
    /** Turn the occupied blocks into the ones that hold actors. */
    protected collect(symbols: SymbolIndex, blocks: ReturnType<typeof readMemoryPoolBlocks>, region: Uint8Array, layout: VesMemoryPoolLayout): ActorEntry[];
    /**
     * Every live component, grouped by the actor it belongs to.
     *
     * Components are pool allocations like everything else, and each one
     * records its `owner`, so the blocks already read contain all of them and
     * the grouping is a scan rather than a traversal. This deliberately does
     * not go through `Entity::components`: that array is a cache the engine
     * fills the first time the game asks for a type, so it is NULL on most
     * actors and complete on almost none.
     */
    protected groupComponents(symbols: SymbolIndex, region: Uint8Array, layout: VesMemoryPoolLayout, blocks: ReturnType<typeof readMemoryPoolBlocks>): Map<number, ActorComponentEntry[]>;
    /** One component, with its rectangle when it is something that draws. */
    protected readComponent(symbols: SymbolIndex, region: Uint8Array, layout: VesMemoryPoolLayout, address: number, className: string): ActorComponentEntry;
    /**
     * Which spec an actor was built from.
     *
     * `Actor::constructor` keeps the spec it was configured with, and a spec is
     * a global the project wrote — `_PlayerRacerActorSpec` and 878 others in a
     * real game — so the pointer names it. That is worth more than anything
     * else on an actor for telling one from another: the engine's own `name`
     * field is optional and usually NULL, while every actor built from a spec
     * has one of these.
     */
    protected specOf(index: SymbolIndex, pointer: number | undefined): {
        spec?: string;
        specOffset?: number;
        specAddress?: number;
    };
    /**
     * The layout to read an actor by: its own class', or the nearest ancestor
     * the build described that fits in the block.
     *
     * Two things send this up the chain. A class whose struct the debug
     * sections do not carry — one the compiler never had to lay out — still
     * has everything an `Actor` has at the same offsets, because the class
     * macro puts inherited fields first. And a layout larger than the block
     * holding it cannot be the right one, since the allocator picked a block
     * the real class fits in; reading it anyway would present the next
     * block's bytes as this object's fields. Either way the fallback reads
     * fewer fields, never wrong ones.
     */
    protected layoutFor(index: SymbolIndex, className: string, availableBytes: number): VesStruct | undefined;
    /**
     * Fetch a few of the names not yet known.
     *
     * Bounded per refresh because each is a round trip of its own; over a
     * couple of ticks every actor on screen has one, and the cache means it is
     * never asked for twice.
     */
    protected resolveNames(sim: Sim): Promise<void>;
    protected reset(status: ActorsStatus): void;
    protected select(objectAddress: number): void;
    /**
     * Mark the selected actor's sprites on the picture.
     *
     * Only sprites have a rectangle: a component that draws nothing is not
     * anywhere on screen, and an actor made only of those is highlighted by
     * nothing rather than by a box at the origin.
     */
    protected applyHighlights(): void;
    /** The name the game gave this actor, if it gave it one. */
    protected ownNameOf(actor: ActorEntry): string;
    /**
     * What identifies an actor in the list.
     *
     * The spec it was built from, which nearly every actor has and which is
     * stable across runs. One built without a global spec falls back to the
     * address of whatever it was configured from, since that at least tells
     * two of them apart.
     */
    protected specLabelOf(actor: ActorEntry): string;
    protected render(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    /**
     * What the actor is made of.
     *
     * Sprites carry the rectangle they were last drawn at, which is what the
     * picture is marked with; anything else is listed by class alone, because
     * that is all a component that draws nothing has to say from here.
     */
    protected renderComponents(actor: ActorEntry): React.ReactNode;
    protected renderList(selected: ActorEntry): React.ReactNode;
    /**
     * Everything the selected actor holds.
     *
     * The fields are whatever its class declares rather than a chosen set, so
     * a project's own subclass shows its own state without this knowing what
     * that is. Nested structs are flattened into their leaves, which is where
     * the numbers actually are.
     */
    protected renderDetail(actor: ActorEntry): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-actors-panel.d.ts.map