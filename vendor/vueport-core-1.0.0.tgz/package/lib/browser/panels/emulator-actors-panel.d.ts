import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Sim } from '../core/vb-core';
import { VesActor, VesActorsRead } from '../core/emulator-actors';
import { VesFieldValue } from '../core/emulator-dwarf';
import { SymbolIndex } from '../core/emulator-symbols';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
/** Why the panel has nothing to show, when it has nothing to show. */
declare enum ActorsStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    NO_SYMBOLS = "noSymbols",
    NO_LAYOUTS = "noLayouts",
    NOT_INITIALIZED = "notInitialized",
    STALE_SYMBOLS = "staleSymbols"
}
type DetailTab = 'fields' | 'components';
type ComponentSortColumn = 'class' | 'rectangle' | 'parallax' | 'index' | 'address';
/** One row of the tree: an actor, a fold of like siblings, or the container at the top. */
interface TreeRow {
    key: string;
    depth: number;
    kind: 'actor' | 'group' | 'container';
    label: string;
    className: string;
    actor?: VesActor;
    /** A fold's members, for its count. */
    members?: VesActor[];
    expandable: boolean;
    open: boolean;
}
/** The fields one class of the chain declares. */
interface FieldGroup {
    className: string;
    fields: VesFieldValue[];
}
/**
 * Every actor currently alive, as the scene tree it makes, and everything the
 * selected one holds.
 *
 * How they are found is `readActors`' business. What this adds is the shape:
 * each actor records the container it was added to, so the list is a tree
 * under the stage, with an actor's children under it and runs of identical
 * siblings folded into one row — a level's forty coins are one line until
 * someone wants them.
 *
 * The inspector beside it reads the selected actor field by field, using the
 * layout the build's debug sections give for its exact class, and sorts the
 * fields under the class that declared them — so a subclass shows its own
 * state first and what it inherits folded away, without this knowing what any
 * of it is.
 *
 * The screen inspector picks actors off the picture and marks the selected
 * one; this panel only says which that is.
 */
export declare class ActorsPanel extends Panel {
    /** As for the pools: a whole-heap read, and every block in it walked. */
    protected static readonly ACTORS_POLL_HZ = 4;
    protected status: ActorsStatus;
    protected read?: VesActorsRead;
    protected symbols?: SymbolIndex;
    protected error?: string;
    protected reading: boolean;
    protected componentSort: TableSort<ComponentSortColumn>;
    /** The selected actor, by the address of the object rather than its row. */
    protected selected?: number;
    /** Resolved `char*` names, which do not change once an actor has one. */
    protected readonly names: Map<number, string>;
    /** Narrows the tree by spec, class or name; not remembered, like the other panels' filters. */
    protected filter: string;
    protected fieldFilter: string;
    protected showHidden: boolean;
    protected tab: DetailTab;
    /** Parents folded shut, by row key: they start open. */
    protected readonly closed: Set<string>;
    /** Folds of like siblings opened up, by row key: they start shut. */
    protected readonly opened: Set<string>;
    /**
     * Field groups the other way from how they start — the actor's own class
     * open, everything it inherits shut — by class name, so a group stays the
     * way it was left from one actor to the next.
     */
    protected readonly flippedGroups: Set<string>;
    /** The selected actor's fields as last read, and when each last changed; see {@link noteChanges}. */
    protected trackedActor?: number;
    protected readonly lastTexts: Map<string, string>;
    protected readonly changedAt: Map<string, number>;
    /** Set by a reveal, so the row is scrolled to once it is drawn. */
    protected scrollPending: boolean;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected onUpdateRequest(msg: Message): void;
    protected refresh(): Promise<void>;
    /** Mark the selected actor's fields that changed since the last read. */
    protected noteChanges(): void;
    /**
     * Fetch a few of the names not yet known.
     *
     * Bounded per refresh because each is a round trip of its own; over a
     * couple of ticks every actor on screen has one, and the cache means it is
     * never asked for twice.
     */
    protected resolveNames(sim: Sim): Promise<void>;
    protected reset(status: ActorsStatus): void;
    protected actors(): VesActor[];
    protected actorAt(address: number): VesActor | undefined;
    protected selectedActor(): VesActor | undefined;
    protected select(objectAddress: number): void;
    /** Select the actor the screen inspector picked, unfolding the tree down to it. */
    reveal(target: ScreenInspectorTarget): void;
    /**
     * Have the screen mark the selected actor's sprites.
     *
     * Always handed over: whether they are drawn is the screen inspector's
     * switch, beside its picker. Only sprites have a rectangle — a component
     * that draws nothing is not anywhere on screen, and an actor made only of
     * those is marked by nothing rather than by a box at the origin.
     */
    protected applyHighlights(): void;
    /** The name the game gave this actor, if it gave it one. */
    protected ownNameOf(actor: VesActor): string;
    protected labelOf(actor: VesActor): string;
    protected parentKey(parent: number): string;
    protected groupKey(actor: VesActor): string;
    /** The rows the tree shows now, folds and filter applied. */
    protected treeRows(): TreeRow[];
    protected toggle(row: TreeRow): void;
    protected render(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    protected renderTree(selected: VesActor): React.ReactNode;
    /** Everything the selected actor is and holds. */
    protected renderInspector(actor: VesActor): React.ReactNode;
    protected tabButton(tab: DetailTab, label: string, count: number): React.ReactNode;
    /** The few things about an actor worth seeing before its fields: label, value and why. */
    protected facts(actor: VesActor): [string, React.ReactNode, string?][];
    /**
     * The actor's fields, under the class of the chain that declares each.
     *
     * The class macro lays the inherited fields out first and by name, so a
     * field belongs to the furthest ancestor whose own layout has a member of
     * its name; the build's layouts say which that is, and a class it does not
     * describe simply has nothing listed under it.
     */
    protected fieldGroups(actor: VesActor): FieldGroup[];
    protected renderFields(groups: FieldGroup[]): React.ReactNode;
    /**
     * What a field holds, with a pointer into the pools said by what it points
     * at — an actor to go to, or the class of whatever else is there.
     */
    protected fieldValue(field: VesFieldValue, name: string): React.ReactNode;
    /**
     * What the actor is made of.
     *
     * Sprites carry the rectangle they were last drawn at and the world or
     * objects they are drawn with, which is what the picture is marked with;
     * anything else is listed by class alone, because that is all a component
     * that draws nothing has to say from here.
     */
    protected renderComponents(actor: VesActor): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-actors-panel.d.ts.map