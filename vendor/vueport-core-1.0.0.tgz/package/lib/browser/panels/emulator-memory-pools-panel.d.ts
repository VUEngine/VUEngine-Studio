import * as React from 'react';
import { VesMemoryPool, VesMemoryPoolLayout, VesMemoryPoolUsage } from '../core/emulator-memory-pool';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
/** Why the panel has nothing to show, when it has nothing to show. */
declare enum PoolStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    NO_SYMBOLS = "noSymbols",
    NOT_VUENGINE = "notVuengine",
    NOT_INITIALIZED = "notInitialized",
    WRONG_BUILD = "wrongBuild"
}
type OccupantSortColumn = 'name' | 'count' | 'block' | 'bytes';
/**
 * What the engine's heap is holding right now.
 *
 * VUEngine allocates every dynamic object out of `MemoryPool`: a fixed set of
 * pools of equally sized blocks, sized per project at compile time and never
 * grown at runtime, so running out is a crash rather than a slowdown. The
 * engine can print its own usage to the screen (`MemoryPool::printDetailedUsage`),
 * but only as totals, and only where it covers the game.
 *
 * This shows the same totals without disturbing the display, and adds the part
 * the engine cannot report: which classes the used blocks actually hold, read
 * back from each object's vTable pointer. A pool creeping towards full is a
 * question of what is filling it, and that is the answer.
 *
 * Both halves come out of a single read of the pool struct — see
 * `parseMemoryPoolLayout`, which also explains how the per-project pool table
 * is recovered rather than assumed.
 */
export declare class MemoryPoolsPanel extends Panel {
    /**
     * Slower than the default: a read here is the whole heap struct, tens of
     * kilobytes, and every block in it is then walked. Four times a second
     * still tracks allocation churn well enough to watch a pool fill.
     */
    protected static readonly POOLS_POLL_HZ = 4;
    protected status: PoolStatus;
    /**
     * Not `layout`: that name belongs to Lumino's `Widget`, and shadowing its
     * accessor with a field leaves the dock reading `undefined` when it goes
     * to arrange this panel.
     */
    protected poolLayout?: VesMemoryPoolLayout;
    protected usage?: VesMemoryPoolUsage[];
    /**
     * Set when the symbols turned out to belong to a different build, which
     * leaves the pool figures usable but the occupant names not.
     */
    protected staleSymbols: boolean;
    protected error?: string;
    /** Guards against a slow read being overlapped by the next tick. */
    protected reading: boolean;
    protected occupantSort: TableSort<OccupantSortColumn>;
    /**
     * Narrows the occupants by class name. Not remembered across sessions,
     * unlike the panels' display controls: a filter is a question about the
     * game in front of you, and coming back to a list that is silently hiding
     * most of itself is the wrong way to be reminded you once asked it.
     */
    protected occupantFilter: string;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected reset(status: PoolStatus): void;
    protected render(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    protected renderSummary(totalBytes: number, usedBytes: number, usedBlocks: number, totalBlocks: number): React.ReactNode;
    protected renderPools(pools: VesMemoryPool[], usage: VesMemoryPoolUsage[]): React.ReactNode;
    /**
     * What is actually in the blocks, across every pool.
     *
     * A class allocates the same size every time, so it normally sits in one
     * pool; a class listed against several block sizes means the pool it
     * belongs in was full when some of them were allocated, which is the same
     * thing the overflow column counts.
     */
    protected renderClasses(pools: VesMemoryPool[], usage: VesMemoryPoolUsage[], usedBlocks: number): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-memory-pools-panel.d.ts.map