import * as React from 'react';
import { VesMemoryPool, VesMemoryPoolLayout, VesMemoryPoolUsage } from '../core/emulator-memory-pool';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
declare enum PoolStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    NO_SYMBOLS = "noSymbols",
    NOT_VUENGINE = "notVuengine",
    NOT_INITIALIZED = "notInitialized",
    WRONG_BUILD = "wrongBuild"
}
type OccupantKind = 'actor' | 'component' | 'graphics' | 'other' | 'raw';
type OccupantSortColumn = 'name' | 'count' | 'block' | 'bytes';
/**
 * VUEngine allocates every dynamic object out of MemoryPool: pools of equally sized blocks, sized per project at
 * compile time and never grown, so running out is a crash. The engine can only print totals on screen
 * (MemoryPool::printDetailedUsage); this also shows which classes the used blocks hold, read from each object's
 * vTable pointer. Both come out of a single read of the pool struct, see parseMemoryPoolLayout.
 */
export declare class MemoryPoolsPanel extends Panel {
    protected static readonly POOLS_POLL_HZ = 4;
    protected status: PoolStatus;
    protected poolLayout?: VesMemoryPoolLayout;
    protected usage?: VesMemoryPoolUsage[];
    protected kinds: Map<string, OccupantKind>;
    protected staleSymbols: boolean;
    protected error?: string;
    protected reading: boolean;
    protected occupantSort: TableSort<OccupantSortColumn>;
    protected occupantFilter: string;
    protected selectedPool?: number;
    protected selectedClass?: string;
    protected readonly hiddenKinds: Set<OccupantKind>;
    protected history: number[];
    protected peaks: number[];
    protected peakShare: number;
    protected trackedLayout?: string;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected track(layout: VesMemoryPoolLayout, usage: VesMemoryPoolUsage[]): void;
    protected resetPeaks(): void;
    protected reset(status: PoolStatus): void;
    protected render(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    protected renderSummary(totalBytes: number, usedBytes: number, usedBlocks: number, totalBlocks: number): React.ReactNode;
    protected renderLegend(): React.ReactNode;
    protected renderPools(pools: VesMemoryPool[], usage: VesMemoryPoolUsage[], selected: VesMemoryPool | undefined): React.ReactNode;
    protected renderPoolBar(pool: VesMemoryPool, usage: VesMemoryPoolUsage, peak: number): React.ReactNode;
    protected renderClasses(pools: VesMemoryPool[], usage: VesMemoryPoolUsage[], usedBytes: number, selected: VesMemoryPool | undefined): React.ReactNode;
    protected kindOf(name: string): OccupantKind;
}
export {};
//# sourceMappingURL=emulator-memory-pools-panel.d.ts.map