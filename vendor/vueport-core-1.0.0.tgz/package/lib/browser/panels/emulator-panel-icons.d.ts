import { VirtualElement } from '@lumino/virtualdom';
import { IconProps } from '@phosphor-icons/react';
import * as React from 'react';
import { EmulatorPanelType } from './emulator-panel';
export declare enum EmulatorPanelCategory {
    VIP = "vip",
    CPU = "cpu",
    MEMORY = "memory",
    AUDIO = "audio",
    HARDWARE = "hardware",
    VUENGINE = "vuengine"
}
export declare const EMULATOR_PANEL_CATEGORIES: {
    id: EmulatorPanelCategory;
    label(): string;
}[];
export declare function emulatorPanelCategory(type: EmulatorPanelType): typeof EMULATOR_PANEL_CATEGORIES[number];
export declare function emulatorPanelIcon(type: EmulatorPanelType): React.ComponentType<IconProps>;
export declare function emulatorPanelTitleIcon(type: EmulatorPanelType): VirtualElement.IRenderer;
//# sourceMappingURL=emulator-panel-icons.d.ts.map