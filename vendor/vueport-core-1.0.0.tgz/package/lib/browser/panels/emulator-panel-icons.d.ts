import { VirtualElement } from '@lumino/virtualdom';
import { IconProps } from '@phosphor-icons/react';
import * as React from 'react';
import { EmulatorPanelType } from './emulator-panel';
/**
 * The families a panel falls into, for the Add Panel picker's headings.
 *
 * Every panel now draws its own icon (see {@link EMULATOR_PANEL_ICON}) — this
 * is only what groups the picker into VIDEO (VIP), CPU, and the rest, so
 * twenty names read as a handful of short lists rather than one long
 * alphabetical column.
 */
export declare enum EmulatorPanelCategory {
    VIP = "vip",
    CPU = "cpu",
    MEMORY = "memory",
    AUDIO = "audio",
    HARDWARE = "hardware",
    VUENGINE = "vuengine"
}
/** A category's heading, in the order the picker groups panels by. */
export declare const EMULATOR_PANEL_CATEGORIES: {
    id: EmulatorPanelCategory;
    label(): string;
}[];
/** A panel's family and heading. */
export declare function emulatorPanelCategory(type: EmulatorPanelType): typeof EMULATOR_PANEL_CATEGORIES[number];
/** A panel's own icon — what its tab carries, and what the picker shows beside its name. */
export declare function emulatorPanelIcon(type: EmulatorPanelType): React.ComponentType<IconProps>;
/**
 * A panel's icon as a Lumino title renderer, for its own tab.
 *
 * `Title.icon` wants a `VirtualElement.IRenderer` — Lumino's own render
 * contract, not React's — so this bridges the one real icon set the rest of
 * the application draws from into it, the same way `VueportReactWidget`
 * bridges a panel's own content: a React root mounted into whatever DOM node
 * Lumino hands over. `render` can be called again with a *different* host if
 * Lumino ever recreates the tab's icon element (its vdom diffing does not
 * promise otherwise), so the mounted root follows the host rather than being
 * created once and assumed to stay valid.
 */
export declare function emulatorPanelTitleIcon(type: EmulatorPanelType): VirtualElement.IRenderer;
//# sourceMappingURL=emulator-panel-icons.d.ts.map