import * as React from 'react';
export declare function field(label: string, value: React.ReactNode, hint?: string): React.JSX.Element;
export declare function control(label: string, input: React.ReactNode, hint?: string, wide?: boolean): React.JSX.Element;
export declare function stacked(label: string, input: React.ReactNode, hint?: string, span?: number): React.JSX.Element;
export declare function numberInput(value: number, min: number, max: number, commit: (value: number) => void, step?: number): React.JSX.Element;
//# sourceMappingURL=emulator-vip-detail.d.ts.map