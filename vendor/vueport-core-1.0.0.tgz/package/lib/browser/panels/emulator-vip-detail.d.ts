import * as React from 'react';
/**
 * The rows of a detail view: the label/value pairs the Worlds and Objects
 * panels put under their tables, and the number input they edit them with.
 *
 * Kept out of the panels themselves because both build the same kind of view
 * over different structures, and a field that reads one way in one of them and
 * another way in the other would be worse than either.
 */
/** A read-only label/value pair. */
export declare function field(label: string, value: React.ReactNode, hint?: string): React.JSX.Element;
/**
 * The same pair, with an editable control in place of the value.
 *
 * `wide` gives the row the whole width of its group rather than one column of
 * it, for a control that needs the room — a name, rather than a number.
 */
export declare function control(label: string, input: React.ReactNode, hint?: string, wide?: boolean): React.JSX.Element;
/**
 * A field whose name sits above its control rather than beside it.
 *
 * What a narrow column asks for: a name beside a control costs the width of
 * the longest name in the group, and in a sidebar three fields wide there is
 * none to spare. `span` is how many of the grid's columns the field takes,
 * for a control that needs more than its share — a dropdown, or an address.
 */
export declare function stacked(label: string, input: React.ReactNode, hint?: string, span?: number): React.JSX.Element;
/**
 * A number input that writes every keystroke straight through.
 *
 * Committing per keystroke rather than on blur is what makes editing work at
 * all here: the panels poll, so anything not written back is overwritten by
 * the next refresh a fraction of a second later. A value that does not parse
 * — the empty field left behind by selecting all and typing, say — is
 * dropped rather than written as a zero.
 */
export declare function numberInput(value: number, min: number, max: number, commit: (value: number) => void, step?: number): React.JSX.Element;
//# sourceMappingURL=emulator-vip-detail.d.ts.map