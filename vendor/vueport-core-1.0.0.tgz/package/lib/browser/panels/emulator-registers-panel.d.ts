import * as React from 'react';
import { Registers } from '../../common/vb-protocol';
import { DebugSource, Panel } from './emulator-panel';
export declare class RegistersPanel extends Panel {
    protected registers?: Registers;
    protected vipRegisters?: DataView;
    protected vcuRegisters?: DataView;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderVip(block: DataView): React.ReactNode;
    protected renderVcu(block: DataView): React.ReactNode;
    protected renderCpu(registers: Registers): React.ReactNode;
}
//# sourceMappingURL=emulator-registers-panel.d.ts.map