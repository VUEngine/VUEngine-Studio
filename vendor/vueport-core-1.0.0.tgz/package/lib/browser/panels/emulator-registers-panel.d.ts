import * as React from 'react';
import { Registers } from '../../common/vb-protocol';
import { DebugSource, Panel } from './emulator-panel';
/**
 * The VIP's control registers, and the V810's below them.
 *
 * The VIP block is read through the CPU's view of memory, so those are the
 * values the running program would see if it read them itself. The CPU's own
 * registers come from the core rather than from memory, since they live
 * nowhere in the address space.
 *
 * r0 is hardwired to zero and r31 is the link register; the rest are general
 * purpose. The system registers carry the exception and interrupt state, which
 * is usually what you want when a game has stopped somewhere unexpected.
 */
export declare class RegistersPanel extends Panel {
    protected registers?: Registers;
    protected vipRegisters?: DataView;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderVip(block: DataView): React.ReactNode;
    protected renderCpu(registers: Registers): React.ReactNode;
}
//# sourceMappingURL=emulator-registers-panel.d.ts.map