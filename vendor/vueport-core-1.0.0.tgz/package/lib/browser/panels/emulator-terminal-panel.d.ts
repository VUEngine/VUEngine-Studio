import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { LogLevel } from '../../common/emulator-log';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
interface TerminalLine {
    text: string;
    at: number;
    level: LogLevel;
}
/**
 * Output the running program wrote to the terminal port. VUEngine's Terminal::print stores a string to a fixed
 * address byte by byte, followed by a newline. Capturing it makes the core call back on every CPU write, so capture
 * is on only while this panel is open, and this is the one panel that is pushed to rather than polled. Shipping
 * builds print nothing, as Terminal::print is compiled out without debugging. Search and level switches compose:
 * the search counts against what the switches left
 */
export declare class TerminalPanel extends Panel {
    protected lines: TerminalLine[];
    protected partial: string;
    protected partialAt: number;
    protected follow: boolean;
    protected pendingScroll: boolean;
    /**
     * Positions the panel scrolled to that have not come back as scroll events. An event says where the view is, not
     * who moved it, and arrives late, so the panel's own scroll to the end can read as the reader scrolling up once
     * output moved the end. An event at one of these positions is the panel's own; several assignments in one frame
     * come back as one event with the last, so a match drops everything up to it
     */
    protected readonly ownScrolls: number[];
    protected endBefore?: number;
    protected search: string;
    protected onlyMatches: boolean;
    protected levels: Record<LogLevel, boolean>;
    protected watched?: Sim;
    protected readonly watching: DisposableCollection;
    protected capturing: boolean;
    protected scroller: HTMLDivElement | undefined;
    protected readonly takeScroller: (element: HTMLDivElement | null) => void;
    constructor(source: DebugSource, instanceId: string);
    protected onAfterAttach(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected pollHz(): number;
    protected refresh(): void;
    protected followMachine(): void;
    protected stopCapture(sim: Sim): void;
    protected append(text: string): void;
    protected clear(): void;
    protected updateAndFollow(): void;
    protected afterRender(): void;
    /**
     * Scrolling turns following on and off, so a reader who scrolled up is not pulled away by the next line; reaching
     * the end turns it on again. While following, the end means the end as it is now, and anything else stops
     * following; content shrinking (a Clear, a level switched off) lands the view at the end, which rightly reads as
     * still there. While not following, the end means where it was when the scroll was made (endBefore), as each burst
     * of output moves the current end further down than the event reporting the scroll
     */
    protected onScroll(): void;
    protected hasOutput(): boolean;
    protected matches(text: string): boolean;
    protected render(): React.ReactNode;
    protected renderToolbar(shown: number, matched: number, searching: boolean, counts: Record<LogLevel, number>): React.ReactNode;
    protected renderLevels(counts: Record<LogLevel, number>): React.ReactNode;
    protected levelLabels(): Record<LogLevel, string>;
    protected renderLine(line: TerminalLine, key: React.Key, badges: Record<LogLevel, string> | undefined, partial: boolean): React.ReactNode;
    protected renderMatches(text: string): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-terminal-panel.d.ts.map