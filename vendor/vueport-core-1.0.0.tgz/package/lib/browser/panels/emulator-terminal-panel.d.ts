import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { LogLevel } from '../../common/emulator-log';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
/** One finished line of output, and what it announced itself as. */
interface TerminalLine {
    /** What the line says, with any `Warning:` prefix parted from it. */
    text: string;
    /**
     * When the line was finished, rather than when its first character
     * arrived: a line the program built up a character at a time — which is
     * how `Terminal::print` sends one — has no single moment before that.
     */
    at: number;
    level: LogLevel;
}
/**
 * Output the running program wrote to the terminal port.
 *
 * VUEngine's `Terminal::print` stores a string to a fixed address one byte at a
 * time and follows it with a newline. Capturing that means the core calls back
 * on every CPU write, so capture is switched on only while this panel is open
 * and torn down again when it closes — which is also why this is the one panel
 * that is pushed to rather than polled.
 *
 * Nothing appears for a shipping build: `Terminal::print` is compiled out
 * unless the ROM was built with debugging enabled.
 *
 * What a build does print is usually a lot of it, so the panel is as much a
 * way of not reading output as of reading it: the search narrows it by what a
 * line says, the level switches by what it announced itself as, and the two
 * compose — the search counts against what the switches left.
 */
export declare class TerminalPanel extends Panel {
    protected lines: TerminalLine[];
    /** Text since the last newline, which is not a line yet. */
    protected partial: string;
    /**
     * When the partial line's first character arrived.
     *
     * A finished line is stamped when it finished, which an unfinished one by
     * definition cannot be. Taking the start instead is a sub-millisecond
     * difference in practice — `Terminal::print` writes a whole string in one
     * burst — and it keeps the time column filled rather than ragged.
     */
    protected partialAt: number;
    protected follow: boolean;
    /**
     * Set when output arrived that the view has not been scrolled down to yet.
     *
     * Following used to be done on every render, which is why it could not be
     * scrolled away from: this panel re-renders once a second whether or not
     * anything was written, so a reader who scrolled up was pulled back down
     * within the second. Now a render only follows output that is actually
     * new, and {@link onScroll} hands the choice back to whoever is scrolling.
     */
    protected pendingScroll: boolean;
    /**
     * Positions the panel put the view at that have not come back as scroll
     * events yet.
     *
     * A scroll event says where the view is, not who moved it, and it is
     * dispatched after the fact — so the panel's own scroll to the end can
     * arrive once output has moved the end further down, and read as somebody
     * having scrolled up. What the panel scrolled to, it knows exactly; an
     * event reporting one of those positions is its own and says nothing.
     * Several assignments in one frame come back as a single event with the
     * last of them, which is why a match drops everything up to it.
     */
    protected readonly ownScrolls: number[];
    /**
     * Where the end of the output was before whatever has arrived since the
     * last scroll event was drawn.
     *
     * Reaching the end is how following is asked for again, and the end has
     * to mean where it was when the reader aimed at it: by the time the event
     * arrives, another burst may have pushed it down a screenful. Undefined
     * while nothing has arrived since.
     */
    protected endBefore?: number;
    /** What is being searched for. Not remembered: a search is about now. */
    protected search: string;
    /** Whether the search hides the rest rather than only dimming it. */
    protected onlyMatches: boolean;
    /** Which levels are shown, each remembered on its own. */
    protected levels: Record<LogLevel, boolean>;
    /**
     * The machine whose output is on screen.
     *
     * Held so that a different one can be told from the same one carrying on:
     * what was captured belonged to the machine that has gone, and none of it
     * describes the one that replaced it. A reset and a different cartridge
     * keep the same simulation and are caught by `onRestart` instead.
     */
    protected watched?: Sim;
    /** What was set up to watch {@link watched}, given back with it. */
    protected readonly watching: DisposableCollection;
    protected capturing: boolean;
    protected scroller: HTMLDivElement | undefined;
    /**
     * Held rather than written inline in the render, because React takes a
     * ref back and hands it out again whenever the function it was given
     * changes — which for one written inline is every render, and the panel
     * would be without its view at exactly the moment it wants to scroll it.
     */
    protected readonly takeScroller: (element: HTMLDivElement | null) => void;
    constructor(source: DebugSource, instanceId: string);
    protected onAfterAttach(msg: Message): void;
    /**
     * Capture costs the core a callback on every CPU write, so it is given
     * back the moment this panel is closed.
     *
     * The lines stay, and so does the machine they belong to: a panel dragged
     * from one side of the dock to the other is detached and attached again,
     * and that is not a reason to lose what it was showing.
     */
    protected onBeforeDetach(msg: Message): void;
    /**
     * Nothing to poll: output arrives as an event. The base class still drives
     * a timer, so it is slowed right down rather than left running at ten hertz.
     */
    protected pollHz(): number;
    protected refresh(): void;
    /**
     * Point the capture at whatever machine there is now, and empty the panel
     * for a machine that is not the one the output came from.
     *
     * Both halves used to be missing. Capture was set up once and never
     * moved, so a second ROM opened with the panel already there went on
     * being listened to through the simulation the first one had — which by
     * then was writing nothing — and the first game's output stayed on
     * screen underneath as though it were the new game's.
     */
    protected followMachine(): void;
    protected stopCapture(sim: Sim): void;
    protected append(text: string): void;
    protected clear(): void;
    /** Redraw, and put the view at the end of the output while doing it. */
    protected updateAndFollow(): void;
    /** Take the view to the end of the output, if that is what was asked for. */
    protected afterRender(): void;
    /**
     * Scrolling is what turns following on and off.
     *
     * The button in the toolbar says whether the view is at the end of the
     * output, and scrolling away from the end is the plainest way of saying
     * you would rather it were not — a reader who has scrolled up to read
     * something should not have to find a control before the next line of
     * output takes it away again. Reaching the end says the opposite.
     *
     * The two directions are not asked the same question, and deliberately:
     *
     * - While following, the end means the end as it is now. Anything else is
     *   somebody having moved the view away, and following stops. Content
     *   *shrinking* — a Clear, a level switched off — takes the view with it
     *   and lands it at the end, which is the one case that reads as "still
     *   there" and is right to.
     * - While not following, the end means where the end was when the scroll
     *   was made, which is what {@link endBefore} keeps. Asking for the end
     *   as it is now would make it unreachable by hand: every burst of output
     *   moves it further down than the event that reports the scroll.
     */
    protected onScroll(): void;
    /**
     * Whether anything has been captured at all.
     *
     * Asked of the trimmed partial rather than the raw one, so that the
     * padding around a line that has not finished arriving does not count as
     * output — otherwise the panel would drop its "waiting for output" the
     * moment a program wrote a space.
     */
    protected hasOutput(): boolean;
    /** Whether a line answers the search, which an empty search does not ask. */
    protected matches(text: string): boolean;
    protected render(): React.ReactNode;
    protected renderToolbar(shown: number, matched: number, searching: boolean, counts: Record<LogLevel, number>): React.ReactNode;
    /**
     * A switch per level, with how many lines it holds.
     *
     * Only the levels that have something to say get one, so a build that
     * announces nothing — and most output announces nothing, which is why a
     * line without a prefix counts as information — is not given two empty
     * switches to read past. A level switched off keeps its
     * switch whether or not it has lines, since a control that hides output
     * and then hides itself leaves nothing to explain where the output went.
     */
    protected renderLevels(counts: Record<LogLevel, number>): React.ReactNode;
    /** What each level is called, on its switch and on the badges. */
    protected levelLabels(): Record<LogLevel, string>;
    /**
     * One line: when it was written, what it announced itself as, and what it
     * says. `badges` is what each level is called, or undefined for output
     * that never announced anything and so wants no column for it.
     */
    protected renderLine(line: TerminalLine, key: React.Key, badges: Record<LogLevel, string> | undefined, partial: boolean): React.ReactNode;
    /** The line with what was searched for picked out of it. */
    protected renderMatches(text: string): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-terminal-panel.d.ts.map