import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
/** VCU registers, cartridge declaration, memory map, and live color RAM. */
export declare class VcuPanel extends Panel {
    protected registers?: DataView;
    protected cram?: DataView;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderOverview(present: boolean): React.ReactNode;
    protected renderRegisters(): React.ReactNode;
    /**
     * The four colors CBKPAL is pointing at.
     *
     * The register names a palette and stops there, which leaves the one
     * question anyone reading it actually has — what color is the backdrop —
     * to be answered by counting into the CRAM grid below. The colors are
     * already fetched; showing them costs nothing.
     */
    protected renderBackdropSwatches(value: number): React.ReactNode;
    /**
     * The rest of the block, as it stands.
     *
     * VBC 1.1 reserves 256 bytes here and documents the first sixteen. What
     * follows is shown rather than hidden: an inspector's job is to report what
     * the hardware holds, and a reserved word that turns out not to be reserved
     * is exactly the kind of thing someone opens this panel to notice. Rows
     * that are entirely zero are folded away, so a block doing nothing takes up
     * no room and one that is takes up as much as it needs.
     */
    protected renderReserved(): React.ReactNode;
    protected renderCram(): React.ReactNode;
}
//# sourceMappingURL=emulator-vcu-panel.d.ts.map