import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VcuRegister } from './emulator-vcu-memory';
interface VcuRegisterDescription {
    name: string;
    offset: VcuRegister;
    label: string;
}
export declare const VCU_REGISTER_GROUPS: {
    group: string;
    registers: VcuRegisterDescription[];
}[];
export declare function registerHint(name: string, label: string, value: number): string;
export declare class VcuPanel extends Panel {
    protected registers?: DataView;
    protected cram?: DataView;
    protected revealedPalette?: number;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderOverview(present: boolean): React.ReactNode;
    protected renderRegisters(): React.ReactNode;
    protected renderBackdropSwatches(value: number): React.ReactNode;
    protected renderReserved(): React.ReactNode;
    reveal(target: ScreenInspectorTarget): void;
    protected renderCram(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vcu-panel.d.ts.map