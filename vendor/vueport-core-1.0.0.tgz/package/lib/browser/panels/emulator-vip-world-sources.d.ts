import { Sim } from '../core/vb-core';
import { VipWorld } from './emulator-vip-memory';
/**
 * How far the worlds around the one being looked at are faded in a Context
 * preview, and they lose the hardware's red with it.
 *
 * The same treatment, and the same factor, as the characters a filter leaves
 * out in the Characters panel: faint enough that the subject reads as the
 * subject, strong enough that what surrounds it is still legible. Gray as
 * well as faint because fading alone would put a neighbouring world and a
 * dark part of the subject on one scale.
 */
export declare const VIP_CONTEXT_FACTOR = 0.18;
/**
 * The BGMap segments and param tables a set of worlds maps from.
 *
 * Shared by the Worlds and Objects panels, whose Context previews both draw
 * the frame's worlds and so both have to read this much of VRAM. OBJECT
 * worlds are passed over: they draw from OAM, which each panel reads itself.
 */
export declare class VipWorldSources {
    /** Indexed by absolute BGMap segment; only the ones the worlds span are read. */
    bgMapSegments: (Uint8Array | undefined)[];
    /** The H-bias or Affine tables of the worlds, by world index. */
    paramTables: (Uint8Array | undefined)[];
    clear(): void;
    /**
     * Read what the given worlds map from, and answer whether any of it
     * differs from the last read.
     */
    read(sim: Sim, sources: readonly VipWorld[]): Promise<boolean>;
    /** One world's param table, as a view, or undefined when none was read. */
    params(index: number): DataView | undefined;
    /** Whether two reads of the param tables agree, absent tables included. */
    protected static sameParamTables(a: ReadonlyArray<Uint8Array | undefined>, b: ReadonlyArray<Uint8Array | undefined>): boolean;
    /**
     * The BGMap segments a world spans, in the order it lays them out: scx
     * across then scy down, from its base segment.
     *
     * Segments past the last real one are dropped rather than read — 14 and 15
     * are where world attribute and object memory live, not map data.
     */
    protected static worldSegments(world: VipWorld): number[];
}
//# sourceMappingURL=emulator-vip-world-sources.d.ts.map