import { Sim } from '../core/vb-core';
import { VipWorld } from './emulator-vip-memory';
export declare const VIP_CONTEXT_FACTOR = 0.18;
export declare class VipWorldSources {
    bgMapSegments: (Uint8Array | undefined)[];
    paramTables: (Uint8Array | undefined)[];
    clear(): void;
    read(sim: Sim, sources: readonly VipWorld[]): Promise<boolean>;
    params(index: number): DataView | undefined;
    protected static sameParamTables(a: ReadonlyArray<Uint8Array | undefined>, b: ReadonlyArray<Uint8Array | undefined>): boolean;
    protected static worldSegments(world: VipWorld): number[];
}
//# sourceMappingURL=emulator-vip-world-sources.d.ts.map