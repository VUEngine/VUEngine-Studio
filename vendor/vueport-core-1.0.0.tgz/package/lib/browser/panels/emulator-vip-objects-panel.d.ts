import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { VipCharacters, VipEye, VipIntensityWatcher, VipObject, VipWorld } from './emulator-vip-memory';
import { VcuColors } from './emulator-vcu-colors';
import { VipWorldSources } from './emulator-vip-world-sources';
import { VipObjectCluster } from './emulator-vip-object-clusters';
import { VbcState, VcuColorAttr, VcuPixelAttr } from './emulator-vcu-memory';
import { Sim } from '../core/vb-core';
/**
 * What the preview draws: the selected object on its own, or the frame it is
 * part of — the Worlds panel's two modes, asked of an object.
 *
 * Context draws every world the VIP draws, in its order, with the objects in
 * the red the hardware emits and every other world faded to gray, so that
 * what is an object and what is background can be told apart at a glance.
 */
type ObjectPreviewMode = 'solo' | 'context';
/** One line of the Figures list, with the picture under it. */
interface FigureEntry {
    cluster: VipObjectCluster;
    /** The object group the figure's objects are in, which is one per figure. */
    group?: number;
    image: ImageData;
}
/**
 * What VB Color adds to the selected object: its byte of OBJ Color Attribute
 * RAM and its halfword of OBJ Pixel Color Attribute RAM, and the colors they
 * come to.
 *
 * Only the selected object's, rather than both blocks: nothing else in the
 * panel shows them, and three bytes a poll are less than three kilobytes.
 */
interface ObjectColor {
    /** The object these were read for, so a read that raced a new selection is not shown for it. */
    index: number;
    /** As read, so that an edit can write back the bits it does not name. */
    colorByte: number;
    pixelHalfword: number;
    /**
     * The Character's own OBJ entries, read only while they are the ones in
     * effect: CHRSEL set and CXCTRL.CCEN on.
     */
    character?: {
        color: VcuColorAttr;
        pixel: VcuPixelAttr;
    };
    /** The CRAM palette the object draws with, and its four RGB888 entries. */
    palette: number;
    colors: number[];
}
/**
 * The VIP's object attribute memory: up to 1024 sprites.
 *
 * Three columns, the shape the Worlds and BGMaps panels have: the objects as
 * tiles, the fields of the one picked, and a preview of where on screen it
 * lands — alone, or in the frame the VIP draws around it. The tiles keep to
 * the objects actually drawn by default, since most of OAM in a typical game
 * is unused slots, and can be kept to some of the four object groups.
 * Rendering the previews is what makes this panel read character memory too,
 * and in Context world and BGMap memory as well; the list on its own needs
 * only OAM.
 */
export declare class ObjectsPanel extends Panel {
    /** Where Export PNG hands its file; no button without it. */
    protected readonly exportFile?: VipExportFile | undefined;
    protected objectBytes?: Uint8Array;
    /**
     * OAM as it was before the last change to it, which is what the figures
     * are told the objects' motion by; see vipObjectClusters.
     */
    protected previousObjectBytes?: Uint8Array;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    /**
     * World attribute memory, read only while the preview is in Context — or
     * in color under WCEN, for the palette offset an OBJ world gives its
     * objects.
     */
    protected worldBytes?: Uint8Array;
    /** The BGMap segments and param tables of the worlds Context draws. */
    protected readonly sources: VipWorldSources;
    /**
     * What a VB Color game has switched on, and nothing otherwise — the one
     * test every color field and the extended characters go by; see
     * readVbcState.
     */
    protected vbc?: VbcState;
    /** The selected object's color attributes, read only while `vbc` is there. */
    protected objectColor?: ObjectColor;
    /** The VCU's color tables the previews draw with, read only while they are in color. */
    protected colors?: VcuColors;
    /** Reused from pixel to pixel while drawing in color, so that drawing does not allocate per pixel. */
    protected readonly placement: import("./emulator-vcu-colors").VcuPlacement;
    protected readonly sample: import("./emulator-vip-memory").VipWorldSample;
    protected error?: string;
    /** The object the fields and the preview describe. There is always one. */
    protected selected: number;
    /**
     * Whether the list keeps to the objects the VIP actually draws — the ones
     * switched on for an eye. On, because most of OAM in a typical game is
     * slots nothing has been put in.
     */
    protected showOnlyDrawn: boolean;
    /**
     * Whether the list keeps to the figure the selected object is part of,
     * and Context grays every other object.
     */
    protected onlyFigure: boolean;
    /**
     * The object groups the panel keeps to, a bit per SPT register: the list
     * leaves the others out, and Context grays their objects like the worlds
     * around them. All four by default. The objects past the last group are
     * in none of them, so no group can leave them out — the VIP never draws
     * them, which is Show Only Drawn's question rather than this one's.
     */
    protected groupFilter: number;
    protected eye: VipEye;
    protected previewMode: ObjectPreviewMode;
    protected zoom: number;
    protected showExtents: boolean;
    /**
     * Whether the previews are shaded with an even ramp instead of the object
     * palette registers. Off: they resolve the brightness registers the way
     * the core does, so the real palettes look like the picture on screen.
     */
    protected showGenericPalette: boolean;
    /**
     * Whether the previews are drawn in the colors a VB Color game shows
     * rather than the VIP's red — while the game has the VCU unlocked, which
     * is the only time the switch is there. On, since that is what is on
     * screen.
     */
    protected vbColorPreview: boolean;
    protected image?: ImageData;
    /** The figures the drawn objects make up, as last worked out; see vipObjectClusters. */
    protected clusters: VipObjectCluster[];
    /** What the Figures list shows, rebuilt with the clusters. */
    protected figures: FigureEntry[];
    /** The figure the pointer is on in the Figures list, by its first object. */
    protected hoveredFigure?: number;
    /**
     * Whether the selected object's figure has been let go of, by clicking
     * it again in the Figures list: the object stays selected, but nothing
     * treats it as part of a figure until another object is picked.
     */
    protected figureReleased: boolean;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    /** The SPT registers as last drawn: Context's groups follow them. */
    protected groupEnds?: string;
    constructor(source: DebugSource, instanceId: string, 
    /** Where Export PNG hands its file; no button without it. */
    exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /**
     * Read character memory: the VIP's four segments, and with CHREXT the
     * VCU's four more, which objects naming characters 2048-4095 draw from.
     * The extension's segments are let go of when CHREXT goes off, since how
     * many segments there are is what VipCharacters reads the mask from.
     */
    protected readCharacters(sim: Sim): Promise<void>;
    /**
     * Read the worlds Context draws around the objects, and the maps and
     * param tables they draw from. Solo draws the object alone, so there
     * this lets go of all of it rather than reading VRAM nothing looks at —
     * save world attribute memory in color under WCEN, where which OBJ world
     * draws an object's group decides the palette offset it is drawn with.
     */
    protected readWorlds(sim: Sim): Promise<void>;
    /** Whether the previews are drawn in VB Color: switched on, and a game that has it on. */
    protected inColor(): boolean;
    /**
     * Read the VCU tables drawing the previews in color takes, and let go of
     * them otherwise. Called after readWorlds, since in Context the BGMap
     * segments it read are the ones whose cells are colored — those, and the
     * segment an overplane world's OVR cell is in.
     */
    protected readColors(sim: Sim): Promise<void>;
    /**
     * The selected object's VB Color attributes, or nothing while the game
     * has not unlocked the VCU — when every one of them would read zero.
     *
     * With CHRSEL set and CXCTRL.CCEN on, the VCU takes palette group and
     * Pixel Color Attribute from the object's Character instead, so those are
     * read too: they, not the object's own, are what is on screen. The four
     * colors are the CRAM palette that comes to, before any OBJ world's
     * palette offset (WCEN) — which world draws the object is the frame's
     * business rather than the object's.
     */
    protected readObjectColor(sim: Sim): Promise<ObjectColor | undefined>;
    /**
     * How many bits of an object's character halfword name its character:
     * twelve under VB Color's CHREXT, the VIP's eleven otherwise.
     */
    protected charMask(): number;
    /**
     * All thirty-two worlds, in the order the VIP draws them: 31 first.
     * Empty unless the preview is in Context, the one thing that reads them
     * — or in color under WCEN, for their palette offsets.
     */
    protected allWorlds(): VipWorld[];
    /**
     * The worlds the VIP draws into the eye being shown, in its order: up to
     * the one that ends the frame, which is not drawn itself. An OBJECT world
     * is drawn if either eye asks for it — its objects then pick their own
     * eye — and any other world only if this one does.
     */
    protected contextWorlds(): VipWorld[];
    /** The selected object, decoded out of the last read of OAM. */
    protected object(): VipObject | undefined;
    /**
     * The figure the selected object is part of, or undefined for an object
     * that is a figure of one — or not drawn, and so part of none.
     */
    protected figure(): VipObjectCluster | undefined;
    /**
     * The objects Only Current Figure keeps to: the selected object's figure,
     * or the object alone when it is a figure of one.
     */
    protected figureObjects(): Set<number>;
    /**
     * The figures of more than one object, each with a picture of it, in
     * OAM order. Built with the clusters rather than while rendering, since
     * the panel re-renders whenever the pointer moves over the list.
     */
    protected buildFigures(registers: DataView, characters: VipCharacters): FigureEntry[];
    /**
     * One figure on its own, cut to the rectangle it covers: its objects
     * from the last index down, so a lower one lands on top as on screen.
     *
     * On black for the Figures list; `transparent` leaves what no object
     * draws see-through instead, for the exported file, which is a sprite
     * to be put on something else.
     */
    protected rasterizeFigure(registers: DataView, view: DataView, cluster: VipObjectCluster, characters: VipCharacters, transparent?: boolean): ImageData;
    /**
     * Write the selected object's figure out as a PNG, cut to its rectangle
     * and see-through around it, in the eye and palettes the panel is set
     * to. Nothing while the selected object is not part of a figure.
     */
    protected exportFigure(): Promise<void>;
    /**
     * Pick a figure out of the list — its first object, unless one of its
     * own is picked already — or, clicked again, let go of it.
     */
    protected selectFigure(cluster: VipObjectCluster): void;
    /**
     * A click in the Figures list that lands on none of its figures — the
     * space between and under them — lets go of the selected one, as a
     * second click on it does.
     */
    protected onFiguresClick(event: React.MouseEvent): void;
    protected setHoveredFigure(first: number | undefined): void;
    protected setOnlyFigure(value: boolean): void;
    protected selectObject(index: number): void;
    protected setShowGenericPalette(value: boolean): void;
    protected setVbColorPreview(value: boolean): void;
    protected setEye(eye: VipEye): void;
    /**
     * Whether the preview is of the one object or of the frame around it.
     * Context draws from world and BGMap memory too, so the sources are read
     * again rather than only the picture being drawn again.
     */
    protected setPreviewMode(mode: ObjectPreviewMode): void;
    /**
     * Keep the panel to the given groups. An object the list no longer holds
     * would leave the fields describing something that cannot be pointed at,
     * so the selection moves to the first object that is still listed.
     */
    protected setGroupFilter(groups: number[]): void;
    protected setShowOnlyDrawn(value: boolean): void;
    /** The shading an object palette produces, or the generic ramp instead. */
    protected intensities(registers: DataView, palette: number): number[];
    /**
     * The shade a pixel value is drawn with in color: the two bits of the
     * JPLT or GPLT register it selects, or the value itself under Generic
     * Palette — the even ramp, as the red previews draw it.
     */
    protected shade(register: number, value: number): number;
    /**
     * The palette offset WCEN has each object group drawn with: that of the
     * OBJ world that draws the group, and 0 for a group no world draws — or
     * when the world memory saying which does is not read.
     */
    protected groupWorldOffsets(colors: VcuColors): number[];
    /** One object's share of {@link groupWorldOffsets}. */
    protected objectWorldOffset(offsets: readonly number[], registers: DataView, index: number): number;
    /**
     * Paint one object in the colors the VB Color draws it with, or at the
     * faded worlds' brightness for an object Context leaves in the
     * background. A pixel the hardware leaves out — value 0 without OPQ, or
     * a Pixel Color Slot's 0xFF — is left as it is, which is the hole the
     * red previews leave for value 0.
     *
     * The character's own coordinates are worked out here rather than taken
     * from forEachVipObjectPixel, which does not pass them on: a Pixel Color
     * Slot is laid out over the unflipped character.
     */
    protected drawObjectInColor(pixels: Uint8ClampedArray, width: number, height: number, object: VipObject, characters: VipCharacters, registers: DataView, colors: VcuColors, worldOffset: number, faded?: boolean): void;
    /**
     * Patch the selected object and write it back to OAM.
     *
     * The whole eight-byte entry goes back rather than the one halfword that
     * changed: an object is small enough that rewriting it whole is simpler
     * than tracking which field lives where, and the values not being edited
     * are written back exactly as they were read.
     */
    protected writeObject(patch: Partial<VipObject>): Promise<void>;
    /** The selected object's color attributes, if they were read for it. */
    protected selectedColor(): ObjectColor | undefined;
    /**
     * Patch the selected object's OBJ Color Attribute byte. The bit neither
     * field names is written back as it was read; see encodeVcuColorAttr.
     */
    protected writeObjectColor(patch: Partial<VcuColorAttr>): Promise<void>;
    /** ...and its OBJ Pixel Color Attribute halfword, the same way. */
    protected writeObjectPixel(patch: Partial<VcuPixelAttr>): Promise<void>;
    /**
     * A screen-sized bitmap of what the preview shows.
     *
     * In Solo that is the selected object alone. In Context it is the frame
     * the VIP draws for the eye being shown: every world in its order, the
     * objects in red and every other world faded to gray. The selected object
     * is not singled out in the bitmap — the outline over it does that — so
     * the picture keeps the overlap the hardware would draw.
     *
     * In color — VB Color switched on, by the game and in the panel — both
     * are drawn in the colors the VCU gives them instead, the worlds around
     * the objects dimmed by the same factor as the gray.
     */
    protected rasterize(registers: DataView): ImageData;
    /**
     * The frame the selected object is part of, drawn into `pixels`.
     *
     * Pixel value 0 is left alone rather than painted, which is the
     * transparency the hardware gives it. Which group an OBJECT world draws
     * is decided by the drawing order, and within a group the objects are
     * drawn from the last index down, so a lower index lands on top — both
     * as the Worlds panel draws them; see vipObjectGroupForWorld.
     */
    protected rasterizeContext(registers: DataView, pixels: Uint8ClampedArray, width: number, height: number, characters: VipCharacters): void;
    /**
     * One BG world of Context's frame in color, at the faded brightness the
     * worlds around the objects are drawn with — dimmed rather than grayed,
     * since in color the objects no longer stand out by being red.
     */
    protected drawWorldInColor(world: VipWorld, pixels: Uint8ClampedArray, width: number, height: number, characters: VipCharacters, colors: VcuColors, gplts: readonly number[]): void;
    /** Just the selected object's character, at its own zoom. */
    protected rasterizeCharacter(registers: DataView, object: VipObject): ImageData;
    protected render(): React.ReactNode;
    /** Every object, decoded out of the last read of OAM — or out of `bytes`. */
    protected objects(bytes?: Uint8Array<ArrayBufferLike> | undefined): VipObject[];
    /**
     * The objects the list shows: all thousand of them, or only the ones
     * switched on for an eye, and of those only the ones in the groups the
     * filter keeps.
     */
    protected listedObjects(): VipObject[];
    /**
     * The objects in OAM order, boiled down to what tells them apart: the
     * index and the eyes it is drawn to on one line, the character it shows
     * and its flips under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next object does not mean leaving the one being read.
     */
    protected renderTiles(): React.ReactNode;
    /**
     * Walk the objects with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by index, so the keys reach what
     * the list shows and stop at its ends. The event is stopped rather than
     * only defaulted, because the emulator listens for keys on the node this
     * panel sits inside and would otherwise read an arrow as the D-pad.
     */
    protected onPanelKey(event: React.KeyboardEvent): void;
    /**
     * Select an object the screen inspector points at, letting go of a
     * filter that would leave it out of the list rather than selecting
     * something the list does not show.
     */
    reveal(target: ScreenInspectorTarget): void;
    /** Keep the picked object's tile in view, and the ring on it. */
    protected revealSelected(): void;
    /** The object itself: which one it is, and the character it shows. */
    protected renderObjectGroup(object: VipObject, registers: DataView): React.ReactNode;
    /**
     * Everything OAM holds for one object, in a grid three fields wide: what
     * it draws, where it lands, and the flags that mirror it and pick the
     * eyes it is drawn to.
     *
     * Its own height and no more: the room left over in the sidebar is the
     * Figures list's, whose length depends on the game.
     */
    protected renderPropertiesGroup(object: VipObject): React.ReactNode;
    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips and the eyes are, that is its only full name.
     * `hint`, when given, is the tooltip in its place.
     */
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    /**
     * What VB Color adds to the object: the CRAM palette it draws with, and
     * the two attributes that pick it — its OBJ Color Attribute (palette
     * group, CHRSEL) and its OBJ Pixel Color Attribute (PCE, OPQ, slot).
     *
     * Only while a VB Color game has unlocked the VCU. A bit that CXCTRL
     * leaves without effect is still shown as it stands, with a line saying
     * so, since a game setting CHRSEL before CCEN is exactly the kind of
     * thing someone opens this to find.
     */
    protected renderColorGroup(object: VipObject): React.ReactNode;
    /**
     * How the preview is drawn and what the list holds, as a bar under the
     * preview rather than a group in the sidebar: the sidebar's room belongs
     * to the object and its figures, and these are about the whole panel.
     */
    protected renderDisplayControls(): React.ReactNode;
    /**
     * Every figure of more than one object, with a picture of each — the
     * Objects panel's counterpart of the BGMaps panel's Used by, and built
     * the same way: the pointer outlines a figure in the preview, a click
     * picks it. The groups the SPT filter leaves out are left out here too.
     */
    protected renderFiguresGroup(): React.ReactNode;
    /**
     * How many objects the figure the selected one belongs to has, and which
     * stretch of OAM they come from. A guess, which the hint says: the
     * hardware has no notion of a figure; see vipObjectClusters.
     */
    protected renderFigureField(): React.ReactNode;
    protected renderPreview(object: VipObject): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-objects-panel.d.ts.map