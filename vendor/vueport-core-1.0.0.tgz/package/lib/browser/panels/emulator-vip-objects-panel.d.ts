import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { VipCharacters, VipEye, VipIntensityWatcher, VipObject, VipWorld } from './emulator-vip-memory';
import { VcuColors } from './emulator-vcu-colors';
import { VipWorldSources } from './emulator-vip-world-sources';
import { VipObjectCluster } from './emulator-vip-object-clusters';
import { VbcState, VcuColorAttr, VcuPixelAttr } from './emulator-vcu-memory';
import { Sim } from '../core/vb-core';
type ObjectPreviewMode = 'solo' | 'context';
interface FigureEntry {
    cluster: VipObjectCluster;
    group?: number;
    image: ImageData;
}
interface ObjectColor {
    index: number;
    colorByte: number;
    pixelHalfword: number;
    character?: {
        color: VcuColorAttr;
        pixel: VcuPixelAttr;
    };
    palette: number;
    colors: number[];
}
export declare class ObjectsPanel extends Panel {
    protected readonly exportFile?: VipExportFile | undefined;
    protected objectBytes?: Uint8Array;
    protected previousObjectBytes?: Uint8Array;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    protected worldBytes?: Uint8Array;
    protected readonly sources: VipWorldSources;
    protected vbc?: VbcState;
    protected objectColor?: ObjectColor;
    protected colors?: VcuColors;
    protected readonly placement: import("./emulator-vcu-colors").VcuPlacement;
    protected readonly sample: import("./emulator-vip-memory").VipWorldSample;
    protected error?: string;
    protected selected: number;
    protected showOnlyDrawn: boolean;
    protected onlyFigure: boolean;
    protected groupFilter: number;
    protected eye: VipEye;
    protected previewMode: ObjectPreviewMode;
    protected zoom: number;
    protected showExtents: boolean;
    protected showGenericPalette: boolean;
    protected vbColorPreview: boolean;
    protected image?: ImageData;
    protected clusters: VipObjectCluster[];
    protected figures: FigureEntry[];
    protected hoveredFigure?: number;
    protected figureReleased: boolean;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    protected groupEnds?: string;
    constructor(source: DebugSource, instanceId: string, exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected readCharacters(sim: Sim): Promise<void>;
    protected readWorlds(sim: Sim): Promise<void>;
    protected inColor(): boolean;
    protected readColors(sim: Sim): Promise<void>;
    /**
     * The selected object's VB Color attributes, undefined while the VCU is locked (all would read zero). With CHRSEL
     * and CXCTRL.CCEN, the VCU takes palette group and Pixel Color Attribute from the object's Character, so those are
     * read too. The four colors are the resulting CRAM palette before any OBJ world's palette offset (WCEN), as which
     * world draws the object is the frame's business.
     */
    protected readObjectColor(sim: Sim): Promise<ObjectColor | undefined>;
    protected charMask(): number;
    protected allWorlds(): VipWorld[];
    protected contextWorlds(): VipWorld[];
    protected object(): VipObject | undefined;
    protected figure(): VipObjectCluster | undefined;
    protected figureObjects(): Set<number>;
    protected buildFigures(registers: DataView, characters: VipCharacters): FigureEntry[];
    protected rasterizeFigure(registers: DataView, view: DataView, cluster: VipObjectCluster, characters: VipCharacters, transparent?: boolean): ImageData;
    protected exportFigure(): Promise<void>;
    protected selectFigure(cluster: VipObjectCluster): void;
    protected onFiguresClick(event: React.MouseEvent): void;
    protected setHoveredFigure(first: number | undefined): void;
    protected setOnlyFigure(value: boolean): void;
    protected selectObject(index: number): void;
    protected setShowGenericPalette(value: boolean): void;
    protected setVbColorPreview(value: boolean): void;
    protected setEye(eye: VipEye): void;
    protected setPreviewMode(mode: ObjectPreviewMode): void;
    protected setGroupFilter(groups: number[]): void;
    protected setShowOnlyDrawn(value: boolean): void;
    protected intensities(registers: DataView, palette: number): number[];
    protected shade(register: number, value: number): number;
    protected groupWorldOffsets(colors: VcuColors): number[];
    protected objectWorldOffset(offsets: readonly number[], registers: DataView, index: number): number;
    /**
     * Paints one object in VB Color's colors, or at the faded brightness for an object Context leaves in the
     * background. A pixel the hardware leaves out (value 0 without OPQ, or a Pixel Color Slot's 0xFF) is left alone,
     * the hole the red previews leave for value 0. The character coordinates are worked out here, as
     * forEachVipObjectPixel does not pass them on and a Pixel Color Slot is laid out over the unflipped character.
     */
    protected drawObjectInColor(pixels: Uint8ClampedArray, width: number, height: number, object: VipObject, characters: VipCharacters, registers: DataView, colors: VcuColors, worldOffset: number, faded?: boolean): void;
    protected writeObject(patch: Partial<VipObject>): Promise<void>;
    protected selectedColor(): ObjectColor | undefined;
    protected writeObjectColor(patch: Partial<VcuColorAttr>): Promise<void>;
    protected writeObjectPixel(patch: Partial<VcuPixelAttr>): Promise<void>;
    /**
     * A screen-sized bitmap of the preview: in Solo the selected object alone, in Context the frame the VIP draws for
     * the shown eye, objects in red and every other world gray. The selected object is not singled out (the outline
     * does that), so the overlap stays as the hardware draws it. In color, both use the VCU's colors, the worlds
     * around the objects dimmed by the same factor as the gray.
     */
    protected rasterize(registers: DataView): ImageData;
    protected rasterizeContext(registers: DataView, pixels: Uint8ClampedArray, width: number, height: number, characters: VipCharacters): void;
    protected drawWorldInColor(world: VipWorld, pixels: Uint8ClampedArray, width: number, height: number, characters: VipCharacters, colors: VcuColors, gplts: readonly number[]): void;
    protected rasterizeCharacter(registers: DataView, object: VipObject): ImageData;
    protected render(): React.ReactNode;
    protected objects(bytes?: Uint8Array<ArrayBufferLike> | undefined): VipObject[];
    protected listedObjects(): VipObject[];
    protected renderTiles(): React.ReactNode;
    protected onPanelKey(event: React.KeyboardEvent): void;
    reveal(target: ScreenInspectorTarget): void;
    protected revealSelected(behavior?: ScrollBehavior): void;
    protected renderObjectGroup(object: VipObject, registers: DataView): React.ReactNode;
    protected renderPropertiesGroup(object: VipObject): React.ReactNode;
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    protected renderColorGroup(object: VipObject): React.ReactNode;
    protected renderDisplayControls(): React.ReactNode;
    protected renderFiguresGroup(): React.ReactNode;
    protected renderFigureField(): React.ReactNode;
    protected renderPreview(object: VipObject): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-objects-panel.d.ts.map