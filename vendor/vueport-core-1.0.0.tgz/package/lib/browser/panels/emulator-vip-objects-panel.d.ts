import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { VipEye, VipIntensityWatcher, VipObject } from './emulator-vip-memory';
import { Sim } from '../core/vb-core';
/**
 * The VIP's object attribute memory: up to 1024 sprites.
 *
 * Three columns, the shape the Worlds and BGMaps panels have: the objects as
 * tiles, the fields of the one picked, and a preview of where on screen it
 * lands. The tiles keep to the objects actually drawn by default, since most
 * of OAM in a typical game is unused slots. Rendering the previews is what
 * makes this panel read character memory too; the list on its own needs only
 * OAM.
 */
export declare class ObjectsPanel extends Panel {
    protected objectBytes?: Uint8Array;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    protected error?: string;
    /** The object the fields and the preview describe. There is always one. */
    protected selected: number;
    /**
     * Whether the list keeps to the objects the VIP actually draws — the ones
     * switched on for an eye. On, because most of OAM in a typical game is
     * slots nothing has been put in.
     */
    protected showOnlyDrawn: boolean;
    protected eye: VipEye;
    protected zoom: number;
    /**
     * Whether the previews are shaded with an even ramp instead of the object
     * palette registers. Off: they resolve the brightness registers the way
     * the core does, so the real palettes look like the picture on screen.
     */
    protected showGenericPalette: boolean;
    protected image?: ImageData;
    protected dirty: boolean;
    protected readonly intensityWatcher: VipIntensityWatcher;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected readCharacters(sim: Sim): Promise<void>;
    /** The selected object, decoded out of the last read of OAM. */
    protected object(): VipObject | undefined;
    protected selectObject(index: number): void;
    protected setShowGenericPalette(value: boolean): void;
    protected setEye(eye: VipEye): void;
    protected setShowOnlyDrawn(value: boolean): void;
    /** The shading an object palette produces, or the generic ramp instead. */
    protected intensities(registers: DataView, palette: number): number[];
    /**
     * Patch the selected object and write it back to OAM.
     *
     * The whole eight-byte entry goes back rather than the one halfword that
     * changed: an object is small enough that rewriting it whole is simpler
     * than tracking which field lives where, and the values not being edited
     * are written back exactly as they were read.
     */
    protected writeObject(patch: Partial<VipObject>): Promise<void>;
    /** A screen-sized bitmap of what the selected object alone draws. */
    protected rasterize(registers: DataView): ImageData;
    /** Just the selected object's character, at its own zoom. */
    protected rasterizeCharacter(registers: DataView, object: VipObject): ImageData;
    protected render(): React.ReactNode;
    /** Every object, decoded out of the last read of OAM. */
    protected objects(): VipObject[];
    /**
     * The objects the list shows: all thousand of them, or only the ones
     * switched on for an eye.
     */
    protected listedObjects(): VipObject[];
    /**
     * The objects in OAM order, boiled down to what tells them apart: the
     * index and the eyes it is drawn to on one line, the character it shows
     * and its flips under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next object does not mean leaving the one being read.
     */
    protected renderTiles(): React.ReactNode;
    /**
     * Walk the objects with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by index, so the keys reach what
     * the list shows and stop at its ends. The event is stopped rather than
     * only defaulted, because the emulator listens for keys on the node this
     * panel sits inside and would otherwise read an arrow as the D-pad.
     */
    protected onPanelKey(event: React.KeyboardEvent): void;
    /** Keep the picked object's tile in view, and the ring on it. */
    protected revealSelected(): void;
    /** The object itself: which one it is, and the character it shows. */
    protected renderObjectGroup(object: VipObject, registers: DataView): React.ReactNode;
    /**
     * Everything OAM holds for one object, in a grid three fields wide: what
     * it draws, where it lands, and the flags that mirror it and pick the
     * eyes it is drawn to.
     */
    protected renderPropertiesGroup(object: VipObject): React.ReactNode;
    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips and the eyes are, that is its only full name.
     */
    protected renderToggle(label: string, name: string, value: boolean, onChange: (value: boolean) => void): React.ReactNode;
    protected renderDisplayGroup(): React.ReactNode;
    protected renderPreview(): React.ReactNode;
}
//# sourceMappingURL=emulator-vip-objects-panel.d.ts.map