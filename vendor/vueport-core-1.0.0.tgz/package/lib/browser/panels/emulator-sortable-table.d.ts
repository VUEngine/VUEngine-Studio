import * as React from 'react';
export type TableSortValue = string | number | boolean | null | undefined;
export type TableSortDirection = 'ascending' | 'descending';
export interface TableSort<K extends string> {
    column?: K;
    direction?: TableSortDirection;
}
export declare function nextTableSort<K extends string>(sort: TableSort<K>, column: K): TableSort<K>;
export declare function sortTableRows<T, K extends string>(rows: readonly T[], sort: TableSort<K>, valueOf: (row: T, column: K) => TableSortValue): T[];
interface SortableHeaderProps<K extends string> extends Omit<React.ThHTMLAttributes<HTMLTableCellElement>, 'onClick'> {
    column: K;
    sort: TableSort<K>;
    onSort: (column: K) => void;
}
export declare function SortableHeader<K extends string>({ column, sort, onSort, children, ...attributes }: SortableHeaderProps<K>): React.ReactElement;
export {};
//# sourceMappingURL=emulator-sortable-table.d.ts.map