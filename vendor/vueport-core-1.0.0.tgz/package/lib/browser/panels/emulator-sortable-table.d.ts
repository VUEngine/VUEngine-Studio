import * as React from 'react';
export type TableSortValue = string | number | boolean | null | undefined;
export type TableSortDirection = 'ascending' | 'descending';
export interface TableSort<K extends string> {
    column?: K;
    direction?: TableSortDirection;
}
/** A new column starts ascending; clicking the active one reverses it. */
export declare function nextTableSort<K extends string>(sort: TableSort<K>, column: K): TableSort<K>;
/** Stable sorting, with absent values kept at the end in either direction. */
export declare function sortTableRows<T, K extends string>(rows: readonly T[], sort: TableSort<K>, valueOf: (row: T, column: K) => TableSortValue): T[];
interface SortableHeaderProps<K extends string> extends Omit<React.ThHTMLAttributes<HTMLTableCellElement>, 'onClick'> {
    column: K;
    sort: TableSort<K>;
    onSort: (column: K) => void;
}
/** A keyboard-accessible table header which reports its sort through aria-sort. */
export declare function SortableHeader<K extends string>({ column, sort, onSort, children, ...attributes }: SortableHeaderProps<K>): React.ReactElement;
export {};
//# sourceMappingURL=emulator-sortable-table.d.ts.map