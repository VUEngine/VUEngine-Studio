export declare const VIP_FRAME_BUFFER_WIDTH = 384;
export declare const VIP_FRAME_BUFFER_HEIGHT = 224;
export declare const VIP_FRAME_BUFFER_BYTES_PER_COLUMN = 64;
export declare const VIP_FRAME_BUFFER_BYTES: number;
export declare const VIP_LEFT_FRAME_BUFFER_0 = 0;
export declare const VIP_LEFT_FRAME_BUFFER_1 = 32768;
export declare const VIP_RIGHT_FRAME_BUFFER_0 = 65536;
export declare const VIP_RIGHT_FRAME_BUFFER_1 = 98304;
export type VipEye = 'left' | 'right';
export declare function vipFrameBufferAddress(eye: VipEye, index: number): number;
export declare class VipFrameBuffer {
    protected readonly bytes: Uint8Array | undefined;
    constructor(bytes: Uint8Array | undefined);
    pixel(x: number, y: number): number;
}
export declare const VIP_CHAR_SEGMENTS: number[];
export declare const VIP_CHARS_PER_SEGMENT = 512;
export declare const VIP_CHAR_COUNT: number;
export declare const VIP_CHAR_BYTES = 16;
export declare const VIP_CHAR_SIZE = 8;
export declare const VIP_CHAR_SEGMENT_BYTES: number;
export declare const VIP_CHAR_SEGMENT_COUNT_EXTENDED = 8;
export declare const VIP_CHAR_COUNT_EXTENDED: number;
export declare function vipCharSegmentCount(extended: boolean): number;
export declare const VIP_BGMAP_BASE = 131072;
export declare const VIP_BGMAP_BYTES = 8192;
export declare const VIP_BGMAP_COUNT = 14;
export declare const VIP_BGMAP_CELLS = 64;
export declare const VIP_BGMAP_SEGMENT_PIXELS: number;
export declare const VIP_WORLD_BASE = 251904;
export declare const VIP_WORLD_BYTES = 32;
export declare const VIP_WORLD_COUNT = 32;
export declare const VIP_WORLD_BLOCK_BYTES: number;
export declare const VIP_OAM_BASE = 253952;
export declare const VIP_OBJECT_BYTES = 8;
export declare const VIP_OBJECT_COUNT = 1024;
export declare const VIP_OAM_BLOCK_BYTES: number;
export declare const VIP_REGISTER_BASE = 391168;
export declare const VIP_REGISTER_BLOCK_BYTES = 128;
export declare enum VipRegister {
    INTPND = 0,
    INTENB = 2,
    INTCLR = 4,
    DPSTTS = 32,
    DPCTRL = 34,
    BRTA = 36,
    BRTB = 38,
    BRTC = 40,
    REST = 42,
    FRMCYC = 46,
    CTA = 48,
    XPSTTS = 64,
    XPCTRL = 66,
    VER = 68,
    SPT0 = 72,
    SPT1 = 74,
    SPT2 = 76,
    SPT3 = 78,
    GPLT0 = 96,
    GPLT1 = 98,
    GPLT2 = 100,
    GPLT3 = 102,
    JPLT0 = 104,
    JPLT1 = 106,
    JPLT2 = 108,
    JPLT3 = 110,
    BKCOL = 112
}
export declare const VIP_OBJECT_GROUP_COUNT = 4;
export declare const VIP_OBJECT_GROUP_ENDS: VipRegister[];
export declare function vipObjectGroupRange(registers: DataView, group: number): {
    first: number;
    last: number;
} | undefined;
export declare function vipObjectGroupOf(registers: DataView, index: number): number | undefined;
/**
 * Not in the world entry: the group pointer starts at 3 and steps down at every OBJECT world drawn, so a world's
 * group depends on what is above it. `worlds` is in drawing order, 31 first. Undefined for a world the VIP never
 * reaches, and past the fourth OBJECT world (no group left; not guessed).
 * Measured against the core in tests/object-group-probe.mjs: an OBJECT world with both eye bits clear consumes
 * no group, one eye is enough. End stops the VIP at its world, which draws nothing and takes no group. Eye bits
 * only decide whether a world is drawn; which eye its objects land in is each object's JLON/JRON (see
 * forEachVipObjectPixel)
 */
export declare function vipObjectGroupForWorld(worlds: readonly VipWorld[], index: number): number | undefined;
export declare const VIP_BGMAP_PALETTES: VipRegister[];
export declare const VIP_OBJECT_PALETTES: VipRegister[];
export declare function vipCharSegmentAddress(segment: number): number;
export declare const VIP_CHAR_MIRROR_BASE = 491520;
export declare function vipCharMirrorAddress(segment: number): number;
export declare function vipBgMapAddress(segment: number): number;
export declare function vipWorldAddress(index: number): number;
export declare function vipObjectAddress(index: number): number;
export declare function vipParamTableAddress(param: number): number;
export declare function vipBrightnessLevels(brta: number, brtb: number, brtc: number): number[];
export declare function vipBrightnessLevel(repeat: number): number;
export declare function vipPaletteIntensities(palette: number, levels: number[]): number[];
export declare function vipBrightnessLevelsFromRegisters(registers: DataView): number[];
export declare function vipIntensitiesForRegister(registers: DataView, register: VipRegister): number[];
export declare class VipIntensityWatcher {
    protected static readonly WATCHED: VipRegister[];
    protected signature?: string;
    changed(registers: DataView): boolean;
}
export declare const VIP_GRAPHICS_POLL_HZ = 4;
export declare const VIP_GENERIC_PALETTE_INTENSITIES: number[];
export declare class VipCharacters {
    protected readonly segments: ReadonlyArray<Uint8Array | undefined>;
    constructor(segments: ReadonlyArray<Uint8Array | undefined>);
    get charMask(): number;
    pixel(char: number, x: number, y: number): number;
}
export interface VipBgMapCell {
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
}
export declare function decodeVipBgMapCell(cell: number, charMask?: number): VipBgMapCell;
export declare function encodeVipBgMapCell(cell: VipBgMapCell, charMask?: number): number;
export declare enum VipWorldMode {
    BGMAP = 0,
    HBIAS = 1,
    AFFINE = 2,
    OBJECT = 3
}
export declare const VIP_WORLD_MODE_NAMES: Record<VipWorldMode, string>;
export interface VipWorld {
    index: number;
    head: number;
    lon: boolean;
    ron: boolean;
    mode: VipWorldMode;
    scx: number;
    scy: number;
    overplane: boolean;
    end: boolean;
    bgMap: number;
    gx: number;
    gp: number;
    gy: number;
    mx: number;
    mp: number;
    my: number;
    w: number;
    h: number;
    param: number;
    overplaneIndex: number;
}
export declare function decodeVipWorld(view: DataView, index: number, byteOffset?: number): VipWorld;
export declare enum VipWorldField {
    HEAD = 0,
    GX = 1,
    GP = 2,
    GY = 3,
    MX = 4,
    MP = 5,
    MY = 6,
    W = 7,
    H = 8,
    PARAM = 9,
    OVERPLANE_INDEX = 10
}
export declare function encodeVipWorldHead(world: VipWorld): number;
export declare const VIP_HBIAS_ENTRY_BYTES = 4;
export declare const VIP_AFFINE_ENTRY_BYTES = 16;
export interface VipHBiasEntry {
    left: number;
    right: number;
}
export declare function decodeVipHBias(view: DataView, row: number): VipHBiasEntry;
export declare function vipHBiasRow(params: DataView | undefined, row: number): VipHBiasEntry | undefined;
export interface VipAffineEntry {
    mx: number;
    mp: number;
    my: number;
    dx: number;
    dy: number;
}
export declare function decodeVipAffine(view: DataView, row: number): VipAffineEntry;
export declare function vipAffineRow(params: DataView | undefined, row: number): VipAffineEntry | undefined;
export declare function vipParamRows(world: VipWorld): number;
export declare function vipParamTableBytes(world: VipWorld): number;
export declare function vipDrawnWorlds(worlds: ReadonlyArray<VipWorld>): VipWorld[];
export declare function vipWorldSegments(world: VipWorld): number[];
export declare function vipOverplaneSegment(world: VipWorld): number;
export declare function vipWorldMapSegment(world: VipWorld, cellX: number, cellY: number): number;
export interface VipBgMapSegmentUse {
    worlds: number[];
    params: number[];
}
export declare function vipBgMapSegmentUses(worlds: ReadonlyArray<VipWorld>): VipBgMapSegmentUse[];
export interface VipObject {
    index: number;
    jx: number;
    jp: number;
    jy: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    lon: boolean;
    ron: boolean;
}
export declare function isVipObjectVisible(object: VipObject): boolean;
export declare function decodeVipObject(view: DataView, index: number, byteOffset?: number, charMask?: number): VipObject;
export declare function encodeVipObject(object: VipObject, charMask?: number): number[];
export declare class VipCharacterUsage {
    protected readonly charMask: number;
    protected readonly cells: Uint16Array<ArrayBuffer>;
    protected readonly objects: Uint16Array<ArrayBuffer>;
    protected readonly totals: Uint32Array<ArrayBuffer>;
    constructor(charMask?: number);
    addBgMapSegment(segment: number, bytes: Uint8Array, drawn?: boolean): void;
    addObjects(bytes: Uint8Array): void;
    used(char: number): boolean;
    objectCount(char: number): number;
    bgMapCounts(char: number): {
        segment: number;
        cells: number;
    }[];
}
export declare function vipChangedCharacters(bytes: Uint8Array, previous: Uint8Array): number[];
export declare function vipCharacterUsage(bgMapSegments: ReadonlyArray<Uint8Array | undefined>, oam: Uint8Array | undefined, drawnSegments?: ReadonlyArray<boolean>, charMask?: number): VipCharacterUsage;
export declare function drawVipChar(target: Uint8ClampedArray, targetWidth: number, destX: number, destY: number, characters: VipCharacters, char: number, intensities: number[], hFlip?: boolean, vFlip?: boolean, transparentZero?: boolean): void;
export interface VipWorldSample {
    segment: number;
    cell: number;
    char: number;
    palette: number;
    value: number;
    charX: number;
    charY: number;
}
export declare function vipWorldSample(): VipWorldSample;
/**
 * A world's source coordinates address a virtual map scx by scy segments, left to right and top to bottom from
 * its base segment. Outside it they wrap (which makes a 1x1 world a tiling background), or with the overplane flag
 * read the cell OVR indexes, whose segment must be handed over too (see vipWorldSegments).
 * Segments are indexed by absolute BGMap segment number, so a caller only reads those the world spans; a missing
 * one reads as blank, like VipCharacters does
 */
export declare class VipWorldMap {
    protected readonly world: VipWorld;
    protected readonly segments: ReadonlyArray<Uint8Array | undefined>;
    protected readonly characters: VipCharacters;
    protected readonly width: number;
    protected readonly height: number;
    constructor(world: VipWorld, segments: ReadonlyArray<Uint8Array | undefined>, characters: VipCharacters);
    intensity(x: number, y: number, palettes: number[][]): number;
    sample(x: number, y: number, into: VipWorldSample): VipWorldSample;
    char(x: number, y: number): number;
    segmentAt(x: number, y: number): number;
    protected overplaneCell(): number;
    protected cellAt(wx: number, wy: number): number;
}
export declare function vipWorldExtents(world: VipWorld, eye: VipEye): {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare function vipObjectExtents(object: VipObject, eye: VipEye): {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare function vipWorldSourceExtents(world: VipWorld, segment: number): {
    x: number;
    y: number;
    width: number;
    height: number;
} | undefined;
export declare function forEachVipWorldPixel(world: VipWorld, targetWidth: number, targetHeight: number, eye: VipEye, params: DataView | undefined, visit: (destX: number, destY: number, sourceX: number, sourceY: number) => void): void;
export declare function drawVipWorld(target: Uint8ClampedArray, targetWidth: number, targetHeight: number, world: VipWorld, map: VipWorldMap, palettes: number[][], eye: VipEye, params?: DataView): void;
export declare function forEachVipObjectPixel(object: VipObject, targetWidth: number, targetHeight: number, characters: VipCharacters, eye: VipEye, visit: (destX: number, destY: number, value: number) => void): void;
export declare function drawVipObject(target: Uint8ClampedArray, targetWidth: number, targetHeight: number, object: VipObject, characters: VipCharacters, intensities: number[], eye: VipEye): void;
export declare function sameVipBytes(a: Uint8Array | undefined, b: Uint8Array | undefined): boolean;
//# sourceMappingURL=emulator-vip-memory.d.ts.map