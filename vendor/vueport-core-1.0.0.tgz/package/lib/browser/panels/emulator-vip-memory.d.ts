/**
 * The VIP's memory map, and decoders for the structures living in it.
 *
 * Addresses and bit layouts are transcribed from the hardware headers this
 * project already ships, `applications/electron/vb/libgccvb/source/`
 * (`video.h`, `vip.h`, `bgmap.h`, `world.h`, `object.h`), which are the
 * authority for everything here.
 *
 * Everything in this module is pure so it can be reasoned about, and reused,
 * without a running emulator.
 */
/**
 * Frame buffer memory: two ping-ponged buffers per eye (the VIP draws into
 * one while the other displays), each a full 384x224 image at two bits per
 * pixel. Unlike character or BGMap data, a frame buffer's two-bit values are
 * already resolved brightness levels (see vipBrightnessLevels) rather than
 * palette indices needing a GPLTn/JPLTn lookup — the VIP's drawing hardware
 * has already done that lookup on the way in.
 *
 * Per `__FRAME_BUFFERS_SIZE`/`__LEFT_FRAME_BUFFER_0`/etc. in
 * `[vuengine-core]/platforms/VirtualBoy/headers/Config.h`,
 * and the pixel packing in `.../Hardware/FrameBuffers.c`'s `drawColorPixel`:
 * each column is 64 bytes (16 words) regardless of the 224 rows actually
 * used, i.e. up to 256 rows would fit — the leftover is simply unused.
 */
export declare const VIP_FRAME_BUFFER_WIDTH = 384;
export declare const VIP_FRAME_BUFFER_HEIGHT = 224;
export declare const VIP_FRAME_BUFFER_BYTES_PER_COLUMN = 64;
export declare const VIP_FRAME_BUFFER_BYTES: number;
export declare const VIP_LEFT_FRAME_BUFFER_0 = 0;
export declare const VIP_LEFT_FRAME_BUFFER_1 = 32768;
export declare const VIP_RIGHT_FRAME_BUFFER_0 = 65536;
export declare const VIP_RIGHT_FRAME_BUFFER_1 = 98304;
/** Which eye something is drawn for; the two differ by parallax. */
export type VipEye = 'left' | 'right';
export declare function vipFrameBufferAddress(eye: VipEye, index: number): number;
/** Random access to one frame buffer's pixels. */
export declare class VipFrameBuffer {
    protected readonly bytes: Uint8Array | undefined;
    constructor(bytes: Uint8Array | undefined);
    /** The two-bit value of one pixel, or 0 when the buffer is missing. */
    pixel(x: number, y: number): number;
}
/** Character segments. Each holds 512 characters and they are not contiguous. */
export declare const VIP_CHAR_SEGMENTS: number[];
export declare const VIP_CHARS_PER_SEGMENT = 512;
export declare const VIP_CHAR_COUNT: number;
/** 8x8 pixels at two bits each. */
export declare const VIP_CHAR_BYTES = 16;
export declare const VIP_CHAR_SIZE = 8;
export declare const VIP_CHAR_SEGMENT_BYTES: number;
/** BGMap memory: 14 segments of 64x64 cells, two bytes per cell. */
export declare const VIP_BGMAP_BASE = 131072;
export declare const VIP_BGMAP_BYTES = 8192;
export declare const VIP_BGMAP_COUNT = 14;
export declare const VIP_BGMAP_CELLS = 64;
/** A segment's size in pixels, which is what a world's source coordinates are in. */
export declare const VIP_BGMAP_SEGMENT_PIXELS: number;
/** World attribute memory: 32 worlds of 32 bytes. */
export declare const VIP_WORLD_BASE = 251904;
export declare const VIP_WORLD_BYTES = 32;
export declare const VIP_WORLD_COUNT = 32;
export declare const VIP_WORLD_BLOCK_BYTES: number;
/** Object attribute memory: 1024 objects of 8 bytes. */
export declare const VIP_OAM_BASE = 253952;
export declare const VIP_OBJECT_BYTES = 8;
export declare const VIP_OBJECT_COUNT = 1024;
export declare const VIP_OAM_BLOCK_BYTES: number;
/** Register block. One read covers all of it. */
export declare const VIP_REGISTER_BASE = 391168;
export declare const VIP_REGISTER_BLOCK_BYTES = 128;
/**
 * Register offsets in bytes.
 *
 * `vip.h` indexes a `u16*`, so its mnemonics are halfword indices; these are
 * doubled to byte offsets from VIP_REGISTER_BASE.
 */
export declare enum VipRegister {
    INTPND = 0,
    INTENB = 2,
    INTCLR = 4,
    DPSTTS = 32,
    DPCTRL = 34,
    BRTA = 36,
    BRTB = 38,
    BRTC = 40,
    REST = 42,
    FRMCYC = 46,
    CTA = 48,
    XPSTTS = 64,
    XPCTRL = 66,
    VER = 68,
    SPT0 = 72,
    SPT1 = 74,
    SPT2 = 76,
    SPT3 = 78,
    GPLT0 = 96,
    GPLT1 = 98,
    GPLT2 = 100,
    GPLT3 = 102,
    JPLT0 = 104,
    JPLT1 = 106,
    JPLT2 = 108,
    JPLT3 = 110,
    BKCOL = 112
}
/**
 * The object groups, and the registers that say where each one ends in OAM.
 *
 * The VIP draws objects in four groups. SPT3 holds the index of the last
 * object of group 3, SPT2 that of group 2, and so on down; a group starts one
 * past where the group below it ended, and group 0 starts at object 0. Only
 * the low ten bits of a register are the index.
 *
 * Which group a world gets is not in the registers but in the drawing order:
 * see {@link vipObjectGroupRange} and the Worlds panel.
 */
export declare const VIP_OBJECT_GROUP_COUNT = 4;
export declare const VIP_OBJECT_GROUP_ENDS: VipRegister[];
/**
 * Which objects one group holds, as a first and last index, or undefined for
 * a group the registers leave empty.
 *
 * Objects in a group are drawn from the last index down to the first, so a
 * lower index is drawn later and lands on top.
 */
export declare function vipObjectGroupRange(registers: DataView, group: number): {
    first: number;
    last: number;
} | undefined;
/**
 * Which object group a world draws, or undefined for a world the VIP never
 * gets to.
 *
 * Not in the world entry: the group pointer starts at 3 and steps down at
 * every OBJECT world the VIP draws, so which group a world takes depends on
 * what is above it. `worlds` is every world in drawing order, 31 first.
 *
 * Three rules here were measured against the core rather than read out of a
 * document, in `tests/object-group-probe.mjs`:
 *
 * - An OBJECT world with both eye bits clear is passed over and does not
 *   consume a group; one eye is enough to consume one.
 * - End stops the VIP at its world rather than after it, so a world carrying
 *   it draws nothing and takes no group with it.
 * - A world's eye bits decide only whether it is drawn at all. Which eye its
 *   objects land in is each object's own JLON/JRON — see
 *   {@link forEachVipObjectPixel}, which is where an object's parallax is
 *   applied.
 *
 * Past the fourth OBJECT world the hardware has no group left to hand out;
 * this answers undefined rather than guessing at what it does then.
 */
export declare function vipObjectGroupForWorld(worlds: readonly VipWorld[], index: number): number | undefined;
export declare const VIP_BGMAP_PALETTES: VipRegister[];
export declare const VIP_OBJECT_PALETTES: VipRegister[];
export declare function vipCharSegmentAddress(segment: number): number;
/**
 * Real hardware does not fully decode VIP addresses, so the four character
 * tables — 0x2000 bytes each, matching VIP_CHAR_SEGMENT_BYTES — repeat
 * contiguously starting here, unlike their primary addresses (VIP_CHAR_SEGMENTS),
 * which are spaced 0x8000 apart:
 *
 *   0x00078000-0x00079FFF  mirror of character table 0
 *   0x0007A000-0x0007BFFF  mirror of character table 1
 *   0x0007C000-0x0007DFFF  mirror of character table 2
 *   0x0007E000-0x0007FFFF  mirror of character table 3
 */
export declare const VIP_CHAR_MIRROR_BASE = 491520;
export declare function vipCharMirrorAddress(segment: number): number;
export declare function vipBgMapAddress(segment: number): number;
export declare function vipWorldAddress(index: number): number;
export declare function vipObjectAddress(index: number): number;
/**
 * Where a world's param register points, for the H-bias and Affine tables.
 *
 * The register holds the table's offset into BGMap memory in halfwords, per
 * `WORLD_PARAM` in `world.h`, which stores `(address - 0x20000) >> 1`.
 */
export declare function vipParamTableAddress(param: number): number;
/**
 * The four brightness levels a palette entry can select, as the screen shows
 * them.
 *
 * The display is monochrome, so a level is an intensity rather than a color.
 * Level 3 is the sum of all three brightness registers, which is why the engine
 * config warns when bright red is not larger than medium plus dark.
 */
export declare function vipBrightnessLevels(brta: number, brtb: number, brtc: number): number[];
/**
 * What the core renders one brightness register's worth of light as.
 *
 * A register is a repeat count — how long the row's LEDs stay lit — and the
 * core resolves that onto a gamma-like curve rather than proportionally. The
 * previews have to follow the same curve or they come out much darker than
 * the picture beside them: at the brightness VUEngine configures by default
 * (32, 64, 32) the levels are 105, 162 and 250 out of 255, not 32, 64 and
 * 128.
 *
 * Measured against the core itself — `tests/brightness-probe.mjs` sweeps
 * every repeat count — and fitted: the display is fully lit at 128 repeats,
 * which the core renders as 250, and the curve through the rest is a gamma of
 * 1.6. Exact at the three stops {@link VB_LEVEL_STOPS} records, and within
 * one step of the core over the whole range.
 */
export declare function vipBrightnessLevel(repeat: number): number;
/**
 * Resolve a palette register into one intensity per pixel value.
 *
 * Pixel value 0 would select the register's lowest two bits, but the hardware
 * hardwires those to zero and always draws value 0 as black — that is what
 * makes it the transparent value. It is forced here rather than read, so that
 * junk in those bits cannot show up as a shade that the VIP would never draw.
 */
export declare function vipPaletteIntensities(palette: number, levels: number[]): number[];
/** vipBrightnessLevels, reading straight out of a register block. */
export declare function vipBrightnessLevelsFromRegisters(registers: DataView): number[];
/** The shading a palette register produces, reading straight out of a register block. */
export declare function vipIntensitiesForRegister(registers: DataView, register: VipRegister): number[];
/**
 * Tracks whether the registers that affect palette shading have changed.
 *
 * Shared by the Characters and BGMaps panels, which both cache a rasterized
 * bitmap and only need to redraw it when either the underlying tiles or their
 * shading actually changed.
 */
export declare class VipIntensityWatcher {
    protected static readonly WATCHED: VipRegister[];
    protected signature?: string;
    /** True the first time, and whenever a watched register's value changes. */
    changed(registers: DataView): boolean;
}
/** Refresh rate for the panels that rasterize VRAM, which read up to 40 KB a time. */
export declare const VIP_GRAPHICS_POLL_HZ = 4;
/**
 * Not a hardware register: an evenly spaced black/dark/medium/bright ramp,
 * for looking at tile data on its own rather than through however the
 * currently running program happens to have set its palette registers up.
 * Shared by the Characters and BGMaps panels.
 */
export declare const VIP_GENERIC_PALETTE_INTENSITIES: number[];
/**
 * Random access to character pixels across the four segments.
 *
 * A segment that has not been read is treated as blank rather than as an error,
 * so a view can render what it has while the rest is still in flight.
 */
export declare class VipCharacters {
    protected readonly segments: ReadonlyArray<Uint8Array | undefined>;
    constructor(segments: ReadonlyArray<Uint8Array | undefined>);
    /** The two-bit value of one pixel, or 0 when its segment is missing. */
    pixel(char: number, x: number, y: number): number;
}
export interface VipBgMapCell {
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
}
/** Per `bgmap.h`: BGM_HFLIP is 0x2000, BGM_VFLIP 0x1000, character mask 0x7FF. */
export declare function decodeVipBgMapCell(cell: number): VipBgMapCell;
/**
 * Inverse of decodeVipBgMapCell, for writing an edited cell back to VRAM.
 *
 * Bit 11 is unaccounted for by either function — it belongs to neither the
 * 11-bit character index nor the flip/palette bits above it — so this always
 * writes it as zero rather than trying to preserve whatever a cell happened
 * to hold there.
 */
export declare function encodeVipBgMapCell(cell: VipBgMapCell): number;
export declare enum VipWorldMode {
    BGMAP = 0,
    HBIAS = 1,
    AFFINE = 2,
    OBJECT = 3
}
export declare const VIP_WORLD_MODE_NAMES: Record<VipWorldMode, string>;
export interface VipWorld {
    index: number;
    head: number;
    /** Shown on the left eye. */
    lon: boolean;
    /** Shown on the right eye. */
    ron: boolean;
    mode: VipWorldMode;
    /** Segments across and down, as a count rather than the exponent. */
    scx: number;
    scy: number;
    /** Draw the overplane outside the map instead of repeating it. */
    overplane: boolean;
    /** Drawing stops at this world. */
    end: boolean;
    /** Base BGMap segment. */
    bgMap: number;
    /** Destination on screen. */
    gx: number;
    gp: number;
    gy: number;
    /** Source within the BGMap. */
    mx: number;
    mp: number;
    my: number;
    /** Register values, which the hardware reads as size minus one. */
    w: number;
    h: number;
    param: number;
    overplaneCell: number;
}
/** Decode one 32-byte world attribute entry. Bit layout per `world.h`. */
export declare function decodeVipWorld(view: DataView, index: number, byteOffset?: number): VipWorld;
/**
 * Which halfword of a world entry each field lives in, for writing one back.
 *
 * The order is `world.h`'s WORLD struct; everything the header packs into the
 * head halfword shares index 0 and goes through encodeVipWorldHead.
 */
export declare enum VipWorldField {
    HEAD = 0,
    GX = 1,
    GP = 2,
    GY = 3,
    MX = 4,
    MP = 5,
    MY = 6,
    W = 7,
    H = 8,
    PARAM = 9,
    OVERPLANE_CELL = 10
}
/**
 * Inverse of the head bits decodeVipWorld reads, for writing an edited world
 * back to VRAM.
 *
 * Bits 5 and 4 are unaccounted for by either function — they belong to none of
 * the fields `world.h` documents — so this always writes them as zero rather
 * than trying to preserve whatever a world happened to hold there.
 */
export declare function encodeVipWorldHead(world: VipWorld): number;
/**
 * Param table entries, whose size and layout depend on the world's mode.
 *
 * Both tables hold one entry per screen row of the world, starting at
 * vipParamTableAddress. The sizes are the ones the engine allocates in
 * `ParamTableManager::calculateSpriteParamTableSize`: four bytes a row for
 * H-bias, sixteen for Affine.
 */
export declare const VIP_HBIAS_ENTRY_BYTES = 4;
export declare const VIP_AFFINE_ENTRY_BYTES = 16;
export interface VipHBiasEntry {
    /** Horizontal shift of this row's source, per eye. */
    left: number;
    right: number;
}
export declare function decodeVipHBias(view: DataView, row: number): VipHBiasEntry;
/** One row's H-bias entry, or undefined when the table was not read that far. */
export declare function vipHBiasRow(params: DataView | undefined, row: number): VipHBiasEntry | undefined;
/**
 * One row of an Affine world's param table.
 *
 * `mx`/`my` are 13.3 fixed point and replace the world's own MX/MY for this
 * row; `dx`/`dy` are 7.9 fixed point and step the source position along the
 * row, which is what lets an affine world rotate and scale. Per `affine.c`,
 * whose comments spell out both formats and the 16-byte stride.
 */
export interface VipAffineEntry {
    mx: number;
    mp: number;
    my: number;
    dx: number;
    dy: number;
}
export declare function decodeVipAffine(view: DataView, row: number): VipAffineEntry;
/** The same, for an Affine row. */
export declare function vipAffineRow(params: DataView | undefined, row: number): VipAffineEntry | undefined;
/**
 * How many rows of param table a world uses: one per row of the world, capped
 * at what a screen can show. Zero for the modes that have no param table.
 */
export declare function vipParamRows(world: VipWorld): number;
/** ...and how many bytes that is, clamped to the end of BGMap memory. */
export declare function vipParamTableBytes(world: VipWorld): number;
/**
 * The worlds the VIP actually draws, in the order it considers them.
 *
 * Drawing runs from world 31 downwards and stops at the first world with the
 * END flag, which is therefore not drawn either — that dummy terminator is how
 * a program tells the hardware where its sprites end. Worlds shown to neither
 * eye are dropped as well, so what is left is what reaches the screen.
 */
export declare function vipDrawnWorlds(worlds: ReadonlyArray<VipWorld>): VipWorld[];
/**
 * The BGMap segments one world maps from, in the order they are laid out.
 *
 * A world's map is scx by scy segments, left to right and top to bottom from
 * its base segment; only the low four bits of a segment number reach the
 * hardware, so the run wraps rather than running on. The same segment can
 * therefore appear twice in a map, which is why this returns the layout
 * rather than a set — see {@link vipWorldMapSegment} for reading one position
 * of it, and dedupe where a count per segment is wanted.
 */
export declare function vipWorldSegments(world: VipWorld): number[];
/** The segment covering one cell of a world's virtual map. */
export declare function vipWorldMapSegment(world: VipWorld, cellX: number, cellY: number): number;
/** What a BGMap segment is being used for, per vipBgMapSegmentUses. */
export interface VipBgMapSegmentUse {
    /** Indices of the worlds whose map spans this segment. */
    worlds: number[];
    /** Indices of the worlds whose param table overlaps it. */
    params: number[];
}
/**
 * Which worlds put what in each of the fourteen BGMap segments.
 *
 * Only the worlds the VIP draws are counted (see vipDrawnWorlds): unused world
 * entries are all zeroes, which reads as a 1x1 BGMap world on segment 0, and
 * listing two dozen of those against segment 0 would say nothing at all.
 *
 * Param tables are included because they live in BGMap memory too — an H-bias
 * or Affine world's table takes space out of the segments at the top of it,
 * which is exactly what makes "which segments are free" a question worth
 * answering.
 */
export declare function vipBgMapSegmentUses(worlds: ReadonlyArray<VipWorld>): VipBgMapSegmentUse[];
export interface VipObject {
    index: number;
    /** Signed 10-bit screen position. */
    jx: number;
    /** Signed 14-bit parallax. */
    jp: number;
    /** Eight-bit screen position. */
    jy: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    lon: boolean;
    ron: boolean;
}
/** True when an object is drawn to at least one eye. */
export declare function isVipObjectVisible(object: VipObject): boolean;
/** Decode one 8-byte OAM entry. Bit layout per `object.h`. */
export declare function decodeVipObject(view: DataView, index: number, byteOffset?: number): VipObject;
/**
 * Inverse of decodeVipObject, for writing an edited object back to OAM.
 *
 * Returns the entry's four halfwords. The bits neither function accounts for —
 * the top six of JX, the top eight of JY, and bit 11 of the character halfword
 * — are written as zero rather than preserved, the same way encodeVipBgMapCell
 * treats its spare bit.
 */
export declare function encodeVipObject(object: VipObject): number[];
/**
 * How often each character is referenced by what the VIP is drawing.
 *
 * Two kinds of reference reach character memory: a BGMap cell naming a
 * character, and an object naming one. Counting both says which quarter of the
 * atlas a game is actually using at this moment, and — for one character —
 * where it is being used, which is otherwise a fact nothing in the debugger
 * can answer.
 *
 * Deliberately built from what is *drawn* rather than from everything in
 * memory. OAM's thousand entries are mostly parked ones pointing at character
 * 0, so counting objects that are shown to neither eye would mark character 0
 * as the busiest in the atlas and say nothing; likewise a BGMap segment no
 * world reads holds whatever the last scene left there. See
 * {@link vipCharacterUsage} for who decides which segments are worth scanning.
 */
export declare class VipCharacterUsage {
    /** Cells per character and segment, indexed segment * VIP_CHAR_COUNT + char. */
    protected readonly cells: Uint16Array<ArrayBuffer>;
    protected readonly objects: Uint16Array<ArrayBuffer>;
    protected readonly totals: Uint32Array<ArrayBuffer>;
    /**
     * Count one BGMap segment's cells. `bytes` is one segment, VIP_BGMAP_BYTES
     * long.
     *
     * `drawn` says whether a world being drawn maps from this segment. Cells
     * are counted either way — a segment nothing reads still says which
     * characters it was built out of — but only a drawn one makes a character
     * count as in use, since a map no world reads reaches no screen.
     */
    addBgMapSegment(segment: number, bytes: Uint8Array, drawn?: boolean): void;
    /** Count the objects OAM holds, skipping the ones drawn to neither eye. */
    addObjects(bytes: Uint8Array): void;
    /** Whether anything being drawn refers to this character. */
    used(char: number): boolean;
    /** How many of the objects being drawn use it. */
    objectCount(char: number): number;
    /** The BGMap segments whose cells name it, and how many cells each has. */
    bgMapCounts(char: number): {
        segment: number;
        cells: number;
    }[];
}
/**
 * Which characters of one segment differ between two reads of it.
 *
 * The indices are within the segment, so a caller watching all four adds the
 * segment's own offset. A read the same length as the last is assumed: the
 * segments are a fixed size, and a short one would say a character changed
 * because it was not read rather than because it moved.
 */
export declare function vipChangedCharacters(bytes: Uint8Array, previous: Uint8Array): number[];
/**
 * Cross-reference character memory against the BGMap segments and the objects
 * that are being drawn.
 *
 * `bgMapSegments` is indexed by segment number and sparse on purpose: a caller
 * reads the segments a drawn world actually maps from (see
 * {@link vipBgMapSegmentUses}) and leaves the rest undefined, both because
 * scanning fourteen segments a poll is a hundred kilobytes of reads for
 * nothing and because a segment nothing reads is not evidence that a character
 * is in use.
 */
export declare function vipCharacterUsage(bgMapSegments: ReadonlyArray<Uint8Array | undefined>, oam: Uint8Array | undefined, drawnSegments?: ReadonlyArray<boolean>): VipCharacterUsage;
/**
 * Paint one character into an RGBA buffer.
 *
 * `intensities` maps a two-bit pixel value to a gray level. Pixel value 0 is
 * drawn rather than skipped, because these views show what is in memory rather
 * than compositing a scene, and a transparent hole would be indistinguishable
 * from a black one.
 */
export declare function drawVipChar(target: Uint8ClampedArray, targetWidth: number, destX: number, destY: number, characters: VipCharacters, char: number, intensities: number[], hFlip?: boolean, vFlip?: boolean): void;
/**
 * Random access to the pixels of the map one world draws from.
 *
 * A world's source coordinates address a virtual map scx by scy segments
 * large, laid out left to right and top to bottom starting at the world's
 * base segment. Coordinates outside it either wrap — the map repeats, which
 * is what makes a 1x1 world a tiling background — or, with the overplane flag
 * set, read the single cell the world's OVR halfword names.
 *
 * Segments are indexed by their absolute BGMap segment number rather than by
 * position within the world, so a caller only has to have read the segments
 * the world actually spans; a segment that is missing reads as blank rather
 * than as an error, the same way VipCharacters treats character memory.
 */
export declare class VipWorldMap {
    protected readonly world: VipWorld;
    protected readonly segments: ReadonlyArray<Uint8Array | undefined>;
    protected readonly characters: VipCharacters;
    protected readonly width: number;
    protected readonly height: number;
    constructor(world: VipWorld, segments: ReadonlyArray<Uint8Array | undefined>, characters: VipCharacters);
    /**
     * The gray level of one source pixel, given one intensity ramp per palette.
     *
     * Returns an intensity rather than a palette index so that a caller
     * rasterizing a whole world does not allocate per pixel.
     */
    intensity(x: number, y: number, palettes: number[][]): number;
    /**
     * The character one source pixel comes from, or undefined outside a map
     * that does not wrap onto an overplane cell.
     *
     * Wraps exactly as {@link intensity} does, since it is the same lookup
     * stopping one step earlier: what a view marking every pixel drawn from a
     * particular character needs is the cell's character, not its shade.
     */
    char(x: number, y: number): number;
    /**
     * Which BGMap segment one source pixel is read out of.
     *
     * The same lookup {@link intensity} does, stopping before the cell: what
     * a view marking the part of a world that comes from one segment needs is
     * where the pixel was read, not what was there.
     */
    segmentAt(x: number, y: number): number;
    /** The raw cell halfword covering a wrapped source pixel, or 0 if unread. */
    protected cellAt(wx: number, wy: number): number;
}
/**
 * Where on screen a world lands for one eye.
 *
 * The size is the register values plus one, since the hardware reads W and H
 * as size minus one, and the position is shifted by the parallax: the left eye
 * to the left of the world's own GX, the right eye to the right of it.
 */
export declare function vipWorldExtents(world: VipWorld, eye: VipEye): {
    x: number;
    y: number;
    width: number;
    height: number;
};
/**
 * Where a world reads from one BGMap segment, in that segment's own pixels,
 * or undefined for a segment the world's map does not cover.
 *
 * A world's source coordinates are in its own map, which is scx segments
 * across and scy down, laid out from its base segment left to right and then
 * top to bottom; this shifts them into the one segment being looked at. The
 * rectangle may well reach past that segment's edges — a map is a window
 * onto a larger one — so a view drawing it has to clip.
 *
 * Parallax is left out: MP moves the read area by an eye's worth of pixels,
 * and a segment is looked at without an eye.
 */
export declare function vipWorldSourceExtents(world: VipWorld, segment: number): {
    x: number;
    y: number;
    width: number;
    height: number;
} | undefined;
/**
 * Paint what one world alone puts on the screen, for one eye.
 *
 * This is the world's own contribution rather than a frame: nothing here
 * composites the worlds drawn before it, and pixel value 0 is painted black
 * rather than left transparent, so what shows is exactly the area the world
 * covers.
 *
 * `params` is the world's param table, needed by the H-bias and Affine modes
 * and ignored by the others; rows it does not reach are drawn unshifted and
 * untransformed rather than skipped. An Object world draws nothing at all,
 * since what it puts on screen lives in OAM rather than in any map of its own.
 */
/**
 * Walk the pixels one world draws, handing each the source coordinate it is
 * read from.
 *
 * Every property that decides *where* a pixel comes from is applied here —
 * the world's size (W and H are sizes minus one, hence the inclusive bounds),
 * its position, its parallax, and the per-row source origin an H-bias or
 * Affine world takes from its param table — so that a caller only has to say
 * what to do with a pixel once it knows where it came from. Both drawing a
 * world and marking where a character lands in one are that same walk.
 *
 * Pixels outside the target are skipped rather than wrapped: a world can sit
 * partly, or wholly, off the screen. An Object world draws nothing here at
 * all; its sprites come from OAM.
 */
export declare function forEachVipWorldPixel(world: VipWorld, targetWidth: number, targetHeight: number, eye: VipEye, params: DataView | undefined, visit: (destX: number, destY: number, sourceX: number, sourceY: number) => void): void;
/** Paint one world into an RGBA buffer, shaded by its palettes. */
export declare function drawVipWorld(target: Uint8ClampedArray, targetWidth: number, targetHeight: number, world: VipWorld, map: VipWorldMap, palettes: number[][], eye: VipEye, params?: DataView): void;
/**
 * Visit every pixel one object puts on screen, with the value it draws there.
 *
 * The counterpart of {@link forEachVipWorldPixel}, and there for the same
 * reason: a view compositing several objects has to decide for itself what a
 * pixel value means — whether value 0 is a hole to leave alone, whether the
 * object is the one being looked at — which a routine that only writes shades
 * cannot be told.
 */
export declare function forEachVipObjectPixel(object: VipObject, targetWidth: number, targetHeight: number, characters: VipCharacters, eye: VipEye, visit: (destX: number, destY: number, value: number) => void): void;
/** Paint one object into an RGBA buffer, shaded by its palette. */
export declare function drawVipObject(target: Uint8ClampedArray, targetWidth: number, targetHeight: number, object: VipObject, characters: VipCharacters, intensities: number[], eye: VipEye): void;
/** Whether two buffers hold the same bytes, treating absent as different. */
export declare function sameVipBytes(a: Uint8Array | undefined, b: Uint8Array | undefined): boolean;
//# sourceMappingURL=emulator-vip-memory.d.ts.map