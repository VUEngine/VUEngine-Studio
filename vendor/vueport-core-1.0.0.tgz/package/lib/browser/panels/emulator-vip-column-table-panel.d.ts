import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
type Eye = 0 | 1;
type Field = 'length' | 'repeat';
/**
 * The column table: how long the display unit lights each group of 4 columns, and how often it pulses them. Edits go
 * straight into VIP memory, so a game that loads its table once keeps them, one writing it every frame does not.
 * Which 96 of the 256 entries an eye uses is up to the servo; CTA says where it starts and the display reads
 * downwards from there, the first entry for the leftmost 4 columns (see vb-column-geometry.ts for positions).
 */
export declare class ColumnTablePanel extends Panel {
    protected tables?: Uint16Array[];
    protected start: [number, number];
    protected error?: string;
    protected eye: Eye;
    protected field: Field;
    protected bothEyes: boolean;
    protected pending: Map<number, number>;
    protected drawing?: {
        last: number;
    };
    protected editing?: number;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected entry(eye: Eye, index: number): number;
    protected fieldOf(word: number, field: Field): number;
    protected withField(word: number, field: Field, value: number): number;
    protected targets(): Eye[];
    protected write(eyes: Eye[], words: Map<number, number>): void;
    protected setField(values: Map<number, number>): void;
    protected restoreDefaults(): void;
    protected copyToOtherEye(): void;
    protected chartPoint(event: React.PointerEvent<SVGSVGElement>): {
        index: number;
        value: number;
    };
    protected strokeTo(index: number, value: number): void;
    protected renderChart(): React.ReactNode;
    protected windowLengths(eye: Eye): number[];
    protected renderPositions(): React.ReactNode;
    protected renderGrid(): React.ReactNode;
    protected renderSummary(eye: Eye): React.ReactNode;
    protected render(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-column-table-panel.d.ts.map