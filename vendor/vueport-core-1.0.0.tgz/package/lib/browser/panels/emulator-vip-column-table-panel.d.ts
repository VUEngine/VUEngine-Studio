import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
type Eye = 0 | 1;
type Field = 'length' | 'repeat';
/**
 * The column table: how long the display unit lights each group of 4
 * columns, and how many times it pulses them.
 *
 * A chart to draw on, the columns' positions on screen as the mirror puts
 * them, and the raw halfwords to type into. Edits go straight into VIP memory,
 * so a game that loads its table once keeps them; one that writes it every
 * frame does not.
 *
 * Which 96 of the 256 entries an eye uses is up to the servo, and CTA says
 * where it starts: the display reads from there downwards, the first entry
 * for the leftmost 4 columns. That window is what the chart marks and the
 * position strip is drawn from — see `vb-column-geometry.ts` for how the
 * lengths become positions.
 */
export declare class ColumnTablePanel extends Panel {
    protected tables?: Uint16Array[];
    protected start: [number, number];
    protected error?: string;
    protected eye: Eye;
    protected field: Field;
    protected bothEyes: boolean;
    /** Values written but perhaps not yet read back, so a poll in between does not snap them away. */
    protected pending: Map<number, number>;
    protected drawing?: {
        last: number;
    };
    /** The entry whose cell in the table has focus, marked in the chart. */
    protected editing?: number;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    /** An entry as shown: what was last written to it, or what was read. */
    protected entry(eye: Eye, index: number): number;
    protected fieldOf(word: number, field: Field): number;
    protected withField(word: number, field: Field, value: number): number;
    /** The eyes an edit lands in. */
    protected targets(): Eye[];
    /** Write whole halfwords, entry index to value, into the eyes edits go to. */
    protected write(eyes: Eye[], words: Map<number, number>): void;
    /** Set one field of a run of entries to values, keeping the other byte of each eye's own word. */
    protected setField(values: Map<number, number>): void;
    protected restoreDefaults(): void;
    protected copyToOtherEye(): void;
    /** Entry and value under a pointer on the chart. */
    protected chartPoint(event: React.PointerEvent<SVGSVGElement>): {
        index: number;
        value: number;
    };
    /** Draw from the last point to this one, every entry in between on the line. */
    protected strokeTo(index: number, value: number): void;
    protected renderChart(): React.ReactNode;
    /** The lengths an eye's display reads, leftmost group first. */
    protected windowLengths(eye: Eye): number[];
    /**
     * Where each group of 4 columns begins on the screen's 384 pixels, as the
     * mirror puts it: Nintendo's table spaces them evenly, a longer entry
     * leaves a wider gap, a shorter one a narrower.
     */
    protected renderPositions(): React.ReactNode;
    protected renderGrid(): React.ReactNode;
    protected renderSummary(eye: Eye): React.ReactNode;
    protected render(): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-column-table-panel.d.ts.map