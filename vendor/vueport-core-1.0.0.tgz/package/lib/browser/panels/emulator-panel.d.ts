import { Disposable } from '../../common/emulator-events';
import { VueportReactWidget } from '../emulator-widget-base';
import { Message } from '@lumino/messaging';
import { Sim } from '../core/vb-core';
import { VesBreakpoints } from '../core/emulator-breakpoints';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { VesScreenRect } from './emulator-screen-panel';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { VbPixelSource } from '../../common/vb-pixel-origin';
import { RomHeader } from '../emulator-types';
export declare enum EmulatorPanelType {
    ACTORS = "actors",
    DISASSEMBLY = "disassembly",
    ES_SOUND = "esSound",
    MEMORY = "memory",
    PROFILER = "profiler",
    MEMORY_POOLS = "memoryPools",
    REGISTERS = "registers",
    ROM_INFO = "romInfo",
    RUMBLE_PACK = "rumblePack",
    SCREEN = "screen",
    SRAM = "sram",
    TERMINAL = "terminal",
    VIP_BGMAPS = "vipBgMaps",
    VIP_CHARACTERS = "vipCharacters",
    VIP_COLUMN_TABLE = "vipColumnTable",
    VIP_FRAME_BUFFERS = "vipFrameBuffers",
    VIP_OBJECTS = "vipObjects",
    VIP_PALETTES = "vipPalettes",
    VIP_WORLDS = "vipWorlds",
    VCU = "vcu",
    VSU = "vsu"
}
export declare function emulatorPanelLabel(type: EmulatorPanelType): string;
export declare const EMULATOR_PANEL_TYPES: EmulatorPanelType[];
export type InspectedSeat = 'own' | 'peer';
export interface DebugSource {
    readonly sim: Sim | undefined;
    readonly inspecting: InspectedSeat;
    readonly hasPeerSim: boolean;
    readonly vbcSupportEnabled: boolean;
    readonly vbcHardwareActive: boolean;
    readonly romHeader: RomHeader;
    readonly romSize: number;
    readonly romChecksum: string | undefined;
    readonly buildMode: string | undefined;
    onDidChange(listener: () => void): Disposable;
    getSymbols(): Promise<SymbolIndex | undefined>;
    getLineTable(): Promise<VesLineTable | undefined>;
    readonly breakpoints: VesBreakpoints;
    readSource(path: string): Promise<string | undefined>;
    /**
     * Marks rectangles on the picture in the VB's screen space, or clears them with an empty list (the Actors panel's
     * selection). Drawn over the picture, so it cannot affect the machine; the screen inspector's switch decides whether
     * they show. A panel that sets these owns them and has to clear them when it stops describing the selection,
     * including when hidden or closed.
     */
    setHighlights(rects: VesScreenRect[]): void;
    highlightSource(source: VbPixelSource | undefined): void;
    reveal(target: ScreenInspectorTarget): void;
    write(address: number, bytes: number[]): Promise<void>;
    panelPreference<T extends string | number | boolean>(kind: EmulatorPanelType, key: string, fallback: T): T;
    setPanelPreference(kind: EmulatorPanelType, key: string, value: string | number | boolean): void;
}
export declare abstract class Panel extends VueportReactWidget {
    readonly kind: EmulatorPanelType;
    protected readonly source: DebugSource;
    protected static readonly POLL_HZ = 10;
    protected pollHz(): number;
    protected pollTimer?: number;
    constructor(kind: EmulatorPanelType, source: DebugSource, instanceId: string);
    protected remembered(key: string, fallback: boolean): boolean;
    protected remembered(key: string, fallback: number): number;
    protected remembered(key: string, fallback: string): string;
    protected remember(key: string, value: boolean): boolean;
    protected remember(key: string, value: number): number;
    protected remember(key: string, value: string): string;
    protected onAfterShow(msg: Message): void;
    protected onAfterAttach(msg: Message): void;
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected lit?: string;
    protected light(source: VbPixelSource | undefined): void;
    reveal(target: ScreenInspectorTarget): void;
    /**
     * This node (.emulator-panel) is where overflow: auto lives for most panels. React cannot always match rows keyed by
     * something that changes under polling (a filter), and removing the node under the scrollbar makes the browser reset
     * scrollTop; ten times a second that reads as scrolling not working. So it is saved and restored around the render.
     * Written only when it moved: any programmatic scroll, even to where it already is, stops a smooth scroll running
     * anywhere on the page in Chrome, so a jump from the screen inspector moved a step and stopped.
     */
    protected onUpdateRequest(msg: Message): void;
    protected startPolling(): void;
    protected poll(): void;
    protected restartPolling(): void;
    protected stopPolling(): void;
    protected abstract refresh(): void | Promise<void>;
    dispose(): void;
}
/**
 * Whether the control the key went to wants the arrow keys itself. Panels walking their contents with the arrows read
 * them on the outer node and ask this first. Text inputs, sliders, listboxes and anything in the tab order on its own
 * (segmented pickers, a second scrolling region) say yes. `root` is the node reading the event.
 */
export declare function arrowKeysTaken(target: EventTarget | null, root: EventTarget | null): boolean;
/**
 * scrollIntoView, smoothly, for the jumps the screen inspector makes. Not scrollIntoView({ behavior: 'smooth' }): Chrome
 * runs that as one sequence across every scroller, which any programmatic scroll on the page stops, and the polling
 * panels make those (a terminal following its log, the memory view following its address). So it is scrollTo on the
 * nearest scroller alone, the element's scroll-margin honoured as scrollIntoView would.
 */
export declare function scrollIntoViewSmoothly(element: Element, block?: 'nearest' | 'center', inline?: 'nearest' | 'center'): void;
export declare function hex(value: number, digits: number): string;
//# sourceMappingURL=emulator-panel.d.ts.map