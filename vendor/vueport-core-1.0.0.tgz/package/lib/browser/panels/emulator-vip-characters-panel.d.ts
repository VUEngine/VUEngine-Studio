import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
import { VipCharacters, VipCharacterUsage, VipWorld, VipWorldMap } from './emulator-vip-memory';
import { Sim } from '../core/vb-core';
/**
 * Which characters the atlas draws.
 *
 * `used` and `changed` blank the rest rather than closing the gaps they leave:
 * where a character sits in the sheet is its index, and a filter that reflowed
 * the grid would answer "which characters are these" with a different number
 * every time something moved.
 */
type CharacterFilter = 'all' | 'used' | 'changed';
/** How a character is shaded in the atlas. See {@link CharactersPanel#shadingFor}. */
interface CharacterShading {
    intensities: number[];
    /** Whether to take the color out of it once it is drawn. */
    gray?: boolean;
}
/** One line of Used by: who uses the character, how often, and their map. */
interface MapPreview {
    key: string;
    label: string;
    note?: string;
    cells: number;
    image?: ImageData;
}
/**
 * Every character currently in VRAM, laid out as one atlas, with a sidebar
 * for inspecting one character at a time.
 *
 * Reads all four character segments each refresh and re-rasterizes only when
 * the pixels — or what the panel knows about them — actually changed, so a
 * paused emulator costs its reads per poll and no drawing at all.
 *
 * Alongside the pixels it cross-references what refers to them: the cells of
 * the BGMap segments the drawn worlds map from, and the objects OAM has
 * switched on. That is what "Used by" in the sidebar answers and what the In
 * use filter keeps — the atlas otherwise shows a thousand characters with no
 * hint of which quarter of it the game is actually using. Only what is being
 * drawn is counted; see {@link VipCharacterUsage}.
 */
export declare class CharactersPanel extends Panel {
    /**
     * How a finished PNG reaches the person, from the host that knows
     * where files go — a download in the browser, a file in the project
     * in VES. Left out by a host that cannot take one, and then the panel
     * simply has no Export button.
     */
    protected readonly exportFile?: ((name: string, data: Uint8Array) => Promise<void>) | undefined;
    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[];
    /**
     * The whole of BGMap memory, as one buffer.
     *
     * One rather than fourteen because the param tables an H-bias or Affine
     * world reads live in it too, at an address rather than in a segment —
     * see {@link paramsFor}, which hands one out as a view over these bytes.
     */
    protected bgMapBytes?: Uint8Array;
    /** The same bytes, cut into segments: views, not copies. */
    protected bgMapSegments: (Uint8Array | undefined)[];
    protected oamBytes?: Uint8Array;
    protected usage?: VipCharacterUsage;
    /**
     * When each character's pixels were last seen to change, as a
     * `performance.now()` reading; 0 for one that has not changed since the
     * panel was opened. See {@link CHANGED_MS}.
     */
    protected readonly changedAt: Float64Array<ArrayBuffer>;
    protected charsPerRow: number;
    protected zoom: number;
    protected showGrid: boolean;
    protected showSegments: boolean;
    protected filter: CharacterFilter;
    protected selected: number;
    protected image?: ImageData;
    /** The same pixels as {@link image}, cut into the four segments. */
    protected segmentImages: ImageData[];
    /** The worlds the VIP is drawing, which Used by attributes its cells to. */
    protected worlds: VipWorld[];
    /** Their attribute memory, to notice when one of them moves. */
    protected worldBytes?: Uint8Array;
    /** Which BGMap segments those worlds map from. */
    protected drawnSegments: boolean[];
    /** What Used by shows for the selected character. See {@link buildMapPreviews}. */
    protected mapPreviews: MapPreview[];
    /** Cleared whenever character memory moves; see {@link characterAverages}. */
    protected averages?: Uint8Array;
    /** Which characters the drawn worlds show. See {@link markDrawnCharacters}. */
    protected drawnChars?: Uint8Array;
    protected dirty: boolean;
    constructor(source: DebugSource, instanceId: string, 
    /**
     * How a finished PNG reaches the person, from the host that knows
     * where files go — a download in the browser, a file in the project
     * in VES. Left out by a host that cannot take one, and then the panel
     * simply has no Export button.
     */
    exportFile?: ((name: string, data: Uint8Array) => Promise<void>) | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /** The four character segments, and which characters of them moved. */
    protected readCharacters(sim: Sim): Promise<void>;
    /** Timestamp the characters of one segment whose bytes are not what they were. */
    protected markChanged(segment: number, bytes: Uint8Array, previous: Uint8Array, now: number): void;
    /**
     * What currently refers to character memory: the cells of the BGMap
     * segments the drawn worlds map from, and OAM.
     *
     * The segments are chosen rather than all fourteen read, both because a
     * hundred kilobytes of reads a poll is a lot to pay for something nothing
     * is drawing and because a segment no world maps from holds whatever the
     * last scene left in it, which is not evidence of anything.
     */
    protected readReferences(sim: Sim): Promise<void>;
    /**
     * The remembered column count, held to the three the slider offers: it is
     * stored as the width rather than as a slider position, and a width that
     * is no longer on offer would leave the slider with no step to sit on.
     */
    protected rememberedCharsPerRow(): number;
    /** The remembered filter, or All for a stored value that is no longer one. */
    protected rememberedFilter(): CharacterFilter;
    protected setCharsPerRow(charsPerRow: number): void;
    protected setFilter(filter: CharacterFilter): void;
    protected selectCharacter(char: number): void;
    /** Whether the current filter keeps a character. */
    protected shown(char: number, now: number): boolean;
    /**
     * How one character is shaded in the atlas: as it is, or ghosted.
     *
     * Two states rather than three. Fading the characters nothing refers to
     * while showing all of them is the same statement the In use filter makes,
     * only quieter, and saying it in two places left the sheet with two kinds
     * of gray to tell apart. What is in use is the filter's question now.
     */
    protected shadingFor(char: number, now: number): CharacterShading;
    protected rasterize(): void;
    /** The whole of character memory as one bitmap, shaded by `shadingFor`. */
    protected drawAtlas(shadingFor: (char: number) => CharacterShading): ImageData | undefined;
    /**
     * A thumbnail per BGMap segment whose cells name the selected character:
     * the map one pixel to the cell, with those cells picked out.
     *
     * A count on its own says a character is used forty times and leaves where
     * as the question — and where, in a map, is a shape: the letters of a line
     * of text, the bricks along a floor. At this size the map is a silhouette
     * rather than a picture, which is enough to recognize what part of the
     * screen is being looked at and to see the marks against it.
     */
    protected buildMapPreviews(): void;
    /**
     * Which characters the drawn worlds actually show, and the objects' too.
     *
     * The In use filter's answer. It has to be the same walk the Used by rows
     * are counted from, or the two disagree about the same character: a map
     * being read is not the same as every cell of it being drawn, and a
     * character sitting in a corner of a map the world never scrolls to is
     * not in use by any reading of the word.
     */
    protected markDrawnCharacters(): void;
    /**
     * Walk the cells one world draws, once each, with the segment each came
     * from.
     *
     * The walk is over pixels, because only the pixels know where they come
     * from once a param table is shifting each row of them — but a cell is
     * eight pixels across, so the lookup only happens where the run of pixels
     * moves into a new cell, and a set keeps a cell the world draws twice from
     * being counted twice.
     */
    protected eachDrawnCell(world: VipWorld, map: VipWorldMap, visit: (char: number, segment: number) => void): void;
    /**
     * One BGMap segment, a pixel to the cell.
     *
     * A whole map rather than a window, because a segment no world reads has
     * no window: there is nothing drawing it to say which part of it matters.
     */
    protected drawSegmentPreview(segment: number): ImageData | undefined;
    /**
     * One world as it is actually drawn, with the pixels that come from the
     * selected character picked out.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one — so the map on its own would answer "where is this
     * character" with a picture of somewhere the world never looks. Every
     * property that decides where a pixel comes from is applied by
     * {@link forEachVipWorldPixel}; the only ones dropped here are the three
     * that place the finished rectangle on the screen (GX, GY, GP), since the
     * preview is the rectangle.
     */
    protected drawWorldPreview(world: VipWorld): ImageData | undefined;
    /**
     * The param table one world reads, as a view over BGMap memory.
     *
     * The tables live in the same region as the maps do, so the read that
     * fetched the segments has already fetched these; a world whose table
     * runs past the end of the region gets none rather than a short one,
     * which the drawing treats as a world with no per-row shift at all.
     */
    protected paramsFor(world: VipWorld): DataView | undefined;
    /**
     * A grid of cells as a bitmap, one pixel each: the character's average
     * brightness, or white where it is the selected one.
     *
     * At this size a map is a silhouette rather than a picture, which is
     * enough to recognize which part of the screen is being looked at and to
     * see the marks against it.
     */
    protected drawCells(width: number, height: number, averages: Uint8Array, charAt: (x: number, y: number) => number | undefined): ImageData;
    /**
     * How bright each character is on average, which is what a cell comes out
     * as when a whole map is drawn one pixel to the cell.
     *
     * Built once per read of character memory rather than per thumbnail: a
     * segment has four thousand cells and a character sixty-four pixels, so
     * doing it the other way round is the same sixty-four lookups over and
     * over for every cell that happens to name the same character.
     */
    protected characterAverages(): Uint8Array;
    /**
     * The atlas cut into its four character segments.
     *
     * Views onto the same pixels rather than four more buffers: a segment is
     * a whole number of rows of the sheet whatever the column count, so each
     * one's rows are already contiguous.
     */
    protected sliceSegments(image: ImageData): ImageData[];
    /** Just the selected character, for the sidebar preview. */
    protected rasterizePreview(characters: VipCharacters, char: number): ImageData;
    /**
     * Write the sheet out as a PNG, at one screen pixel per source pixel.
     *
     * Neither filtered nor dimmed, and without the grid: this is the file
     * somebody lines up against the source art they built the characters
     * from, and the viewing aids would be in the way of that.
     */
    protected exportPng(): Promise<void>;
    protected render(): React.ReactNode;
    /**
     * The character being inspected: its pixels first, then where it lives.
     *
     * A group like the two under it, rather than the bare block it started
     * as: three things in a sidebar that are each a heading and a list of
     * facts should look like three of the same thing.
     */
    protected renderSelected(): React.ReactNode;
    /**
     * Who refers to the selected character right now, and only to it.
     *
     * Reads as a list of places rather than a count, because the useful
     * question about a character in an atlas is which map or how many sprites
     * it turned up in, not how many references exist in total — and each map
     * comes with a thumbnail of itself, marked where those cells are.
     */
    protected renderUsedBy(): React.ReactNode;
    protected renderDisplayGroup(): React.ReactNode;
    /**
     * One of the Display group's settings, as a switch.
     *
     * A switch rather than a checkbox because these take effect the moment
     * they are thrown — see the kit component, and the SRAM panel's toggles,
     * which are laid out the same way: the control, then the name beside it.
     */
    protected renderToggle(label: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    /**
     * Walk the sheet with the keyboard: a character at a time, a row at a
     * time, a segment at a time, or to either end of it.
     *
     * The event is stopped rather than only defaulted, because the emulator
     * listens for keys on the node this panel sits inside and would otherwise
     * read an arrow as the D-pad and move the game while the sheet is being
     * read. Anything this does not handle is left alone and carries on to it.
     */
    /** The sheet's own arrow keys, from anywhere in the panel. */
    protected onPanelKey(event: React.KeyboardEvent): void;
    protected onAtlasKey(event: React.KeyboardEvent): void;
    /**
     * Scroll the selection back into view after the keyboard moved it.
     *
     * After the next frame rather than now: the selection is drawn by the
     * render this has just asked for, and the element to scroll to does not
     * exist until that has happened.
     */
    protected revealSelection(): void;
    /** The sheet: one canvas, or one per segment under its own heading. */
    protected renderAtlas(): React.ReactNode;
    /**
     * One canvas of the sheet, whose top-left character is `first`.
     *
     * Split or not, a canvas only knows the range it draws, so both the
     * selection outline and a click are in its own coordinates and offset by
     * that first index on the way in and out.
     */
    protected renderCanvas(image: ImageData, first: number): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-characters-panel.d.ts.map