import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { VbcState } from './emulator-vcu-memory';
import { VcuColors } from './emulator-vcu-colors';
import { VipCharacters, VipCharacterUsage, VipWorld, VipWorldMap } from './emulator-vip-memory';
import { Sim } from '../core/vb-core';
type CharacterFilter = 'all' | 'used' | 'changed';
interface CharacterShading {
    intensities: number[];
    gray?: boolean;
}
interface MapPreview {
    key: string;
    label: string;
    note?: string;
    cells: number;
    image?: ImageData;
}
/**
 * Every character in VRAM as one atlas, with a sidebar inspecting one at a time. Reads the four character segments
 * each refresh (eight with CHRCTRL.CHREXT on a VB Color) and re-rasterizes only on change, so a paused emulator costs
 * reads and no drawing. Cross-references the BGMap cells of the drawn worlds' segments and the objects OAM switched
 * on, for Used by and the In use filter; only what is drawn counts, see VipCharacterUsage
 */
export declare class CharactersPanel extends Panel {
    protected readonly exportFile?: VipExportFile | undefined;
    protected error?: string;
    protected registers?: DataView;
    protected vbc?: VbcState;
    protected segmentCount: number;
    protected charSegments: (Uint8Array | undefined)[];
    protected charColorAttrs?: Uint8Array;
    protected charPixelAttrs?: Uint8Array;
    protected bgMapBytes?: Uint8Array;
    protected bgMapSegments: (Uint8Array | undefined)[];
    protected oamBytes?: Uint8Array;
    protected usage?: VipCharacterUsage;
    protected readonly changedAt: Float64Array<ArrayBuffer>;
    protected charsPerRow: number;
    protected zoom: number;
    protected showGrid: boolean;
    protected showSegments: boolean;
    protected filter: CharacterFilter;
    protected vbColorPreview: boolean;
    protected selected: number;
    protected colors?: VcuColors;
    protected image?: ImageData;
    protected segmentImages: ImageData[];
    protected worlds: VipWorld[];
    protected worldBytes?: Uint8Array;
    protected drawnSegments: boolean[];
    protected mapPreviews: MapPreview[];
    protected averages?: Uint8Array;
    protected drawnChars?: Uint8Array;
    protected dirty: boolean;
    constructor(source: DebugSource, instanceId: string, exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected readCharacters(sim: Sim): Promise<void>;
    protected resizeCharacters(count: number): void;
    protected get charCount(): number;
    protected readColorAttributes(sim: Sim): Promise<void>;
    protected readColors(sim: Sim): Promise<void>;
    protected markChanged(segment: number, bytes: Uint8Array, previous: Uint8Array, now: number): void;
    protected readReferences(sim: Sim): Promise<void>;
    protected rememberedCharsPerRow(): number;
    protected rememberedFilter(): CharacterFilter;
    protected setCharsPerRow(charsPerRow: number): void;
    protected setVbColorPreview(on: boolean): void;
    protected setFilter(filter: CharacterFilter): void;
    reveal(target: ScreenInspectorTarget): void;
    protected selectCharacter(char: number): void;
    protected shown(char: number, now: number): boolean;
    protected shadingFor(char: number, now: number): CharacterShading;
    protected rasterize(): void;
    protected drawAtlas(shadingFor: (char: number) => CharacterShading): ImageData | undefined;
    protected buildMapPreviews(): void;
    protected markDrawnCharacters(): void;
    protected eachDrawnCell(world: VipWorld, map: VipWorldMap, visit: (char: number, segment: number) => void): void;
    protected drawSegmentPreview(segment: number): ImageData | undefined;
    /**
     * One world as drawn, with the selected character's pixels picked out. Its own W+1 by H+1 window onto its map from
     * MX/MY, shifted per row by its param table, as the map alone would show somewhere the world never looks.
     * Everything deciding where a pixel comes from is applied by forEachVipWorldPixel; only GX, GY and GP are dropped
     */
    protected drawWorldPreview(world: VipWorld): ImageData | undefined;
    protected paramsFor(world: VipWorld): DataView | undefined;
    protected drawCells(width: number, height: number, averages: Uint8Array, charAt: (x: number, y: number) => number | undefined): ImageData;
    protected characterAverages(): Uint8Array;
    protected sliceSegments(image: ImageData): ImageData[];
    protected rasterizePreview(characters: VipCharacters, char: number): ImageData;
    protected exportPng(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderSelected(): React.ReactNode;
    /**
     * The selected character's VB Color attributes: palette groups and Pixel Color Attribute. Only while the VCU is
     * active, and a group of its own, as none of it applies by itself: a cell or object only uses these with CHRSEL in
     * its Color Attribute and CXCTRL.CCEN set. When CCEN is off the group says so rather than going away, as games set
     * these up before switching them on, exactly when somebody wants to check them
     */
    protected renderCharacterColor(): React.ReactNode;
    protected writeColorAttr(offset: number, value: number): void;
    protected writePixelAttr(value: number): void;
    protected writeVcu(address: number, bytes: number[]): void;
    protected renderUsedBy(): React.ReactNode;
    protected renderDisplayGroup(): React.ReactNode;
    protected renderToggle(label: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    protected onPanelKey(event: React.KeyboardEvent): void;
    protected onAtlasKey(event: React.KeyboardEvent): void;
    protected revealSelection(): void;
    protected renderAtlas(): React.ReactNode;
    protected renderCanvas(image: ImageData, first: number): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-characters-panel.d.ts.map