import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DebugSource, Panel } from './emulator-panel';
import { VipExportFile } from './emulator-vip-canvas';
import { VbcState } from './emulator-vcu-memory';
import { VcuColors } from './emulator-vcu-colors';
import { VipCharacters, VipCharacterUsage, VipWorld, VipWorldMap } from './emulator-vip-memory';
import { Sim } from '../core/vb-core';
/**
 * Which characters the atlas draws.
 *
 * `used` and `changed` blank the rest rather than closing the gaps they leave:
 * where a character sits in the sheet is its index, and a filter that reflowed
 * the grid would answer "which characters are these" with a different number
 * every time something moved.
 */
type CharacterFilter = 'all' | 'used' | 'changed';
/** How a character is shaded in the atlas. See {@link CharactersPanel#shadingFor}. */
interface CharacterShading {
    intensities: number[];
    /** Whether to take the color out of it once it is drawn. */
    gray?: boolean;
}
/** One line of Used by: who uses the character, how often, and their map. */
interface MapPreview {
    key: string;
    label: string;
    note?: string;
    cells: number;
    image?: ImageData;
}
/**
 * Every character currently in VRAM, laid out as one atlas, with a sidebar
 * for inspecting one character at a time.
 *
 * Reads all four character segments each refresh — eight, on a VB Color
 * whose game has switched on CHRCTRL.CHREXT — and re-rasterizes only when
 * the pixels — or what the panel knows about them — actually changed, so a
 * paused emulator costs its reads per poll and no drawing at all.
 *
 * Alongside the pixels it cross-references what refers to them: the cells of
 * the BGMap segments the drawn worlds map from, and the objects OAM has
 * switched on. That is what "Used by" in the sidebar answers and what the In
 * use filter keeps — the atlas otherwise shows a thousand characters with no
 * hint of which quarter of it the game is actually using. Only what is being
 * drawn is counted; see {@link VipCharacterUsage}.
 */
export declare class CharactersPanel extends Panel {
    protected readonly exportFile?: VipExportFile | undefined;
    protected error?: string;
    protected registers?: DataView;
    /**
     * Only while a VB Color game has unlocked the VCU; see `readVbcState`.
     * Every VB Color thing the panel shows goes by this, so without it the
     * panel is the plain VIP one.
     */
    protected vbc?: VbcState;
    /**
     * How many character segments there are: four, or eight while CHREXT
     * makes the VCU's Character RAM Extension reachable. Everything that
     * runs over "every character" — the sheet, the selection, the keys —
     * goes by this rather than by the VIP's 2048.
     */
    protected segmentCount: number;
    protected charSegments: (Uint8Array | undefined)[];
    /**
     * The VCU's Character Color Attribute and Character Pixel Color Attribute
     * RAM, both indexed two bytes to the Character. Read only while
     * {@link vbc} is there, and only for the sidebar: neither changes how the
     * sheet is drawn, which stays in the hardware's red.
     */
    protected charColorAttrs?: Uint8Array;
    protected charPixelAttrs?: Uint8Array;
    /**
     * The whole of BGMap memory, as one buffer.
     *
     * One rather than fourteen because the param tables an H-bias or Affine
     * world reads live in it too, at an address rather than in a segment —
     * see {@link paramsFor}, which hands one out as a view over these bytes.
     */
    protected bgMapBytes?: Uint8Array;
    /** The same bytes, cut into segments: views, not copies. */
    protected bgMapSegments: (Uint8Array | undefined)[];
    protected oamBytes?: Uint8Array;
    protected usage?: VipCharacterUsage;
    /**
     * When each character's pixels were last seen to change, as a
     * `performance.now()` reading; 0 for one that has not changed since the
     * panel was opened. See {@link CHANGED_MS}. Sized for the extension
     * whether or not it is on, since it is only timestamps.
     */
    protected readonly changedAt: Float64Array<ArrayBuffer>;
    protected charsPerRow: number;
    protected zoom: number;
    protected showGrid: boolean;
    protected showSegments: boolean;
    protected filter: CharacterFilter;
    /**
     * Whether to draw in the colors a VB Color shows rather than the VIP's
     * red. On unless turned off, so a color game is seen in color; it only
     * has a say while {@link vbc} is there — see {@link colors}.
     */
    protected vbColorPreview: boolean;
    protected selected: number;
    /**
     * The VCU's color tables, while the previews are drawn in color: only
     * there with {@link vbc} and {@link vbColorPreview} both, so every
     * drawing routine can go by this alone and draws exactly as it did
     * without a VB Color when it is not.
     */
    protected colors?: VcuColors;
    protected image?: ImageData;
    /** The same pixels as {@link image}, cut into the four segments. */
    protected segmentImages: ImageData[];
    /** The worlds the VIP is drawing, which Used by attributes its cells to. */
    protected worlds: VipWorld[];
    /** Their attribute memory, to notice when one of them moves. */
    protected worldBytes?: Uint8Array;
    /** Which BGMap segments those worlds map from. */
    protected drawnSegments: boolean[];
    /** What Used by shows for the selected character. See {@link buildMapPreviews}. */
    protected mapPreviews: MapPreview[];
    /** Cleared whenever character memory moves; see {@link characterAverages}. */
    protected averages?: Uint8Array;
    /** Which characters the drawn worlds show. See {@link markDrawnCharacters}. */
    protected drawnChars?: Uint8Array;
    protected dirty: boolean;
    constructor(source: DebugSource, instanceId: string, exportFile?: VipExportFile | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /**
     * The character segments, and which characters of them moved: the VIP's
     * four, and with CHREXT the extension's four after them as segments 4-7.
     */
    protected readCharacters(sim: Sim): Promise<void>;
    /**
     * Follow CHREXT being switched on or off.
     *
     * The extension's segments are dropped rather than kept for later: what
     * reads them goes by how many it is handed — `VipCharacters` reads cells
     * with twelve bits when it has eight — and a character no cell can reach
     * any more is not one the sheet should go on offering. Usage is counted
     * again with the new mask, and a selection past the end is pulled back.
     */
    protected resizeCharacters(count: number): void;
    /** How many characters there are; see {@link segmentCount}. */
    protected get charCount(): number;
    /**
     * Every Character's two VB Color attribute entries, for the sidebar's
     * Character Color group.
     *
     * Not compared or kept for change marking like the characters are: they
     * only feed the sidebar's fields, which are rendered on every poll anyway.
     * Dropped as soon as the VCU is not active, so nothing of them shows on a
     * plain Virtual Boy or before the game has unlocked color.
     */
    protected readColorAttributes(sim: Sim): Promise<void>;
    /**
     * The color tables the previews are drawn with, while they are drawn in
     * color: CRAM, the cell tables of the segments the drawn worlds map from,
     * and the World offsets — no objects, since no preview here draws one.
     *
     * Compared with the last read, so a game that leaves its colors alone
     * costs the read and no drawing; and dropped, with a redraw, the moment
     * color stops applying, so the panel is back in red at once.
     */
    protected readColors(sim: Sim): Promise<void>;
    /** Timestamp the characters of one segment whose bytes are not what they were. */
    protected markChanged(segment: number, bytes: Uint8Array, previous: Uint8Array, now: number): void;
    /**
     * What currently refers to character memory: the cells of the BGMap
     * segments the drawn worlds map from, and OAM.
     *
     * The segments are chosen rather than all fourteen read, both because a
     * hundred kilobytes of reads a poll is a lot to pay for something nothing
     * is drawing and because a segment no world maps from holds whatever the
     * last scene left in it, which is not evidence of anything.
     */
    protected readReferences(sim: Sim): Promise<void>;
    /**
     * The remembered column count, held to the three the slider offers: it is
     * stored as the width rather than as a slider position, and a width that
     * is no longer on offer would leave the slider with no step to sit on.
     */
    protected rememberedCharsPerRow(): number;
    /** The remembered filter, or All for a stored value that is no longer one. */
    protected rememberedFilter(): CharacterFilter;
    protected setCharsPerRow(charsPerRow: number): void;
    protected setVbColorPreview(on: boolean): void;
    protected setFilter(filter: CharacterFilter): void;
    /** Select a character the screen inspector points at, and bring it into view. */
    reveal(target: ScreenInspectorTarget): void;
    protected selectCharacter(char: number): void;
    /** Whether the current filter keeps a character. */
    protected shown(char: number, now: number): boolean;
    /**
     * How one character is shaded in the atlas: as it is, or ghosted.
     *
     * Two states rather than three. Fading the characters nothing refers to
     * while showing all of them is the same statement the In use filter makes,
     * only quieter, and saying it in two places left the sheet with two kinds
     * of gray to tell apart. What is in use is the filter's question now.
     */
    protected shadingFor(char: number, now: number): CharacterShading;
    protected rasterize(): void;
    /**
     * The whole of character memory as one bitmap, shaded by `shadingFor` —
     * in red, or in color while there are {@link colors} to draw with.
     */
    protected drawAtlas(shadingFor: (char: number) => CharacterShading): ImageData | undefined;
    /**
     * A thumbnail per BGMap segment whose cells name the selected character:
     * the map one pixel to the cell, with those cells picked out.
     *
     * A count on its own says a character is used forty times and leaves where
     * as the question — and where, in a map, is a shape: the letters of a line
     * of text, the bricks along a floor. At this size the map is a silhouette
     * rather than a picture, which is enough to recognize what part of the
     * screen is being looked at and to see the marks against it.
     */
    protected buildMapPreviews(): void;
    /**
     * Which characters the drawn worlds actually show, and the objects' too.
     *
     * The In use filter's answer. It has to be the same walk the Used by rows
     * are counted from, or the two disagree about the same character: a map
     * being read is not the same as every cell of it being drawn, and a
     * character sitting in a corner of a map the world never scrolls to is
     * not in use by any reading of the word.
     */
    protected markDrawnCharacters(): void;
    /**
     * Walk the cells one world draws, once each, with the segment each came
     * from.
     *
     * The walk is over pixels, because only the pixels know where they come
     * from once a param table is shifting each row of them — but a cell is
     * eight pixels across, so the lookup only happens where the run of pixels
     * moves into a new cell, and a set keeps a cell the world draws twice from
     * being counted twice.
     */
    protected eachDrawnCell(world: VipWorld, map: VipWorldMap, visit: (char: number, segment: number) => void): void;
    /**
     * One BGMap segment, a pixel to the cell.
     *
     * A whole map rather than a window, because a segment no world reads has
     * no window: there is nothing drawing it to say which part of it matters.
     */
    protected drawSegmentPreview(segment: number): ImageData | undefined;
    /**
     * One world as it is actually drawn, with the pixels that come from the
     * selected character picked out.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one — so the map on its own would answer "where is this
     * character" with a picture of somewhere the world never looks. Every
     * property that decides where a pixel comes from is applied by
     * {@link forEachVipWorldPixel}; the only ones dropped here are the three
     * that place the finished rectangle on the screen (GX, GY, GP), since the
     * preview is the rectangle.
     */
    protected drawWorldPreview(world: VipWorld): ImageData | undefined;
    /**
     * The param table one world reads, as a view over BGMap memory.
     *
     * The tables live in the same region as the maps do, so the read that
     * fetched the segments has already fetched these; a world whose table
     * runs past the end of the region gets none rather than a short one,
     * which the drawing treats as a world with no per-row shift at all.
     */
    protected paramsFor(world: VipWorld): DataView | undefined;
    /**
     * A grid of cells as a bitmap, one pixel each: the character's average
     * brightness, or white where it is the selected one.
     *
     * At this size a map is a silhouette rather than a picture, which is
     * enough to recognize which part of the screen is being looked at and to
     * see the marks against it.
     */
    protected drawCells(width: number, height: number, averages: Uint8Array, charAt: (x: number, y: number) => number | undefined): ImageData;
    /**
     * How bright each character is on average, which is what a cell comes out
     * as when a whole map is drawn one pixel to the cell.
     *
     * Built once per read of character memory rather than per thumbnail: a
     * segment has four thousand cells and a character sixty-four pixels, so
     * doing it the other way round is the same sixty-four lookups over and
     * over for every cell that happens to name the same character.
     */
    protected characterAverages(): Uint8Array;
    /**
     * The atlas cut into its character segments, four or eight.
     *
     * Views onto the same pixels rather than four more buffers: a segment is
     * a whole number of rows of the sheet whatever the column count, so each
     * one's rows are already contiguous.
     */
    protected sliceSegments(image: ImageData): ImageData[];
    /** Just the selected character, for the sidebar preview. */
    protected rasterizePreview(characters: VipCharacters, char: number): ImageData;
    /**
     * Write the sheet out as a PNG, at one screen pixel per source pixel.
     *
     * Neither filtered nor dimmed, and without the grid: this is the file
     * somebody lines up against the source art they built the characters
     * from, and the viewing aids would be in the way of that.
     */
    protected exportPng(): Promise<void>;
    protected render(): React.ReactNode;
    /**
     * The character being inspected: its pixels first, then where it lives.
     *
     * A group like the two under it, rather than the bare block it started
     * as: three things in a sidebar that are each a heading and a list of
     * facts should look like three of the same thing.
     */
    protected renderSelected(): React.ReactNode;
    /**
     * The selected character's VB Color attributes: the palette groups and
     * the Pixel Color Attribute the VCU keeps per Character.
     *
     * Only while the VCU is active, and a group of its own rather than more
     * rows under Current Character, because none of it is in effect by
     * itself: a cell or object only draws with these when its own Color
     * Attribute carries CHRSEL, and then only while CXCTRL.CCEN is set —
     * which is said under the fields when it is not, rather than the group
     * going away, since a game sets these entries up before it switches them
     * on and that is exactly when somebody wants to check them.
     */
    protected renderCharacterColor(): React.ReactNode;
    /** One byte of the selected character's Character Color Attribute entry. */
    protected writeColorAttr(offset: number, value: number): void;
    /** The selected character's Character Pixel Color Attribute halfword. */
    protected writePixelAttr(value: number): void;
    /**
     * Write VCU memory and pick the change straight back up, as the other
     * panels' editors do: the next poll would otherwise show the old value
     * for a moment and make the field look as if it had not taken.
     */
    protected writeVcu(address: number, bytes: number[]): void;
    /**
     * Who refers to the selected character right now, and only to it.
     *
     * Reads as a list of places rather than a count, because the useful
     * question about a character in an atlas is which map or how many sprites
     * it turned up in, not how many references exist in total — and each map
     * comes with a thumbnail of itself, marked where those cells are.
     */
    protected renderUsedBy(): React.ReactNode;
    protected renderDisplayGroup(): React.ReactNode;
    /**
     * One of the Display group's settings, as a switch.
     *
     * A switch rather than a checkbox because these take effect the moment
     * they are thrown — see the kit component, and the SRAM panel's toggles,
     * which are laid out the same way: the control, then the name beside it.
     */
    protected renderToggle(label: string, value: boolean, onChange: (value: boolean) => void, hint?: string): React.ReactNode;
    /**
     * Walk the sheet with the keyboard: a character at a time, a row at a
     * time, a segment at a time, or to either end of it.
     *
     * The event is stopped rather than only defaulted, because the emulator
     * listens for keys on the node this panel sits inside and would otherwise
     * read an arrow as the D-pad and move the game while the sheet is being
     * read. Anything this does not handle is left alone and carries on to it.
     */
    /** The sheet's own arrow keys, from anywhere in the panel. */
    protected onPanelKey(event: React.KeyboardEvent): void;
    protected onAtlasKey(event: React.KeyboardEvent): void;
    /**
     * Scroll the selection back into view after the keyboard moved it.
     *
     * After the next frame rather than now: the selection is drawn by the
     * render this has just asked for, and the element to scroll to does not
     * exist until that has happened.
     */
    protected revealSelection(): void;
    /** The sheet: one canvas, or one per segment under its own heading. */
    protected renderAtlas(): React.ReactNode;
    /**
     * One canvas of the sheet, whose top-left character is `first`.
     *
     * Split or not, a canvas only knows the range it draws, so both the
     * selection outline and a click are in its own coordinates and offset by
     * that first index on the way in and out.
     */
    protected renderCanvas(image: ImageData, first: number): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-vip-characters-panel.d.ts.map