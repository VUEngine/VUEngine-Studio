import { Disposable, Emitter } from '../../common/emulator-events';
import { Drag } from '@lumino/dragdrop';
import { Message } from '@lumino/messaging';
import { DockLayout, DockPanel, TabBar, Widget } from '@lumino/widgets';
import { VueportRumblePack } from '../../common/emulator-rumble';
import { EsSoundPlayer } from '../emulator-essound-player';
import { Sim } from '../core/vb-core';
import { VesBreakpoints } from '../core/emulator-breakpoints';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { RomHeader } from '../emulator-types';
import { EmulatorPanelType, DebugSource, InspectedSeat, Panel } from './emulator-panel';
import { ScreenPanel, VesScreenRect } from './emulator-screen-panel';
/** Panels other than the screen, which is always present. */
/**
 * Every panel that is not the screen.
 *
 * Derived rather than listed. It used to be a list beside the enum, and a
 * panel added to one and not the other was a panel that could be opened from
 * the command palette — which builds one directly — but not from a tab group's
 * "+", and that was dropped from the layout the next time it was restored:
 * both of those go through `widgetFor`, which checks this. Being a copy of the
 * enum, the list could only ever be wrong.
 *
 * The screen is left out because it is not a debug panel and is never created
 * on demand; `widgetFor` answers for it separately.
 */
export declare const EMULATOR_DEBUG_PANELS: (EmulatorPanelType.ACTORS | EmulatorPanelType.DISASSEMBLY | EmulatorPanelType.ES_SOUND | EmulatorPanelType.MEMORY | EmulatorPanelType.PROFILER | EmulatorPanelType.MEMORY_POOLS | EmulatorPanelType.REGISTERS | EmulatorPanelType.ROM_INFO | EmulatorPanelType.RUMBLE_PACK | EmulatorPanelType.SRAM | EmulatorPanelType.TERMINAL | EmulatorPanelType.VIP_BGMAPS | EmulatorPanelType.VIP_CHARACTERS | EmulatorPanelType.VIP_FRAME_BUFFERS | EmulatorPanelType.VIP_OBJECTS | EmulatorPanelType.VIP_PALETTES | EmulatorPanelType.VIP_WORLDS | EmulatorPanelType.VCU | EmulatorPanelType.VSU)[];
/**
 * The emulator's dockable area.
 *
 * Panels can be dragged, split, resized, tabbed and closed like any other dock
 * area, and the arrangement is saved so it survives reopening the emulator.
 * Reset Layout puts it back to the built-in default (DEFAULT_LAYOUT), which is
 * also what a freshly opened emulator starts with. That dragging is sealed off
 * from the rest of the application in both directions — see `trackOwnDrag`
 * and `blockForeignOverlay` — so none of it can end up as a tab in the main
 * shell, and nothing from the shell can end up docked here.
 */
/**
 * What the dock needs from whatever it is embedded in.
 *
 * Both are about coexisting with an outer dock that is also tracking the
 * pointer, which is a situation only VES has: standing alone there is
 * nothing above this dock to confuse, so a host may leave them out entirely.
 */
export interface VueportDockHost {
    /**
     * Tell the surrounding shell to forget the drag it thinks is happening,
     * because this dock is handling it. See `trackOwnDrag`.
     */
    cancelForeignDrag?(): void;
    /**
     * The arrangement a fresh emulator starts with, and what Reset Layout
     * restores. Left out to take the built-in one — see `DEFAULT_LAYOUT` for
     * what that is and what it deliberately leaves closed.
     */
    defaultLayout?: AreaLayout;
    /**
     * The recording profiler — record a session, replay it, export the call
     * tree — for the CPU Profiler panel's own button. Not part of
     * `DebugSource` either: starting a recording drives the
     * emulator, which that interface deliberately cannot. Left out on a host
     * that offers no recording; the button then does not appear.
     */
    isProfiling?(): boolean;
    toggleProfiling?(): void;
    /**
     * Whether the machine is stopped, and how to stop or start it, for the
     * Disassembly panel's own controls.
     *
     * Not part of `DebugSource` for the same reason the profiler's button is
     * not: that interface reads the machine and deliberately cannot drive it,
     * and pausing is driving. A host that leaves these out gets a panel that
     * reads the program but cannot stop it, which is what every host had
     * before breakpoints existed.
     */
    isPaused?(): boolean;
    setPaused?(paused: boolean): void;
    /**
     * The build's line table, and the source files it names, for the
     * Disassembly panel's source view.
     *
     * Both optional and both about the same thing: a host that can reach the
     * files a build left behind can show the C each instruction came from,
     * and one that cannot shows the instructions alone. Read through the host
     * rather than here because it owns the file access and the caching, the
     * same way `symbolLoader` does.
     */
    lineTable?(): Promise<VesLineTable | undefined>;
    readSource?(path: string): Promise<string | undefined>;
    /**
     * Where the panels' own control settings are kept — see
     * `DebugSource.panelPreference`. Read once when the dock is
     * built and written back whole whenever one changes; a host that leaves
     * them out gets panels that remember nothing past this session.
     */
    readPanelPreferences?(): Record<string, string | number | boolean>;
    writePanelPreferences?(state: Record<string, string | number | boolean>): void;
    /**
     * Hand a file a panel made to the person — the Characters panel's PNG of
     * the character sheet.
     *
     * Not part of `DebugSource` either: that interface is about the machine,
     * and where a file somebody asked for should land is the host's business
     * — a download in the browser, a file in the project in VES. The panel
     * says what the file is called and the host is free to put its own stamp
     * on the name. A host that leaves this out gets a panel with no Export
     * button rather than one whose button fails.
     */
    exportFile?(name: string, data: Uint8Array): Promise<void>;
}
export declare class VueportDock extends DockPanel implements DebugSource {
    protected readonly instanceId: string;
    protected readonly host: VueportDockHost;
    protected readonly rumblePack: VueportRumblePack;
    protected readonly esSound: EsSoundPlayer;
    protected readonly symbolLoader: () => Promise<SymbolIndex | undefined>;
    readonly screen: ScreenPanel;
    protected currentSim: Sim | undefined;
    /**
     * The other player's machine, while a link session is running.
     *
     * This window runs it alongside its own — see `emulator-core-service.ts` —
     * so pointing an inspector at it costs nothing and shows the same thing
     * the other player's own debugger would.
     */
    protected currentPeerSim: Sim | undefined;
    protected currentInspecting: InspectedSeat;
    /**
     * Where a panel's writes go, when something other than this owns that.
     *
     * Set by the host while a link session is running: a write then has to
     * reach both windows on one frame rather than this window now. Returning
     * false means it could not be arranged and the write should go straight
     * in. See `write`.
     */
    protected writeRoute: ((seat: InspectedSeat, address: number, bytes: number[]) => boolean) | undefined;
    protected currentVbcSupportEnabled: boolean;
    protected currentVbcHardwareActive: boolean;
    protected currentRomHeader: RomHeader;
    protected currentRomSize: number;
    protected currentBuildMode?: string;
    protected currentRomChecksum?: string;
    protected panelPreferenceState: Record<string, string | number | boolean> | undefined;
    protected panelPreferenceWrite?: number;
    protected readonly panels: Map<EmulatorPanelType, Panel>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    protected readonly onDidChangeLayoutEmitter: Emitter<void>;
    protected readonly onDidRequestAddPanelEmitter: Emitter<TabBar<Widget>>;
    protected readonly onDidRequestResetLayoutEmitter: Emitter<void>;
    /** Fires when the arrangement changes, so it can be persisted. */
    readonly onDidChangeLayout: import("../../common/emulator-events").Event<void>;
    /**
     * Fires when a tab group's "+" is pressed, with the group it was pressed
     * on — which is where whatever the user then picks should land.
     *
     * The dock raises this rather than asking for a panel itself, because
     * choosing one is a quick pick, and that belongs to the view contribution
     * that owns the Add Panel command.
     */
    readonly onDidRequestAddPanel: import("../../common/emulator-events").Event<TabBar<Widget>>;
    /**
     * A tab bar's reset button was pressed.
     *
     * The dock does not reset itself: the host decides whether to ask first,
     * and owns the persisted layout that has to be cleared alongside.
     */
    readonly onDidRequestResetLayout: import("../../common/emulator-events").Event<void>;
    constructor(instanceId: string, host: VueportDockHost, rumblePack: VueportRumblePack, esSound: EsSoundPlayer, symbolLoader: () => Promise<SymbolIndex | undefined>);
    /**
     * Double-clicking empty space in a tab row asks for a panel to put there,
     * the same as its "+" — a double-click on a strip of tabs reads as "give me
     * another one", and applications commonly treat it that way.
     *
     * Capture phase, so this runs on the way *down* to the tab bar: the tab bar
     * stops the event on the way back up to keep it away from the surrounding
     * application (see `VueportTabBar`), which would otherwise mean the
     * dock never saw it.
     */
    protected readonly addOnDoubleClickListener: (event: Event) => void;
    protected onAfterAttach(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected static readonly DRAG_EVENTS: readonly ["lm-dragenter", "lm-dragover", "lm-dragleave", "lm-drop"];
    protected readonly pointerMoveListener: (event: Event) => void;
    protected readonly dragEnterListener: (event: Event) => void;
    protected readonly sealDragListener: (event: Event) => void;
    /**
     * Keep this dock's own drag events from reaching the dock panels it is
     * nested inside — which is what left drop indicators stranded over the
     * shell's left, right and top edges.
     *
     * This dock is a `DockPanel` inside a Theia widget inside the shell's main
     * `DockPanel`, and Lumino binds `lm-drag*` on `this.node` in the *bubble*
     * phase. So every drag event in here travels up through the ancestor dock
     * panel on its way out, and two asymmetries in Lumino's own handlers turn
     * that into a stuck overlay:
     *
     * - `_evtDragOver` calls `_showOverlay(…)` as the second operand of an
     *   `||`, so the overlay is shown as a *side effect* of deciding the drop
     *   is invalid, and `stopPropagation()` only happens on the accepting
     *   branch. Any position this dock declines — over the screen panel, or a
     *   gap between panels — therefore bubbles on, and the ancestor obligingly
     *   shows its own drop indicator for a drag that can never land there.
     * - `_evtDragLeave` *does* call `stopPropagation()` for a drag whose
     *   source is this panel. So the leave that would have hidden that
     *   indicator is exactly the event the ancestor never receives.
     *
     * Hence the asymmetry is self-sustaining: the ancestor is told to show,
     * and never told to hide. `trackOwnDrag`'s `overlay.hide(0)` cannot help,
     * because that hides *this* dock's overlay, not an ancestor's.
     *
     * Only this dock's own drags are sealed. A foreign tab dragged across the
     * emulator on its way to the main area must still reach the panel that can
     * accept it — `tabsConstrained` already refuses the drop here, and Lumino's
     * own handlers deliberately leave that case propagating.
     */
    protected sealDragFromAncestors(event: Drag.Event): void;
    /** The `Drag` this dock's own tab bar started, for as long as one is in flight. */
    protected get ownDrag(): Drag | null;
    /**
     * Keep this dock's own drag from leaking into the rest of the
     * application, in every sense that turned out to matter. Three separate
     * problems, addressed together because each has a different, unrelated
     * cause:
     *
     * 1. **A foreign panel showing its own drop-target overlay.** Handled by
     *    `blockForeignOverlay`, on `lm-dragenter`.
     *
     * 2. **`ApplicationShell` revealing a collapsed sidebar or the bottom
     *    panel near a screen edge, mid-drag.** Its "drag near an edge for
     *    500ms" gate (`onDragOver`) measures from `dragState.startTime`,
     *    which is set the moment *any* `lm-dragenter` fires anywhere in the
     *    application — including ones entirely within this dock's own tab
     *    bars, during perfectly ordinary in-dock dragging. An real drag
     *    gesture easily takes longer than 500ms before ever nearing an edge,
     *    so by the time one is reached the gate is already open and the
     *    panel expands on the very first qualifying tick — no interception
     *    at the boundary, however early, can prevent that, because the clock
     *    started long before the boundary was ever approached. The only fix
     *    is to keep that clock from ever running while the drag is still
     *    ours: `trackOwnDrag`, on every `pointermove` for as long as this
     *    dock has a drag in flight, unconditionally clears `dragState`
     *    (private — there is no public way to opt a drag out of this) so it
     *    is never more than one tick old, wherever the cursor currently is.
     *
     * 3. **Ending the gesture once it truly leaves.** Also `trackOwnDrag`:
     *    once the raw cursor position falls outside this dock's own
     *    rectangle, it calls `Drag.dispose()` — Lumino's own sanctioned way
     *    to abort mid-gesture, the same thing pressing Escape does, and what
     *    `DockPanel`'s own `dispose()` calls on a drag it still has in
     *    flight. That tears down the pointer tracking driving every later
     *    dragenter/dragover/drop, so nothing gets another tick to react to
     *    this drag again. The tab itself was only ever hidden while dragged,
     *    never actually removed from its tab bar, so it simply reappears
     *    where it was — exactly what already happens when an ordinary drag
     *    is canceled over invalid space. `overlay.hide(0)` alongside it is
     *    cheap insurance for this dock's own drop-target indicator, in case
     *    the `dragleave` `dispose()` sends on its way out does not reach it.
     *
     * Position is read straight from the event rather than resolved through
     * Lumino's own `elementFromPoint`-based target tracking, deliberately:
     * two earlier designs built on `lm-dragenter`/`lm-dragover` each modeled
     * that machinery well enough to fix one symptom, then left another
     * boundary case (a still-stuck overlay, then this edge-expansion timing
     * issue) for the next region of the screen to surface. Raw cursor
     * position against this dock's own rectangle has no such subtlety.
     */
    protected trackOwnDrag(event: PointerEvent): void;
    /**
     * Refuse one of this dock's own tabs onto a foreign panel's own overlay.
     *
     * The other direction — a foreign tab dragged in — is `tabsConstrained`
     * (set in the constructor), checked by Lumino's own `DockPanel` before
     * accepting a *drop*, which is enough on its own. Outgoing has no such
     * built-in support, since that check would have to run on whatever
     * foreign panel the drag has wandered onto, which knows nothing about
     * this dock — so this stops it here instead, in the capture phase, before
     * the event ever reaches that panel's own (bubble-phase) `_evtDragEnter`.
     * `stopPropagation()` alone, never `preventDefault()`: Lumino's own
     * `dispatchDragEnter` treats a *canceled* dragenter as *acceptance* —
     * `if (canceled) return currElem` — so calling `preventDefault()` to
     * reject, as an earlier version of this did, backfires by adopting the
     * foreign element as the drag's target instead of refusing it.
     */
    protected blockForeignOverlay(event: Drag.Event): void;
    /**
     * The machine the panels are reading.
     *
     * Falls back to this window's own whenever the other player's is not
     * there — a session that has just ended leaves panels pointed at a
     * machine that no longer exists otherwise, and every one of them would
     * show an empty readout rather than the game that is still running.
     */
    get sim(): Sim | undefined;
    get inspecting(): InspectedSeat;
    get hasPeerSim(): boolean;
    write(address: number, bytes: number[]): Promise<void>;
    get vbcSupportEnabled(): boolean;
    get vbcHardwareActive(): boolean;
    get romHeader(): RomHeader;
    get romSize(): number;
    get romChecksum(): string | undefined;
    get buildMode(): string | undefined;
    panelPreference<T extends string | number | boolean>(kind: EmulatorPanelType, key: string, fallback: T): T;
    setPanelPreference(kind: EmulatorPanelType, key: string, value: string | number | boolean): void;
    /** The panels' settings, read from the host the first time one is asked for. */
    protected panelPreferences(): Record<string, string | number | boolean>;
    /** Write a pending change out now, rather than at the end of its delay. */
    protected flushPanelPreferences(): void;
    onDidChange(listener: () => void): Disposable;
    getSymbols(): Promise<SymbolIndex | undefined>;
    getLineTable(): Promise<VesLineTable | undefined>;
    /**
     * Where the machine should stop.
     *
     * On the dock rather than in the panel that draws the gutter, because it
     * is not only that panel's: a host with editors sets breakpoints on
     * source lines and reaches this the same way. See `VesBreakpoints`.
     */
    readonly breakpoints: VesBreakpoints;
    protected readonly armOnChange: Disposable;
    readSource(path: string): Promise<string | undefined>;
    setHighlights(rects: VesScreenRect[]): void;
    setSim(sim: Sim | undefined): void;
    /**
     * Hand the machine the set as it stands.
     *
     * From here rather than from the panel, and regardless of whether that
     * panel is open: a breakpoint set on a line in an editor has to work
     * while nobody is looking at a disassembly, and that is the whole point
     * of the set living outside it. Nothing is armed when nothing is set, so
     * a session that uses no breakpoints still pays nothing for them.
     */
    protected armBreakpoints(): void;
    /**
     * Offer, or stop offering, the other player's machine to the inspectors.
     *
     * Taking it away points them back at this window's own rather than
     * leaving them on nothing, which is what ending a session should look
     * like: the debugger goes back to the game still in front of the player.
     */
    setPeerSim(sim: Sim | undefined): void;
    /** Point every inspector at one machine or the other. */
    setInspecting(seat: InspectedSeat): void;
    /** Hand a link session the panels' writes. See {@link writeRoute}. */
    setWriteRoute(route: ((seat: InspectedSeat, address: number, bytes: number[]) => boolean) | undefined): void;
    /**
     * Keep VB Color-only debugger surfaces in step with the machine.
     *
     * Two facts, set together because they change together: the global gate,
     * and whether what is running is a VB Color at all. The second is what the
     * color-only surfaces key off — see `vbcHardwareActive` on
     * {@link DebugSource}.
     *
     * The VCU panel is not one of them any more. It used to be closed outright
     * whenever the machine was not a VB Color, on the grounds that a tab for
     * absent hardware invites the question of what is wrong with it — but that
     * also meant the panel could not be opened at all except in color mode,
     * and a tab that disappears when the hardware mode changes is the more
     * confusing of the two. It stays open and says which machine is running.
     */
    setVbcSupportEnabled(enabled: boolean, hardwareActive?: boolean): void;
    /** Called whenever a ROM is (re)loaded, independently of the sim changing. */
    setRomInfo(romHeader: RomHeader, romSize: number, buildMode?: string, romChecksum?: string): void;
    /** Open a debug panel, or focus it if it is already there. */
    togglePanel(kind: EmulatorPanelType): void;
    /**
     * Open a panel in one particular tab group — what a group's "+" does.
     *
     * A panel that is already open elsewhere is moved rather than duplicated:
     * Lumino's `addWidget` relocates a widget the layout already contains, so
     * the same call covers both cases.
     */
    addPanelTo(kind: EmulatorPanelType, tabBar: TabBar<Widget>): void;
    /** The tab group a widget is currently in, if it is in one. */
    protected tabBarFor(widget: Widget): TabBar<Widget> | undefined;
    isPanelOpen(kind: EmulatorPanelType): boolean;
    /** Open *and* on top of its tab group, rather than behind another tab. */
    isPanelVisible(kind: EmulatorPanelType): boolean;
    protected createPanel(kind: EmulatorPanelType): Panel;
    protected clearPanels(): void;
    /** Put the panels back to the built-in default arrangement (DEFAULT_LAYOUT). */
    resetLayout(): void;
    /**
     * Play mode: show only the screen, hiding whatever debug panels are open
     * without closing them. `restoreLayout` only unparents widgets that drop
     * out of the new config rather than disposing them, so this is fully
     * reversible — `applySerializedLayout`/`resetLayout` bring back exactly
     * what was open before, `widgetFor` finding the same still-live instances.
     *
     * The cheats, macros, patches, colors and achievements are not among the
     * panels this hides, because they are not panels: in both modes they are
     * shown beside the screen without the dock being involved at all — see
     * `EmulatorHost#renderCheats` — because somebody reaching for one should
     * not have to think about panels, tabs or layouts.
     */
    showScreenOnly(): void;
    /**
     * The screen's own tab bar is pointless chrome when it is the only thing
     * docked (Play mode always leaves it that way, via showScreenOnly), so
     * hide it entirely rather than render a single-tab bar above the screen.
     */
    setPlayMode(active: boolean): void;
    /**
     * Keep Lumino's layout in step with the CSS that hides the tab bar in Play
     * mode.
     *
     * `.vp-dock-play-mode .lm-TabBar { display: none }` takes the bar off
     * the screen, but `DockLayout` still reserves its height — it only
     * collapses a tab bar whose widget it knows is hidden, and a CSS rule is
     * not that. Hiding the bar at the widget level too is what closes the empty
     * band above the picture.
     */
    protected updatePlayModeTabBars(): void;
    private applyingPlayModeTabBars;
    /**
     * Record the arrangement, including splits and their sizes.
     *
     * Lumino's own layout config holds widget instances, which cannot be
     * stored, so the tree is copied with each widget replaced by the kind of
     * panel it is. Restoring rebuilds the same tree with fresh instances.
     */
    serializeLayout(): VueportDockLayout;
    applySerializedLayout(layout: VueportDockLayout | undefined): void;
    protected serializeArea(area: DockLayout.AreaConfig | null): AreaLayout | undefined;
    protected deserializeArea(area: AreaLayout): DockLayout.AreaConfig | undefined;
    protected kindOf(widget: Widget): EmulatorPanelType | undefined;
    /** The instance for a kind, creating a debug panel if it is not open yet. */
    protected widgetFor(kind: EmulatorPanelType): Widget | undefined;
    protected focusWidget(widget: Widget): void;
    /**
     * Scroll a widget's tab into view.
     *
     * Tab rows scroll once there are more tabs than fit, so the tab of a panel
     * just opened or focused can be off the end of one — which would look like
     * nothing happened.
     */
    protected revealTab(widget: Widget): void;
    dispose(): void;
}
export type AreaLayout = {
    type: 'tab-area';
    panels: EmulatorPanelType[];
    currentIndex: number;
} | {
    type: 'split-area';
    orientation: 'horizontal' | 'vertical';
    children: AreaLayout[];
    sizes: number[];
};
export interface VueportDockLayout {
    main?: AreaLayout;
}
//# sourceMappingURL=emulator-dock.d.ts.map