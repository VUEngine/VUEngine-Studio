import { Disposable, Emitter } from '../../common/emulator-events';
import { Drag } from '@lumino/dragdrop';
import { Message } from '@lumino/messaging';
import { DockLayout, DockPanel, TabBar, Widget } from '@lumino/widgets';
import { VueportRumblePack } from '../../common/emulator-rumble';
import { EsSoundPlayer } from '../emulator-essound-player';
import { Sim } from '../core/vb-core';
import { VesBreakpoints } from '../core/emulator-breakpoints';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { RomHeader } from '../emulator-types';
import { EmulatorPanelType, DebugSource, InspectedSeat, Panel } from './emulator-panel';
import { ScreenPanel, VesScreenRect } from './emulator-screen-panel';
import { ScreenInspector, ScreenInspectorTarget } from './emulator-screen-inspector';
import { VbPixelSource } from '../../common/vb-pixel-origin';
import { VipExportFile } from './emulator-vip-canvas';
export declare const EMULATOR_DEBUG_PANELS: (EmulatorPanelType.ACTORS | EmulatorPanelType.DISASSEMBLY | EmulatorPanelType.ES_SOUND | EmulatorPanelType.MEMORY | EmulatorPanelType.PROFILER | EmulatorPanelType.MEMORY_POOLS | EmulatorPanelType.REGISTERS | EmulatorPanelType.ROM_INFO | EmulatorPanelType.RUMBLE_PACK | EmulatorPanelType.SRAM | EmulatorPanelType.TERMINAL | EmulatorPanelType.VIP_BGMAPS | EmulatorPanelType.VIP_CHARACTERS | EmulatorPanelType.VIP_COLUMN_TABLE | EmulatorPanelType.VIP_FRAME_BUFFERS | EmulatorPanelType.VIP_OBJECTS | EmulatorPanelType.VIP_PALETTES | EmulatorPanelType.VIP_WORLDS | EmulatorPanelType.VCU | EmulatorPanelType.VSU)[];
export interface VueportDockHost {
    cancelForeignDrag?(): void;
    defaultLayout?: AreaLayout;
    isProfiling?(): boolean;
    toggleProfiling?(): void;
    isPaused?(): boolean;
    setPaused?(paused: boolean): void;
    lineTable?(): Promise<VesLineTable | undefined>;
    readSource?(path: string): Promise<string | undefined>;
    readPanelPreferences?(): Record<string, string | number | boolean>;
    writePanelPreferences?(state: Record<string, string | number | boolean>): void;
    exportFile?(name: string, data: Uint8Array): Promise<void>;
}
export declare class VueportDock extends DockPanel implements DebugSource {
    protected readonly instanceId: string;
    protected readonly host: VueportDockHost;
    protected readonly rumblePack: VueportRumblePack;
    protected readonly esSound: EsSoundPlayer;
    protected readonly symbolLoader: () => Promise<SymbolIndex | undefined>;
    readonly screen: ScreenPanel;
    protected readonly inspector: ScreenInspector;
    protected debugMode: boolean;
    protected originsSim: Sim | undefined;
    protected currentSim: Sim | undefined;
    protected currentPeerSim: Sim | undefined;
    protected currentInspecting: InspectedSeat;
    protected writeRoute: ((seat: InspectedSeat, address: number, bytes: number[]) => boolean) | undefined;
    protected currentVbcSupportEnabled: boolean;
    protected currentVbcHardwareActive: boolean;
    protected currentRomHeader: RomHeader;
    protected currentRomSize: number;
    protected currentBuildMode?: string;
    protected currentRomChecksum?: string;
    protected panelPreferenceState: Record<string, string | number | boolean> | undefined;
    protected panelPreferenceWrite?: number;
    protected readonly panels: Map<EmulatorPanelType, Panel>;
    protected readonly onDidChangeEmitter: Emitter<void>;
    protected readonly onDidChangeLayoutEmitter: Emitter<void>;
    protected readonly onDidRequestAddPanelEmitter: Emitter<TabBar<Widget>>;
    protected readonly onDidRequestResetLayoutEmitter: Emitter<void>;
    readonly onDidChangeLayout: import("../../common/emulator-events").Event<void>;
    readonly onDidRequestAddPanel: import("../../common/emulator-events").Event<TabBar<Widget>>;
    readonly onDidRequestResetLayout: import("../../common/emulator-events").Event<void>;
    constructor(instanceId: string, host: VueportDockHost, rumblePack: VueportRumblePack, esSound: EsSoundPlayer, symbolLoader: () => Promise<SymbolIndex | undefined>);
    protected readonly addOnDoubleClickListener: (event: Event) => void;
    protected onAfterAttach(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected static readonly DRAG_EVENTS: readonly ["lm-dragenter", "lm-dragover", "lm-dragleave", "lm-drop"];
    protected readonly pointerMoveListener: (event: Event) => void;
    protected readonly dragEnterListener: (event: Event) => void;
    protected readonly sealDragListener: (event: Event) => void;
    /**
     * Keeps this dock's own drag events from the ancestor dock panels, which left drop indicators stranded over
     * the shell's edges. Lumino binds `lm-drag*` in the bubble phase, and its `_evtDragOver` shows the overlay as
     * a side effect of rejecting a drop (only accepting stops propagation), while `_evtDragLeave` stops
     * propagation for our own drags, so the ancestor is told to show but never to hide. `overlay.hide(0)` in
     * `trackOwnDrag` only hides our own overlay. Foreign drags still propagate: `tabsConstrained` refuses them here
     */
    protected sealDragFromAncestors(event: Drag.Event): void;
    protected get ownDrag(): Drag | null;
    /**
     * Keeps this dock's own drag from leaking into the application:
     * 1. a foreign panel's drop overlay: `blockForeignOverlay`, on `lm-dragenter`.
     * 2. `ApplicationShell` revealing a collapsed side or bottom panel near a screen edge: its 500ms edge gate
     *    (`onDragOver`) times from `dragState.startTime`, set by any `lm-dragenter`, including ones in our own tab
     *    bars, so it is often open by the time an edge is reached. So while our drag is in flight, every
     *    `pointermove` clears the private `dragState`.
     * 3. once the cursor leaves this dock's rectangle, `Drag.dispose()` aborts the gesture (as Escape does); the
     *    tab was only hidden, so it reappears. `overlay.hide(0)` covers our own indicator if `dragleave` misses it.
     * Position is the raw cursor against our rectangle; earlier designs built on `lm-dragenter`/`lm-dragover`
     * each fixed one symptom and left another
     */
    protected trackOwnDrag(event: PointerEvent): void;
    /**
     * Refuses our own tabs onto a foreign panel's overlay, in the capture phase before its bubble-phase
     * `_evtDragEnter` (incoming is `tabsConstrained`). Only `stopPropagation()`: Lumino's `dispatchDragEnter`
     * treats a canceled dragenter as acceptance (`if (canceled) return currElem`), so `preventDefault()`
     * would adopt the foreign element as the target
     */
    protected blockForeignOverlay(event: Drag.Event): void;
    get sim(): Sim | undefined;
    get inspecting(): InspectedSeat;
    get hasPeerSim(): boolean;
    write(address: number, bytes: number[]): Promise<void>;
    get vbcSupportEnabled(): boolean;
    get vbcHardwareActive(): boolean;
    get romHeader(): RomHeader;
    get romSize(): number;
    get romChecksum(): string | undefined;
    get buildMode(): string | undefined;
    panelPreference<T extends string | number | boolean>(kind: EmulatorPanelType, key: string, fallback: T): T;
    setPanelPreference(kind: EmulatorPanelType, key: string, value: string | number | boolean): void;
    protected panelPreferences(): Record<string, string | number | boolean>;
    protected flushPanelPreferences(): void;
    onDidChange(listener: () => void): Disposable;
    getSymbols(): Promise<SymbolIndex | undefined>;
    getLineTable(): Promise<VesLineTable | undefined>;
    readonly breakpoints: VesBreakpoints;
    protected readonly armOnChange: Disposable;
    readSource(path: string): Promise<string | undefined>;
    setHighlights(rects: VesScreenRect[]): void;
    highlightSource(source: VbPixelSource | undefined): void;
    reveal(target: ScreenInspectorTarget): void;
    setSim(sim: Sim | undefined): void;
    protected applyPixelOrigins(): void;
    protected armBreakpoints(): void;
    setPeerSim(sim: Sim | undefined): void;
    setInspecting(seat: InspectedSeat): void;
    setWriteRoute(route: ((seat: InspectedSeat, address: number, bytes: number[]) => boolean) | undefined): void;
    setVbcSupportEnabled(enabled: boolean, hardwareActive?: boolean): void;
    setRomInfo(romHeader: RomHeader, romSize: number, buildMode?: string, romChecksum?: string): void;
    togglePanel(kind: EmulatorPanelType): void;
    addPanelTo(kind: EmulatorPanelType, tabBar: TabBar<Widget>): void;
    protected tabBarFor(widget: Widget): TabBar<Widget> | undefined;
    isPanelOpen(kind: EmulatorPanelType): boolean;
    isPanelVisible(kind: EmulatorPanelType): boolean;
    protected exportFile(): VipExportFile | undefined;
    protected createPanel(kind: EmulatorPanelType): Panel;
    protected clearPanels(): void;
    resetLayout(): void;
    showScreenOnly(): void;
    setPlayMode(active: boolean): void;
    protected updatePlayModeTabBars(): void;
    private applyingPlayModeTabBars;
    serializeLayout(): VueportDockLayout;
    applySerializedLayout(layout: VueportDockLayout | undefined): void;
    protected pendingArrangement?: DockLayout.AreaConfig;
    protected restoreArrangement(main: DockLayout.AreaConfig): void;
    protected onResize(msg: Widget.ResizeMessage): void;
    protected holdsScreen(): boolean;
    protected serializeArea(area: DockLayout.AreaConfig | null): AreaLayout | undefined;
    protected deserializeArea(area: AreaLayout): DockLayout.AreaConfig | undefined;
    protected kindOf(widget: Widget): EmulatorPanelType | undefined;
    protected widgetFor(kind: EmulatorPanelType): Widget | undefined;
    protected focusWidget(widget: Widget): void;
    protected revealTab(widget: Widget): void;
    dispose(): void;
}
export type AreaLayout = {
    type: 'tab-area';
    panels: EmulatorPanelType[];
    currentIndex: number;
} | {
    type: 'split-area';
    orientation: 'horizontal' | 'vertical';
    children: AreaLayout[];
    sizes: number[];
};
export interface VueportDockLayout {
    main?: AreaLayout;
}
//# sourceMappingURL=emulator-dock.d.ts.map