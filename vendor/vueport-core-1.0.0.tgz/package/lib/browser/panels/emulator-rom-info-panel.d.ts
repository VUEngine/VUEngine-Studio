import * as React from 'react';
import { MemoryFootprint } from '../core/emulator-symbols';
import { DebugSource, Panel } from './emulator-panel';
/**
 * The cartridge header, parsed once when the ROM is loaded, and what the build
 * beside it spent.
 *
 * Almost nothing here is read from the running simulation — the header is
 * pushed by the widget whenever a ROM (re)loads, and the budgets come out of
 * the `.elf`, which does not change while a ROM is running — so there is
 * nothing that benefits from polling ten times a second. It still polls, at a
 * slow rate, purely as a safety net; opening the panel always shows the
 * current header regardless, since the base class refreshes immediately on
 * attach and on show.
 */
export declare class RomInfoPanel extends Panel {
    /**
     * What the build claimed before it ran, or undefined for a ROM with no
     * `.elf` beside it — which is every ROM that was not built here, and so an
     * ordinary state rather than a failure.
     */
    protected footprint?: MemoryFootprint;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    /**
     * What the build spent of the two memories it cannot grow.
     *
     * Only for a ROM with an `.elf` beside it: the figures are the linker's,
     * and nothing in a bare ROM says which of its bytes are code, which are
     * artwork, or how much of WRAM the game will be standing in.
     */
    protected renderBudgets(romSize: number): React.ReactNode;
}
//# sourceMappingURL=emulator-rom-info-panel.d.ts.map