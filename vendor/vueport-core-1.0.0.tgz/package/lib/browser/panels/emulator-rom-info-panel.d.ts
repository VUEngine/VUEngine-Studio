import * as React from 'react';
import { MemoryFootprint } from '../core/emulator-symbols';
import { DebugSource, Panel } from './emulator-panel';
export declare class RomInfoPanel extends Panel {
    protected footprint?: MemoryFootprint;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderBudgets(romSize: number): React.ReactNode;
}
//# sourceMappingURL=emulator-rom-info-panel.d.ts.map