import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
/**
 * The VIP's brightness and palette registers, shown as swatches.
 *
 * A palette register maps each of a pixel's four possible values to one of
 * the three brightness levels (or black); this shows exactly that mapping
 * rather than the raw register value, which alone is not very readable.
 */
export declare class PalettesPanel extends Panel {
    protected registers?: DataView;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
}
//# sourceMappingURL=emulator-vip-palettes-panel.d.ts.map