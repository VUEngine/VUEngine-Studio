import * as React from 'react';
import { DebugSource, Panel } from './emulator-panel';
export declare class PalettesPanel extends Panel {
    protected registers?: DataView;
    protected error?: string;
    constructor(source: DebugSource, instanceId: string);
    protected refresh(): Promise<void>;
    protected render(): React.ReactNode;
}
//# sourceMappingURL=emulator-vip-palettes-panel.d.ts.map