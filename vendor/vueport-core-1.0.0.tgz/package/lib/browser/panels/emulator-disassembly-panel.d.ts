import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { DisposableCollection } from '../../common/emulator-events';
import { DisassemblyLine } from '../../common/vb-protocol';
import { DisassemblyRow } from '../core/emulator-disassembly';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
export interface VesExecutionControl {
    isPaused(): boolean;
    setPaused(paused: boolean): void;
}
export declare class DisassemblyPanel extends Panel {
    protected readonly control?: VesExecutionControl | undefined;
    protected lines: DisassemblyLine[];
    protected error?: string;
    protected follow: boolean;
    protected address: number;
    protected pc?: number;
    protected breakpoints: Set<number>;
    protected selected?: number;
    protected history: number[];
    protected symbols?: SymbolIndex;
    protected lineTable?: VesLineTable;
    protected sources: Map<string, string[] | null>;
    protected showSource: boolean;
    protected railGrab?: number;
    protected watched?: Sim;
    protected readonly watching: DisposableCollection;
    protected scroller: HTMLElement | undefined;
    constructor(source: DebugSource, instanceId: string, control?: VesExecutionControl | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    protected followMachine(): void;
    protected toggleBreakpoint(row: DisassemblyRow): void;
    protected get paused(): boolean;
    protected step(): Promise<void>;
    protected stepOver(): Promise<void>;
    protected runTo(address: number): Promise<void>;
    protected rows(): DisassemblyRow[];
    protected requestSources(rows: DisassemblyRow[]): void;
    protected sourceText(file: string, line: number): string | undefined;
    protected pin(): void;
    reveal(target: ScreenInspectorTarget): void;
    protected goTo(address: number, remember?: boolean): void;
    protected goToProgramCounter(): void;
    protected back(): void;
    protected scrollBy(instructions: number): void;
    protected shareOf(address: number): number;
    protected get romBytes(): number;
    protected railThumb(height: number): {
        top: number;
        size: number;
    };
    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubRail(box: DOMRect, clientY: number): void;
    protected releaseRail(event: React.PointerEvent<HTMLDivElement>): void;
    protected goToText(text: string): void;
    protected render(): React.ReactNode;
    protected renderRail(): React.ReactNode;
    protected onKey(event: React.KeyboardEvent): void;
    protected renderToolbar(): React.ReactNode;
    protected renderRow(row: DisassemblyRow): React.ReactNode;
    protected renderOperands(row: DisassemblyRow): React.ReactNode;
}
//# sourceMappingURL=emulator-disassembly-panel.d.ts.map