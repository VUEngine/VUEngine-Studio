import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { DisassemblyLine } from '../../common/vb-protocol';
import { DisassemblyRow } from '../core/emulator-disassembly';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
/**
 * The machine's run state, as far as this panel can drive it.
 *
 * Handed in by the dock from its host rather than reached through the debug
 * source, which reads the machine and deliberately cannot drive it — the same
 * arrangement the CPU Profiler's record button has. Absent on a host that
 * offers no control, and the panel then reads the program without being able
 * to stop it, which is what every host had before breakpoints existed.
 */
export interface VesExecutionControl {
    isPaused(): boolean;
    setPaused(paused: boolean): void;
}
/**
 * What the program is, as the machine reads it.
 *
 * The panel used to show forty-eight lines around the program counter and
 * nothing else — no names, nowhere to stop, and a window that redrew rather
 * than scrolled. Three things were added, and they lean on each other: the
 * symbols name what the listing points at, the listing can be walked and
 * followed, and the machine can be stopped somewhere while you read it.
 *
 * Stopping is the part with a cost. Breakpoints are checked on every
 * instruction the core executes, so they are armed in the core only while
 * this panel holds some, and given back when it is closed or hidden.
 */
export declare class DisassemblyPanel extends Panel {
    protected readonly control?: VesExecutionControl | undefined;
    protected lines: DisassemblyLine[];
    protected error?: string;
    protected follow: boolean;
    /** The address the window starts at while not following. */
    protected address: number;
    /** Where the machine is, which the gutter marks. */
    protected pc?: number;
    /** Armed addresses, which the gutter draws and the core is told about. */
    protected breakpoints: Set<number>;
    /** The line Run to Cursor means, set by clicking one. */
    protected selected?: number;
    /** Addresses jumped from, newest last. */
    protected history: number[];
    protected symbols?: SymbolIndex;
    protected lineTable?: VesLineTable;
    /**
     * Source files, by the path the line table names, split into lines.
     *
     * Null for one that could not be read, which is as worth remembering as
     * the text: without it the panel would ask for the same missing file on
     * every refresh.
     */
    protected sources: Map<string, string[] | null>;
    /** Whether the source view is on, which is a per-panel choice. */
    protected showSource: boolean;
    /** Held while the rail is being dragged, as the offset within the thumb. */
    protected railGrab?: number;
    protected watched?: Sim;
    protected readonly watching: DisposableCollection;
    protected scroller: HTMLElement | undefined;
    constructor(source: DebugSource, instanceId: string, control?: VesExecutionControl | undefined);
    protected pollHz(): number;
    protected refresh(): Promise<void>;
    /** Point the panel at whatever machine there is now. */
    protected followMachine(): void;
    /**
     * Set or clear one, through the shared set rather than a set of its own.
     *
     * The source line travels with it where there is one, so a breakpoint put
     * on an instruction here is the same breakpoint an editor would show on
     * that line — and survives a rebuild moving the code, which is what
     * `VesBreakpoints.reresolve` is for. Arming the machine is the dock's
     * business: this set is not this panel's alone, and it stays armed while
     * this panel is closed.
     */
    protected toggleBreakpoint(row: DisassemblyRow): void;
    protected get paused(): boolean;
    protected step(): Promise<void>;
    /**
     * One instruction, or the whole of the call it makes.
     *
     * The panel decides which, because it is the one holding the listing: a
     * call is stepped over by arming the instruction after it and letting the
     * machine run into it, and anything else is an ordinary step.
     */
    protected stepOver(): Promise<void>;
    protected runTo(address: number): Promise<void>;
    /**
     * The listing with everything the symbols can say about it.
     *
     * Worked out in `emulator-disassembly`, which is a pure function of the
     * lines and the symbol index and so can be run over a real build without
     * a browser — see `tests/disassembly-symbols-probe.mjs`.
     */
    protected rows(): DisassemblyRow[];
    /**
     * Read the files this window turned out to need, once each.
     *
     * From the render, because that is where it becomes known which files
     * those are, and asynchronously because nothing should wait on a disk to
     * draw a listing: the line arrives on the next refresh, which is a tenth
     * of a second later.
     */
    protected requestSources(rows: DisassemblyRow[]): void;
    /** One line of a source file, or undefined while it is not to hand. */
    protected sourceText(file: string, line: number): string | undefined;
    /** Stop following and leave the window where it is. */
    protected pin(): void;
    protected goTo(address: number, remember?: boolean): void;
    /**
     * Back to where the machine is, and stay with it.
     *
     * Following is otherwise given up by anything that moves the window on
     * purpose — see `pin` — so this is how somebody who has read their way
     * across the program gets back to what is running.
     */
    protected goToProgramCounter(): void;
    protected back(): void;
    /** Move the window by whole instructions, which is what a listing scrolls in. */
    protected scrollBy(instructions: number): void;
    /**
     * How far into the cartridge an address is, as a fraction.
     *
     * By ROM offset rather than by the address itself, because the same code
     * is reachable through two windows — the cartridge's own and the mirror
     * the machine boots from — and only the offset is the same in both. So
     * the thumb says where in the *program* the window is, whichever window
     * it happens to be reading through.
     */
    protected shareOf(address: number): number;
    protected get romBytes(): number;
    /** Where the thumb sits and how tall it is, down a rail of `height`. */
    protected railThumb(height: number): {
        top: number;
        size: number;
    };
    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void;
    protected scrubRail(box: DOMRect, clientY: number): void;
    protected releaseRail(event: React.PointerEvent<HTMLDivElement>): void;
    /** Take what the Go To box was given: an address, or a routine's name. */
    protected goToText(text: string): void;
    protected render(): React.ReactNode;
    /**
     * The scrollbar, over the cartridge rather than over the lines.
     *
     * The listing is a window of forty-eight instructions, not a list long
     * enough to scroll — so a scrollbar over its own content would say only
     * how far down forty-eight lines you are, which is nothing anybody wants
     * to know. This says where in the program the window sits, and takes you
     * anywhere in it. The Memory panel's rail answers the same question the
     * same way.
     *
     * Absent for a ROM whose size nothing reported: there is then no extent
     * to be a fraction of.
     */
    protected renderRail(): React.ReactNode;
    protected onKey(event: React.KeyboardEvent): void;
    protected renderToolbar(): React.ReactNode;
    protected renderRow(row: DisassemblyRow): React.ReactNode;
    protected renderOperands(row: DisassemblyRow): React.ReactNode;
}
//# sourceMappingURL=emulator-disassembly-panel.d.ts.map