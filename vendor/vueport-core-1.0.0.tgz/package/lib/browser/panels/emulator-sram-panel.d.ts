import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { SramRun } from '../../common/vb-protocol';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
interface SramBurst {
    id: number;
    at: number;
    until: number;
    write: boolean;
    pc: number;
    first: number;
    last: number;
    bytes: number;
    runs: SramRun[];
}
/**
 * What a game does with its save data, reads as well as writes: a save never read back, or read from the wrong
 * address, looks like one that works until the game is restarted. Both come from the core's access callbacks, not
 * polling, so nothing is missed, but each costs a call out of the core per access: requested only while its switch
 * is on (the switches decide what is captured, not just shown; Wario Land reads its save every frame) and released
 * when the panel closes. The map shows which bytes were touched and how, the list one row per instruction, and the
 * caller column names the instruction and narrows the list to it when clicked.
 */
export declare class SramPanel extends Panel {
    protected bursts: SramBurst[];
    protected byteCount: number;
    protected nextBurstId: number;
    protected touched: Uint8Array<ArrayBufferLike>;
    protected get shown(): number;
    protected get anything(): boolean;
    protected window: number;
    protected used: number;
    protected dropped: number;
    protected showWrites: boolean;
    protected showReads: boolean;
    protected caller?: number;
    protected opened: Set<number>;
    protected symbols?: SymbolIndex;
    protected names: Map<number, string | undefined>;
    protected watched?: Sim;
    protected readonly watching: DisposableCollection;
    constructor(source: DebugSource, instanceId: string);
    protected pollHz(): number;
    protected onAfterShow(msg: Message): void;
    protected onAfterHide(msg: Message): void;
    protected refresh(): Promise<void>;
    protected follow(): void;
    protected capture(sim: Sim, writes: boolean, reads: boolean): void;
    protected watchDirection(direction: 'writes' | 'reads', wanted: boolean): void;
    protected readCartRam(sim: Sim): void;
    protected setWindow(bytes: number): void;
    protected get extent(): number;
    protected append(runs: SramRun[]): void;
    protected record(run: SramRun, at: number): void;
    protected joins(burst: SramBurst, run: SramRun, first: number, last: number, at: number): boolean;
    protected touch(first: number, last: number, write: boolean): void;
    protected trim(): void;
    protected clear(): void;
    protected visible(): SramBurst[];
    protected nameOf(pc: number): string | undefined;
    protected callerLabel(pc: number): string;
    protected render(): React.ReactNode;
    protected renderToolbar(): React.ReactNode;
    protected renderSwitch(direction: 'writes' | 'reads', label: string): React.ReactNode;
    protected renderMap(): React.ReactNode;
    protected cellState(state: number): string;
    protected renderEmpty(): React.ReactNode;
    protected renderList(rows: SramBurst[]): React.ReactNode;
    protected toggle(id: number): void;
    protected renderBurst(burst: SramBurst, index: number): React.ReactNode;
    protected renderDetail(burst: SramBurst): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-sram-panel.d.ts.map