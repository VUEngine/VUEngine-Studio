import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { SramRun } from '../../common/vb-protocol';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
/**
 * One row of the list: what one instruction did to one stretch of the save,
 * for as long as it kept doing it.
 *
 * The unit the panel is built on, because it is the unit a game works in. A
 * save is written by a loop, and a loop is one thing that happened — five
 * hundred rows saying so are five hundred copies of the same fact, and they
 * push the only other thing that happened off the end of the list.
 *
 * The worker gathers each tick's share of that into a {@link SramRun}; this
 * is the same thing carried across ticks, which is what turns a save too long
 * for one tick into one row instead of several.
 */
interface SramBurst {
    /** Stable across renders, so React keeps the row somebody opened. */
    id: number;
    /** When the batch carrying the first run arrived. */
    at: number;
    /** When the batch carrying the most recent one did. */
    until: number;
    write: boolean;
    /** The instruction behind every byte in it. */
    pc: number;
    /** The lowest and highest save offset it has reached, inclusive. */
    first: number;
    last: number;
    /** How many bytes crossed the bus, across all of its runs. */
    bytes: number;
    /**
     * The runs themselves, in arrival order.
     *
     * Kept as they came rather than flattened to one object per byte: a game
     * reading its save on every frame would otherwise cost an allocation per
     * byte read, and where each byte went is arithmetic on the run.
     */
    runs: SramRun[];
}
/**
 * What a game is doing with its save data, as it does it.
 *
 * Reads as well as writes, which is the point: a save that is written and
 * never read back, or read back from the wrong address, looks exactly like a
 * save that works right up until the game is started again. Neither half can
 * be seen from the outside — cart RAM is memory like any other, and the
 * emulator only notices a save at all when it writes the file out.
 *
 * Both directions come from the core's own access callbacks rather than from
 * polling, so nothing is missed between frames. They cost a call out of the
 * core on every access, which is why each is asked for only while its switch
 * is on and both are given back when the panel closes. The switches are one
 * control rather than two views: what is not shown is not captured either,
 * because a game that reads its save on every frame — Wario Land does — costs
 * real speed to watch and nothing at all to leave alone.
 *
 * Three things are made of what arrives. The map says which of the save's
 * bytes have been touched and how, which is the question the panel exists for
 * — was it written and then read back from the same place — answered at a
 * glance rather than by scrolling. The list gathers what one instruction did
 * into one row, so a save is a line rather than a screenful. And the caller
 * column names the instruction where the symbols can, and narrows the list to
 * it when clicked, which is how the one routine writing where it should not
 * is found.
 */
export declare class SramPanel extends Panel {
    /** Oldest first, the way they happened; the list draws them the other way. */
    protected bursts: SramBurst[];
    /** Bytes held across all of them, against {@link MAX_BYTES}. */
    protected byteCount: number;
    protected nextBurstId: number;
    /**
     * What the save map has seen, one entry per {@link TOUCH_BYTES}; see
     * `TOUCHED_*`. Folded into cells when it is drawn, not before.
     */
    protected touched: Uint8Array<ArrayBufferLike>;
    /** Which marks the switches let through, for the map; see `TOUCHED_*`. */
    protected get shown(): number;
    /** Whether the map has anything to draw, which is what decides if it is. */
    protected get anything(): boolean;
    /**
     * How much of the bus the cartridge's save answers on.
     *
     * Not a constant, because it decides what an address means: the core
     * indexes its buffer by masked address, so the same byte of the chip is
     * reachable at several addresses and only this says which byte a given one
     * is. In practice a cartridge is now given the whole of Game Pak RAM and
     * nothing mirrors, but the panel still asks rather than assuming — a
     * machine set to emulate a narrower window is exactly the case somebody
     * would open this panel to watch.
     */
    protected window: number;
    /**
     * How far up the window the game has written, in bytes.
     *
     * Read from the machine rather than added up from what arrived here, and
     * the difference matters: the capture is given back whenever this panel is
     * behind another tab, so what arrived here is only what the game did while
     * somebody was watching. This is the whole of what the save holds — the
     * same figure the save file is written at — so the two numbers in the
     * caption cannot disagree with what ends up on disk.
     */
    protected used: number;
    /** How many batches arrived full, and so were cut short by the worker. */
    protected dropped: number;
    /** Which directions are being watched, and so which are being shown. */
    protected showWrites: boolean;
    protected showReads: boolean;
    /** The one instruction the list is narrowed to, if any. */
    protected caller?: number;
    /** Bursts opened to show the bytes inside them, by id. */
    protected opened: Set<number>;
    protected symbols?: SymbolIndex;
    /** A program counter to the routine holding it, worked out once each. */
    protected names: Map<number, string | undefined>;
    /** The machine being watched, and what was set up to watch it. */
    protected watched?: Sim;
    protected readonly watching: DisposableCollection;
    constructor(source: DebugSource, instanceId: string);
    /**
     * What arrives does so as events, but what is drawn is drawn on the poll.
     *
     * The worker hands over a batch every tick, fifty times a second, and
     * redrawing the list on each of them is redrawing it fifty times a second
     * — for a game that reads its save continuously, that is the whole list
     * reconciled on every frame, and it is the interface's own thread that
     * pays. Nothing is lost by drawing at the ordinary rate instead: the
     * batches are still taken as they come, and ten times a second is faster
     * than anybody reads.
     */
    protected pollHz(): number;
    /**
     * Give the capture back while this panel is behind another tab.
     *
     * A hidden panel is not being read, and watching the save is not free: it
     * is a call out of the core on every access the game makes, paid whether
     * or not anybody can see the result. The base class already stops the
     * poll on hide for the same reason; this is the half the poll does not
     * cover, because what fills this panel arrives as events.
     *
     * What was gathered stays gathered, so coming back to the tab shows what
     * was there rather than an empty panel — with the gap that the machine
     * carried on unwatched, which is the price of not slowing it down for a
     * panel nobody is looking at.
     */
    protected onAfterShow(msg: Message): void;
    protected onAfterHide(msg: Message): void;
    protected refresh(): Promise<void>;
    /**
     * Point the capture at whatever machine there is now.
     *
     * Closing a ROM takes the simulation away and opening one brings a new
     * one, so this covers both: what was gathered belonged to the machine
     * that has gone, and none of it describes the one that replaced it. A
     * reset keeps the same simulation, and is caught by `onRestart` instead.
     */
    protected follow(): void;
    protected capture(sim: Sim, writes: boolean, reads: boolean): void;
    /** Throw one of the two switches, which is a capture as much as a filter. */
    protected watchDirection(direction: 'writes' | 'reads', wanted: boolean): void;
    /** Take the window and the high-water mark the machine actually has. */
    protected readCartRam(sim: Sim): void;
    /**
     * Take the window the machine actually has.
     *
     * A different size is a different cartridge, and every offset already
     * gathered was masked with the old one — so rather than rescale them into
     * something that would read as fact, the panel starts again.
     *
     * The record is resized with it. It is kept at a fixed granularity
     * (see {@link TOUCH_BYTES}) so that the map widening as a game reaches
     * further up the save costs nothing; only the window itself changing,
     * which means a different cartridge, throws anything away.
     */
    protected setWindow(bytes: number): void;
    /**
     * How much of the save the map draws.
     *
     * The extent the game has reached, rounded up to a power of two, rather
     * than the window: with the whole of Game Pak RAM backed, a map of the
     * window would be one lit cell in 128 for every game ever made, and the
     * other 127 would be saying nothing about anything. Floored at the
     * baseline so that the ordinary case reads exactly as it always has.
     */
    protected get extent(): number;
    protected append(runs: SramRun[]): void;
    /** Put one run on the end of the burst it continues, or start a new one. */
    protected record(run: SramRun, at: number): void;
    /**
     * Whether a run carries on the burst before it.
     *
     * One instruction, one direction, no pause, and a stretch the burst
     * already reaches or is about to. A run the worker had to cut at the end
     * of a tick picks up where it left off, which is what this is for;
     * anything else is a second thing happening.
     */
    protected joins(burst: SramBurst, run: SramRun, first: number, last: number, at: number): boolean;
    /**
     * Mark the cells a run covered.
     *
     * Kept apart from the bursts on purpose: the map is every byte touched
     * since the machine started, and giving up the oldest row to stay inside
     * a cap is not the same as the game never having been there.
     */
    protected touch(first: number, last: number, write: boolean): void;
    /** Give up whole bursts from the front until both caps are met again. */
    protected trim(): void;
    protected clear(): void;
    protected visible(): SramBurst[];
    /**
     * What the build calls the routine a program counter is in, where there is
     * a build to ask.
     *
     * A ROM that was not built here has no symbols and so no names, which is
     * an ordinary state: the address is shown instead, and it still groups and
     * filters exactly the same way.
     */
    protected nameOf(pc: number): string | undefined;
    /** The caller as it is written in a row or a chip, named or bare. */
    protected callerLabel(pc: number): string;
    protected render(): React.ReactNode;
    protected renderToolbar(): React.ReactNode;
    protected renderSwitch(direction: 'writes' | 'reads', label: string): React.ReactNode;
    /**
     * The save itself, one cell per block of it, coloured by what happened
     * there.
     *
     * A cell is written if anything ever wrote it, read if it was only ever
     * read, and neither otherwise — the order matters, because a byte written
     * and read back is a byte that works and a byte only read is one the game
     * expected to find something in.
     */
    protected renderMap(): React.ReactNode;
    /** What a map cell's marks say, for its legend and for its tooltip. */
    protected cellState(state: number): string;
    protected renderEmpty(): React.ReactNode;
    /** Newest first, so a save that has just happened is where the eye is. */
    protected renderList(rows: SramBurst[]): React.ReactNode;
    /** Open a burst's bytes, or put them away again. */
    protected toggle(id: number): void;
    protected renderBurst(burst: SramBurst, index: number): React.ReactNode;
    /**
     * The bytes a burst carried, for when the run itself is not the question —
     * which byte went where, and how wide the instruction was.
     *
     * Cut off well short of a whole burst: a save's worth of rows under one
     * opened line would be the list this panel was rewritten to stop being,
     * and the beginning of a run is where anything surprising about it is.
     */
    protected renderDetail(burst: SramBurst): React.ReactNode;
}
export {};
//# sourceMappingURL=emulator-sram-panel.d.ts.map