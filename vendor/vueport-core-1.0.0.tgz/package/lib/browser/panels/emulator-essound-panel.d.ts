import * as React from 'react';
import { EsSoundPlayer } from '../emulator-essound-player';
import { DebugSource, Panel } from './emulator-panel';
export declare class EsSoundPanel extends Panel {
    protected readonly player: EsSoundPlayer;
    constructor(source: DebugSource, instanceId: string, player: EsSoundPlayer);
    protected startPolling(): void;
    protected refresh(): void;
    protected render(): React.ReactNode;
    protected renderHistory(): React.ReactNode;
}
//# sourceMappingURL=emulator-essound-panel.d.ts.map