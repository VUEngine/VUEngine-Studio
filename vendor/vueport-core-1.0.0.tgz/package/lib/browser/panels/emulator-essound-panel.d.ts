import * as React from 'react';
import { EsSoundNowPlaying, EsSoundPlayer, EsSoundTrack } from '../emulator-essound-player';
import { DebugSource, Panel } from './emulator-panel';
export declare class EsSoundPanel extends Panel {
    protected readonly player: EsSoundPlayer;
    constructor(source: DebugSource, instanceId: string, player: EsSoundPlayer);
    /**
     * Only the playback position moves between changes the player announces,
     * so polling redraws only while something is playing.
     */
    protected refresh(): void;
    protected render(): React.ReactNode;
    protected renderNowPlaying(entry: EsSoundNowPlaying): React.ReactNode;
    /**
     * The same block with nothing in it, so the list below does not jump
     * when a track starts or ends.
     */
    protected renderNothingPlaying(): React.ReactNode;
    /** Jump to where on the bar the click landed. */
    protected seek(event: React.MouseEvent<HTMLElement>, track: EsSoundTrack, length: number): void;
    protected renderPlayButton(track: EsSoundTrack, playing: boolean): React.ReactNode;
    protected renderHistory(): React.ReactNode;
}
//# sourceMappingURL=emulator-essound-panel.d.ts.map