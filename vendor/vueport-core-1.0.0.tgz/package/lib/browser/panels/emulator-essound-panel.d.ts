import * as React from 'react';
import { EsSoundNowPlaying, EsSoundPlayer, EsSoundTrack } from '../emulator-essound-player';
import { DebugSource, Panel } from './emulator-panel';
export declare class EsSoundPanel extends Panel {
    protected readonly player: EsSoundPlayer;
    constructor(source: DebugSource, instanceId: string, player: EsSoundPlayer);
    protected refresh(): void;
    protected render(): React.ReactNode;
    protected renderNowPlaying(entry: EsSoundNowPlaying): React.ReactNode;
    protected renderNothingPlaying(): React.ReactNode;
    protected seek(event: React.MouseEvent<HTMLElement>, track: EsSoundTrack, length: number): void;
    protected renderPlayButton(track: EsSoundTrack, playing: boolean): React.ReactNode;
    protected renderHistory(): React.ReactNode;
}
//# sourceMappingURL=emulator-essound-panel.d.ts.map