import { Message } from '@lumino/messaging';
import { ISignal, Signal } from '@lumino/signaling';
import { TabBar, Widget } from '@lumino/widgets';
import PerfectScrollbar from 'perfect-scrollbar';
/**
 * A dock tab bar whose tabs scroll when there are more than fit, with perfect-scrollbar like the shell's own
 * (Theia's ScrollableTabBar), attached here as that class expects shell markup this dock does not have.
 * The scrolling container wraps the list of tabs rather than being the list: the tab bar re-renders the list
 * from a virtual DOM, and anything the scrollbar put inside it would go with the old nodes.
 */
export declare class VueportTabBar extends TabBar<Widget> {
    protected readonly contentContainer: HTMLElement;
    protected readonly resetButton: HTMLElement;
    protected scrollBar: PerfectScrollbar | undefined;
    protected readonly _resetRequested: Signal<this, void>;
    get resetRequested(): ISignal<this, void>;
    constructor(options?: TabBar.IOptions<Widget>);
    protected readonly onResetClicked: (event: Event) => void;
    /**
     * Keeps a double-click on the tabs from the ancestors: Theia opens an untitled editor on a double-click in
     * empty lm-TabBar-content space, which these tab bars share, and the dock sits inside one of its widgets.
     * stopPropagation rather than preventDefault, as TabBar's own listener renames a tab. The dock opens the panel
     * picker on it in the capture phase (see addOnDoubleClickListener).
     */
    protected readonly containDoubleClick: (event: Event) => void;
    protected onAfterAttach(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    protected onUpdateRequest(msg: Message): void;
    protected onResize(msg: Widget.ResizeMessage): void;
}
//# sourceMappingURL=emulator-tab-bar.d.ts.map