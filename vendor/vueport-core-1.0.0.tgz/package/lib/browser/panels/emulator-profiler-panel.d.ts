import { Message } from '@lumino/messaging';
import * as React from 'react';
import { LiveProfileFrame, LiveProfileFunction, LiveProfileSnapshot, LiveMachineCounters } from '../../common/emulator-live-profile';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
declare enum ProfilerStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    WAITING = "waiting"
}
interface ProfilerRow extends LiveProfileFunction {
    name: string;
    section: string;
    root: boolean;
}
interface ProfilerGroup {
    id: string;
    name: string;
    self: number;
    selfAvg: number;
    selfPeak: number;
    calls: number;
    functions: number;
    rows: ProfilerRow[];
    leaf?: ProfilerRow;
    hidden?: boolean;
}
type ProfilerColumn = 'name' | 'self' | 'avg' | 'peak' | 'total' | 'calls' | 'cost';
interface ProfilerBaseline {
    shares: Map<string, number>;
    names: Map<string, string>;
    busy: number;
}
export interface VesProfileRecordingControl {
    isProfiling(): boolean;
    toggleProfiling(): void;
}
/**
 * Where the machine's clocks go, frame by frame, while it runs; the recording profiler only answers once the run is
 * over. Measures clocks, not samples: the execute callback reads the clock budget word the core decrements, so
 * every instruction's cost is exact. Percentages are shares of a real frame (VB_CLOCKS_PER_BUFFER clocks at 20 MHz).
 * The timeline draws the whole window so a bad frame can be seen; clicking one pins it, and the pinned frame is kept
 * after it scrolls out of the window.
 * - Idle is measured, not inferred: a game waiting for the next frame either halts or spins (VUEngine's frame loop
 *   is a bare `while(!hasGameFrameStarted())`). VesLiveProfileCollector.harvestWait finds both, or the headline would
 *   read 100% on most games; a found wait loop is named in the headline.
 * - Without the .elf beside the ROM every row is an address; only the labels change.
 * - The first row is not a function but what ran in the call stack from before profiling began
 *   (VES_LIVE_PROFILE_ROOT).
 */
export declare class ProfilerPanel extends Panel {
    protected readonly recording?: VesProfileRecordingControl | undefined;
    protected static readonly PROFILER_POLL_HZ = 5;
    protected status: ProfilerStatus;
    protected snapshot?: LiveProfileSnapshot;
    protected symbols?: SymbolIndex;
    protected armed?: Sim;
    protected error?: string;
    protected reading: boolean;
    protected sort: TableSort<ProfilerColumn>;
    protected showQuiet: boolean;
    protected functionFilter: string;
    protected pin?: number;
    protected pinned?: LiveProfileFrame;
    protected readonly sectionOpen: Map<string, boolean>;
    protected autoOpen?: string;
    protected baseline?: ProfilerBaseline;
    constructor(source: DebugSource, instanceId: string, recording?: VesProfileRecordingControl | undefined);
    protected pollHz(): number;
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    dispose(): void;
    protected disarm(): void;
    protected refresh(): Promise<void>;
    protected capture(snapshot: LiveProfileSnapshot, wanted: number): void;
    protected render(): React.ReactNode;
    protected renderRecording(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    protected renderMachine(machine: LiveMachineCounters): React.ReactNode;
    protected renderSummary(snapshot: LiveProfileSnapshot): React.ReactNode;
    protected renderTimeline(snapshot: LiveProfileSnapshot): React.ReactNode;
    protected onTimelineKey(event: React.KeyboardEvent, oldest: number, newest: number): void;
    protected togglePin(number: number): void;
    protected setPin(number: number): void;
    protected unpin(): void;
    protected renderTable(snapshot: LiveProfileSnapshot, { groups, quiet, filtered }: {
        groups: ProfilerGroup[];
        quiet: number;
        filtered: boolean;
    }): React.ReactNode;
    protected renderSection(group: ProfilerGroup, snapshot: LiveProfileSnapshot): React.ReactNode;
    protected renderRow(row: ProfilerRow, snapshot: LiveProfileSnapshot, nested: boolean): React.ReactNode;
    protected renderBaseline(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): React.ReactNode;
    protected renderMovers(snapshot: LiveProfileSnapshot, rows: ProfilerRow[], baseline: ProfilerBaseline): React.ReactNode;
    protected takeBaseline(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): ProfilerBaseline;
    protected shares(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): Map<string, {
        name: string;
        share: number;
    }>;
    protected isOpen(id: string): boolean;
    protected toggleSection(id: string): void;
    protected weight(row: {
        self: number;
        selfAvg: number;
    }): number;
    protected groups(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): {
        groups: ProfilerGroup[];
        quiet: number;
        filtered: boolean;
    };
    protected rememberAutoOpen(groups: ProfilerGroup[]): void;
    protected rows(snapshot: LiveProfileSnapshot): ProfilerRow[];
    protected describe(address: number, other: string): {
        name: string;
        section: string;
        root: boolean;
    };
}
export {};
//# sourceMappingURL=emulator-profiler-panel.d.ts.map