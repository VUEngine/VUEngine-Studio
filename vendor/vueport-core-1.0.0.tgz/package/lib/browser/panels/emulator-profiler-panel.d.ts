import { Message } from '@lumino/messaging';
import * as React from 'react';
import { LiveProfileFrame, LiveProfileFunction, LiveProfileSnapshot } from '../../common/emulator-live-profile';
import { SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel } from './emulator-panel';
import { TableSort } from './emulator-sortable-table';
/** Why the panel has nothing to show, when it has nothing to show. */
declare enum ProfilerStatus {
    OK = "ok",
    NOT_RUNNING = "notRunning",
    WAITING = "waiting"
}
/** One row of the table, named and placed in a section. */
interface ProfilerRow extends LiveProfileFunction {
    name: string;
    section: string;
    /** True for the row that holds what was already running when it began. */
    root: boolean;
}
/**
 * A section of the table, and the functions nested under it.
 *
 * Sections and functions used to be two tables side by side, which asked the
 * reader to hold a name in their head while they looked for it in the other
 * one. They are the same clocks grouped twice, so this is one group per
 * section with its own functions inside it.
 */
interface ProfilerGroup {
    /** Sorting and grouping key, since two sections can be shown alike. */
    id: string;
    name: string;
    /** Clocks in the section itself, in the frame on show and over the window. */
    self: number;
    selfAvg: number;
    selfPeak: number;
    calls: number;
    /** How many functions of the section ran, for the row's own hint. */
    functions: number;
    /** The functions listed under it, after the filter and the quiet fold. */
    rows: ProfilerRow[];
    /**
     * The single row a group *is*, rather than contains.
     *
     * "Already running" is not a section with functions in it — it is one row
     * that no function name would improve — so it sits at the top level with
     * the sections rather than alone inside one.
     */
    leaf?: ProfilerRow;
    /**
     * A leaf the filter or the quiet fold has taken out.
     *
     * A section stays listed whatever happens to the rows inside it, because
     * the figures on it are the section's own and still true. A leaf has no
     * figures of its own to keep: hiding its row is hiding it.
     */
    hidden?: boolean;
}
type ProfilerColumn = 'name' | 'self' | 'avg' | 'peak' | 'total' | 'calls' | 'cost';
/** What a reader saved to compare against, and when. */
interface ProfilerBaseline {
    /** Each section's average share of a frame, as a percentage. */
    shares: Map<string, number>;
    /** What it was called, for a section that has since stopped running. */
    names: Map<string, string>;
    /** The busy average the whole thing had, which is the headline figure. */
    busy: number;
}
/**
 * The other profiler, the recording one, as far as this panel can drive it.
 *
 * Handed in by the dock from its host rather than reached through the debug
 * source, which is read-only on purpose; absent on a host that offers no
 * recording, and the panel then shows no button for it.
 */
export interface VesProfileRecordingControl {
    isProfiling(): boolean;
    /** Start a recording — the host asks first — or stop one and export it. */
    toggleProfiling(): void;
}
/**
 * Where the machine's clocks are going, frame by frame, while it runs.
 *
 * The emulator has had a profiler since Phase 6, but of the other kind: record
 * a session, replay it afterwards following every instruction, export the call
 * tree. That answers "where did those thirty seconds go" exactly, and answers
 * nothing at all until the run is over. This is the question a developer asks
 * while they are still holding the controller — is this frame too expensive,
 * and what in it — so it measures the run as it happens and redraws a few
 * times a second.
 *
 * What it measures is clocks, not samples: the core decrements the clock
 * budget it is given as it runs, and the execute callback can read that word,
 * so every instruction's cost is known to the clock rather than estimated from
 * how often a sampler happened to land on it. Percentages here are shares of a
 * real frame — {@link VB_CLOCKS_PER_BUFFER} clocks at 20 MHz — and not shares
 * of a sample count.
 *
 * The panel is built around one frame at a time. The timeline draws the whole
 * window so a bad frame can be *seen* rather than averaged away, and clicking
 * one pins it: the table below then says where that frame's clocks went, and
 * goes on saying it after the frame has scrolled out of the window, because
 * what was pinned is kept rather than asked for again.
 *
 * Three things about the figures are worth knowing before reading them:
 *
 * - **Idle is measured, not inferred.** A game waiting for the next frame
 *   either `halt`s, which stops the processor while the clock runs on, or
 *   spins in a loop until the interrupt arrives — VUEngine's frame loop is a
 *   bare `while(!hasGameFrameStarted())`, and a spinning machine is busy by
 *   every measure the processor has. Both are found: see
 *   {@link VesLiveProfileCollector.harvestWait}, which is what keeps the
 *   headline from reading 100% on most of the games ever written for the
 *   machine. Where a wait was found, the headline says so and names it, since
 *   a loop is only called waiting by measurement rather than by declaration.
 * - **Names need the build.** Without the `.elf` beside the ROM every row is an
 *   address. The profile is exactly as accurate either way; only the labels
 *   change.
 * - **The first row is not a function.** Profiling starts in the middle of a
 *   game, inside a stack of calls that happened before anything was watching,
 *   and what those frames run collects under one row — see
 *   {@link VES_LIVE_PROFILE_ROOT}.
 */
export declare class ProfilerPanel extends Panel {
    protected readonly recording?: VesProfileRecordingControl | undefined;
    /**
     * Slower than the default ten.
     *
     * Every refresh aggregates the whole window — a hundred frames of a few
     * hundred functions — on the worker thread, which is the thread that is
     * also emulating. Five times a second is faster than a reader can take a
     * table in, and leaves the worker to get on with it.
     */
    protected static readonly PROFILER_POLL_HZ = 5;
    protected status: ProfilerStatus;
    protected snapshot?: LiveProfileSnapshot;
    protected symbols?: SymbolIndex;
    /** The machine profiling was switched on for, so a change of seat re-arms. */
    protected armed?: Sim;
    protected error?: string;
    /** Guards against a slow read being overlapped by the next tick. */
    protected reading: boolean;
    protected sort: TableSort<ProfilerColumn>;
    /** Whether functions too small to matter are listed as well. */
    protected showQuiet: boolean;
    /**
     * Narrows the function list by name. Not remembered across sessions: a
     * filter is a question about the frame in front of you, and a profiler
     * that came back silently hiding most of its rows would be read as a
     * profiler that had stopped seeing them.
     */
    protected functionFilter: string;
    /**
     * The frame the reader clicked in the timeline, by its number.
     *
     * Set the moment it is clicked; {@link pinned} follows on the next read,
     * which is what actually freezes the figures.
     */
    protected pin?: number;
    /**
     * That frame, kept.
     *
     * The window is a couple of seconds long, so a pinned frame leaves it
     * almost immediately — and a spike you cannot go on looking at is no
     * better than a peak percentage. Once the worker has handed it over it
     * stays here until the pin is dropped.
     */
    protected pinned?: LiveProfileFrame;
    /** Sections the reader has opened or closed, over {@link autoOpen}. */
    protected readonly sectionOpen: Map<string, boolean>;
    /**
     * The section opened without being asked, once, on the first figures.
     *
     * A table of nothing but collapsed section rows is a worse first sight
     * than the list of functions this replaced, and a build with no symbols
     * has a single section holding everything — which collapsed would be a
     * panel with one row in it. So the busiest section starts open. Decided
     * once rather than every refresh, because the busiest section changes
     * places while a game runs and a table that opened and shut by itself
     * would be unusable.
     */
    protected autoOpen?: string;
    /** What the figures are being compared against, if anything. */
    protected baseline?: ProfilerBaseline;
    constructor(source: DebugSource, instanceId: string, recording?: VesProfileRecordingControl | undefined);
    protected pollHz(): number;
    /**
     * Profiling is on only while this panel is.
     *
     * It costs a callback on every emulated instruction — measured at 1.5x on
     * a call-heavy loop, which the core has the headroom for but which nobody
     * should be paying for a panel they closed. So the panel owns the switch,
     * and every way out of view turns it off again.
     */
    protected onAfterHide(msg: Message): void;
    protected onBeforeDetach(msg: Message): void;
    dispose(): void;
    protected disarm(): void;
    protected refresh(): Promise<void>;
    /**
     * Keep the frame that was pinned, or drop the pin if it got away.
     *
     * A frame can only be unpacked while it is still in the window, and the
     * window is two seconds long — so a click that arrives late has nothing
     * to pin, and the honest response is to go back to the live figures
     * rather than to show an empty table headed by a frame number.
     */
    protected capture(snapshot: LiveProfileSnapshot, wanted: number): void;
    protected render(): React.ReactNode;
    /**
     * The switch for the recording profiler, above the live figures.
     *
     * Here rather than in the title bar because it is this panel's question
     * asked the other way: the figures below answer "what is this frame
     * costing" while the game runs, a recording answers "where did the whole
     * session go" once it is over. Shown while there is a machine to record,
     * and always while a recording runs, so it can be stopped from here.
     */
    protected renderRecording(): React.ReactNode;
    protected renderEmpty(): React.ReactNode;
    /**
     * The headline and the window it came out of.
     *
     * Busy rather than idle, because that is the number a developer is trying
     * to keep down, and against the frame rather than against what was
     * accounted for — a frame that overran is over 100% and should look it.
     * One frame at a time: the newest, or the pinned one, which is the whole
     * point of being able to pin one.
     */
    protected renderSummary(snapshot: LiveProfileSnapshot): React.ReactNode;
    /**
     * The window, drawn.
     *
     * The hundred frames behind the averages were already being kept; all a
     * peak percentage ever said about them was that one of them was bad. Here
     * they are one bar each, with the frame budget as a line across them, so a
     * spike is a thing you can point at — and clicking one pins it, which is
     * the only way to ask what was *in* a frame that has already gone.
     */
    protected renderTimeline(snapshot: LiveProfileSnapshot): React.ReactNode;
    /**
     * Walking the timeline from the keyboard.
     *
     * The chart is one tab stop, so the arrows have to be what moves along it.
     * They move the pin rather than a cursor, because a highlight that is not
     * a pin would be a second kind of selection that does nothing.
     */
    protected onTimelineKey(event: React.KeyboardEvent, oldest: number, newest: number): void;
    protected togglePin(number: number): void;
    protected setPin(number: number): void;
    protected unpin(): void;
    /**
     * One table: sections, with their functions inside them.
     *
     * The frame columns are whichever frame the panel is on — the newest, or
     * the one pinned — and the window columns beside them are always the
     * window, which is what makes a single frame readable: 41% of this frame
     * against 12% on average is a different fact from 41% against 40%.
     */
    protected renderTable(snapshot: LiveProfileSnapshot, { groups, quiet, filtered }: {
        groups: ProfilerGroup[];
        quiet: number;
        filtered: boolean;
    }): React.ReactNode;
    /** A section's own row: the sum of what is folded underneath it. */
    protected renderSection(group: ProfilerGroup, snapshot: LiveProfileSnapshot): React.ReactNode;
    protected renderRow(row: ProfilerRow, snapshot: LiveProfileSnapshot, nested: boolean): React.ReactNode;
    /**
     * What the figures are being measured against, if anything.
     *
     * The question a profiler is usually open for is not "what does this
     * cost" but "did what I just changed help", and answering that from
     * memory across a rebuild is how a percent and a half goes unnoticed.
     * Averages rather than the pinned frame: a baseline is a claim about how
     * the game runs, and one frame is not one.
     */
    protected renderBaseline(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): React.ReactNode;
    /** The sections that have moved furthest since the baseline was taken. */
    protected renderMovers(snapshot: LiveProfileSnapshot, rows: ProfilerRow[], baseline: ProfilerBaseline): React.ReactNode;
    protected takeBaseline(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): ProfilerBaseline;
    /**
     * Every section's average share of a frame, whatever is being listed.
     *
     * A baseline is taken from the whole profile rather than from the table:
     * a filter is a question about what to show, and a comparison that
     * quietly left out whatever was typed at the time would report every
     * section it had not been looking at as having appeared out of nowhere.
     */
    protected shares(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): Map<string, {
        name: string;
        share: number;
    }>;
    protected isOpen(id: string): boolean;
    protected toggleSection(id: string): void;
    /**
     * The clocks a row is read by: the frame on show, or the window average.
     *
     * The share bar and the sections' order both follow this, so pinning a
     * frame reorders the table into what that frame cost rather than leaving
     * it sorted by a window the reader has just stepped out of.
     */
    protected weight(row: {
        self: number;
        selfAvg: number;
    }): number;
    /**
     * The snapshot as sections with functions under them, sorted and folded.
     *
     * Section figures are the whole section, whatever the filter is doing to
     * the rows inside it: the filter asks which functions to list, not what a
     * section costs, and a section total that moved as you typed would be a
     * different number every keystroke.
     */
    protected groups(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): {
        groups: ProfilerGroup[];
        quiet: number;
        filtered: boolean;
    };
    /** Pick the section that starts open, once — see {@link autoOpen}. */
    protected rememberAutoOpen(groups: ProfilerGroup[]): void;
    /**
     * The snapshot's addresses, named and grouped.
     *
     * With a frame pinned the rows *are* that frame: only what ran in it, with
     * that frame's own clocks in the frame columns, joined to the window for
     * the averages beside them. A function the window still remembers but that
     * frame never ran is not a row — it would be a line of zeroes in a table
     * headed "where the clocks went".
     */
    protected rows(snapshot: LiveProfileSnapshot): ProfilerRow[];
    /**
     * What to call an address, and which section it belongs to.
     *
     * Three kinds of row, and the two that are not functions are the ones a
     * reader would otherwise puzzle over: the frames that were already open
     * when profiling began, and the interrupt handlers hardware enters without
     * a call.
     */
    protected describe(address: number, other: string): {
        name: string;
        section: string;
        root: boolean;
    };
}
export {};
//# sourceMappingURL=emulator-profiler-panel.d.ts.map