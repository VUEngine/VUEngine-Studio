import { Message } from '@lumino/messaging';
import * as React from 'react';
import { RumbleCommand, RumbleState, VueportRumblePack } from '../../common/emulator-rumble';
import { DebugSource, Panel } from './emulator-panel';
/**
 * What the running game asks a rumble pack to do, and whether one is plugged in. All but the connection block
 * shows either way, as commands are read off the emulated link port, also where no serial port can be opened
 * (see DecodingRumblePack). Only a second player stops it: cable and pack share the socket, so during a session
 * the port is the cable's (see applyRumbleForwarding on the widget). Connection and bytes arrive as events, so
 * the inherited polling only notices a simulation appearing or going away
 */
export declare class RumblePackPanel extends Panel {
    protected readonly rumblePack: VueportRumblePack;
    protected static readonly MOTOR_MIN_MS = 120;
    protected static readonly MOTOR_STEP_MS = 60;
    protected detecting: boolean;
    protected error: string | undefined;
    protected motorTimer: ReturnType<typeof setTimeout> | undefined;
    constructor(source: DebugSource, instanceId: string, rumblePack: VueportRumblePack);
    protected onAfterAttach(msg: Message): void;
    protected pollHz(): number;
    protected refresh(): void;
    protected detect(): Promise<void>;
    protected render(): React.ReactNode;
    protected renderConnection(state: RumbleState): React.ReactNode;
    protected renderMotor(strength: number | undefined, frequency: number | undefined): React.ReactNode;
    /**
     * How hard to draw the motor shaking, or undefined for still. Effects end on their own after their measured
     * length (isRumblePlaying), ramps change strength (rumbleEffectAmplitudeAt), and the shortest are floored at
     * MOTOR_MIN_MS. Bytes bring their own redraws; the timer covers ramp steps and effects nothing came to end
     */
    protected motorStrength(state: RumbleState): number | undefined;
    protected renderEffect(state: RumbleState): React.ReactNode;
    protected renderCommands(commands: RumbleCommand[]): React.ReactNode;
}
//# sourceMappingURL=emulator-rumble-pack-panel.d.ts.map