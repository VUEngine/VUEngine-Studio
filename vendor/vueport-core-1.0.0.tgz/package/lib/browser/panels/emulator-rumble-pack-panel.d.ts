import { Message } from '@lumino/messaging';
import * as React from 'react';
import { RumbleCommand, RumbleState, VueportRumblePack } from '../../common/emulator-rumble';
import { DebugSource, Panel } from './emulator-panel';
/**
 * What the running game is asking a rumble pack to do, and whether one is
 * plugged in to do it.
 *
 * Everything but the connection block is shown either way. The rumble commands
 * a game broadcasts are read off the emulated link port, not off the hardware,
 * so decoding them is just as useful to somebody who owns no pack — which is
 * why the port is read for as long as a game is running, whether or not one is
 * plugged in and whether or not this host could even take one. A page cannot
 * open a serial port and still shows everything here but the buzz; see
 * `DecodingRumblePack`.
 *
 * The one thing that stops it is a second player: a link cable and a pack want
 * the same socket, so while a session is running the port is the cable's and
 * this panel says so rather than decoding the traffic between the two machines
 * as rumble commands nobody sent. See `applyRumbleForwarding` on the widget.
 *
 * Connection is pushed as an event, and so is every byte the port carries, so
 * the inherited polling is slowed right down; what it is left doing is
 * noticing a simulation appearing or going away.
 */
export declare class RumblePackPanel extends Panel {
    protected readonly rumblePack: VueportRumblePack;
    /**
     * The least time the motor box shakes for, in ms.
     *
     * A floor rather than an addition: an effect runs for its own measured
     * length now (see `RUMBLE_EFFECT_SHAPES`), and the shortest of them is a
     * 69 ms tick — four frames, which is a flicker rather than a shake. So
     * the short ones are stretched to where the eye can catch them and
     * everything else is left exactly as long as it really is.
     */
    protected static readonly MOTOR_MIN_MS = 120;
    /**
     * How often the box is redrawn while an effect runs, in ms.
     *
     * Only the 48 ramps need it — they change strength as they go, and a box
     * redrawn twice over a 320 ms rise would show two steps of it. Flat
     * effects look the same at every redraw, so this costs them nothing but
     * the redraw itself, which is a handful of nodes.
     */
    protected static readonly MOTOR_STEP_MS = 60;
    /** Set while a detection triggered from here is in flight. */
    protected detecting: boolean;
    /** Why the last detection failed, if it did. Cleared by the next attempt. */
    protected error: string | undefined;
    /** The redraw that carries a shake on, and the one that ends it. */
    protected motorTimer: ReturnType<typeof setTimeout> | undefined;
    constructor(source: DebugSource, instanceId: string, rumblePack: VueportRumblePack);
    protected onAfterAttach(msg: Message): void;
    protected pollHz(): number;
    protected refresh(): void;
    protected detect(): Promise<void>;
    protected render(): React.ReactNode;
    /**
     * The whole connection story, in one box.
     *
     * It used to be spread over three: a banner saying whether a pack was
     * attached, a note under it about the link cable, and rows further down
     * for the board, its USB ids and what the port was carrying. Between them
     * they answer one question — why is nothing buzzing — and answering it
     * meant reading all three and joining them up. So they are one line now:
     * what is attached, what the port is doing with it, and the one button
     * that can change the answer.
     *
     * There are exactly three situations, and the box says which it is in its
     * own right rather than by the absence of something: a pack is attached; a
     * link cable has the port the pack would have used; or there is no pack,
     * in which case the commands below are still worth reading.
     */
    protected renderConnection(state: RumbleState): React.ReactNode;
    /**
     * The pack itself: a box that shakes while the motor is running.
     *
     * The rest of the panel is numbers, and numbers are read one after another;
     * an effect is over by the time the third of them has been. This is the one
     * part that can be taken in without reading, which is what makes it worth
     * the space — and it is as true with no pack attached, where it shows what
     * a pack would be doing with the commands the game is sending.
     */
    protected renderMotor(strength: number | undefined, frequency: number | undefined): React.ReactNode;
    /**
     * How hard to draw the motor as shaking, or undefined for still.
     *
     * Three things sit between `state.playing` and the answer. An effect ends
     * on its own after the length it was measured to run, whether or not the
     * game bothers to say so, which is `isRumblePlaying`. A ramp is a
     * different strength at its start than at its end, which is
     * `rumbleEffectAmplitudeAt`. And the shortest effects in the library are
     * over in a few frames, which is where {@link MOTOR_MIN_MS} comes in.
     *
     * The bytes bring their own redraws — the service fires on every one of
     * them — so the timer here is for the moments no byte arrives for: the
     * next step of a ramp, and the end of an effect nothing came to end.
     */
    protected motorStrength(state: RumbleState): number | undefined;
    /**
     * The effect the forwarded bytes add up to, laid out the way the rumble
     * effect editor lays out the same settings.
     *
     * Every field is filled in only over time: the engine skips a command
     * whose value has not changed since the last effect (`Rumble.c` caches
     * them), so a game that never varies its frequency sends it once and a
     * field that has not been seen yet is genuinely unknown rather than zero.
     */
    protected renderEffect(state: RumbleState): React.ReactNode;
    /** The forwarded bytes mapped back to what each of them asked for. */
    protected renderCommands(commands: RumbleCommand[]): React.ReactNode;
}
//# sourceMappingURL=emulator-rumble-pack-panel.d.ts.map