/**
 * The few parts of WebXR, and of its Layers module, that playing in a headset
 * uses — see `emulator-xr.ts`.
 *
 * Stated here rather than taken from `@types/webxr`, so that nothing that
 * builds against this package needs those types too, and kept out of the
 * package's index for the same reason.
 */
export interface XrViewport {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}
export interface XrRigidTransform {
    readonly matrix: Float32Array;
    readonly inverse: XrRigidTransform;
}
export type XrEye = 'left' | 'right' | 'none';
export interface XrView {
    readonly eye: XrEye;
    readonly projectionMatrix: Float32Array;
    readonly transform: XrRigidTransform;
}
export interface XrSpace extends EventTarget {
}
export interface XrFrame {
    getViewerPose(space: XrSpace): {
        readonly views: readonly XrView[];
    } | null;
    getPose?(space: XrSpace, baseSpace: XrSpace): {
        readonly transform: XrRigidTransform;
    } | null;
}
export interface XrInputSource {
    readonly handedness: 'none' | 'left' | 'right';
    readonly gamepad?: Gamepad | null;
    /** Where the controller points from, and along its -Z axis. */
    readonly targetRaySpace?: XrSpace;
}
export interface XrSession extends EventTarget {
    readonly enabledFeatures?: readonly string[];
    readonly supportedFrameRates?: Float32Array | null;
    readonly visibilityState: 'visible' | 'visible-blurred' | 'hidden';
    readonly inputSources: ArrayLike<XrInputSource>;
    updateTargetFrameRate?(rate: number): Promise<void>;
    updateRenderState(state: {
        baseLayer?: XrWebGlLayer;
        layers?: unknown[];
    }): void;
    requestReferenceSpace(type: string): Promise<XrSpace>;
    requestAnimationFrame(callback: (time: number, frame: XrFrame) => void): number;
    cancelAnimationFrame(handle: number): void;
    end(): Promise<void>;
}
export interface XrSystem {
    isSessionSupported(mode: string): Promise<boolean>;
    requestSession(mode: string, init?: {
        optionalFeatures?: string[];
    }): Promise<XrSession>;
    /** For `devicechange`: a headset connected or gone — a PC's, through Link or a streamer, comes and goes. */
    addEventListener?(type: 'devicechange', listener: () => void): void;
    removeEventListener?(type: 'devicechange', listener: () => void): void;
}
export interface XrWebGlLayer {
    readonly framebuffer: WebGLFramebuffer | null;
    getViewport(view: XrView): XrViewport | null;
}
export interface XrSubImage {
    readonly colorTexture: WebGLTexture;
    readonly viewport: XrViewport;
    /** The whole texture's size, which the viewport is a part of. */
    readonly colorTextureWidth?: number;
    readonly colorTextureHeight?: number;
}
export interface XrQuadLayer {
    /** Writable: a quad layer can be resized and moved while it is shown. */
    width: number;
    height: number;
    transform: XrRigidTransform;
    /** Whether the compositor blends the layer by its texture's (premultiplied) alpha. */
    blendTextureSourceAlpha?: boolean;
}
export interface XrWebGlBinding {
    createQuadLayer(init: {
        space: XrSpace;
        viewPixelWidth: number;
        viewPixelHeight: number;
        layout: 'stereo-left-right' | 'mono';
        textureType: 'texture';
        isStatic: boolean;
        width: number;
        height: number;
        transform: XrRigidTransform;
    }): XrQuadLayer;
    getSubImage(layer: XrQuadLayer, frame: XrFrame, eye?: XrEye): XrSubImage;
    /** A layer over the whole view, drawn per eye; where the browser has them. */
    createProjectionLayer?(init: {
        textureType: 'texture';
        scaleFactor?: number;
    }): XrProjectionLayer;
    getViewSubImage?(layer: XrProjectionLayer, view: XrView): XrSubImage;
}
/** A layer over the whole of each eye's view. Nothing of it is used here but its existence. */
export interface XrProjectionLayer {
}
export interface XrGlobals {
    XRWebGLLayer?: new (session: XrSession, gl: WebGL2RenderingContext) => XrWebGlLayer;
    XRWebGLBinding?: new (session: XrSession, gl: WebGL2RenderingContext) => XrWebGlBinding;
    XRRigidTransform?: new (position?: DOMPointInit, orientation?: DOMPointInit) => XrRigidTransform;
}
export declare function xrSystem(): XrSystem | undefined;
export declare const xrGlobals: XrGlobals;
//# sourceMappingURL=emulator-xr-webxr.d.ts.map