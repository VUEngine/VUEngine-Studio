export interface XrViewport {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}
export interface XrRigidTransform {
    readonly matrix: Float32Array;
    readonly inverse: XrRigidTransform;
}
export type XrEye = 'left' | 'right' | 'none';
export interface XrView {
    readonly eye: XrEye;
    readonly projectionMatrix: Float32Array;
    readonly transform: XrRigidTransform;
}
export interface XrSpace extends EventTarget {
}
export interface XrFrame {
    getViewerPose(space: XrSpace): {
        readonly views: readonly XrView[];
    } | null;
    getPose?(space: XrSpace, baseSpace: XrSpace): {
        readonly transform: XrRigidTransform;
    } | null;
}
export interface XrInputSource {
    readonly handedness: 'none' | 'left' | 'right';
    readonly gamepad?: Gamepad | null;
    readonly targetRaySpace?: XrSpace;
}
export interface XrSession extends EventTarget {
    readonly enabledFeatures?: readonly string[];
    readonly supportedFrameRates?: Float32Array | null;
    readonly visibilityState: 'visible' | 'visible-blurred' | 'hidden';
    readonly inputSources: ArrayLike<XrInputSource>;
    updateTargetFrameRate?(rate: number): Promise<void>;
    updateRenderState(state: {
        baseLayer?: XrWebGlLayer;
        layers?: unknown[];
    }): void;
    requestReferenceSpace(type: string): Promise<XrSpace>;
    requestAnimationFrame(callback: (time: number, frame: XrFrame) => void): number;
    cancelAnimationFrame(handle: number): void;
    end(): Promise<void>;
}
export interface XrSystem {
    isSessionSupported(mode: string): Promise<boolean>;
    requestSession(mode: string, init?: {
        optionalFeatures?: string[];
    }): Promise<XrSession>;
    offerSession?(mode: string, init?: {
        optionalFeatures?: string[];
    }): Promise<XrSession>;
    addEventListener?(type: 'devicechange', listener: () => void): void;
    removeEventListener?(type: 'devicechange', listener: () => void): void;
}
export interface XrWebGlLayer {
    readonly framebuffer: WebGLFramebuffer | null;
    getViewport(view: XrView): XrViewport | null;
}
export interface XrSubImage {
    readonly colorTexture: WebGLTexture;
    readonly viewport: XrViewport;
    readonly colorTextureWidth?: number;
    readonly colorTextureHeight?: number;
}
export interface XrQuadLayer {
    width: number;
    height: number;
    transform: XrRigidTransform;
    blendTextureSourceAlpha?: boolean;
}
export interface XrWebGlBinding {
    createQuadLayer(init: {
        space: XrSpace;
        viewPixelWidth: number;
        viewPixelHeight: number;
        layout: 'stereo-left-right' | 'mono';
        textureType: 'texture';
        isStatic: boolean;
        width: number;
        height: number;
        transform: XrRigidTransform;
    }): XrQuadLayer;
    getSubImage(layer: XrQuadLayer, frame: XrFrame, eye?: XrEye): XrSubImage;
    createProjectionLayer?(init: {
        textureType: 'texture';
        scaleFactor?: number;
    }): XrProjectionLayer;
    createEquirectLayer?(init: {
        space: XrSpace;
        viewPixelWidth: number;
        viewPixelHeight: number;
        layout: 'mono';
        textureType: 'texture';
        isStatic: boolean;
        radius: number;
        centralHorizontalAngle: number;
        upperVerticalAngle: number;
        lowerVerticalAngle: number;
    }): XrQuadLayer;
    getViewSubImage?(layer: XrProjectionLayer, view: XrView): XrSubImage;
}
export interface XrProjectionLayer {
}
export interface XrGlobals {
    XRWebGLLayer?: new (session: XrSession, gl: WebGL2RenderingContext) => XrWebGlLayer;
    XRWebGLBinding?: new (session: XrSession, gl: WebGL2RenderingContext) => XrWebGlBinding;
    XRRigidTransform?: new (position?: DOMPointInit, orientation?: DOMPointInit) => XrRigidTransform;
}
export declare function xrSystem(): XrSystem | undefined;
export declare const xrGlobals: XrGlobals;
//# sourceMappingURL=emulator-xr-webxr.d.ts.map