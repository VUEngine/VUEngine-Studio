/**
 * What a headset shows besides the game: a menu or a question in front of the
 * screen, and a line of news beneath it.
 *
 * The page's own interface is gone while a session lasts — a headset shows
 * nothing of the document — so the little that is needed in there is drawn
 * here, with a 2D canvas, and handed to the session as a texture. Driven by
 * the controllers alone: the sticks move through a list, A takes the line
 * under the cursor, B goes back. See `EmulatorXrSession.showPanel`.
 */
/** One line of a panel: something to do. */
export interface XrPanelItem {
    label: string;
    /** Shown beside the label, dimmer: a state, a shortcut. */
    detail?: string;
    disabled?: boolean;
    /**
     * What choosing it does. The panel closes afterwards, unless this says
     * `'keep'` — a switch, whose new state the panel then shows.
     */
    run(): void | 'keep';
}
/** A menu or a question, in front of the screen. */
export interface XrPanel {
    title: string;
    /** Lines of text above the items: what a question is asking. */
    message?: string[];
    /** Read again whenever the panel is drawn, so a switch shows its new state. */
    items(): XrPanelItem[];
    /**
     * Lines at the foot of the panel, dimmer than the rest: what else the
     * controllers do, for somebody who cannot look at the page to find out.
     */
    footer?: string[];
    /** A heading over the footer, saying when what it lists applies. */
    footerTitle?: string;
    /** The panel has gone, however: chosen, backed out of, or replaced. */
    onClose?(): void;
}
/** The panel's canvas, in pixels; its width in the room is `XR_PANEL_WIDTH`. */
export declare const XR_PANEL_PIXELS: {
    width: number;
    height: number;
};
/** The news line's canvas, in pixels. */
export declare const XR_TOAST_PIXELS: {
    width: number;
    height: number;
};
/**
 * Draw a panel, with the cursor on the item at `cursor`. Opaque all over: a
 * headset's compositor blends a layer by its alpha, and a panel that let the
 * game show through it would be harder to read for no gain.
 */
export declare function drawXrPanel(canvas: HTMLCanvasElement, panel: XrPanel, cursor: number): XrPanelRow[];
/** Where an item was drawn on a panel, for finding what a controller points at. */
export interface XrPanelRow {
    /** Its place among the panel's items. */
    index: number;
    /** Its top and bottom edge, in the canvas' pixels from the top. */
    top: number;
    bottom: number;
}
/** The pointer's dot, in pixels; see {@link drawXrPointer}. */
export declare const XR_POINTER_PIXELS: {
    width: number;
    height: number;
};
/** The dot where a controller's ray meets a panel: light, ringed in dark, so it shows on either. */
export declare function drawXrPointer(canvas: HTMLCanvasElement): void;
/** Draw a line of news: a save written, an achievement earned, an error. */
export declare function drawXrToast(canvas: HTMLCanvasElement, text: string, error: boolean): void;
/**
 * Where the cursor goes from `cursor` by `step`, past disabled items, staying
 * put at either end rather than wrapping: with a stick, overshooting the last
 * line by holding it too long should not land on the first.
 */
export declare function moveXrCursor(items: readonly XrPanelItem[], cursor: number, step: number): number;
/** The first item that can be chosen, for where the cursor starts. */
export declare function firstXrItem(items: readonly XrPanelItem[]): number;
/**
 * One pill over the screen: a state the machine is in, or something running
 * on it. Words rather than the page's icons, which a 2D canvas cannot draw.
 */
export interface XrBadge {
    text: string;
    /** Something being recorded or taken, drawn in red as the page draws it. */
    live?: boolean;
}
/** One reading in the strip beneath the screen, as the page's status bar has it. */
export interface XrStatusItem {
    label: string;
    value: string;
    tone?: 'ok' | 'off';
}
/**
 * What the page shows around the picture, for the headset to show around the
 * screen: the badges over it, the status bar under it.
 */
export interface XrHud {
    /** What the machine is doing — paused, muted, fast-forwarding — at the left. */
    states: XrBadge[];
    /** What is running on it — cheats, patches, a recording — at the right. */
    activities: XrBadge[];
    status: XrStatusItem[];
}
/** The badge row's canvas, in pixels; its width in the room is the screen's. */
export declare const XR_BADGES_PIXELS: {
    width: number;
    height: number;
};
/** The status strip's canvas, in pixels; likewise. */
export declare const XR_STATUS_PIXELS: {
    width: number;
    height: number;
};
/**
 * Draw the badges over the screen: states from the left, activities from the
 * right. Transparent between them, unlike everything else drawn here — the
 * pills stand over the room the way they stand over the page's picture.
 */
export declare function drawXrBadges(canvas: HTMLCanvasElement, hud: XrHud): void;
/** Draw the status strip beneath the screen: each reading's name, dimmer, then its value. */
export declare function drawXrStatus(canvas: HTMLCanvasElement, hud: XrHud): void;
//# sourceMappingURL=emulator-xr-panel.d.ts.map