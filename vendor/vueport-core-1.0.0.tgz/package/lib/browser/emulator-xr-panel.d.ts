export interface XrPanelItem {
    label: string;
    detail?: string;
    disabled?: boolean;
    run(): void | 'keep';
}
export interface XrPanel {
    title: string;
    message?: string[];
    items(): XrPanelItem[];
    footer?: string[];
    footerTitle?: string;
    onClose?(): void;
}
export declare const XR_PANEL_PIXELS: {
    width: number;
    height: number;
};
export declare const XR_TOAST_PIXELS: {
    width: number;
    height: number;
};
export declare function drawXrPanel(canvas: HTMLCanvasElement, panel: XrPanel, cursor: number): XrPanelRow[];
export interface XrPanelRow {
    index: number;
    top: number;
    bottom: number;
}
export declare const XR_POINTER_PIXELS: {
    width: number;
    height: number;
};
export declare function drawXrPointer(canvas: HTMLCanvasElement): void;
export declare function drawXrToast(canvas: HTMLCanvasElement, text: string, error: boolean): void;
export declare function moveXrCursor(items: readonly XrPanelItem[], cursor: number, step: number): number;
export declare function firstXrItem(items: readonly XrPanelItem[]): number;
//# sourceMappingURL=emulator-xr-panel.d.ts.map