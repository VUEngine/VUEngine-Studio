import { Emitter, Event } from '../common/emulator-events';
import { Movie } from '../common/emulator-movie';
import { Sim } from './core/vb-core';
/**
 * Plays a recorded input movie back. Each frame's mask is booked against its frame number with `queueKeys`
 * and the machine runs under lockstep, so it waits for the movie and cannot drift (the link-session
 * machinery, with one window replaced by a file). It does not reset the machine: what power-on means
 * (save, hardware model, color patch) belongs to whoever owns the emulator.
 */
export declare class MoviePlayer {
    protected static readonly HORIZON = 240;
    protected movie: Movie | undefined;
    protected sim: Sim | undefined;
    protected nextFrame: number;
    protected machineFrame: number;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    get playing(): boolean;
    get current(): Movie | undefined;
    get frame(): number;
    get length(): number;
    start(sim: Sim, movie: Movie): Promise<void>;
    advance(frame: number): void;
    stop(): Promise<void>;
    protected fill(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-movie-player.d.ts.map