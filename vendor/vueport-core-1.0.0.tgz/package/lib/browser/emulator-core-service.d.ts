import { Disposable } from '../common/emulator-events';
import { Core, Sim } from './core/vb-core';
/**
 * One emulator's worker and the machines in it. A link session adds the mirror, the other player's machine run
 * here as well from their inputs: both must live in one WebAssembly instance, as the link port is emulated by
 * walking from one simulation to its peer. That keeps each window a whole emulator (toolbar, debugger, audio),
 * and is what netplay would do over a wire instead of a BroadcastChannel. See link-session.ts.
 */
export interface EmulatorSession extends Disposable {
    readonly core: Core;
    readonly sim: Sim;
    readonly mirror: Sim | undefined;
    /**
     * Brings the mirror up and wires the two together over the link port. Needs the same cartridge this window runs;
     * without one the mirror boots into empty memory and only looks like a working session.
     * `seat` is this window's player, the mirror takes the other. The core gets the pair in seat order, as the order
     * changes what a linked pair emulates and the two windows build theirs the opposite way round (setPeer in
     * vb-protocol.ts). Idempotent.
     */
    attachMirror(rom: ArrayBuffer, seat?: 1 | 2): Promise<Sim>;
    detachMirror(): Promise<void>;
    /**
     * Runs work that owns the mirror once whatever owns it now is done. Building and releasing the mirror are several
     * worker round trips belonging to different link sessions (unlink, then link again), and when the release won
     * the race it disposed of the machine the new session had just built. The mirror belongs to the emulator session,
     * so the queue lives here.
     */
    withMirror<T>(work: () => Promise<T>): Promise<T>;
}
declare class EmulatorSessionImpl implements EmulatorSession {
    readonly core: Core;
    readonly sim: Sim;
    protected readonly service: EmulatorCoreService;
    mirror: Sim | undefined;
    protected mirrorWork: Promise<unknown>;
    constructor(core: Core, sim: Sim, service: EmulatorCoreService);
    attachMirror(rom: ArrayBuffer, seat?: 1 | 2): Promise<Sim>;
    withMirror<T>(work: () => Promise<T>): Promise<T>;
    detachMirror(): Promise<void>;
    dispose(): void;
}
export interface VueportCoreUrls {
    workerUrl: string;
    audioWorkletUrl: string;
    wasmUrl: string;
    rcheevosModuleUrl?: string;
    mainThreadVideo?: boolean;
}
export declare class EmulatorCoreService implements Disposable {
    protected readonly urls: VueportCoreUrls;
    protected readonly sessions: Set<EmulatorSessionImpl>;
    constructor(urls: VueportCoreUrls);
    createSession(): Promise<EmulatorSession>;
    disposeSession(session: EmulatorSession): void;
    protected createCore(): Promise<Core>;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-core-service.d.ts.map