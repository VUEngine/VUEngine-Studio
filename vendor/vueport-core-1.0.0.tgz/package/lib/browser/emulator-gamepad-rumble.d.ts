/**
 * A game's rumble played on a game pad's two motors via the Gamepad API, as a stand-in for the Rumble Pack.
 * The pack drives a DRV2625 through 123 waveforms; a pad has a heavy and a light motor and a duration in ms.
 * RUMBLE_EFFECT_SHAPES bridges them: strength from the effect's name, length measured off the real hardware, and
 * ramps played in steps, as playEffect holds one magnitude for its whole duration. The shortest effects (~70 ms)
 * barely exceed motor spin-up, so they arrive as a bump.
 * Fed by the pack's change event rather than the byte path, so it works with a real serial pack or the
 * decoding-only fallback alike.
 */
import { Disposable } from '../common/emulator-events';
import { RumbleEffectShape, RumbleState, VueportRumblePack } from '../common/emulator-rumble';
export declare const GAMEPAD_PULSE_MS = 200;
export declare const GAMEPAD_RAMP_STEPS = 4;
interface PadMotors {
    play(duration: number, strong: number, weak: number): void;
    reset(): void;
}
/**
 * The phone's or tablet's own motor, for a game played on its screen with no pad to hold: navigator.vibrate, which
 * Chrome on Android has and Safari on iOS does not. One motor and no strength, so the stronger of the two pad
 * magnitudes decides how much of each short period it runs (see DEVICE_PWM_MS); full strength is one long buzz.
 */
export declare function deviceMotor(): PadMotors | undefined;
export declare function deviceCanRumble(): boolean;
export declare function gamepadCanRumble(pad: Gamepad): boolean;
export type RumblePads = () => Gamepad[];
export declare class GamepadRumble implements Disposable {
    protected readonly pack: VueportRumblePack;
    protected readonly pads: RumblePads;
    protected readonly intensity: () => number;
    protected readonly onDevice?: (() => boolean) | undefined;
    protected playing: number | undefined;
    protected subscription: Disposable | undefined;
    protected steps: ReturnType<typeof setTimeout>[];
    constructor(pack: VueportRumblePack, pads: RumblePads, intensity: () => number, onDevice?: (() => boolean) | undefined);
    start(): this;
    dispose(): void;
    protected wanted(): boolean;
    protected follow(): void;
    protected pulse(state: RumbleState): void;
    protected strength(shape: RumbleEffectShape | undefined, frequency: number | undefined, step: number, count: number): {
        strong: number;
        weak: number;
    };
    protected play(duration: number, { strong, weak }: {
        strong: number;
        weak: number;
    }): void;
    protected silence(): void;
    protected clearSteps(): void;
    protected motors(): PadMotors[];
}
/**
 * The pack's one frequency (50 to 400 Hz) as a crossfade over a pad's heavy and light motor: low leans on the heavy
 * one, high on the light. Not what the hardware does (one motor, driven harder or softer), but it keeps a 400 Hz
 * buzz feeling different from a 50 Hz shudder. An unknown frequency sits in the middle.
 */
export declare function magnitudes(frequency: number | undefined): {
    strong: number;
    weak: number;
};
export {};
//# sourceMappingURL=emulator-gamepad-rumble.d.ts.map