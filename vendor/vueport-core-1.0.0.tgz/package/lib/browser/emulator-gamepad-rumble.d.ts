/**
 * A game's rumble, played on the controller in somebody's hands.
 *
 * The Rumble Pack is one device on one link port, and most people playing have
 * neither. What they often do have is a game pad with two motors in it, and
 * the Gamepad API will drive them — so the effects a game broadcasts can be
 * felt without the hardware they were written for.
 *
 * A stand-in, and it says so. The pack drives a DRV2625 through a library of
 * 123 waveforms; a pad has one heavy motor, one light one, and a duration in
 * milliseconds. What bridges them is `RUMBLE_EFFECT_SHAPES`: how hard each
 * effect pulls, from its name, and how long it runs, measured off the real
 * hardware. So a click taps for the tenth of a second it actually lasts, an
 * alert buzzes for its three quarters, and a ramp is played as a ramp — in a
 * few steps, because `playEffect` holds one magnitude for its whole duration.
 *
 * What it cannot do is worth knowing. The shortest effects are around 70 ms,
 * which is not much more than a pad's motor takes to spin up, so those arrive
 * as a bump whatever is asked for; and the two motors are a crossfade rather
 * than a waveform. It is the difference between a game that rumbles and one
 * that does not, which is most of the point.
 *
 * Fed by the pack's own change event rather than by the byte path, so it works
 * the same whichever pack a host built — a real one over a serial port, or the
 * decoding-only one a page falls back to.
 */
import { Disposable } from '../common/emulator-events';
import { RumbleEffectShape, RumbleState, VueportRumblePack } from '../common/emulator-rumble';
/**
 * How long a pad buzzes for a Play whose effect nobody named.
 *
 * Only for that: an effect the panel knows the number of is played for the
 * length its shape gives. This is the fallback for a game that sent a Play
 * before ever choosing an effect, where the honest answer is a short pulse
 * rather than the ceiling's worth of buzzing.
 */
export declare const GAMEPAD_PULSE_MS = 200;
/**
 * How many steps a ramp is played in.
 *
 * `playEffect` holds one pair of magnitudes for its whole duration, so a ramp
 * has to be several of them in a row. Four is enough to feel like a rise or a
 * fall rather than a block, and few enough that the shortest ramp measured —
 * 216 ms — still gives each step longer than a pad takes to respond.
 */
export declare const GAMEPAD_RAMP_STEPS = 4;
/**
 * What the Gamepad API calls a motor, as much of it as is used here.
 *
 * Declared rather than taken from the DOM library: `vibrationActuator` is not
 * in every version of it, and a build that has it would still not agree with
 * one that does not.
 */
interface VibrationActuator {
    playEffect(type: string, params: {
        duration: number;
        startDelay?: number;
        strongMagnitude?: number;
        weakMagnitude?: number;
    }): Promise<string>;
    reset?(): Promise<string>;
}
/** The pads this machine should buzz, as the caller decides which those are. */
export type RumblePads = () => Gamepad[];
export declare class GamepadRumble implements Disposable {
    protected readonly pack: VueportRumblePack;
    protected readonly pads: RumblePads;
    /** Whether the person wants this at all. Read on every effect. */
    protected readonly enabled: () => boolean;
    /** The Play this has already acted on, by its number. */
    protected playing: number | undefined;
    protected subscription: Disposable | undefined;
    /** The steps of a ramp still to come. Dropped when anything ends it. */
    protected steps: ReturnType<typeof setTimeout>[];
    constructor(pack: VueportRumblePack, pads: RumblePads, 
    /** Whether the person wants this at all. Read on every effect. */
    enabled: () => boolean);
    /** Start following the pack. Returns this, so it can be built and started. */
    start(): this;
    dispose(): void;
    /**
     * Whether a pad should be buzzing for this machine right now.
     *
     * Off while a real pack is attached and being fed: the pack is the device
     * the game was written for, and somebody who has gone to the trouble of
     * plugging one in does not also want it in their hands. This is a
     * stand-in, and it stands down.
     */
    protected wanted(): boolean;
    /** Called on every byte the pack sees; acts only on the ones that matter. */
    protected follow(): void;
    /**
     * Play one effect, in as many steps as its shape needs.
     *
     * For exactly as long as the panel counts it as playing, which is the
     * effect's own measured length: a pad still buzzing for something the rest
     * of the emulator has stopped showing would be saying two things at once.
     */
    protected pulse(state: RumbleState): void;
    /** One step's worth of both motors. */
    protected strength(shape: RumbleEffectShape | undefined, frequency: number | undefined, step: number, count: number): {
        strong: number;
        weak: number;
    };
    protected play(duration: number, { strong, weak }: {
        strong: number;
        weak: number;
    }): void;
    protected silence(): void;
    protected clearSteps(): void;
    /** The motors of the pads that drive this machine, where they have any. */
    protected actuators(): VibrationActuator[];
}
/**
 * The pack's one frequency, split over a pad's two motors.
 *
 * The pack shakes at 50 to 400 Hz; a dual-rumble pad has a heavy motor that
 * gives a low rumble and a light one that gives a high buzz. So the frequency
 * a game asked for is a crossfade between them rather than an intensity: a low
 * frequency leans on the heavy motor, a high one on the light. Not what the
 * hardware does — it is one motor, driven harder or softer — but it is what a
 * pad has, and it keeps a 400 Hz buzz feeling different from a 50 Hz shudder.
 *
 * An unknown frequency sits in the middle, which is where a game that never
 * said belongs.
 */
export declare function magnitudes(frequency: number | undefined): {
    strong: number;
    weak: number;
};
export {};
//# sourceMappingURL=emulator-gamepad-rumble.d.ts.map