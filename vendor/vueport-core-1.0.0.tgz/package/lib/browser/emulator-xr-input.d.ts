import { XrInputSource } from './emulator-xr-webxr';
export declare const XR_STICK_THRESHOLD = 0.5;
/**
 * Laid out like the console's pad: sticks are the D-pads, triggers L and R, right A/B are A and B, left
 * X/Y are Select and Start (under the console's left D-pad). Buttons by the `xr-standard` mapping, which
 * every current headset reports. A held grip turns both sticks to adjusting the view (see adjustView), so
 * their directions are left out of the keys and their leans and clicks reported instead
 */
export declare function readControllers(sources: ArrayLike<XrInputSource>): XrControllerReading;
export interface XrButtons {
    leftClick: boolean;
    rightClick: boolean;
    leftTrigger: boolean;
    rightTrigger: boolean;
    a: boolean;
    b: boolean;
    x: boolean;
    y: boolean;
    menu: boolean;
}
export declare function noXrButtons(): XrButtons;
export interface XrControllerReading {
    keys: number;
    adjusting: boolean;
    leftLean: number;
    rightLean: number;
    vertical: number;
    buttons: XrButtons;
    triggers: {
        left: number;
        right: number;
    };
}
//# sourceMappingURL=emulator-xr-input.d.ts.map