/**
 * A headset's controllers, read once a frame — see `emulator-xr.ts`.
 *
 * A headset browser never lists its controllers to the Gamepad API, and stops
 * the page's animation frames while a session lasts, so the session reads
 * them itself, through this: as the Virtual Boy's buttons while playing, and
 * as named buttons and stick leans for the menu and the screen's adjustments.
 */
import { XrInputSource } from './emulator-xr-webxr';
/** How far a stick has to lean before it counts as a D-pad direction. */
export declare const XR_STICK_THRESHOLD = 0.5;
/**
 * The Virtual Boy buttons held on a headset's controllers.
 *
 * Laid out as the console's own pad is: the left stick is the left D-pad and
 * the right stick the right one, the triggers are L and R, the right hand's
 * A and B are A and B, and the left hand's X and Y, where the console has
 * Select and Start under its left D-pad, are those. Buttons are by the
 * `xr-standard` mapping, which every current headset's controllers report.
 *
 * A grip held turns both sticks from playing to adjusting how the screen is
 * shown — see `adjustView` — so their directions are left out of the keys
 * while it is, and their leans and clicks are reported instead.
 */
export declare function readControllers(sources: ArrayLike<XrInputSource>): XrControllerReading;
/** The controller buttons a menu is driven with, by name rather than by index. */
export interface XrButtons {
    leftClick: boolean;
    rightClick: boolean;
    leftTrigger: boolean;
    rightTrigger: boolean;
    a: boolean;
    b: boolean;
    x: boolean;
    y: boolean;
    /** The left controller's menu button, if the browser passes it on. */
    menu: boolean;
}
export declare function noXrButtons(): XrButtons;
/** What the controllers are doing, once a frame; see {@link readControllers}. */
export interface XrControllerReading {
    /** The Virtual Boy buttons held. */
    keys: number;
    /** Whether a grip is held, which turns the sticks to adjusting the view. */
    adjusting: boolean;
    /**
     * How far each stick leans towards more, from -1 to 1: right or up, by
     * whichever of the two it leans further in.
     */
    leftLean: number;
    rightLean: number;
    /** The furthest either stick leans up (negative) or down, for moving through a menu. */
    vertical: number;
    buttons: XrButtons;
}
//# sourceMappingURL=emulator-xr-input.d.ts.map