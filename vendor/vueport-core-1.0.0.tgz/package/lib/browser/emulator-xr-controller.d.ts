/**
 * Playing in a headset, as a host offers it: whether there is one, the button
 * that starts a session, the menu and the readings around the screen in it,
 * and what is kept between sessions.
 *
 * `EmulatorXrSession` is the session itself and knows nothing of the host; this
 * is what both hosts — the standalone build and the studio — would otherwise
 * each write around it, in the same words.
 */
import { DisplayMode } from '../common/vb-constants';
import { Core, Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import { MacroActivity } from './emulator-macro-store';
import { EmulatorStatusSource } from './emulator-status';
import { EmulatorAction } from './emulator-types';
import { EmulatorXrSession, XrAvailability, XrBackdrop, XrDiagnostics, XrScreen } from './emulator-xr';
import { XrHud, XrPanel } from './emulator-xr-panel';
/** What the headset can show in place of the host's own notices and questions. */
export interface XrHeadsetUi {
    toast(text: string, error: boolean): void;
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean>;
}
/** What the readings around the screen are read from — the host's own badges and status bar. */
export interface XrHudSource extends EmulatorStatusSource {
    readonly state: {
        readonly loaded: boolean;
        readonly paused: boolean;
        readonly frameAdvance: boolean;
        readonly fastForward: boolean;
        readonly slowmotion: boolean;
        readonly muted: boolean;
        readonly lowPower: boolean;
    };
    readonly settings: {
        get(key: 'fastForwardRatio' | 'slowMotionRatio'): unknown;
    };
    readonly rewinding: boolean;
    readonly activeCheats: number;
    readonly activePatches: number;
    readonly macroActivity: MacroActivity;
    readonly profiling: boolean;
    readonly moviePlaying: boolean;
    readonly movieFrame: number;
    readonly movieLength: number;
    readonly recordingVideo: boolean;
    recordedSeconds(): number;
    readonly saveGameSlot: string;
}
/** What the controller needs from the host it is part of. */
export interface XrControllerHost {
    sim(): Sim | undefined;
    core(): Core | undefined;
    input(): EmulatorInputController;
    displayMode(): DisplayMode;
    /** The badges and readings to show around the screen. */
    hudSource(): XrHudSource;
    /** What the menu is headed with: the game's name. */
    romTitle(): string;
    runAction(action: EmulatorAction): void;
    /** Whether Load Latest State has anything to load, and may. */
    canLoadState(): boolean;
    /**
     * The machine's 3D depth has changed — on the way in or out, or adjusted
     * in the headset. The host's to apply, through {@link EmulatorXrController.stereoDepth}.
     */
    applyStereoDepth(): Promise<void>;
    /** Draw again: the button, the settings pane. */
    update(): void;
    notifyError(message: string): void;
    /** The headset is showing, or no longer: where notices and questions should go. */
    setHeadset?(headset: XrHeadsetUi | undefined): void;
    /** False to draw into the eye buffers even where a quad layer is on offer; see `EmulatorXrHost.quadLayers`. */
    quadLayers?: boolean;
    /** Report each session's diagnostics to the console when it ends. */
    debug?: boolean;
}
export declare class EmulatorXrController {
    protected readonly host: XrControllerHost;
    protected session: EmulatorXrSession | undefined;
    protected starting: boolean;
    /** Whether the headset's menu paused the game, which it then does not report as news. */
    protected menuPaused: boolean;
    protected disposed: boolean;
    protected readonly deviceChange: {
        dispose(): void;
    };
    /** What the browser said it can do with a headset, once it has. */
    availability: XrAvailability | undefined;
    /** And whether that headset can show the room it is in — passthrough. */
    passthroughSupported: boolean;
    /** How the screen is shown in a headset, as it was last adjusted there. */
    screen: XrScreen;
    /**
     * What is wanted around the screen: a room of its own, the player's, or
     * the player's through the screen as well.
     */
    backdrop: XrBackdrop;
    constructor(host: XrControllerHost);
    dispose(): void;
    /** Whether there is a headset to play in. */
    get supported(): boolean;
    /** Whether the game is being played in one. */
    get active(): boolean;
    /** The 3D depth the machine should be drawn at: the headset's own while in one. */
    stereoDepth(page: number): number;
    protected check(): void;
    /**
     * Put the running game in a headset, or take it out again.
     *
     * Called straight from a click: a browser grants a headset only to a
     * gesture, and `EmulatorXrSession.start` asks for it before anything else.
     */
    toggle(): Promise<void>;
    end(): Promise<void>;
    /**
     * Start a session, with or without a game in it yet. Without one is how a
     * game is started straight into the headset: the session shows the
     * machine as soon as {@link setSim} hands it one.
     */
    enter(): Promise<void>;
    protected ended(diagnostics: XrDiagnostics): void;
    /**
     * The machine to show, or none while one is being built again — a patch,
     * a hardware change, a new build. The headset stays through that.
     */
    setSim(sim: Sim | undefined): Promise<void>;
    setDisplayMode(mode: DisplayMode): void;
    /**
     * The headset's screen size and depth, set from the settings pane. A
     * session under way — a tethered headset, with the page still in view —
     * takes them at once.
     */
    setScreen(screen: XrScreen): void;
    /** What is around the headset's screen, set from the settings pane. */
    setBackdrop(backdrop: XrBackdrop): void;
    /**
     * Get the machine going again if the audio that clocks it stopped with
     * the move into the headset or out of it — see `Core.restartStalledAudio`.
     *
     * Checked twice, because the headset takes the audio device over a moment
     * after the session has started rather than as it starts. Without this a
     * game started on the page and taken into the headset afterwards — after
     * a patch rebuilt it, say — showed its first, black frame until it was
     * paused and resumed by hand.
     */
    protected watchAudioClock(): void;
    /** How long after a headset comes or goes to look at the audio clock again. */
    protected static readonly AUDIO_CLOCK_RECHECK_MS = 2500;
    /**
     * The menu a stick click opens in the headset: what is worth doing
     * without taking it off. The game waits while it is up, and carries on
     * when it goes — unless it was already paused, which it then stays.
     */
    protected quickMenu(): XrPanel | undefined;
    /**
     * What goes around the screen in the headset: the badges the host puts
     * over its picture, and its status bar's readings — the same ones, in the
     * same words, as far as words can stand in for icons.
     */
    protected hud(): XrHud | undefined;
}
//# sourceMappingURL=emulator-xr-controller.d.ts.map