/**
 * Playing in a headset as a host offers it: availability, the start button, the page's interface around the screen,
 * and what is kept between sessions. EmulatorXrSession is the session itself and knows nothing of the host.
 * Only the standalone build uses this: Electron has WebXR's API but nothing behind it that reaches a headset
 * (isSessionSupported says no with a Quest connected and the switches that make WebView2 work).
 */
import { DisplayMode } from '../common/vb-constants';
import { Core, Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import { EmulatorXrSession, XrAvailability, XrBackdrop, XrDiagnostics, XrScreen } from './emulator-xr';
export interface XrHeadsetUi {
    toast(text: string, error: boolean): void;
    wait(text: string | undefined): void;
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean>;
    showsPage?: boolean;
}
export interface XrControllerHost {
    sim(): Sim | undefined;
    core(): Core | undefined;
    input(): EmulatorInputController;
    displayMode(): DisplayMode;
    applyStereoDepth(): Promise<void>;
    update(): void;
    notifyError(message: string): void;
    setHeadset?(headset: XrHeadsetUi | undefined): void;
    quadLayers?: boolean;
    debug?: boolean;
    enterAtStart?: boolean;
    onXrUiShown?(shown: boolean): void;
}
export declare class EmulatorXrController {
    protected readonly host: XrControllerHost;
    protected session: EmulatorXrSession | undefined;
    protected starting: boolean;
    protected disposed: boolean;
    protected startTried: boolean;
    startOffered: boolean;
    protected readonly deviceChange: {
        dispose(): void;
    };
    availability: XrAvailability | undefined;
    passthroughSupported: boolean;
    screen: XrScreen;
    backdrop: XrBackdrop;
    constructor(host: XrControllerHost);
    dispose(): void;
    get supported(): boolean;
    get active(): boolean;
    stereoDepth(page: number): number;
    protected check(): void;
    /**
     * Straight into the headset with the app, the library there to pick a game from. A browser grants a headset only
     * to a gesture: an installed app's start from its icon counts as one on the Quest, so that asks at once; in a
     * tab the session is offered in the browser's own interface (an Enter VR button by the address) instead. Once,
     * and quietly, as either may be refused
     */
    protected enterAtStart(): void;
    toggle(): Promise<void>;
    end(): Promise<void>;
    dismissStart(): void;
    /**
     * Back into the headset from the page, straight from a click on it: a session the player left for another of the
     * headset's windows runs on unseen, and the browser's own Resume does not bring it back. So it is ended and a new
     * one asked for, which the click still counts for
     */
    resume(): Promise<void>;
    protected static readonly RESUME_WAIT_MS = 300;
    enter(options?: {
        offer?: boolean;
        background?: boolean;
        quiet?: boolean;
    }): Promise<void>;
    protected ended(diagnostics: XrDiagnostics): void;
    setSim(sim: Sim | undefined): Promise<void>;
    gameStarting(): void;
    setDisplayMode(mode: DisplayMode): void;
    setScreen(screen: XrScreen): void;
    setBackdrop(backdrop: XrBackdrop): void;
    protected watchAudioClock(): void;
    protected static readonly AUDIO_CLOCK_RECHECK_MS = 2500;
}
//# sourceMappingURL=emulator-xr-controller.d.ts.map