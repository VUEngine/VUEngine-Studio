import { VueportConfig } from '../common/emulator-settings';
/**
 * How each setting should be presented, for a host that builds a settings
 * screen from this rather than listing the controls by hand.
 *
 * Plain JSON Schema, which is what both hosts want: Theia's preference schema
 * takes it almost as-is (see `VesEmulatorPreferenceSchema`), and a standalone
 * settings window can switch on `type`.
 *
 * Here rather than in `common/` because the enum labels come from the display
 * tables, which are browser-side. The contract itself — `VueportConfig`, the
 * defaults, the ranges — has no such dependency and stays in `common/`.
 */
export interface VueportSettingSchema {
    type: 'string' | 'number' | 'integer' | 'boolean' | 'array';
    title: string;
    description?: string;
    enum?: string[];
    enumItemLabels?: string[];
    /**
     * What each choice does, one per `enum` entry.
     *
     * A setting's own `description` says what the setting is for; this says what
     * picking a given answer gets you, which a standalone window can show under
     * the control for whichever one is chosen rather than making somebody try
     * all of them. Optional: most settings' choices explain themselves.
     */
    enumItemDescriptions?: string[];
    /**
     * Each choice's name written out in full, one per `enum` entry, where the
     * control's own label is an abbreviation it has no room to expand — `HLI`
     * on a card, `Horizontal Line Interlaced` in the line beneath it. Optional,
     * and falls back to `enumItemLabels` per choice.
     */
    enumItemNames?: string[];
    items?: unknown;
    multipleOf?: number;
    minimum?: number;
    maximum?: number;
    /**
     * A presentational hint for a string setting. `color` asks for a color well
     * rather than a text field; the stored value is still a `#rrggbb` string.
     */
    format?: 'color';
}
/**
 * The emulator's settings, described.
 *
 * Built on first use rather than at import, because the titles are localized
 * and the host installs its localization during start-up. Carries no default,
 * scope or preference id: what a setting *is* belongs here, where a host keeps
 * it belongs to the host — see `VUEPORT_DEFAULTS` and `VUEPORT_PREFERENCE_IDS`.
 */
export declare function vueportSettingsSchema(): Record<keyof VueportConfig, VueportSettingSchema>;
//# sourceMappingURL=emulator-settings-schema.d.ts.map