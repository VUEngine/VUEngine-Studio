import { VueportConfig } from '../common/emulator-settings';
export interface VueportSettingSchema {
    type: 'string' | 'number' | 'integer' | 'boolean' | 'array';
    title: string;
    description?: string;
    enum?: string[] | number[];
    enumItemLabels?: string[];
    enumItemDescriptions?: string[];
    enumItemNames?: string[];
    items?: unknown;
    multipleOf?: number;
    minimum?: number;
    maximum?: number;
    format?: 'color';
}
export declare function vueportSettingsSchema(): Record<keyof VueportConfig, VueportSettingSchema>;
//# sourceMappingURL=emulator-settings-schema.d.ts.map