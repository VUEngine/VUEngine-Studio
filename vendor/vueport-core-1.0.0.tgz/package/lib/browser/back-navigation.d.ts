/**
 * The device's Back (Android's button or gesture, a browser's back button) as a way back inside VUEPort rather than
 * off the page: from a settings pane to the list of panes, out of a sheet or a window, out of a game to the library.
 *
 * Whatever can be gone back from registers a handler; the most recent is the one Back runs. While there is any, one
 * extra entry sits on the page's history (the guard), so Back pops that instead of leaving, and the handler runs on
 * the popstate. Once nothing is left to go back from, the guard is taken off again, so the next Back leaves the page
 * as it would have. Opt-in (allowBackNavigation), as only the standalone build owns its page's history; the studio's
 * is Theia's.
 */
export declare function allowBackNavigation(): void;
/**
 * Registers what Back does while this is the most recent thing open, until the returned function takes it away. Taken
 * away by identity, as React unmounts in its own order and a handler above may go first
 */
export declare function pushBackHandler(run: () => void): () => void;
//# sourceMappingURL=back-navigation.d.ts.map