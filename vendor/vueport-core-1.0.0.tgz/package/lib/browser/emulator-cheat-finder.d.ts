import { Emitter, Event } from '../common/emulator-events';
import { ScanDataType, ScanOperator } from '../common/emulator-cheat-scan';
import { Sim } from './core/vb-core';
export declare enum CheatScanRegion {
    WRAM = "wram",
    CART_RAM = "cartRam"
}
export declare const CHEAT_SCAN_REGIONS: CheatScanRegion[];
export interface CheatScanResult {
    address: number;
    value: number;
    previous: number;
}
export declare class CheatFinder {
    protected sim: Sim | undefined;
    protected writer: ((address: number, bytes: number[]) => boolean) | undefined;
    protected region: CheatScanRegion;
    protected type: ScanDataType;
    protected baseline: Uint8Array | undefined;
    protected current: Uint8Array | undefined;
    protected cartRamBytes?: number;
    protected candidates: Uint32Array | undefined;
    protected history: Uint32Array[];
    protected working: boolean;
    protected readonly onDidChangeEmitter: Emitter<void>;
    readonly onDidChange: Event<void>;
    setSim(sim: Sim | undefined): void;
    setWriter(writer: ((address: number, bytes: number[]) => boolean) | undefined): void;
    get hasSim(): boolean;
    get busy(): boolean;
    get scanRegion(): CheatScanRegion;
    get dataType(): ScanDataType;
    get started(): boolean;
    get count(): number;
    get canUndo(): boolean;
    setRegion(region: CheatScanRegion): void;
    setDataType(type: ScanDataType): void;
    reset(): void;
    undo(): void;
    first(op: ScanOperator, value?: number): Promise<void>;
    next(op: ScanOperator, value?: number): Promise<void>;
    refreshValues(): Promise<void>;
    poke(address: number, value: number): Promise<void>;
    results(limit: number): CheatScanResult[];
    get cheatDigits(): number;
    dispose(): void;
    protected regionBase(): number;
    protected pass(judge: (snapshot: Uint8Array) => Promise<void>): Promise<void>;
    protected read(): Promise<Uint8Array | undefined>;
    protected changed(): void;
}
//# sourceMappingURL=emulator-cheat-finder.d.ts.map