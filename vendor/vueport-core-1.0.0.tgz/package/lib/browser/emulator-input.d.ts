import { VbKey } from '../common/vb-constants';
import { Disposable } from '../common/emulator-events';
import { VueportInputBindings } from '../common/emulator-settings';
import { Sim } from './core/vb-core';
import { EmulatorGamePadButton } from './emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from './emulator-types';
import { GamepadProfileResolver } from './emulator-gamepad';
import { GAMEPAD_KEY_TO_VB_KEY } from '../common/emulator-gamepad-profiles';
export interface EmulatorInputBinding {
    keys: string[];
    command: EmulatorAction | EmulatorGamePadKeyCode;
}
interface TurboKeyBinding {
    keys: string[];
    vbKey: VbKey;
}
interface MacroSlotKeyBinding {
    keys: string[];
    slot: number;
}
export { GAMEPAD_KEY_TO_VB_KEY };
export declare function emulatorHeldButtons(keys: number): EmulatorGamePadButton[];
export interface EmulatorInputHost {
    readonly sim?: Sim;
    sendKeys?(keys: number): void;
    sendTurbo?(keys: number, rate: number): void;
    readonly turboRate?: number;
    readonly isVisible: boolean;
    readonly lowPower: boolean;
    isAcceptingInput(): boolean;
    mayTakeFocus?(): boolean;
    readonly rewinding: boolean;
    stopRewinding(): void;
    sendCommand(command: string, data?: unknown): void;
    canRunAction(action: EmulatorAction): boolean;
    runAction(action: EmulatorAction): void;
    usesPlayer2Controls(): boolean;
    gamepadPlayer?(): number | undefined;
    gamepadProfiles?(): GamepadProfileResolver | undefined;
    playMacroSlot?(slot: number): void;
}
export interface EmulatorMacroHook {
    recordKeys(keys: number): void;
    tick(): void;
}
export declare class EmulatorInputController implements Disposable {
    protected readonly host: EmulatorInputHost;
    protected readonly keymap: VueportInputBindings;
    protected pressedKeys: number;
    protected gamepadKeys: number;
    protected heldBackPadKeys: number;
    protected macroKeys: number;
    protected turboKeyboardKeys: number;
    protected turboGamepadKeys: number;
    protected appliedTurbo: {
        keys: number;
        rate: number;
    };
    protected heldGamepadMacroSlots: Set<number>;
    protected xrKeys: number;
    protected touchKeys: number;
    protected externalFrames: boolean;
    protected heldGamepadActions: Set<EmulatorAction>;
    protected reportedPlayerKeys: number;
    protected appliedKeys: number;
    protected frameHandle?: number;
    protected wasAcceptingInput: boolean;
    protected _bindings: Record<string, EmulatorInputBinding>;
    protected turboBindings: TurboKeyBinding[];
    protected macroSlotBindings: MacroSlotKeyBinding[];
    protected macros: EmulatorMacroHook | undefined;
    protected node?: HTMLElement;
    protected screenNode?: HTMLElement;
    constructor(host: EmulatorInputHost, keymap: VueportInputBindings);
    get bindings(): Record<string, EmulatorInputBinding>;
    get playerKeys(): number;
    setTouchKeys(keys: number): void;
    setXrKeys(keys: number): void;
    setExternalFrames(external: boolean): void;
    setMacroHook(macros: EmulatorMacroHook | undefined): void;
    setMacroKeys(keys: number): void;
    refreshBindings(): void;
    attach(node: HTMLElement, screenNode: HTMLElement): void;
    focus(): void;
    detach(): void;
    setKey(vbKey: VbKey, down: boolean): Promise<void>;
    tapKey(vbKey: VbKey): Promise<void>;
    applyKeys(): Promise<void>;
    applyTurbo(): Promise<void>;
    setTurboKey(vbKey: VbKey, down: boolean): Promise<void>;
    invalidate(): void;
    protected keyEventListener: (e: KeyboardEvent) => void;
    /**
     * Reclaims keyboard focus for the widget that owns the keydown listener. The screen is a plain canvas inside the
     * debug dock's Lumino DockPanel (it used to be an iframe, its own focus scope), so clicking around in the dock
     * moves focus away without involving the emulator. Scoped to the screen so it does not fight e.g. typing an address
     * into the Memory panel.
     */
    protected focusListener: () => void | undefined;
    protected focusInListener: () => void;
    protected focusOutListener: (e: FocusEvent) => void;
    protected processKeyEvent(e: KeyboardEvent): void;
    protected matchKey(keyCodes: string[], keyCode: string): boolean;
    /**
     * Runs the actions a pad has just started holding, and ends rewind, which is held rather than tapped. Same guards
     * as processKeyEvent: a release always ends rewind first, or a filtered release would leave the emulator suspended.
     * isTypingTarget does not apply, as a pad is never what somebody types with.
     */
    protected dispatchGamepadActions(held: Set<EmulatorAction>): void;
    protected dispatchGamepadMacroSlots(held: Set<number>): void;
    /**
     * Takes the keyboard back whenever nothing has a better claim on it. Keys are heard on the emulator's node, and the
     * gestures around a game lose focus: the start page's button is gone from the DOM once the game runs, leaving focus
     * on the body, so a session used to need a click on the picture first.
     * Called per frame for two moments: focus has fallen to nowhere, or a window taking the keyboard just closed. A
     * click is the third, handled in clickListener.
     */
    protected keepFocus(): void;
    protected focusIsNowhere(): boolean;
    /**
     * Gives the keyboard to the game, unless something has a better claim on it: a window taking the keyboard
     * (isAcceptingInput, as in processKeyEvent), a field being typed into (isTypingTarget), a window nobody is looking
     * at (so player two's window does not grab focus), or the host saying something else is being worked in
     * (mayTakeFocus).
     */
    protected takeFocus(): void;
    /**
     * A click anywhere hands the keyboard back to the game: after pressing a button in the chrome (fullscreen, a panel
     * tab, a settings toggle) the button would otherwise keep focus. The screen's own mousedown handler generalized,
     * with the same guards. `detail` tells a pressed button from Space or Enter on a focused one, which also clicks;
     * the interface has to stay usable from the keyboard.
     */
    protected clickListener: (e: MouseEvent) => void;
    protected startInputLoop(): void;
    pollFrame(): void;
    protected stopInputLoop(): void;
    dispose(): void;
}
//# sourceMappingURL=emulator-input.d.ts.map