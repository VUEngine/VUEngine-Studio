/**
 * The page's interface around the screen in a headset: title bar on top, the state badges over the screen, the
 * toolbar and the status bar under it, the side panel (cheats, achievements, …) to the right and whatever window is
 * open (settings, …) to the left; with no game, the library where the screen would be. Each part is the page's own
 * element, copied into a texture when it changes (see emulator-xr-dom.ts) and shown as a quad of its own; pointing at
 * one with a controller is a mouse on the real element. Debug mode stays on the page.
 * While a session lasts, <html> carries `vp-xr-layout`, which gives the parts the fixed sizes they have in the headset
 * (the page itself is out of sight then), so what is drawn and what is pointed at agree.
 */
import { XrDomPointer, XrDomSnapshot, XrStateSheet } from './emulator-xr-dom';
import { XrKeyboard } from './emulator-xr-keyboard';
import { Point3, XrOverlay, XrOverlayHit } from './emulator-xr-render';
export declare const XR_UI_METERS_PER_PIXEL = 0.0014;
type Slot = 'middle' | 'tabs' | 'aside' | 'window' | 'popup';
declare class Part {
    readonly slot: Slot;
    element: HTMLElement | undefined;
    overlay: XrOverlay | undefined;
    dirty: boolean;
    drawnAt: number;
    drawn: boolean;
    cost: number;
    hoveredAt: number | undefined;
    constructor(slot: Slot);
}
export interface XrRay {
    origin: Point3;
    direction: Point3;
}
export interface XrUiAim {
    overlay: XrOverlay;
    hit: XrOverlayHit;
}
export declare class XrUi {
    protected readonly gl: WebGL2RenderingContext;
    protected readonly debug: boolean;
    protected static active: number;
    protected readonly parts: Part[];
    protected readonly snapshot: XrDomSnapshot;
    protected readonly pointer: XrDomPointer;
    protected readonly states: XrStateSheet;
    protected readonly keyboard: XrKeyboard;
    protected readonly keyboardOverlay: XrOverlay;
    protected keyboardShown: boolean;
    protected readonly observer: MutationObserver;
    protected drawing: boolean;
    protected changed: boolean;
    protected shownKey: string;
    protected aimed: {
        part: Part;
        x: number;
        y: number;
    } | 'keyboard' | undefined;
    protected screen: {
        width: number;
        height: number;
        z: number;
    };
    protected lowest: number;
    protected disposed: boolean;
    protected panelHeights: string;
    readonly stats: ({
        slot: Slot;
        upload: number;
    } & NonNullable<XrDomSnapshot['timings']>)[];
    shown: boolean;
    onQuestion: (() => void) | undefined;
    game: boolean;
    constructor(gl: WebGL2RenderingContext, debug?: boolean);
    dispose(): void;
    setShown(shown: boolean): void;
    setGame(game: boolean): void;
    setScreen(width: number, height: number, z: number): void;
    protected get ratio(): number;
    protected get metersPerPixel(): number;
    get underlays(): XrOverlay[];
    get overlays(): XrOverlay[];
    get coversScreen(): boolean;
    protected get sideYaw(): number;
    get distance(): number;
    get bottom(): number;
    update(time: number): boolean;
    aim(rays: XrRay[]): XrUiAim | undefined;
    protected pointAt(part: Part | 'keyboard' | undefined, overlay?: XrOverlay, hit?: XrOverlayHit): void;
    get aiming(): boolean;
    press(): void;
    release(): void;
    scroll(lean: number, seconds: number): void;
    escape(): void;
    protected topmostIsModal(): boolean;
    protected part(slot: Slot): Part;
    protected wanted(part: Part): boolean;
    protected showing(part: Part): boolean;
    protected overlayKey(overlay: XrOverlay): string;
    protected draw(part: Part, time: number): void;
    protected drawKeyboard(): void;
    protected place(): void;
    /**
     * Where the screen goes in the middle's window, in CSS pixels from the window's center (right and down): the middle
     * of the screen frame's room, which the .vp-xr-layout rules make as large as the screen, with the badges over it
     * and the play strip under it as on the page
     */
    protected screenSlot(): {
        x: number;
        y: number;
    } | undefined;
    protected setPanelHeights(panel: number, aside: number): void;
    protected nestedIn(part: Part): Set<Element>;
    protected ownerOf(node: Node): Part | undefined;
    /**
     * What the pointer is over changed in a part. A quick one is drawn again at once; a slow one (a library, the
     * settings) once the pointer has settled, as sweeping across it would otherwise have it drawn over and over,
     * each time costing the headset frames
     */
    protected hoverChanged(part: Part | undefined): void;
    protected dirtyAround(element: Node | undefined): void;
    protected onMutations(records: MutationRecord[]): void;
    protected readonly onEvent: (event: Event) => void;
}
export {};
//# sourceMappingURL=emulator-xr-ui.d.ts.map