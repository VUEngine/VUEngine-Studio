/**
 * Where a ROM's save, save states and cheats go.
 *
 * Two layouts, chosen by the `companionFiles` setting:
 *
 *   beside the ROM   `<rom dir>/Red Alarm (USA).p1.sram`
 *   in the store     `roms/Red Alarm (USA)/save.sram`
 *
 * They differ in more than the directory, and deliberately. Beside a ROM the
 * files share a folder with everything else there, so each carries the ROM's
 * own name — which is also the convention every other emulator follows, so a
 * save written here can be read by one of them. In the store nothing else is
 * in the way, so each ROM gets a folder and the files inside it are named for
 * what they are.
 *
 * The store layout is unchanged from before there was a choice, so an
 * application that has been keeping saves there still finds them.
 */
import { EmulatorCompanionLocation } from '../common/emulator-sram';
import { VueportStorage } from '../common/emulator-host';
/** A ROM, as far as its companion files are concerned. */
export interface CompanionRom {
    /** The ROM's file name, which is always known. */
    name: string;
    /**
     * Where the ROM itself is, when the host knows.
     *
     * Undefined in a browser, which is never told where a file came from, and
     * on the desktop for a ROM whose path the shell never saw. Beside-the-ROM
     * needs this; without it there is no "beside".
     *
     * For a ROM that came out of an archive this is the archive — the file
     * that is actually on the disk — and so its name is not `name`. The
     * companion files go into its folder, named for the archive when it is a
     * cartridge's own (`.vbz`, `.vb.zip`) and for the ROM inside when it is a
     * plain `.zip`, which may hold a whole collection — see `besideStem`.
     */
    location?: string;
}
/**
 * Where the store's per-ROM folders live, relative to the store's root.
 *
 * Exported for the library, which weighs it and offers to clear it.
 */
export declare const COMPANION_STORE_ROOT = "roms";
export declare class EmulatorCompanionFiles {
    protected readonly storage: VueportStorage;
    /** Read on every call, so a change in the setting takes effect at once. */
    protected readonly location: () => EmulatorCompanionLocation;
    constructor(storage: VueportStorage, 
    /** Read on every call, so a change in the setting takes effect at once. */
    location: () => EmulatorCompanionLocation);
    /**
     * Whether the files really are going beside the ROM.
     *
     * Not the same question as what the setting says: a ROM the host cannot
     * place has no "beside", and asking for one does not create it. Every path
     * below falls back to the store in that case, and this is how a host can
     * tell somebody that is what happened.
     */
    besideRom(rom: CompanionRom): boolean;
    /** The folder the files are written into. */
    directory(rom: CompanionRom): string;
    /** The ROM's own folder in the store, whatever the setting says. */
    protected storeDirectory(rom: CompanionRom): string;
    /**
     * Whether the file on the disk is an archive the ROM was unpacked from
     * rather than the ROM itself — which is the one case where the two names
     * differ. See {@link CompanionRom.location}.
     */
    protected unpacked(rom: CompanionRom): boolean;
    /**
     * What the files beside the ROM are named for.
     *
     * The file on the disk, so that `Red Alarm.vbz` gets `Red Alarm.p1.sram`
     * whatever the ROM inside it happens to be called — that name is one
     * nobody sees. `.vb.zip` is one extension rather than two, or the save
     * would be `Red Alarm.vb.p1.sram`.
     *
     * A plain `.zip` is the exception, and names its files for the ROM inside:
     * it is as likely to be somebody's whole collection as one cartridge, and
     * every game in it sharing one save would be far worse than a name that
     * does not match the archive's.
     */
    protected besideStem(rom: CompanionRom): string;
    /**
     * The macros that belong to every game rather than to one.
     *
     * Always in the store, never beside a ROM, and the one companion path that
     * takes no ROM: a macro marked global outlives whichever game happened to
     * be running when it was recorded, so putting it in that game's folder —
     * or worse, beside that game's file, where deleting the ROM would take it
     * — would be filing it under the one thing it is not about.
     */
    globalMacros(): string;
    /**
     * The ROM itself, as a path the cheat store hangs `.cht` off.
     *
     * Beside the ROM this is the ROM — or, for one that came out of an
     * archive, where the ROM would be if it had been unpacked next to it under
     * the archive's name. In the store it is where the ROM would be if it were
     * kept there. The stores only ever take it apart, so a path to a file that
     * does not exist is a perfectly good answer.
     */
    romPath(rom: CompanionRom): string;
    /**
     * A player's save file, on the slot they are playing.
     *
     * Numbered even where only one machine is running, because the two of a
     * link session each have a cartridge and neither may write over the
     * other's — and a save that changed its name depending on how the game was
     * started would be worse than one that is always numbered.
     *
     * The store keeps `save.sram` for player one: that is the name it has
     * always written, and a folder of its own means there is nothing there to
     * be ambiguous with. Only a second player needs distinguishing there.
     *
     * Slot A is left unspelt in both layouts, and deliberately: it is the file
     * every save written before slots existed is in, and the one another
     * emulator would read. See `EMULATOR_SAVE_SLOTS`.
     */
    saveRam(rom: CompanionRom, player?: number, slot?: string): string;
    /**
     * One save state of this ROM, by the id the store gave it.
     *
     * No player number and no slot any more. A linked pair is one state in one
     * file — the container has held both machines all along, see
     * `wrapSaveState` — and a state is now identified by when it was taken
     * rather than by a numbered slot somebody had to keep track of.
     *
     * Beside the ROM the id goes between the ROM's name and the extension, so
     * that everything belonging to one game still sorts together in a folder
     * full of games; in the store, where the folder holds nothing else, the
     * files are simply named for what they are.
     */
    saveState(rom: CompanionRom, id: string): string;
    /**
     * The id a file in the states' directory belongs to, or nothing if it is
     * not one of this ROM's states.
     *
     * The inverse of {@link saveState}, and the reason the browser can list a
     * folder rather than keep an index of its own: the naming is the index.
     * Beside a ROM the folder is full of other games' files, so the ROM's own
     * name is what tells them apart.
     */
    saveStateId(rom: CompanionRom, fileName: string): string | undefined;
    /**
     * Where ESSound's tracks are looked for.
     *
     * Always the ROM's own folder when there is one, because that is where the
     * expansion reads them from on real hardware — an archive unpacked into
     * the store is a stand-in for a folder the browser cannot see, not a place
     * anyone chose.
     *
     * So this is deliberately *not* `directory`: the `companionFiles` setting
     * decides where the emulator's own files are written, and a person who
     * would rather keep their saves in the application's storage has not said
     * anything about where a game's audio lives. It said this all along and
     * did the opposite, being written as `directory(rom)` — which left the
     * tracks beside a ROM unfindable for anyone whose saves were set to go to
     * the store, while the symbols in the same folder were read perfectly.
     *
     * An archive is the exception: its tracks are unpacked into the store, as
     * they are in a browser, and looked for there. Unpacking them beside it
     * would mean writing into — and clearing old tracks out of — a folder of
     * somebody's own files, for a game that already carries its tracks.
     */
    sounds(rom: CompanionRom): string;
}
//# sourceMappingURL=emulator-companion-files.d.ts.map