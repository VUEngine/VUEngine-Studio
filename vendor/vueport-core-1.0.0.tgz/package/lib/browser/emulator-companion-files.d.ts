/**
 * Where a ROM's save, save states and cheats go, by the companionFiles setting:
 *
 *   beside the ROM   `<rom dir>/Red Alarm (USA).p1.sram`
 *   in the store     `roms/Red Alarm (USA)/save.sram`
 *
 * Beside a ROM the files share a folder with everything else, so each carries the ROM's name, the convention
 * other emulators follow too. In the store each ROM gets a folder and the files are named for what they are.
 */
import { EmulatorCompanionLocation } from '../common/emulator-sram';
import { VueportStorage } from '../common/emulator-host';
export interface CompanionRom {
    name: string;
    location?: string;
}
export declare const COMPANION_STORE_ROOT = "roms";
export declare class EmulatorCompanionFiles {
    protected readonly storage: VueportStorage;
    protected readonly location: () => EmulatorCompanionLocation;
    constructor(storage: VueportStorage, location: () => EmulatorCompanionLocation);
    besideRom(rom: CompanionRom): boolean;
    directory(rom: CompanionRom): string;
    protected storeDirectory(rom: CompanionRom): string;
    protected unpacked(rom: CompanionRom): boolean;
    protected besideStem(rom: CompanionRom): string;
    globalMacros(): string;
    romPath(rom: CompanionRom): string;
    /**
     * A player's save file on the slot they play. Numbered even with one machine running, as the two of a link
     * session each have a cartridge. The store keeps save.sram for player one, as it always has. Slot A is left
     * unspelt in both layouts: it holds every save from before slots existed, and is the one another emulator
     * would read. See EMULATOR_SAVE_SLOTS
     */
    saveRam(rom: CompanionRom, player?: number, slot?: string): string;
    saveState(rom: CompanionRom, id: string): string;
    saveStateId(rom: CompanionRom, fileName: string): string | undefined;
    /**
     * Where ESSound's tracks are looked for: the ROM's own folder when there is one, as real hardware reads them
     * from there. Deliberately not directory: the companionFiles setting only decides where the emulator's own
     * files go (as directory(rom), tracks beside a ROM were unfindable for anyone saving to the store). An archive
     * is the exception: its tracks are unpacked into the store and looked for there, rather than writing into and
     * clearing a folder of the player's own files.
     */
    sounds(rom: CompanionRom): string;
}
//# sourceMappingURL=emulator-companion-files.d.ts.map