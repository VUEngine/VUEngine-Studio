import * as React from 'react';
export default function PanelAside(props: {
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=PanelAside.d.ts.map