import * as React from 'react';
import { MacroActivity } from '../emulator-macro-store';
export default function EmulatorMacroBadge(props: {
    activity: MacroActivity;
    onShow: () => void;
    onCancelRecording: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorMacroBadge.d.ts.map