import * as React from 'react';
import { VueportSettings } from '../../common/emulator-settings';
import { RetroAchievementsService } from '../emulator-retroachievements';
export default function EmulatorAchievementsSettings(props: {
    settings: VueportSettings;
    achievements: RetroAchievementsService;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorAchievementsSettings.d.ts.map