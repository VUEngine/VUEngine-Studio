import * as React from 'react';
import { VueportSettings } from '../../common/emulator-settings';
import { RetroAchievementsService } from '../emulator-retroachievements';
/**
 * The RetroAchievements pane of the settings window: turn the feature on,
 * sign in, and see the account it is signed in as.
 *
 * Shared: signing in to RetroAchievements is the same act in either host.
 *
 * The service itself owns the account and the running set; this only reads it
 * and asks it to log in or out. `onDidChange` covers everything shown here,
 * including the moment a login finishes, so there is nothing to poll.
 */
export default function EmulatorAchievementsSettings(props: {
    settings: VueportSettings;
    achievements: RetroAchievementsService;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorAchievementsSettings.d.ts.map