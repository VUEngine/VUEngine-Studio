import * as React from 'react';
export default function EmulatorPatchBadge(props: {
    count: number;
    onShow: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorPatchBadge.d.ts.map