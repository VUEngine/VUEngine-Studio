import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { CheatFinder } from '../emulator-cheat-finder';
import { CheatStore } from '../emulator-cheat-store';
/**
 * Finding the address behind a number on the screen.
 *
 * Scan for what the counter says, spend some of it, scan again for what it says
 * now, and repeat until one address is left — the Action Replay loop. When the
 * number is not on screen to read, the same loop works on "it went down"
 * instead, which is what the operators below the value are for.
 *
 * A view inside the Cheats panel rather than a panel of its own, because
 * finding an address and pinning it are two halves of one job: the list this
 * comes back to is where the found address ends up, and living here is also
 * what makes the finder reachable while playing rather than only in Debug mode.
 *
 * The search itself lives in `CheatFinder`, which outlives this
 * component — closing the panel mid-search and coming back does not start over.
 */
export default function EmulatorCheatFinder(props: {
    finder: CheatFinder;
    cheats: CheatStore;
    notifications: VueportNotifications;
    /** Back to the list of cheats. */
    onBack: () => void;
    /** A cheat was made from an address; open it in the editor. */
    onCreated: (index: number) => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheatFinder.d.ts.map