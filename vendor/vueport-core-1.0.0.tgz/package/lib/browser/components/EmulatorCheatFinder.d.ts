import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { CheatFinder } from '../emulator-cheat-finder';
import { CheatStore } from '../emulator-cheat-store';
/**
 * Finds the address behind a number on the screen: scan for what the counter says, change it, scan again,
 * until one address is left (the Action Replay loop). Operators like "decreased" cover values not on screen.
 * A view inside the Cheats panel, as finding an address and pinning it are one job, and so the finder is
 * reachable while playing. The search lives in CheatFinder, which outlives this component.
 */
export default function EmulatorCheatFinder(props: {
    finder: CheatFinder;
    cheats: CheatStore;
    notifications: VueportNotifications;
    onBack: () => void;
    onCreated: (index: number) => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheatFinder.d.ts.map