import * as React from 'react';
export default function EmulatorVideoBadge(props: {
    recording: boolean;
    seconds(): number;
    onStop: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorVideoBadge.d.ts.map