import * as React from 'react';
/**
 * That a video is being recorded, over the corner of the picture.
 *
 * The profile badge's sibling, and there for the same reasons: a recording
 * costs something for as long as it runs, the button that stops it may be in a
 * hidden strip, and the file only exists once it is stopped. Red and blinking,
 * because that is what a record light is.
 *
 * It counts on a clock of its own rather than being redrawn by the emulator.
 * A running recording would otherwise make the whole chrome re-render once a
 * second for the sake of one number — and that number is the only thing here
 * that changes.
 */
export default function EmulatorVideoBadge(props: {
    recording: boolean;
    /**
     * How long it has been running, asked for rather than passed in: the badge
     * decides when to look, so nothing above it has to keep a timer.
     */
    seconds(): number;
    onStop: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorVideoBadge.d.ts.map