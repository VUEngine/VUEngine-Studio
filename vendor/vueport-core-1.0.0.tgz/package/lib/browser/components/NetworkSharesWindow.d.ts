import * as React from 'react';
import { LanSharing, ReachedLanShare } from '../emulator-lan-share';
export interface NetworkSharesHost {
    readonly hasRom: boolean;
    readonly lanSharing?: LanSharing;
    shareInLan?(): Promise<void>;
    readonly lanShareRunning?: boolean;
    retakeLanShare?(): Promise<void>;
    stopLanShare?(): Promise<void>;
    playLanShare?(reached: ReachedLanShare, resume: boolean): Promise<void>;
}
/**
 * Games between devices in the same network, from the title bar's share button: sharing a game from this computer
 * (where the host can serve it), with a QR code a phone's camera opens it from, and the games other computers share,
 * to play from the start or from the moment they were shared. A headset's browser finds them here too. See
 * emulator-lan-share.ts for how the two sides meet. Both hosts show it: the standalone build and VUEngine Studio.
 */
export default function NetworkSharesWindow(props: {
    emulator: NetworkSharesHost;
    onClose: () => void;
}): React.JSX.Element;
//# sourceMappingURL=NetworkSharesWindow.d.ts.map