import * as React from 'react';
import { ScreenPanel } from '../panels/emulator-screen-panel';
export interface EmulatorScreenPreviewProps {
    /** The panel the picture normally lives in. */
    screen: ScreenPanel;
    /**
     * A still to show when there is no game — a screenshot the host points to,
     * recolored through the current palette. See
     * {@link ScreenPanel.setPlaceholder}.
     *
     * Optional: a host with no still to offer gets the live picture alone and
     * no picker at all, rather than a picker with one usable answer. The
     * studio is one — its emulator opens on a ROM it just built, so the case
     * the still covers barely arises there.
     */
    placeholder?: string;
    /** Whether a ROM is loaded, i.e. whether there is a live picture to show. */
    loaded: boolean;
}
/**
 * The Display pane's preview — a mini screen panel.
 *
 * Not a copy of the canvas: presentation was handed to the worker and only one
 * element can hold it, so this borrows the picture itself while it is mounted
 * and gives it back on the way out. Unlike the palette window it once served,
 * this borrows it *with* the decoration and the scale, so both can be seen at
 * work. With no game it shows the still instead, run through the palette so a
 * choice still previews.
 */
export default function EmulatorScreenPreview(props: EmulatorScreenPreviewProps): React.JSX.Element;
//# sourceMappingURL=EmulatorScreenPreview.d.ts.map