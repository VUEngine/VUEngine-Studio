import * as React from 'react';
import { ScreenPanel } from '../panels/emulator-screen-panel';
export interface EmulatorScreenPreviewProps {
    screen: ScreenPanel;
    placeholder?: string;
    loaded: boolean;
}
export default function EmulatorScreenPreview(props: EmulatorScreenPreviewProps): React.JSX.Element;
//# sourceMappingURL=EmulatorScreenPreview.d.ts.map