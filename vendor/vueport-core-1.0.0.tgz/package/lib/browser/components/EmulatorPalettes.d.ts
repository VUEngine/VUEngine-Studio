import React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { VueportSettings } from '../../common/emulator-settings';
export declare function PaletteSwatch(props: {
    colors: string[];
    small?: boolean;
}): React.JSX.Element;
export declare function AnaglyphSwatch(props: {
    left: string;
    right: string;
    small?: boolean;
}): React.JSX.Element;
export type PaletteTarget = 'display' | 'screenshot' | 'video';
interface EmulatorPalettesProps {
    settings: VueportSettings;
    notifications: VueportNotifications;
    target?: PaletteTarget;
    sections?: 'both' | 'color' | 'anaglyph' | 'none';
    preview?: React.ReactNode;
    children?: React.ReactNode | ((pickers: React.ReactNode) => React.ReactNode);
}
export default function EmulatorPalettes(props: EmulatorPalettesProps): React.JSX.Element;
export {};
//# sourceMappingURL=EmulatorPalettes.d.ts.map