import React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { VueportSettings } from '../../common/emulator-settings';
export declare function PaletteSwatch(props: {
    colors: string[];
    small?: boolean;
}): React.JSX.Element;
export declare function AnaglyphSwatch(props: {
    left: string;
    right: string;
    small?: boolean;
}): React.JSX.Element;
/** Whose colors are being picked: the picture itself, or a capture of it. */
export type PaletteTarget = 'display' | 'screenshot' | 'video';
interface EmulatorPalettesProps {
    settings: VueportSettings;
    notifications: VueportNotifications;
    /**
     * Which pair of palette settings the pickers read and write. The Display
     * pane drives the picture's own; the Screenshots and Video panes point at
     * their own, so a screenshot or a recording can be composed differently
     * from what is on screen.
     */
    target?: PaletteTarget;
    /**
     * Which pickers to show. Both, by default — the Display pane offers the
     * two at once because either can apply the moment the mode is changed. A
     * pane that has settled on a mode other than Anaglyph asks for the one
     * that answers it, and one with nothing to pick yet asks for `none`.
     */
    sections?: 'both' | 'color' | 'none';
    /**
     * What sits in the sticky column beside the pickers: the running picture,
     * framed the way the pane's own settings frame it, so a change is seen
     * where it lands. Passed in rather than reached for, because it depends on
     * the host. Left out entirely and the pickers have the window to themselves.
     */
    preview?: React.ReactNode;
    /**
     * The pane's own settings, above the pickers — the Display pane puts its
     * rendering mode, scale and decoration here. Set aside while a custom
     * palette is being edited, which takes the whole column.
     */
    children?: React.ReactNode;
}
/**
 * The palette pickers: the color ramp a single eye is drawn in, and the pair
 * of tints the Anaglyph mode gives the two eyes. Custom entries of either are
 * made, edited and thrown away here, and every choice takes effect
 * immediately.
 *
 * The pane around them supplies its own settings ({@link
 * EmulatorPalettesProps.children}) and the running picture ({@link
 * EmulatorPalettesProps.preview}).
 */
export default function EmulatorPalettes(props: EmulatorPalettesProps): React.JSX.Element;
export {};
//# sourceMappingURL=EmulatorPalettes.d.ts.map