import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
export declare function EmulatorStateBadges(props: {
    host: EmulatorToolbarHost;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorStateBadges.d.ts.map