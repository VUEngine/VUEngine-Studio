/**
 * What a physical controller's buttons do — the Game Pads page of the input
 * settings.
 *
 * A page of its own rather than a section of each player's, because a pad
 * mapping belongs to the *device*: a controller keeps its layout whichever
 * player happens to be holding it, and duplicating it per player would mean
 * setting the same pad up twice. Which player a pad drives is a separate
 * question, and is asked here as one small control rather than by filing the
 * whole mapping under a player.
 *
 * The picture is the same one the keyboard pages draw — see `input-diagram.tsx`
 * — captioned with the pad's own buttons instead of keys. It lights up live
 * while a control is physically held, which is the only honest way to check a
 * mapping: you press the button and watch the right thing light up, without
 * starting a game.
 *
 * The mapping itself, and why it is per device rather than one fixed table, is
 * in `emulator-gamepad-profiles.ts`.
 */
import * as React from 'react';
import { GamepadDatabase } from '../../../common/emulator-gamepad-profiles';
import { VueportSettings } from '../../../common/emulator-settings';
export interface GamePadBindingsProps {
    settings: VueportSettings;
    /** The pane's tab strip, which leads this page's own top row. */
    tabs: React.ReactNode;
    /**
     * Where the harvested device-name database comes from, when the host ships
     * one — see `scripts/fetch-controller-db.mjs`. Asked once, the first time
     * this page is opened, so the file never weighs on a session that does not
     * look at its controllers. Everything works without it: a pad falls back to
     * the name its own id carries.
     */
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator re-reads it. */
    onChange?: () => void;
}
export default function GamePadBindings(props: GamePadBindingsProps): React.JSX.Element;
//# sourceMappingURL=GamePadBindings.d.ts.map