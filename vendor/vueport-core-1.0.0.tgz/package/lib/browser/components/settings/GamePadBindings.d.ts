/**
 * The Game Pads page of the input settings. A page of its own, as a pad mapping belongs to the device: a
 * controller keeps its layout whichever player holds it. Which player it drives is one small control here.
 * The picture is the keyboard pages' one (input-diagram.tsx), captioned with the pad's buttons, and lights up
 * live while a control is held. Why mappings are per device: emulator-gamepad-profiles.ts.
 */
import * as React from 'react';
import { GamepadDatabase, GamepadProfileFile, GamepadUiAction } from '../../../common/emulator-gamepad-profiles';
import { VueportNotifications } from '../../../common/emulator-host';
import { VueportSettings } from '../../../common/emulator-settings';
export interface GamePadBindingsProps {
    settings: VueportSettings;
    notifications: VueportNotifications;
    tabs: React.ReactNode;
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    onChange?: () => void;
    exportFile?: (name: string, data: Uint8Array) => Promise<void>;
    shareProfile?: (file: GamepadProfileFile, note: string) => Promise<'received' | 'duplicate'>;
    uiActions?: readonly GamepadUiAction[];
}
export default function GamePadBindings(props: GamePadBindingsProps): React.JSX.Element;
//# sourceMappingURL=GamePadBindings.d.ts.map