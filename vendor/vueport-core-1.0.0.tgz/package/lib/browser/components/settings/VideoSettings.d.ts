import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
/**
 * The Video pane: the Screenshots pane with the file's own settings above it —
 * a recording is a file in a container at a quality, which a still is not.
 */
export default function VideoSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications;
}): React.JSX.Element;
//# sourceMappingURL=VideoSettings.d.ts.map