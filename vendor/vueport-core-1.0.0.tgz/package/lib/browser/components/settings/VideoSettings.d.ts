import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
export default function VideoSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications;
}): React.JSX.Element;
//# sourceMappingURL=VideoSettings.d.ts.map