import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function SoundSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=SoundSettings.d.ts.map