import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
/**
 * The Screenshots pane: the Display pane pointed at the screenshot settings,
 * and with only the palette the chosen mode actually uses — the mode is settled
 * here rather than being changed underneath it.
 */
export default function ScreenshotSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications;
}): React.JSX.Element;
//# sourceMappingURL=ScreenshotSettings.d.ts.map