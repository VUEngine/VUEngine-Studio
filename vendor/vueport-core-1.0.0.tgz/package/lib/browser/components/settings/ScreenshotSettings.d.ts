import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
export default function ScreenshotSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications;
}): React.JSX.Element;
//# sourceMappingURL=ScreenshotSettings.d.ts.map