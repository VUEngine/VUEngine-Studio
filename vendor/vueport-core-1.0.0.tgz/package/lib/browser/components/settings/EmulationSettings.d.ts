import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function EmulationSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=EmulationSettings.d.ts.map