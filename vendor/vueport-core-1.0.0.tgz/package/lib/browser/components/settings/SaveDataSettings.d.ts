import React from 'react';
import { SettingsPaneProps } from './SettingFields';
/**
 * A game's own saved progress: which cartridge save it plays on, and what a
 * fresh one holds.
 *
 * The save states the emulator takes by itself have a pane of their own — see
 * `SaveStateSettings` — and so does the folder all of it is written to, see
 * `FileSettings`: that one answer covers the states and the cheats as well,
 * so it is not a question about save games.
 */
export default function SaveDataSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=SaveDataSettings.d.ts.map