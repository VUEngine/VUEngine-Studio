import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function SaveDataSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=SaveDataSettings.d.ts.map