import React from 'react';
import { SettingsPaneProps } from './SettingFields';
/**
 * Where a ROM's companion files — its save file, its save states, its cheats —
 * are written.
 *
 * One setting, and a pane of its own rather than a section of Save Data: the
 * answer covers everything written beside a game, not the save in particular,
 * and it is the kind of thing somebody sets up once and then looks for by the
 * name of the folder rather than by what happens to be in it.
 */
export default function FileSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=FileSettings.d.ts.map