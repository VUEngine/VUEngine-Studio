import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function FileSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=FileSettings.d.ts.map