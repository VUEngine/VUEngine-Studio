import * as React from 'react';
import { EmulatorGamePadButton } from '../../emulator-commands';
/**
 * The shell both input pages wear.
 *
 * The keyboard pages and the Game Pads page ask entirely different questions —
 * one binds key codes to commands, the other binds a physical controller's
 * buttons and axes to a per-device profile — but they answer them in the same
 * shape: the controller drawn with its bindings written on it, a strip under it
 * that waits for a press, a row of presets, and the same bindings again as two
 * lists to read straight down. That shape is here, so it is one answer rather
 * than two that drift apart.
 *
 * Nothing in this file knows what a binding is. Each page keeps its own state
 * and hands these the text.
 */
/** A walk through every button, one press at a time. */
export interface CaptureRun {
    step: number;
    total: number;
    queue: EmulatorGamePadButton[];
}
/**
 * The keys pressed while a capture is running.
 *
 * On an escape layer, so a window opened over this one gets the key first, and
 * in the capture phase, because the emulator's own key handler is listening on
 * the page and must not see the key being bound. Installed only when a capture
 * starts or ends — not once per step of a run — so the layer does not flicker
 * as the run advances.
 *
 * What a key means is the page's: the keyboard pages bind it, the Game Pads
 * page watches only for Escape and takes its bindings off the controller.
 */
export declare function useCaptureKeys(waiting: boolean, onKey: (event: KeyboardEvent) => void): void;
/**
 * The strip under the picture, while a press is being waited for.
 *
 * In the same card as the picture rather than in a modal, so the control being
 * asked for stays in view, lit, while it waits.
 */
export declare function CaptureStrip(props: {
    /** What is being bound — a button's name, or a command's. */
    title: React.ReactNode;
    /** Set while walking every button, which is what puts "3 of 14" beside the title. */
    run?: CaptureRun;
    /** How to answer: press a key, press a control on your controller. */
    prompt: React.ReactNode;
    /** What is bound right now, or what a run promises about saving. */
    detail: React.ReactNode;
    /** Cancel, and whatever else this page offers for the binding at hand. */
    actions: React.ReactNode;
}): React.JSX.Element;
/** The button that gets out of a capture without changing anything. */
export declare function CancelCapture(props: {
    onClick: () => void;
}): React.JSX.Element;
/**
 * One binding in a list — the whole row is the button that rebinds it.
 *
 * Lit when the pointer is over it or over the control it names on the picture,
 * so the two halves of the page point at each other.
 */
export declare function BindingRow(props: {
    name: React.ReactNode;
    /** The key or control it answers to, or the "press…" prompt while waiting. */
    value: React.ReactNode;
    lit?: boolean;
    waiting?: boolean;
    onClick: () => void;
    onHoverIn?: () => void;
    onHoverOut?: () => void;
}): React.JSX.Element;
/** A titled list of bindings, beside or under the picture. */
export declare function BindingList(props: {
    title: string;
    children: React.ReactNode;
}): React.JSX.Element;
/** A whole layout in one press, plus whatever else the row carries at its end. */
export declare function PresetRow(props: {
    /** The pills, in the order they are offered. */
    children: React.ReactNode;
    /** Pushed to the far end of the row — "Set all buttons…", and the like. */
    trailing?: React.ReactNode;
}): React.JSX.Element;
export declare function PresetPill(props: {
    label: string;
    /** Marked as the one the bindings currently match. */
    current?: boolean;
    onClick: () => void;
}): React.JSX.Element;
/** The button that walks every control in one run. */
export declare function SetAllButton(props: {
    label: string;
    onClick: () => void;
}): React.JSX.Element;
/** The two controller halves, side by side above the capture strip. */
export declare function PadDiagrams(props: {
    children: React.ReactNode;
}): React.JSX.Element;
/**
 * One page of the input settings: the tab strip and whatever that page carries
 * beside it, then the page itself.
 *
 * The strip is handed in rather than drawn here, because which page is showing
 * is the pane's business — see `InputSettings` — while what else belongs in the
 * row is the page's: whether player two has keys of its own, which controller
 * is being configured, which player it drives.
 */
export declare function InputPage(props: {
    top: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
/** Pushes whatever follows it to the far end of a row. */
export declare function InputSpacer(): React.JSX.Element;
/**
 * The controller a page has found, named as the Game Pads page names it.
 *
 * Every page of the pane carries it in the same place — beside the tab strip,
 * before the spacer — so that moving between them does not move the pad's name
 * from one end of the row to the other.
 */
export declare function PadBadge(props: {
    label?: string;
    title?: string;
}): React.JSX.Element;
/** The picture, the capture strip and the presets, in one titled card. */
export declare function BindingCard(props: {
    children: React.ReactNode;
}): React.JSX.Element;
/** The card and the lists, which wrap under it when the window is narrow. */
export declare function BindingBody(props: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function BindingLists(props: {
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=input-fields.d.ts.map