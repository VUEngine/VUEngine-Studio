import * as React from 'react';
import { VueportSettings } from '../../../common/emulator-settings';
import { EmulatorGamePadButton } from '../../emulator-commands';
export interface CaptureRun {
    step: number;
    total: number;
    queue: EmulatorGamePadButton[];
}
/**
 * On an escape layer, so a window opened over this one gets the key first, and in the capture phase, so the
 * emulator's own key handler on the page does not see the key being bound. Installed only when a capture starts or
 * ends, not per step of a run, so the layer does not flicker. The keyboard pages bind the key, the Game Pads page
 * only watches for Escape
 */
export declare function useCaptureKeys(waiting: boolean, onKey: (event: KeyboardEvent) => void): void;
export declare function CaptureStrip(props: {
    title: React.ReactNode;
    run?: CaptureRun;
    prompt: React.ReactNode;
    detail: React.ReactNode;
    actions: React.ReactNode;
}): React.JSX.Element;
export declare function CancelCapture(props: {
    onClick: () => void;
}): React.JSX.Element;
export declare function BindingRow(props: {
    name: React.ReactNode;
    value: React.ReactNode;
    lit?: boolean;
    waiting?: boolean;
    changed?: boolean;
    changedTitle?: string;
    onClick: () => void;
    onHoverIn?: () => void;
    onHoverOut?: () => void;
}): React.JSX.Element;
export declare function BindingList(props: {
    title: string;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function PresetRow(props: {
    children: React.ReactNode;
    trailing?: React.ReactNode;
}): React.JSX.Element;
export declare function PresetPill(props: {
    label: string;
    current?: boolean;
    onClick: () => void;
}): React.JSX.Element;
export declare function SetAllButton(props: {
    label: string;
    onClick: () => void;
}): React.JSX.Element;
export declare function PadDiagrams(props: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function InputPage(props: {
    top: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function InputSpacer(): React.JSX.Element;
export declare function PadBadge(props: {
    label?: string;
    title?: string;
}): React.JSX.Element;
export declare function BindingCard(props: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function BindingBody(props: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function BindingLists(props: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function TurboRateSlider(props: {
    settings: VueportSettings;
    onChange?: () => void;
}): React.JSX.Element;
export declare function TurboTitle(props: {
    name: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=input-fields.d.ts.map