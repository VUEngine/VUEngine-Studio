import * as React from 'react';
import { XrAvailability, XrBackdrop, XrScreen } from '../../emulator-xr';
/** The VR pane of the settings window, in either host. */
export default function XrSettings(props: {
    /** `undefined` until the browser has answered. */
    availability: XrAvailability | undefined;
    screen: XrScreen;
    backdrop: XrBackdrop;
    onScreen: (screen: XrScreen) => void;
    onBackdrop: (backdrop: XrBackdrop) => void;
}): React.JSX.Element;
//# sourceMappingURL=XrSettings.d.ts.map