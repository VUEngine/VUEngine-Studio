import * as React from 'react';
import { XrAvailability, XrBackdrop, XrScreen } from '../../emulator-xr';
export default function XrSettings(props: {
    availability: XrAvailability | undefined;
    screen: XrScreen;
    backdrop: XrBackdrop;
    onScreen: (screen: XrScreen) => void;
    onBackdrop: (backdrop: XrBackdrop) => void;
}): React.JSX.Element;
//# sourceMappingURL=XrSettings.d.ts.map