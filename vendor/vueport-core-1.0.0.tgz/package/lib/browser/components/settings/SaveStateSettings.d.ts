import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function SaveStateSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=SaveStateSettings.d.ts.map