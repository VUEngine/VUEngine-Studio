import * as React from 'react';
import { GamepadDatabase } from '../../../common/emulator-gamepad-profiles';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
export interface KeyboardBindingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    player: 1 | 2;
    tabs: React.ReactNode;
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    onChange?: () => void;
}
export default function KeyboardBindings(props: KeyboardBindingsProps): React.JSX.Element;
//# sourceMappingURL=KeyboardBindings.d.ts.map