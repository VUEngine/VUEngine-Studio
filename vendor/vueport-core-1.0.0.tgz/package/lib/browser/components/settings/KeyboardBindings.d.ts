import * as React from 'react';
import { GamepadDatabase } from '../../../common/emulator-gamepad-profiles';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
export interface KeyboardBindingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    /** Whose keymap this page edits. */
    player: 1 | 2;
    /** The pane's tab strip, which leads this page's own top row. */
    tabs: React.ReactNode;
    /** The Game Pads page's device-name database, so the pad badge names it the same way. */
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator can re-read it. */
    onChange?: () => void;
}
export default function KeyboardBindings(props: KeyboardBindingsProps): React.JSX.Element;
//# sourceMappingURL=KeyboardBindings.d.ts.map