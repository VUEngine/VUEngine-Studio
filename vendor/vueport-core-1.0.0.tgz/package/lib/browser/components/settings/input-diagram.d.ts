/**
 * The controller drawn with its bindings written on it.
 *
 * Shared by the two halves of the input settings — the keyboard pages, which
 * caption each control with the key it answers to, and the Game Pads page,
 * which captions the same controls with the physical button that drives them.
 * One picture, two sets of captions: the geometry, the hit targets and the
 * lighting behavior are identical, and the only thing that differs is the text
 * and what a click means.
 *
 * So this knows nothing about keymaps or profiles. It takes a function for the
 * caption and one for whether a control is lit, and reports clicks and hovers
 * back out. Both callers keep their own state.
 */
import * as React from 'react';
import { EmulatorGamePadButton } from '../../emulator-commands';
/** The buttons, in the order the list reads and a run asks for them. */
export declare const PAD_BUTTONS: EmulatorGamePadButton[];
/** Where a button is drawn, and where its caption sits beside it. */
export interface PadControl {
    /** The shell it belongs to, so the right SVG draws it. */
    face: 'front' | 'back';
    /** The outline, in `controller.xml`'s coordinates. */
    shape: React.ReactNode;
    /** The transparent target over it. */
    hit: {
        x: number;
        y: number;
        r: number;
    };
    /** The caption's anchor and direction. */
    caption: {
        x: number;
        y: number;
        anchor: 'start' | 'middle' | 'end';
    };
}
export declare const PAD_CONTROLS: Record<EmulatorGamePadButton, PadControl>;
/** The two halves, and the coordinates each is drawn in. */
export declare const PAD_FACES: {
    readonly front: {
        readonly viewBox: "0.16 0.15 249.95 214.70";
        readonly shell: React.JSX.Element;
    };
    readonly back: {
        readonly viewBox: "269.89 0.15 249.95 214.70";
        readonly shell: React.JSX.Element;
    };
};
/** The D-pad arrow, as a Phosphor icon rather than the glyph a label carries. */
export declare function dpadArrow(button: EmulatorGamePadButton): React.JSX.Element | undefined;
/**
 * What a button is called wherever its name is shown — the list, the capture
 * strip. A D-pad direction reads as "Left D-Pad" and an arrow icon; every
 * other button carries the label it was given.
 */
export declare function padButtonName(button: EmulatorGamePadButton, label: React.ReactNode): React.ReactNode;
/** What the caller has to answer for every control on the picture. */
export interface PadDiagramProps {
    face: 'front' | 'back';
    /** The text written beside a control. */
    caption(button: EmulatorGamePadButton): string;
    /** Whether it is drawn lit — hovered, held, or being asked about. */
    isLit(button: EmulatorGamePadButton): boolean;
    /** Whether it is the one currently waiting for an input. */
    isWaiting(button: EmulatorGamePadButton): boolean;
    onSelect(button: EmulatorGamePadButton): void;
    onHover(button: EmulatorGamePadButton | undefined): void;
    /**
     * Where a caption sits, for the ones that need moving.
     *
     * The anchors in `PAD_CONTROLS` were placed for a key name — "E", at most
     * "F10" — and Select's and Start's sit nineteen units apart, which carries
     * one character each. A game pad's controls are named far longer ("Share",
     * "Options"), so that page moves those two apart rather than every page
     * paying for it. Anything not named here keeps its own anchor.
     */
    captionAt?: Partial<Record<EmulatorGamePadButton, PadControl['caption']>>;
    /**
     * The power switch, drawn on the front only.
     *
     * The Virtual Boy has no reset button — its power switch is the reset — so
     * the keyboard pages make it a binding target. The Game Pads page passes
     * nothing and gets it as part of the picture.
     */
    powerSwitch?: React.ReactNode;
}
/** One controller half, with the buttons that belong to it drawn on top. */
export declare function PadDiagram(props: PadDiagramProps): React.JSX.Element;
//# sourceMappingURL=input-diagram.d.ts.map