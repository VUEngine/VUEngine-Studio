import * as React from 'react';
import { EmulatorGamePadButton } from '../../emulator-commands';
export declare const PAD_BUTTONS: EmulatorGamePadButton[];
export interface PadControl {
    face: 'front' | 'back';
    shape: React.ReactNode;
    hit: {
        x: number;
        y: number;
        r: number;
    };
    caption: {
        x: number;
        y: number;
        anchor: 'start' | 'middle' | 'end';
    };
}
export declare const PAD_CONTROLS: Record<EmulatorGamePadButton, PadControl>;
export declare const PAD_FACES: {
    readonly front: {
        readonly viewBox: "0.16 0.15 249.95 214.70";
        readonly shell: React.JSX.Element;
    };
    readonly back: {
        readonly viewBox: "269.89 0.15 249.95 214.70";
        readonly shell: React.JSX.Element;
    };
};
export declare function dpadArrow(button: EmulatorGamePadButton): React.JSX.Element | undefined;
export declare function padButtonName(button: EmulatorGamePadButton, label: React.ReactNode): React.ReactNode;
export interface PadDiagramProps {
    face: 'front' | 'back';
    caption(button: EmulatorGamePadButton): string;
    isLit(button: EmulatorGamePadButton): boolean;
    isWaiting(button: EmulatorGamePadButton): boolean;
    onSelect(button: EmulatorGamePadButton): void;
    onHover(button: EmulatorGamePadButton | undefined): void;
    powerSwitch?: React.ReactNode;
}
export declare function PadDiagram(props: PadDiagramProps): React.JSX.Element;
//# sourceMappingURL=input-diagram.d.ts.map