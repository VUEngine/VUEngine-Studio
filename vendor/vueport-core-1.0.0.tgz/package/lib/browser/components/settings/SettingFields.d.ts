import React from 'react';
import { VueportConfig, VueportSettings } from '../../../common/emulator-settings';
import { VueportHover } from '../kit/KitContext';
/**
 * The parts a settings pane is built from.
 *
 * A pane writes its controls out — `<SwitchSetting id='rewindEnabled' />` —
 * rather than handing over a list of ids for something else to interpret, so
 * which control a setting gets, where it sits and what it sits beside are all
 * read and changed in the pane itself. What still comes from
 * {@link vueportSettingsSchema} is what a setting *is*: its title, its
 * description, its range and its choices, which the application's own
 * preferences page reads from the same declaration.
 */
/** The settings whose value has the given type — what each control can be pointed at. */
type SettingsOf<T> = {
    [K in keyof VueportConfig]: VueportConfig[K] extends T ? K : never;
}[keyof VueportConfig];
export type BooleanSetting = SettingsOf<boolean>;
export type StringSetting = SettingsOf<string>;
export type NumberSetting = SettingsOf<number>;
/** What every pane is handed. */
export interface SettingsPaneProps {
    settings: VueportSettings;
    /**
     * Passed in rather than taken from the kit's context: the settings window
     * is not inside one, and the controls it uses want an explicit hover.
     */
    hover: VueportHover;
    /**
     * Which settings this host has settled for itself, and why.
     *
     * Returns the reason a setting cannot be changed here, or undefined when
     * it can. Shown rather than hidden: a setting that simply vanishes in one
     * application looks like a feature that is missing, where one shown fixed
     * with a reason beside it says what the application does and why it has no
     * choice.
     */
    readOnly?: (id: keyof VueportConfig) => string | undefined;
    /**
     * The settings dialog's running search. When at least one setting in this
     * pane matches every word of it, only the matches are shown; when none do,
     * the query was meant for another pane and everything is shown as normal.
     */
    search?: string;
}
/** Read a setting, and redraw whenever it changes elsewhere. */
export declare function useSetting<K extends keyof VueportConfig>(settings: VueportSettings, id: K): VueportConfig[K];
/**
 * A pane's settings, stacked.
 *
 * `ids` is what the pane is showing right now, which is what the search
 * filters against — a setting the pane has folded away is not one a query can
 * land on.
 */
export declare function SettingsFields(props: SettingsPaneProps & {
    ids: readonly (keyof VueportConfig)[];
    /** The space between the pane's blocks. Sectioned panes sit closer together. */
    gap?: number | string;
    children: React.ReactNode;
}): React.JSX.Element;
/** A fieldset with a legend, for a pane whose settings fall into categories. */
export declare function SettingsSection(props: {
    title: string;
    /** The settings it holds: a search that hides every one of them hides this too. */
    ids: readonly (keyof VueportConfig)[];
    children: React.ReactNode;
}): React.JSX.Element | null;
export declare function SettingsRow(props: {
    /** The settings it holds: a search that hides every one of them hides this too. */
    ids: readonly (keyof VueportConfig)[];
    children: React.ReactNode;
}): React.JSX.Element | null;
/**
 * What a setting does, always visible between its title and its control — the
 * same reading order as the standalone Welcome pane's "Remembered ROMs".
 */
export declare const SettingDescription: import("styled-components/dist/types").IStyledComponentBase<"web", Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "style"> & {
    style?: React.CSSProperties | import("styled-components/dist/types").CSSPropertiesWithVars | undefined;
}> & string;
/**
 * The title, description and reset button around one control.
 *
 * Nothing is hidden behind hover: every setting follows the same
 * title-description-control reading order.
 */
export declare function Setting(props: {
    id: keyof VueportConfig;
    children: React.ReactNode;
}): React.JSX.Element | null;
/** A boolean, as the switch every pane shows one with. */
export declare function SwitchSetting(props: {
    id: BooleanSetting;
}): React.JSX.Element;
/**
 * A handful of choices, as a segmented control. Past four or five it stops
 * being readable and {@link DropdownSetting} is the answer instead.
 */
export declare function ChoiceSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
/** More choices than a segmented control stays readable at. */
export declare function DropdownSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
/**
 * The rendering mode as a set of pictures rather than phrases: a card per mode
 * with a schematic of what it does to the picture.
 */
export declare function RenderingModeSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
export declare function SliderSetting(props: {
    id: NumberSetting;
}): React.JSX.Element;
/**
 * Where the Ambient halo takes its color from: a color well, and under it the
 * switch that hands the choice to the current palette instead.
 *
 * Two settings under one title, because they are one decision. While the
 * palette is the answer the well stays put and goes dim, showing the color
 * that is being used rather than the one that was last chosen — what the halo
 * is doing is the thing worth seeing, and a well that vanished would leave the
 * switch to say it in words alone.
 */
export declare function DecorationColorSetting(props: {
    /**
     * VB Color hardware is driving the picture. Optional, and false where a
     * host has no such thing: it only changes which color the well shows while
     * the switch is on, since colors then come from CRAM rather than the
     * chosen palette.
     */
    vbcHardware?: boolean;
}): React.JSX.Element;
export {};
//# sourceMappingURL=SettingFields.d.ts.map