import React from 'react';
import { VueportConfig, VueportSettings } from '../../../common/emulator-settings';
import { VueportHover } from '../kit/KitContext';
type SettingsOf<T> = {
    [K in keyof VueportConfig]: VueportConfig[K] extends T ? K : never;
}[keyof VueportConfig];
export type BooleanSetting = SettingsOf<boolean>;
export type StringSetting = SettingsOf<string>;
export type NumberSetting = SettingsOf<number>;
export interface SettingsPaneProps {
    settings: VueportSettings;
    hover: VueportHover;
    readOnly?: (id: keyof VueportConfig) => string | undefined;
    search?: string;
}
export declare function useSetting<K extends keyof VueportConfig>(settings: VueportSettings, id: K): VueportConfig[K];
export declare function SettingsFields(props: SettingsPaneProps & {
    ids: readonly (keyof VueportConfig)[];
    gap?: number | string;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function SettingsSection(props: {
    title: string;
    ids: readonly (keyof VueportConfig)[];
    children: React.ReactNode;
}): React.JSX.Element | null;
export declare function SettingsRow(props: {
    ids: readonly (keyof VueportConfig)[];
    even?: boolean;
    children: React.ReactNode;
}): React.JSX.Element | null;
export declare const SettingDescription: import("styled-components/dist/types").IStyledComponentBase<"web", Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "style"> & {
    style?: React.CSSProperties | import("styled-components/dist/types").CSSPropertiesWithVars | undefined;
}> & string;
export declare function Setting(props: {
    id: keyof VueportConfig;
    children: React.ReactNode;
}): React.JSX.Element | null;
export declare function SwitchSetting(props: {
    id: BooleanSetting;
}): React.JSX.Element;
export declare function ChoiceSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
export declare function DropdownSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
export declare function RenderingModeSetting(props: {
    id: StringSetting;
}): React.JSX.Element;
export declare function NumberChoiceSetting(props: {
    id: NumberSetting;
}): React.JSX.Element;
export declare function SliderSetting(props: {
    id: NumberSetting;
}): React.JSX.Element;
export declare function DecorationColorSetting(props: {
    vbcHardware?: boolean;
}): React.JSX.Element;
export {};
//# sourceMappingURL=SettingFields.d.ts.map