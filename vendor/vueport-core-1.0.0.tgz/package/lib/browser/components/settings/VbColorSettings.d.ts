import React from 'react';
import { SettingsPaneProps } from './SettingFields';
export default function VbColorSettings(props: SettingsPaneProps): React.JSX.Element;
//# sourceMappingURL=VbColorSettings.d.ts.map