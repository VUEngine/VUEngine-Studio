import * as React from 'react';
export declare const CONTROLLER_FRONT_SHELL: React.JSX.Element;
export declare const CONTROLLER_POWER_SWITCH: React.JSX.Element;
export declare const CONTROLLER_BACK_SHELL: React.JSX.Element;
//# sourceMappingURL=controller-art.d.ts.map