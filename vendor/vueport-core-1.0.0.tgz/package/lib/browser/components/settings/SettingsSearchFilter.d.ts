import * as React from 'react';
/**
 * The settings search, for a pane that is written by hand.
 *
 * The schema-backed panes filter themselves: they know which settings they
 * hold and what each is called (see `SettingsFields`). A hand-written pane has
 * no such list — its rows are whatever it renders — so this reads them off the
 * page instead, the same way somebody looking at the pane would.
 *
 * A row is one of the setting layouts the panes share (`ROW`); a group is a
 * fieldset, which shows in full when its legend matches and otherwise only for
 * the rows in it that do, and goes when none of them does. Anything else — a
 * note, a status line, the library's tiles — stays when its own text matches.
 * When nothing in the pane matches, the query was meant for the pane's label or
 * keywords rather than a row, and everything is shown, as the schema panes do.
 *
 * Read again on every change below it, since a pane redraws by itself: a
 * switch that brings more rows with it, a scan that finishes, a chunk that
 * arrives.
 */
export declare function SettingsSearchFilter(props: {
    search: string;
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=SettingsSearchFilter.d.ts.map