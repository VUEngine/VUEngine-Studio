import * as React from 'react';
/**
 * The settings search for a hand-written pane, which unlike the schema-backed panes (SettingsFields) has no
 * list of its settings, so this reads them off the page. A row is one of the shared setting layouts (ROW); a
 * fieldset shows in full when its legend matches, otherwise only its matching rows, and goes when none does.
 * Anything else stays when its own text matches. When nothing matches, everything is shown, as the query was
 * meant for the pane's label or keywords. Re-read on every change below it, as panes redraw by themselves.
 */
export declare function SettingsSearchFilter(props: {
    search: string;
    children: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=SettingsSearchFilter.d.ts.map