import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
interface DisplayProps extends SettingsPaneProps {
    vbcHardwareActive?: boolean;
    pickers?: React.ReactNode;
}
export default function DisplaySettings(props: DisplayProps & {
    notifications: VueportNotifications;
    preview?: React.ReactNode;
}): React.JSX.Element;
export {};
//# sourceMappingURL=DisplaySettings.d.ts.map