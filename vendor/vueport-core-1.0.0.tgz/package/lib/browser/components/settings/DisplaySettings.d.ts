import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { SettingsPaneProps } from './SettingFields';
/** What the Display pane is handed beyond the settings themselves. */
interface DisplayProps extends SettingsPaneProps {
    /**
     * Whether VB Color hardware is driving the picture. Passed through to the
     * decoration color, which is the one control here that answers differently
     * for it — see {@link DecorationColorSetting}.
     */
    vbcHardwareActive?: boolean;
}
/**
 * The Display pane: the rendering mode, the scale and the screen decoration,
 * then the colors the picture is shown in, with the running picture in the
 * column beside them so a change lands where it can be seen.
 */
export default function DisplaySettings(props: DisplayProps & {
    notifications: VueportNotifications;
    /** The running picture. Passed in, because where it comes from is the host's. */
    preview?: React.ReactNode;
}): React.JSX.Element;
export {};
//# sourceMappingURL=DisplaySettings.d.ts.map