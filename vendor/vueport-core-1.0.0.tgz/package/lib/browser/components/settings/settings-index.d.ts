import { VueportConfig } from '../../../common/emulator-settings';
export declare const DECORATION_SETTINGS: readonly (keyof VueportConfig)[];
export declare const DISPLAY_SETTINGS: readonly (keyof VueportConfig)[];
export declare const SCREENSHOT_SETTINGS: readonly (keyof VueportConfig)[];
export declare const RECORDING_SETTINGS: readonly (keyof VueportConfig)[];
export declare const VIDEO_SETTINGS: readonly (keyof VueportConfig)[];
export declare const REWIND_SETTINGS: readonly (keyof VueportConfig)[];
export declare const SPEED_SETTINGS: readonly (keyof VueportConfig)[];
export declare const EMULATION_SETTINGS: readonly (keyof VueportConfig)[];
export declare const SAVE_STATE_SETTINGS: readonly (keyof VueportConfig)[];
export declare const SAVE_DATA_SETTINGS: readonly (keyof VueportConfig)[];
export declare const FILE_SETTINGS: readonly (keyof VueportConfig)[];
export declare const VB_COLOR_SETTINGS: readonly (keyof VueportConfig)[];
export declare const SOUND_SETTINGS: readonly (keyof VueportConfig)[];
export declare const TOUCH_SETTINGS: readonly (keyof VueportConfig)[];
//# sourceMappingURL=settings-index.d.ts.map