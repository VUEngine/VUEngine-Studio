import * as React from 'react';
import { VueportSettings } from '../../../common/emulator-settings';
/**
 * The Input pane's Touch page: when the on-screen controller shows, how it looks and answers, and the way into its
 * layout editor, which needs the game's screen and so closes the settings while it is up (onEditLayout)
 */
export default function TouchSettings(props: {
    settings: VueportSettings;
    tabs?: React.ReactNode;
    onEditLayout: () => void;
    search?: string;
}): React.JSX.Element;
//# sourceMappingURL=TouchSettings.d.ts.map