import * as React from 'react';
import { GamepadDatabase } from '../../../common/emulator-gamepad-profiles';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
/**
 * The Input pane: which control does what.
 *
 * Three pages behind one tab strip. Two of them are keyboards — player one's
 * and player two's — and the third is whatever physical controller is plugged
 * in. They are separate components because they answer separate questions: a
 * keymap binds key codes to the emulator's commands and belongs to a player,
 * while a pad mapping binds a controller's buttons and axes to a profile and
 * belongs to the *device*. What they share is the shape of the answer, which
 * is in `input-fields.tsx`.
 *
 * All this owns is the strip and which page is showing. Each page draws its own
 * top row around the strip, because what belongs beside it is the page's:
 * whether player two has keys of its own, which controller is being configured,
 * which player it drives.
 */
/** The pages of the tab strip at the top. */
export type InputSettingsPage = 'player1' | 'player2' | 'gamePads';
export interface InputSettingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    /** Passed straight to the Game Pads page; see its own props. */
    loadGamepadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator can re-read it. */
    onChange?: () => void;
    /**
     * The page to open on, for a link straight to one — the status bar's
     * controller entry. Read once, when the pane mounts; player one otherwise.
     */
    initialPage?: InputSettingsPage;
}
export default function InputSettings(props: InputSettingsProps): React.JSX.Element;
//# sourceMappingURL=InputSettings.d.ts.map