import * as React from 'react';
import { GamepadDatabase, GamepadProfileFile, GamepadUiAction } from '../../../common/emulator-gamepad-profiles';
import { VueportNotifications } from '../../../common/emulator-host';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
export type InputSettingsPage = 'player1' | 'player2' | 'gamePads' | 'touch';
export interface InputSettingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    notifications: VueportNotifications;
    loadGamepadDatabase?: () => Promise<GamepadDatabase | undefined>;
    exportFile?: (name: string, data: Uint8Array) => Promise<void>;
    shareProfile?: (file: GamepadProfileFile, note: string) => Promise<'received' | 'duplicate'>;
    gamepadUiActions?: readonly GamepadUiAction[];
    onChange?: () => void;
    initialPage?: InputSettingsPage;
    onEditTouchLayout?: () => void;
    search?: string;
}
export default function InputSettings(props: InputSettingsProps): React.JSX.Element;
//# sourceMappingURL=InputSettings.d.ts.map