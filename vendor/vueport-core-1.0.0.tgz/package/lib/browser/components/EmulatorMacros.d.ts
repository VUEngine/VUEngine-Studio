import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { MacroStore } from '../emulator-macro-store';
/**
 * The macros kept beside the ROM: recorded button sequences, named, and played
 * back on demand.
 *
 * The list on top is every macro in the file; opening one shows what it is
 * made of and lets it be renamed. Everything here drives the store, which owns
 * the list, writes the file and holds the buttons down during playback — so a
 * macro plays on with this closed, and this is only a view of it.
 *
 * A component rather than a panel, for the reason the cheats are one: it is
 * shown in two places and only one of them is a panel. In Debug mode it is
 * docked like every other inspector; while playing it sits beside the screen
 * with no dock involved, because recording a sequence is something you do
 * *while* playing and should not cost you the game you are in.
 */
export default function EmulatorMacros(props: {
    macros: MacroStore;
    notifications: VueportNotifications;
    /**
     * Put these away, when there is somewhere to put them away to.
     *
     * Given for the strip beside the screen, which has no chrome of its own to
     * close it by. The docked panel leaves this out: it has a tab.
     */
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorMacros.d.ts.map