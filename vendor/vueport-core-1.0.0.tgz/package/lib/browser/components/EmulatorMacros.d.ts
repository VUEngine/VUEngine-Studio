import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { MacroStore } from '../emulator-macro-store';
/**
 * The macros kept beside the ROM. Only a view of the store, which owns the list, writes the file and holds the
 * buttons during playback, so a macro plays on with this closed. A component rather than a panel, like the
 * cheats: in Debug mode it is docked, while playing it sits beside the screen, as recording happens mid-game.
 */
export default function EmulatorMacros(props: {
    macros: MacroStore;
    notifications: VueportNotifications;
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorMacros.d.ts.map