import * as React from 'react';
export default function EmulatorCheatBadge(props: {
    count: number;
    onShow: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheatBadge.d.ts.map