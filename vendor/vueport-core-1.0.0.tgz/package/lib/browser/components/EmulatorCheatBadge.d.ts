import * as React from 'react';
/**
 * How many cheats are on, over the corner of the picture.
 *
 * Shown only while the cheats themselves are put away. A cheat changes what a
 * game does, and a game that is behaving oddly for a reason somebody set up an
 * hour ago and forgot is a bad afternoon — so once they are out of sight,
 * something has to keep saying they are there.
 *
 * A button, because the obvious thing to want after noticing it is to see
 * which ones.
 */
export default function EmulatorCheatBadge(props: {
    count: number;
    onShow: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheatBadge.d.ts.map