import * as React from 'react';
import { VueportConfig, VueportSettings } from '../../common/emulator-settings';
export interface SettingsTabSpec<T extends string = string> {
    id: T;
    label: string;
    icon: React.ReactNode;
    settings?: readonly (keyof VueportConfig)[];
    alsoResets?: readonly (keyof VueportConfig)[];
    keywords?: string;
    foot?: boolean;
}
export interface SettingsWindowParts {
    title: string;
    icon: React.ReactNode;
    search: React.ReactNode;
    resetAll?: React.ReactNode;
    rail: React.ReactNode;
    pane: React.ReactNode;
}
export declare function SettingsWindow<T extends string>(props: {
    tabs: SettingsTabSpec<T>[];
    tab: T;
    onTab: (tab: T) => void;
    onClose: () => void;
    renderPane: (tab: T, search: string) => React.ReactNode;
    paneBoundary?: (tab: T, pane: React.ReactNode) => React.ReactNode;
    frame?: (parts: SettingsWindowParts) => React.ReactNode;
    resetAll?: {
        settings: VueportSettings;
        confirm: () => Promise<boolean>;
    };
    closable?: boolean;
    startOnList?: boolean;
    leaving?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=SettingsWindow.d.ts.map