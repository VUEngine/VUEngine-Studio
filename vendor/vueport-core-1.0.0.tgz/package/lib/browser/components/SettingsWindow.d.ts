import * as React from 'react';
import { VueportConfig } from '../../common/emulator-settings';
/**
 * One tab of the settings window, as its host describes it.
 *
 * The window knows nothing about what settings exist or how a pane is built;
 * it is handed this list and renders a rail from it. That is what lets the two
 * hosts carry different tabs over the same window — the standalone build has
 * panes for the things an application owns (its APIs, its start page, its
 * theme, its About) that mean nothing inside an IDE.
 */
export interface SettingsTabSpec<T extends string = string> {
    id: T;
    /** Localized, and what the rail is sorted by. */
    label: string;
    icon: React.ReactNode;
    /**
     * The schema-backed settings this pane shows, so their titles and
     * descriptions feed the search index. Kept to exactly what the pane shows
     * and filters, so a query that lights this tab always leaves it with
     * something.
     */
    settings?: readonly (keyof VueportConfig)[];
    /**
     * Extra words this pane answers to. For a hand-written pane, which does not
     * filter its own rows, this is all there is to route a query to it by
     * besides its label.
     */
    keywords?: string;
    /** Sits alone at the foot of the rail, the way an application's About does. */
    foot?: boolean;
}
/**
 * The settings window: a titled window with a tab rail down its left and one
 * pane at a time beside it.
 *
 * Deliberately holds none of the panes' own logic — `renderPane` builds each one
 * and this only decides which is on screen. The pane that is not showing is not
 * rendered, the same as when each of these was its own window: the input mapper
 * captures keys while it is mounted, and one sitting live behind another tab has
 * no business doing that.
 */
export declare function SettingsWindow<T extends string>(props: {
    /** Every tab this host carries. The rail's order is computed, not this one. */
    tabs: SettingsTabSpec<T>[];
    tab: T;
    onTab: (tab: T) => void;
    onClose: () => void;
    /** One pane, built for the given tab and handed the running search query. */
    renderPane: (tab: T, search: string) => React.ReactNode;
    /**
     * Wraps the pane, for a host whose panes arrive as separately loaded chunks:
     * the window, its search and its rail stay mounted while one is on its way,
     * and an error belongs in the pane rather than in place of the whole window.
     * A host that builds its panes outright leaves this out.
     */
    paneBoundary?: (tab: T, pane: React.ReactNode) => React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=SettingsWindow.d.ts.map