import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
/**
 * The transport, as a strip that floats over the picture.
 *
 * The same controls as `EmulatorToolbar` and the same host interface — this is
 * a second presentation, not a second emulator. Which one a host gets is the
 * `chrome` prop on `Emulator`: the studio and anything embedding the emulator
 * in a workbench want the toolbar, because there the emulator is one panel
 * among many and a row of controls above it reads as that panel's own. The
 * standalone application wants this, because there the picture is the product
 * and a permanent toolbar frames a 384x224 image with an IDE.
 *
 * What is deliberately NOT here, compared to the toolbar: the scale, rendering
 * mode and palette selectors, the Play/Debug switch, and linking a second
 * player. Those are settings rather than transport — they are changed once and
 * then left, and they live in the settings window and the title bar
 * respectively. Keeping them out is what lets this be a strip rather than a
 * floating toolbar.
 *
 * The strip carries no state of its own beyond nothing: what is switched on is
 * said by the badges over the picture (`EmulatorStateBadges`), because this
 * strip is not always on screen and a lit button nobody can see is not a
 * status display.
 */
export interface EmulatorControlStripProps {
    host: EmulatorToolbarHost;
    /** Held open regardless of the pointer, and drawn as pressed. */
    pinned?: boolean;
    /**
     * Left out for a strip the host has placed somewhere of its own — the
     * studio's title bar — where there is no hiding to pin against. The pin
     * button is then not drawn at all, rather than drawn doing nothing.
     */
    onTogglePinned?(): void;
    /**
     * Sits in a row the host owns rather than floating over the picture.
     *
     * It is the same controls either way; what changes is that it is not a
     * layer — no rounded slab, no shadow, and it gives its height to the row
     * around it instead of claiming its own.
     */
    inline?: boolean;
}
export declare function EmulatorControlStrip(props: EmulatorControlStripProps): React.JSX.Element;
//# sourceMappingURL=EmulatorControlStrip.d.ts.map