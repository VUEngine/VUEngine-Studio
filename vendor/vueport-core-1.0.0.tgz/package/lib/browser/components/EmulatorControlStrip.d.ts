import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
/**
 * The transport as a strip floating over the picture: the same controls and host interface as EmulatorToolbar,
 * chosen by Emulator's chrome prop. Workbench hosts like the studio want the toolbar, the standalone app this, as
 * there the picture is the product. Scale, rendering mode, palette, Play/Debug and link are settings, so they live
 * in the settings window and title bar. No state of its own: what is on is shown by EmulatorStateBadges, as the
 * strip is not always on screen
 */
export interface EmulatorControlStripProps {
    host: EmulatorToolbarHost;
    pinned?: boolean;
    onTogglePinned?(): void;
    inline?: boolean;
}
export declare function EmulatorControlStrip(props: EmulatorControlStripProps): React.JSX.Element;
//# sourceMappingURL=EmulatorControlStrip.d.ts.map