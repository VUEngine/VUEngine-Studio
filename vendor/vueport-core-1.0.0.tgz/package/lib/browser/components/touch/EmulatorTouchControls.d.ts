import * as React from 'react';
import { TouchControlsLayout, VueportSettings } from '../../../common/emulator-settings';
import { TouchOrientation } from './touch-layout';
export interface EmulatorTouchControlsProps {
    settings: VueportSettings;
    orientation: TouchOrientation;
    onKeys: (keys: number) => void;
    editing?: {
        onDone: (layout: TouchControlsLayout) => void;
        onCancel: () => void;
    };
}
export declare function EmulatorTouchControls(props: EmulatorTouchControlsProps): React.JSX.Element;
//# sourceMappingURL=EmulatorTouchControls.d.ts.map