import { TouchControlsLayout } from '../../../common/emulator-settings';
import { VbKey } from '../../../common/vb-constants';
/**
 * The on-screen controller's parts and where each goes. Laid out after the real pad: L and R on top, a d-pad under
 * each, Select and Start under the left one where B and A sit under the right, mirrored (Select outside and higher,
 * as A is). All eight are round or a cross, as on the hardware.
 *
 * A place is a centre measured from a corner of the controller's area, in CSS pixels at 100 %: from the left or right
 * edge across, from the top or bottom edge down. So the arrangement keeps to the edges the thumbs are at, however
 * wide or tall the phone is, and only the space between grows.
 */
export type TouchControlId = 'l' | 'r' | 'ldpad' | 'rdpad' | 'select' | 'start' | 'b' | 'a';
export declare const TOUCH_CONTROL_IDS: readonly TouchControlId[];
export type TouchOrientation = 'portrait' | 'landscape';
export interface TouchControlSpot {
    from: 'left' | 'right';
    x: number;
    fromY: 'top' | 'bottom' | 'middle';
    y: number;
    size: number;
}
export interface TouchLayoutSpec {
    width: number;
    height: number;
    side: number;
    spots: Record<TouchControlId, TouchControlSpot>;
}
export declare const TOUCH_LAYOUTS: Record<TouchOrientation, TouchLayoutSpec>;
export declare const BUTTON_KEYS: Record<Exclude<TouchControlId, 'ldpad' | 'rdpad'>, VbKey>;
export declare const DPAD_KEYS: Record<'ldpad' | 'rdpad', {
    up: VbKey;
    right: VbKey;
    down: VbKey;
    left: VbKey;
}>;
export declare function isDpad(id: TouchControlId): id is 'ldpad' | 'rdpad';
/**
 * How much smaller than drawn the controller has to be for this area, never larger: a phone shorter than the layout
 * (an iPhone SE upright) shrinks it rather than letting L and R run into the picture. Not below two thirds, where the
 * buttons would get too small to hit; the area scrolls nothing, so what is left over is simply clipped.
 */
export declare function layoutScale(spec: TouchLayoutSpec, width: number, height: number): number;
export interface PlacedControl {
    id: TouchControlId;
    cx: number;
    cy: number;
    size: number;
}
export declare function placeControls(orientation: TouchOrientation, width: number, height: number, size: number, custom: TouchControlsLayout | undefined): PlacedControl[];
export declare function sideClearance(orientation: TouchOrientation, width: number, height: number, size: number): number;
export declare const PLACEMENT_SCALE_STEP = 0.05;
export declare const PLACEMENT_SCALE_RANGE: {
    min: number;
    max: number;
};
//# sourceMappingURL=touch-layout.d.ts.map