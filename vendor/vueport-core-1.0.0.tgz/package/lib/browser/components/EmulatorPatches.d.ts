import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { PatchStore } from '../emulator-patch-store';
export default function EmulatorPatches(props: {
    patches: PatchStore;
    notifications: VueportNotifications;
    /**
     * Make sure the VB Color hardware is on before a colorization is switched
     * on, offering to turn it on — which restarts the game — if not.
     * Resolves to whether it is on now.
     */
    ensureVbcSupport?: () => Promise<boolean>;
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorPatches.d.ts.map