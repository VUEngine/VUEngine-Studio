import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { PatchStore } from '../emulator-patch-store';
export default function EmulatorPatches(props: {
    patches: PatchStore;
    notifications: VueportNotifications;
    ensureVbcSupport?: () => Promise<boolean>;
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorPatches.d.ts.map