import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
import type { XrAvailability } from '../emulator-xr';
export type PlayStrip = 'save-states' | 'cheats' | 'macros' | 'patches' | 'achievements';
export interface TitleBarHost extends EmulatorToolbarHost {
    readonly hasRom: boolean;
    readonly settingsOpen: boolean;
    toggleDebugMode(): void;
    readonly vbcSupportEnabled: boolean;
    readonly vbcHeaderPillLabel?: string;
    pickHardwareMode?(): Promise<void>;
    offerToLeaveHardcore?(): Promise<void>;
    readonly linksWithoutRom?: boolean;
    toggleXr?(): Promise<void>;
    readonly xrAvailability?: XrAvailability;
    readonly xrActive?: boolean;
    openNetworkShares?(): void;
    readonly networkSharesOpen?: boolean;
    readonly lanShareActive?: boolean;
    leaveXr?(): void;
}
/**
 * `none`: a browser, or a strip inside a larger application; no controls, no drag.
 * `overlay`: macOS keeps its traffic lights and lends the space behind them, the inset keeps our controls clear.
 * Fake lights would lose the hover symbols, option-click to zoom and double-click to fill.
 * `custom`: the frame is off, so minimize, maximize and close are drawn here.
 */
export type TitleBarWindowControls = 'none' | 'overlay' | 'custom';
export interface TitleBarProps {
    emulator: TitleBarHost;
    title?: React.ReactNode;
    logo?: React.ReactNode;
    windowControls?: TitleBarWindowControls;
    onMinimizeWindow?: () => void;
    onMaximizeWindow?: () => void;
    onCloseWindow?: () => void;
    fullscreen?: boolean;
}
export default function TitleBar(props: TitleBarProps): React.JSX.Element;
//# sourceMappingURL=TitleBar.d.ts.map