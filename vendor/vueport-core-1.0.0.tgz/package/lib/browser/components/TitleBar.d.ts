import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
/**
 * Which of the five strips a control opens.
 *
 * Named for what they are rather than for a mode: they open beside the screen
 * in Play and in Debug alike. They were Play mode's alone once, with docked
 * panels standing in for them while debugging — two ways to reach one list,
 * and a button whose meaning changed with the mode.
 */
export type PlayStrip = 'save-states' | 'cheats' | 'macros' | 'patches' | 'colors' | 'achievements';
/**
 * What the title bar needs beyond what the toolbar already asks for.
 *
 * Everything optional is a thing a host may simply not have: a build with no
 * VB Color hardware switch draws no pill, one with no Debug mode draws no bug.
 */
export interface TitleBarHost extends EmulatorToolbarHost {
    /** Whether there is a cartridge in the machine — the panel controls need one. */
    readonly hasRom: boolean;
    /** Whether the settings window is open, so its button can say so. */
    readonly settingsOpen: boolean;
    toggleDebugMode(): void;
    /** Whether the color unit is switched on at all; off leaves the Colors panel nothing to do. */
    readonly vbcSupportEnabled: boolean;
    /** What the VB Color pill says, or nothing for a machine that is not one. */
    readonly vbcHeaderPillLabel?: string;
    /** The pill's click: choose which console this is. */
    pickHardwareMode?(): Promise<void>;
    /** Turn hardcore mode off, for the pill that says it is on. */
    offerToLeaveHardcore?(): Promise<void>;
}
/**
 * How much of the window this strip is responsible for.
 *
 * `none` — a browser, or a strip inside a larger application. No window, no
 * controls, no drag.
 *
 * `overlay` — macOS keeps its traffic lights and lends the space behind them.
 * Nothing to draw; the strip only has to keep its own controls clear of the
 * three, which is what the inset is for. Fake lights would lose the symbols
 * that appear on hover, option-click to zoom and double-click to fill.
 *
 * `custom` — the frame is off, so minimize, maximize and close are drawn here.
 */
export type TitleBarWindowControls = 'none' | 'overlay' | 'custom';
export interface TitleBarProps {
    emulator: TitleBarHost;
    /**
     * What sits on the left, where a window would put its document's name.
     *
     * The one place the two hosts differ, and the reason this is a slot: the
     * standalone build names the ROM here and offers the way out of it; the
     * studio's tab already names the file, so it puts the emulator's transport
     * toolbar here instead.
     */
    title?: React.ReactNode;
    /** The application's mark, left of the title. Nothing is drawn without one. */
    logo?: React.ReactNode;
    /** See {@link TitleBarWindowControls}. Defaults to `none`. */
    windowControls?: TitleBarWindowControls;
    onMinimizeWindow?: () => void;
    onMaximizeWindow?: () => void;
    onCloseWindow?: () => void;
    /**
     * Whether the view is fullscreen, so the button can invite the way out
     * rather than the way in.
     *
     * Left out, the page's own fullscreen element is watched, which is right
     * for anything running in a browser. A host whose fullscreen is the
     * window's — the desktop shell, where macOS's own green button changes it
     * from outside this strip — passes what it knows instead.
     */
    fullscreen?: boolean;
}
export default function TitleBar(props: TitleBarProps): React.JSX.Element;
//# sourceMappingURL=TitleBar.d.ts.map