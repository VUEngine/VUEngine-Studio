import * as React from 'react';
import { EmulatorRewindBrowser } from '../emulator-rewind-browser';
export interface EmulatorRewindStripProps {
    browser: EmulatorRewindBrowser;
}
/**
 * The rewind history as a strip of thumbnails along the bottom of the picture, in place of the control strip while it
 * is up; the picture above shows the moment picked. Keys are heard on the window ahead of everything else, as the
 * emulator's own key handling is off while the strip is open. Subscribes to the browser itself, so a thumbnail
 * arriving redraws only this.
 */
export declare function EmulatorRewindStrip(props: EmulatorRewindStripProps): React.JSX.Element | null;
//# sourceMappingURL=EmulatorRewindStrip.d.ts.map