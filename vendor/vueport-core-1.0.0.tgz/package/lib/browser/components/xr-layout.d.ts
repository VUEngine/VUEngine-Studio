export declare function useXrLayout(): boolean;
//# sourceMappingURL=xr-layout.d.ts.map