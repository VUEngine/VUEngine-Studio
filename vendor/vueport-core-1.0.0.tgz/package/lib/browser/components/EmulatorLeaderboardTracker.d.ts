import * as React from 'react';
import { RetroAchievementsService } from '../emulator-retroachievements';
export default function EmulatorLeaderboardTracker(props: {
    achievements: RetroAchievementsService;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorLeaderboardTracker.d.ts.map