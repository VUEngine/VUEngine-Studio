import * as React from 'react';
import { RetroAchievementsService } from '../emulator-retroachievements';
/**
 * The running leaderboard attempts' values, over the corner of the picture.
 *
 * A leaderboard attempt is the one thing RetroAchievements tracks that the
 * player has to be able to see while it happens — a timer they are racing, a
 * score they are pushing — so unlike the achievements, which can wait for the
 * panel, this belongs over the game.
 *
 * Not a button: there is nothing to open. The panel lists the same
 * leaderboards, and an attempt in progress is not the moment to send anybody
 * looking at a list.
 *
 * It subscribes to the service itself rather than being handed the values,
 * because they change many times a second while an attempt runs and nothing
 * larger than this should redraw at that rate — which is exactly why
 * `onDidChangeTrackers` is separate from `onDidChange`.
 */
export default function EmulatorLeaderboardTracker(props: {
    achievements: RetroAchievementsService;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorLeaderboardTracker.d.ts.map