import { VueportNotifications } from '../../common/emulator-host';
/** The sentence every patch switch ends with, for any dialog that restarts the game. */
export declare const RESTART_CONFIRM: () => string;
/**
 * Ask before switching a ROM patch on or off.
 *
 * Both ways, and for every kind of patch alike, because both cost the same: a
 * patch is applied by rebuilding the machine from the original ROM, so the
 * game restarts and anything since the last save is gone. `notes` go before
 * the shared sentence — what else the switch does, such as a color patch
 * switching another one off.
 */
export declare function confirmPatchRestart(notifications: VueportNotifications, enable: boolean, notes?: string[]): Promise<boolean>;
//# sourceMappingURL=patch-restart.d.ts.map