import { VueportNotifications } from '../../common/emulator-host';
export declare const RESTART_CONFIRM: () => string;
export declare function confirmPatchRestart(notifications: VueportNotifications, enable: boolean, notes?: string[]): Promise<boolean>;
//# sourceMappingURL=patch-restart.d.ts.map