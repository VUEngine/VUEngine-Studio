import * as React from 'react';
import { VueportInputBindings, VueportSettings } from '../../common/emulator-settings';
import { VueportHover } from '../components/kit/KitContext';
import { EmulatorRewindBrowser } from '../emulator-rewind-browser';
import { EmulatorAction, EmulatorMode, EmulatorRomStatus } from '../emulator-types';
export interface EmulatorToolbarState {
    loaded: boolean;
    paused: boolean;
    muted: boolean;
    lowPower: boolean;
    slowmotion: boolean;
    fastForward: boolean;
    frameAdvance: boolean;
    showControls: boolean;
    showPalettes: boolean;
    showPreferences: boolean;
    showCheats: boolean;
    showMacros: boolean;
    showPatches: boolean;
    showAchievements: boolean;
    showSaveStates?: boolean;
    saveStateExists: boolean;
    mode: EmulatorMode;
}
export interface EmulatorToolbarControl {
    id: string;
    label: string;
    icon: React.ReactNode;
    run(): void;
    disabled?: boolean;
    active?: boolean;
}
export interface EmulatorToolbarHost {
    readonly state: EmulatorToolbarState;
    readonly status: EmulatorRomStatus;
    readonly rewinding: boolean;
    readonly profiling: boolean;
    readonly recordingVideo?: boolean;
    recordedSeconds?(): number;
    linkStatus(): 'idle' | 'relinkable' | 'waiting' | 'linked';
    isLinked(): boolean;
    readonly player: 1 | 2;
    canInspectPeer(): boolean;
    isInspectingPeer(): boolean;
    isRewindEnabled(): boolean;
    isHardcore(): boolean;
    getRenderingMode(): string;
    getPaletteLabel(): string;
    renderPalettePreview(): React.ReactNode;
    runAction(action: EmulatorAction): void;
    setMode(mode: EmulatorMode): void;
    setRenderingMode(mode: string): Promise<void>;
    setScale(scale: string): Promise<void>;
    togglePaletteWindow(): void;
    togglePreferencesWindow(): void;
    toggleSaveStates?(): void;
    toggleCheats(): void;
    toggleMacros(): void;
    togglePatches(): void;
    toggleAchievements(): void;
    onRewindButtonDown(e: React.PointerEvent<HTMLButtonElement>): void;
    onRewindButtonUp(e: React.PointerEvent<HTMLButtonElement>): void;
    stopRewinding(): void;
    promptEnableRewind(): Promise<void>;
    readonly rewindBrowser?: EmulatorRewindBrowser;
    runCommand(id: string): void;
    readonly settings: VueportSettings;
    readonly bindings: VueportInputBindings;
    readonly leadingControls?: EmulatorToolbarControl[];
    readonly trailingControls?: EmulatorToolbarControl[];
    readonly hover?: VueportHover;
}
//# sourceMappingURL=EmulatorToolbar.d.ts.map