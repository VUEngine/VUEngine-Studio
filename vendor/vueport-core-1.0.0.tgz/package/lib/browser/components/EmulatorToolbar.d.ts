import * as React from 'react';
import { VueportInputBindings, VueportSettings } from '../../common/emulator-settings';
import { VueportHover } from '../components/kit/KitContext';
import { EmulatorAction, EmulatorMode, EmulatorRomStatus } from '../emulator-types';
/**
 * The contract between the emulator and the chrome around it.
 *
 * There was a toolbar here once — a permanent row of controls above the panels
 * — and this is what is left of it now that both hosts have stopped drawing
 * one. The controls themselves live in `EmulatorControlStrip`, which the
 * standalone build floats over the picture and the studio puts in its title
 * bar; the badges and the title bar read the same state and call the same
 * actions. The name stayed because every one of them names this interface.
 *
 * An interface rather than the widget itself, because this is vueport's and
 * the widget is not: anything that can answer these questions and perform
 * these actions can wear the chrome. `VesEmulatorWidget` satisfies it
 * structurally, so there is nothing to adapt.
 */
/** The parts of the emulator's state the chrome shows. */
export interface EmulatorToolbarState {
    loaded: boolean;
    paused: boolean;
    muted: boolean;
    lowPower: boolean;
    slowmotion: boolean;
    fastForward: boolean;
    frameAdvance: boolean;
    showControls: boolean;
    showPalettes: boolean;
    showPreferences: boolean;
    /**
     * Whether the cheats are shown beside the screen.
     *
     * These five read the same in both modes: none of them is a docked panel
     * any more — see `EmulatorHost#renderCheats` — and only one is open at once.
     */
    showCheats: boolean;
    /** Whether the macros are shown beside the screen. */
    showMacros: boolean;
    /** Whether the ROM patches are shown beside the screen. */
    showPatches: boolean;
    /** Whether the VB Color editor is shown beside the screen. */
    showColors: boolean;
    /** Whether the achievements are shown beside the screen. */
    showAchievements: boolean;
    /**
     * Whether the save-state browser is shown beside the screen.
     *
     * Optional, unlike its five siblings, because a host that has not adopted
     * the browser — the studio's widget — should go on satisfying this
     * interface; absent reads as "not shown", and the chrome leaves the button
     * out rather than offering one that opens nothing.
     */
    showSaveStates?: boolean;
    /**
     * Whether there is a state to load: the newest one somebody made.
     *
     * Not "slot 3 has something in it" any more — there are no slots. See
     * `SaveStateStore`.
     */
    saveStateExists: boolean;
    mode: EmulatorMode;
}
/**
 * A control a host adds to one end of the strip.
 *
 * Described rather than rendered, so that a host's own buttons get the same
 * markup, styling and hover treatment as the built-in ones without having to
 * reproduce any of it. The web build uses this for the one thing only it can
 * offer — opening a different ROM; the studio has its own menu for that and
 * adds nothing.
 */
export interface EmulatorToolbarControl {
    /** Distinguishes one control from another in a list. */
    id: string;
    /** What the hover says, and the button's accessible name. */
    label: string;
    icon: React.ReactNode;
    run(): void;
    disabled?: boolean;
    /** Drawn as pressed, for a control that opens something that is open. */
    active?: boolean;
}
export interface EmulatorToolbarHost {
    readonly state: EmulatorToolbarState;
    readonly status: EmulatorRomStatus;
    /** True from the moment rewind is pressed until it is released. */
    readonly rewinding: boolean;
    /** True while a profile recording is being taken. */
    readonly profiling: boolean;
    /**
     * True while a video of the session is being recorded.
     *
     * Optional, like the reading below it, because a host that does not offer
     * recording — an older embedder, or one on a platform with no encoder —
     * should go on satisfying this interface without saying anything about it.
     * Absent reads as "not recording", which is what it is.
     */
    readonly recordingVideo?: boolean;
    /**
     * How long that recording has been running, in seconds.
     *
     * A function rather than a number so that the badge showing it can keep its
     * own clock: a value passed in would be as old as the last time the chrome
     * happened to be redrawn, and keeping it fresh would mean redrawing all of
     * the chrome once a second for one number. See `EmulatorVideoBadge`.
     */
    recordedSeconds?(): number;
    /**
     * What the link button is offering, in one word.
     *
     * Four states, because "not linked" was three different situations wearing
     * one label: nobody to link to, somebody to link to *again*, and a session
     * already open that nobody has answered yet. A button that said "Link Second
     * Player" in all three did nothing in two of them.
     *
     *   `idle`       — invite somebody, which opens a window for them
     *   `relinkable` — the other window is still there; pick the pairing back up
     *   `waiting`    — a session with nobody in it; pressing gives up on it
     *   `linked`     — both windows are playing; pressing unlinks
     */
    linkStatus(): 'idle' | 'relinkable' | 'waiting' | 'linked';
    isLinked(): boolean;
    /**
     * Which player this window is, for a linked pair. 1 when playing alone,
     * which is also what it says on the tin: there is one player.
     */
    readonly player: 1 | 2;
    /**
     * True once the other player's machine is there to be inspected.
     *
     * Not the same as being linked: the session says it is connected a moment
     * before the mirror of the other machine has been built, and a switch
     * offered in that moment would have nothing to switch to.
     */
    canInspectPeer(): boolean;
    /**
     * True while the inspectors are pointed at the other player's machine
     * rather than this window's own. Never true outside a session.
     */
    isInspectingPeer(): boolean;
    isRewindEnabled(): boolean;
    /** True while RetroAchievements hardcore mode is on — it disables load-state, rewind and more. */
    isHardcore(): boolean;
    getRenderingMode(): string;
    /** Name of the palette in use, built-in or custom. */
    getPaletteLabel(): string;
    /** The swatch shown on the palette button. */
    renderPalettePreview(): React.ReactNode;
    runAction(action: EmulatorAction): void;
    setMode(mode: EmulatorMode): void;
    setRenderingMode(mode: string): Promise<void>;
    setScale(scale: string): Promise<void>;
    togglePaletteWindow(): void;
    togglePreferencesWindow(): void;
    /**
     * Show or hide the save-state browser beside the screen.
     *
     * Optional, like `EmulatorToolbarState.showSaveStates` and for the same
     * reason: a host without a browser says nothing, and the title bar and the
     * strip leave their buttons out rather than offering one that opens nothing.
     */
    toggleSaveStates?(): void;
    /** Show or hide the cheats beside the screen; see `EmulatorHost#renderCheats`. */
    toggleCheats(): void;
    /** Show or hide the macros beside the screen; see `EmulatorHost#renderMacros`. */
    toggleMacros(): void;
    /** Show or hide ROM patches beside the screen. */
    togglePatches(): void;
    toggleColors(): void;
    /**
     * Show or hide the achievements beside the screen; see
     * `EmulatorHost#renderAchievements`. Opening it closes the other four.
     */
    toggleAchievements(): void;
    onRewindButtonDown(e: React.PointerEvent<HTMLButtonElement>): void;
    onRewindButtonUp(e: React.PointerEvent<HTMLButtonElement>): void;
    stopRewinding(): void;
    promptEnableRewind(): Promise<void>;
    runCommand(id: string): void;
    readonly settings: VueportSettings;
    readonly bindings: VueportInputBindings;
    /** Host controls at the far left of the toolbar, before the transport. */
    readonly leadingControls?: EmulatorToolbarControl[];
    /** Host controls at the far right, after the settings button. */
    readonly trailingControls?: EmulatorToolbarControl[];
    /**
     * Where a button's explanation is shown. Optional so that a host which has
     * not been given one still renders; the studio passes its own hover service
     * here, the same way the settings window takes one.
     */
    readonly hover?: VueportHover;
}
//# sourceMappingURL=EmulatorToolbar.d.ts.map