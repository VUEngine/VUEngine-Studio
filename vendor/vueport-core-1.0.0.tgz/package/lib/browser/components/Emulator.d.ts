import * as React from 'react';
import { MacroActivity } from '../emulator-macro-store';
import { RetroAchievementsService } from '../emulator-retroachievements';
import { VueportDock } from '../panels/emulator-dock';
import { EmulatorToolbarHost } from './EmulatorToolbar';
/**
 * What the emulator's chrome needs from the emulator itself.
 *
 * Everything the toolbar reads, plus the dock to show and the overlays to lay
 * over it.
 */
export interface EmulatorHost extends EmulatorToolbarHost {
    /** The panels: the screen, and whichever inspectors are open. */
    readonly dock: VueportDock;
    /** The controller reference and the palette and settings windows. */
    renderOverlay(): React.ReactNode;
    /**
     * The cheats, shown beside the screen — in Play mode and in Debug mode.
     *
     * Deliberately not a panel. They were one in Debug mode once, which made
     * the same list two things: a strip while playing and a dockable tab while
     * debugging, opened by one button that meant whichever the mode said. The
     * dock is for inspecting the machine; the cheats, the macros, the patches,
     * the colors and the achievements belong to the game, so all five are
     * rendered beside it instead and `state.showCheats` and its four siblings
     * are what say whether.
     */
    renderCheats(): React.ReactNode;
    /**
     * The running ROM's save states, beside the screen on the cheats' terms —
     * see `renderCheats`. `state.showSaveStates` is what says whether.
     *
     * Optional, unlike its siblings: the browser is the standalone build's,
     * and a host that has not adopted it leaves this out rather than having to
     * answer for a panel it does not have. See `EmulatorToolbarState`.
     */
    renderSaveStates?(): React.ReactNode;
    /**
     * The VB Color palette editor beside the screen, on the same terms as the
     * cheats — see `renderCheats`. `state.showColors` is what says whether.
     */
    renderColors(): React.ReactNode;
    /** How many cheats are switched on. */
    readonly activeCheats: number;
    /** Put them on screen beside the picture. */
    showCheats(): void;
    /**
     * The macros, shown beside the screen.
     *
     * The cheats' arrangement exactly, and for the same reasons — see
     * `renderCheats`. `state.showMacros` is what says whether.
     */
    renderMacros(): React.ReactNode;
    /** Whether a macro is being recorded, one is playing, or neither. */
    readonly macroActivity: MacroActivity;
    /** Whether a recorded input movie is driving the controller. */
    readonly moviePlaying: boolean;
    /** How far through it the machine is, and how long it runs, in frames. */
    readonly movieFrame: number;
    readonly movieLength: number;
    /** Stop it and hand the controller back; see `EmulatorMovieBadge`. */
    stopMoviePlayback(): void;
    /** Put them on screen beside the picture. */
    showMacros(): void;
    /**
     * Stop recording and throw away what was recorded.
     *
     * What the REC badge over the picture does. Thrown away rather than kept,
     * because keeping it means naming it and opening the editor on it, and a
     * badge pressed mid-game is somebody saying "stop that", not somebody
     * asking to be taken out of the game and shown a form.
     */
    cancelMacroRecording(): void;
    /** The registered ROM patches, shown beside the screen. */
    renderPatches(): React.ReactNode;
    /** Put the ROM patches on screen beside the picture. */
    showPatches(): void;
    /** Show the color editor beside the picture. */
    showColors(): void;
    /**
     * The RetroAchievements list, shown beside the screen.
     *
     * The cheats' and macros' arrangement exactly, and for the same reasons —
     * see `renderCheats`. `state.showAchievements` is what says whether, and
     * only one of the five strips is ever open at once.
     */
    renderAchievements(): React.ReactNode;
    /** Put it on screen beside the picture. */
    showAchievements(): void;
    /**
     * The account and the running set, for the leaderboard readout over the
     * picture.
     *
     * The service itself rather than the values, unlike the other two badges:
     * a running attempt's value changes many times a second, and only that
     * one small overlay should be redrawing at that rate. It subscribes for
     * itself — see `EmulatorLeaderboardTracker`.
     */
    readonly retroAchievements: RetroAchievementsService;
}
/**
 * Which set of chrome the emulator wears.
 *
 * `immersive` is a strip that floats over the picture and hides itself when
 * the pointer stops. Right for a host where the emulator IS the application:
 * a 384x224 image framed by a permanent toolbar is a picture in an IDE, and
 * what the controls cost in attention they do not earn back while somebody is
 * playing. What is switched on is said by the badges over the picture instead,
 * which do not hide.
 *
 * `hosted` is `immersive` with the strip taken out: the badges still sit over
 * the picture and the overlays still open, but the transport is somewhere the
 * host put it. Right for a host that has a row of its own to put it in — the
 * studio's title bar — where hiding it would be hiding a row that is already
 * there, and showing it over the picture as well would be two of them.
 *
 * `screen` is the picture and nothing else — no toolbar, no strip, no badges,
 * no overlay. For a linked player 2, whose transport, cheats and settings are
 * all player 1's; all it owns is a screen and its own controller.
 */
export type EmulatorChrome = 'immersive' | 'hosted' | 'screen';
export interface EmulatorProps {
    emulator: EmulatorHost;
    /**
     * Whether the emulator's own node is in the document yet.
     *
     * Lumino refuses to attach a widget to a host that is not itself attached,
     * and React effects run as soon as the tree commits — which can be before
     * the surrounding widget has been put anywhere. So the dock waits for this
     * to turn true rather than for the effect to fire.
     */
    attached: boolean;
    /**
     * Shown where the panels would be, and only then.
     *
     * For a host that has no ROM yet and something better to put there than an
     * empty dock — the standalone build's start page.
     */
    placeholder?: React.ReactNode;
    /** Defaults to `immersive`, which is the emulator with all of its own chrome. */
    chrome?: EmulatorChrome;
}
/**
 * The emulator, as one React component.
 *
 * The toolbar and the overlays are React. The dock is not: it is a Lumino
 * `DockPanel`, because panels that can be dragged, split, tabbed and resized
 * are what it is for, and Lumino does that without a framework. It is attached
 * into a container this component owns but never renders into — the same
 * arrangement the screen panel uses one level down for its canvas, and for the
 * same reason: some things have to keep their identity across renders.
 */
export declare function Emulator(props: EmulatorProps): React.JSX.Element;
//# sourceMappingURL=Emulator.d.ts.map