import * as React from 'react';
import { MacroActivity } from '../emulator-macro-store';
import { TouchControlsLayout } from '../../common/emulator-settings';
import { EmulatorQuickMenuHost } from './EmulatorQuickMenu';
import { RetroAchievementsService } from '../emulator-retroachievements';
import { VueportDock } from '../panels/emulator-dock';
import { EmulatorToolbarHost } from './EmulatorToolbar';
export interface EmulatorHost extends EmulatorToolbarHost, EmulatorQuickMenuHost {
    setTouchKeys?(keys: number): void;
    readonly touchLayoutEditing?: boolean;
    finishTouchLayoutEditing?(layout?: TouchControlsLayout): void;
    readonly dock: VueportDock;
    renderOverlay(): React.ReactNode;
    renderCheats(): React.ReactNode;
    renderSaveStates?(): React.ReactNode;
    readonly activeCheats: number;
    showCheats(): void;
    renderMacros(): React.ReactNode;
    readonly macroActivity: MacroActivity;
    readonly moviePlaying: boolean;
    readonly movieFrame: number;
    readonly movieLength: number;
    stopMoviePlayback(): void;
    showMacros(): void;
    cancelMacroRecording(): void;
    renderPatches(): React.ReactNode;
    showPatches(): void;
    readonly activePatches: number;
    renderAchievements(): React.ReactNode;
    showAchievements(): void;
    readonly retroAchievements: RetroAchievementsService;
}
/**
 * `immersive`: a strip floating over the picture that hides itself when the pointer stops, for hosts where the
 * emulator is the application; badges over the picture, which do not hide, say what is switched on.
 * `hosted`: `immersive` without the strip, for a host with a row of its own for the transport (the studio's title bar).
 * `screen`: the picture alone, no toolbar, strip, badges or overlay; for a linked player 2, whose transport, cheats
 * and settings are all player 1's.
 */
export type EmulatorChrome = 'immersive' | 'hosted' | 'screen';
export interface EmulatorProps {
    emulator: EmulatorHost;
    attached: boolean;
    placeholder?: React.ReactNode;
    chrome?: EmulatorChrome;
}
export declare function Emulator(props: EmulatorProps): React.JSX.Element;
//# sourceMappingURL=Emulator.d.ts.map