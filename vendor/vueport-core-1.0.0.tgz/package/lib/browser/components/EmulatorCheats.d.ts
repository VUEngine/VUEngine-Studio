import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { CheatFinder } from '../emulator-cheat-finder';
import { CheatStore } from '../emulator-cheat-store';
/**
 * The cheats kept beside the ROM: named sets of writes the core repeats every frame. Everything here edits the store,
 * which owns the list, writes the file and pushes enabled writes into the core, so a cheat stays on with this closed
 * and nothing is polled. A component rather than a panel, as it is docked in Debug mode but sits beside the screen
 * while playing
 */
export default function EmulatorCheats(props: {
    cheats: CheatStore;
    finder: CheatFinder;
    notifications: VueportNotifications;
    onClose?: () => void;
    inspecting?: 'own' | 'peer';
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheats.d.ts.map