import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { CheatFinder } from '../emulator-cheat-finder';
import { CheatStore } from '../emulator-cheat-store';
/**
 * The cheats kept beside the ROM: named sets of writes the core repeats every
 * frame, which is what holds a value against a game that keeps changing it.
 *
 * The list on top is every cheat in the file, with the selected one's name,
 * switch and codes editable below it. Everything here edits the store, which
 * owns the list, writes the file and pushes the enabled writes into the core —
 * so a cheat stays on with this closed, and this is only a view of it. That is
 * also why nothing is polled: the store says when to redraw.
 *
 * A component rather than a panel, because it is shown in two places and only
 * one of them is a panel. In Debug mode it is docked like every other
 * inspector; while playing it sits beside the screen with no dock involved at
 * all, since somebody reaching for a cheat mid-game should not have to think
 * about panels, tabs or layouts.
 */
export default function EmulatorCheats(props: {
    cheats: CheatStore;
    /** The memory search behind the Find button — see `EmulatorCheatFinder`. */
    finder: CheatFinder;
    notifications: VueportNotifications;
    /**
     * Put these away, when there is somewhere to put them away to.
     *
     * Given for the strip beside the screen, which has no chrome of its own to
     * close it by. The docked panel leaves this out: it has a tab, and a
     * second way to close it sitting inside would be one too many.
     */
    onClose?: () => void;
    /**
     * Whose machine the debugger is currently pointed at, while a link
     * session is running.
     *
     * Only for the note below. The switches here always belong to this
     * window's own player, whichever machine the inspectors are showing — see
     * `peerNote` — and the note is what keeps that from being a surprise.
     */
    inspecting?: 'own' | 'peer';
}): React.JSX.Element;
//# sourceMappingURL=EmulatorCheats.d.ts.map