import React from 'react';
export default function EmulatorRenderingModeField(props: {
    options: {
        value: string;
        label: string;
    }[];
    value: string;
    disabled?: boolean;
    onChange: (value: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorRenderingModeField.d.ts.map