import * as React from 'react';
import { RaLeaderboard } from '../../common/vb-protocol';
import { RetroAchievementsService } from '../emulator-retroachievements';
export declare function EmulatorLeaderboardList(props: {
    achievements: RetroAchievementsService;
    /** The panel's own filter box, shared with the achievements list. */
    filterText: string;
    onSelect: (id: number) => void;
}): React.JSX.Element;
export declare function EmulatorLeaderboardDetail(props: {
    achievements: RetroAchievementsService;
    leaderboard: RaLeaderboard;
    onBack: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorLeaderboards.d.ts.map