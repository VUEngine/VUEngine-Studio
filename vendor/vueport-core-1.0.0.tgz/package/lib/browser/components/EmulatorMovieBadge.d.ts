import * as React from 'react';
export default function EmulatorMovieBadge(props: {
    playing: boolean;
    frame: number;
    length: number;
    onStop: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorMovieBadge.d.ts.map