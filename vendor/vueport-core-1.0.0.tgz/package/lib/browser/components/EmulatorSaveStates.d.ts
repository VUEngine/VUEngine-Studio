import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { SaveStateEntry, SaveStateStore } from '../emulator-save-state-store';
/**
 * The running ROM's save states, beside the screen.
 *
 * The replacement for the numbered slot in the transport: saving always makes
 * a new state, and this is where they are told apart — by the picture of the
 * moment and the time it was taken, which is how a person remembers a moment
 * rather than by a number they had to keep track of.
 *
 * The picture is the button that loads it. That is the one action worth a
 * click of its own here, and a thumbnail somebody is already looking at to
 * decide which moment they want is the obvious thing to press once they have
 * decided.
 */
export default function EmulatorSaveStates(props: {
    states: SaveStateStore;
    notifications: VueportNotifications;
    /** Whether there is a machine running to take a state of, or put one into. */
    canSave: boolean;
    /** Hardcore mode forbids loading; saving and keeping states is still fine. */
    hardcore?: boolean;
    /** The host takes the state: it has the notice to put up and the flags to set. */
    onSave(): void;
    onLoad(entry: SaveStateEntry): void;
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorSaveStates.d.ts.map