import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { SaveStateEntry, SaveStateStore } from '../emulator-save-state-store';
export default function EmulatorSaveStates(props: {
    states: SaveStateStore;
    notifications: VueportNotifications;
    canSave: boolean;
    hardcore?: boolean;
    onSave(): void;
    onLoad(entry: SaveStateEntry): void;
    onClose?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorSaveStates.d.ts.map