/**
 * The VB Color palette editor, beside the running game.
 *
 * Scene filter, object list, four swatches per palette. Changing one writes the
 * color into the running game at once, so the result is on screen without the
 * game restarting; the patch that carries the same colors is rebuilt behind
 * it. Why those are two paths, and why there is nothing here to enter or leave,
 * is in `emulator-vb-color-store.ts`.
 *
 * A component rather than a panel because it is shown in two places and only one
 * of them is a panel — the same arrangement `EmulatorCheats` uses. While playing
 * it is a strip beside the screen; in Debug mode it is docked, where it can sit
 * open alongside the VCU panel's Color RAM grid.
 *
 * The game *is* the preview, which is the whole reason this is not in the
 * settings dialog: colors are chosen by looking at them. It is also why the
 * whole feature is governed from here — the switch that applies the
 * colorization is at the bottom of this panel rather than in a list of games
 * under the settings, where it would have been a switch for something you
 * could not see. Making one for a game that has none starts here too, and for
 * the same reason: see `emulator-vb-color-create.ts` for what that makes and
 * what it warns about first.
 */
import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { ColorStore } from '../emulator-vb-color-store';
export interface EmulatorColorsProps {
    colors: ColorStore;
    /** For the switch at the foot of the panel, which warns before it restarts. */
    notifications: VueportNotifications;
    /** Present only for the strip beside the screen, which has no chrome. */
    onClose?: () => void;
}
export default function EmulatorColors(props: EmulatorColorsProps): React.JSX.Element;
//# sourceMappingURL=EmulatorColors.d.ts.map