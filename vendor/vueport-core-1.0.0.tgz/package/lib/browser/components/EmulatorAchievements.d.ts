import * as React from 'react';
import { RetroAchievementsService } from '../emulator-retroachievements';
/**
 * The achievement set for the running ROM, and the player's progress through
 * it — the third panel in the pattern Cheats and Macros share, but read-only:
 * nothing here is edited, only shown.
 *
 * Entirely push-driven. `RetroAchievementsService` fires `onDidChange`
 * whenever the account, the loaded set or an unlock changes, so this only ever
 * re-renders in answer to that — there is nothing here worth polling for.
 */
export default function EmulatorAchievements(props: {
    achievements: RetroAchievementsService;
    /**
     * Put the panel away, when there is somewhere to put it away to.
     *
     * Given for the strip beside the screen, which has no chrome of its own to
     * close it by — the same as `EmulatorCheats` and `EmulatorMacros`. The
     * docked panel leaves this out: it has a tab.
     */
    onClose?: () => void;
    /**
     * Take the player to where they can actually sign in.
     *
     * This panel only ever reads the account (see the class doc on
     * `RetroAchievementsService`), so signing in itself happens on the
     * settings page, not here — this is the way there, shown as a button on
     * the "not signed in" empty state. Left out entirely on a host that has
     * nowhere to send it to; the button simply does not appear then.
     */
    onOpenSettings?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorAchievements.d.ts.map