import * as React from 'react';
import { RetroAchievementsService } from '../emulator-retroachievements';
export default function EmulatorAchievements(props: {
    achievements: RetroAchievementsService;
    onClose?: () => void;
    onOpenSettings?: () => void;
    onEnable?: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorAchievements.d.ts.map