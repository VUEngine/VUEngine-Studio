import React, { FocusEventHandler, MouseEventHandler, RefObject } from 'react';
interface InputProps {
    value: string | number;
    setValue?: (data: string | number) => void;
    type?: 'string' | 'number';
    label?: string;
    tooltip?: string;
    size?: 'small' | 'large';
    title?: string;
    placeholder?: string;
    min?: number;
    max?: number;
    defaultValue?: string | number;
    step?: number;
    disabled?: boolean;
    readOnly?: boolean;
    clearable?: boolean;
    style?: object;
    tabIndex?: number;
    autoFocus?: boolean;
    width?: number;
    grow?: number;
    id?: string;
    className?: string;
    onClick?: MouseEventHandler<HTMLInputElement>;
    onBlur?: FocusEventHandler<HTMLInputElement>;
    inputRef?: RefObject<HTMLInputElement>;
}
export default function Input(props: InputProps): React.JSX.Element;
export {};
//# sourceMappingURL=Input.d.ts.map