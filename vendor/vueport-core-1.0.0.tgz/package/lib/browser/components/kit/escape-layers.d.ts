/**
 * Which layer Escape belongs to. Both a key capture and the input window under it listen on `window` in the
 * capture phase (so the emulator's own key handler never sees the key), and stopPropagation does not reach a
 * listener on the same target, so without this one Escape would close both. A stack, as nesting is open-ended
 * and the most recently opened layer is on top.
 */
export interface EscapeLayer {
    isTop(): boolean;
    dispose(): void;
}
export declare function pushEscapeLayer(): EscapeLayer;
//# sourceMappingURL=escape-layers.d.ts.map