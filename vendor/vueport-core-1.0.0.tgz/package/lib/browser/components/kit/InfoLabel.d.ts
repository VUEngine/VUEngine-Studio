import React, { PropsWithChildren, ReactElement } from 'react';
import { VueportHover } from './KitContext';
interface InfoLabelProps {
    label: string;
    subLabel?: string;
    count?: number;
    tooltip?: string | ReactElement;
    hover?: VueportHover;
    style?: object;
}
export default function InfoLabel(props: PropsWithChildren<InfoLabelProps>): React.JSX.Element;
export {};
//# sourceMappingURL=InfoLabel.d.ts.map