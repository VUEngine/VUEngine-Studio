import { ReactElement, ReactNode } from 'react';
/**
 * A JSX tooltip for a hover service that takes a string or an element (VueportHover.show, like the studio's).
 * A portal into a detached div renders it as part of the ordinary tree, instead of pulling React's server
 * renderer into the bundle. Containers are kept per index, so each option of a list gets a stable node and a
 * re-render does not hand the hover a container it no longer fills.
 */
export interface TooltipContents {
    resolve(index: number): string | HTMLElement | undefined;
    portals: ReactNode;
}
export type Tooltip = string | ReactElement | undefined;
export declare function useTooltipContents(tooltips: Tooltip[]): TooltipContents;
//# sourceMappingURL=tooltip-content.d.ts.map