import { ReactElement, ReactNode } from 'react';
/**
 * A tooltip written as JSX, handed to a hover service that speaks DOM.
 *
 * `VueportHover.show` takes a string or an element, because the studio's own
 * hover service does and a bare page has nothing richer. Turning JSX into one
 * used to mean `renderToStaticMarkup` and an `innerHTML` assignment — which
 * pulled the whole of React's server renderer into a browser bundle for the
 * sake of two tooltips, and threw away the component's identity on the way.
 *
 * A portal into a detached `div` does the same job with what the page already
 * has: React renders the tooltip as part of the ordinary tree, into a node the
 * hover service can place, and keeps it up to date afterwards.
 *
 * The containers are kept per index rather than per element so that a list of
 * options — each with its own explanation — gets a stable node each, and a
 * re-render does not hand the hover a container it no longer fills.
 */
export interface TooltipContents {
    /** What to give `show` for the tooltip at `index`, if it has one. */
    resolve(index: number): string | HTMLElement | undefined;
    /** Render this somewhere in the component's own output. */
    portals: ReactNode;
}
export type Tooltip = string | ReactElement | undefined;
export declare function useTooltipContents(tooltips: Tooltip[]): TooltipContents;
//# sourceMappingURL=tooltip-content.d.ts.map