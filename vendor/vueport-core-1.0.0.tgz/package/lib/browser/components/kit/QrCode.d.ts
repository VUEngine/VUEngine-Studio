import * as React from 'react';
/**
 * A QR code of `value`, drawn as one SVG path of its dark modules, so it stays sharp at any size and needs no canvas.
 * Dark on white whatever the theme, as a camera reads light-on-dark codes badly. Medium error correction: enough for
 * a slightly glary screen, and an address fits a small, coarse code that a phone reads from across a desk.
 */
export declare function QrCode(props: {
    value: string;
    size?: number;
    label: string;
}): React.JSX.Element;
//# sourceMappingURL=QrCode.d.ts.map