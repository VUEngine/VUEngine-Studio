import React from 'react';
interface ColorFieldProps {
    value: string;
    onChange: (hex: string) => void;
    onPreview?: (hex: string) => void;
    disabled?: boolean;
    large?: boolean;
    title?: string;
}
export default function ColorField(props: ColorFieldProps): React.JSX.Element;
export {};
//# sourceMappingURL=ColorField.d.ts.map