import React from 'react';
interface ColorFieldProps {
    /** The current color as `#rrggbb`. */
    value: string;
    /**
     * The settled color: once the picker has come to rest, or at once when it
     * closes. Not one per pointer move — see `COMMIT_MS`.
     */
    onChange: (hex: string) => void;
    /**
     * The color while the picker is dragged. Optional — for a live preview.
     * Several a second rather than every move (see `PREVIEW_MS`), but still
     * not a place to persist.
     */
    onPreview?: (hex: string) => void;
    disabled?: boolean;
    large?: boolean;
    /** Names the well for a screen reader, and titles it on hover. */
    title?: string;
}
export default function ColorField(props: ColorFieldProps): React.JSX.Element;
export {};
//# sourceMappingURL=ColorField.d.ts.map