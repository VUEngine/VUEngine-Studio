import React from 'react';
interface PanelFilterProps {
    value: string;
    onChange(value: string): void;
    placeholder?: string;
    status?: React.ReactNode;
    missed?: boolean;
}
export default function PanelFilter({ value, onChange, placeholder, status, missed, }: PanelFilterProps): React.JSX.Element;
export {};
//# sourceMappingURL=PanelFilter.d.ts.map