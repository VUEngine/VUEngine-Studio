import React from 'react';
interface PanelFilterProps {
    value: string;
    onChange(value: string): void;
    /**
     * Overrides the plain "Filter" in the box and on the label, for a list
     * whose rows want naming — "Filter classes".
     */
    placeholder?: string;
    /**
     * A readout inside the box, between the text and the clear button — how
     * much of the list is left, for one long enough that counting it by eye
     * is not an option.
     */
    status?: React.ReactNode;
    /** Marks the box when what was typed matches nothing. */
    missed?: boolean;
}
/**
 * The box that narrows a list by name, between a panel's heading and its rows.
 *
 * The markup rather than the styling is what is shared here: `.vp-panel-filter`
 * has always been common to the cheats, the macros, the patches and the rest,
 * but each of them wrote out the same glass-input-cross by hand. A list that
 * gained one and got a detail wrong — the clear button that only appears with
 * text in the field, the label a screen reader reads — would say only that
 * nobody was paying attention.
 */
export default function PanelFilter({ value, onChange, placeholder, status, missed, }: PanelFilterProps): React.JSX.Element;
export {};
//# sourceMappingURL=PanelFilter.d.ts.map