import * as React from 'react';
export default function Switch(props: {
    label: string;
    value: boolean;
    disabled?: boolean;
    onChange: (value: boolean) => void;
}): React.JSX.Element;
//# sourceMappingURL=Switch.d.ts.map