import * as React from 'react';
/**
 * A setting that is on or off.
 *
 * A switch rather than a checkbox: these take effect the moment they are
 * thrown — nothing here is a form with an OK button — and a switch is what
 * says so. Shared so that the settings panes, the input pages and the
 * hand-written panes all show the same thing.
 *
 * The label names it for a screen reader rather than being drawn: what the
 * switch is for is already written beside or above it, and repeating it inside
 * would be the same words twice.
 */
export default function Switch(props: {
    label: string;
    value: boolean;
    disabled?: boolean;
    onChange: (value: boolean) => void;
}): React.JSX.Element;
//# sourceMappingURL=Switch.d.ts.map