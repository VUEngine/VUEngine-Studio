export declare const isNumber: (value: unknown) => value is number;
export declare const clamp: (value: number, min: number, max: number, deflt?: number) => number;
export interface Debounced<A extends unknown[]> {
    (...args: A): void;
    cancel(): void;
}
export declare function debounce<A extends unknown[]>(fn: (...args: A) => void, wait: number): Debounced<A>;
//# sourceMappingURL=Utils.d.ts.map