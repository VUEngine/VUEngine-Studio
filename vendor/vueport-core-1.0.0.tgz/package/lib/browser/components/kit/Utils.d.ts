/**
 * The handful of helpers the copied controls need.
 *
 * Copied from VES's `editors/.../Common/Utils` for the same reason the
 * controls themselves are: so that nothing here reaches into the editors.
 *
 * `isNumber` and `debounce` were lodash's. They are three lines each, and the
 * import cost a hundred kilobytes: `lodash`'s entry point is a CommonJS
 * barrel, which a bundler cannot tree-shake — asking it for one function gets
 * the whole library. So they live here now.
 */
/** lodash's `isNumber`: number primitives and boxed numbers, `NaN` included. */
export declare const isNumber: (value: unknown) => value is number;
export declare const clamp: (value: number, min: number, max: number, deflt?: number) => number;
/**
 * lodash's `debounce`, trailing edge only — which is all the controls ask for.
 *
 * The returned function keeps the last call's arguments and `this`, and
 * `cancel` drops a pending call, so a component unmounting can stop one from
 * landing on a dead state.
 */
export interface Debounced<A extends unknown[]> {
    (...args: A): void;
    cancel(): void;
}
export declare function debounce<A extends unknown[]>(fn: (...args: A) => void, wait: number): Debounced<A>;
//# sourceMappingURL=Utils.d.ts.map