import React, { PropsWithChildren } from 'react';
interface PopUpDialogProps {
    open: boolean;
    onClose: () => void;
    onOk: () => void;
    okLabel?: string;
    title: string;
    error?: string;
    height?: string;
    width?: string;
    maxWidth?: string;
    okButton?: boolean;
    disableOkButton?: boolean;
    cancelButton?: boolean;
    overflow?: string;
}
export default function PopUpDialog(props: PropsWithChildren<PopUpDialogProps>): React.JSX.Element;
export {};
//# sourceMappingURL=PopUpDialog.d.ts.map