import React, { ReactElement, ReactNode } from 'react';
/**
 * A dropdown, in the shape the rest of these controls are in.
 *
 * The native `<select>` it replaces was the one control the browser drew
 * itself: its own font, its own arrow, its own list, and on every platform a
 * different one. Everything around it — the fields, the buttons, the segmented
 * switches — is the application's, so the odd one out read as a seam. This
 * wraps `react-dropdown`, which brings the behaviour (a real listbox, the
 * arrow keys, Home/End, Escape, type-ahead-free but focus-correct) and leaves
 * the drawing to `.vp-dropdown-*` in the stylesheet.
 *
 * Two ways to carry an icon:
 *
 *   - {@link SelectProps.icon} sits in the control and never moves — what the
 *     dropdown is FOR rather than what is chosen in it. Worth having only
 *     while the icon says nothing the control's own choice says: the library's
 *     sort dropdown gave its sort icon up to a button beside it the moment the
 *     direction became something to click.
 *   - {@link SelectOption.icon} belongs to one choice, and so appears both in
 *     the menu row and in the control once that row is the chosen one.
 */
export interface SelectOption {
    value: string;
    label: ReactNode;
    /** Shown before the label, in the menu and in the control alike. */
    icon?: ReactElement;
    disabled?: boolean;
}
/** Choices under a heading — what `<optgroup>` was. */
export interface SelectGroup {
    group: ReactNode;
    options: SelectOption[];
}
export type SelectEntry = SelectOption | SelectGroup;
export interface SelectProps {
    options: SelectEntry[];
    value: string;
    onChange: (value: string) => void;
    /** The control's own icon, before whatever is chosen. */
    icon?: ReactElement;
    /** Said while nothing is chosen. */
    placeholder?: ReactNode;
    disabled?: boolean;
    /** What the choice is about, for a screen reader. */
    label?: string;
    /** The hover title, for a control whose name is not beside it. */
    title?: string;
    size?: 'small' | 'large';
    /**
     * How wide the menu is drawn.
     *
     * `control` — the default — makes it exactly as wide as the control, which
     * is what a dropdown that fills its row wants: the menu is the field, open.
     * `content` sizes it to the longest row instead, for a control narrower
     * than what is in it — a pill sized to the word `Type` has a menu saying
     * `Technical demos`, and a menu clipped to the pill would be four
     * ellipses.
     */
    menuWidth?: 'control' | 'content';
    className?: string;
    style?: React.CSSProperties;
}
export default function Select(props: SelectProps): React.JSX.Element;
//# sourceMappingURL=Select.d.ts.map