import React, { ReactElement, ReactNode } from 'react';
export interface SelectOption {
    value: string;
    label: ReactNode;
    icon?: ReactElement;
    disabled?: boolean;
}
export interface SelectGroup {
    group: ReactNode;
    options: SelectOption[];
}
export type SelectEntry = SelectOption | SelectGroup;
export interface SelectProps {
    options: SelectEntry[];
    value: string;
    onChange: (value: string) => void;
    icon?: ReactElement;
    placeholder?: ReactNode;
    disabled?: boolean;
    label?: string;
    title?: string;
    size?: 'small' | 'large';
    menuWidth?: 'control' | 'content';
    className?: string;
    style?: React.CSSProperties;
}
export default function Select(props: SelectProps): React.JSX.Element;
//# sourceMappingURL=Select.d.ts.map