import React, { PropsWithChildren, ReactElement } from 'react';
import { VueportHover } from './KitContext';
interface HoverInfoProps {
    tooltip: string | ReactElement;
    hover?: VueportHover;
}
export default function HoverInfo(props: PropsWithChildren<HoverInfoProps>): React.JSX.Element;
export {};
//# sourceMappingURL=HoverInfo.d.ts.map