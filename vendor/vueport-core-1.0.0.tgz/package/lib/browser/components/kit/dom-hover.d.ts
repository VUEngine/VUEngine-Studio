import type { VueportHover } from './KitContext';
export declare const DOM_HOVER: VueportHover;
//# sourceMappingURL=dom-hover.d.ts.map