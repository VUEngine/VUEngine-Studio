import * as React from 'react';
export interface VueportHover {
    show(target: HTMLElement, content: string | HTMLElement): void;
    hide(): void;
}
export interface VueportKitServices {
    hover: VueportHover;
    setCommandsEnabled(enabled: boolean): void;
}
export declare const DEFAULT_KIT_SERVICES: VueportKitServices;
export declare const KitContext: React.Context<VueportKitServices>;
export declare function useKit(): VueportKitServices;
//# sourceMappingURL=KitContext.d.ts.map