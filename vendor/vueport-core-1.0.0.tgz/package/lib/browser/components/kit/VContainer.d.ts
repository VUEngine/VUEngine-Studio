import React, { MouseEventHandler, PropsWithChildren } from 'react';
interface VContainerProps {
    alignItems?: string;
    className?: string;
    gap?: number | string;
    grow?: number;
    justifyContent?: string;
    onClick?: MouseEventHandler;
    overflow?: string;
    style?: object;
}
export default function VContainer(props: PropsWithChildren<VContainerProps>): React.JSX.Element;
export {};
//# sourceMappingURL=VContainer.d.ts.map