import React, { ReactElement } from 'react';
import { VueportHover } from './KitContext';
export interface RadioSelectOption {
    value: string | number | boolean;
    label?: string | ReactElement;
    tooltip?: string | ReactElement;
    /** Where the explanation should appear, when the host can place it. */
    tooltipPosition?: string;
    /** This one choice cannot be taken, though the rest of the control works. */
    disabled?: boolean;
}
interface RadioSelectProps {
    options: RadioSelectOption[];
    canSelectMany?: boolean;
    allowBlank?: boolean;
    defaultValue: string | number | boolean | (string | number | boolean)[];
    onChange: (options: RadioSelectOption[]) => void;
    fitSpace?: boolean;
    disabled?: boolean;
    hover?: VueportHover;
}
export default function RadioSelect(props: RadioSelectProps): React.JSX.Element;
export {};
//# sourceMappingURL=RadioSelect.d.ts.map