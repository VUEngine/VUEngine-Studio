import React, { ReactElement } from 'react';
/** One of the buttons at the foot of an empty state. */
export interface EmptyContainerAction {
    label: string;
    /** The button's own icon; a plus when nothing is given. */
    icon?: ReactElement;
    /** A font glyph instead, for a host that ships an icon font. */
    iconCls?: string;
    /** Draw it as the one being asked for rather than as an alternative. */
    primary?: boolean;
    /** Offered but not available — a folder picker this browser has not got. */
    disabled?: boolean;
    onClick: () => void;
}
interface EmptyContainerProps {
    title: string;
    description?: string;
    icon?: ReactElement;
    buttonIconCls?: string;
    /**
     * The button's own icon, for a container whose call to action is not
     * "add" — recording a macro, say.
     *
     * Takes precedence over `buttonIconCls`, which names a font glyph: an
     * element works in a host that ships no icon font, which the standalone
     * build does not.
     */
    buttonIcon?: ReactElement;
    buttonLabel?: string;
    onClick?: () => void;
    /**
     * Several calls to action rather than one.
     *
     * Takes precedence over `buttonLabel` and friends, which stay for the many
     * screens that offer exactly one thing.
     */
    actions?: EmptyContainerAction[];
}
export default function EmptyContainer(props: EmptyContainerProps): React.JSX.Element;
export {};
//# sourceMappingURL=EmptyContainer.d.ts.map