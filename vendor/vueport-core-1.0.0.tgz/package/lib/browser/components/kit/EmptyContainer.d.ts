import React, { ReactElement } from 'react';
export interface EmptyContainerAction {
    label: string;
    icon?: ReactElement;
    iconCls?: string;
    primary?: boolean;
    disabled?: boolean;
    onClick: () => void;
}
interface EmptyContainerProps {
    title: string;
    description?: string;
    icon?: ReactElement;
    buttonIconCls?: string;
    buttonIcon?: ReactElement;
    buttonLabel?: string;
    onClick?: () => void;
    actions?: EmptyContainerAction[];
}
export default function EmptyContainer(props: EmptyContainerProps): React.JSX.Element;
export {};
//# sourceMappingURL=EmptyContainer.d.ts.map