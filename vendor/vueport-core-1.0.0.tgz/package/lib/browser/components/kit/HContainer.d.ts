import React, { KeyboardEventHandler, MouseEventHandler, PropsWithChildren } from 'react';
interface HContainerProps {
    alignItems?: string;
    className?: string;
    gap?: number | string;
    grow?: number;
    justifyContent?: string;
    onClick?: MouseEventHandler;
    onKeyDown?: KeyboardEventHandler;
    onMouseOver?: MouseEventHandler;
    onMouseOut?: MouseEventHandler;
    overflow?: string;
    style?: object;
    tabIndex?: number;
    wrap?: 'nowrap' | 'wrap' | 'wrap-reverse';
}
export default function HContainer(props: PropsWithChildren<HContainerProps>): React.JSX.Element;
export {};
//# sourceMappingURL=HContainer.d.ts.map