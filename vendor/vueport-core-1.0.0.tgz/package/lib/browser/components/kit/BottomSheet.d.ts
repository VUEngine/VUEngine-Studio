import * as React from 'react';
/**
 * A sheet coming up from the bottom edge over a dimmed page, for a phone: the menu and the panels that sit beside
 * the screen on a larger one. Closed by the backdrop, by Escape, by the device's Back, by pulling its handle down, or
 * by a swipe down across it. `tall` sheets keep
 * the picture's top part in view rather than reaching the top of the screen, so a game paused under it stays seen.
 */
export declare function BottomSheet(props: {
    label: string;
    onClose: () => void;
    children: React.ReactNode;
    tall?: boolean;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=BottomSheet.d.ts.map