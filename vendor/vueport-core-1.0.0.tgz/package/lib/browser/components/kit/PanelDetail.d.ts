import React from 'react';
/**
 * Back to the list, and on to the entry before or after this one.
 *
 * The back button carries the list's name rather than "Back To List": it is
 * the only thing that says which panel this is in the strip beside the screen,
 * where there is no tab to say it. Stepping along is for going through a list
 * of shipped cheats or patches one after another without the round trip.
 */
export declare function PanelDetailToolbar(props: {
    /** What the list is called — "Cheats". */
    list: string;
    index: number;
    count: number;
    onBack: () => void;
    onStep: (index: number) => void;
}): React.JSX.Element;
/**
 * The entry as a heading: what kind of thing it is, its name, a line of what
 * is known about it, and the one control that is its reason to exist — the
 * switch of a cheat or a patch, the play button of a macro.
 *
 * The name is typed into where it is read, rather than into a "Name" field
 * further down: renaming is the commonest edit, and a heading that is also the
 * field is one place to look rather than two. A name that is not the player's
 * to change is plain text.
 */
export declare function PanelDetailHero(props: {
    icon: React.ReactNode;
    name: string;
    /** How a name that cannot be renamed is shown, where that is more than its text. */
    title?: React.ReactNode;
    onRename?: (name: string) => void;
    meta?: React.ReactNode;
    badges?: React.ReactNode;
    control?: React.ReactNode;
}): React.JSX.Element;
/** One pill under the heading. */
export declare function PanelDetailBadge(props: {
    icon?: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
/**
 * One part of the entry, under a small title.
 *
 * The title is the label of the field below when the section is just one
 * field — `htmlFor` — so the field is named without a second label beside it.
 */
export declare function PanelDetailSection(props: {
    title: string;
    htmlFor?: string;
    /** At the far end of the title row — a count, or a unit. */
    aside?: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
/**
 * Facts about the entry that are read rather than edited — its file, its
 * format, its version — as a two-column sheet. Rows without a value are left
 * out, so a caller can list everything it might know.
 */
export declare function PanelDetailFacts(props: {
    rows: Array<[label: string, value: React.ReactNode | undefined, code?: boolean]>;
}): React.JSX.Element;
/**
 * The foot of the view: a line about the entry as a whole, and what can be
 * done to it — taking it away, mostly. Pushed to the bottom of the panel, away
 * from the switch at the top, so that the one thing here that cannot be undone
 * is never next to the one that is pressed all the time.
 */
export declare function PanelDetailFooter(props: {
    hint?: React.ReactNode;
    children?: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=PanelDetail.d.ts.map