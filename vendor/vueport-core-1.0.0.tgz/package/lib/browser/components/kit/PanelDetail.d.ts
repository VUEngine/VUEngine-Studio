import React from 'react';
export declare function PanelDetailToolbar(props: {
    list: string;
    index: number;
    count: number;
    onBack: () => void;
    onStep: (index: number) => void;
}): React.JSX.Element;
export declare function PanelDetailHero(props: {
    icon: React.ReactNode;
    name: string;
    title?: React.ReactNode;
    onRename?: (name: string) => void;
    meta?: React.ReactNode;
    badges?: React.ReactNode;
    control?: React.ReactNode;
}): React.JSX.Element;
export declare function PanelDetailBadge(props: {
    icon?: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function PanelDetailSection(props: {
    title: string;
    htmlFor?: string;
    aside?: React.ReactNode;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function PanelDetailFacts(props: {
    rows: Array<[label: string, value: React.ReactNode | undefined, code?: boolean]>;
}): React.JSX.Element;
export declare function PanelDetailFooter(props: {
    hint?: React.ReactNode;
    children?: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=PanelDetail.d.ts.map