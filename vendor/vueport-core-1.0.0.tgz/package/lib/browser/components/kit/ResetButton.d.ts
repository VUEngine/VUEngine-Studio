import React from 'react';
export default function ResetButton(props: {
    onReset: () => void;
    disabled?: boolean;
    size?: number;
}): React.JSX.Element;
//# sourceMappingURL=ResetButton.d.ts.map