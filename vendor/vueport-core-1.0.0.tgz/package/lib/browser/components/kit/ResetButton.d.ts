import React from 'react';
export default function ResetButton(props: {
    onReset: () => void;
    /** Nothing to undo — the setting already holds its default. */
    disabled?: boolean;
    size?: number;
}): React.JSX.Element;
//# sourceMappingURL=ResetButton.d.ts.map