import * as React from 'react';
export declare function Window(props: {
    title: string;
    icon: React.ReactNode;
    onClose: () => void;
    children: React.ReactNode;
    large?: boolean;
    compact?: boolean;
    sidebar?: React.ReactNode;
    headerActions?: React.ReactNode;
    closable?: boolean;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=Window.d.ts.map