import * as React from 'react';
/**
 * A window over the emulator: the settings, colors and input windows.
 *
 * Both hosts' now. It began as the standalone build's, because a browser has
 * no dialog system to borrow and pulling one in for three windows would have
 * been a poor trade. The studio has `PopUpDialog` and used it, which is how
 * the two ended up with the same windows wearing different clothes — so the
 * studio uses this one too, and they are one window again.
 *
 * The whole of what those windows need: a titled panel that closes.
 */
export declare function Window(props: {
    title: string;
    /** Shown beside the title — a caller's own icon, matching what the window is for. */
    icon: React.ReactNode;
    onClose: () => void;
    children: React.ReactNode;
    /**
     * Take the whole 90% the backdrop allows, rather than stopping at the
     * width and height that suit a form. For the controller window, which
     * draws a game pad with its assignments laid out around it.
     */
    large?: boolean;
    /**
     * Size to the content rather than taking the standard window's fixed
     * 60×45rem. For a window with a set amount to say — the game-info window,
     * not a settings screen someone browses.
     */
    compact?: boolean;
    /**
     * A column down the left of the body, outside the scroll region. For a
     * window whose body is one of several panes — the settings dialog puts its
     * tab rail here so it stays put while a pane scrolls.
     */
    sidebar?: React.ReactNode;
    /**
     * Controls in the header, between the title and the close button — the
     * settings dialog's search field sits here.
     */
    headerActions?: React.ReactNode;
}): React.JSX.Element;
//# sourceMappingURL=Window.d.ts.map