import * as React from 'react';
export declare function VbColorIcon(props: {
    size?: number;
    box?: number;
}): React.JSX.Element;
//# sourceMappingURL=VbColorIcon.d.ts.map