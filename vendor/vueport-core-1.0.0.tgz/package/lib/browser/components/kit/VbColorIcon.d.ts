/**
 * The VB Color mark: the console's stylized "C", used wherever the interface
 * stands for VB Color itself — the settings dialog's tab and the title bar's
 * hardware badge.
 *
 * Traced art rather than a Phosphor glyph, so it keeps the original's own
 * transform (the tracer emitted a flipped, tenth-scale path) and is padded to
 * a square box, letting it size and align like the icons around it.
 *
 * In core because the title bar is: both hosts draw the same badge.
 */
import * as React from 'react';
export declare function VbColorIcon(props: {
    size?: number;
}): React.JSX.Element;
//# sourceMappingURL=VbColorIcon.d.ts.map