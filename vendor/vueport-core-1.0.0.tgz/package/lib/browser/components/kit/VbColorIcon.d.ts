/**
 * The VB Color mark: the console's stylized "C", used wherever the interface
 * stands for VB Color itself — the settings dialog's tab and the title bar's
 * hardware badge.
 *
 * Traced art rather than a Phosphor glyph, so it keeps the original's own
 * transform (the tracer emitted a flipped, tenth-scale path) and is padded to
 * a square box, letting it size and align like the icons around it.
 *
 * In core because the title bar is: both hosts draw the same badge.
 */
import * as React from 'react';
export declare function VbColorIcon(props: {
    size?: number;
    /**
     * The square the icon takes up, when that is larger than the glyph: the
     * glyph stays `size` and is centered in it. For a column of icons drawn
     * a size larger — the settings rail's — that this mark would look heavy
     * at, so its label still lines up with theirs.
     */
    box?: number;
}): React.JSX.Element;
//# sourceMappingURL=VbColorIcon.d.ts.map