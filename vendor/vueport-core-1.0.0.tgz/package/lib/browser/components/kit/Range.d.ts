import React, { PropsWithChildren } from 'react';
import { SelectOption } from './Select';
interface RangeProps {
    min: number;
    max: number;
    step?: number;
    value: number;
    clearable?: boolean;
    disabled?: boolean;
    options?: SelectOption[];
    setValue: (value: number) => void;
    width?: string | number;
    selectWidth?: number;
    containerStyle?: object;
}
export default function Range(props: PropsWithChildren<RangeProps>): React.JSX.Element;
export {};
//# sourceMappingURL=Range.d.ts.map