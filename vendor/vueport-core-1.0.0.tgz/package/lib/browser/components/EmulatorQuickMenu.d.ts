import * as React from 'react';
import { EmulatorToolbarHost } from './EmulatorToolbar';
import type { XrAvailability } from '../emulator-xr';
export interface EmulatorQuickMenuHost extends EmulatorToolbarHost {
    readonly gameTitle?: string;
    readonly vbcHeaderPillLabel?: string;
    toggleRomInfo?(): void;
    toggleXr?(): Promise<void>;
    readonly xrAvailability?: XrAvailability;
    readonly xrActive?: boolean;
    openNetworkShares?(): void;
    readonly lanShareActive?: boolean;
}
/**
 * The phone's menu, behind the ⋯ in the short strip under the picture: the whole strip a larger screen floats over the
 * picture, and the title bar's panel, VR and fullscreen buttons, as a sheet of large tiles. Settings and the host's
 * own controls (Open and Close ROM in the standalone build) at the foot. Most tiles close the sheet once pressed, as
 * what they do is seen on the picture; the toggles that only change a state (mute, low battery) leave it up.
 */
export declare function EmulatorQuickMenu(props: {
    host: EmulatorQuickMenuHost;
    onClose: () => void;
}): React.JSX.Element;
//# sourceMappingURL=EmulatorQuickMenu.d.ts.map