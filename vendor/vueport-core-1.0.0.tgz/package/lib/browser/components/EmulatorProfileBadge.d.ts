import * as React from 'react';
export default function EmulatorProfileBadge(props: {
    profiling: boolean;
    onStop: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorProfileBadge.d.ts.map