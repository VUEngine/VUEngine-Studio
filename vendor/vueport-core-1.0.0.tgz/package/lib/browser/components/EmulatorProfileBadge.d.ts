import * as React from 'react';
/**
 * That a profile recording is running, over the corner of the picture.
 *
 * The macro badge's sibling, and there for the same reason: profiling costs
 * performance and memory for as long as it runs, and the only thing that
 * currently says it is running is one button in a toolbar that may be in
 * another mode, behind a window, or off screen. A recording nobody remembers
 * starting is a slow emulator with no visible cause.
 *
 * Shown whatever mode the emulator is in, unlike that button. Profiling is
 * started from Debug mode, but nothing stops somebody switching to Play with
 * it still going — and that is exactly the case where the toolbar has stopped
 * saying so and this has to.
 *
 * A button, because the obvious thing to want after noticing it is to stop it
 * — which is also what writes the profile out, so nothing is lost by pressing
 * it.
 */
export default function EmulatorProfileBadge(props: {
    profiling: boolean;
    onStop: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=EmulatorProfileBadge.d.ts.map