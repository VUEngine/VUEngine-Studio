export interface Disposable {
    dispose(): void;
}
export declare namespace Disposable {
    function create(fn: () => void): Disposable;
    const NULL: Disposable;
}
export interface DisposableGroup {
    push(disposable: Disposable): unknown;
}
export interface Event<T> {
    (listener: (e: T) => unknown, thisArgs?: unknown, disposables?: DisposableGroup): Disposable;
}
export declare namespace Event {
    const None: Event<never>;
}
export declare class DisposableCollection implements Disposable {
    protected disposables: Disposable[];
    protected disposed: boolean;
    constructor(...disposables: Disposable[]);
    get isDisposed(): boolean;
    push(disposable: Disposable): Disposable;
    pushAll(disposables: Disposable[]): Disposable[];
    dispose(): void;
}
interface Registration<T> {
    listener: (e: T) => unknown;
    thisArgs?: unknown;
}
export declare class Emitter<T = void> implements Disposable {
    protected registrations: Registration<T>[];
    protected _event?: Event<T>;
    get event(): Event<T>;
    fire(value: T): void;
    get hasListeners(): boolean;
    dispose(): void;
}
export {};
//# sourceMappingURL=emulator-events.d.ts.map