export type HexColor = `#${string}`;
export interface VbcPalette {
    id: number;
    name: string;
    channelId: "bg" | "obj";
    colors: [HexColor, HexColor, HexColor, HexColor];
    variants?: Record<string, [HexColor, HexColor, HexColor, HexColor]>;
}
export interface VbcChannel {
    id: "bg" | "obj";
    name: string;
}
export interface VbcScene {
    id: string;
    name: string;
    order?: number;
    description?: string;
}
export interface VbcObjectPaletteEntry {
    type: "palette";
    id: number;
    role?: string;
    variant?: string;
}
export interface VbcEditorObject {
    id: string;
    name: string;
    sceneId: string;
    kind?: string;
    order?: number;
    entries: VbcObjectPaletteEntry[];
}
export interface VbcPatchDocument {
    version: 2;
    id: string;
    name: string;
    description?: string;
    channels?: VbcChannel[];
    palettes: VbcPalette[];
    scenes?: VbcScene[];
    objects?: VbcEditorObject[];
    patch: {
        type: "bps";
        encoding: "hex";
        dataHex: string;
        sha256?: string;
    };
}
export interface AppliedBps {
    target: Uint8Array;
    metadataBytes: Uint8Array;
}
export declare function applyBps(source: Uint8Array, patch: Uint8Array): AppliedBps;
export declare function exportPatchedRom(sourceRom: Uint8Array, document: VbcPatchDocument): Promise<Uint8Array>;
//# sourceMappingURL=vbc-patch-export.d.ts.map