export type ChannelId = 'bg' | 'obj';
export type HexColor = `#${string}`;
export interface VbcPalette {
    id: number;
    name: string;
    channelId: ChannelId;
    colors: [HexColor, HexColor, HexColor, HexColor];
}
export declare const DEFAULT_VB_RED_RAMP: readonly HexColor[];
export declare function rgb888ToRgb555(color: string): number;
export declare function rgb555ToRgb888(value: number): HexColor;
export declare function makeDefaultPalettes(): VbcPalette[];
export declare function validatePalette(palette: VbcPalette): void;
export declare function normalizePalettes(palettes: readonly VbcPalette[]): VbcPalette[];
/** Encode all 256 four-color palettes as 1024 little-endian RGB555 words. */
export declare function encodeCramTable(palettes: readonly VbcPalette[]): Uint8Array;
export interface PaletteSelector {
    channelId: ChannelId;
    globalPaletteId: number;
    localPalette: number;
    legacyPalette: number;
    colorAttribute: number;
}
/**
 * Convert a global palette id to VBC 1.1's split selector:
 * low two bits stay in GPLTS/JPLTS, high five bits go to Color Attribute RAM.
 */
export declare function paletteSelector(globalPaletteId: number): PaletteSelector;
/** CPU address of the first RGB555 entry for a global palette id. */
export declare function cramAddressForPalette(globalPaletteId: number): number;
/** Four direct 16-bit CRAM writes useful for live editor preview; persistence still goes into the BPS. */
export declare function palettePreviewWrites(palette: VbcPalette): Array<{
    address: number;
    value: number;
}>;
//# sourceMappingURL=palette.d.ts.map