export interface BootstrapLayout {
    paletteTableCpuAddress: number;
    originalResetCpuAddress: number;
}
/**
 * Build the ROM-side bootstrap. It is deliberately conservative:
 * - detects VBC before touching VBC state;
 * - enables only VBCEN and COLEN;
 * - leaves CPUSPD, LNKCTRL, CHRCTRL and MEMCTRL at reset defaults;
 * - clears Cell/OBJ Color Attribute RAM so legacy GPLTS/JPLTS select palettes 0..3;
 * - uploads all 1024 RGB555 CRAM entries;
 * - jumps to the original, byte-unchanged reset vector.
 *
 * No stack or WRAM is used, so this can execute before the original game's startup.
 */
export declare function buildVbcBootstrap(layout: BootstrapLayout): Uint8Array;
//# sourceMappingURL=bootstrap.d.ts.map