/** VB Color 1.1 addresses used by the generic bootstrap. */
export declare const VBC: Readonly<{
    VBCID0: 50853888;
    VBCID1: 50853890;
    VBCVER: 50853892;
    VBCCTRL: 50853894;
    CPUSPD: 50853896;
    COLCTRL: 50853898;
    CBKPAL: 50853900;
    LNKCTRL: 50853902;
    CHRCTRL: 50853904;
    MEMCTRL: 50853906;
    CELL_ATTR_RAM: 50724864;
    OBJ_ATTR_RAM: 50790400;
    CRAM: 50827264;
    CRAM_BG: 50827264;
    CRAM_OBJ: 50828288;
}>;
export declare const VBCID0_VALUE = 16982;
export declare const VBCID1_VALUE = 8515;
export declare const VBC_ENABLE_KEY = 49153;
export declare const VBC_SUPPORT_ENHANCED = 128;
/** CPU-visible base of Game Pak ROM. */
export declare const ROM_CPU_BASE = 117440512;
export declare const ROM_CPU_END_EXCLUSIVE = 134217728;
/** VBC 1.1 permits up to 16 MiB directly addressable ROM. */
export declare const MAX_ROM_SIZE = 16777216;
/** Generic mirror-expansion strategy doubles the input, so source may be at most 8 MiB. */
export declare const MAX_GENERIC_SOURCE_SIZE: number;
export declare const MIN_GENERIC_SOURCE_SIZE = 65536;
/** Header offsets are relative to the physical end of the ROM image. */
export declare const VBC_SUPPORT_CODE_FROM_END = 524;
export declare const RESET_VECTOR_FROM_END = 16;
export declare const BG_PALETTE_COUNT = 128;
export declare const OBJ_PALETTE_COUNT = 128;
export declare const PALETTE_COUNT = 256;
export declare const COLORS_PER_PALETTE = 4;
export declare const CRAM_ENTRY_COUNT: number;
export declare const CRAM_TABLE_BYTES: number;
export declare const GENERATOR_ID = "vbc-generic-bootstrap-v1";
export declare const FORMAT_VERSION: 2;
//# sourceMappingURL=constants.d.ts.map