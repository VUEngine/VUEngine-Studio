/** Tiny V810 encoder containing only the instructions needed by the bootstrap. */
export declare const COND: Readonly<{
    V: 0;
    C: 1;
    Z: 2;
    NH: 3;
    S: 4;
    T: 5;
    LT: 6;
    LE: 7;
    NV: 8;
    NC: 9;
    NZ: 10;
    H: 11;
    NS: 12;
    F: 13;
    GE: 14;
    GT: 15;
}>;
export declare class V810Emitter {
    private readonly data;
    private readonly labels;
    private readonly branches;
    get offset(): number;
    private checkReg;
    emit16(word: number): void;
    private formatI;
    private formatV;
    label(name: string): void;
    cmp(r1: number, r2: number): void;
    jmp(reg: number): void;
    movImm5(value: number, r2: number): void;
    addImm5(value: number, r2: number): void;
    movea(imm16: number, r1: number, r2: number): void;
    ori(imm16: number, r1: number, r2: number): void;
    movhi(imm16: number, r1: number, r2: number): void;
    ldH(disp16: number, base: number, dest: number): void;
    stH(src: number, disp16: number, base: number): void;
    stW(src: number, disp16: number, base: number): void;
    loadU32(value: number, reg: number): void;
    loadU16(value: number, reg: number): void;
    branch(condition: number, label: string): void;
    nop(): void;
    finish(): Uint8Array;
}
/** 16-byte reset vector: load absolute address into r10, JMP [r10], NOP padding. */
export declare function buildAbsoluteJumpVector(targetAddress: number): Uint8Array;
//# sourceMappingURL=v810.d.ts.map