import { inspectBps } from './bps';
import { type VbcPalette } from './palette';
export interface EmbeddedBpsPatch {
    type: 'bps';
    encoding: 'hex';
    dataHex: string;
}
export interface VbcColorPatchDocument {
    version: 2;
    id: string;
    name: string;
    description: string;
    palettes: VbcPalette[];
    patch: EmbeddedBpsPatch;
}
export interface GeneratorOptions {
    id?: string;
    name?: string;
    description?: string;
    sourceSha256?: string;
    palettes?: readonly VbcPalette[];
}
export interface GenericPatchLayout {
    sourceSize: number;
    targetSize: number;
    upperMirrorOffset: number;
    stubOffset: number;
    stubSize: number;
    paletteTableOffset: number;
    paletteTableSize: number;
    supportCodeOffset: number;
    resetVectorOffset: number;
    stubCpuAddress: number;
    paletteTableCpuAddress: number;
    originalResetCpuAddress: number;
}
export interface GeneratedColorPatch {
    document: VbcColorPatchDocument;
    targetRom: Uint8Array;
    bps: Uint8Array;
    stub: Uint8Array;
    paletteTable: Uint8Array;
    layout: GenericPatchLayout;
}
export declare class GenericPatchError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function bytesToHex(data: Uint8Array): string;
export declare function hexToBytes(hex: string): Uint8Array;
export declare function validateGenericSourceRom(sourceRom: Uint8Array): void;
/**
 * Compute the deterministic mirror-expansion layout.
 * The upper half is a byte-for-byte mirror of the original except for:
 * bootstrap, CRAM table, VBC support byte, and reset vector.
 */
export declare function computeGenericLayout(sourceSize: number): GenericPatchLayout;
export declare function generateGenericColorPatch(sourceRom: Uint8Array, options?: GeneratorOptions): GeneratedColorPatch;
/** Recompile the embedded BPS from an edited format-v2 document. */
export declare function rebuildGenericColorPatch(sourceRom: Uint8Array, document: VbcColorPatchDocument, sourceSha256?: string): GeneratedColorPatch;
/** Verify and apply the BPS embedded in a finished format-v2 document. */
export declare function applyEmbeddedColorPatch(sourceRom: Uint8Array, document: VbcColorPatchDocument): Uint8Array;
export declare function inspectEmbeddedColorPatch(document: VbcColorPatchDocument): ReturnType<typeof inspectBps>;
/** `allowDraft=true` accepts an empty BPS only for the editor's new-document template. */
export declare function validateColorPatchDocument(document: VbcColorPatchDocument, allowDraft?: boolean): void;
//# sourceMappingURL=generator.d.ts.map