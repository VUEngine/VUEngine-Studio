/** Minimal dependency-free BPS encoder/decoder with CRC verification. */
export declare function crc32(data: Uint8Array): number;
/** BPS's biased little-endian base-128 integer. */
export declare function encodeNumber(input: number): Uint8Array;
export interface BpsMetadata {
    [key: string]: unknown;
}
/**
 * Compact encoder specialized for a target of exactly source||modified(source).
 * The lower half is SourceRead; the upper half is mostly TargetCopy from the lower half,
 * with only changed bootstrap/palette/header/vector regions encoded as TargetRead.
 */
export declare function createMirrorExpansionBps(source: Uint8Array, target: Uint8Array, metadata?: BpsMetadata): Uint8Array;
export interface ParsedBpsInfo {
    sourceSize: number;
    targetSize: number;
    metadataText: string;
    metadata: unknown;
}
export declare function inspectBps(patch: Uint8Array): ParsedBpsInfo;
export declare function applyBps(source: Uint8Array, patch: Uint8Array): Uint8Array;
//# sourceMappingURL=bps.d.ts.map