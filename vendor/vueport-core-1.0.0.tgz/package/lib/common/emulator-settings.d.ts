import type { ReactNode } from 'react';
import { Event } from './emulator-events';
import { GamepadProfile } from './emulator-gamepad-profiles';
import { EmulatorResumeStart } from './emulator-save-state';
import { EmulatorCompanionLocation, EmulatorSramInit, EmulatorSramWindow } from './emulator-sram';
import { FrameBlending, VbAnaglyphMatrices, VbDuboisProfileSelection } from './vb-constants';
export interface CustomPaletteSetting {
    name: string;
    colors: string[];
}
export interface CustomAnaglyphPaletteSetting {
    name: string;
    left: string;
    right: string;
    duboisProfile?: VbDuboisProfileSelection;
    duboisMatrices?: VbAnaglyphMatrices;
}
export interface TouchControlPlacement {
    dx: number;
    dy: number;
    scale: number;
}
export interface TouchControlsLayout {
    portrait?: Record<string, TouchControlPlacement>;
    landscape?: Record<string, TouchControlPlacement>;
}
export type TouchControlsMode = 'auto' | 'always' | 'never';
export interface VueportConfig {
    vbcSupportEnabled: boolean;
    vbcAutoApplyColorPatches: boolean;
    vbcColorPatchesDisabled: string[];
    hardwareMode: string;
    renderingMode: string;
    swapEyes: boolean;
    stereoDepth: number;
    frameBlending: FrameBlending;
    columnTable: boolean;
    mirrorSpinUp: boolean;
    mirrorSpinUpDelay: boolean;
    palette: string;
    anaglyphPalette: string;
    customPalettes: CustomPaletteSetting[];
    customAnaglyphPalettes: CustomAnaglyphPaletteSetting[];
    scale: string;
    decoration: string;
    decorationColor: string;
    decorationColorFromPalette: boolean;
    decorationIntensity: number;
    screenshotUseDisplaySettings: boolean;
    screenshotRenderingMode: string;
    screenshotFrameBlending: FrameBlending;
    screenshotScale: number;
    screenshotPalette: string;
    screenshotAnaglyphPalette: string;
    videoUseDisplaySettings: boolean;
    videoRenderingMode: string;
    videoFrameBlending: FrameBlending;
    videoScale: number;
    videoPalette: string;
    videoAnaglyphPalette: string;
    videoQuality: string;
    videoFormat: string;
    sramInit: EmulatorSramInit;
    sramWindow: EmulatorSramWindow;
    saveGameSlot: string;
    autoSaveStatesEnabled: boolean;
    autoSaveStateInterval: number;
    autoSaveStateCount: number;
    suspendResumeEnabled: boolean;
    suspendResumeStart: EmulatorResumeStart;
    companionFiles: EmulatorCompanionLocation;
    player2SameControls: boolean;
    gamepadProfiles: GamepadProfile[];
    gamepadPlayers: Record<string, number>;
    /**
     * Strength of game rumble on the controller when no Rumble Pack is there, in percent of the motors; 0 is off.
     * Full by default: such games were written to be felt, and many pads are on/off only (SDL's Switch driver says so;
     * the 8BitDo 64's motor does not start below a threshold and runs flat out above, pulsing only rattles), where a
     * lower setting only drops weak effects. See GamepadRumble
     */
    gamepadRumbleIntensity: number;
    turboRate: number;
    touchControls: TouchControlsMode;
    touchControlsOpacity: number;
    touchControlsSize: number;
    touchControlsDiagonals: boolean;
    touchControlsSlide: boolean;
    touchControlsVibration: boolean;
    touchControlsHighlight: boolean;
    touchControlsRumble: boolean;
    touchControlsLayout: TouchControlsLayout;
    rewindEnabled: boolean;
    rewindGranularity: number;
    rewindBufferSize: number;
    slowMotionRatio: number;
    fastForwardRatio: number;
    retroAchievementsEnabled: boolean;
    /**
     * Hardcore disables cheats, macros, ROM patches, save-state loading, rewind and Debug mode, and runs the achievement
     * engine in hardcore; enforced by RetroAchievementsService and the host's controls. Hardcore unlocks stay inert until
     * RetroAchievements approves the VUEPort client (memory editor, disassembler, rewind need discussing first), but
     * the client-side restrictions apply now
     */
    retroAchievementsHardcore: boolean;
    /**
     * How each debug panel was left, by `"<panel>.<control>"` (atlas width, disassembly following the PC, ...). One
     * setting with no schema entry, as these are only changed on the panels themselves, but kept so reopening finds
     * the inspectors as they were. Sparse: untouched controls are absent, values of a mismatched type are ignored.
     * See VesEmulatorPanel.remembered
     */
    debugPanelState: Record<string, string | number | boolean>;
    errorSoundEnabled: boolean;
    achievementSoundEnabled: boolean;
}
export declare const VUEPORT_DEFAULTS: VueportConfig;
export declare const VUEPORT_SETTING_RANGES: Partial<Record<keyof VueportConfig, {
    min: number;
    max: number;
}>>;
export interface VueportSettings {
    readonly fixed?: Partial<Record<keyof VueportConfig, string>>;
    readonly defaults?: Partial<VueportConfig>;
    get<K extends keyof VueportConfig>(key: K): VueportConfig[K];
    set<K extends keyof VueportConfig>(key: K, value: VueportConfig[K]): Promise<void>;
    readonly onDidChange: Event<keyof VueportConfig>;
    readonly ready: Promise<void>;
}
export interface VueportBindableCommand {
    id: string;
    label?: string;
    category?: string;
}
export type VueportBindingWrite = void | Promise<void>;
export interface VueportInputBindings {
    label(commandId: string, compact: boolean): string;
    keyCodes(commandId: string): string[];
    capture(command: VueportBindableCommand, when?: string, title?: ReactNode): Promise<boolean>;
    /**
     * Asks for a key for each command in turn and binds them all at once, or nothing if Escape comes first. Each
     * command gets exactly the pressed key, replacing its others. `title` names the step ("Start · 6 of 14"), `onStep`
     * gets the index of the command about to be asked. True only if the set was saved
     */
    captureAll(commands: VueportBindableCommand[], when: string | undefined, title: (command: VueportBindableCommand, step: number, total: number) => ReactNode, onStep?: (index: number) => void): Promise<boolean>;
    resetToDefaults(): VueportBindingWrite;
    bind(commandId: string, code: string): boolean | Promise<boolean>;
    clear(commandId: string): VueportBindingWrite;
    unbind?(commandId: string, code: string): VueportBindingWrite;
    keyLabel?(code: string): string;
    resetToDefault(commandId: string): VueportBindingWrite;
    replaceAll(codes: Record<string, string>): VueportBindingWrite;
}
//# sourceMappingURL=emulator-settings.d.ts.map