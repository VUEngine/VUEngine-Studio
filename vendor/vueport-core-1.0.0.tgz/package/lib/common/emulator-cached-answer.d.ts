export interface CachedAnswerRead<T> {
    value?: T;
    settled: boolean;
}
export declare class CachedAnswer<T> {
    protected readonly read: () => Promise<CachedAnswerRead<T>>;
    protected readonly retryDelay: number;
    protected readonly now: () => number;
    protected pending: Promise<T | undefined> | undefined;
    protected retryAfter: number;
    constructor(read: () => Promise<CachedAnswerRead<T>>, retryDelay: number, now?: () => number);
    get(): Promise<T | undefined>;
    get isAnswered(): boolean;
    clear(): void;
    protected forget(attempt: Promise<T | undefined>): void;
}
//# sourceMappingURL=emulator-cached-answer.d.ts.map