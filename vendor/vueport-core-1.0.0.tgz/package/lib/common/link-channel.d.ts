import { Disposable, Emitter, Event } from './emulator-events';
import { ScheduledEdit } from './vb-protocol';
/**
 * What travels between two linked windows: only inputs and what is needed to agree on what is played. Both windows
 * run the whole pair of machines and stay identical because the core is deterministic given the same cartridge and
 * inputs on the same frames (packages/core/tests/determinism-probe.mjs). So messages are tiny, and the protocol works
 * over a BroadcastChannel, the desktop shell or a data channel between two machines alike.
 */
export type LinkMessage = LinkHello | LinkWelcome | LinkBegin | LinkHandover | LinkResume | LinkRestart | LinkPause | LinkCall | LinkInput | LinkEdit | LinkDigest | LinkGoodbye;
export type LinkSeat = 1 | 2;
export declare const LINK_PROTOCOL_VERSION = 5;
export interface LinkHello {
    kind: 'hello';
    seat: LinkSeat;
    protocol: number;
    rom: string;
    core: number;
    running?: string;
    rejoin?: boolean;
}
export interface LinkMachine {
    state: ArrayBuffer;
    cartRam: ArrayBuffer;
    cartRamWindow: number;
}
export interface LinkWelcome {
    kind: 'welcome';
    seat: LinkSeat;
    protocol: number;
    rom: string;
    core: number;
    delay: number;
}
/**
 * Starts both windows' machines from power-on at frame zero, as two running windows would be hundreds of frames
 * apart. The cartridge save RAM travels with it, being the one part of a fresh machine that differs between sides.
 * Sent by player 1's window only, which is why one window answers a hello rather than both answering each other.
 */
export interface LinkBegin {
    kind: 'begin';
    seat: LinkSeat;
    cartRam: ArrayBuffer;
    cartRamWindow: number;
    image?: ArrayBuffer;
    vbc?: boolean;
    esSound?: boolean;
    /**
     * Player 1's machine as it stands, when relinking two windows running the very same code (LinkHello.rejoin and
     * LinkHello.running) picks both games up where they are. Each window keeps its own machine as it was and builds its
     * mirror from the other's state; cartRam and the cartridge fields are ignored. Player 2 answers with a
     * LinkHandover, and player 1 begins once it has it.
     */
    hot?: LinkMachine;
    epoch: number;
}
export interface LinkHandover {
    kind: 'handover';
    seat: LinkSeat;
    machine: LinkMachine;
}
export interface LinkResume {
    kind: 'resume';
    seat: LinkSeat;
    epoch: number;
    p1: ArrayBuffer;
    p2: ArrayBuffer;
}
export interface LinkRestart {
    kind: 'restart';
    seat: LinkSeat;
    epoch: number;
}
export interface LinkPause {
    kind: 'pause';
    seat: LinkSeat;
    paused: boolean;
}
export interface LinkCall {
    kind: 'call';
    seat: LinkSeat;
}
export interface LinkInput {
    kind: 'input';
    seat: LinkSeat;
    frame: number;
    keys: number;
    epoch: number;
}
/**
 * A change made to one of the machines from outside it (cheats, debugger pokes), booked against the frame it takes
 * effect on; nothing else carries it to the other window, and before this a cheat switched on mid-session ended it
 * at the digest check. The seat names the machine being changed, not the window asking, so either window can poke
 * either machine. See scheduleEdits in link-session.ts for how the frame is chosen.
 */
export interface LinkEdit {
    kind: 'edit';
    seat: LinkSeat;
    epoch: number;
    frame: number;
    edits: ScheduledEdit[];
}
export interface LinkDigest {
    kind: 'digest';
    seat: LinkSeat;
    epoch: number;
    frame: number;
    digest: number;
}
export interface LinkGoodbye {
    kind: 'bye';
    seat: LinkSeat;
    leaving: 'session' | 'window' | 'ended';
}
export interface LinkChannel extends Disposable {
    send(message: LinkMessage): void;
    readonly onMessage: Event<LinkMessage>;
}
export declare class BroadcastChannelLink implements LinkChannel {
    protected readonly channel: BroadcastChannel;
    protected readonly onMessageEmitter: Emitter<LinkMessage>;
    readonly onMessage: Event<LinkMessage>;
    protected closed: boolean;
    constructor(sessionId: string);
    send(message: LinkMessage): void;
    dispose(): void;
}
//# sourceMappingURL=link-channel.d.ts.map