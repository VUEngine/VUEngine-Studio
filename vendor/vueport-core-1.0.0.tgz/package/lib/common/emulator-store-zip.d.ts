/**
 * Just enough ZIP to write one, for a LAN share of a game that came packed or has ESSound tracks: the headset unpacks
 * it like any other .vbz. The reading side is the standalone build's (packages/web/src/web-zip.ts).
 */
/**
 * The files as one archive, stored rather than deflated: what goes in is a ROM and ESSound tracks, MP3 and Ogg are
 * compressed already, and the archive only crosses the local network. No dates (1980-01-01), no ZIP64, so nothing
 * over 4 GB, far beyond a ROM and its tracks.
 */
export declare function storeZip(files: ReadonlyArray<{
    name: string;
    data: Uint8Array;
}>): Uint8Array;
//# sourceMappingURL=emulator-store-zip.d.ts.map