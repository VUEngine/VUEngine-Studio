/** Patch formats accepted by the emulator. */
export type RomPatchFormat = 'ips' | 'ups' | 'bps' | 'bsdiff';
/** What kind of change a ROM patch makes. */
export declare const ROM_PATCH_TYPES: readonly ["hack", "debug", "trainer", "translation"];
export type RomPatchType = typeof ROM_PATCH_TYPES[number];
/** A patch ready to be applied to a ROM. */
export interface RomPatch {
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: Uint8Array;
    enabled: boolean;
    description?: string;
    author?: string;
    type: RomPatchType;
    /** Asset URL or data URL displayed by the patch detail view. */
    screenshot?: string;
    builtIn?: boolean;
    id?: string;
    /**
     * VUEPort built this patch in-process rather than reading it from a file.
     *
     * Currently only the VB Color colorizations, and the reason it is worth a
     * field is that they have a panel of their own: the Patches panel lists
     * what a player registered for this ROM, and a colorization is not that.
     * It is switched on from the Colors panel, its name and version come from
     * the colorization catalog rather than from a file, and removing it there
     * would mean nothing — so listing it beside imported patches would offer
     * three controls that either lie or do nothing. Set by
     * `VesEmulatorPatchStore.setGeneratedPatch`.
     */
    generated?: boolean;
}
/** A malformed patch, or one made for a different source ROM. */
export declare class RomPatchError extends Error {
    constructor(message: string);
}
/** Detect by signature; extensions are deliberately not trusted. */
export declare function detectRomPatchFormat(data: Uint8Array): RomPatchFormat;
/**
 * Apply one patch.
 *
 * The format algorithms follow RomPatcher.js (MIT, Marc Robledo) and their
 * respective public specifications, adapted to typed arrays and strict bounds
 * checking for VUEPort.
 */
export declare function applyRomPatch(source: Uint8Array, patch: Uint8Array): Uint8Array;
/** Apply enabled patches in list order, each one seeing the prior result. */
export declare function applyRomPatches(source: Uint8Array, patches: readonly RomPatch[]): Uint8Array;
/**
 * Encode a BPS patch that turns `source` into `target`.
 *
 * For patches VUEPort builds itself — a VB Color colorization, which is a whole
 * ROM by the time it is built and has to reach the patch store as a delta like
 * every other patch. Linear and deliberately simple: a run of bytes matching
 * the source at the same offset is a SourceRead, anything else goes in as a
 * TargetRead. For a target that is the source with some regions rewritten,
 * which is all this is used for, that is as small as a BPS gets without
 * searching for anything.
 */
export declare function createBpsPatch(source: Uint8Array, target: Uint8Array): Uint8Array;
//# sourceMappingURL=emulator-rom-patches.d.ts.map