/** Patch formats accepted by the emulator. */
export type RomPatchFormat = 'ips' | 'ups' | 'bps' | 'bsdiff';
/**
 * What kind of change a ROM patch makes.
 *
 * `vb-color` is a VB Color colorization, and the one type that changes how a
 * patch is handled, shipped or imported alike, all kept by `PatchStore`: a
 * game's colorizations are alternatives of which at most one is on, and one is
 * applied after every other patch and against the original ROM, then laid
 * over their result — see `overlayRomPatch` — so it combines with a
 * translation or a hack instead of refusing its source. Whether a shipped one
 * is on comes from the colorization settings rather than from the patch
 * switches.
 */
export declare const ROM_PATCH_TYPES: readonly ["hack", "enhancement", "debug", "trainer", "translation", "vb-color"];
export type RomPatchType = typeof ROM_PATCH_TYPES[number];
/** Whether a patch is a VB Color colorization — see {@link ROM_PATCH_TYPES}. */
export declare function isColorPatch(patch: {
    type: RomPatchType;
}): boolean;
/** How far along a patch that is still being worked on is. */
export type RomPatchStatus = 
/** Finished and verified against the game from start to end. */
'complete'
/** Playable and correct in most places, with known gaps. */
 | 'partial'
/** Being worked on; listed so it can be tried, not so it can be relied on. */
 | 'wip';
/** A patch ready to be applied to a ROM. */
export interface RomPatch {
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: Uint8Array;
    enabled: boolean;
    description?: string;
    author?: string;
    type: RomPatchType;
    builtIn?: boolean;
    id?: string;
    /** The patch's own version, where its catalog entry gives one. */
    version?: string;
    /** How far along the patch is, where its catalog entry says. */
    status?: RomPatchStatus;
}
/** A malformed patch, or one made for a different source ROM. */
export declare class RomPatchError extends Error {
    constructor(message: string);
}
/** Detect by signature; extensions are deliberately not trusted. */
export declare function detectRomPatchFormat(data: Uint8Array): RomPatchFormat;
/**
 * Apply one patch.
 *
 * The format algorithms follow RomPatcher.js (MIT, Marc Robledo) and their
 * respective public specifications, adapted to typed arrays and strict bounds
 * checking for VUEPort.
 */
export declare function applyRomPatch(source: Uint8Array, patch: Uint8Array): Uint8Array;
/** Apply enabled patches in list order, each one seeing the prior result. */
export declare function applyRomPatches(source: Uint8Array, patches: readonly RomPatch[]): Uint8Array;
/**
 * Lay a patch made against the original ROM over a ROM other patches have
 * already changed.
 *
 * What a VB Color colorization needs to be combined with anything at all. Its
 * BPS is made against the original — it has to be, since it ships for that
 * ROM — so applied after a translation or a hack
 * it would refuse the source it was handed, and applied before one it would
 * hand *that* patch a source it refuses in turn. So it is applied to the
 * original on its own, and what it changed is carried over: every byte where
 * its result differs from the original comes from it, every other byte from
 * the ROM the other patches made. A colorization doubles the cartridge, so the
 * comparison wraps at the original's size, the way the mirror does.
 *
 * Where both changed the same byte, the colorization wins: its hooks are code,
 * and half a hook is a crash where half a translated string is a typo. And a
 * patch that changed the ROM's size cannot be combined this way at all —
 * nothing says where its bytes would land in the doubled cartridge — which is
 * refused rather than guessed at.
 */
export declare function overlayRomPatch(original: Uint8Array, patched: Uint8Array, patch: Uint8Array): Uint8Array;
/**
 * Encode a BPS patch that turns `source` into `target`.
 *
 * For a patch made from a whole ROM, which has to reach the patch store as a
 * delta like every other patch. Linear and deliberately simple: a run of bytes matching
 * the source at the same offset is a SourceRead, anything else goes in as a
 * TargetRead. For a target that is the source with some regions rewritten,
 * which is all this is used for, that is as small as a BPS gets without
 * searching for anything.
 */
export declare function createBpsPatch(source: Uint8Array, target: Uint8Array): Uint8Array;
//# sourceMappingURL=emulator-rom-patches.d.ts.map