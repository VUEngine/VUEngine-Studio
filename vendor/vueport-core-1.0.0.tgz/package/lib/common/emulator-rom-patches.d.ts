export type RomPatchFormat = 'ips' | 'ups' | 'bps' | 'bsdiff';
export declare const ROM_PATCH_TYPES: readonly ["hack", "enhancement", "debug", "trainer", "translation", "vb-color"];
export type RomPatchType = typeof ROM_PATCH_TYPES[number];
export declare function isColorPatch(patch: {
    type: RomPatchType;
}): boolean;
export type RomPatchStatus = 'complete' | 'partial' | 'wip';
export interface RomPatch {
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: Uint8Array;
    enabled: boolean;
    description?: string;
    author?: string;
    type: RomPatchType;
    builtIn?: boolean;
    id?: string;
    version?: string;
    status?: RomPatchStatus;
}
export declare class RomPatchError extends Error {
    constructor(message: string);
}
export declare function detectRomPatchFormat(data: Uint8Array): RomPatchFormat;
export declare function applyRomPatch(source: Uint8Array, patch: Uint8Array): Uint8Array;
export declare function applyRomPatches(source: Uint8Array, patches: readonly RomPatch[]): Uint8Array;
/**
 * Lays a patch made against the original ROM over a ROM other patches have already changed, which is what a
 * VB Color colorization needs: its BPS is made against the original, so it would refuse a translated source,
 * and applied first it would make the next patch refuse its source. So it is applied to the original alone,
 * and every byte where its result differs comes from it, every other byte from the other patches' ROM.
 * A colorization grows the cartridge downwards: the original stays at the top at its own addresses, the space
 * below is the colorization's. The other patches' bytes go there only into blocks the colorization kept as a
 * copy of the original (some keep mirrored stretches for code reading through a lower mirror); a block it
 * changed at all is its own. Where both changed a byte the colorization wins: half a hook is a crash, half a
 * translated string a typo. The other patches may grow the ROM the same way; all are aligned at the top, so
 * one needing more room goes below the colorization's space. Own bytes of both in the same space, or a patch
 * that shrinks the ROM, are refused; filler (0x00 or 0xFF, as an IPS that grows the ROM pads it) is no own byte.
 */
export declare function overlayRomPatch(original: Uint8Array, patched: Uint8Array, patch: Uint8Array): Uint8Array;
export declare function createBpsPatch(source: Uint8Array, target: Uint8Array): Uint8Array;
//# sourceMappingURL=emulator-rom-patches.d.ts.map