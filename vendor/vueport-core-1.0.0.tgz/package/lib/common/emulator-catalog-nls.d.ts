/**
 * Translations of the shipped catalogs (cheats, ROM patches and colorizations) and of RetroAchievements achievements.
 * Entry texts are translated under keys built from the stable id (`vueport/cheatDatabase/<id>/title`,
 * `vueport/patchDatabase/<id>/name`...), with the English as the default. Shared patch names and description intros
 * are translated once (PATCH_SHARED_NAMES, PATCH_DESCRIPTION_INTROS).
 * `yarn nls-extract` cannot follow built keys, so their i18n/nls.json entries are kept by hand and
 * tests/catalog-nls-probe.mjs checks every entry has them in every shipped language.
 * Called when an entry is shown or loaded, never at module load (see emulator-nls.ts).
 * An achievement's key also carries the CRC32 of its English (`vueport/achievementDatabase/56777/title-<crc32>`), so
 * one reworded by its RetroAchievements authors shows the new English rather than a translation of the old.
 */
import { BuiltInCheat } from './emulator-cheat-database';
import { BuiltInRomPatch } from './emulator-patch-database';
export declare function cheatTitle(cheat: BuiltInCheat): string;
export declare function cheatNotes(cheat: BuiltInCheat): string | undefined;
export declare function patchName(patch: BuiltInRomPatch): string;
export declare function patchDescription(patch: BuiltInRomPatch): string | undefined;
export declare function achievementTextKey(id: number, field: 'title' | 'description', english: string): string;
export declare function localizeAchievement<T extends {
    id: number;
    title: string;
    description: string;
}>(achievement: T): T;
//# sourceMappingURL=emulator-catalog-nls.d.ts.map