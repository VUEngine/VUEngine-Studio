/**
 * The colorization patches that ship with VUEPort, and which games they are for.
 *
 * A VB Color patch is an ordinary ROM patch: one compiled BPS, made against
 * the original ROM, that gives a Virtual Boy title everything the VB Color
 * hardware needs. VUEPort ships it as its authors built it and applies it as
 * it is; there is nothing in it to edit. Nothing about applying one is
 * special; what is special is that a player should not have to go and find
 * it. And because it is a ROM patch, it is switched off in hardcore mode like
 * any other.
 *
 * Two switches decide whether one is applied *when a game is opened*, and they
 * nest. `vbcAutoApplyColorPatches` is the master: off, nothing here comes on by
 * itself. On, each entry answers for itself — a player who wants color
 * everywhere except in one game turns that one off rather than the feature.
 * `vbcColorPatchesDisabled` holds the ids they opted out of, so the default
 * state of a newly shipped entry is on.
 *
 * Neither decides whether a colorization is *known*. The Patches panel lists
 * every colorization for the running game and writes both of these when one
 * is switched, so a game whose colorization is switched off still has one —
 * it is off, which is a thing the panel has to be able to say and to undo.
 * That is why the lookup below takes no choice: finding the colorizations and
 * choosing to apply one are two questions, and answering them together is what
 * once made the panel unable to show a switch for a game somebody had turned
 * off.
 *
 * A game may have several. They are alternatives rather than layers — each
 * one's BPS is made against the original ROM, so two of them cannot be
 * chained — and so at most one is applied at a time. Which one comes on by
 * itself is the first in catalog order that the switches leave on; switching
 * one on in the panel switches its siblings off in those same settings, so
 * the choice holds the next time the game is opened.
 *
 * Keyed by CRC32 of the whole file, for the reason `emulator-cheat-database.ts`
 * gives: it is what the preservation catalogs key on, it is cheap, and it
 * works in an insecure context where `crypto.subtle` does not. One game has one
 * CRC32 per padding, which is why an entry carries a list of them. Each CRC32
 * below is the source CRC in the footer of the entry's own BPS, so a match here
 * is a ROM the patch will accept.
 */
/** How far along a game's colorization is. */
export type VesColorPatchStatus = 
/** Finished and verified against the game from start to end. */
'complete'
/** Playable and color-correct in most places, with known gaps. */
 | 'partial'
/** Being worked on; listed so it can be tried, not so it can be relied on. */
 | 'wip';
/** One game's colorization. */
export interface VesColorPatch {
    /**
     * Stable for the life of the entry: renaming the game is fine, changing
     * this is not, because whether a player turned it off — and every color
     * they changed — is filed under it.
     */
    id: string;
    /** The game, as its catalog entry names it. */
    game: string;
    /** What the Patches panel lists it as. */
    name: string;
    /** Lower-case, eight hex digits, one per known ROM of this game. */
    crc32: string[];
    /** Who did the colorization. */
    author?: string;
    /** The patch's own version, which moves independently of VUEPort's. */
    version?: string;
    status: VesColorPatchStatus;
    /**
     * What is worth knowing before turning it on — which revision it was made
     * against, what is not colored yet, anything that looks wrong on purpose.
     */
    notes?: string;
    /**
     * The BPS, relative to where the host serves its assets. Absent while an
     * entry is a placeholder, which is what {@link isVesColorPatchReady} tests
     * for.
     */
    file?: string;
}
/**
 * Whether an entry can actually do anything yet.
 *
 * An entry with no BPS and no ROMs to match is a promise rather than a
 * feature: {@link colorPatchesForRom} passes over it, so nothing can be offered
 * as something to switch on before there is anything behind the switch.
 */
export declare function isVesColorPatchReady(patch: VesColorPatch): boolean;
export declare const COLOR_PATCH_DATABASE: VesColorPatch[];
/** Both switches that decide whether a colorization is applied. */
export interface VesColorPatchChoice {
    /** The master switch, `vbcAutoApplyColorPatches`. */
    autoApply: boolean;
    /** The ids turned off individually, `vbcColorPatchesDisabled`. */
    disabled: readonly string[];
}
/**
 * Every colorization that ships for a ROM, in catalog order.
 *
 * Nothing is returned for an entry that is not ready, so a placeholder can
 * never be offered as something to switch on. Whether one *is* switched on is
 * {@link colorPatchAutoApplied}'s question, deliberately kept apart — see this
 * module's own note.
 */
export declare function colorPatchesForRom(crc32: string): VesColorPatch[];
/**
 * Whether the settings say this one should come on when its game is opened.
 *
 * The master switch is read here rather than left to the caller, so that the
 * rule — off means off, whatever the individual entries say — is stated once
 * instead of once per place that loads a ROM.
 */
export declare function colorPatchAutoApplied(patch: VesColorPatch, choice: VesColorPatchChoice): boolean;
//# sourceMappingURL=emulator-color-patches.d.ts.map