export interface BuiltInCheat {
    id: string;
    description: string;
    codes: string;
    notes?: string;
}
export interface CheatDatabaseEntry {
    game: string;
    crc32: string[];
    cheats: BuiltInCheat[];
}
export declare const CHEAT_DATABASE: CheatDatabaseEntry[];
export declare function crc32(bytes: Uint8Array): number;
export declare function formatRomId(checksum: number): string;
export declare function builtInCheatsFor(romId: string | undefined, database?: CheatDatabaseEntry[]): BuiltInCheat[];
//# sourceMappingURL=emulator-cheat-database.d.ts.map