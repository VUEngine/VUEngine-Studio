import { CheatCode } from './emulator-cheats';
export interface BuiltInCheat {
    id: string;
    description: string;
    codes: string;
    notes?: string;
}
export interface CheatDatabaseEntry {
    game: string;
    crc32: string[];
    cheats: BuiltInCheat[];
}
export declare const CHEAT_DATABASE: CheatDatabaseEntry[];
export declare function crc32(bytes: Uint8Array): number;
export declare function formatRomId(checksum: number): string;
/**
 * Published ROM codes address the bottom mirror (`7069F2E`). A ROM-growing patch puts the original image at the
 * top, where the reset vector has to stay, so the code moves to the topmost mirror, which reaches the same byte
 * both ways: `7E69F2E` for a 2 MiB original. Only ROM addresses, sized by the unpatched ROM (that is what the
 * CRC32 is of); RAM stays where it is.
 */
export declare function anchorCheatCodeToRomTop(code: CheatCode, romSize: number): CheatCode;
export declare function builtInCheatsFor(romId: string | undefined, database?: CheatDatabaseEntry[]): BuiltInCheat[];
//# sourceMappingURL=emulator-cheat-database.d.ts.map