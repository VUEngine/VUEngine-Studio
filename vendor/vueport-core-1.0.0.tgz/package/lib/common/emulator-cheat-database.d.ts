/**
 * Cheats that ship with the emulator.
 *
 * Keyed by the CRC32 of the whole ROM, which is what the Virtual Boy's
 * preservation catalogs (No-Intro, and libretro's own cheat lists) key on —
 * so an entry here can be taken from those without a translation step. It is
 * also cheap, needs no crypto API, and works in an insecure context, which
 * `crypto.subtle` does not.
 *
 * A CRC32 covers a whole file, and a Virtual Boy ROM is routinely padded up to
 * the next power of two — the header lives at `size - 544`, so it floats with
 * the end and parsing is unaffected, but the checksum is not. The same game
 * therefore has one CRC32 per padding, which is why an entry carries a list of
 * them rather than one.
 */
/** One cheat the emulator knows about without being told. */
export interface BuiltInCheat {
    /**
     * Stable for the life of the cheat: renaming its description is fine,
     * changing this is not, because a player's on/off state is filed under it.
     */
    id: string;
    description: string;
    /**
     * The codes, in the `+`-separated form the `.cht` files use — so an entry
     * can be pasted from a published list unchanged.
     */
    codes: string;
    /**
     * What is worth knowing beyond the name — a caveat about when the codes
     * take effect, why a game needs two variants, what was tried and did not
     * work. Optional, and shown but not editable, the same as the description
     * and the codes: see `Cheat.notes` for where it ends up.
     */
    notes?: string;
}
/** One game, and every ROM of it these cheats apply to. */
export interface CheatDatabaseEntry {
    /** For whoever is reading the database; never shown. */
    game: string;
    /** Lower-case, eight hex digits, one per known ROM of this game. */
    crc32: string[];
    cheats: BuiltInCheat[];
}
export declare const CHEAT_DATABASE: CheatDatabaseEntry[];
/** The CRC32 of a ROM, lower-case and eight digits, as the database spells it. */
/**
 * CRC-32 of a ROM, which is how the preservation catalogs the cheat database
 * is drawn from identify a dump.
 *
 * Written out rather than taken from a package: it is twenty lines, and this
 * is the only checksum the emulator needs — a host that already has one is
 * free to compute the number itself and call `formatRomId`.
 */
export declare function crc32(bytes: Uint8Array): number;
export declare function formatRomId(checksum: number): string;
/**
 * The cheats shipped for a ROM, or none for one nothing is known about — which
 * is the ordinary case for homebrew and for anything still being built.
 */
export declare function builtInCheatsFor(romId: string | undefined, database?: CheatDatabaseEntry[]): BuiltInCheat[];
//# sourceMappingURL=emulator-cheat-database.d.ts.map