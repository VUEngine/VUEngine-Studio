/**
 * Macros: recorded button sequences. A macro is a list of states, not presses and releases, so it cannot express
 * a stuck button: every entry says what is held until the next one. Invariants, set by `finishMacro` and relied on
 * everywhere: the first entry is at 0, and the last holds nothing with `duration` as its moment, so a macro always
 * ends released and looping is `elapsed % duration`. Times are milliseconds of emulated running time, so a pause
 * while recording does not lengthen it.
 */
export interface MacroStep {
    at: number;
    keys: number;
}
export interface Macro {
    name: string;
    steps: MacroStep[];
    duration: number;
    loop?: boolean;
    global?: boolean;
    slot?: number;
}
export declare const MACRO_SLOT_COUNT = 8;
export declare function readMacroSlot(value: unknown): number | undefined;
export declare const MACRO_FILE_VERSION = 1;
export declare function emptyMacro(name: string): Macro;
export declare function macroIsEmpty(macro: Macro): boolean;
export declare function finishMacro(name: string, steps: MacroStep[], stoppedAt: number): Macro;
export declare function macroKeysAt(macro: Macro, elapsed: number): number;
export declare function macroKeysUsed(macro: Macro): number;
export declare function macroPresses(macro: Macro): number[];
export declare function macroPressCount(macro: Macro): number;
export declare function formatMacroDuration(milliseconds: number): string;
export declare function parseMacroFile(text: string): Macro[];
export declare function serializeMacroFile(macros: ReadonlyArray<Macro>): string;
//# sourceMappingURL=emulator-macros.d.ts.map