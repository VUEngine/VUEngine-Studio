/**
 * Macros: recorded button sequences, and the file they live in.
 *
 * A macro is what the controller did, written down — a list of moments and the
 * buttons held from each of them. Played back, the emulator holds those same
 * buttons at those same moments, so a sequence somebody worked out once (a
 * fighting game's combo, a level's opening, a code typed on the title screen)
 * can be repeated exactly, any number of times.
 *
 * Deliberately a list of *states* rather than of presses and releases. A press
 * without its release is a stuck button, and a release without its press does
 * nothing, so a format that can express either separately can express a macro
 * that is wrong. Here every entry says what is held from that moment until the
 * next one, which makes both impossible: playback is "find the last entry that
 * has happened and hold exactly that".
 *
 * Two invariants, established by `finishMacro` and relied on everywhere
 * else:
 *
 *   - the first entry is at 0, so a macro starts the moment it is played
 *     rather than after however long the person took to press anything;
 *   - the last entry holds nothing, and `duration` is its moment — so a macro
 *     always ends with its buttons released, and a looping one is simply
 *     `elapsed % duration`.
 *
 * Times are milliseconds of *emulated* running time: the clock that measures
 * them stops with the machine (see the macro store), so a recording is not
 * lengthened by the pause somebody took in the middle of it.
 *
 * Everything here is pure, so it can be reasoned about, and tested, without a
 * running emulator or a file system.
 */
/** One moment in a macro, and the buttons held from it. */
export interface MacroStep {
    /** Milliseconds from the start of the macro. */
    at: number;
    /**
     * The buttons held from this moment on, as a VbKey mask.
     *
     * The player's buttons only: the "controller present" bit and the low
     * battery signal are the machine's business and are folded in by whatever
     * pushes a mask into the core, not recorded here.
     */
    keys: number;
}
export interface Macro {
    name: string;
    steps: MacroStep[];
    /** How long it runs, in milliseconds, which is its last step's moment. */
    duration: number;
    /** Play it again from the top, until something stops it. */
    loop?: boolean;
    /**
     * Whether this macro belongs to every game rather than to one.
     *
     * Which file it is kept in, said on the object so the list can mark it —
     * not part of the recording, and so not written into either file: the file
     * a macro is in is what makes it global, and a flag saying otherwise could
     * only ever contradict it. `loop` is left out of the files for the same
     * reason and a different one; see `serializeMacroFile`.
     */
    global?: boolean;
}
/** What the file says it is, so a later format can be told from this one. */
export declare const MACRO_FILE_VERSION = 1;
/** A macro with nothing in it — what an empty recording finishes as. */
export declare function emptyMacro(name: string): Macro;
/** Whether there is anything to play: at least one step that holds a button. */
export declare function macroIsEmpty(macro: Macro): boolean;
/**
 * Turn a raw recording into a macro that satisfies both invariants above.
 *
 * `steps` are as they were observed, timed from when recording started;
 * `stoppedAt` is when it stopped, on the same clock. Leading dead time is cut
 * — the wait between pressing Record and pressing the first button belongs to
 * nobody — and a release is appended if the recording ended with something
 * still held, so playback can never leave a button down.
 */
export declare function finishMacro(name: string, steps: MacroStep[], stoppedAt: number): Macro;
/**
 * The buttons a macro holds `elapsed` milliseconds in.
 *
 * A linear scan from the front, which is what playback wants anyway: it steps
 * forward a frame at a time and would gain nothing from a search. Past the end
 * nothing is held, which the closing step already says.
 */
export declare function macroKeysAt(macro: Macro, elapsed: number): number;
/** Every button the macro ever holds, as one mask — for saying what it uses. */
export declare function macroKeysUsed(macro: Macro): number;
/**
 * The presses it makes, in order: what each step *adds* to what was already
 * held, as a mask per press.
 *
 * A press is a button going down, which is not the same as a step — releases
 * are not presses, and letting go of one of two buttons is not a new one. Two
 * buttons going down together are one press of two, which is why this is a
 * list of masks rather than of single buttons: a chord is a thing somebody did
 * once, and splitting it would read as two.
 *
 * This is the sequence a person would read out loud from watching the
 * recording, which is what the list shows under a macro's name.
 */
export declare function macroPresses(macro: Macro): number[];
/** How many presses it contains. */
export declare function macroPressCount(macro: Macro): number;
/** A duration, as short as it can be said: `0.4 s`, `12.5 s`, `1:03.2`. */
export declare function formatMacroDuration(milliseconds: number): string;
/**
 * Read the macros file beside a ROM.
 *
 * Lenient in the same way the cheat reader is, and for a weaker version of the
 * same reason: this format is the emulator's own, but a file can still be
 * hand-edited, truncated by a browser that ran out of quota, or left behind by
 * a future version. Anything that does not parse as a macro is dropped, and
 * the rest are kept — losing one macro beats losing the file.
 */
export declare function parseMacroFile(text: string): Macro[];
export declare function serializeMacroFile(macros: ReadonlyArray<Macro>): string;
//# sourceMappingURL=emulator-macros.d.ts.map