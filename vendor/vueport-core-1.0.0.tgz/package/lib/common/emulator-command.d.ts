export interface Command {
    id: string;
    label?: string;
    originalLabel?: string;
    iconClass?: string;
    category?: string;
    originalCategory?: string;
}
/**
 * A command whose label and category are translated when read: unlike Theia's, the emulator's localization is
 * installed during start-up, long after these module-level constants are created.
 * The name is load-bearing: yarn nls-extract matches the callee text Command.toLocalizedCommand exactly, or all
 * the commands drop out of nls.json silently. The accessors use defineProperty because TypeScript downlevels a
 * spread to Object.assign, which reads getters and would freeze every label; never copy a command with spread.
 */
export declare namespace Command {
    function toLocalizedCommand(command: Command, labelKey?: string, categoryKey?: string): Command;
}
//# sourceMappingURL=emulator-command.d.ts.map