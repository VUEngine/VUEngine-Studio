/**
 * Recorded input movies, as the Virtual Boy emulators that make them write
 * them down.
 *
 * A movie is one line per frame saying which buttons were held, and nothing
 * else: no save states, no memory, no timing. Played back from a reset on the
 * same ROM, a deterministic core reproduces the run exactly — which is what
 * makes a tool-assisted run a usable way to drive the machine somewhere far
 * from the title screen.
 *
 * Only VBjin's `.mc2` is read here. It is the format the published Virtual Boy
 * runs are in, it is plain text, and the alternative formats belong to
 * emulators whose cores are not this one.
 *
 * ## What playing one back does not promise
 *
 * A movie reproduces a run exactly on the core it was recorded with, and only
 * there. Two cores that disagree about a single cycle of a single instruction
 * will hold the same buttons and get different games — usually within a minute
 * of real play, because the first thing a run that has drifted does is walk the
 * player into something.
 *
 * That is not a fault in either core or in this reader, and it cannot be
 * corrected by aligning the start: an emulator's idea of what happens between
 * power-on and its first counted frame differs too, and shifting the movie to
 * match only moves where the drift begins. adelikat's published Wario Land run
 * was measured against this checkout's core and comes apart about fifty
 * seconds into the first course whatever the alignment, on the patched
 * cartridge and the original alike. So playback is worth having for what it is
 * — a hands-free way to drive a game a long way from its title screen — and is
 * not a way to reproduce somebody else's run.
 */
/** One frame of a movie: the buttons held, as a VbKey mask. */
export type MovieFrame = number;
export interface Movie {
    /** What wrote it — `VBjin`, and the version it claims. */
    emulator: string;
    emulatorVersion: string;
    /** How many times the author rewound while making it, if it says. */
    rerecordCount?: number;
    /** The free-text `comment` lines, in order, with the keyword kept. */
    comments: string[];
    frames: MovieFrame[];
}
/** How many buttons a movie line carries. */
export declare const MOVIE_BUTTON_COLUMNS: number;
/**
 * Read a VBjin `.mc2`.
 *
 * Lenient about the header, which differs between the versions that wrote
 * these and carries nothing playback depends on, and strict about the frames,
 * which are the movie. A line that is not a frame and not a header line is
 * skipped rather than refused: a movie with a stray blank line is still a
 * movie.
 */
export declare function parseVesMovie(text: string): Movie;
/** Whether a file looks like a movie this can read, by its first line. */
export declare function looksLikeVesMovie(text: string): boolean;
/** A movie's length as a duration, at the Virtual Boy's fifty frames a second. */
export declare function formatVesMovieLength(frames: number): string;
//# sourceMappingURL=emulator-movie.d.ts.map