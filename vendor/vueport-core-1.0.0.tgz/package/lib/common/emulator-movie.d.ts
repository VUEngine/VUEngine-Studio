/**
 * Recorded input movies: one line per frame saying which buttons were held, which a deterministic core replays
 * exactly from a reset on the same ROM. Only VBjin's .mc2 is read, the format published VB runs are in.
 * A movie only reproduces a run on the core it was recorded with: cores disagreeing about a single cycle drift
 * apart, and aligning the start does not help, as the time before the first counted frame differs too. adelikat's
 * Wario Land run comes apart about fifty seconds into the first course on this core whatever the alignment, so
 * playback is a hands-free way to drive a game far from its title screen, not a way to reproduce somebody's run.
 */
export type MovieFrame = number;
export interface Movie {
    emulator: string;
    emulatorVersion: string;
    rerecordCount?: number;
    comments: string[];
    frames: MovieFrame[];
}
export declare const MOVIE_BUTTON_COLUMNS: number;
export declare function parseVesMovie(text: string): Movie;
export declare function looksLikeVesMovie(text: string): boolean;
export declare function formatVesMovieLength(frames: number): string;
//# sourceMappingURL=emulator-movie.d.ts.map