import { LiveProfileSnapshot } from './emulator-live-profile';
import { DisplayMode, DisplayOutput } from './vb-constants';
export type SimHandle = number;
export interface Recording {
    state: ArrayBuffer;
    chunks: number;
    keys: [number, number][];
}
export interface ProfileNode {
    parent: number;
    address: number;
    selfSamples: number;
    totalSamples: number;
}
export interface ProfileResult {
    nodes: ProfileNode[];
    instructions: number;
    overflows: number;
    resets: number;
    elapsedMs: number;
}
export interface Backdrop {
    pixels: ArrayBuffer;
    colorMode: boolean;
}
export type FrameKind = 'next' | 'replace' | 'jump';
export interface Frame {
    pixels: ArrayBuffer;
    colorMode: boolean;
    kind?: FrameKind;
}
export interface RewindHistory {
    frames: number[];
    thumbnails: number[];
    cursor: number;
}
export interface VideoFrame extends Frame {
    sim: SimHandle;
    presentation: number;
}
export interface CoreCommands {
    init: {
        params: {
            wasmUrl: string;
            rcheevosModuleUrl?: string;
        };
        result: void;
    };
    createSim: {
        params: Record<string, never>;
        result: SimHandle;
    };
    deleteSim: {
        params: {
            sim: SimHandle;
        };
        result: void;
    };
    attachCanvas: {
        params: {
            sim: SimHandle;
            canvas: OffscreenCanvas;
        } | {
            sim: SimHandle;
            mainThread: {
                presentation: number;
                buffers: ArrayBuffer[];
            };
        };
        result: void;
    };
    setCartRom: {
        params: {
            sim: SimHandle;
            rom: ArrayBuffer;
        };
        result: void;
    };
    setCartRam: {
        params: {
            sim: SimHandle;
            ram: ArrayBuffer;
        };
        result: void;
    };
    getCartRam: {
        params: {
            sim: SimHandle;
            length?: number;
        };
        result: ArrayBuffer;
    };
    cartRamInfo: {
        params: {
            sim: SimHandle;
        };
        result: {
            size: number;
            used: number;
        };
    };
    stateSize: {
        params: Record<string, never>;
        result: number;
    };
    reset: {
        params: {
            sim: SimHandle;
        };
        result: void;
    };
    setHardwareMode: {
        params: {
            sim: SimHandle;
            vbc: boolean;
        };
        result: boolean;
    };
    setKeys: {
        params: {
            sim: SimHandle;
            keys: number;
        };
        result: void;
    };
    setTurbo: {
        params: {
            sim: SimHandle;
            keys: number;
            rate: number;
        };
        result: void;
    };
    /**
     * Books a mask against the frame number it belongs to, applied by the drive loop as that frame comes up, so the same
     * press lands on the same frame on two linked machines however long the wire took. Frames are counted like the
     * `speed` report. A frame already emulated is refused rather than silently dropped, as a link session needs to know.
     */
    queueKeys: {
        params: {
            sim: SimHandle;
            frame: number;
            keys: number;
        };
        result: void;
    };
    setLockstep: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    stateDigest: {
        params: {
            sim: SimHandle;
        };
        result: {
            frame: number;
            digest: number;
        };
    };
    setDigestPeriod: {
        params: {
            sim: SimHandle;
            frames: number;
        };
        result: void;
    };
    linkJournal: {
        params: {
            sim: SimHandle;
        };
        result: LinkJournalEntry[];
    };
    setDisplayMode: {
        params: {
            sim: SimHandle;
            mode: DisplayMode;
        };
        result: void;
    };
    setDisplayOutput: {
        params: {
            sim: SimHandle;
            output?: DisplayOutput;
        };
        result: void;
    };
    capture: {
        params: {
            sim: SimHandle;
            mode?: DisplayMode;
            scale?: number;
        };
        result: ArrayBuffer;
    };
    setVolume: {
        params: {
            sim: SimHandle;
            volume: number;
        };
        result: void;
    };
    setPanning: {
        params: {
            sim: SimHandle;
            panning: number;
        };
        result: void;
    };
    run: {
        params: Record<string, never>;
        result: void;
    };
    suspend: {
        params: Record<string, never>;
        result: void;
    };
    saveState: {
        params: {
            sim: SimHandle;
        };
        result: ArrayBuffer;
    };
    loadState: {
        params: {
            sim: SimHandle;
            state: ArrayBuffer;
            clearCaches?: boolean;
        };
        result: void;
    };
    startProfileRecording: {
        params: {
            sim: SimHandle;
        };
        result: void;
    };
    stopProfileRecording: {
        params: {
            sim: SimHandle;
        };
        result: Recording;
    };
    replayProfile: {
        params: {
            sim: SimHandle;
            recording: Recording;
        };
        result: ProfileResult;
    };
    setLiveProfiler: {
        params: {
            sim: SimHandle;
            enabled: boolean;
            window?: number;
        };
        result: void;
    };
    readLiveProfile: {
        params: {
            sim: SimHandle;
            pin?: number;
        };
        result: LiveProfileSnapshot | undefined;
    };
    setSpeed: {
        params: {
            speed: number;
        };
        result: void;
    };
    setStereoDepth: {
        params: {
            depth: number;
        };
        result: void;
    };
    setColumnGeometry: {
        params: {
            enabled: boolean;
        };
        result: void;
    };
    setMirrorSpinUp: {
        params: {
            enabled: boolean;
            fullDelay: boolean;
        };
        result: void;
    };
    stepFrame: {
        params: Record<string, never>;
        result: void;
    };
    setRewind: {
        params: {
            enabled: boolean;
            granularity: number;
            budgetBytes: number;
        };
        result: void;
    };
    rewindStep: {
        params: {
            count?: number;
        };
        result: number;
    };
    /**
     * The history for the filmstrip, taken while suspended: the moment now is captured first, with a thumbnail, so
     * going back to the newest capture returns exactly here. Browsing it with rewindSeek moves back and forth without
     * losing anything; what lies after the capture landed on is let go once the machine runs again
     */
    rewindHistory: {
        params: {
            sim: SimHandle;
        };
        result: RewindHistory;
    };
    rewindSeek: {
        params: {
            index: number;
        };
        result: number;
    };
    rewindThumbnail: {
        params: {
            sim: SimHandle;
            index: number;
        };
        result: ArrayBuffer | undefined;
    };
    readRewindThumbnail: {
        params: {
            index: number;
        };
        result: Frame | undefined;
    };
    setPeer: {
        params: {
            sim: SimHandle;
            peer: SimHandle;
            order?: 1 | 2;
        };
        result: void;
    };
    readPixels: {
        params: {
            sim: SimHandle;
            x: number;
            y: number;
            width: number;
            height: number;
        };
        result: ArrayBuffer;
    };
    readBackdrop: {
        params: {
            sim: SimHandle;
            columns: number;
            rows: number;
        };
        result: Backdrop;
    };
    refreshFrame: {
        params: {
            sim: SimHandle;
        };
        result: void;
    };
    readFrame: {
        params: {
            sim: SimHandle;
        };
        result: Frame & {
            previous: Frame[];
        };
    };
    /**
     * Mirrors every presented frame to the DOM thread for a video recording, as a canvas transferred to a worker cannot
     * be captured. The frames come as the uncomposited transport buffers attachCanvas hands a main-thread renderer.
     * Additional to live rendering; no `tap` stops it and drops the buffers.
     */
    setVideoTap: {
        params: {
            sim: SimHandle;
            tap?: {
                presentation: number;
                buffers: ArrayBuffer[];
            };
        };
        result: void;
    };
    /**
     * While held, the worker leaves the page's picture as it is: no upload, no draw, no transfer to a DOM-thread
     * renderer. For a taker that shows every frame in the page's place (the headset, where nobody sees the page);
     * screenshots are redrawn from the frame instead. Releasing it shows the current frame on the page again.
     */
    holdPage: {
        params: {
            sim: SimHandle;
            held: boolean;
        };
        result: void;
    };
    readMemory: {
        params: {
            sim: SimHandle;
            address: number;
            length: number;
        };
        result: ArrayBuffer;
    };
    writeMemory: {
        params: {
            sim: SimHandle;
            address: number;
            data: ArrayBuffer;
        };
        result: void;
    };
    readRegisters: {
        params: {
            sim: SimHandle;
        };
        result: Registers;
    };
    disassemble: {
        params: {
            sim: SimHandle;
            address: number;
            count: number;
            before?: number;
        };
        result: DisassemblyLine[];
    };
    /**
     * The complete set, as the worker keeps no identity per breakpoint; an empty list disarms everything and takes the
     * per-instruction callback off the core. Costs about a sixth of the emulation while armed (tests/breakpoint-probe.mjs).
     * The core reports every instruction before it executes and lets the callback refuse it, so a stop lands on it.
     */
    setBreakpoints: {
        params: {
            sim: SimHandle;
            addresses: number[];
        };
        result: void;
    };
    stepInstruction: {
        params: {
            sim: SimHandle;
        };
        result: void;
    };
    runTo: {
        params: {
            sim: SimHandle;
            address: number;
        };
        result: void;
    };
    setTerminalCapture: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    setLinkCapture: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    setPointerWatch: {
        params: {
            sim: SimHandle;
            address: number;
        };
        result: void;
    };
    /**
     * Stops the machine after the next CPU write into any of these ranges, once (the stop takes the ranges with it); the
     * stop says which instruction wrote (StopWrite). Not the VB Color DMA. VIP and VCU addresses are decoded as those do,
     * 512 KiB and 1 MiB repeated across their regions, so any mirror hits; the character memory's second window at
     * 0x00078000 is a range of its own. Not while two players are linked, like breakpoints.
     */
    setWriteStop: {
        params: {
            sim: SimHandle;
            ranges: {
                address: number;
                length: number;
            }[];
        };
        result: void;
    };
    setPixelOrigins: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    readPixelOrigins: {
        params: {
            sim: SimHandle;
        };
        result: ArrayBuffer;
    };
    streamPixelOrigins: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    setCheats: {
        params: {
            sim: SimHandle;
            codes: VbCheatWrite[];
        };
        result: void;
    };
    /**
     * The write-side twin of queueKeys: setCheats and writeMemory land whenever their message arrives, so a cheat switched
     * on a few frames apart in two linked windows runs two different games, reported as a desync without a cause. A linked
     * session books the write against a frame both windows can still reach. Refused for a frame already emulated.
     */
    queueEdits: {
        params: {
            sim: SimHandle;
            frame: number;
            edits: ScheduledEdit[];
        };
        result: void;
    };
    setEsSoundCapture: {
        params: {
            sim: SimHandle;
            enabled: boolean;
        };
        result: void;
    };
    /**
     * Reports the save region's reads as well as writes, as a list showing only writes would not say whether a game found
     * what it saved; instruction fetches are reported separately, so reads are real loads. The directions are separate
     * because reading may happen every frame (Wario Land does), so writes alone install one callback. Both false is off.
     */
    setSramCapture: {
        params: {
            sim: SimHandle;
            writes: boolean;
            reads: boolean;
        };
        result: void;
    };
    /**
     * The VSU as it stands: VB_VSU_MAP_BYTES from VB_VSU_BASE (waveform banks, modulation table, six channel register
     * blocks). The range cannot be read, on this core as on the machine (see VB_VSU_BASE), so the worker composes it from
     * the core's decoded VSU copy in the simulation struct: a channel playing since before a panel opened reads as playing,
     * one switched off by its interval as off. Where the core holds both what a channel was given and what it does (an
     * envelope's level, a swept frequency), the latter comes back. See worker/vb-vsu-layout.ts, which throws through this
     * call if it cannot find the layout.
     */
    readVsu: {
        params: {
            sim: SimHandle;
        };
        result: VsuReading;
    };
    /**
     * Mutes channels in the mixer, not the game: `channels` is a bitmask, bit n for channel n, zero unmutes all (a closing
     * panel sends that). The game keeps writing the VSU, and VsuReading still carries a muted channel's stereo levels.
     * Free when nothing is muted, otherwise two bytes per muted channel per frame; dropped with the simulation, so a reset
     * machine comes back at full voice.
     */
    setVsuMutes: {
        params: {
            sim: SimHandle;
            channels: number;
        };
        result: void;
    };
    raLoginPassword: {
        params: {
            username: string;
            password: string;
        };
        result: VesRaUser;
    };
    raLoginToken: {
        params: {
            username: string;
            token: string;
        };
        result: VesRaUser;
    };
    raLogout: {
        params: Record<string, never>;
        result: void;
    };
    raLoadGame: {
        params: {
            sim: SimHandle;
            hash: string;
        };
        result: void;
    };
    raUnloadGame: {
        params: Record<string, never>;
        result: void;
    };
    raProvideResponse: {
        params: {
            requestId: number;
            status: number;
            body: string;
        };
        result: void;
    };
    raReset: {
        params: Record<string, never>;
        result: void;
    };
    raSetHardcore: {
        params: {
            enabled: boolean;
        };
        result: void;
    };
    raFetchLeaderboardEntries: {
        params: {
            leaderboardId: number;
            firstEntry: number;
            count: number;
            aroundUser: boolean;
        };
        result: VesRaLeaderboardEntries;
    };
}
export interface VesRaUser {
    username: string;
    displayName: string;
    token: string;
    score: number;
    softcoreScore: number;
    avatarUrl?: string;
}
export interface RaGame {
    id: number;
    title: string;
    iconUrl: string;
    achievementCount: number;
    pointsTotal: number;
}
export interface RaAchievement {
    id: number;
    title: string;
    description: string;
    points: number;
    badgeUrl: string;
    state: 'locked' | 'unlocked' | 'unsupported';
    unlockedHardcore: boolean;
    bucket: number;
    measured?: {
        percent: number;
        display: string;
    };
    type?: 'missable' | 'progression' | 'win';
    rarity?: number;
    rarityHardcore?: number;
    unlockTime?: number;
}
export interface RaLeaderboard {
    id: number;
    title: string;
    description: string;
    format: 'time' | 'score' | 'value';
    lowerIsBetter: boolean;
    state: 'inactive' | 'active' | 'tracking' | 'unsupported';
    value?: string;
}
export interface VesRaLeaderboardEntry {
    rank: number;
    user: string;
    display: string;
    submitted: number;
    avatarUrl?: string;
}
export interface VesRaLeaderboardEntries {
    entries: VesRaLeaderboardEntry[];
    total: number;
    userIndex: number;
}
export type VesRaEvent = {
    kind: 'serverCall';
    requestId: number;
    method: 'GET' | 'POST';
    url: string;
    body?: string;
    contentType?: string;
} | {
    kind: 'gameLoaded';
    game: RaGame | undefined;
    reason?: string;
} | {
    kind: 'achievements';
    achievements: RaAchievement[];
} | {
    kind: 'unlocked';
    id: number;
    title: string;
    description: string;
    points: number;
    badgeUrl: string;
    hardcore: boolean;
} | {
    kind: 'challengeIndicator';
    id: number;
    show: boolean;
    badgeUrl: string;
} | {
    kind: 'connection';
    online: boolean;
} | {
    kind: 'leaderboards';
    leaderboards: RaLeaderboard[];
    reason?: string;
} | {
    kind: 'leaderboardAttempt';
    id: number;
    title: string;
    description: string;
    state: 'started' | 'failed' | 'submitted';
    value?: string;
} | {
    kind: 'leaderboardTracker';
    trackerId: number;
    show: boolean;
    display: string;
} | {
    kind: 'leaderboardScoreboard';
    id: number;
    submittedScore: string;
    bestScore: string;
    rank: number;
    total: number;
    topEntries: {
        rank: number;
        user: string;
        score: string;
    }[];
} | {
    kind: 'engineUnavailable';
    reason: string;
};
export interface VbCheatWrite {
    address: number;
    value: number;
    bytes: number;
}
export type ScheduledEdit = {
    kind: 'cheats';
    codes: VbCheatWrite[];
} | {
    kind: 'memory';
    address: number;
    bytes: number[];
};
export type LinkJournalEntry = {
    frame: number;
    kind: 'reset';
    cartRam: number;
} | {
    frame: number;
    kind: 'keys';
    keys: number;
} | {
    frame: number;
    kind: 'refusedKeys';
    keys: number;
} | {
    frame: number;
    kind: 'edits';
    edits: ScheduledEdit[];
} | {
    frame: number;
    kind: 'digest';
    digest: number;
} | {
    frame: number;
    kind: 'stalled';
    pc: number;
};
export interface Registers {
    pc: number;
    program: number[];
    system: Record<string, number>;
}
export interface DisassemblyLine {
    address: number;
    code: number[];
    isPC: boolean;
    mnemonic: string;
    operands: string[];
}
export type CommandName = keyof CoreCommands;
export type Params<K extends CommandName> = CoreCommands[K]['params'];
export type Result<K extends CommandName> = CoreCommands[K]['result'];
export interface Request<K extends CommandName = CommandName> {
    id: number;
    command: K;
    params: Params<K>;
}
export interface Response {
    id: number;
    result?: unknown;
    error?: string;
}
/**
 * One reading of the VSU. The map is VB_VSU_MAP_BYTES from VB_VSU_BASE in the hardware's own layout, so
 * emulator-vsu-memory.ts decodes it without knowing its source. The peaks, of the machine's last one-frame buffer
 * before the master volume, are what the six channels actually came to, which the registers cannot say. Copied rather
 * than transferred: 1,412 bytes ten times a second.
 */
export interface VsuReading {
    map: ArrayBuffer;
    peakLeft: number;
    peakRight: number;
}
export interface SramAccess {
    address: number;
    value: number;
    write: boolean;
    type: number;
    pc: number;
}
/**
 * What crosses the wire instead of SramAccess. A game saves in a loop, one instruction walking an address, and sending
 * thousands of objects a tick costs more structured cloning than the emulation (a game reading its save every frame,
 * like Wario Land, stalls the interface). So runs are gathered in the worker and arrive as one object and a byte
 * array; nothing is lost, each byte went to address plus its index times stride.
 */
export interface SramRun {
    address: number;
    stride: number;
    values: Uint8Array;
    write: boolean;
    type: number;
    pc: number;
}
export declare const MAX_SRAM_RUNS = 512;
export declare const MAX_SRAM_RUN_BYTES = 8192;
export declare const MAX_SRAM_STRIDE = 4;
export interface Speed {
    framesPerSecond: number;
    ratio: number;
    requested: number;
    load: number;
}
export interface Events {
    error: {
        message: string;
    };
    frame: VideoFrame;
    terminal: {
        sim: SimHandle;
        text: string;
    };
    link: {
        sim: SimHandle;
        bytes: number[];
    };
    pointerWrite: {
        sim: SimHandle;
        address: number;
        values: number[];
    };
    esSound: {
        sim: SimHandle;
        commands: number[];
    };
    sram: {
        sim: SimHandle;
        runs: SramRun[];
    };
    speed: Speed;
    retroAchievements: {
        events: VesRaEvent[];
    };
    digest: {
        sim: SimHandle;
        frame: number;
        digest: number;
    };
    progress: {
        frame: number;
    };
    awaitingInput: {
        waiting: boolean;
        frame: number;
        sims: SimHandle[];
    };
    /**
     * The core stopped advancing and emulation was suspended. Not an error: the core can return from Emulate without
     * spending its clock budget over and over (a program that has run off into memory it cannot execute), and the loops
     * draining the budget would spin forever. A reset is the way out, which the chrome can say.
     */
    stalled: {
        frames: number;
    };
    pixelOrigins: {
        sim: SimHandle;
        runs: ArrayBuffer;
    };
    stopped: {
        sim: SimHandle;
        address: number;
        reason: StopReason;
        write?: StopWrite;
    };
}
export interface StopWrite {
    pc: number;
    address: number;
    value: number;
    size: number;
}
export declare enum StopReason {
    BREAKPOINT = "breakpoint",
    STEP = "step",
    CURSOR = "cursor",
    WRITE = "write"
}
export type VbEvent = {
    [K in keyof Events]: {
        event: K;
        payload: Events[K];
    };
}[keyof Events];
export type Outbound = Response | VbEvent;
export declare function isVbEvent(message: Outbound): message is VbEvent;
export interface Bootstrap {
    audioPort: MessagePort;
}
export interface VideoFrameReturn {
    videoFrame: {
        sim: SimHandle;
        presentation: number;
        pixels: ArrayBuffer;
    };
}
//# sourceMappingURL=vb-protocol.d.ts.map