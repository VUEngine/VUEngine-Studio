/**
 * Making a colorization for a game nobody has colorized.
 *
 * The four that ship with VUEPort were written by hand against one game each:
 * native code that knows when the game changes scene, which sprite is whose,
 * what a health bar looks like. Nothing here does any of that. What it does is
 * the part that is the same for every Virtual Boy cartridge — get VB Color
 * switched on before the game's first instruction, and put 256 editable
 * palettes somewhere the hardware reads them — and then get out of the way.
 *
 * The compiler is vendored in `vb-color/generic`; see `VENDORED.md` beside it
 * for what it emits and why the ROM comes out twice its size. This module is
 * the seam: it decides whether a ROM can take one, dresses the result up as
 * the format-2 document the rest of VUEPort already knows how to edit, build
 * and export, and encodes the ROM patch that carries it.
 *
 * The result is a starting point and is meant to read as one. A generic
 * bootstrap leaves Color Attribute RAM cleared, so a legacy game goes on
 * selecting BG palettes 0–3 and OBJ palettes 0–3 through the two-bit
 * selectors it always used — eight palettes of the 256, and the rest loaded,
 * editable and selected by nothing. Which of the other 248 belongs to which
 * pixel is the game-specific question, and answering it is what a hand-written
 * patch is for. The panel says so before it makes one.
 *
 * DOM-free, like `emulator-vb-color.ts`, so `tests/vb-color-create-probe.mjs`
 * can run the whole path.
 */
import { VesColorPatch } from './emulator-color-patches';
import { VbcPatchDocument } from './emulator-vb-color';
/** Who a created colorization is by, in the places a shipped one names its author. */
export declare const VB_COLOR_CREATED_AUTHOR = "VUEPort";
/** The version string a created colorization carries — the compiler's, not VUEPort's. */
export declare const VB_COLOR_CREATED_VERSION = "generic bootstrap v1";
/**
 * The palettes a legacy game selects on its own once the bootstrap has run.
 *
 * The two-bit GPLTS and JPLTS selectors it already uses, against Color
 * Attribute RAM the bootstrap cleared: BG 0–3, and the first four OBJ
 * palettes, which are global ids 128–131.
 */
export declare function vbColorGenericSelectsPalette(paletteId: number): boolean;
/** The catalog id a colorization created for this ROM is filed under. */
export declare function createdColorPatchId(romId: string): string;
/** Whether a catalog id names a colorization somebody made here. */
export declare function isCreatedColorPatchId(id: string): boolean;
/**
 * Why this ROM cannot take a generic colorization, or undefined if it can.
 *
 * Asked before the button is offered rather than after it is pressed, so the
 * refusal can sit in a tooltip instead of arriving as an error. The compiler's
 * own codes, said in words somebody can act on — the sizes are its limits, not
 * VUEPort's: mirror expansion doubles the image, and VB Color addresses 16 MiB.
 */
export declare function genericColorRefusal(source: Uint8Array | undefined): string | undefined;
/**
 * Compile a colorization for a ROM that has none.
 *
 * The compiler's document, with the editor metadata above laid over it: the
 * palettes and the BPS are its, and both are what every other path in VUEPort
 * reads. Nothing about the result is special-cased downstream — it carries the
 * palette ABI a shipped patch carries, so it is edited, built, live-previewed
 * and exported by the same code.
 *
 * The source ROM's SHA-256 goes into the patch's metadata, which is what stops
 * a document from being applied to a different dump of the same game later.
 */
export declare function createGenericColorDocument(source: Uint8Array, options: {
    name: string;
    id?: string;
}): Promise<VbcPatchDocument>;
/**
 * The catalog entry a created colorization is shown under.
 *
 * The same shape a shipped one has, so the info page, the switch and the
 * per-game settings need to know nothing about where it came from — only
 * `author` and `version` say, which is where somebody would look. Filed as
 * `wip` because that is what it is: eight palettes doing something and 248
 * waiting for a patch that knows the game.
 */
export declare function createdColorPatchEntry(romId: string, game: string): VesColorPatch;
/**
 * The ROM patch that carries a built colorization to the patch store.
 *
 * {@link createBpsPatch} encodes every byte that differs as a literal, which
 * is right for a colorization that changes a ROM in place and wrong for one
 * that doubles it: the whole upper half differs from a source that has no
 * upper half, so a two-megabyte game would produce a two-megabyte patch — and
 * produce it again behind every color somebody changes. The compiler's own
 * encoder says the upper half as a copy of the lower one with the bootstrap,
 * the palette table and the header written over it, which is a few kilobytes
 * whatever the game's size.
 *
 * It only accepts that exact shape, so anything else — every shipped
 * colorization — falls back to the general encoder, which is what it was
 * always given.
 */
export declare function createColorRomPatch(source: Uint8Array, target: Uint8Array): Uint8Array;
//# sourceMappingURL=emulator-vb-color-create.d.ts.map