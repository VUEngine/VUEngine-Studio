/**
 * A stand-in for Theia's nls with the same nls.localize(key, default, ...args). VES installs Theia's implementation
 * at startup (setLocalization in the frontend module); standalone, the default returns the English default.
 * There is no localizeByDefault, as a standalone host has no VS Code translation table; such strings are keyed
 * under vueport/general/... instead.
 * The name is load-bearing: `yarn nls-extract` matches the callee text `nls.localize` exactly, so renaming it would
 * empty i18n/nls.json on the next extraction.
 * setLocalization runs after every imported module was evaluated, so strings in module-level constants stay English.
 * Translate a string when it is shown, not when its module loads (see EMULATOR_PANEL_LABELS)
 */
export type FormatType = string | number | boolean | undefined;
export type LocalizeFn = (key: string, defaultValue: string, ...args: FormatType[]) => string;
export declare namespace nls {
    function localize(key: string, defaultValue: string, ...args: FormatType[]): string;
}
export interface Translations {
    [segment: string]: string | Translations;
}
export declare function flattenTranslations(translations: Translations, prefix?: string): Record<string, string>;
export declare function useTranslations(translations: Translations): void;
export declare function setLocalization(localize: LocalizeFn): void;
//# sourceMappingURL=emulator-nls.d.ts.map