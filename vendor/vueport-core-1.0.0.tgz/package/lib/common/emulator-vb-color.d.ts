/**
 * VB Color patch documents — format 2 — as the emulator reads them.
 *
 * A document is two things: the palettes a color editor may change, and one
 * compiled BPS carrying everything else — hooks, native code, and every
 * decision about which palette is shown when (`VBC_PATCH_FORMAT.md`). VUEPort
 * interprets none of the second. It applies the BPS, writes the palettes into
 * the table the BPS's own metadata points at, and runs the ROM that comes out.
 * The exporter vendored in `vb-color/vbc-patch-export.ts` does both of those;
 * this module is what sits between it and the editor — reading a document,
 * laying a person's edits over it, finding the palette table a live edit is
 * written into, and the color arithmetic a picker needs.
 *
 * DOM-free on purpose, so the whole path can be exercised from
 * `tests/vb-color-probe.mjs`.
 */
import { VbcPalette, VbcPatchDocument } from './vb-color/vbc-patch-export';
export type { VbcPalette, VbcPatchDocument };
/** A palette is four colors, and only four. */
export declare const VB_COLOR_COLORS_PER_PALETTE = 4;
export declare class VbColorError extends Error {
    constructor(message: string);
}
/** `#RRGGBB` to the packed 15-bit word the hardware stores: `r | g << 5 | b << 10`. */
export declare function parseRgb555(color: string): number;
/**
 * The packed word as `#RRGGBB`.
 *
 * The *round-trip* color, which is the one worth showing: a picker offers
 * 24-bit colors and the hardware has 15, so what somebody chose and what they
 * will see are usually not the same value.
 */
export declare function rgb555ToHex(value: number): string;
/**
 * What the hardware will actually display for a requested color.
 *
 * Stable under the exporter: a snapped color converts back to exactly the
 * word it was snapped from, so storing snapped colors means the ROM holds
 * what the swatch showed.
 */
export declare function snapToRgb555(color: string): string;
/** Four colors as a palette table entry or a Color RAM palette: four little-endian words. */
export declare function paletteBytes(colors: readonly string[]): Uint8Array;
/**
 * Whether a parsed JSON value is a format-2 patch document, as far as the
 * emulator needs to know before handing it to the exporter.
 *
 * The shape and nothing more. What the exporter checks — the BPS's own
 * checksums, its metadata, that every palette has a place in the table — it
 * checks better than a second copy of the rules would, and says why when it
 * refuses.
 */
export declare function isVbcPatchDocument(value: unknown): value is VbcPatchDocument;
/** The embedded BPS as bytes. */
export declare function vbcPatchBytes(document: VbcPatchDocument): Uint8Array;
/**
 * Whether a BPS says where its palettes live — the palette ABI.
 *
 * Without it the palettes in the JSON describe the colorization and change
 * nothing: its colors are compiled into native code nobody outside it can
 * find. Such a patch still runs, exactly as shipped, and cannot be edited.
 * Zero Racers dev29 is one, carried over from before the ABI existed.
 */
export declare function vbcPaletteAbiPresent(patch: Uint8Array): boolean;
/** Where each color set lives in the patched ROM, as the BPS's palette ABI says. */
export interface VbColorPaletteTable {
    /** The table's offset in the ROM. */
    offset: number;
    /** Each set's entry in it, by {@link vbColorOverrideKey}. Entries are eight bytes. */
    index: Map<string, number>;
}
/**
 * The palette table a BPS's metadata describes, or undefined for a patch
 * without the palette ABI.
 *
 * What the live path writes into: the colorization's native code copies its
 * colors out of this table, in the running ROM, whenever it sets a palette
 * up. Checked only as far as the live path relies on it; the exporter is what
 * refuses a patch whose metadata does not add up.
 */
export declare function vbcPaletteTable(patch: Uint8Array): VbColorPaletteTable | undefined;
/** A scene: a filter over the objects, and nothing else. It never reaches the ROM. */
export interface VbColorScene {
    id: string;
    name: string;
}
/** One thing in the game that has colors — the editor's unit of work. */
export interface VbColorObject {
    id: string;
    name: string;
    sceneId?: string;
    /** The palettes it owns, in the order the document lists them. */
    palettes: number[];
}
/**
 * The document's scenes, if it has any.
 *
 * Not part of format 2 as the specification stands, but documents have
 * carried them — at the top level, or under `editor` — and the editor uses
 * them when they are there. Read loosely: a malformed scene is left out
 * rather than refused, since none of this reaches the ROM.
 */
export declare function vbcScenes(document: VbcPatchDocument): VbColorScene[];
/**
 * The document's objects, or one per palette for a document without any.
 *
 * An object names the palettes it owns through entries of type `palette`;
 * anything else an entry says — a mapping, an effect — is how an older format
 * decided when a palette applied, which is the BPS's business now. A document
 * with no objects still gets a list to work from: each palette as its own.
 */
export declare function vbcObjects(document: VbcPatchDocument): VbColorObject[];
/**
 * A person's color edits, kept apart from the document they edit.
 *
 * Sparse, keyed by {@link vbColorOverrideKey}, four `#RRGGBB` values each.
 * Separate rather than written back into the document so that a later release
 * of a patch can ship corrected colors without discarding somebody's work —
 * the palette ids are the stable half of the palette ABI, which is what makes
 * carrying edits across releases safe.
 */
export type VbColorOverrides = Record<string, string[]>;
/** Where an edit is filed: the palette id, and the variant after a slash. */
export declare function vbColorOverrideKey(paletteId: number, variant?: string): string;
/**
 * Keep the edits that are usable against this document, and drop the rest.
 *
 * Stored settings can be hand-edited, can come from an older build, and can
 * name palettes a newer release of the patch no longer has. One bad entry
 * should cost that entry rather than every color somebody chose; what
 * survives is four snapped colors for a palette the document defines.
 */
export declare function sanitizeOverrides(overrides: unknown, document: VbcPatchDocument): VbColorOverrides;
/**
 * What a person has renamed a colorization's palettes to, by palette id.
 *
 * Names and colors are edited in the same panel and kept the same way — apart
 * from the document, so a later release of a shipped colorization can arrive
 * with its own corrections without discarding either. They are two records
 * rather than one because they are two shapes, and because "put the colors
 * back" and "put the names back" are different things to want.
 *
 * A name reaches nothing but the editor. The compiled patch addresses a palette
 * by its id, which is the half of the palette ABI that never moves; what it is
 * called is for whoever is looking at it.
 */
export type VbColorPaletteNames = Record<string, string>;
/** How long a palette name may be. Long enough to say what it is, short enough to show. */
export declare const VB_COLOR_MAX_PALETTE_NAME = 60;
/**
 * Keep the renames that are usable against this document, and drop the rest.
 *
 * {@link sanitizeOverrides}'s reasoning, for the same reasons: stored settings
 * can be hand-edited or name palettes a newer release no longer has, and one
 * bad entry should cost that entry. A name that is only whitespace is the
 * absence of a name rather than a name — it is what the editor writes when
 * somebody empties the field to get the shipped one back.
 */
export declare function sanitizeNames(names: unknown, document: VbcPatchDocument): VbColorPaletteNames;
/** One palette as the editor shows it, with a person's edits laid over it. */
export interface VbColorPaletteView {
    id: number;
    name: string;
    channel: 'bg' | 'obj';
    colors: string[];
    /** The document's other color sets for this palette, in its order. */
    variants: {
        name: string;
        colors: string[];
    }[];
}
/** The document's palettes, in its order, with the edits over them. */
export declare function resolvePalettes(document: VbcPatchDocument, overrides?: VbColorOverrides, names?: VbColorPaletteNames): VbColorPaletteView[];
/**
 * The document with the edits written into its palettes.
 *
 * A copy, deep enough that nothing done to it reaches the document the store
 * holds. It is both what an export saves and what a build hands the exporter,
 * so the two can never disagree about a color.
 *
 * Renames come along when they are given, which an export and a save want and
 * a build has no use for — a name reaches no part of the ROM. An object that
 * owns exactly one palette is renamed with it: for a document with no objects
 * of its own, and for one generated here, an object *is* a palette, and a list
 * row that went on saying "BG Palette 37" after the palette was renamed would
 * be showing the same thing under two names.
 */
export declare function applyOverrides(document: VbcPatchDocument, overrides: VbColorOverrides, names?: VbColorPaletteNames): VbcPatchDocument;
/**
 * The ROM a document makes of a source ROM, with a person's edits in it.
 *
 * The exporter's own flow, unchanged: apply the BPS, check it against both
 * ROMs, overwrite the palette table entries its metadata names. A patch with
 * no palette ABI is applied as it is and the edits are ignored — there is
 * nowhere to write them.
 *
 * Asynchronous because the exporter checks SHA-256s as well as the BPS's CRCs,
 * and a browser offers SHA-256 only through `crypto.subtle` — which it offers
 * only to secure pages. Refused with that reason rather than failing somewhere
 * inside the exporter with a message about `undefined`.
 */
export declare function buildColorizedRom(source: Uint8Array, document: VbcPatchDocument, overrides: VbColorOverrides): Promise<Uint8Array>;
//# sourceMappingURL=emulator-vb-color.d.ts.map