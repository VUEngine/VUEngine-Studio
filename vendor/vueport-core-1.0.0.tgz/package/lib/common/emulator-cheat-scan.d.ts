/**
 * Searching memory for the address behind a number on screen.
 *
 * The Action Replay loop, and the half of the Cheats panel that was missing: a
 * cheat is a write to an address (see `emulator-cheats.ts`), and until now
 * VUEPort could only apply one somebody else had already worked out. This is
 * how the address is found in the first place.
 *
 * The method is elimination rather than insight. Take a copy of memory; say
 * something about the value being looked for; keep every address that agrees.
 * Play until the number changes; say what it did; keep every address that
 * agrees with that too. Repeat, and the survivors converge on the one the game
 * actually keeps its lives, its rings or its health in.
 *
 * Two kinds of question can be asked, which is what makes this usable on a game
 * that shows a bar rather than a number:
 *
 *   - against a value the player typed, when the number is on screen to read;
 *   - against what the address held last time, when it is not — "it went down"
 *     is a fact about a health bar even when nobody knows what it went down
 *     *from*.
 *
 * The second kind is why a first pass may start with every address a candidate:
 * with no value to match, nothing has been ruled out yet, and the first real
 * narrowing happens on the pass after it.
 *
 * Everything here is pure — snapshots in, candidate offsets out — so the search
 * can be reasoned about, and tested, without an emulator or a browser.
 */
/**
 * How to read the bytes at an address.
 *
 * The Virtual Boy is little-endian, so a halfword at offset n is
 * `bytes[n] | bytes[n+1] << 8`, and the signed types are the same bytes read as
 * two's complement. Both spellings are offered because a game's counter is
 * usually unsigned and its coordinates usually are not, and searching for -1 in
 * a u16 finds nothing.
 */
export declare enum ScanDataType {
    U8 = "u8",
    S8 = "s8",
    U16 = "u16",
    S16 = "s16",
    U32 = "u32",
    S32 = "s32"
}
/** The order they are offered in, narrowest first. */
export declare const SCAN_DATA_TYPES: ScanDataType[];
/**
 * What is being asked of each candidate.
 *
 * The first four compare against a number the player gave; the last four
 * compare against what the same address held at the previous pass, and need no
 * number at all.
 */
export type ScanOperator = 'eq' | 'ne' | 'gt' | 'lt' | 'changed' | 'unchanged' | 'increased' | 'decreased';
export declare const SCAN_OPERATORS: ScanOperator[];
/**
 * Whether this operator needs a number typed in beside it.
 *
 * The panel asks so it can disable the value box rather than ignore what is in
 * it: a box that accepts a number nothing reads is a box that lies.
 */
export declare function scanOperatorNeedsValue(op: ScanOperator): boolean;
/** How wide a value of this type is. */
export declare function scanValueBytes(type: ScanDataType): 1 | 2 | 4;
/** Whether this type reads as two's complement. */
export declare function scanTypeIsSigned(type: ScanDataType): boolean;
/**
 * The value at an offset, as this type reads it.
 *
 * Little-endian, and sign-extended for the signed types, so what comes back is
 * the number the program running on the machine would see. An offset with fewer
 * bytes after it than the type needs reads as 0 rather than throwing: the
 * callers below never generate one, and a snapshot truncated by something else
 * should not take the panel down.
 */
export declare function readScanValue(bytes: Uint8Array, offset: number, type: ScanDataType): number;
/**
 * The first pass: every offset in the snapshot that answers the question.
 *
 * A relative operator has nothing to be relative to yet, so it keeps
 * everything — that is what "I do not know what the value is" means, and the
 * narrowing starts with `scanNext` once the number has been made to move.
 */
export declare function scanFirst(current: Uint8Array, type: ScanDataType, op: ScanOperator, value?: number): Uint32Array;
/**
 * A later pass: the candidates that still answer the question.
 *
 * `previous` is the snapshot the last pass was made against, so "decreased"
 * means decreased since then rather than since the machine started. Candidates
 * are only ever removed, which is what makes the search converge — and why the
 * panel keeps the sets it has been through, so a pass that narrowed too far can
 * be taken back.
 */
export declare function scanNext(candidates: Uint32Array, previous: Uint8Array, current: Uint8Array, type: ScanDataType, op: ScanOperator, value?: number): Uint32Array;
//# sourceMappingURL=emulator-cheat-scan.d.ts.map