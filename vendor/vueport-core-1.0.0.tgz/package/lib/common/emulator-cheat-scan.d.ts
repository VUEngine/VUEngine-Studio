/**
 * Searching memory for the address behind a number on screen, the Action Replay loop: snapshot memory, keep every
 * address that matches a value the player typed or a change since the last pass ("it went down" works for a health
 * bar with no number), and repeat until the survivors converge. A relative first pass keeps every address, as
 * nothing has been ruled out yet. Pure, snapshots in and candidate offsets out, so it is testable without an emulator
 */
export declare enum ScanDataType {
    U8 = "u8",
    S8 = "s8",
    U16 = "u16",
    S16 = "s16",
    U32 = "u32",
    S32 = "s32"
}
export declare const SCAN_DATA_TYPES: ScanDataType[];
export type ScanOperator = 'eq' | 'ne' | 'gt' | 'lt' | 'changed' | 'unchanged' | 'increased' | 'decreased';
export declare const SCAN_OPERATORS: ScanOperator[];
export declare function scanOperatorNeedsValue(op: ScanOperator): boolean;
export declare function scanValueBytes(type: ScanDataType): 1 | 2 | 4;
export declare function scanTypeIsSigned(type: ScanDataType): boolean;
export declare function readScanValue(bytes: Uint8Array, offset: number, type: ScanDataType): number;
export declare function scanFirst(current: Uint8Array, type: ScanDataType, op: ScanOperator, value?: number): Uint32Array;
export declare function scanNext(candidates: Uint32Array, previous: Uint8Array, current: Uint8Array, type: ScanDataType, op: ScanOperator, value?: number): Uint32Array;
//# sourceMappingURL=emulator-cheat-scan.d.ts.map