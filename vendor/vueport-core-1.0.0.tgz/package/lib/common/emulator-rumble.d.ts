import { Emitter, Event } from './emulator-events';
export interface RumbleCommand {
    bytes: number[];
    label: string;
    unknown?: boolean;
    at: number;
}
export interface RumbleState {
    effect?: number;
    frequency?: number;
    playing?: boolean;
    playingSince?: number;
    plays?: number;
    chain?: number;
}
export declare const RUMBLE_EFFECT_MAX_MS = 1000;
export declare function isRumblePlaying(state: RumbleState, now?: number): boolean;
export interface EmulatedRumbleSpec {
    address: number;
    name?: string;
}
export declare function builtInRumbleEffects(): string[];
/**
 * How hard and how long one of the 123 built-in effects pulls. The lengths are Immersion's, held in the haptic driver's
 * ROM and published nowhere (TI's datasheets name the effects only), so they were measured:
 * packages/web/tools/rumble-durations.html plays every effect into a microphone and times the sound, and
 * rumble-effect-durations.json beside it is the run these numbers come from. The 750 ms and 1000 ms alerts measured
 * 789 and 1037, about 38 ms of motor run-on, which is kept, as the player feels the vibration, not the drive.
 * Names mislead: Strong Buzz is a quarter second, Smooth Hum stops after half a second, and Short/Medium/Long in the
 * ramp names say nothing about length (Ramp Down Long Smooth 1 and Short Smooth 1 are both about 320 ms).
 */
export interface RumbleEffectShape {
    amplitude: number;
    rampTo?: number;
    ms?: number;
}
/**
 * The 123 effects, as shapes rather than as words.
 *
 * In step with `builtInRumbleEffects` above, entry for entry — the comments
 * carry the same numbers and family names, and `rumble-effects-probe` reads
 * the English names and fails if the two ever disagree about an amplitude.
 * Written out rather than derived from the names at run time: those names are
 * translated, and a program that reads its own interface text is a program
 * that breaks in German.
 */
export declare const RUMBLE_EFFECT_SHAPES: readonly RumbleEffectShape[];
export declare function rumbleEffectShape(effect: number | undefined): RumbleEffectShape | undefined;
export declare function rumbleEffectMs(shape: RumbleEffectShape | undefined): number;
export declare function rumbleEffectAmplitudeAt(shape: RumbleEffectShape | undefined, progress: number): number;
export declare function getRumbleEffectName(effect: number): string;
export interface VueportRumblePack {
    readonly connected: boolean;
    readonly canConnect?: boolean;
    readonly deviceName: string | undefined;
    readonly deviceIds: {
        vendor?: number;
        product?: number;
    } | undefined;
    readonly onDidChangeConnected: Event<void>;
    detect(): Promise<void>;
    forwarding: boolean;
    linkPortInUse?: boolean;
    emulatedSpec: EmulatedRumbleSpec | undefined;
    readonly emulatedCommands: RumbleCommand[];
    readonly emulatedRumbleState: RumbleState;
    readonly emulatedByteCount: number;
    readonly lastReply: string | undefined;
    readonly droppedCommands?: number;
    clearEmulatedTraffic(): void;
    sendByte(byte: number): Promise<void>;
    stop?(): Promise<void>;
}
export declare const NO_RUMBLE_PACK: VueportRumblePack;
export declare class DecodingRumblePack implements VueportRumblePack {
    protected readonly onDidChangeConnectedEmitter: Emitter<void>;
    readonly onDidChangeConnected: Event<void>;
    protected readonly decoder: RumbleStreamDecoder;
    protected commands: RumbleCommand[];
    protected bytes: number;
    forwarding: boolean;
    linkPortInUse: boolean;
    emulatedSpec: EmulatedRumbleSpec | undefined;
    get canConnect(): boolean;
    get connected(): boolean;
    get deviceName(): string | undefined;
    get deviceIds(): {
        vendor?: number;
        product?: number;
    } | undefined;
    get lastReply(): string | undefined;
    get emulatedCommands(): RumbleCommand[];
    get emulatedRumbleState(): RumbleState;
    get emulatedByteCount(): number;
    get droppedCommands(): number;
    detect(): Promise<void>;
    clearEmulatedTraffic(): void;
    sendByte(byte: number): Promise<void>;
    protected forward(_byte: number): Promise<void>;
}
export interface RumblePackDevice {
    name: string;
    vendor: number;
    product: number;
}
export declare const RUMBLE_PACK_IDS: readonly RumblePackDevice[];
export declare function rumblePackName(vendor?: number, product?: number): string | undefined;
export declare abstract class SerialRumblePack extends DecodingRumblePack {
    /**
     * In ms. The board is an ATmega32u4 with a 64-byte serial buffer, and every command becomes an I2C transaction with
     * the motor driver, so it drains far slower than a 115200-baud line fills it. Beyond eight commands back to back the
     * overflow lands mid-command, the parser waits for an eaten `>`, and the pack takes nothing until power-cycled.
     * Two hundred commands a second is far more than any game asks for (an effect is four or five).
     */
    protected static readonly WRITE_GAP_MS = 5;
    protected static readonly MAX_QUEUED = 32;
    protected current: RumblePackDevice | undefined;
    protected reply: string | undefined;
    protected replyBuffer: string;
    protected queue: string[];
    protected draining: Promise<void> | undefined;
    protected dropped: number;
    get droppedCommands(): number;
    get connected(): boolean;
    get deviceName(): string | undefined;
    get deviceIds(): {
        vendor?: number;
        product?: number;
    } | undefined;
    get lastReply(): string | undefined;
    protected abstract write(text: string): Promise<void>;
    /**
     * Angle brackets and no newline, the firmware's own framing, as VES has driven the hardware for years
     * (ves-rumble-pack-service.ts): a newline-terminated `VB 124` is no command at all, and the pack sits perfectly still
     * (see the `<VB nnn>` check in rumble-panel-probe). Queued, returning at once, as the caller is the emulator's link
     * port callback and holding it up would hold up the game.
     */
    protected send(command: string): Promise<void>;
    protected startDraining(): void;
    protected drain(): Promise<void>;
    abstract start(): Promise<void>;
    protected attached(device: RumblePackDevice): void;
    protected detached(): void;
    protected receive(text: string): void;
    protected forward(byte: number): Promise<void>;
    stop(): Promise<void>;
}
export declare const RUMBLE_CMD: {
    readonly STOP: 0;
    readonly MIN_EFFECT: 1;
    readonly MAX_EFFECT: 123;
    readonly PLAY: 124;
    readonly CHAIN_EFFECT_0: 128;
    readonly CHAIN_EFFECT_4: 132;
    readonly OVERDRIVE: 160;
    readonly SUSTAIN_POS: 161;
    readonly SUSTAIN_NEG: 162;
    readonly BREAK: 163;
    readonly WRITE_EFFECT_CHAIN: 176;
    readonly WRITE_EFFECT_LOOPS_CHAIN: 177;
    readonly EFFECT_CHAIN_END: 255;
};
export declare const RUMBLE_CMD_FREQUENCIES: Record<number, number>;
export declare class RumbleStreamDecoder {
    protected pending: number | undefined;
    state: RumbleState;
    reset(): void;
    push(byte: number): RumbleCommand | undefined;
    protected decode(byte: number, at: number): Omit<RumbleCommand, 'at'> | undefined;
    protected applyValue(command: number, value: number): Omit<RumbleCommand, 'at'>;
}
//# sourceMappingURL=emulator-rumble.d.ts.map