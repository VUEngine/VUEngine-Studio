/**
 * The rumble pack, as the emulator sees it.
 *
 * A copy of the parts of VES's rumble pack support that the emulator
 * needs — the protocol's shapes and its effect names — so that nothing under
 * `emulator/` reaches into `rumble-pack/`. VES keeps its own copy for
 * flashing firmware and for the effect editor; the two are expected to drift
 * apart rather than be kept in step, since one describes a device the emulator
 * pretends to be and the other drives a real one.
 */
import { Emitter, Event } from './emulator-events';
/** One decoded command from the byte stream a game sends. */
export interface RumbleCommand {
    bytes: number[];
    label: string;
    /** True for a byte that means nothing in this protocol. */
    unknown?: boolean;
    /** When it was decoded, as `Date.now()` reads. */
    at: number;
}
/** What the game has asked the pack to be doing. */
export interface RumbleState {
    effect?: number;
    frequency?: number;
    playing?: boolean;
    /**
     * When the last Play was decoded, as `Date.now()` reads.
     *
     * Kept because a game is not obliged to end what it started: the pack's
     * effects have a length of their own and stop on their own, so a Stop is
     * something a game sends when it wants one cut short. See
     * {@link isRumblePlaying}, which is where that turns into an answer.
     */
    playingSince?: number;
    /**
     * How many Plays have been decoded since the stream was reset.
     *
     * A counter as well as a timestamp because the two answer different
     * questions. {@link playingSince} says how far into an effect we are,
     * which is what the ceiling needs; this one says *which* Play it is, which
     * is what anybody acting once per effect needs — and two Plays that land
     * in the same millisecond share a timestamp but not a number.
     */
    plays?: number;
    chain?: number;
}
/**
 * How long an effect counts as playing when nothing says otherwise.
 *
 * Not the usual case any more: the 123 effects have measured lengths now (see
 * {@link RUMBLE_EFFECT_SHAPES}), and each is played for its own. This is what
 * is left over — the one effect built to run until it is stopped, and a Play
 * whose effect number the game never sent. Both need an end, and neither has
 * one of its own.
 */
export declare const RUMBLE_EFFECT_MAX_MS = 1000;
/**
 * Whether the motor should still be turning, as far as this side can tell.
 *
 * `state.playing` on its own only ever says what the game last asked for, and
 * a game that never sends a Stop would leave it true for the rest of the
 * session — the pack's effects end themselves, so a Stop is what a game sends
 * to cut one short rather than what ends it.
 *
 * How long the effect had is its own, and measured: a click is over in a tenth
 * of a second where an alert runs three quarters of one. See
 * {@link rumbleEffectMs}. The ceiling is what answers for the two cases with
 * no length — the buzz meant to be stopped, and a Play whose effect was never
 * chosen.
 *
 * `now` is a parameter so that a caller drawing several things in one pass
 * gets one answer for all of them, and so that a test can say when it is.
 */
export declare function isRumblePlaying(state: RumbleState, now?: number): boolean;
/** The address a game's rumble effect spec was found at. */
export interface EmulatedRumbleSpec {
    address: number;
    /** Only set when a symbol covers the address. */
    name?: string;
}
export declare function builtInRumbleEffects(): string[];
/**
 * What one of the 123 built-in effects does: how hard it pulls, and how long.
 *
 * The lengths are measured, not looked up. They are Immersion's, held in the
 * haptic driver's ROM and published by nobody — TI's datasheets print the
 * names and not one duration, and TI's own answer to the question is to
 * measure it. So they were: `packages/web/tools/rumble-durations.html` plays
 * every effect into a microphone and times the sound, and
 * `rumble-effect-durations.json` beside it is the run these numbers come from.
 *
 * Two of the 123 carry their length in their name, which is what makes the
 * rest trustworthy: the 750 ms alert measured 789 and the 1000 ms alert 1037,
 * both about 38 ms long. That excess is the motor still moving after it stops
 * being driven, and it is kept rather than subtracted — what a player feels is
 * the vibration, not the drive.
 *
 * What the names claimed, and measuring disproved: a Strong Buzz is a quarter
 * of a second and not a whole one, a Smooth Hum stops by itself after half a
 * second rather than running on, and the Short, Medium and Long in the 48 ramp
 * names say nothing at all about their length — Ramp Down Long Smooth 1 and
 * Ramp Down Short Smooth 1 are both about 320 ms, while the 1 and 2 variants
 * of the same name differ by 200. Guessing from the names would have been
 * wrong for more than half the library.
 */
export interface RumbleEffectShape {
    /** How hard, 0 to 1, as the name's percentage says. Where a ramp starts. */
    amplitude: number;
    /** Where a ramp ends. Only a ramp has one. */
    rampTo?: number;
    /**
     * How long it runs, measured, in milliseconds.
     *
     * Absent for the one effect that has no length of its own: 118 is named
     * "Long buzz for programmatic stopping" and runs until a Stop, which the
     * measurement confirmed by hitting its three-second cap.
     */
    ms?: number;
}
/**
 * The 123 effects, as shapes rather than as words.
 *
 * In step with `builtInRumbleEffects` above, entry for entry — the comments
 * carry the same numbers and family names, and `rumble-effects-probe` reads
 * the English names and fails if the two ever disagree about an amplitude.
 * Written out rather than derived from the names at run time: those names are
 * translated, and a program that reads its own interface text is a program
 * that breaks in German.
 */
export declare const RUMBLE_EFFECT_SHAPES: readonly RumbleEffectShape[];
/** What effect `effect` is, or undefined for a number the pack does not have. */
export declare function rumbleEffectShape(effect: number | undefined): RumbleEffectShape | undefined;
/**
 * How long an effect runs, in milliseconds.
 *
 * Its measured length, and the ceiling for the two cases where there is none:
 * the effect that runs until it is stopped, and a Play whose effect number was
 * never chosen.
 */
export declare function rumbleEffectMs(shape: RumbleEffectShape | undefined): number;
/**
 * How hard an effect is pulling at one point along its length.
 *
 * `progress` runs 0 to 1 over the effect. A flat effect answers the same all
 * the way through; a ramp is read off the line between where it starts and
 * where it ends, which for the 48 ramps in the library is the whole of what
 * makes them ramps.
 *
 * Shared, so that a pad's motors and the panel's little box are never two
 * different opinions about what the game asked for.
 */
export declare function rumbleEffectAmplitudeAt(shape: RumbleEffectShape | undefined, progress: number): number;
export declare function getRumbleEffectName(effect: number): string;
/**
 * A rumble pack the emulator can drive.
 *
 * Narrower than VES's service, which also flashes firmware and keeps a
 * log widget: this is only what it takes to forward a game's link port traffic
 * to a real pack and to show what it is asking for. A host with no pack — or no
 * WebSerial — can implement this as a permanently disconnected one.
 */
export interface VueportRumblePack {
    readonly connected: boolean;
    /**
     * Whether this host could ever have one attached.
     *
     * False for a page, which cannot reach a serial port however many packs
     * are plugged into the machine it is running on. It is the difference
     * between a pack that is not there yet and one that can never be, and the
     * panel needs it to know whether offering a Detect button is honest.
     *
     * Optional so that a host written before this existed still reads as one
     * that can, which is what every host that implements this interface at all
     * used to be.
     */
    readonly canConnect?: boolean;
    /** The device's name, when it is one we recognize. */
    readonly deviceName: string | undefined;
    /** The connected device's USB ids, for the panel to show. */
    readonly deviceIds: {
        vendor?: number;
        product?: number;
    } | undefined;
    readonly onDidChangeConnected: Event<void>;
    /** Ask the person to pick a port, and open it. */
    detect(): Promise<void>;
    /** Whether the emulator is forwarding the game's link traffic to it. */
    forwarding: boolean;
    /**
     * Whether a link cable has the port instead, which is the one reason a
     * pack that is plugged in and has a game running is still left alone.
     *
     * Set by the emulator alongside {@link forwarding}, because only it knows
     * what the port is carrying. It is the difference between "nothing is
     * running" and "something else is using the one port", and a player looking
     * for their missing rumble needs to be told which.
     *
     * Optional so that a host with no way to link two machines can leave it
     * alone and read as never cabled.
     */
    linkPortInUse?: boolean;
    /** The effect spec the running game last started, if it is known. */
    emulatedSpec: EmulatedRumbleSpec | undefined;
    readonly emulatedCommands: RumbleCommand[];
    readonly emulatedRumbleState: RumbleState;
    readonly emulatedByteCount: number;
    /** What the pack itself last said, where an unknown command shows up. */
    readonly lastReply: string | undefined;
    /**
     * Commands dropped because the game asked for them faster than the wire
     * and the board could take them. See `SerialRumblePack.MAX_QUEUED`.
     *
     * Optional, like the rest of what only a host with hardware can answer.
     * Worth showing where it is not zero: it is the difference between a pack
     * that is behaving oddly and a game that is asking for more than a pack
     * can do.
     */
    readonly droppedCommands?: number;
    clearEmulatedTraffic(): void;
    sendByte(byte: number): Promise<void>;
    /**
     * Silence the motor, without the game having asked for it.
     *
     * Needed because forwarding can be taken away mid-effect — a cable goes in,
     * or the game is closed while something is playing — and the Stop the game
     * would eventually have sent is exactly what is no longer being carried.
     * A pack left like that buzzes until it is unplugged.
     *
     * Outside the forwarded stream on purpose: the byte is ours rather than the
     * game's, so it is not counted or decoded into the traffic the panel shows.
     *
     * Optional, like {@link linkPortInUse}: a host that cannot take the port
     * away has nothing to stop.
     */
    stop?(): Promise<void>;
}
/** A pack that is never plugged in, for a host that cannot talk to one. */
export declare const NO_RUMBLE_PACK: VueportRumblePack;
/**
 * The half of a rumble pack that needs no rumble pack.
 *
 * Counting the bytes a game clocks out of the link port and decoding them into
 * effects is arithmetic: it needs the protocol and nothing else, which is why
 * it lives here rather than in a host. What a host adds is the device — a port
 * to open, bytes to write to it, a reply to read back — and that is the whole
 * of what {@link forward} and the overridable getters are for.
 *
 * Used directly by a host that has no way to reach a pack, and there it is not
 * a stub: the panel's readings are about what the game is asking for, and a
 * game asks for it whether or not anything is listening. A page gets the
 * commands, the effect and the motor that would be running; what it does not
 * get is the buzz.
 */
export declare class DecodingRumblePack implements VueportRumblePack {
    protected readonly onDidChangeConnectedEmitter: Emitter<void>;
    readonly onDidChangeConnected: Event<void>;
    protected readonly decoder: RumbleStreamDecoder;
    protected commands: RumbleCommand[];
    protected bytes: number;
    forwarding: boolean;
    linkPortInUse: boolean;
    emulatedSpec: EmulatedRumbleSpec | undefined;
    /** Overridden by a host that can open a port. */
    get canConnect(): boolean;
    get connected(): boolean;
    get deviceName(): string | undefined;
    get deviceIds(): {
        vendor?: number;
        product?: number;
    } | undefined;
    get lastReply(): string | undefined;
    get emulatedCommands(): RumbleCommand[];
    get emulatedRumbleState(): RumbleState;
    get emulatedByteCount(): number;
    /** Nothing is sent, so nothing is ever given up on. */
    get droppedCommands(): number;
    /** Nothing to look for. A host that has somewhere to look overrides this. */
    detect(): Promise<void>;
    clearEmulatedTraffic(): void;
    /**
     * One byte the running game clocked out of its link port.
     *
     * Decoded first and handed on second, so that what the panel shows is the
     * same whether or not the handing on goes anywhere.
     *
     * Every byte fires the change event. That is what keeps the panel live —
     * it polls once a second and would otherwise show an effect after it had
     * finished — and it is affordable because the traffic is a handful of
     * bytes per effect, not a stream.
     */
    sendByte(byte: number): Promise<void>;
    /** Hand the byte to the hardware. There is none here. */
    protected forward(_byte: number): Promise<void>;
}
/** One revision of the board, by the USB ids it reports. */
export interface RumblePackDevice {
    /** Which revision this is, as the studio names it. */
    name: string;
    vendor: number;
    product: number;
}
/**
 * The boards that are a Rumble Pack.
 *
 * The studio's table (`ves-rumble-pack-types.ts`) and the desktop shell's
 * (`rumble.rs`) say the same, and have to: a pack recognized by one
 * application and not by another would be a bug nobody could explain. The
 * final board reports itself as an Arduino Leonardo, which it is built on.
 */
export declare const RUMBLE_PACK_IDS: readonly RumblePackDevice[];
/** Which board these ids are, or undefined for something that is not a pack. */
export declare function rumblePackName(vendor?: number, product?: number): string | undefined;
/**
 * A pack on a serial line, whatever is carrying the line.
 *
 * Everything above the transport: which board is on the other end, the text
 * protocol it speaks, and the lines it answers with. A host adds the line
 * itself — a port the desktop shell opened, or one `navigator.serial` handed
 * the page — by implementing {@link write} and calling {@link attached} once
 * it has one.
 *
 * Here rather than in each host because it is the same firmware answering
 * either way, and a protocol spelled out twice is a protocol that drifts: the
 * `<VB nnn>` a packaged build sends and the one a browser sends have to stay
 * the same eight characters. See {@link send} for what those are.
 */
export declare abstract class SerialRumblePack extends DecodingRumblePack {
    /**
     * The least time between two commands, in ms.
     *
     * The board is an ATmega32u4 with a 64-byte serial buffer, and every
     * command it reads turns into an I2C transaction with the motor driver —
     * so it empties that buffer far slower than a 115200-baud line fills it.
     * Eight commands back to back is all the buffer holds, and a game in the
     * middle of something can easily ask for more: the overflow lands
     * mid-command, the parser is left waiting for a `>` that was eaten, and
     * from then on the pack takes nothing and answers nothing until it is
     * unplugged from power.
     *
     * So the wire is paced. Two hundred commands a second is far more than any
     * game asks for — a whole effect is four or five — and far less than the
     * board can be made to choke on.
     */
    protected static readonly WRITE_GAP_MS = 5;
    /**
     * How many commands may be waiting before the oldest are given up on.
     *
     * A bound rather than a queue that grows: haptics that arrive late are not
     * haptics, and a game that outruns the wire for a second and a half is one
     * whose backlog is worth dropping rather than playing out minutes later.
     */
    protected static readonly MAX_QUEUED = 32;
    /** The board on the other end, once there is one. */
    protected current: RumblePackDevice | undefined;
    protected reply: string | undefined;
    /** Bytes the pack has sent that have not yet ended in a newline. */
    protected replyBuffer: string;
    /** Commands waiting for the wire, oldest first. */
    protected queue: string[];
    /** The drain in progress, which is what keeps writes one at a time. */
    protected draining: Promise<void> | undefined;
    protected dropped: number;
    /** Commands given up on because the game outran the wire. */
    get droppedCommands(): number;
    get connected(): boolean;
    get deviceName(): string | undefined;
    get deviceIds(): {
        vendor?: number;
        product?: number;
    } | undefined;
    get lastReply(): string | undefined;
    /** Put text on the wire, exactly as given. The framing is {@link send}'s. */
    protected abstract write(text: string): Promise<void>;
    /**
     * One command, framed the way the firmware reads them, onto the queue.
     *
     * Angle brackets and nothing else — no newline. This is the firmware's
     * own framing and it is not negotiable: VUEngine Studio has driven the
     * hardware this way for years (`ves-rumble-pack-service.ts`), and a
     * newline-terminated `VB 124` is read as no command at all. A pack sent
     * those connects, answers nothing and sits perfectly still, which is a
     * hard fault to see. See the `<VB nnn>` check in `rumble-panel-probe`.
     *
     * Queued rather than written, and the queue is the point — see
     * {@link drain}. Returns as soon as the command is on it: the caller is
     * the emulator's link-port callback, and holding that up would be holding
     * up the game.
     */
    protected send(command: string): Promise<void>;
    /**
     * Put the queue on the wire, one command at a time, no faster than
     * {@link WRITE_GAP_MS}.
     *
     * One at a time is not only pacing. The desktop shell writes through a
     * Tauri command, and two of those in flight are two calls on a thread pool
     * that take the port's lock in whatever order they get it — so unawaited
     * writes can reach the pack in the wrong order, which is a frequency
     * arriving as an effect number and an effect as a frequency. A single
     * drain is what makes the order the game's order on every transport.
     */
    protected startDraining(): void;
    protected drain(): Promise<void>;
    /**
     * Pick up a pack that is already attached, and watch for one arriving.
     *
     * Called once at start-up, before anything is running. Separate from
     * {@link detect} because this one may not ask the person anything: a pack
     * found here was found without being looked for.
     */
    abstract start(): Promise<void>;
    /** Called by a host once a port is open and answering. */
    protected attached(device: RumblePackDevice): void;
    /** Called by a host when the port closes, whoever closed it. */
    protected detached(): void;
    /**
     * What the pack said.
     *
     * Kept as whole lines: the firmware answers in text terminated by a
     * newline, and half a line is not something worth showing anyone.
     */
    protected receive(text: string): void;
    /** One byte the game sent, relayed as the pack's own `<VB nnn>`. */
    protected forward(byte: number): Promise<void>;
    /**
     * Stop whatever the motor is doing, on our own account.
     *
     * `STP` rather than a forwarded `VB 000`: the emulator is commanding the
     * device here, not relaying a byte the game sent, and the traffic the
     * panel shows should stay the game's own. Silent with no pack attached —
     * there is nothing running to stop.
     */
    stop(): Promise<void>;
}
/**
 * The command bytes a game sends to the pack.
 *
 * The same protocol VUEngine Studio speaks to the real hardware; the numbers
 * are the device's, not ours.
 */
export declare const RUMBLE_CMD: {
    readonly STOP: 0;
    readonly MIN_EFFECT: 1;
    readonly MAX_EFFECT: 123;
    readonly PLAY: 124;
    readonly CHAIN_EFFECT_0: 128;
    readonly CHAIN_EFFECT_4: 132;
    readonly OVERDRIVE: 160;
    readonly SUSTAIN_POS: 161;
    readonly SUSTAIN_NEG: 162;
    readonly BREAK: 163;
    readonly WRITE_EFFECT_CHAIN: 176;
    readonly WRITE_EFFECT_LOOPS_CHAIN: 177;
    readonly EFFECT_CHAIN_END: 255;
};
/** The bytes that select a vibration frequency, and the frequency each means. */
export declare const RUMBLE_CMD_FREQUENCIES: Record<number, number>;
/**
 * Turns the byte stream a game sends into the effect it describes.
 *
 * Stateful because the protocol is: four of the commands take their value from
 * the byte that follows, and the rest accumulate into one effect configuration
 * that the pack plays when told to.
 *
 * In `vueport-core` rather than in a host because there is nothing
 * host-specific about it — it is bytes in, `RumbleCommand` and `RumbleState`
 * out, both of which are declared here.
 */
export declare class RumbleStreamDecoder {
    protected pending: number | undefined;
    state: RumbleState;
    reset(): void;
    /** Feed one byte. Returns a command once one is complete. */
    /**
     * One byte of the stream, and the command it completed if it completed one.
     *
     * The time is stamped here rather than in each of `decode`'s many answers:
     * one place to be right, and the moment a command is understood is as
     * close to when the game sent it as this side can see.
     */
    push(byte: number): RumbleCommand | undefined;
    /** `at` is the reading `push` took, so that a Play is stamped by that one. */
    protected decode(byte: number, at: number): Omit<RumbleCommand, 'at'> | undefined;
    /**
     * Names a value command, and swallows the byte that carries its value.
     *
     * None of the four settings survives on current packs — the editor no
     * longer offers them and the engine no longer sends them — so none of them
     * lands in {@link RumbleState}. The decoding stays because older ROMs do
     * send them, and a pair of bytes read as one command is the difference
     * between a log that says `Overdrive: 126` and one that claims effect 126
     * was selected.
     */
    protected applyValue(command: number, value: number): Omit<RumbleCommand, 'at'>;
}
//# sourceMappingURL=emulator-rumble.d.ts.map