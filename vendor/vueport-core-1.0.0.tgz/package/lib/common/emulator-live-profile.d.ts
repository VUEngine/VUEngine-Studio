/**
 * Profiling a game while it is being played, rather than replaying it after.
 *
 * `VesProfileCollector` next door answers "where did the last thirty seconds
 * go", exhaustively, from a recording — which is the right shape for a report
 * and the wrong one for a panel: nothing is on screen until the run is over
 * and replayed. This answers "where is *this frame* going", every frame, while
 * the game runs, so the number moves when the developer changes something.
 *
 * Three measurements decided that this is affordable, all of them taken
 * against the vendored core rather than assumed:
 *
 * - An execute callback costs 1.03x with nothing in it and 1.17x with a set
 *   lookup per instruction (`tests/breakpoint-probe.mjs`). The core runs about
 *   five times faster than the machine it emulates, so there is room.
 * - The clock budget `Emulate` is given is decremented *as it runs* and can be
 *   read from inside the callback: 398, 391, 386, 381 over the first four
 *   instructions of a boot. So each instruction's cost is knowable to the
 *   clock, and time here is real time rather than an instruction count
 *   standing in for it.
 * - `halt` parks the processor and lets the clock run on, which is what makes
 *   an idle figure measurable without knowing what the game's wait loop looks
 *   like — see {@link VesInstructionKind.HALT}. Most games do not halt, and
 *   {@link VesLiveProfileCollector.harvestWait} is what finds the rest: a loop
 *   that was still going round when the interrupt arrived was waiting for it.
 *
 * Nothing here runs the machine or knows what a function is called. The worker
 * feeds it program counters and clocks; the panel puts names to the addresses
 * with the build's symbols. Both ends stay ignorant of the other.
 */
import { VesInstructionKind } from './emulator-profile';
/**
 * The address a frame's own time is charged to when nothing called it.
 *
 * Profiling starts in the middle of a game, several calls deep in a stack that
 * was built before anything was watching. Those frames cannot be named — they
 * were entered before the first callback — so their time collects here, under
 * one row the panel labels for what it is. It shrinks to the current function
 * within a call or two and never goes away entirely, since the game's own main
 * loop is one of the frames that was already open.
 *
 * Zero rather than a negative sentinel because every other address travels as
 * an unsigned 32-bit number, and the Virtual Boy executes nothing at zero: the
 * bottom of the map is the VIP's register window. A program that has run off
 * into it would land in this row, which is as good a place as any for it.
 */
export declare const VES_LIVE_PROFILE_ROOT = 0;
/** One function's share of one frame, as the collector accumulates it. */
interface LiveRow {
    address: number;
    /** Clocks spent in this function itself, this frame. */
    self: number;
    /** Clocks spent in it and everything it called, this frame. */
    total: number;
    /** Times it was entered this frame. */
    calls: number;
    /** Whether it has been touched since the last frame was closed. */
    touched: boolean;
}
/** What one function did over the window a snapshot covers. */
export interface LiveProfileFunction {
    /** Where the function starts, as the machine reports the program counter. */
    address: number;
    /** Clocks in the function itself, in the most recent frame. */
    self: number;
    selfAvg: number;
    selfPeak: number;
    /** Clocks in it and everything it called, in the most recent frame. */
    total: number;
    totalAvg: number;
    totalPeak: number;
    /** The cheapest frame it appeared in at all, which is not the same as zero. */
    totalMin: number;
    /** Times it was entered in the most recent frame. */
    calls: number;
    callsAvg: number;
    /** Frames of the window it ran in at all, which is what the averages divide by. */
    frames: number;
}
/** What one function did in one frame, with nothing of the window in it. */
export interface LiveProfileFrameFunction {
    address: number;
    /** Clocks in the function itself. */
    self: number;
    /** Clocks in it and everything it called. */
    total: number;
    /** Times it was entered. */
    calls: number;
}
/**
 * One finished frame, as it was recorded.
 *
 * The window's averages answer "what does a frame cost here". This answers
 * "what was in *that* frame", which is the question a spike raises and the one
 * an average is least able to answer — a frame that overran by half is one
 * frame in a hundred, and the mean moves by half a percent.
 *
 * Only ever readable while the frame is still in the window, which is a couple
 * of seconds of play, so whoever wants to keep one keeps the answer rather
 * than the number.
 */
export interface LiveProfileFrame {
    /** Which frame this is, counted from when profiling began. The first is 1. */
    number: number;
    /**
     * Clocks accounted for, of which `halted` were spent with the processor
     * stopped and `waited` going round a loop until an interrupt came.
     */
    clocks: number;
    halted: number;
    waited: number;
    /** Where the longest wait of the frame was, or 0 if it had none. */
    waitAt: number;
    instructions: number;
    functions: LiveProfileFrameFunction[];
}
/** Everything the panel draws one refresh from. */
export interface LiveProfileSnapshot {
    /** Frames these figures were taken over. Zero means nothing has run yet. */
    frames: number;
    /** Frames profiled since it was switched on, for a panel that wants to say. */
    framesSeen: number;
    /** Clocks in a frame at the machine's own rate — what a share is a share of. */
    frameClocks: number;
    /** Clocks accounted for in the most recent frame. */
    clocks: number;
    clocksAvg: number;
    clocksPeak: number;
    /** Of those, clocks the processor spent halted rather than working. */
    halted: number;
    haltedAvg: number;
    haltedPeak: number;
    /**
     * And clocks spent going round a loop until an interrupt arrived, which is
     * how most games wait — see {@link VesLiveProfileCollector.harvestWait}.
     * Waiting is not work, so the busy figure is the frame less both of these.
     */
    waiting: number;
    waitingAvg: number;
    waitingPeak: number;
    /** Where the most recent frame's longest wait was, or 0 if it had none. */
    waitingAt: number;
    /** Instructions retired, which says how much work the clocks bought. */
    instructions: number;
    instructionsAvg: number;
    /**
     * Busy clocks — everything the frame was not idling — for each frame of
     * the window, oldest first.
     *
     * The shape of the window, which no average beside it can show: a frame
     * that overran is one bar above the budget, and dividing it by a hundred
     * good ones is exactly what hides it. The newest of these is the frame
     * numbered {@link framesSeen}.
     */
    frameBusy: number[];
    /** The frame a reader asked for by number, if it is still in the window. */
    pinned?: LiveProfileFrame;
    functions: LiveProfileFunction[];
    /** Machine restarts seen, which end every frame that was open. */
    resets: number;
    /** Calls dropped for depth, which should be zero on anything sane. */
    overflows: number;
}
/**
 * One frame, flattened.
 *
 * Four numbers per function — address, self, total, calls — in one typed array
 * rather than a map of objects, because a window is a hundred of these and
 * they are only ever written once and read in bulk. A frame's own totals ride
 * alongside in {@link VesLiveFrame}.
 */
type VesLiveFrameRows = Int32Array;
interface VesLiveFrame {
    rows: VesLiveFrameRows;
    clocks: number;
    halted: number;
    /** Clocks spent in a loop that was waiting for an interrupt. */
    waited: number;
    /** Where the longest of those waits was, or 0 if there was none. */
    waitAt: number;
    instructions: number;
}
/**
 * Turns a running game's program counters into a per-frame profile.
 *
 * Feed it every instruction in order, along with what the *previous* one cost
 * — the callback fires before an instruction executes, so its price is only
 * known when the next one arrives — and close each frame as the machine
 * reaches it. It keeps a shadow stack exactly as the replay collector does,
 * charging clocks to whichever frame is on top, and hands back a window of
 * finished frames on demand.
 */
export declare class VesLiveProfileCollector {
    protected readonly capacity: number;
    /** Every function seen since profiling began, by address. */
    protected readonly rows: Map<number, LiveRow>;
    /**
     * Rows written since the last frame was closed.
     *
     * The map is kept across frames — the set of functions a game runs settles
     * within a second, and rebuilding it fifty times a second would allocate
     * for no reason — so something has to say which of its rows this frame
     * actually touched. This is that, and it is also what gets zeroed.
     */
    protected readonly touched: LiveRow[];
    protected readonly stackRow: LiveRow[];
    protected readonly stackReturn: number[];
    protected readonly stackEnter: number[];
    /**
     * Whether each level is the outermost activation of its function.
     *
     * Inclusive time is only counted for the outermost one: a recursive
     * function is inside itself, and adding every level's span would count the
     * same clocks once per level and report more time than the frame has.
     */
    protected readonly stackOutermost: boolean[];
    /** How many activations of each function are on the stack right now. */
    protected readonly active: Map<number, number>;
    /** Monotonic clock since profiling began, which every span is measured on. */
    protected cycle: number;
    /** Set by a call, resolved on the next instruction — see `VesProfileCollector`. */
    protected pendingReturn: number;
    /**
     * Whether the instruction whose cost is about to arrive was a `halt`.
     *
     * Its clocks are the machine waiting rather than the function working, and
     * they are what the CPU load figure is measured against, so they are
     * charged to the frame's idle total instead of to the function the `halt`
     * happens to sit in.
     */
    protected halting: boolean;
    /**
     * The row a quiet stretch is running in, and where it began.
     *
     * A "quiet" stretch is execution that writes nothing, calls nothing and
     * stays within {@link QUIET_SPAN} bytes — which is what a program looks
     * like when it has finished and is waiting for the next interrupt. It is
     * only *called* waiting once something ends it that nothing else could
     * have: see {@link harvestWait}.
     */
    protected quietRow?: LiveRow;
    protected quietSince: number;
    protected quietLow: number;
    protected quietHigh: number;
    /** Instructions in the stretch, and how many of them wrote. */
    protected quietSteps: number;
    protected quietStores: number;
    protected frameClocksSpent: number;
    protected frameHalted: number;
    protected frameWaited: number;
    protected frameWaitTop: number;
    protected frameWaitAt: number;
    protected frameInstructions: number;
    protected resets: number;
    protected overflowed: number;
    protected framesSeen: number;
    /** The window of finished frames, oldest first, capped at `capacity`. */
    protected readonly frames: VesLiveFrame[];
    /**
     * @param capacity how many frames the window holds. Two seconds of play is
     *     enough for a peak to be a peak rather than a hiccup, and short
     *     enough that a change made in the game is visible in the averages
     *     within a moment of making it.
     */
    constructor(capacity: number);
    /**
     * Charge an instruction, and follow it if it enters or leaves a frame.
     *
     * The hot path of the whole feature: this runs once per emulated
     * instruction, twenty million times a second of play, so it does its own
     * bookkeeping rather than calling out to anything.
     *
     * @param address where the instruction about to run is
     * @param kind what it does, from the ROM's decoded table
     * @param clocks what the *previous* instruction cost
     */
    step(address: number, kind: VesInstructionKind, clocks: number): void;
    /**
     * Charge a finished wait to the frame rather than to the code it was in.
     *
     * Called where a quiet stretch has been ended by something outside the
     * program — an interrupt, or the frame boundary itself — and nowhere else.
     * That is the whole test. A loop that finishes on its own was doing
     * something, however little it wrote; a loop that was still going when the
     * interrupt arrived was waiting for it, which is the same thing `halt`
     * says in one instruction and which most Virtual Boy games say by spinning
     * instead — VUEngine's frame loop is a bare `while(!hasGameFrameStarted())`.
     *
     * The clocks have already been charged to the function the loop is in, so
     * they are taken back out of it: a wait is not work, and a table that
     * shows the engine's idle loop as the most expensive thing in the frame is
     * a table nobody can read a frame's cost off.
     */
    protected harvestWait(): void;
    /**
     * Charge clocks to whatever is running, and to the idle total if that is
     * a `halt`.
     *
     * Every clock the machine spends passes through here exactly once, which
     * is what lets a frame's rows plus its idle time add up to the frame — see
     * the accounting check in `tests/live-profile-probe.mjs`.
     */
    protected charge(clocks: number): void;
    /**
     * Close the frame the machine has just finished and start the next.
     *
     * Called when the core reports a frame break, so the figures are per
     * displayed frame — the same boundary the game's own work is bounded by —
     * rather than per audio buffer, which is the same length but not the same
     * moment.
     *
     * @param spent what the instruction now executing has run up so far. The
     *     callback only ever learns an instruction's cost when the next one
     *     arrives, and the instruction a frame ends inside is very often a
     *     `halt` waiting for the very interrupt that ends it — which would
     *     otherwise charge a frame's worth of idling to the frame after, and
     *     leave a game that spends most of its time waiting reporting almost
     *     nothing at all.
     */
    endFrame(spent?: number): void;
    /**
     * The window as one set of figures.
     *
     * Aggregated on the way out rather than as frames arrive, because the
     * window is read a handful of times a second and written fifty: whatever
     * work can wait for a reader should.
     */
    snapshot(frameClocks: number, pin?: number): LiveProfileSnapshot;
    /**
     * One frame of the window, unpacked, or nothing if it has scrolled out.
     *
     * By frame number rather than by index, because the window moves fifty
     * times a second and an index means something different by the time the
     * answer arrives. A number that has fallen off the back is not an error:
     * it is what happens to every frame a couple of seconds after it ran, and
     * the caller is expected to have kept whatever it needed.
     */
    protected frameDetail(number: number): LiveProfileFrame | undefined;
    /** Throw the window away, keeping the shadow stack the machine is in. */
    clear(): void;
    /** A row for an address, made on first sight and kept for good. */
    protected rowFor(address: number): LiveRow;
    protected push(address: number, interrupt: boolean, returnTo?: number): void;
    /**
     * Leave every frame that was waiting for this address.
     *
     * More than one at a time because a return can skip levels — see
     * `VesProfileCollector.unwindTo`, which this is the clock-charging twin of.
     */
    protected unwindTo(address: number): void;
    /** The innermost interrupt frame, and anything left open underneath it. */
    protected leaveInterrupt(): void;
    /** Close every frame from `depth` up, charging each its span. */
    protected unwind(depth: number): void;
}
export {};
//# sourceMappingURL=emulator-live-profile.d.ts.map