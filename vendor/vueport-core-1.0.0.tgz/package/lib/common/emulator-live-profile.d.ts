/**
 * Profiling a game while it is played: "where is this frame going", every frame, unlike VesProfileCollector's
 * exhaustive report from a replayed recording. Measured against the vendored core:
 * - an execute callback costs 1.03x empty and 1.17x with a set lookup per instruction (tests/breakpoint-probe.mjs);
 *   the core runs about five times faster than the machine, so there is room
 * - the clock budget Emulate is given is decremented as it runs and readable in the callback (398, 391, 386, 381 over
 *   the first four instructions of a boot), so time here is real clocks, not instruction counts
 * - halt parks the processor while the clock runs on, so idle is measurable (VesInstructionKind.HALT); for the many
 *   games that do not halt, harvestWait finds loops still going round when the interrupt arrived
 * The worker feeds program counters and clocks; the panel names addresses with the build's symbols.
 */
import { VesInstructionKind } from './emulator-profile';
/**
 * Where a frame's own time is charged when nothing called it: profiling starts several calls deep, and frames entered
 * before the first callback cannot be named. Shrinks within a call or two but never goes away, as the game's main loop
 * is one of them. Zero, as addresses travel unsigned and the VB executes nothing at zero (the VIP register window).
 */
export declare const VES_LIVE_PROFILE_ROOT = 0;
interface LiveRow {
    address: number;
    self: number;
    total: number;
    calls: number;
    touched: boolean;
}
export interface LiveProfileFunction {
    address: number;
    self: number;
    selfAvg: number;
    selfPeak: number;
    total: number;
    totalAvg: number;
    totalPeak: number;
    totalMin: number;
    calls: number;
    callsAvg: number;
    frames: number;
}
export interface LiveProfileFrameFunction {
    address: number;
    self: number;
    total: number;
    calls: number;
}
export interface LiveProfileFrame {
    number: number;
    clocks: number;
    halted: number;
    waited: number;
    waitAt: number;
    instructions: number;
    functions: LiveProfileFrameFunction[];
}
export interface LiveProfileSnapshot {
    frames: number;
    framesSeen: number;
    frameClocks: number;
    clocks: number;
    clocksAvg: number;
    clocksPeak: number;
    halted: number;
    haltedAvg: number;
    haltedPeak: number;
    waiting: number;
    waitingAvg: number;
    waitingPeak: number;
    waitingAt: number;
    instructions: number;
    instructionsAvg: number;
    frameBusy: number[];
    pinned?: LiveProfileFrame;
    functions: LiveProfileFunction[];
    resets: number;
    overflows: number;
    machine?: LiveMachineCounters;
}
export interface LiveMachineCounters {
    frames: number;
    last: LiveMachineFrame;
    avg: LiveMachineFrame;
}
export interface LiveMachineFrame {
    cycles: number;
    halted: number;
    cacheHits: number;
    cacheMisses: number;
    fetchWait: number;
    busVip: number;
    busVsu: number;
    busMisc: number;
    busCart: number;
    busSram: number;
    busWram: number;
    vipContention: number;
    pipelineWait: number;
    xpBusy: number;
    xpHeld: number;
}
export declare function liveMachineFrame(values: ArrayLike<number>): LiveMachineFrame;
type VesLiveFrameRows = Int32Array;
interface VesLiveFrame {
    rows: VesLiveFrameRows;
    clocks: number;
    halted: number;
    waited: number;
    waitAt: number;
    instructions: number;
}
export declare class VesLiveProfileCollector {
    protected readonly capacity: number;
    protected readonly rows: Map<number, LiveRow>;
    protected readonly touched: LiveRow[];
    protected readonly stackRow: LiveRow[];
    protected readonly stackReturn: number[];
    protected readonly stackEnter: number[];
    protected readonly stackOutermost: boolean[];
    protected readonly active: Map<number, number>;
    protected cycle: number;
    protected pendingReturn: number;
    protected halting: boolean;
    protected quietRow?: LiveRow;
    protected quietSince: number;
    protected quietLow: number;
    protected quietHigh: number;
    protected quietSteps: number;
    protected quietStores: number;
    protected frameClocksSpent: number;
    protected frameHalted: number;
    protected frameWaited: number;
    protected frameWaitTop: number;
    protected frameWaitAt: number;
    protected frameInstructions: number;
    protected resets: number;
    protected overflowed: number;
    protected framesSeen: number;
    protected readonly frames: VesLiveFrame[];
    constructor(capacity: number);
    step(address: number, kind: VesInstructionKind, clocks: number): void;
    /**
     * Charges a finished wait to the frame rather than the code it was in. Called only where something outside the
     * program ended a quiet stretch (an interrupt, the frame boundary): a loop still going then was waiting, the spinning
     * equivalent of halt (VUEngine's frame loop is a bare `while(!hasGameFrameStarted())`). The clocks are taken back out
     * of the function, so the engine's idle loop does not top the table.
     */
    protected harvestWait(): void;
    protected charge(clocks: number): void;
    /**
     * Called on the core's frame break, so figures are per displayed frame rather than per audio buffer (same length,
     * different moment). `spent` is what the executing instruction has run up so far: its cost would only arrive with the
     * next one, and that is often a halt waiting for the very interrupt ending the frame, which would charge a frame of
     * idling to the next frame.
     */
    endFrame(spent?: number): void;
    snapshot(frameClocks: number, pin?: number): LiveProfileSnapshot;
    frameTotals(): Omit<LiveProfileFrame, 'functions'>[];
    protected frameDetail(number: number): LiveProfileFrame | undefined;
    clear(): void;
    protected rowFor(address: number): LiveRow;
    protected push(address: number, interrupt: boolean, returnTo?: number): void;
    protected unwindTo(address: number): void;
    protected leaveInterrupt(): void;
    protected unwind(depth: number): void;
}
export {};
//# sourceMappingURL=emulator-live-profile.d.ts.map