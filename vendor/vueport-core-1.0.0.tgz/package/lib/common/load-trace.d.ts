export declare function beginLoadTrace(): void;
export declare function markLoadTrace(step: string): void;
export declare function endLoadTrace(step: string): void;
//# sourceMappingURL=load-trace.d.ts.map