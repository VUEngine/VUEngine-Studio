/**
 * TEMPORARY: where the time goes between opening a ROM and its first frame.
 *
 * For a report from Linux of a ROM taking some five seconds to start, in the
 * desktop application and the browser alike. `begin` starts the clock when a
 * ROM is opened; every `mark` after it logs the step's own duration and the
 * running total, so one console dump says which step it is. Remove once that
 * is answered.
 */
export declare function beginLoadTrace(): void;
export declare function markLoadTrace(step: string): void;
/** The last mark: logs it and stops, so later restarts do not keep logging. */
export declare function endLoadTrace(step: string): void;
//# sourceMappingURL=load-trace.d.ts.map