/**
 * Collecting a profile by replaying a recorded session.
 *
 * The Virtual Boy's emulation is bit-deterministic (§2 of the rewrite plan), so
 * a session can be reproduced exactly from the machine's state when recording
 * began plus the input it was given. Replaying it with an execute callback
 * gives an *exhaustive* profile — every instruction, no sampling error — and,
 * because the call stack is rebuilt from the calls and returns the replay sees
 * rather than unwound from frames, it works on the optimized, frame-pointer-less
 * builds a project actually ships. See §6.3.
 *
 * Nothing here runs the machine. It takes the stream of program counters a
 * replay produces and turns it into a call tree; driving the core is the
 * worker's job, and converting the result for Firefox Profiler is
 * `toFirefoxProfile` at the end.
 */
/** What an instruction does to the call stack. */
export declare const enum VesInstructionKind {
    OTHER = 0,
    /** JAL: pushes a frame. */
    CALL = 1,
    /**
     * JMP [r31], the ordinary return.
     *
     * Decoded but no longer acted on: it turned out to miss about one return in
     * thirty on real code — see `returnTo` — so frames are closed by arriving
     * at their return address instead, which catches every way out. Kept
     * because it says what the instruction is, and a future consumer may want
     * to know.
     */
    RETURN = 2,
    /**
     * HALT: the processor stops until an interrupt wakes it.
     *
     * The clock runs on regardless, so this is the one instruction whose time
     * is not work being done — it is the machine waiting. The live profiler
     * charges it to an idle total rather than to the function it is in, which
     * is what makes a CPU load figure measurable without knowing anything
     * about the engine. Verified against the core rather than assumed: a ROM
     * whose loop is a single `halt` executes five instructions and then drains
     * a hundred thousand clocks with the program counter parked on it.
     */
    HALT = 3,
    /**
     * RETI: the way out of an interrupt handler.
     *
     * Hardware enters a handler without a call, so nothing pushed a frame for
     * it and no return address was ever recorded — which leaves this the only
     * signal that one has finished. See `VesLiveProfileCollector`, which opens
     * a frame on the vector and closes it here.
     */
    RETI = 4,
    /**
     * Anything that writes: a store, an I/O write, a bit string operation.
     *
     * Not about the memory but about the program. A machine waiting for the
     * next frame is running instructions that change nothing — `while(!flag);`
     * is a load and a branch, over and over — and one doing work leaves marks.
     * So a stretch of execution with no write in it is a candidate for time
     * the game was not actually getting anything done, which is what
     * {@link VesLiveProfileCollector} measures waiting with on the many games
     * that spin rather than `halt`.
     */
    STORE = 5
}
/**
 * Work out what every instruction in a ROM does to the call stack, once, and
 * which of them are the two the machine's own state turns on — `halt` and
 * `reti`.
 *
 * A replay reads no instruction back out of the machine: the ROM cannot change
 * while it runs, so this is knowable up front. Measured at 2.6 ms for a 1 MB
 * ROM, and it takes the per-instruction cost of maintaining a call stack from
 * 1.34x down to 1.13x — see §6.3.
 *
 * Indexed by halfword, since that is the smallest an instruction can be.
 */
export declare function decodeRomKinds(rom: Uint8Array): Uint8Array;
/** A node of the collected call tree. */
export interface VesProfileNode {
    /** Index into the collector's `nodes`, and this node's own id. */
    id: number;
    /** The node this was called from, or -1 at the root. */
    parent: number;
    /**
     * The address called to reach this frame — the callee's entry point, which
     * is what names the function. -1 for the root.
     */
    address: number;
    /** Instructions executed in this frame itself, excluding anything it called. */
    selfSamples: number;
    /** Instructions executed here and in everything below it. */
    totalSamples: number;
    children: Map<number, number>;
}
/**
 * Turns a replay's program counters into a call tree.
 *
 * Feed it every instruction in order. It keeps a shadow stack of the frames
 * entered so far and charges each instruction to whichever frame is on top, so
 * `selfSamples` is time in a function proper and `totalSamples` is time in it
 * and everything it called.
 */
export declare class VesProfileCollector {
    /** The tree, with node 0 as the root everything hangs off. */
    readonly nodes: VesProfileNode[];
    /** Node ids from the root down to the frame currently executing. */
    protected readonly stack: number[];
    /**
     * Where each frame on the stack is expected to return to.
     *
     * A call is not always undone by the instruction the plan assumed. Over
     * sixty frames of a real game: 3,800 `jal` against 3,667 `jmp [r31]`, with
     * the rest returning through `jmp` on some other register, through `reti`,
     * or not at all. Watching only for `jmp [r31]` leaks about two frames per
     * game frame, which buries the stack within seconds.
     *
     * So the return address is what actually decides: whenever execution
     * arrives at the address a frame said it would return to, that frame is
     * done, however it got there.
     */
    protected readonly returnTo: number[];
    /** Set by a call, resolved on the next instruction — see `push`. */
    protected pendingReturn: number;
    protected overflowed: number;
    protected instructions: number;
    protected resets: number;
    /**
     * Charge one instruction, and follow it if it enters or leaves a frame.
     *
     * The kind is looked up by the caller, which has the decoded table and the
     * address already; passing it in keeps this loop free of any indexing it
     * does not have to do.
     *
     * @param address where the instruction is, in whatever window the machine
     *     reports — the collector only ever compares these to each other
     * @param kind what it does to the stack
     */
    push(address: number, kind: VesInstructionKind): void;
    /**
     * Leave every frame that was waiting for this address.
     *
     * More than one at a time because a return can skip levels: a tail call
     * leaves its caller's frame to be closed by the callee's return, and a
     * non-local exit can abandon several at once. Scanning from the top down
     * finds the innermost frame that was expecting to come back here.
     */
    protected unwindTo(address: number): void;
    protected enter(address: number, returnTo: number): void;
    /** Calls dropped for exceeding MAX_DEPTH, which nothing normal should. */
    get overflows(): number;
    get sampleCount(): number;
    /**
     * How many times the machine restarted during the recording.
     *
     * Worth surfacing rather than hiding: a profile spanning several reboots
     * is describing several runs, and a reader should know that before drawing
     * conclusions from it.
     */
    get resetCount(): number;
    /**
     * Roll self time up into total time.
     *
     * Children always come after their parent in `nodes` — a node is only
     * created while its parent is on the stack — so one pass backwards
     * accumulates the whole tree without recursing.
     */
    finish(): VesProfileNode[];
}
/** What a frame's address is called, and where it came from. */
export interface VesProfileSymbol {
    name: string;
    file?: string;
    line?: number;
}
/**
 * The processed profile shape Firefox Profiler reads.
 *
 * Deliberately loose: the format is a set of parallel arrays whose exact
 * membership shifts between versions, and this only has to produce one the
 * importer accepts. The invariants that matter — every index in range, every
 * table the length it claims — are what the tests check.
 */
export interface VesFirefoxProfile {
    meta: Record<string, unknown>;
    libs: unknown[];
    threads: Record<string, unknown>[];
}
/**
 * Convert a collected tree into a profile Firefox Profiler can open.
 *
 * Samples are *instructions*, not time, so the weight column says so: one
 * sample per instruction executed, which is exact rather than statistical.
 *
 * @param nodes the tree, after `finish()`
 * @param symbolize names an address — the Phase 5 line table does this
 * @param product what was profiled, shown as the profile's title. The game,
 *     not the editor: someone comparing two captures needs to know which is
 *     which, and every one of them would otherwise be called the same thing.
 */
export declare function toFirefoxProfile(nodes: VesProfileNode[], symbolize: (address: number) => VesProfileSymbol, product: string): VesFirefoxProfile;
//# sourceMappingURL=emulator-profile.d.ts.map