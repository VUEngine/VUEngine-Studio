/**
 * Collects a profile by replaying a recorded session. VB emulation is bit-deterministic (§2 of the rewrite
 * plan), so a replay with an execute callback gives an exhaustive profile, and the call stack is rebuilt from
 * calls and returns, so it works on optimized, frame-pointer-less builds (§6.3). Turns the replay's program
 * counters into a call tree; driving the core is the worker's job, `toFirefoxProfile` converts the result
 */
export declare const enum VesInstructionKind {
    OTHER = 0,
    CALL = 1,
    RETURN = 2,
    /**
     * HALT: the processor stops until an interrupt, while the clock runs on, so its time is waiting, not work. The
     * live profiler charges it to an idle total, which gives a CPU load figure without knowing the engine.
     * Verified against the core: a ROM looping on a single `halt` executes five instructions, then drains a hundred
     * thousand clocks with the PC parked on it
     */
    HALT = 3,
    RETI = 4,
    STORE = 5
}
export declare function decodeRomKinds(rom: Uint8Array): Uint8Array;
export interface VesProfileNode {
    id: number;
    parent: number;
    address: number;
    selfSamples: number;
    totalSamples: number;
    children: Map<number, number>;
}
export declare class VesProfileCollector {
    readonly nodes: VesProfileNode[];
    protected readonly stack: number[];
    protected readonly returnTo: number[];
    protected pendingReturn: number;
    protected overflowed: number;
    protected instructions: number;
    protected resets: number;
    push(address: number, kind: VesInstructionKind): void;
    protected unwindTo(address: number): void;
    protected enter(address: number, returnTo: number): void;
    get overflows(): number;
    get sampleCount(): number;
    get resetCount(): number;
    finish(): VesProfileNode[];
}
export interface VesProfileSymbol {
    name: string;
    file?: string;
    line?: number;
}
export interface VesFirefoxProfile {
    meta: Record<string, unknown>;
    libs: unknown[];
    threads: Record<string, unknown>[];
}
export declare function toFirefoxProfile(nodes: VesProfileNode[], symbolize: (address: number) => VesProfileSymbol, product: string): VesFirefoxProfile;
//# sourceMappingURL=emulator-profile.d.ts.map