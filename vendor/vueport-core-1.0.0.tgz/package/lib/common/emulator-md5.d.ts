/**
 * MD5 of a byte buffer, for the one thing that needs it: naming a ROM the way
 * RetroAchievements names it.
 *
 * RetroAchievements identifies a Virtual Boy dump by the MD5 of the whole file,
 * with no header skipping or transformation — the plain-buffer bucket of
 * rcheevos' `rc_hash`. `crypto.subtle` has no MD5 (and does not exist in an
 * insecure context at all), so it is written out here, the same way `crc32` is
 * in `emulator-cheat-database.ts` and for the same reasons: it is one hash, it
 * is short, and a dependency for it would never be used for anything else.
 *
 * Not a general-purpose hashing utility. MD5 is broken for every purpose that
 * matters and is used here only because it is the identifier a third party
 * already keys its catalog on.
 */
/**
 * The MD5 of `bytes`, as 32 lower-case hex digits.
 *
 * Streams the padded message in 64-byte blocks so a whole ROM — up to a couple
 * of megabytes — never needs a second copy.
 */
export declare function md5Hex(bytes: Uint8Array): string;
//# sourceMappingURL=emulator-md5.d.ts.map