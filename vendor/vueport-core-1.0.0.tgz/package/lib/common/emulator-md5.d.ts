export declare function md5Hex(bytes: Uint8Array): string;
//# sourceMappingURL=emulator-md5.d.ts.map