/**
 * When something in a log happened.
 *
 * Written out by hand rather than through `toLocaleTimeString`, because a log
 * wants a fixed-width column that lines up and can be compared by eye — the
 * same eight-and-three digits in every language, rather than a form that
 * changes with the locale and puts the milliseconds somewhere else.
 *
 * Local time rather than elapsed time, so that an entry can be lined up
 * against something outside the emulator: a build that was running, a note
 * somebody made, a log from the hardware beside it.
 */
export declare function formatLogTime(at: number): string;
/**
 * What a line of terminal output said it was, by the word it starts with.
 *
 * Three, in the order they run up in severity. A line that announced nothing
 * is information: it is what a `printf` is for, and the alternative — a level
 * for "did not say" — is a fourth kind of line that nobody writing the
 * program ever meant to produce.
 */
export declare const LOG_LEVELS: readonly ["info", "warning", "error"];
export type LogLevel = typeof LOG_LEVELS[number];
/** A line of output, parted from the prefix it announced itself with. */
export interface LogLine {
    level: LogLevel;
    /** What the line says, with the prefix taken off a line that had one. */
    text: string;
}
/**
 * Split a line into what it announced itself as and what it actually says.
 *
 * The prefix is taken off rather than left in because it is shown as a badge
 * beside the line, and a line reading "Warning: Warning: sprite queue" is one
 * word of news and one of bookkeeping repeated.
 *
 * What is left is trimmed, and trimmed *after* the cut rather than before it:
 * the space between the prefix and the message is part of the prefix's
 * punctuation, so a body trimmed only at the ends of the original line would
 * still start with it — every announced line indented by one column against
 * every ordinary one. The ends are worth trimming for their own reason:
 * output formatted for a fixed-width debug screen arrives padded out to the
 * width of a row, often with a carriage return before the newline, and none
 * of that is the program's news.
 */
export declare function splitLogLevel(text: string): LogLine;
/** Which level a line of output announced itself as, `info` for none. */
export declare function parseLogLevel(text: string): LogLevel;
//# sourceMappingURL=emulator-log.d.ts.map