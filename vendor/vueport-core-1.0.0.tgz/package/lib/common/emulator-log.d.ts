export declare function formatLogTime(at: number): string;
export declare const LOG_LEVELS: readonly ["info", "warning", "error"];
export type LogLevel = typeof LOG_LEVELS[number];
export interface LogLine {
    level: LogLevel;
    text: string;
}
export declare function splitLogLevel(text: string): LogLine;
export declare function parseLogLevel(text: string): LogLevel;
//# sourceMappingURL=emulator-log.d.ts.map