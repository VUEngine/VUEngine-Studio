export declare const TOUCHED_READ = 1;
export declare const TOUCHED_WRITE = 2;
/**
 * How much save one record entry stands for. Finer than a cell and fixed, as the map's extent grows during
 * a session; widening it is then only a coarser fold of the same record. 128 bytes is one cell of the old
 * 16 KiB map, so nothing is lost; over the full 16 MiB window it is 128 KiB of marks
 */
export declare const TOUCH_BYTES = 128;
export declare function makeTouchRecord(window: number): Uint8Array;
export declare function markTouchRecord(record: Uint8Array, first: number, last: number, mark: number): void;
export interface FoldedTouchRecord {
    marks: Uint8Array;
    covered: Float32Array;
}
/**
 * The record as the map draws it, over `extent` bytes. Marks alone overstate large cells: sixteen 1 KB
 * records spread over 8 MB light sixteen cells of a 32x4 map that stand for a megabyte, sixty times what
 * was written, so the touched fraction is folded alongside for shading. Where a cell is one entry (every
 * commercial game) it is 0 or 1 and shading is a no-op
 */
export declare function foldTouchRecord(record: Uint8Array, extent: number, cells: number): FoldedTouchRecord;
export declare function touchFillPercent(covered: number): number;
//# sourceMappingURL=emulator-sram-map.d.ts.map