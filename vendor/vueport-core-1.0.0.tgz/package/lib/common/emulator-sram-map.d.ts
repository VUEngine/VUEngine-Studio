/**
 * The record behind the SRAM panel's save map, and how it folds into cells.
 *
 * Here rather than in the panel because it is the half of the map that can be
 * reasoned about on its own: bytes in, marks out, no machine and no DOM. The
 * panel is a Lumino widget and cannot be loaded outside a browser at all, so
 * anything of it worth measuring has to live somewhere a probe can reach —
 * see `tests/sram-map-probe.mjs`, which draws the map at sizes no game has
 * yet reached.
 */
/** What a map cell has seen. Written wins over read, which wins over neither. */
export declare const TOUCHED_READ = 1;
export declare const TOUCHED_WRITE = 2;
/**
 * How much of the save one entry of the touch record stands for.
 *
 * Finer than a map cell, and fixed rather than derived from what is being
 * shown, because the extent the map covers grows during a session: a game that
 * reaches further up the window than it had before widens the map, and a
 * record kept at the map's own granularity would have to be thrown away every
 * time that happened. Kept this way, widening the map is only a coarser fold
 * of the same record.
 *
 * 128 bytes is what one cell stood for when the window was 16 KiB and the map
 * was the whole of it, so nothing is lost against how the map used to read.
 * Over the full 16 MiB window it is 128 KiB of marks, which is nothing beside
 * the save itself.
 */
export declare const TOUCH_BYTES = 128;
/** A record covering `window` bytes of save. */
export declare function makeTouchRecord(window: number): Uint8Array;
/** Mark the record entries a run of bytes covers. */
export declare function markTouchRecord(record: Uint8Array, first: number, last: number, mark: number): void;
/** What one map cell says: what happened in it, and how much of it. */
export interface FoldedTouchRecord {
    /** Per cell, the `TOUCHED_*` marks anything inside it carried. */
    marks: Uint8Array;
    /** Per cell, how much of it was touched, from 0 to 1. */
    covered: Float32Array;
}
/**
 * The record as the map draws it, over `extent` bytes.
 *
 * The marks alone are not enough once a cell stands for more than a few
 * hundred bytes, and the difference is not small: a save of sixteen one-kilobyte
 * records spread over 8 MB lights sixteen cells of a 32x4 map, and those cells
 * stand for a megabyte between them. Lit-or-not, the map would be claiming
 * sixty times what the game wrote. So how much of a cell was touched is folded
 * alongside, and the map shades by it.
 *
 * Where a cell is one record entry — which is every commercial game, whose
 * saves the map covered exactly before any of this — `covered` is 0 or 1 and
 * the shading is a no-op.
 */
export declare function foldTouchRecord(record: Uint8Array, extent: number, cells: number): FoldedTouchRecord;
/**
 * How solid a cell is drawn, as a percentage, from how much of it was touched.
 *
 * Not the fraction itself: a cell holding one kilobyte of a megabyte would be
 * drawn at one percent and be indistinguishable from an untouched one, and
 * "something happened here" is the first thing the map is for. So the scale
 * starts well above nothing and rises by the square root, which spends more of
 * its range on the sparse end where the differences are.
 */
export declare function touchFillPercent(covered: number): number;
//# sourceMappingURL=emulator-sram-map.d.ts.map