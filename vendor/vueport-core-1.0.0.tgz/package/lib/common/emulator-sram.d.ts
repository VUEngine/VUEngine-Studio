export declare enum EmulatorSramInit {
    RANDOM = "random",
    ZEROES = "zeroes"
}
/**
 * AUTO answers on all of Game Pak RAM: a VB ROM cannot declare its save RAM size, so anything lower is a guess.
 * The smaller windows are for real-hardware builds and buy mirroring, so a game probing its save RAM size by
 * writing a pattern gets what the real cartridge would answer instead of 16 MiB. Window sizes, not chip sizes:
 * only the low byte of each halfword is wired, so a standard 8 KiB chip is the 16 KiB window.
 */
export declare enum EmulatorSramWindow {
    AUTO = "auto",
    W16K = "16k",
    W32K = "32k",
    W64K = "64k",
    W128K = "128k",
    W256K = "256k",
    W512K = "512k",
    W1M = "1m",
    W2M = "2m",
    W4M = "4m",
    W8M = "8m"
}
export declare enum EmulatorCompanionLocation {
    ROM = "rom",
    STORAGE = "storage"
}
export declare const EMULATOR_SAVE_SLOTS: readonly string[];
export declare const DEFAULT_SAVE_SLOT = "A";
export declare function emulatorSaveSlot(value: unknown): string;
//# sourceMappingURL=emulator-sram.d.ts.map