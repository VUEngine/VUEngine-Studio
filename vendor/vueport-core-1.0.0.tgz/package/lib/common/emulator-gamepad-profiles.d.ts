/**
 * What a physical controller's buttons do, per device.
 *
 * The Gamepad API hands a page raw indices — `buttons[3]`, `axes[1]` — and says
 * nothing about what the person holding the pad would call them. A *profile* is
 * the table that closes that gap for one device: which index drives which
 * Virtual Boy button, which drives which emulator action, and how far a stick
 * has to move before it counts as a press.
 *
 * The reason this is a table rather than the fixed mapping it replaces is that
 * the raw indices are not portable. Chrome and Firefox enumerate the same pad
 * differently — Firefox reports an extra axis, so every axis index after it
 * shifts by one — and a pad the browser does not recognize is reported in
 * whatever order its HID descriptor happens to list.
 *
 * What *is* portable is `Gamepad.mapping === 'standard'`: both browsers carry
 * their own remapping tables (Chromium's `gamepad_standard_mappings.cc`,
 * Firefox since bug 1542893) and normalize every pad they recognize to the W3C
 * standard layout. That covers the large majority of controllers, and it is why
 * the built-in presets here are *semantic* rather than per-device: they all sit
 * on the standard layout and differ only in which face button is which and what
 * it is called. A pad the browser does not recognize gets no guess at all — it
 * gets the guided walk-through in the Game Pads settings, whose result is
 * verified rather than inferred, and is then remembered for that device.
 *
 * Deliberately free of DOM: everything here takes plain data, so the whole
 * resolution path can be exercised from `tests/gamepad-profile-probe.mjs`.
 */
import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';
/** The mask bit one button contributes. */
export declare function vbKeyForButton(button: EmulatorGamePadButton): VbKey;
/**
 * The game pad codes the mappings speak, as the mask bits the core wants.
 *
 * Lives here rather than beside the keyboard handling because both the keyboard
 * and a physical pad have to end up as the same mask, and this is the module
 * both can reach without one depending on the other. Re-exported from
 * `emulator-input.ts`, which is where it used to live.
 */
export declare const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey>;
/**
 * One physical control: a button, or one end of an axis.
 *
 * An axis carries a direction because a stick is being used as a d-pad here,
 * and the two halves of one axis are two different buttons as far as the
 * Virtual Boy is concerned. `direction` is the sign of the deflection that
 * counts as pressed.
 */
export type GamepadSource = {
    kind: 'button';
    index: number;
} | {
    kind: 'axis';
    index: number;
    direction: -1 | 1;
};
/** A source as a string, for comparing and for using as a key. */
export declare function gamepadSourceId(source: GamepadSource): string;
/** Parse back what {@link gamepadSourceId} wrote; undefined if it is not one. */
export declare function parseGamepadSource(id: string): GamepadSource | undefined;
export declare function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean;
/**
 * Whose button glyphs a pad wears.
 *
 * Not cosmetic: the families disagree about which face button is which. A
 * Nintendo pad's A sits where an Xbox pad's B does, and a PlayStation pad calls
 * the same two ○ and ✕. Since a Virtual Boy's A is the *rightmost* face button,
 * "VB A" lands on a differently-named button depending on the family, and a
 * settings page that showed the wrong name would be worse than one that showed
 * a bare index.
 */
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';
/** One device's mapping, as it is stored and as the input loop reads it. */
export interface GamepadProfile {
    /**
     * What this profile is filed under: `vendor:product` in lower-case hex
     * ("054c:05c4") when the browser's id carries them, and the whole id
     * otherwise. See {@link gamepadDeviceKey}.
     */
    device: string;
    /** The name to show. The browser's id cleaned up, or the database's. */
    label?: string;
    /**
     * Which built-in preset this started as, so "reset to preset" knows where
     * back is. Absent for a profile built entirely by hand.
     */
    preset?: string;
    family: GamepadFamily;
    /**
     * More than one source per button on purpose: the standard presets put both
     * the d-pad and the left stick on the Virtual Boy's left cross, which is
     * what makes a modern pad feel right on a machine that has two of them.
     */
    buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;
    /** Emulator actions — pause, save state, rewind — on the pad. Usually empty. */
    actions?: Partial<Record<EmulatorAction, GamepadSource[]>>;
    /**
     * How far a stick must move before it reads as pressed, 0–1.
     *
     * Generous by default, because the control it stands in for is digital and
     * a partial press has no meaning to the machine.
     */
    deadZone: number;
}
/** What a stick deflection has to reach before it counts, when nothing says otherwise. */
export declare const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;
/** The narrowest and widest dead zone the settings will offer. */
export declare const GAMEPAD_DEAD_ZONE_RANGE: {
    min: number;
    max: number;
};
/** A preset offered in the settings, and applied on detection. */
export interface GamepadPreset {
    id: string;
    /** English; the settings localize it through {@link gamepadPresetLabel}. */
    name: string;
    family: GamepadFamily;
    /** Only offered by hand — never the automatic answer for a detected pad. */
    manualOnly?: boolean;
    /**
     * Set only on a preset written for one particular device rather than for
     * the standard layout: the name that device reports itself by, as
     * {@link gamepadName} reads it out of the browser's id. Such a preset is
     * offered, and detected, only for a pad the browser has *not* normalized —
     * its table is that device's raw HID order, which stops being right the
     * moment a browser learns the pad and remaps it to the standard layout.
     */
    deviceName?: RegExp;
    buttons: Record<EmulatorGamePadButton, GamepadSource[]>;
}
/**
 * What a preset is worth applying to.
 *
 * All the standard ones share one button table and differ only in family, since
 * the browser has already done the physical-to-semantic translation by the time
 * `mapping === 'standard'` holds. The family is what decides the glyphs, and
 * the glyphs are the whole visible difference.
 *
 * `standard-nofaceswap` is the exception that earns its place: a handful of
 * pads — mostly Nintendo layouts driven through a browser that maps them
 * positionally rather than by label — end up with A and B the other way round
 * from what is printed on the shell. It is offered by hand rather than
 * detected, because there is no way to tell from the id which it will be.
 *
 * The ones with a `deviceName` are the other kind: one device's raw order,
 * recorded off the device, for a pad no browser normalizes.
 */
export declare const GAMEPAD_PRESETS: GamepadPreset[];
export declare function gamepadPreset(id: string | undefined): GamepadPreset | undefined;
/** What the browser's id says about a device. */
export interface GamepadIdentity {
    /** Four lower-case hex digits, when the id carries them. */
    vendor?: string;
    product?: string;
    /** The readable part, with the identifiers stripped off both ends. */
    name: string;
    /** What a profile for this device is filed under. */
    key: string;
}
/**
 * Take a device apart into the name a person would read and the ids a lookup
 * needs.
 *
 * The two browsers write the same information in different shapes. Chrome:
 * `Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 05c4)`, with the
 * identifiers in a trailing parenthetical. Firefox: `054c-05c4-Wireless
 * Controller`, with them in front. Both are handled, and an id in neither shape
 * comes back as a name with no ids — which still works, since the whole id is
 * then the key.
 */
export declare function gamepadIdentity(id: string): GamepadIdentity;
/**
 * What to call a controller.
 *
 * The browser's id is built for matching rather than for reading, so this takes
 * the name back out and returns the id untouched if it is not in a shape it
 * recognizes: an odd name is better than an empty one.
 */
export declare function gamepadName(id: string): string;
/** What a profile for this device is filed under. */
export declare function gamepadDeviceKey(id: string): string;
/**
 * One entry of the harvested device database — see
 * `scripts/fetch-controller-db.mjs`. Keyed by `vendor:product`.
 */
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}
export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;
/**
 * Which family a pad belongs to.
 *
 * The database first, since it was harvested from people who had the device in
 * hand; then the vendor id; then the name. Everything falls back to `generic`,
 * which shows bare indices rather than a wrong glyph.
 */
export declare function detectGamepadFamily(identity: GamepadIdentity, database?: GamepadDatabase): GamepadFamily;
/** Just enough of a `Gamepad` to resolve a profile for it. */
export interface GamepadDescriptor {
    id: string;
    /** `'standard'` when the browser has normalized the pad; `''` when not. */
    mapping: string;
}
/** What resolution decided, and why — the settings page shows the reason. */
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    /**
     * Where the mapping came from. `stored` is the person's own, `preset` was
     * detected, and `unmapped` means the browser does not recognize the pad and
     * nothing has been recorded for it yet — the one case with no working
     * mapping, and the one the settings page asks somebody to fix.
     */
    origin: 'stored' | 'preset' | 'unmapped';
    /** The preset it would reset to, when there is one. */
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}
/**
 * Which preset a pad should start on, or undefined if it cannot be guessed.
 *
 * Undefined is the honest answer for a pad the browser has not normalized: its
 * indices are in whatever order the device's HID descriptor lists them, and no
 * table written here could know that order. Guessing would produce a mapping
 * that looks configured and is wrong, which is worse than one that asks to be
 * set up. See the note at the top of this file. The one exception is a device
 * whose raw order somebody has recorded — see `deviceName` on the presets.
 */
export declare function detectGamepadPreset(pad: GamepadDescriptor, database?: GamepadDatabase): GamepadPreset | undefined;
/**
 * The presets the settings offer for one pad.
 *
 * Every standard one; the A/B-swapped one only where the standard layout is
 * actually in force; and a device's own only for that device, and only while
 * the browser leaves it un-normalized — first, since it is the one that fits.
 */
export declare function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[];
/** Build a fresh profile for a device from a preset. */
export declare function profileFromPreset(preset: GamepadPreset, identity: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
/**
 * The mapping in force for one pad: what was stored for it, what its preset
 * says, or nothing at all.
 *
 * `stored` is whatever the settings hold, in no particular order; the first
 * entry filed under this device wins.
 */
export declare function resolveGamepadProfile(pad: GamepadDescriptor, stored?: GamepadProfile[], database?: GamepadDatabase): ResolvedGamepadProfile;
/**
 * Make a stored profile safe to read.
 *
 * Settings come from `localStorage` and from a file the person can edit, so
 * every field is treated as a suggestion: a missing dead zone, a button holding
 * something that is not a source, a device key from an older build. Anything
 * unusable is dropped rather than allowed to reach the input loop, where a
 * malformed index would silently stop a button working.
 */
export declare function normalizeProfile(profile: GamepadProfile, identity?: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
/** The buttons and axes of one pad, as much as reading it needs. */
export interface GamepadReading {
    buttons: readonly {
        pressed: boolean;
        value: number;
    }[];
    axes: readonly number[];
}
/** Whether one source is being held on a given reading. */
export declare function isSourcePressed(reading: GamepadReading, source: GamepadSource, deadZone: number): boolean;
/**
 * Every source currently held, as ids — what the settings page reads to notice
 * a button being pressed, and to light the picture up while one is held.
 *
 * Axes are reported through the profile's own dead zone so that what the
 * settings show is what the game will feel.
 */
export declare function pressedGamepadSources(reading: GamepadReading, deadZone: number): Set<string>;
/** What one pad is contributing this frame. */
export interface GamepadContribution {
    /** The Virtual Boy key mask. */
    keys: number;
    /** Emulator actions whose source is held — a set, so edges can be found. */
    actions: Set<EmulatorAction>;
}
/** Fold one pad's reading through its profile. */
export declare function readGamepadContribution(reading: GamepadReading, profile: GamepadProfile): GamepadContribution;
/**
 * Put a source on a button, replacing whatever was there.
 *
 * Replacing rather than adding, because this is what a person pressing a button
 * in the settings means: the one they just pressed, and not also the one that
 * happened to be there. The same source is taken off every *other* button
 * first, since one physical button driving two Virtual Boy buttons is never
 * what somebody wanted and is very hard to notice afterwards.
 */
export declare function assignGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton, source: GamepadSource): GamepadProfile;
/** The same, for an emulator action. */
export declare function assignGamepadAction(profile: GamepadProfile, target: EmulatorAction, source: GamepadSource): GamepadProfile;
/** Take everything off one button. */
export declare function clearGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton): GamepadProfile;
/** Take everything off one action. */
export declare function clearGamepadAction(profile: GamepadProfile, target: EmulatorAction): GamepadProfile;
/**
 * Store a profile, replacing any earlier one for the same device.
 *
 * The list is the whole setting, so this is what every edit goes through: it
 * keeps exactly one entry per device and leaves the others alone.
 */
export declare function storeGamepadProfile(stored: GamepadProfile[], profile: GamepadProfile): GamepadProfile[];
/** Forget a device's profile, so it goes back to whatever is detected. */
export declare function forgetGamepadProfile(stored: GamepadProfile[], device: string): GamepadProfile[];
//# sourceMappingURL=emulator-gamepad-profiles.d.ts.map