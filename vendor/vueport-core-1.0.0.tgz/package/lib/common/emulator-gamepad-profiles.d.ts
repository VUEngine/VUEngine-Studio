/**
 * What a physical controller's buttons do, per device.
 *
 * The Gamepad API hands a page raw indices — `buttons[3]`, `axes[1]` — and says
 * nothing about what the person holding the pad would call them. A *profile* is
 * the table that closes that gap for one device: which index drives which
 * Virtual Boy button, which drives which emulator action, and how far a stick
 * has to move before it counts as a press.
 *
 * The reason this is a table rather than the fixed mapping it replaces is that
 * the raw indices are not portable. Chrome and Firefox enumerate the same pad
 * differently — Firefox reports an extra axis, so every axis index after it
 * shifts by one — and a pad the browser does not recognize is reported in
 * whatever order its HID descriptor happens to list.
 *
 * What *is* portable is `Gamepad.mapping === 'standard'`: both browsers carry
 * their own remapping tables (Chromium's `gamepad_standard_mappings.cc`,
 * Firefox since bug 1542893) and normalize every pad they recognize to the W3C
 * standard layout. That covers the large majority of controllers, and it is why
 * the built-in presets here are *semantic* rather than per-device: they all sit
 * on the standard layout and differ only in which face button is which and what
 * it is called. A pad the browser does not recognize gets no guess at all — it
 * gets the guided walk-through in the Game Pads settings, whose result is
 * verified rather than inferred, and is then remembered for that device.
 *
 * Deliberately free of DOM: everything here takes plain data, so the whole
 * resolution path can be exercised from `tests/gamepad-profile-probe.mjs`.
 */
import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';
/** The mask bit one button contributes. */
export declare function vbKeyForButton(button: EmulatorGamePadButton): VbKey;
/**
 * The game pad codes the mappings speak, as the mask bits the core wants.
 *
 * Lives here rather than beside the keyboard handling because both the keyboard
 * and a physical pad have to end up as the same mask, and this is the module
 * both can reach without one depending on the other. Re-exported from
 * `emulator-input.ts`, which is where it used to live.
 */
export declare const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey>;
/**
 * One physical control: a button, one end of an axis, or one direction of a
 * hat switch.
 *
 * An axis carries a direction because a stick is being used as a d-pad here,
 * and the two halves of one axis are two different buttons as far as the
 * Virtual Boy is concerned. `direction` is the sign of the deflection that
 * counts as pressed.
 *
 * A hat is a d-pad that the browser hands over as a single axis rather than as
 * four buttons — Chrome and Firefox both do this for a pad they have no mapping
 * for, the 8BitDo 64 among them. The axis then holds one of eight positions,
 * evenly spaced from -1 (up) clockwise to 1 (up-left), and rests *outside*
 * -1…1 when nothing is pressed (23/7 on the 8BitDo 64, in both). Read as a
 * stick it is nonsense: resting, it looks like a full deflection; and left and
 * right sit at 5/7 and -3/7, one of which is under any sensible dead zone and
 * the other of which is the same sign as resting, so it never shows up as a
 * new press.
 */
export type GamepadSource = {
    kind: 'button';
    index: number;
} | {
    kind: 'axis';
    index: number;
    direction: -1 | 1;
} | {
    kind: 'hat';
    index: number;
    direction: GamepadHatDirection;
};
export type GamepadHatDirection = 'up' | 'right' | 'down' | 'left';
/** A source as a string, for comparing and for using as a key. */
export declare function gamepadSourceId(source: GamepadSource): string;
/** Parse back what {@link gamepadSourceId} wrote; undefined if it is not one. */
export declare function parseGamepadSource(id: string): GamepadSource | undefined;
export declare function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean;
/**
 * Whose button glyphs a pad wears.
 *
 * Not cosmetic: the families disagree about which face button is which. A
 * Nintendo pad's A sits where an Xbox pad's B does, and a PlayStation pad calls
 * the same two ○ and ✕. Since a Virtual Boy's A is the *rightmost* face button,
 * "VB A" lands on a differently-named button depending on the family, and a
 * settings page that showed the wrong name would be worse than one that showed
 * a bare index.
 */
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';
/**
 * The browser engine a raw pad is recorded under. A raw recording has to be
 * kept apart between them: the 8BitDo 64 shows its d-pad as axis 0 of 7 in
 * Firefox and as a later axis in Chrome.
 *
 * `sdl` is not a browser: it is the desktop shell reading pads through SDL
 * instead of through its webview, which numbers a raw pad SDL's way. A pad
 * read like that says so itself — see `engine` on {@link GamepadDescriptor},
 * which the desktop's pads carry — since the webview it runs in is WebKit.
 */
export type GamepadEngine = 'chromium' | 'gecko' | 'webkit' | 'sdl';
/**
 * The engine this page runs in; undefined outside a browser.
 *
 * Asked of the user agent rather than read off the pad's id, although the ids
 * do differ in shape: Safari writes `vendor-product-name` like Firefox, so a
 * pad whose ids happen to be four digits long would pass for Firefox.
 */
export declare function hostGamepadEngine(): GamepadEngine | undefined;
/**
 * The operating system a raw pad is recorded on. As much a part of a raw
 * layout as the engine: each engine reads pads through a different backend
 * per system — IOKit on macOS, Raw Input on Windows, joydev on Linux — and
 * each backend numbers what it finds its own way.
 */
export type GamepadPlatform = 'macos' | 'windows' | 'linux' | 'chromeos' | 'android' | 'ios';
/**
 * The system this page runs on, as far as the browser says; undefined outside
 * one. The id carries no trace of it, so it is asked of `navigator`.
 */
export declare function hostGamepadPlatform(): GamepadPlatform | undefined;
/**
 * What a pad button can do outside the game and outside the emulator: open
 * the host's command palette. The host decides whether it has one — the
 * standalone build does, a host without one leaves the binding unused — and
 * reads it on its own loop, since it has to work with no game running and
 * while the palette it opened is taking the input.
 */
export type GamepadUiAction = 'commandPalette';
export declare const GAMEPAD_UI_ACTIONS: readonly GamepadUiAction[];
/**
 * Playing whichever macro sits in a slot — see `setSlot` in the macro store.
 * Eight, as the Macros panel numbers them.
 */
export type GamepadMacroAction = 'macro1' | 'macro2' | 'macro3' | 'macro4' | 'macro5' | 'macro6' | 'macro7' | 'macro8';
export declare const GAMEPAD_MACRO_ACTIONS: readonly GamepadMacroAction[];
/** The slot (1-based) a macro action plays, or undefined for any other action. */
export declare function gamepadMacroSlot(action: string): number | undefined;
/** The action that plays a slot (1-based). */
export declare function gamepadMacroAction(slot: number): GamepadMacroAction;
/** Anything a pad control can be bound to besides a Virtual Boy button. */
export type GamepadPadAction = EmulatorAction | GamepadUiAction | GamepadMacroAction;
/** The buttons a pad control is bound to, by Virtual Boy button — plain or on turbo. */
export type GamepadButtonMap = Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;
/** One device's mapping, as it is stored and as the input loop reads it. */
export interface GamepadProfile {
    /**
     * What this profile is filed under: `vendor:product` in lower-case hex
     * ("054c:05c4") when the browser's id carries them, and the whole id
     * otherwise. See {@link gamepadDeviceKey}.
     */
    device: string;
    /** The name to show. The browser's id cleaned up, or the database's. */
    label?: string;
    /**
     * Which built-in preset this started as, so "reset to preset" knows where
     * back is. Absent for a profile built entirely by hand.
     */
    preset?: string;
    family: GamepadFamily;
    /**
     * More than one source per button on purpose: the standard presets put both
     * the d-pad and the left stick on the Virtual Boy's left cross, which is
     * what makes a modern pad feel right on a machine that has two of them.
     */
    buttons: GamepadButtonMap;
    /**
     * Virtual Boy buttons held on turbo: pressed and released over and over
     * for as long as the source is held. Same shape as `buttons`, and a source
     * drives one or the other, never both.
     */
    turbo?: GamepadButtonMap;
    /**
     * Emulator actions — pause, save state, rewind — on the pad, and the
     * host's own (see {@link GamepadUiAction}), and the macro slots (see
     * {@link GamepadMacroAction}). Usually only the host's.
     */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /**
     * How far a stick must move before it reads as pressed, 0–1.
     *
     * Generous by default, because the control it stands in for is digital and
     * a partial press has no meaning to the machine.
     */
    deadZone: number;
}
/** What a stick deflection has to reach before it counts, when nothing says otherwise. */
export declare const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;
/** The narrowest and widest dead zone the settings will offer. */
export declare const GAMEPAD_DEAD_ZONE_RANGE: {
    min: number;
    max: number;
};
/** A preset offered in the settings, and applied on detection. */
export interface GamepadPreset {
    id: string;
    /** English; the settings localize it through {@link gamepadPresetLabel}. */
    name: string;
    family: GamepadFamily;
    /** Only offered by hand — never the automatic answer for a detected pad. */
    manualOnly?: boolean;
    /**
     * Set only on a preset written for one particular device rather than for
     * the standard layout — a bundled profile file, see
     * {@link GamepadProfileFile}. Such a preset is offered, and detected, only
     * for the pad it was recorded on, and only while the browser reports that
     * pad the way it did then.
     */
    match?: GamepadDeviceMatch;
    /** The dead zone it was recorded with, when it is not the default. */
    deadZone?: number;
    buttons: GamepadButtonMap;
    /** Buttons held on turbo; see {@link GamepadProfile.turbo}. */
    turbo?: GamepadButtonMap;
    /** What the pad's other controls do — the emulator's actions, and Home opening the palette. */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /**
     * What a device's controls are printed with, by source id ("b8": "C↑").
     * For the settings page: the families' names are the standard layout's,
     * and a pad whose layout is not one of theirs — an N64 pad, its C buttons
     * on the standard layout's Back and face buttons — would be labelled with
     * buttons it does not have.
     */
    labels?: Record<string, string>;
}
/**
 * Which one device a bundled profile is for, and how the browser showed it.
 *
 * The how matters as much as the which. A pad the browser has not normalized
 * arrives in its own HID order, and a table recorded in that order stops being
 * right the moment a browser learns the pad and remaps it to the standard
 * layout — so `mapping` has to agree. And the browsers disagree among
 * themselves about a raw pad: Firefox reports an extra axis on some, which
 * shifts every index after it, and a hat is an axis in one and four buttons in
 * another. The counts are what catch that: a pad showing a different number of
 * buttons or axes than it did when recorded is not laid out the same way, and
 * gets no guess rather than a wrong one.
 */
export interface GamepadDeviceMatch {
    /** `vendor:product`, as {@link gamepadDeviceKey} files it. */
    device?: string;
    /** The name the device reports, as {@link gamepadName} reads it; any case. */
    name?: string;
    /** `Gamepad.mapping` when it was recorded: `'standard'`, or `''` for raw. */
    mapping: string;
    /**
     * The engine it was recorded in. Set, the preset applies in that engine
     * only: two engines can show a raw pad with the same counts and still in a
     * different order. Absent means any — right only for a pad whose layout
     * is known to be the same everywhere, like the VB USB Adapter's buttons.
     */
    engine?: GamepadEngine;
    /** The system it was recorded on; absent means any, as with `engine`. */
    platform?: GamepadPlatform;
    buttons?: number;
    axes?: number;
}
/**
 * One controller's mapping as a file: what the Game Pads settings export, and
 * what ships with VUEPort in `src/data/gamepad-profiles/`.
 *
 * The same shape both ways on purpose — bundling a mapping somebody recorded is
 * dropping their export into that folder and listing it in
 * {@link BUNDLED_GAMEPAD_PROFILES}, with nothing to translate in between.
 */
export interface GamepadProfileFile {
    format: typeof GAMEPAD_PROFILE_FORMAT;
    version: 1;
    /** The preset id it becomes; a stored profile's `preset` names it. */
    id: string;
    name: string;
    family: GamepadFamily;
    match: GamepadDeviceMatch;
    deadZone: number;
    buttons: GamepadButtonMap;
    /** Buttons held on turbo; see {@link GamepadProfile.turbo}. */
    turbo?: GamepadButtonMap;
    /** The emulator's and the host's actions; see {@link gamepadProfileFile}. */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /** What the controls are printed with; see {@link GamepadPreset.labels}. */
    labels?: Record<string, string>;
}
export declare const GAMEPAD_PROFILE_FORMAT = "vueport-gamepad-profile";
/**
 * What a preset is worth applying to.
 *
 * All the standard ones share one button table and differ only in family, since
 * the browser has already done the physical-to-semantic translation by the time
 * `mapping === 'standard'` holds. The family is what decides the glyphs, and
 * the glyphs are the whole visible difference.
 *
 * `standard-nofaceswap` is the exception that earns its place: a handful of
 * pads — mostly Nintendo layouts driven through a browser that maps them
 * positionally rather than by label — end up with A and B the other way round
 * from what is printed on the shell. It is offered by hand rather than
 * detected, because there is no way to tell from the id which it will be.
 *
 * The bundled ones are the other kind: one device's mapping, recorded off the
 * device and matched by its `match`.
 */
export declare const GAMEPAD_PRESETS: GamepadPreset[];
export declare function gamepadPreset(id: string | undefined): GamepadPreset | undefined;
/** What the browser's id says about a device. */
export interface GamepadIdentity {
    /** Four lower-case hex digits, when the id carries them. */
    vendor?: string;
    product?: string;
    /** The readable part, with the identifiers stripped off both ends. */
    name: string;
    /** What a profile for this device is filed under. */
    key: string;
}
/**
 * Take a device apart into the name a person would read and the ids a lookup
 * needs.
 *
 * The two browsers write the same information in different shapes. Chrome:
 * `Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 05c4)`, with the
 * identifiers in a trailing parenthetical. Firefox: `054c-05c4-Wireless
 * Controller`, with them in front. Both are handled, and an id in neither shape
 * comes back as a name with no ids — which still works, since the whole id is
 * then the key.
 */
export declare function gamepadIdentity(id: string): GamepadIdentity;
/**
 * What to call a controller.
 *
 * The browser's id is built for matching rather than for reading, so this takes
 * the name back out and returns the id untouched if it is not in a shape it
 * recognizes: an odd name is better than an empty one.
 */
export declare function gamepadName(id: string): string;
/** What a profile for this device is filed under. */
export declare function gamepadDeviceKey(id: string): string;
/**
 * One entry of the harvested device database — see
 * `scripts/fetch-controller-db.mjs`. Keyed by `vendor:product`.
 */
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}
export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;
/**
 * Which family a pad belongs to.
 *
 * The database first, since it was harvested from people who had the device in
 * hand; then the vendor id; then the name. Everything falls back to `generic`,
 * which shows bare indices rather than a wrong glyph.
 */
export declare function detectGamepadFamily(identity: GamepadIdentity, database?: GamepadDatabase): GamepadFamily;
/** Just enough of a `Gamepad` to resolve a profile for it. */
export interface GamepadDescriptor {
    id: string;
    /** `'standard'` when the browser has normalized the pad; `''` when not. */
    mapping: string;
    /** Only counted, to tell layouts apart — see {@link GamepadDeviceMatch}. */
    buttons?: ArrayLike<unknown>;
    axes?: ArrayLike<unknown>;
    /** The engine and system it is seen in; the host's own when not given. */
    engine?: GamepadEngine;
    platform?: GamepadPlatform;
}
/** What resolution decided, and why — the settings page shows the reason. */
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    /**
     * Where the mapping came from. `stored` is the person's own, `preset` was
     * detected, and `unmapped` means the browser does not recognize the pad and
     * nothing has been recorded for it yet — the one case with no working
     * mapping, and the one the settings page asks somebody to fix.
     */
    origin: 'stored' | 'preset' | 'unmapped';
    /** The preset it would reset to, when there is one. */
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}
/**
 * Which preset a pad should start on, or undefined if it cannot be guessed.
 *
 * Undefined is the honest answer for a pad the browser has not normalized: its
 * indices are in whatever order the device's HID descriptor lists them, and no
 * table written here could know that order. Guessing would produce a mapping
 * that looks configured and is wrong, which is worse than one that asks to be
 * set up. See the note at the top of this file. The exception is a device
 * whose mapping somebody has recorded and bundled — see `match` on the presets
 * — which wins over the general presets for a normalized pad too.
 */
export declare function detectGamepadPreset(pad: GamepadDescriptor, database?: GamepadDatabase): GamepadPreset | undefined;
/**
 * The presets the settings offer for one pad.
 *
 * Every standard one; the A/B-swapped one only where the standard layout is
 * actually in force; and a device's own only for that device, and only while
 * the browser shows it the way it was recorded — first, since it is the one
 * that fits.
 */
export declare function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[];
/** Build a fresh profile for a device from a preset. */
export declare function profileFromPreset(preset: GamepadPreset, identity: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
/**
 * A profile as a file for bundling, recorded off the pad it is in force for.
 *
 * Everything bound travels: the buttons, and the actions with them — Home
 * opening the palette, and the emulator's own, rewind and the rest. A profile
 * that ships is somebody's whole setup of a pad, and one that leaves the
 * other controls doing nothing is the worse default for the next person.
 */
export declare function gamepadProfileFile(profile: GamepadProfile, pad: GamepadDescriptor): GamepadProfileFile;
/** Read a profile file back as a preset; undefined if it is not one. */
export declare function gamepadPresetFromFile(file: unknown): GamepadPreset | undefined;
/**
 * The mapping in force for one pad: what was stored for it, what its preset
 * says, or nothing at all.
 *
 * `stored` is whatever the settings hold, in no particular order; the first
 * entry filed under this device wins.
 */
export declare function resolveGamepadProfile(pad: GamepadDescriptor, stored?: GamepadProfile[], database?: GamepadDatabase): ResolvedGamepadProfile;
/**
 * Make a stored profile safe to read.
 *
 * Settings come from `localStorage` and from a file the person can edit, so
 * every field is treated as a suggestion: a missing dead zone, a button holding
 * something that is not a source, a preset id that names no preset. Anything
 * unusable is dropped rather than allowed to reach the input loop, where a
 * malformed index would silently stop a button working.
 */
export declare function normalizeProfile(profile: GamepadProfile, identity?: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
/** The buttons and axes of one pad, as much as reading it needs. */
export interface GamepadReading {
    buttons: readonly {
        pressed: boolean;
        value: number;
    }[];
    axes: readonly number[];
}
/** Whether one source is being held on a given reading. */
export declare function isSourcePressed(reading: GamepadReading, source: GamepadSource, deadZone: number): boolean;
/**
 * Every source currently held, as ids — what the settings page reads to notice
 * a button being pressed, and to light the picture up while one is held.
 *
 * Axes are reported through the profile's own dead zone so that what the
 * settings show is what the game will feel.
 *
 * `hats` is which axes are hat switches. It is the caller's to keep across
 * readings, and this grows it: a hat can only be told from a stick while it
 * rests, out of a stick's range, and the reading that matters is the later one
 * where a direction is pressed and the value looks like any other deflection.
 * A pad's d-pad is at rest long before anyone presses it, so by the time it is
 * pressed its axis is already known.
 */
export declare function pressedGamepadSources(reading: GamepadReading, deadZone: number, hats?: Set<number>): Set<string>;
/** What one pad is contributing this frame. */
export interface GamepadContribution {
    /** The Virtual Boy key mask. */
    keys: number;
    /** Emulator actions whose source is held — a set, so edges can be found. */
    actions: Set<EmulatorAction>;
    /** The host's own actions whose source is held, kept apart from the emulator's. */
    uiActions: Set<GamepadUiAction>;
    /** The Virtual Boy buttons held on turbo, as a key mask. */
    turboKeys: number;
    /** The macro slots (1-based) whose source is held. */
    macroSlots: Set<number>;
}
/** Fold one pad's reading through its profile. */
export declare function readGamepadContribution(reading: GamepadReading, profile: GamepadProfile): GamepadContribution;
/**
 * Put a source on a button, replacing whatever was there — or, with `add`,
 * beside it.
 *
 * Replacing by default, because this is what a person pressing a button in the
 * settings usually means: the one they just pressed, and not also the one that
 * happened to be there. Adding is the deliberate second step, for a d-pad and a
 * stick on the same cross. Either way the same source is taken off everything
 * else first; see {@link withSourceFreed}.
 */
export declare function assignGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton, source: GamepadSource, add?: boolean): GamepadProfile;
/** The same, for a button held on turbo. */
export declare function assignGamepadTurbo(profile: GamepadProfile, target: EmulatorGamePadButton, source: GamepadSource, add?: boolean): GamepadProfile;
/** The same, for an emulator action or a macro slot. */
export declare function assignGamepadAction(profile: GamepadProfile, target: GamepadPadAction, source: GamepadSource, add?: boolean): GamepadProfile;
/**
 * Take one source off whatever it drives — the way to drop one of several on a
 * control. Wherever it is, since a source only ever drives one control.
 */
export declare function removeGamepadSource(profile: GamepadProfile, source: GamepadSource): GamepadProfile;
/** Take everything off one button. */
export declare function clearGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton): GamepadProfile;
/** Take everything off one turbo button. */
export declare function clearGamepadTurbo(profile: GamepadProfile, target: EmulatorGamePadButton): GamepadProfile;
/** Take everything off one action. */
export declare function clearGamepadAction(profile: GamepadProfile, target: GamepadPadAction): GamepadProfile;
/**
 * Store a profile, replacing any earlier one for the same device.
 *
 * The list is the whole setting, so this is what every edit goes through: it
 * keeps exactly one entry per device and leaves the others alone.
 */
export declare function storeGamepadProfile(stored: GamepadProfile[], profile: GamepadProfile): GamepadProfile[];
/** Whether a profile binds every control, and sets the dead zone, exactly as the preset does. */
export declare function gamepadProfileMatchesPreset(profile: GamepadProfile, preset: GamepadPreset): boolean;
/** Forget a device's profile, so it goes back to whatever is detected. */
export declare function forgetGamepadProfile(stored: GamepadProfile[], device: string): GamepadProfile[];
//# sourceMappingURL=emulator-gamepad-profiles.d.ts.map