/**
 * What a physical controller's buttons do, per device. The Gamepad API gives raw indices, and they are not portable:
 * Chrome and Firefox enumerate the same pad differently (Firefox reports an extra axis, shifting every index after
 * it), and an unrecognized pad comes in its HID descriptor's order. Portable is `mapping === 'standard'`: both
 * browsers normalize pads they recognize (Chromium's gamepad_standard_mappings.cc, Firefox since bug 1542893), so the
 * built-in presets are semantic, on the standard layout, differing only in face buttons and names. An unrecognized pad
 * gets no guess but the guided walk-through in the Game Pads settings, remembered per device.
 * Free of DOM, so the whole resolution path can be exercised from tests/gamepad-profile-probe.mjs.
 */
import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';
export declare function vbKeyForButton(button: EmulatorGamePadButton): VbKey;
export declare const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey>;
/**
 * One physical control: a button, one end of an axis, or one direction of a hat switch. An axis carries the sign of
 * the deflection that counts as pressed, as the two halves of a stick are two VB buttons. A hat is a d-pad given as a
 * single axis (Chrome and Firefox do this for unmapped pads, e.g. the 8BitDo 64): eight positions evenly spaced from
 * -1 (up) clockwise to 1 (up-left), resting outside -1…1 (23/7 on the 8BitDo 64, in both). Read as a stick it is
 * nonsense: resting looks like full deflection, left and right sit at 5/7 and -3/7.
 */
export type GamepadSource = {
    kind: 'button';
    index: number;
} | {
    kind: 'axis';
    index: number;
    direction: -1 | 1;
} | {
    kind: 'hat';
    index: number;
    direction: GamepadHatDirection;
};
export type GamepadHatDirection = 'up' | 'right' | 'down' | 'left';
export declare function gamepadSourceId(source: GamepadSource): string;
export declare function parseGamepadSource(id: string): GamepadSource | undefined;
export declare function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean;
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';
export type GamepadEngine = 'chromium' | 'gecko' | 'webkit' | 'sdl';
export declare function hostGamepadEngine(): GamepadEngine | undefined;
export type GamepadPlatform = 'macos' | 'windows' | 'linux' | 'chromeos' | 'android' | 'ios';
export declare function hostGamepadPlatform(): GamepadPlatform | undefined;
export type GamepadUiAction = 'commandPalette';
export declare const GAMEPAD_UI_ACTIONS: readonly GamepadUiAction[];
export type GamepadMacroAction = 'macro1' | 'macro2' | 'macro3' | 'macro4' | 'macro5' | 'macro6' | 'macro7' | 'macro8';
export declare const GAMEPAD_MACRO_ACTIONS: readonly GamepadMacroAction[];
export declare function gamepadMacroSlot(action: string): number | undefined;
export declare function gamepadMacroAction(slot: number): GamepadMacroAction;
export type GamepadPadAction = EmulatorAction | GamepadUiAction | GamepadMacroAction;
export type GamepadButtonMap = Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;
export interface GamepadProfile {
    device: string;
    label?: string;
    preset?: string;
    family: GamepadFamily;
    buttons: GamepadButtonMap;
    turbo?: GamepadButtonMap;
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    deadZone: number;
}
export declare const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;
export declare const GAMEPAD_DEAD_ZONE_RANGE: {
    min: number;
    max: number;
};
export interface GamepadPreset {
    id: string;
    name: string;
    family: GamepadFamily;
    manualOnly?: boolean;
    match?: GamepadDeviceMatch;
    deadZone?: number;
    buttons: GamepadButtonMap;
    turbo?: GamepadButtonMap;
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    labels?: Record<string, string>;
}
export interface GamepadDeviceMatch {
    device?: string;
    name?: string;
    mapping: string;
    engine?: GamepadEngine;
    platform?: GamepadPlatform;
    buttons?: number;
    axes?: number;
}
export interface GamepadProfileFile {
    format: typeof GAMEPAD_PROFILE_FORMAT;
    version: 1;
    id: string;
    name: string;
    family: GamepadFamily;
    match: GamepadDeviceMatch;
    deadZone: number;
    buttons: GamepadButtonMap;
    turbo?: GamepadButtonMap;
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    labels?: Record<string, string>;
}
export declare const GAMEPAD_PROFILE_FORMAT = "vueport-gamepad-profile";
/**
 * The standard presets share one button table and differ only in family, which decides the glyphs.
 * `standard-nofaceswap` is for pads (mostly Nintendo layouts mapped positionally by the browser) that end up with A
 * and B swapped against the print; offered by hand only, as the id cannot tell. The bundled ones are one device's
 * recorded mapping, matched by `match`.
 */
export declare const GAMEPAD_PRESETS: GamepadPreset[];
export declare function gamepadPreset(id: string | undefined): GamepadPreset | undefined;
export interface GamepadIdentity {
    vendor?: string;
    product?: string;
    name: string;
    key: string;
}
export declare function gamepadIdentity(id: string): GamepadIdentity;
export declare function gamepadName(id: string): string;
export declare function gamepadDeviceKey(id: string): string;
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}
export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;
export declare function detectGamepadFamily(identity: GamepadIdentity, database?: GamepadDatabase): GamepadFamily;
export interface GamepadDescriptor {
    id: string;
    mapping: string;
    buttons?: ArrayLike<unknown>;
    axes?: ArrayLike<unknown>;
    engine?: GamepadEngine;
    platform?: GamepadPlatform;
}
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    origin: 'stored' | 'preset' | 'unmapped';
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}
export declare function detectGamepadPreset(pad: GamepadDescriptor, database?: GamepadDatabase): GamepadPreset | undefined;
export declare function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[];
export declare function profileFromPreset(preset: GamepadPreset, identity: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
export declare function gamepadProfileFile(profile: GamepadProfile, pad: GamepadDescriptor): GamepadProfileFile;
export declare function gamepadPresetFromFile(file: unknown): GamepadPreset | undefined;
export declare function resolveGamepadProfile(pad: GamepadDescriptor, stored?: GamepadProfile[], database?: GamepadDatabase): ResolvedGamepadProfile;
export declare function normalizeProfile(profile: GamepadProfile, identity?: GamepadIdentity, database?: GamepadDatabase): GamepadProfile;
export interface GamepadReading {
    buttons: readonly {
        pressed: boolean;
        value: number;
    }[];
    axes: readonly number[];
}
export declare function isSourcePressed(reading: GamepadReading, source: GamepadSource, deadZone: number): boolean;
/**
 * Every source held, as ids, for the settings page to notice presses and light up held controls. Axes go through the
 * profile's dead zone, so the settings show what the game feels. `hats` is the caller's to keep across readings and
 * this grows it: a hat can only be told from a stick at rest (out of a stick's range), and a d-pad rests long before
 * anyone presses it.
 */
export declare function pressedGamepadSources(reading: GamepadReading, deadZone: number, hats?: Set<number>): Set<string>;
export interface GamepadContribution {
    keys: number;
    actions: Set<EmulatorAction>;
    uiActions: Set<GamepadUiAction>;
    turboKeys: number;
    macroSlots: Set<number>;
}
export declare function readGamepadContribution(reading: GamepadReading, profile: GamepadProfile): GamepadContribution;
export declare function assignGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton, source: GamepadSource, add?: boolean): GamepadProfile;
export declare function assignGamepadTurbo(profile: GamepadProfile, target: EmulatorGamePadButton, source: GamepadSource, add?: boolean): GamepadProfile;
export declare function assignGamepadAction(profile: GamepadProfile, target: GamepadPadAction, source: GamepadSource, add?: boolean): GamepadProfile;
export declare function removeGamepadSource(profile: GamepadProfile, source: GamepadSource): GamepadProfile;
export declare function clearGamepadButton(profile: GamepadProfile, target: EmulatorGamePadButton): GamepadProfile;
export declare function clearGamepadTurbo(profile: GamepadProfile, target: EmulatorGamePadButton): GamepadProfile;
export declare function clearGamepadAction(profile: GamepadProfile, target: GamepadPadAction): GamepadProfile;
export declare function storeGamepadProfile(stored: GamepadProfile[], profile: GamepadProfile): GamepadProfile[];
export declare function gamepadProfileMatchesPreset(profile: GamepadProfile, preset: GamepadPreset): boolean;
export declare function forgetGamepadProfile(stored: GamepadProfile[], device: string): GamepadProfile[];
//# sourceMappingURL=emulator-gamepad-profiles.d.ts.map