export declare const PERF_DIAGNOSTICS: boolean;
//# sourceMappingURL=perf-diagnostics.d.ts.map