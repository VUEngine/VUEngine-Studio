/**
 * What drew a pixel of a frame buffer, as the core keeps it while asked to (`VbMachine.keepOrigins` in the probe,
 * `Sim.setPixelOrigins` in the app). Two 32-bit words a pixel, laid out in the core's `vip.c` (`PixelOrigins`):
 *
 *     what   bits  0-2  kind: 0 unknown, 1 backdrop, 2 BG map cell,
 *                       3 overplane cell, 4 object, 5 CPU write, 6 debug write
 *            bits  3-7  world
 *            bits  8-19 character
 *            bits 20-25 pixel within the character as stored, y * 8 + x
 *            bits 26-27 flip (hflp << 1 | vflp)
 *            bits 28-29 the character's pixel value, the backdrop's shade,
 *                       or the value written
 *            bits 30-31 palette (GPLTn for cells, JPLTn for objects)
 *     where  cells: BG map cell index (segment << 12 | cell); objects: the
 *            object's index; with bit 24 set and the VB Color source byte in
 *            bits 16-23 where VB Color drew one, and in bits 25-26 what chose
 *            it: 1 the cell's or object's color attribute, 2 the character's
 *            color attribute (CCEN), 3 a pixel color slot (PCE) — bit 27 set
 *            where a world palette offset was added. For the backdrop, bits
 *            25-26 are 1 for CBKPAL and 2 for the backdrop row table.
 *            Writes: the PC.
 */
export type VbColorSource = 'attribute' | 'character' | 'slot' | 'register' | 'rows';
export type VbPixelOriginKind = 'unknown' | 'backdrop' | 'cell' | 'overplane' | 'object' | 'cpu' | 'debugger';
export interface VbPixelOrigin {
    kind: VbPixelOriginKind;
    world?: number;
    bgmap?: {
        segment: number;
        x: number;
        y: number;
        address: number;
    };
    object?: {
        index: number;
        address: number;
    };
    character?: number;
    pixel?: {
        x: number;
        y: number;
    };
    flip?: {
        h: boolean;
        v: boolean;
    };
    value: number;
    palette?: string;
    vbc?: number;
    vbcSource?: VbColorSource;
    vbcOffset?: boolean;
    pc?: number;
}
export declare function decodeOrigin(what: number, where: number): VbPixelOrigin;
export declare function originSource(origin: VbPixelOrigin): string;
export declare function decodeOriginRuns(runs: Uint32Array, pixels: number): Uint32Array;
export interface VbScreenBox {
    x: number;
    y: number;
    width: number;
    height: number;
    parallax: number;
}
export interface VbCellArea {
    segment: number;
    x: number;
    y: number;
    cols: number;
    rows: number;
    near?: VbScreenBox;
}
export interface VbCharacterSpan {
    from: number;
    to: number;
    near?: VbScreenBox;
}
export type VbPixelSource = {
    kind: 'world';
    world: number;
} | {
    kind: 'object';
    object: number;
} | {
    kind: 'cell';
    address: number;
} | {
    kind: 'character';
    character: number;
} | {
    kind: 'vbcPalette';
    palette: number;
} | {
    kind: 'sprites';
    cells: VbCellArea[];
    characters: VbCharacterSpan[];
    worlds: number[];
    objects: number[];
};
export declare function originDrawnBy(what: number, where: number, source: VbPixelSource, x?: number, y?: number, eye?: 0 | 1): boolean;
//# sourceMappingURL=vb-pixel-origin.d.ts.map