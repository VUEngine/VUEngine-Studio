/**
 * What drew a pixel of a frame buffer, as the core keeps it while asked to
 * (`VbMachine.keepOrigins` in the probe, `Sim.setPixelOrigins` in the app):
 * the world, the BG map cell or object, the character and which of its
 * pixels, the palette — or the code that wrote the pixel into the frame
 * buffer itself.
 *
 * Two 32-bit words a pixel, laid out in the core's `vip.c` (`PixelOrigins`):
 *
 *     what   bits  0-2  kind: 0 unknown, 1 backdrop, 2 BG map cell,
 *                       3 overplane cell, 4 object, 5 CPU write, 6 debug write
 *            bits  3-7  world
 *            bits  8-19 character
 *            bits 20-25 pixel within the character as stored, y * 8 + x
 *            bits 26-27 flip (hflp << 1 | vflp)
 *            bits 28-29 the character's pixel value, the backdrop's shade,
 *                       or the value written
 *            bits 30-31 palette (GPLTn for cells, JPLTn for objects)
 *     where  cells: BG map cell index (segment << 12 | cell); objects: the
 *            object's index; with bit 24 set and the VB Color source byte in
 *            bits 16-23 where VB Color drew one, and in bits 25-26 what chose
 *            it: 1 the cell's or object's color attribute, 2 the character's
 *            color attribute (CCEN), 3 a pixel color slot (PCE) — bit 27 set
 *            where a world palette offset was added. For the backdrop, bits
 *            25-26 are 1 for CBKPAL and 2 for the backdrop row table.
 *            Writes: the PC.
 */
/**
 * What chose a pixel's VB Color palette: the cell's or object's own color
 * attribute, the character's (CCEN), a pixel color slot (PCE), or for the
 * backdrop the CBKPAL register or the backdrop row table (BKREN).
 */
export type VbColorSource = 'attribute' | 'character' | 'slot' | 'register' | 'rows';
export type VbPixelOriginKind = 'unknown' | 'backdrop' | 'cell' | 'overplane' | 'object' | 'cpu' | 'debugger';
export interface VbPixelOrigin {
    /**
     * `unknown` for a pixel nothing has drawn since origins were first kept,
     * `cpu` for one a program wrote into the frame buffer, `debugger` for one
     * a tool did.
     */
    kind: VbPixelOriginKind;
    world?: number;
    /** The BG map cell: its segment, its place in it, and its address. */
    bgmap?: {
        segment: number;
        x: number;
        y: number;
        address: number;
    };
    /** The object's index, and its address in OAM. */
    object?: {
        index: number;
        address: number;
    };
    character?: number;
    /** Which of the character's pixels, as the character stores it — the flip undone. */
    pixel?: {
        x: number;
        y: number;
    };
    flip?: {
        h: boolean;
        v: boolean;
    };
    /** The character's pixel value (0-3); for the backdrop its shade, for a write the value written. */
    value: number;
    palette?: string;
    /** The VB Color palette id drawn with the pixel, where VB Color drew one. */
    vbc?: number;
    /** What chose {@link vbc}. */
    vbcSource?: VbColorSource;
    /** Whether a world palette offset was added to the palette the source chose. */
    vbcOffset?: boolean;
    /** The instruction that wrote the pixel. */
    pc?: number;
}
export declare function decodeOrigin(what: number, where: number): VbPixelOrigin;
/** What a pixel came from, without which of its pixels: the same for every pixel one cell, object or instruction drew. */
export declare function originSource(origin: VbPixelOrigin): string;
/**
 * Origins as runs: `count, what, where` again and again, row by row through
 * the left eye's 384x224 and then the right eye's. A picture is mostly a few
 * long stretches of the same backdrop and the same cell, so a frame of it is
 * a few kilobytes where the words themselves are 1.4 MB — small enough for
 * the worker to send with every frame. See {@link decodeOriginRuns}.
 */
export declare function decodeOriginRuns(runs: Uint32Array, pixels: number): Uint32Array;
/** A rectangle of one eye's screen, as an engine drew a sprite; `parallax` moves it apart for the two eyes. */
export interface VbScreenBox {
    x: number;
    y: number;
    width: number;
    height: number;
    parallax: number;
}
/** A block of BG map cells: where in BG map memory a sprite's picture is kept. */
export interface VbCellArea {
    segment: number;
    x: number;
    y: number;
    cols: number;
    rows: number;
    /** Set where other sprites draw from the same cells: only pixels near this box are its own. */
    near?: VbScreenBox;
}
/** A run of characters, `from` up to but not including `to`: what a sprite's objects are drawn with. */
export interface VbCharacterSpan {
    from: number;
    to: number;
    /** As for {@link VbCellArea.near}. */
    near?: VbScreenBox;
}
/**
 * Something on screen that drew pixels, as the debugger names it: a world,
 * an object, a BG map cell (by its address) or a character — or a set of
 * sprites, which is how an engine's actor is on screen.
 *
 * Sprites are told by what they draw rather than where: the cells their
 * picture is kept in, the characters their objects use. An engine hands the
 * worlds and objects round again as often as every frame, so a world or an
 * object number read a moment ago may already belong to another sprite;
 * `worlds` and `objects` are only for the sprites whose picture could not be
 * found.
 */
export type VbPixelSource = {
    kind: 'world';
    world: number;
} | {
    kind: 'object';
    object: number;
} | {
    kind: 'cell';
    address: number;
} | {
    kind: 'character';
    character: number;
} | {
    kind: 'vbcPalette';
    palette: number;
} | {
    kind: 'sprites';
    cells: VbCellArea[];
    characters: VbCharacterSpan[];
    worlds: number[];
    objects: number[];
};
/**
 * Whether the two words of one pixel say `source` drew it — on the words
 * themselves rather than through {@link decodeOrigin}, since this runs for
 * every pixel of a picture at a time. Where the pixel is, in one eye, matters
 * only for sprites that share what they draw with others.
 */
export declare function originDrawnBy(what: number, where: number, source: VbPixelSource, x?: number, y?: number, eye?: 0 | 1): boolean;
//# sourceMappingURL=vb-pixel-origin.d.ts.map