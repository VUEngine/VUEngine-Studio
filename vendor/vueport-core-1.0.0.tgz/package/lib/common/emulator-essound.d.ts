/**
 * ESSound, the MP3/WAV expansion. A game stores one 16-bit value to VB_ES_SOUND_PORT: bits 15..8 track id,
 * bits 7..4 command value, bits 3..0 command, plus two whole-word values for init and stop-all.
 * Tracks are files beside the ROM named by id: 1.mp3 to 100.mp3 and 101.wav to 254.wav. The hardware plays at
 * most one MP3 and one WAV at a time, hence two slots rather than a pool.
 * Transcribed from the ESSound documentation (ESSound_01.pdf), not from any implementation.
 */
export declare enum EsSoundCommand {
    STOP = 0,
    PLAY = 1,
    PLAY_LOOP = 2,
    SET_VOLUME = 3,
    SET_BALANCE = 4
}
export declare const ES_SOUND_INIT = 65535;
export declare const ES_SOUND_STOP_ALL = 0;
export declare const ES_SOUND_FIRST_MP3 = 1;
export declare const ES_SOUND_LAST_MP3 = 100;
export declare const ES_SOUND_FIRST_WAV = 101;
export declare const ES_SOUND_LAST_WAV = 254;
export declare const ES_SOUND_LEVELS = 16;
export type EsSoundKind = 'mp3' | 'wav';
export type EsSoundMessage = {
    kind: 'init';
    raw: number;
} | {
    kind: 'stopAll';
    raw: number;
} | {
    kind: 'command';
    raw: number;
    track: number;
    command: EsSoundCommand;
    value: number;
};
export declare function decodeEsSoundMessage(raw: number): EsSoundMessage;
export declare function esSoundKindOf(track: number): EsSoundKind | undefined;
export declare function esSoundFileName(track: number): string | undefined;
export declare function esSoundTrackOf(fileName: string): number | undefined;
export declare const ES_SOUND_TITLES_FILE = "essound.json";
export declare function isEsSoundFile(fileName: string): boolean;
export declare function parseEsSoundTitles(text: string): Map<number, string>;
export declare function esSoundVolume(value: number): number;
export declare function esSoundBalance(value: number): number;
export declare const ES_SOUND_COMMAND_NAMES: Record<number, string>;
export declare function describeEsSoundMessage(message: EsSoundMessage): string;
export declare function describeEsSoundBalance(value: number): string;
export interface Mp3Gapless {
    frames: number;
    samplesPerFrame: number;
    sampleRate: number;
    delay: number;
    padding: number;
}
export declare const MP3_DECODER_DELAY = 529;
export declare function mp3GaplessInfo(bytes: Uint8Array): Mp3Gapless | undefined;
export declare function esSoundAudibleWindow(info: Mp3Gapless | undefined, decodedLength: number, decodedRate: number): {
    start: number;
    end: number;
};
export interface EsSoundFileInfo {
    seconds?: number;
    title?: string;
}
export declare function esSoundFileInfo(kind: EsSoundKind, bytes: Uint8Array): EsSoundFileInfo;
//# sourceMappingURL=emulator-essound.d.ts.map