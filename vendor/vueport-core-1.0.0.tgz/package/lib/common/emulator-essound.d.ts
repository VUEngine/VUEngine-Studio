/**
 * ESSound: the MP3/WAV expansion, and the halfwords that drive it.
 *
 * A game plays audio by storing one 16-bit value to VB_ES_SOUND_PORT. The
 * hardware reads it as three fields — a track, a command, and a value the
 * command interprets — with two whole-word values reserved for starting the
 * expansion and stopping everything:
 *
 *     bits 15..8  track id
 *     bits  7..4  command value
 *     bits  3..0  command
 *
 * Tracks are files beside the ROM, named by id: `1.mp3` to `100.mp3` and
 * `101.wav` to `254.wav`. The hardware plays at most one MP3 and one WAV at a
 * time, so those two are separate slots rather than a pool.
 *
 * Everything here is pure, and transcribed from the ESSound documentation
 * (ESSound_01.pdf) rather than from any implementation.
 */
/** The low nibble: what to do. */
export declare enum EsSoundCommand {
    STOP = 0,
    PLAY = 1,
    PLAY_LOOP = 2,
    SET_VOLUME = 3,
    SET_BALANCE = 4
}
/**
 * The two halfwords that are commands in their own right rather than a
 * track/command/value triple.
 */
export declare const ES_SOUND_INIT = 65535;
export declare const ES_SOUND_STOP_ALL = 0;
export declare const ES_SOUND_FIRST_MP3 = 1;
export declare const ES_SOUND_LAST_MP3 = 100;
export declare const ES_SOUND_FIRST_WAV = 101;
export declare const ES_SOUND_LAST_WAV = 254;
/** How many command values the volume and balance nibbles hold. */
export declare const ES_SOUND_LEVELS = 16;
export type EsSoundKind = 'mp3' | 'wav';
export type EsSoundMessage = 
/** `0xFFFF`: start the expansion, and reset volume and balance to default. */
{
    kind: 'init';
    raw: number;
}
/** `0x0000`: stop everything, leaving the stored volume and balance alone. */
 | {
    kind: 'stopAll';
    raw: number;
} | {
    kind: 'command';
    raw: number;
    track: number;
    command: EsSoundCommand;
    value: number;
};
export declare function decodeEsSoundMessage(raw: number): EsSoundMessage;
/** Which kind of file a track id names, or undefined for one that names none. */
export declare function esSoundKindOf(track: number): EsSoundKind | undefined;
/** The file a track id names, beside the ROM, or undefined for a bad id. */
export declare function esSoundFileName(track: number): string | undefined;
/**
 * The track id a file name is for, or undefined when it is not one of ours.
 *
 * No leading zeroes: the hardware builds the name from the id, so `1.mp3` is
 * track 1 and `001.mp3` is a file it never looks for — reading it as track 1
 * as well would give one id two files.
 */
export declare function esSoundTrackOf(fileName: string): number | undefined;
/**
 * Titles for the tracks beside a ROM, in a file beside them.
 *
 * ESSound itself names nothing: a track is the number in its file name. So
 * this is VUEPort's own file, not part of the expansion, and it lives in the
 * same folder as the tracks — they are per folder rather than per ROM, so it
 * is too:
 *
 *     {
 *         "tracks": {
 *             "1": { "title": "Overworld" },
 *             "101": { "title": "Jump" }
 *         }
 *     }
 *
 * An object per track rather than a bare string, so more can be said about a
 * track later without changing the format. A title here wins over one in the
 * file's own tags.
 */
export declare const ES_SOUND_TITLES_FILE = "essound.json";
/** Whether a file belongs with the tracks: a track, or their titles. */
export declare function isEsSoundFile(fileName: string): boolean;
/**
 * The titles in an `essound.json`, by track id.
 *
 * Throws on a file that is not JSON or not shaped like one, saying where:
 * somebody writes this file by hand, and a title that silently fails to show
 * up would leave them guessing.
 */
export declare function parseEsSoundTitles(text: string): Map<number, string>;
/** A command value as a gain, `0x0` silent through `0xF` full. */
export declare function esSoundVolume(value: number): number;
/**
 * A command value as a stereo position, -1 left through +1 right.
 *
 * The nibble runs the other way to the axis every audio API uses: `0x0` is
 * 100% right, `0x7` is center, `0xF` is 100% left.
 */
export declare function esSoundBalance(value: number): number;
export declare const ES_SOUND_COMMAND_NAMES: Record<number, string>;
/** One line of the history list: what the halfword asked for. */
export declare function describeEsSoundMessage(message: EsSoundMessage): string;
export declare function describeEsSoundBalance(value: number): string;
/**
 * What an MP3's encoder recorded about the silence it added: the LAME
 * extension of the Xing/Info frame, as LAME and FFmpeg write it.
 *
 * An MP3 cannot start or end exactly where the music does. The encoder
 * prepends `delay` samples and appends `padding` to fill the last frame, and
 * every decoder adds 529 samples of its own at the start. Played once, that
 * is a few milliseconds nobody hears; played in a loop, it is a gap at every
 * turn — so a looping track is played from the music's first sample to its
 * last, which these numbers locate.
 */
export interface Mp3Gapless {
    /** Audio frames, without the Info frame itself. */
    frames: number;
    samplesPerFrame: number;
    sampleRate: number;
    /** Encoder delay and end padding, in samples. */
    delay: number;
    padding: number;
}
/** Samples every MP3 decoder outputs before the first encoded one. */
export declare const MP3_DECODER_DELAY = 529;
/** The gapless information of an MP3, or undefined when it carries none. */
export declare function mp3GaplessInfo(bytes: Uint8Array): Mp3Gapless | undefined;
/**
 * The part of a decoded track that is music, in seconds of the decoded buffer.
 *
 * Browsers differ in what they hand back: some cut the encoder's silence off
 * as the tag asks, some decode every frame, one counts the Info frame as a
 * frame of silence too. Which one happened shows in the length; anything this
 * does not recognise is taken whole.
 */
export declare function esSoundAudibleWindow(info: Mp3Gapless | undefined, decodedLength: number, decodedRate: number): {
    start: number;
    end: number;
};
/** What the panel shows about a file without decoding it. */
export interface EsSoundFileInfo {
    /** How long the music runs, when the file says. */
    seconds?: number;
    /** The title in its tags, when it has one. */
    title?: string;
}
/**
 * The length and title of an audio file, read from its headers.
 *
 * Decoding a whole soundtrack just to list how long each track is would cost
 * hundreds of megabytes; the headers say as much for next to nothing. A WAV
 * states its byte rate and data size outright; an MP3 states its frame count
 * in an Xing/Info frame, and one without is walked frame header by frame
 * header, which is exact for variable bit rates too.
 */
export declare function esSoundFileInfo(kind: EsSoundKind, bytes: Uint8Array): EsSoundFileInfo;
//# sourceMappingURL=emulator-essound.d.ts.map