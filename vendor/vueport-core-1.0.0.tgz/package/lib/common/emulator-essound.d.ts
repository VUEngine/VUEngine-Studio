/**
 * ESSound: the MP3/WAV expansion, and the halfwords that drive it.
 *
 * A game plays audio by storing one 16-bit value to VB_ES_SOUND_PORT. The
 * hardware reads it as three fields — a track, a command, and a value the
 * command interprets — with two whole-word values reserved for starting the
 * expansion and stopping everything:
 *
 *     bits 15..8  track id
 *     bits  7..4  command value
 *     bits  3..0  command
 *
 * Tracks are files beside the ROM, named by id: `1.mp3` to `100.mp3` and
 * `101.wav` to `254.wav`. The hardware plays at most one MP3 and one WAV at a
 * time, so those two are separate slots rather than a pool.
 *
 * Everything here is pure, and transcribed from the ESSound documentation
 * (ESSound_01.pdf) rather than from any implementation.
 */
/** The low nibble: what to do. */
export declare enum EsSoundCommand {
    STOP = 0,
    PLAY = 1,
    PLAY_LOOP = 2,
    SET_VOLUME = 3,
    SET_BALANCE = 4
}
/**
 * The two halfwords that are commands in their own right rather than a
 * track/command/value triple.
 */
export declare const ES_SOUND_INIT = 65535;
export declare const ES_SOUND_STOP_ALL = 0;
export declare const ES_SOUND_FIRST_MP3 = 1;
export declare const ES_SOUND_LAST_MP3 = 100;
export declare const ES_SOUND_FIRST_WAV = 101;
export declare const ES_SOUND_LAST_WAV = 254;
/** How many command values the volume and balance nibbles hold. */
export declare const ES_SOUND_LEVELS = 16;
export type EsSoundKind = 'mp3' | 'wav';
export type EsSoundMessage = 
/** `0xFFFF`: start the expansion, and reset volume and balance to default. */
{
    kind: 'init';
    raw: number;
}
/** `0x0000`: stop everything, leaving the stored volume and balance alone. */
 | {
    kind: 'stopAll';
    raw: number;
} | {
    kind: 'command';
    raw: number;
    track: number;
    command: EsSoundCommand;
    value: number;
};
export declare function decodeEsSoundMessage(raw: number): EsSoundMessage;
/** Which kind of file a track id names, or undefined for one that names none. */
export declare function esSoundKindOf(track: number): EsSoundKind | undefined;
/** The file a track id names, beside the ROM, or undefined for a bad id. */
export declare function esSoundFileName(track: number): string | undefined;
/**
 * The track id a file name is for, or undefined when it is not one of ours.
 *
 * No leading zeroes: the hardware builds the name from the id, so `1.mp3` is
 * track 1 and `001.mp3` is a file it never looks for — reading it as track 1
 * as well would give one id two files.
 */
export declare function esSoundTrackOf(fileName: string): number | undefined;
/** A command value as a gain, `0x0` silent through `0xF` full. */
export declare function esSoundVolume(value: number): number;
/**
 * A command value as a stereo position, -1 left through +1 right.
 *
 * The nibble runs the other way to the axis every audio API uses: `0x0` is
 * 100% right, `0x7` is center, `0xF` is 100% left.
 */
export declare function esSoundBalance(value: number): number;
export declare const ES_SOUND_COMMAND_NAMES: Record<number, string>;
/** One line of the history list: what the halfword asked for. */
export declare function describeEsSoundMessage(message: EsSoundMessage): string;
export declare function describeEsSoundBalance(value: number): string;
//# sourceMappingURL=emulator-essound.d.ts.map