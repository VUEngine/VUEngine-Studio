import { RomPatchFormat, RomPatchType } from './emulator-rom-patches';
/** A ROM patch shipped with VUEPort. */
export interface BuiltInRomPatch {
    /** Stable key used only to persist the enabled state. */
    id: string;
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: readonly number[];
    description: string;
    author: string;
    type: RomPatchType;
    /** Optional URL of an image shipped with VUEPort. */
    screenshot?: string;
}
/** Patches belonging to one exact, whole-file ROM checksum. */
export interface RomPatchDatabaseEntry {
    game: string;
    crc32: string;
    patches: readonly BuiltInRomPatch[];
}
/**
 * Patches distributed with VUEPort.
 *
 * Like the cheat database, this is keyed by the unmodified ROM's CRC32: an
 * offset patch must never be offered for a merely similar dump.
 */
export declare const PATCH_DATABASE: RomPatchDatabaseEntry[];
/** Built-ins for one original ROM, copied so callers may own their state. */
export declare function builtInPatchesFor(romId: string | undefined, database?: readonly RomPatchDatabaseEntry[]): BuiltInRomPatch[];
//# sourceMappingURL=emulator-patch-database.d.ts.map