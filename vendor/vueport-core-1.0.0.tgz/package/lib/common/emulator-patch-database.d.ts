import { RomPatchFormat, RomPatchType } from './emulator-rom-patches';
export interface BuiltInRomPatch {
    id: string;
    name: string;
    fileName: string;
    format: RomPatchFormat;
    file: string;
    description: string;
    author: string;
    type: RomPatchType;
}
export interface RomPatchDatabaseEntry {
    game: string;
    /** Lower-case, eight hex digits, one per ROM these patches apply to. */
    crc32: readonly string[];
    patches: readonly BuiltInRomPatch[];
}
export declare const PATCH_DATABASE: RomPatchDatabaseEntry[];
export declare function builtInPatchesFor(romId: string | undefined, database?: readonly RomPatchDatabaseEntry[]): BuiltInRomPatch[];
//# sourceMappingURL=emulator-patch-database.d.ts.map