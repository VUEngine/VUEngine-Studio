import { RomPatchFormat, RomPatchStatus, RomPatchType } from './emulator-rom-patches';
interface BuiltInRomPatchFields {
    id: string;
    fileName: string;
    format: RomPatchFormat;
    file: string;
    descriptionIntro?: PatchDescriptionIntro;
    description?: string;
    author: string;
    type: RomPatchType;
    version?: string;
    status?: RomPatchStatus;
}
export type BuiltInRomPatch = BuiltInRomPatchFields & ({
    name: string;
    sharedName?: undefined;
} | {
    sharedName: PatchSharedName;
    name?: undefined;
});
export declare const PATCH_SHARED_NAMES: {
    readonly vbColorName: "VB Color Enhanced";
};
export type PatchSharedName = keyof typeof PATCH_SHARED_NAMES;
export declare const PATCH_DESCRIPTION_INTROS: {
    readonly vbColorDescriptionIntro: "Adds a \"VB Color Enhanced\" mode for VB Color, a fictional full color successor to the Virtual Boy, that colors the game according to the VB Color specification.";
};
export type PatchDescriptionIntro = keyof typeof PATCH_DESCRIPTION_INTROS;
export interface RomPatchDatabaseEntry {
    game: string;
    crc32: readonly string[];
    patches: readonly BuiltInRomPatch[];
}
export declare const PATCH_DATABASE: RomPatchDatabaseEntry[];
export declare function builtInPatchesFor(romId: string | undefined, database?: readonly RomPatchDatabaseEntry[]): BuiltInRomPatch[];
export {};
//# sourceMappingURL=emulator-patch-database.d.ts.map