import { RomPatchFormat, RomPatchStatus, RomPatchType } from './emulator-rom-patches';
interface BuiltInRomPatchFields {
    id: string;
    fileName: string;
    format: RomPatchFormat;
    file: string;
    /**
     * A paragraph several patches open their description with, translated
     * once rather than once per patch — see {@link PATCH_DESCRIPTION_INTROS}.
     */
    descriptionIntro?: PatchDescriptionIntro;
    /** What this patch does, after the intro where it has one. */
    description?: string;
    author: string;
    type: RomPatchType;
    /** The patch's own version, which moves independently of VUEPort's. */
    version?: string;
    /** How far along the patch is, for one still being worked on. */
    status?: RomPatchStatus;
}
export type BuiltInRomPatch = BuiltInRomPatchFields & (
/** A name of its own, translated under its id. */
{
    name: string;
    sharedName?: undefined;
}
/**
 * A name several patches share, translated once rather than once per
 * patch — see {@link PATCH_SHARED_NAMES}.
 */
 | {
    sharedName: PatchSharedName;
    name?: undefined;
});
/**
 * Names several shipped patches share, by the key they are translated under:
 * `vueport/patchDatabase/<key>`.
 */
export declare const PATCH_SHARED_NAMES: {
    /** Every VB Color colorization's: the game is already the running one. */
    readonly vbColorName: "VB Color Enhanced";
};
export type PatchSharedName = keyof typeof PATCH_SHARED_NAMES;
/**
 * Paragraphs that open the description of several shipped patches, by the key
 * they are translated under: `vueport/patchDatabase/<key>`.
 */
export declare const PATCH_DESCRIPTION_INTROS: {
    /** What every VB Color colorization says it does. */
    readonly vbColorDescriptionIntro: "Adds a \"VB Color Enhanced\" mode for VB Color, a fictional full color successor to the Virtual Boy, that colors the game according to the VB Color specification.";
};
export type PatchDescriptionIntro = keyof typeof PATCH_DESCRIPTION_INTROS;
export interface RomPatchDatabaseEntry {
    game: string;
    /** Lower-case, eight hex digits, one per ROM these patches apply to. */
    crc32: readonly string[];
    patches: readonly BuiltInRomPatch[];
}
export declare const PATCH_DATABASE: RomPatchDatabaseEntry[];
export declare function builtInPatchesFor(romId: string | undefined, database?: readonly RomPatchDatabaseEntry[]): BuiltInRomPatch[];
export {};
//# sourceMappingURL=emulator-patch-database.d.ts.map