/**
 * Constants for the Shrooms-VB core.
 *
 * Mirrors the values in the vendored core's Constants.js, which is the
 * authority. Kept as a TypeScript module so that the worker, the audio worklet
 * and the frontend can share them without pulling in the vendored shim.
 */
/** Virtual Boy master clock, in Hz. */
export declare const VB_CLOCK_RATE = 20000000;
/** Sample rate the core produces audio at, in Hz. */
export declare const VB_SAMPLE_RATE = 41700;
/** Frames the display is driven at, in Hz. One audio buffer covers one frame. */
export declare const VB_FRAME_RATE = 50;
/**
 * Number of emulated clocks per audio buffer. 400000 clocks is 0.02 seconds at
 * 20 MHz, which is exactly VB_SAMPLES_PER_BUFFER samples.
 */
export declare const VB_CLOCKS_PER_BUFFER: number;
/** Stereo frames per audio buffer. */
export declare const VB_SAMPLES_PER_BUFFER: number;
/**
 * Audio buffers cycled between the core worker and the audio worklet. Three
 * buffers is ~60ms of latency, matching the vendored shim.
 */
export declare const VB_AUDIO_BUFFER_COUNT = 3;
/**
 * How many `Emulate` calls in a row may spend none of the clock budget before
 * the core is taken to be stuck.
 *
 * Draining a budget means calling `Emulate` until nothing is left, and the
 * core can reach a state where it returns having spent nothing, for ever — a
 * program that has run off into memory it cannot execute does it. The loops
 * that drain the budget have no other stopping condition, so without a limit
 * the worker spins and the tab goes with it, silently.
 *
 * Measured rather than guessed: a healthy chunk drains in a single call and
 * never spends nothing at all, across every ROM `tests/stall-guard-probe.mjs`
 * puts through it. The headroom here is three orders of magnitude.
 */
export declare const VB_MAX_IDLE_EMULATE_CALLS = 1000;
/** Display dimensions, per eye. */
export declare const VB_SCREEN_WIDTH = 384;
export declare const VB_SCREEN_HEIGHT = 224;
/** Name the audio worklet processor is registered under. */
export declare const VB_AUDIO_PROCESSOR = "ves-vb-audio";
/** Controller button bits, as accepted by vbSetKeys. */
export declare enum VbKey {
    PWR = 1,
    SGN = 2,
    A = 4,
    B = 8,
    RT = 16,
    LT = 32,
    RU = 64,
    RR = 128,
    LR = 256,
    LL = 512,
    LD = 1024,
    LU = 2048,
    STA = 4096,
    SEL = 8192,
    RL = 16384,
    RD = 32768
}
/** Data types for vbRead/vbWrite and vbSetSamples. */
export declare enum VbDataType {
    S8 = 0,
    U8 = 1,
    S16 = 2,
    U16 = 3,
    S32 = 4,
    F32 = 5
}
/** System register indices. */
export declare enum VbSystemRegister {
    EIPC = 0,
    EIPSW = 1,
    FEPC = 2,
    FEPSW = 3,
    ECR = 4,
    PSW = 5,
    PIR = 6,
    TKCW = 7,
    CHCW = 24,
    ADTRE = 25
}
/**
 * Game Pak RAM, where a cartridge keeps its save data.
 *
 * The core drops every access to this region — writes as well as reads — until
 * a simulation has been given cartridge RAM with setCartRam.
 */
export declare const VB_CART_RAM_BASE = 100663296;
/**
 * Whether an address lands in Game Pak RAM.
 *
 * By region rather than by range: the Virtual Boy decodes memory on three bits
 * of the address, so the save region is not 8 KB at one address but the whole
 * of region 6, with the cartridge's actual RAM mirrored across it. A game
 * reaching its save through a mirror — which some do, the region being far
 * larger than any cartridge fills — is still touching its save.
 */
export declare function isCartRam(address: number): boolean;
/**
 * Main system RAM (WRAM), the Virtual Boy's 64 KB of work memory.
 *
 * The bus decodes on three bits the same way the save region does, so WRAM is
 * the whole of region 5 with the 64 KB mirrored across it. This is also the
 * Memory panel's own default base.
 */
export declare const VB_WRAM_BASE = 83886080;
/** Video RAM, region 0, of which the Virtual Boy has 128 KB. */
export declare const VB_VRAM_BASE = 0;
export declare const VB_VRAM_SIZE = 131072;
/** WRAM's own size, the 64 KB mirrored across region 5. */
export declare const VB_WRAM_SIZE = 65536;
/**
 * How wide one of the bus' eight regions is.
 *
 * The Virtual Boy decodes an address on three bits, so the space is eight
 * regions of 16 MB and everything above `0x08000000` is the whole map again.
 * What a region actually answers with is usually far smaller than 16 MB and
 * repeats across it — see {@link isCartRam}, which is why that test is written
 * on the region and not on a range.
 */
export declare const VB_REGION_BYTES = 16777216;
/**
 * The most bytes one `readMemory` may ask for.
 *
 * Reads go through vbRead a byte at a time, so windows are bounded. The
 * ceiling is a whole bank of WRAM, which is the largest contiguous region in
 * the address space anything here inspects, because two callers want a
 * structure whole rather than in pieces and a partial read would show up as
 * corrupt data rather than as an error: the graphics inspectors read a
 * character segment, a BGMap, the whole of OAM, or a whole frame buffer
 * (0x6000 bytes), and the Memory Pools panel reads VUEngine's pool struct,
 * which is sized per project and takes most of WRAM on a real game. Bounded
 * still: a byte at a time over 64 KiB costs nothing, but an unbounded request
 * would be a way to stall the worker.
 *
 * Shared rather than the worker's own, because a caller that reads memory in
 * windows — the Memory panel's search walks the whole cartridge — has to know
 * how wide a window may be, and a second copy of the number would be a second
 * copy to get wrong. The worker still refuses anything over it: this is what
 * the limit is, not a promise that callers respect it.
 */
export declare const VB_MAX_MEMORY_READ = 65536;
/**
 * Whether an address lands in WRAM, by region rather than by range — the same
 * decoding as {@link isCartRam}, and for the same reason.
 */
export declare function isWram(address: number): boolean;
/**
 * The client string RetroAchievements sees.
 *
 * RetroAchievements allowlists integrations by this string server-side and
 * refuses any it does not recognize with `unsupported_client` — softcore
 * included. Registering it with them is what turns the integration on; nothing
 * in the code changes at that point. Kept here so the worker, the desktop
 * shell's HTTP command and anything logging it all quote the same one.
 */
export declare const RETROACHIEVEMENTS_CLIENT = "VUEPort/1.0.0";
/** RetroAchievements' console identifier for the Virtual Boy (`RC_CONSOLE_VIRTUAL_BOY`). */
export declare const RETROACHIEVEMENTS_CONSOLE_ID = 28;
/**
 * Where the engine writes terminal output.
 *
 * `Terminal::print` stores a string here one byte at a time and follows it with
 * a newline, so this is a byte-wide port rather than an address holding a
 * value. See `vuengine/core/source/Debugging/Terminal/Terminal.c`; it is
 * compiled out of shipping builds, so a released ROM writes nothing.
 */
export declare const VB_TERMINAL_PORT = 33554480;
/**
 * The link port's control register, CCR.
 *
 * A byte leaves the machine in two steps: the payload is stored to
 * VB_LINK_TRANSMIT_PORT, then this register is written with VB_LINK_START set,
 * which clocks it out. Watching the payload register alone would therefore
 * report bytes that were never sent — `Communications::reset` clears it
 * without transmitting, for one.
 */
export declare const VB_LINK_CONTROL_PORT = 33554432;
/** The link port's transmit data register, CDTR. */
export declare const VB_LINK_TRANSMIT_PORT = 33554440;
/**
 * The address an ESSound cartridge listens on.
 *
 * ESSound is an expansion that plays MP3 and WAV files from the cartridge
 * folder, driven entirely by halfword writes to this one address — the
 * hardware selects on `/ES`, so the whole `0x04......` range reaches it and a
 * single address is all the protocol needs. See `vueport-essound.ts` for
 * what the halfwords mean.
 */
export declare const VB_ES_SOUND_PORT = 67108864;
/**
 * The CCR bit that starts a transfer, `__COM_START`.
 *
 * See `Communications::startTransmissions` and
 * `Communications::startClockSignal` in
 * `applications/electron/vb/vuengine/platforms/VirtualBoy/source/Hardware/Communications.c`,
 * and `libgccvb/source/hw.h` for the register map itself.
 */
export declare const VB_LINK_START = 4;
/**
 * The VSU's waveform tables, MODDATA and the six channel register blocks
 * (`applications/electron/vb/libgccvb/source/audio.h`), up to but not
 * including SSTOP.
 *
 * Real hardware never lets these be read back, and this core matches that:
 * confirmed directly against it (see `tests/vsu-state-probe.mjs`) that
 * vbRead on any address in this range always comes back 0, whether the value
 * arrived through an actual CPU store instruction or the debug vbWrite
 * primitive.
 *
 * The VSU panel does not read this range, then. It reads the core's own
 * decoded copy of it out of the simulation struct and composes the map below
 * from that — see `worker/vb-vsu-layout.ts`, which also covers why the write
 * watching this used to rely on could never answer the question the panel is
 * opened to ask.
 */
export declare const VB_VSU_BASE = 16777216;
/**
 * How much of the map the worker reports, which runs far enough to include
 * SSTOP, one word past the last channel's registers.
 *
 * SSTOP holds nothing to report — it is a write-only switch, not a register —
 * but the range is quoted as "up to and including" everywhere else, and
 * stopping one word short of it would invite the question every time.
 */
export declare const VB_VSU_MAP_BYTES = 1412;
/**
 * The register block's own geometry.
 *
 * The panel decodes the blocks themselves — see
 * `panels/emulator-vsu-memory.ts`, which is where the bit layouts and their
 * sourcing live. These are here because the *worker* composes the map it
 * decodes, and that file is browser-side.
 */
export declare const VB_VSU_REGISTERS = 16778240;
export declare const VB_VSU_CHANNEL_STRIDE = 64;
export declare const VB_VSU_CHANNELS = 6;
/** `SxINT` bit 7: the channel is switched on. */
export declare const VB_VSU_CHANNEL_ENABLE = 128;
/** Write-only, and one word past the last channel: any write with bit 0 set silences them all. */
export declare const VB_VSU_SSTOP = 16778624;
/**
 * The cartridge ROM as the CPU sees it: region 7, mirrored across it.
 *
 * Only readable to the game, but the core's debug write reaches it too — which
 * is how the color editor puts an edited palette into the palette table a
 * colorization's native code copies from. See `emulator-vb-color-store.ts`.
 */
export declare const VB_ROM_BASE = 117440512;
/** VB Color Color RAM: 256 palettes of four RGB555 colors, BG 0-127 then OBJ 128-255. */
export declare const VBC_CRAM_BASE = 50827264;
export declare const VBC_CRAM_PALETTES = 256;
export declare const VBC_CRAM_PALETTE_BYTES = 8;
/**
 * The VB Color unit's Color Framebuffer, and what its bytes mean.
 *
 * Four pages of 384x256 pixels at one byte per pixel, the byte being a *palette
 * id* rather than a color: the VCU looks the final pixel up as
 * `CRAM[byte * 4 + legacy shade]`, which is why a colorization can tint a game
 * it never re-renders.
 *
 * Worth stating plainly because it is the only place a palette id survives in
 * memory. Color RAM says what the colors *are*; this says which palette is
 * painting, and it is the only thing that does — the colorization's own store
 * into it is where `setDrawnPaletteCapture` reads the id off the bus.
 */
export declare const VBC_COLOR_FRAMEBUFFER_BASE = 50331648;
export declare const VBC_COLOR_FRAMEBUFFER_PAGE_BYTES: number;
export declare const VBC_COLOR_FRAMEBUFFER_PAGES = 4;
export declare const VBC_COLOR_FRAMEBUFFER_BYTES: number;
/**
 * Whether an address lands in the Color Framebuffer.
 *
 * By region and offset, the way {@link isCartRam} is and for the same reason:
 * the bus decodes three bits, so the VCU is the whole of region 3 with its
 * aperture mirrored across it. The framebuffer is the first
 * `VBC_COLOR_FRAMEBUFFER_BYTES` of that aperture; the attribute RAMs, Color RAM
 * and the register block sit above it and are deliberately outside this test.
 */
export declare function isVbcColorFramebuffer(address: number): boolean;
/**
 * The CPU's interrupt levels, in the order the hardware vectors them.
 *
 * Confirmed by the engine's own vector table (`vuengine/core/source/Runtime/
 * crt0.s`, section `.vbvectors`), which labels them KEY, TIM, CRO, COM and
 * VPU at sixteen-byte intervals. CRO is the expansion port's, which is what an
 * ESSound cartridge pulses to say it is there.
 */
export declare enum VbInterrupt {
    KEY = 0,
    TIM = 1,
    CRO = 2,
    COM = 3,
    VPU = 4
}
/**
 * Where the CPU jumps for interrupt level n: this plus `n * 0x10`.
 *
 * The addresses the ROM links its table at (`0x07FFFE00`) are the same memory
 * seen through the cartridge mirror.
 */
export declare const VB_INTERRUPT_VECTOR_BASE = 4294966784;
/** The exception code an interrupt of level n writes to ECR's low halfword. */
export declare function vbInterruptExceptionCode(level: VbInterrupt): number;
/**
 * PSW bits, per the V810's program status word.
 *
 * The interrupt level mask occupies bits 16 to 19, which the engine's
 * `set_intlevel` in `libgccvb/source/asm.c` reads and writes the same way.
 */
export declare enum VbPsw {
    /** Interrupts are disabled. */
    ID = 4096,
    /** Address trap enable. */
    AE = 8192,
    /** An exception is being handled. */
    EP = 16384,
    /** A non-maskable interrupt is being handled. */
    NP = 32768
}
export declare const VB_PSW_INTERRUPT_LEVEL_SHIFT = 16;
export declare const VB_PSW_INTERRUPT_LEVEL_MASK = 983040;
/** Core option keys for vbSetOption/vbGetOption. */
export declare enum VbOption {
    PSEUDO_HALT = 0
}
/** Break condition bits returned by GetBreaks. */
export declare enum VbBreak {
    FRAME = 1,
    POINT = 2
}
/**
 * Anaglyph configuration that packs the left eye's brightness into the red
 * channel and the right eye's into the green channel, both unscaled.
 *
 * The core's mixer assigns RGB channels to eyes independently, so this yields a
 * single RGBA framebuffer carrying both eyes at full 8-bit precision. Every
 * display mode is then derived in a shader from one texture, without per-eye
 * passes or decoding VIP framebuffers. The core is always configured this way;
 * color is applied entirely by the renderer.
 */
export declare const VB_EYE_PACKED_LEFT = 16711680;
export declare const VB_EYE_PACKED_RIGHT = 65280;
/**
 * Tints the built-in anaglyph pairs are made of.
 *
 * Green and magenta are the core's own constants (see Constants.js); the rest
 * are full-saturation equivalents, which is what a filter passes best. Nothing
 * here affects emulation.
 */
export declare const VB_COLORS: {
    RED: number;
    BLUE: number;
    CYAN: number;
    GREEN: number;
    MAGENTA: number;
    AMBER: number;
};
/**
 * Where the display's four brightness levels land in the framebuffer's 0..1
 * range, with the brightness registers a VUEngine game configures by default
 * (BRTA 32, BRTB 64, BRTC 32 — see __BRIGHTNESS_DARK/MEDIUM/BRIGHT_RED).
 *
 * The core resolves a pixel's brightness before the renderer sees it, and does
 * so on a gamma-like curve rather than proportionally:
 * `scripts/brightness-probe.mjs` measures level 1 at 105, level 2 at 162 and
 * level 3 at 250 out of 255. The renderer interpolates the palette between
 * these stops, so a display at the standard brightness shows the four palette
 * colors exactly, while a game dimming the brightness registers — a fade —
 * slides smoothly down through them instead of banding.
 */
export declare const VB_LEVEL_STOPS: number[];
export declare const VB_LEVELS = 4;
export type VbDuboisProfile = 'red-cyan' | 'green-magenta' | 'amber-blue';
export type VbDuboisProfileSelection = 'none' | VbDuboisProfile | 'custom';
/** Two 3x3 color transforms, stored column-major for WebGL. */
export interface VbAnaglyphMatrices {
    left: number[];
    right: number[];
}
export interface VbAnaglyphPalette {
    left: number;
    right: number;
    /** Explicit built-in calibration; absent for RGB channel filters and custom matrices. */
    duboisProfile?: VbDuboisProfile;
    /** Explicit user calibration. Takes precedence over a built-in profile when present. */
    duboisMatrices?: VbAnaglyphMatrices;
}
export type VbPalette = [number, number, number, number];
export declare const VB_PALETTE_GROUPS: Record<string, VbPalette>[];
/** Every shipped palette, in the order the groups list them. */
export declare const VB_PALETTES: Record<string, VbPalette>;
export declare const VB_DEFAULT_PALETTE_ID: string;
/** The palette everything falls back to, which is the first one shipped. */
export declare const VB_DEFAULT_PALETTE: VbPalette;
/**
 * Published Dubois least-squares calibrations.
 *
 * They operate on linear RGB and are column-major here so the arrays can be
 * uploaded to WebGL without a transpose. Keeping the coefficients in common
 * code also lets a custom calibration start as an editable copy of a preset.
 * Method and calibration limitations: https://www.site.uottawa.ca/~edubois/anaglyph/
 * Red/cyan coefficients: https://github.com/mrdoob/three.js/blob/dev/examples/jsm/effects/AnaglyphEffect.js
 * Green/magenta LCD profile: https://www.flickr.com/photos/e_dubois/5132528166/
 * Amber/blue LCD / ColorCode profile: https://www.flickr.com/photos/e_dubois/5230654930/
 */
export declare const VB_DUBOIS_MATRICES: Record<VbDuboisProfile, VbAnaglyphMatrices>;
export declare const VB_ANAGLYPH_PALETTES: Record<string, VbAnaglyphPalette>;
export declare const VB_DEFAULT_ANAGLYPH_PALETTE_ID = "red-cyan";
export declare enum VbStereoLayout {
    OVERLAY = 0,
    SIDE_BY_SIDE = 1,
    CYBERSCOPE = 2,
    HLI = 3,
    VLI = 4
}
export declare enum VbEyes {
    LEFT = 0,
    RIGHT = 1,
    BOTH = 2
}
export declare enum VbRenderingMode {
    LEFT = "left",
    RIGHT = "right",
    ANAGLYPH = "anaglyph",
    SIDE_BY_SIDE = "side-by-side",
    CYBERSCOPE = "cyberscope",
    HLI = "hli",
    VLI = "vli"
}
interface VbRenderingGeometry {
    layout: VbStereoLayout;
    eyes: VbEyes;
    width: number;
    height: number;
}
/**
 * Everything the renderer needs to present a frame: the geometry the rendering
 * mode dictates, plus the colors chosen for it. The color palette resolves
 * every legacy eye image before composition; in Anaglyph mode the resolved
 * images are then passed through the selected left/right filters. VBC frames
 * already carry full RGB555 colors and bypass the legacy palette.
 */
export interface DisplayMode extends VbRenderingGeometry {
    palette: VbPalette;
    anaglyph: VbAnaglyphPalette;
}
export declare function isRenderingMode(mode: string): mode is VbRenderingMode;
export declare const VB_DEFAULT_RENDERING_MODE = VbRenderingMode.LEFT;
export declare function buildDisplayMode(mode: string, palette: VbPalette, anaglyph: VbAnaglyphPalette): DisplayMode;
export declare const VB_DEFAULT_DISPLAY_MODE: DisplayMode;
export {};
//# sourceMappingURL=vb-constants.d.ts.map