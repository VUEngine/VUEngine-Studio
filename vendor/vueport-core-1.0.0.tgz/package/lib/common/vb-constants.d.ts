export declare const VB_CLOCK_RATE = 20000000;
export declare const VB_SAMPLE_RATE = 41700;
export declare const VB_FRAME_RATE = 50;
export declare const VB_CLOCKS_PER_BUFFER: number;
export declare const VB_SAMPLES_PER_BUFFER: number;
export declare const VB_AUDIO_BUFFER_COUNT = 3;
export declare const VB_MAX_IDLE_EMULATE_CALLS = 1000;
export declare const VB_SCREEN_WIDTH = 384;
export declare const VB_SCREEN_HEIGHT = 224;
export declare const VB_AUDIO_PROCESSOR = "ves-vb-audio";
export declare enum VbKey {
    PWR = 1,
    SGN = 2,
    A = 4,
    B = 8,
    RT = 16,
    LT = 32,
    RU = 64,
    RR = 128,
    LR = 256,
    LL = 512,
    LD = 1024,
    LU = 2048,
    STA = 4096,
    SEL = 8192,
    RL = 16384,
    RD = 32768
}
export declare enum VbDataType {
    S8 = 0,
    U8 = 1,
    S16 = 2,
    U16 = 3,
    S32 = 4,
    F32 = 5
}
export declare enum VbSystemRegister {
    EIPC = 0,
    EIPSW = 1,
    FEPC = 2,
    FEPSW = 3,
    ECR = 4,
    PSW = 5,
    PIR = 6,
    TKCW = 7,
    CHCW = 24,
    ADTRE = 25
}
export declare const VB_CART_RAM_BASE = 100663296;
export declare function isCartRam(address: number): boolean;
export declare const VB_WRAM_BASE = 83886080;
export declare const VB_VRAM_BASE = 0;
export declare const VB_VRAM_SIZE = 131072;
export declare const VB_WRAM_SIZE = 65536;
export declare const VB_REGION_BYTES = 16777216;
/**
 * The most bytes one `readMemory` may ask for. Reads go through vbRead a byte at a time, so windows are
 * bounded; the ceiling is a whole bank of WRAM, as the graphics inspectors (a character segment, BGMap, all of
 * OAM, a 0x6000 byte frame buffer) and the Memory Pools panel (VUEngine's pool struct, most of WRAM) need
 * structures whole, and a partial read would look like corrupt data. Unbounded requests could stall the worker.
 * Shared, as callers reading in windows (the Memory panel's search) must know the width; the worker still
 * refuses anything over it
 */
export declare const VB_MAX_MEMORY_READ = 65536;
export declare function isWram(address: number): boolean;
export declare const RETROACHIEVEMENTS_CLIENT = "VUEPort/1.0.0";
export declare const RETROACHIEVEMENTS_CONSOLE_ID = 28;
export declare const VB_TERMINAL_PORT = 33554480;
export declare const VB_LINK_CONTROL_PORT = 33554432;
export declare const VB_LINK_TRANSMIT_PORT = 33554440;
export declare const VB_ES_SOUND_PORT = 67108864;
export declare const VB_LINK_START = 4;
/**
 * The VSU's waveform tables, MODDATA and the six channel register blocks
 * (`applications/electron/vb/libgccvb/source/audio.h`), up to but not including SSTOP. Write-only on real
 * hardware and in this core: vbRead always returns 0 here, after CPU stores and debug vbWrite alike (see
 * `tests/vsu-state-probe.mjs`). So the VSU panel reads the core's decoded copy from the simulation struct
 * instead, see `worker/vb-vsu-layout.ts`
 */
export declare const VB_VSU_BASE = 16777216;
export declare const VB_VSU_MAP_BYTES = 1412;
export declare const VB_VSU_REGISTERS = 16778240;
export declare const VB_VSU_CHANNEL_STRIDE = 64;
export declare const VB_VSU_CHANNELS = 6;
export declare const VB_VSU_CHANNEL_ENABLE = 128;
export declare const VB_VSU_SSTOP = 16778624;
export declare const VB_ROM_BASE = 117440512;
export declare const VBC_CRAM_BASE = 50827264;
export declare const VBC_VCU_APERTURE_BYTES = 1048576;
export declare const VBC_CRAM_PALETTES = 256;
export declare const VBC_CRAM_PALETTE_BYTES = 16;
export declare const VBC_FRAME_WIDTH: number;
export declare const VBC_FRAME_BYTES: number;
export declare const VB_FRAME_BYTES: number;
export declare function vbFrameBytes(colorMode: boolean): number;
export declare const VBC_COLOR_FRAMEBUFFER_BASE = 50331648;
export declare const VBC_COLOR_FRAMEBUFFER_PAGE_BYTES: number;
export declare const VBC_COLOR_FRAMEBUFFER_PAGES = 4;
export declare const VBC_COLOR_FRAMEBUFFER_BYTES: number;
export declare function isVbcColorFramebuffer(address: number): boolean;
export declare enum VbInterrupt {
    KEY = 0,
    TIM = 1,
    CRO = 2,
    COM = 3,
    VPU = 4
}
export declare const VB_INTERRUPT_VECTOR_BASE = 4294966784;
export declare function vbInterruptExceptionCode(level: VbInterrupt): number;
export declare enum VbPsw {
    ID = 4096,
    AE = 8192,
    EP = 16384,
    NP = 32768
}
export declare const VB_PSW_INTERRUPT_LEVEL_SHIFT = 16;
export declare const VB_PSW_INTERRUPT_LEVEL_MASK = 983040;
export declare enum VbOption {
    PSEUDO_HALT = 0,
    VBC_HARDWARE = 1,
    STEREO_DEPTH = 2,
    WRITE_RANGES = 3
}
export declare const VB_WRITE_RANGES_ALL = 255;
export declare enum VbBreak {
    FRAME = 1,
    POINT = 2
}
export declare const VB_EYE_PACKED_LEFT = 16711680;
export declare const VB_EYE_PACKED_RIGHT = 65280;
export declare const VB_COLORS: {
    RED: number;
    BLUE: number;
    CYAN: number;
    GREEN: number;
    MAGENTA: number;
    AMBER: number;
};
/**
 * Where the four brightness levels land in the framebuffer's 0..1 range, with VUEngine's default brightness
 * registers (BRTA 32, BRTB 64, BRTC 32, see __BRIGHTNESS_DARK/MEDIUM/BRIGHT_RED). The core resolves brightness
 * on a gamma-like curve: `scripts/brightness-probe.mjs` measures levels 1-3 at 105, 162 and 250 out of 255.
 * The renderer interpolates the palette between these stops, so standard brightness shows the palette exactly
 * and a fade slides through it without banding
 */
export declare const VB_LEVEL_STOPS: number[];
export declare const VB_LEVELS = 4;
export type VbDuboisProfile = 'red-cyan' | 'green-magenta' | 'amber-blue';
export type VbDuboisProfileSelection = 'none' | VbDuboisProfile | 'custom';
export interface VbAnaglyphMatrices {
    left: number[];
    right: number[];
}
export interface VbAnaglyphPalette {
    left: number;
    right: number;
    duboisProfile?: VbDuboisProfile;
    duboisMatrices?: VbAnaglyphMatrices;
}
export type VbPalette = [number, number, number, number];
export declare const VB_PALETTE_GROUPS: Record<string, VbPalette>[];
export declare const VB_PALETTES: Record<string, VbPalette>;
export declare const VB_DEFAULT_PALETTE_ID: string;
export declare const VB_DEFAULT_PALETTE: VbPalette;
/**
 * Published Dubois least-squares calibrations, on linear RGB, column-major for WebGL. In common code so a
 * custom calibration can start as a copy of a preset.
 * Method and calibration limitations: https://www.site.uottawa.ca/~edubois/anaglyph/
 * Red/cyan coefficients: https://github.com/mrdoob/three.js/blob/dev/examples/jsm/effects/AnaglyphEffect.js
 * Green/magenta LCD profile: https://www.flickr.com/photos/e_dubois/5132528166/
 * Amber/blue LCD / ColorCode profile: https://www.flickr.com/photos/e_dubois/5230654930/
 */
export declare const VB_DUBOIS_MATRICES: Record<VbDuboisProfile, VbAnaglyphMatrices>;
export declare const VB_ANAGLYPH_PALETTES: Record<string, VbAnaglyphPalette>;
export declare const VB_DEFAULT_ANAGLYPH_PALETTE_ID = "red-cyan";
export declare enum VbStereoLayout {
    OVERLAY = 0,
    SIDE_BY_SIDE = 1,
    CYBERSCOPE = 2,
    HLI = 3,
    VLI = 4
}
export declare enum VbEyes {
    LEFT = 0,
    RIGHT = 1,
    BOTH = 2
}
export declare enum VbRenderingMode {
    LEFT = "left",
    RIGHT = "right",
    ANAGLYPH = "anaglyph",
    SIDE_BY_SIDE = "side-by-side",
    CYBERSCOPE = "cyberscope",
    HLI = "hli",
    VLI = "vli"
}
interface VbRenderingGeometry {
    layout: VbStereoLayout;
    eyes: VbEyes;
    width: number;
    height: number;
}
export declare function isInterleavedLayout(layout: VbStereoLayout): boolean;
export interface DisplayOutput {
    width: number;
    height: number;
    parity: number;
}
export declare enum FrameBlending {
    OFF = "off",
    SMART = "smart",
    FULL = "full"
}
export interface DisplayMode extends VbRenderingGeometry {
    palette: VbPalette;
    anaglyph: VbAnaglyphPalette;
    swapEyes: boolean;
    frameBlending: FrameBlending;
}
export declare function eyesSwapped(mode: DisplayMode): boolean;
export declare function isRenderingMode(mode: string): mode is VbRenderingMode;
export declare const VB_DEFAULT_RENDERING_MODE = VbRenderingMode.LEFT;
export declare function buildDisplayMode(mode: string, palette: VbPalette, anaglyph: VbAnaglyphPalette, swapEyes?: boolean, frameBlending?: FrameBlending): DisplayMode;
export declare function thumbnailDisplayMode(live: DisplayMode): DisplayMode;
export declare const VB_DEFAULT_DISPLAY_MODE: DisplayMode;
export declare enum VbCounter {
    Cycles = 0,
    Halted = 1,
    CacheHits = 2,
    CacheMisses = 3,
    FetchWait = 4,
    BusVip = 5,
    BusVsu = 6,
    BusMisc = 7,
    BusCart = 8,
    BusSram = 9,
    BusWram = 10,
    VipContention = 11,
    PipelineWait = 12,
    XpBusy = 13,
    XpHeld = 14,
    Count = 15
}
export {};
//# sourceMappingURL=vb-constants.d.ts.map