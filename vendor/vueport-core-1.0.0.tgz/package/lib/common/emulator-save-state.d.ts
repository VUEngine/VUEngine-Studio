import { EmulatorSramInit } from './emulator-sram';
/**
 * Save state container. The header guards against loading a state into the wrong game, or one from a core
 * with a different state layout, which would restore convincing nonsense.
 *
 *  0  'VESS'
 *  4  version
 *  8  the ROM's size in MBit
 * 12  bytes per machine, as the core hands them over
 * 16  the ROM's 32-byte header
 * 48  how many machines
 * 52  metadata length   ┐
 * 56  thumbnail length  │  the sections, in this order,
 * 60  ESSound length    │  straight after the header
 * 64  body length       ┘
 *
 * Everything the save-state browser draws a row from comes before the body, so it is read without inflating.
 * Every length is spelt out, as the compressed body's size says nothing about the machine count. A file is
 * only taken for a state when its sections add up to exactly its length, which also rejects an earlier
 * pre-release layout that was numbered 1 as well.
 */
export declare const STATE_MAGIC = 1447383891;
export declare const STATE_VERSION = 1;
export declare const STATE_HEADER_BYTES = 68;
/**
 * How much of the save window comes up like a real cartridge's SRAM. A size in address space, not storage:
 * only the low byte of each halfword is wired to the SRAM chip on every game pak, so the 8 KiB chip spans
 * 16 KiB of bus (Lemur allocates the same). A cartridge gets all of SAVE_RAM_WINDOW, so this is the line between
 * the part that powers up like a chip and the part that is no chip at all; see freshSaveRam and saveRamHighWater.
 */
export declare const DEFAULT_SAVE_RAM_SIZE = 16384;
/**
 * The save RAM a cartridge gets: all of Game Pak RAM. The VB decodes addresses on three bits, so region 6 is
 * 16 MiB wide; handing over all of it means no game can run out of a size a ROM cannot declare, and costs
 * nothing on disk as saveRamHighWater trims the file. Traded away on purpose: mirroring (a 16 KiB cartridge is
 * not emulated as one) and a game probing its save RAM size is told all of it. Narrowing the window for
 * real-hardware development is still to be built; setCartRam already takes any power of two.
 */
export declare const SAVE_RAM_WINDOW = 16777216;
export type SaveStateKind = 'manual' | 'auto' | 'suspend';
export declare enum EmulatorResumeStart {
    ASK = "ask",
    RESUME = "resume",
    IGNORE = "ignore"
}
export interface VesEmulatorSaveStateMeta {
    kind: SaveStateKind;
    created: number;
    label?: string;
    thumbnail?: Uint8Array;
    romName?: string;
}
export declare class SaveStateOtherRomError extends Error {
    constructor();
}
export interface VesEmulatorSaveState {
    states: ArrayBuffer[];
    otherRom: boolean;
    esSound: string | undefined;
    meta: VesEmulatorSaveStateMeta | undefined;
}
export interface VesEmulatorSaveStateIdentity {
    romIdentity: Uint8Array;
    romSize: number;
}
/**
 * A header, the metadata, what ESSound was playing, and one block per simulation, compressed together. A
 * linked pair is snapshotted as a unit, or the machines disagree about the link port conversation; the blocks
 * are the same size, so the header holds it once with the count. The audio plays on the DOM side, so without
 * its section loading a state would leave whatever was playing running on.
 */
export declare function wrapSaveState(states: ArrayBuffer[], identity: VesEmulatorSaveStateIdentity, esSoundSnapshot: unknown, meta?: VesEmulatorSaveStateMeta): Promise<Uint8Array>;
export declare function rewriteSaveStateMeta(stored: Uint8Array, next: VesEmulatorSaveStateMeta): Uint8Array;
export declare function unwrapSaveState(stored: Uint8Array, expectedCount: number, identity: VesEmulatorSaveStateIdentity, options?: {
    otherRom?: boolean;
}): Promise<VesEmulatorSaveState>;
/**
 * How many machines a state holds and its metadata, without inflating the body; what the save-state browser
 * lists a folder with. Undefined for anything that is not a state file, as a folder beside a ROM is full of
 * other files. No identity check: this describes, it does not load, and a state of another ROM is exactly what
 * the browser wants to say; unwrapSaveState is the only way in.
 */
export declare function describeSaveState(stored: Uint8Array): {
    machines: number;
    meta: VesEmulatorSaveStateMeta | undefined;
} | undefined;
export declare function saveRamWindowBytes(window: string): number;
/**
 * Random rather than zeroed by default, as real SRAM powers up holding whatever it holds, and a game mistaking
 * zeroes for a valid save is a bug worth finding on the developer's machine. Only up to DEFAULT_SAVE_RAM_SIZE:
 * beyond the chip there are no cells, so zero is more honest, and it lets saveRamHighWater tell how much a game
 * used. Randomizing all 16 MiB would pause every launch and make save files incompressible.
 */
export declare function freshSaveRam(fill: EmulatorSramInit, size?: number): Uint8Array;
/**
 * Read out of the buffer rather than watching writes: everything above DEFAULT_SAVE_RAM_SIZE starts as zero (see
 * freshSaveRam), so a non-zero byte there is one a game wrote. Never less than the baseline, which holds noise.
 * Trimming on this is lossless: a zero written into zeroed space is indistinguishable from none, and the region
 * is zeroed again on the way back in.
 */
export declare function saveRamHighWater(ram: Uint8Array): number;
export declare function saveRamFileSize(used: number, existing?: number): number;
//# sourceMappingURL=emulator-save-state.d.ts.map