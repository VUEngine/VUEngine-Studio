/**
 * What the emulator needs from whatever it is running inside: somewhere to keep files, and somewhere to talk to the
 * person using it. Paths are opaque strings, as their meaning is the host's business (workspace-relative in VES,
 * an OPFS key on the web, a real path in a native wrapper); the emulator only composes them with parent, stem and join.
 */
export interface VueportFile {
    path: string;
    name: string;
    size: number;
}
export interface VueportUsage {
    bytes: number;
    files: number;
}
export interface VueportStorage {
    read(path: string): Promise<Uint8Array>;
    readText(path: string): Promise<string>;
    write(path: string, data: Uint8Array): Promise<void>;
    writeText(path: string, text: string): Promise<void>;
    exists(path: string): Promise<boolean>;
    delete(path: string): Promise<void>;
    list(directory: string): Promise<VueportFile[]>;
    measure?(directory: string): Promise<VueportUsage>;
    parent(path: string): string;
    stem(path: string): string;
    name(path: string): string;
    join(directory: string, name: string): string;
    export(name: string, data: Uint8Array): Promise<void>;
    exportBlob?(name: string, blob: Blob): Promise<void>;
}
export interface VueportProgress {
    cancel(): void;
}
export interface VueportNotifications {
    info(text: string): void;
    warn(text: string): void;
    error(text: string): void;
    confirm(options: {
        title: string;
        message: string | string[];
        okLabel?: string;
    }): Promise<boolean>;
    progress(text: string): Promise<VueportProgress>;
}
export interface VueportHost {
    readonly storage: VueportStorage;
    readonly notifications: VueportNotifications;
}
//# sourceMappingURL=emulator-host.d.ts.map