/**
 * Pixels as an indexed PNG — a palette of their colours and an index per pixel
 * — or nothing, when they have more colours than a palette holds.
 *
 * What a Virtual Boy picture nearly always is: four shades per eye, a few more
 * where frames blend or the eyes overlap in anaglyph. Indexed, a screenshot is
 * a fraction of the truecolour file the canvas would write, and loses nothing.
 *
 * `scale` enlarges by whole multiples, nearest-neighbour, so a big shot is
 * counted and indexed at its own size and only repeated on the way out.
 *
 * Nothing either where `CompressionStream` is missing: the caller has the
 * canvas's own encoder to fall back on.
 */
export declare function encodeIndexedPng(rgba: Uint8ClampedArray, width: number, height: number, scale?: number): Promise<Uint8Array<ArrayBuffer> | undefined>;
//# sourceMappingURL=emulator-png.d.ts.map