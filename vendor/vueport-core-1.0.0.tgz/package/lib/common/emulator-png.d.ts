/**
 * Pixels as an indexed PNG, or undefined when they have more colours than a palette holds. A VB picture nearly
 * always fits (four shades per eye, a few more with blending or anaglyph), at a fraction of the canvas's truecolour
 * size. `scale` enlarges by whole multiples, nearest-neighbour, so a big shot is indexed at its own size. Also
 * undefined without CompressionStream; the caller falls back to the canvas's own encoder.
 */
export declare function encodeIndexedPng(rgba: Uint8ClampedArray, width: number, height: number, scale?: number): Promise<Uint8Array<ArrayBuffer> | undefined>;
//# sourceMappingURL=emulator-png.d.ts.map