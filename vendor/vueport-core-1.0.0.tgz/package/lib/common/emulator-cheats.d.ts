/**
 * Cheats, and the `.cht` files they live in.
 *
 * A cheat is a set of RAM writes the emulator repeats every frame, which is
 * what makes a value stay put however hard the game tries to change it — the
 * "RAM Write" codes gamehacking.org publishes for the Virtual Boy. A code is
 * written `ADDRESS:VALUE`, both hexadecimal, e.g. `50091A4:0001` for "write 1
 * to 0x050091A4 every frame". The number of digits in the value is how wide
 * the write is: two for a byte, four for a halfword, eight for a word.
 *
 * The file format is RetroArch's: a `cheats` count followed by `cheatN_desc`,
 * `cheatN_code` and `cheatN_enable` for each, with several codes in one cheat
 * separated by `+`. Reading is deliberately lenient — unknown keys, missing
 * quotes, a wrong or absent count, blank lines and `;` comments are all
 * tolerated — because these files are written by hand and by other tools as
 * often as by this one. Writing produces the canonical form.
 *
 * `cheatN_notes` is this application's own addition, an optional free-text
 * explanation beside a cheat — why it needs the value it does, what it does
 * not cover, a caveat about when it takes effect. It is not part of
 * RetroArch's format, but an unknown key is exactly what the leniency above is
 * for: a tool that only knows the standard keys reads a `.cht` this writes and
 * ignores the line, keeping every cheat — only the explanation goes missing,
 * never the cheat itself. Omitted entirely for a cheat with no notes, so a
 * file that uses none of this looks exactly as it always has.
 *
 * Everything here is pure, so it can be reasoned about, and tested, without a
 * running emulator or a file system.
 */
/** One `ADDRESS:VALUE` write. */
export interface CheatCode {
    /** Where to write, in the CPU's address space. */
    address: number;
    value: number;
    /** The value's width in hexadecimal digits: 2, 4 or 8. */
    digits: number;
}
export interface Cheat {
    description: string;
    enabled: boolean;
    codes: CheatCode[];
    /**
     * An optional explanation, shown beside the cheat rather than folded into
     * its name — see the module doc comment for the line it lives on in the
     * file. Free text, and may be several lines; nothing here parses it.
     */
    notes?: string;
    /**
     * Set for a cheat that came from the built-in database rather than from
     * the file beside the ROM.
     *
     * Such a cheat can be switched on and off but not edited or removed: it is
     * not the player's to change, and the next release may correct it. Only
     * whether it is on is remembered in browser state — see the cheat store.
     */
    readonly builtIn?: boolean;
    /**
     * A built-in's identity, stable across releases, which is what its
     * remembered on/off state is filed under. Absent on a player's own cheats,
     * which use a definition-derived identity in browser state.
     */
    readonly id?: string;
}
/** The widths a code's value may be written at, and what they mean in bytes. */
export declare const CHEAT_DIGITS: number[];
export declare const CHEAT_DEFAULT_DIGITS = 4;
export declare function vesCheatCodeBytes(code: CheatCode): number;
/** The largest value a code of this width can hold. */
export declare function vesCheatMaxValue(digits: number): number;
/**
 * Read one `ADDRESS:VALUE` code, or undefined if it is not one.
 *
 * The address is masked to 32 bits rather than rejected when it is longer,
 * since published codes routinely leave off leading zeroes and occasionally
 * carry a stray one.
 */
export declare function parseVesCheatCode(text: string): CheatCode | undefined;
export declare function formatVesCheatCode(code: CheatCode): string;
/** All of a cheat's codes, in the `+`-separated form the file holds. */
export declare function formatVesCheatCodes(cheat: Cheat): string;
/**
 * Parse all of a cheat's codes from the `+`-separated form the files use, and
 * that published cheat lists are written in. Anything unparseable is dropped
 * rather than failing the rest.
 */
export declare function parseVesCheatCodes(text: string): CheatCode[];
/** Parse the `.cht` file next to a ROM. */
export declare function parseVesCheatFile(text: string): Cheat[];
export declare function serializeVesCheatFile(cheats: Cheat[]): string;
/** The writes the enabled cheats add up to, in the order they are listed. */
export declare function enabledVesCheatCodes(cheats: ReadonlyArray<Cheat>): CheatCode[];
//# sourceMappingURL=emulator-cheats.d.ts.map