/**
 * Cheats and their `.cht` files. A cheat is a set of RAM writes repeated every frame (gamehacking.org's
 * "RAM Write" codes), written `ADDRESS:VALUE` in hex, e.g. `50091A4:0001` writes 1 to 0x050091A4. Value
 * digits give the width: 2 byte, 4 halfword, 8 word.
 * File format is RetroArch's (`cheats` count, then `cheatN_desc`, `cheatN_code`, `cheatN_enable`, codes
 * joined by `+`). Reading is lenient (unknown keys, missing quotes, wrong count, blank lines, `;` comments)
 * as files are hand-written; writing is canonical. `cheatN_notes` is our own optional addition, which
 * standard readers ignore as an unknown key; omitted when empty
 */
export interface CheatCode {
    address: number;
    value: number;
    digits: number;
}
export interface Cheat {
    description: string;
    enabled: boolean;
    codes: CheatCode[];
    notes?: string;
    readonly builtIn?: boolean;
    readonly id?: string;
}
export declare const CHEAT_DIGITS: number[];
export declare const CHEAT_DEFAULT_DIGITS = 4;
export declare function vesCheatCodeBytes(code: CheatCode): number;
export declare function vesCheatMaxValue(digits: number): number;
export declare function parseVesCheatCode(text: string): CheatCode | undefined;
export declare function formatVesCheatCode(code: CheatCode): string;
export declare function formatVesCheatCodes(cheat: Cheat): string;
export declare function parseVesCheatCodes(text: string): CheatCode[];
export declare function parseVesCheatFile(text: string): Cheat[];
export declare function serializeVesCheatFile(cheats: Cheat[]): string;
export declare function enabledVesCheatCodes(cheats: ReadonlyArray<Cheat>): CheatCode[];
//# sourceMappingURL=emulator-cheats.d.ts.map