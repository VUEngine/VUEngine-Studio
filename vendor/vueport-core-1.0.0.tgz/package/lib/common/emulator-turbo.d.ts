export declare const DEFAULT_TURBO_RATE = 2;
export declare const TURBO_RATE_RANGE: {
    min: number;
    max: number;
};
export declare function clampTurboRate(rate: number): number;
export declare function turboPressedOn(frame: number, rate: number): boolean;
export declare function withTurbo(keys: number, turboKeys: number, frame: number, rate: number): number;
//# sourceMappingURL=emulator-turbo.d.ts.map