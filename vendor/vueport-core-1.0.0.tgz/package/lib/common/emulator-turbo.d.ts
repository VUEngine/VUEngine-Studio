/**
 * Turbo: a button that, held, presses and releases itself over and over.
 *
 * The rhythm is counted in emulated frames rather than wall-clock time, so that
 * it is the same at any speed and the same in both windows of a linked pair:
 * a turbo button is pressed for `rate` frames and released for `rate` frames,
 * and which half of that a frame falls in depends on nothing but its number.
 */
/** Frames per half period when nothing says otherwise: about 12.5 presses a second. */
export declare const DEFAULT_TURBO_RATE = 2;
/** The fastest and slowest rates the settings offer, in frames per half period. */
export declare const TURBO_RATE_RANGE: {
    min: number;
    max: number;
};
/** A rate made safe to count with: a whole number within {@link TURBO_RATE_RANGE}. */
export declare function clampTurboRate(rate: number): number;
/**
 * Whether turbo buttons are down on this frame.
 *
 * Down for the first half of every period, so a turbo press that starts on a
 * period boundary reaches the game at once.
 */
export declare function turboPressedOn(frame: number, rate: number): boolean;
/** The mask a frame runs with: the held buttons, plus the turbo ones while they are down. */
export declare function withTurbo(keys: number, turboKeys: number, frame: number, rate: number): number;
//# sourceMappingURL=emulator-turbo.d.ts.map