/**
 * Where the Virtual Boy's columns land on screen, from the column table.
 *
 * The display unit draws a column at a time onto an oscillating mirror, and
 * the column table says how long each group of 4 columns is lit. Measured on
 * hardware with `column-table-test` (see the vb projects folder): the display
 * period follows the table exactly — Column Length + 1, in units of 200ns —
 * and the mirror swings sinusoidally once per 20ms frame. Nintendo's table is
 * that sinusoid's inverse speed to within a pixel, which is what keeps its
 * columns evenly spaced. Another table therefore spaces them differently: a
 * column given longer leaves a gap before the next, and one shown past the end
 * of the swing comes back the other way.
 *
 * The mirror's motion is not a guess: it is fitted to Nintendo's table, as
 * x(t) = a + b·sin ωt + c·cos ωt with ω from the 20ms frame, and what the fit
 * misses of that table (under a pixel, the table being in whole steps of
 * 200ns) is added back as a correction, so that Nintendo's table maps every
 * column exactly onto itself. Every commercial game uses it, and for those
 * nothing here changes a pixel.
 *
 * Which entries the display uses is up to the servo. The core reads them from
 * where a measured unit settled, `VB_COLUMN_TABLE_START`; the lengths it hands
 * over (`vbGetColumnLengths`) are those of the image shown.
 */
/** Nintendo's recommended column table, Column Length only, as every commercial game loads it. */
export declare const VB_COLUMN_TABLE: readonly number[];
/**
 * The entry each eye's display begins with, left eye first: where the servo of
 * a measured unit settled. Must match the core's reset values of CTA.
 */
export declare const VB_COLUMN_TABLE_START: readonly [number, number];
/** Column groups per eye: one table entry per 4 columns. */
export declare const VB_COLUMN_GROUPS = 96;
/**
 * The mirror while it is not yet in step with the display, see
 * `mirrorSpinUp`: the picture `stretch` times as wide as once settled, about
 * its left edge, which stays where it is.
 */
export interface MirrorState {
    stretch: number;
}
/** Whether an eye was shown with exactly the lengths Nintendo's table gives it. */
export declare function isReferenceColumns(lengths: ArrayLike<number>, eye: number): boolean;
/**
 * The screen position of each of an eye's 385 column edges, in pixels, for
 * the lengths it was shown with. Nintendo's table gives 0, 1, … 384.
 */
export declare function columnEdges(lengths: ArrayLike<number>, eye: number, state?: MirrorState): Float64Array;
/** How the picture looks some frames after the machine is switched on: a mirror state, and how much light is let through. */
export interface SpinUpFrame extends MirrorState {
    light: number;
}
/**
 * The display unit coming to life, frame by frame from power on; undefined
 * once it has settled.
 *
 * Measured on hardware (`column-table-fx`, display switched on at once, cold
 * start filmed twice, in real time and at 240fps): nothing at all for about
 * 4s, whatever the program does, then the whole picture at full brightness,
 * every frame. Its left edge stays put; the rest is stretched from it, the
 * right edge first a little wide, then 6% short, 3.5% wide at 1.75s and a
 * little short again, settled after some 5s. How the first second goes
 * differed between the two starts (the other began 10% wide and came down
 * slowly); the later breathing did not. Four seconds is long to look at
 * nothing every time a game is loaded, so unless `fullDelay` asks for it the
 * wait is shortened; the settling is as measured either way.
 */
export declare function mirrorSpinUp(frame: number, fullDelay?: boolean): SpinUpFrame | undefined;
/**
 * How each screen pixel of one eye is lit by the columns: for pixel x, the
 * columns `columns[offsets[x]] … columns[offsets[x + 1] - 1]`, each times its
 * `weights` entry.
 *
 * A column is not lit for the whole of its time but for a pulse at its start
 * — the brightness duration, repeated, a fraction of a microsecond against
 * the ten or more the column lasts — so its light is a thin line where the
 * mirror stood then, not a band across the time it was given. On hardware a
 * column given far more time than its neighbours shows as a line with a gap
 * after it, not as a wider pixel. Each column's light goes to the pixel at
 * its position, shared with the next one by how far between the two it fell;
 * Nintendo's table puts every column exactly on its own pixel. Columns that
 * fall closer than a pixel apart add up there, as light does, and what falls
 * off the screen's 384 pixels is not seen.
 */
export interface ColumnSpread {
    offsets: Uint32Array;
    columns: Uint16Array;
    weights: Float32Array;
}
export declare function columnSpread(edges: Float64Array): ColumnSpread;
//# sourceMappingURL=vb-column-geometry.d.ts.map