/**
 * Where the VB's columns land on screen, from the column table. Measured on hardware (`column-table-test` in
 * the vb projects folder): the display period follows the table exactly (Column Length + 1, in 200ns units)
 * and the mirror swings sinusoidally once per 20ms frame. Nintendo's table is that sinusoid's inverse speed to
 * within a pixel; another table spaces columns differently (a longer column leaves a gap, one past the end of
 * the swing comes back the other way). The mirror is fitted to Nintendo's table as x(t) = a + b·sin ωt + c·cos ωt,
 * with the residual (under a pixel) added back, so Nintendo's table, which every commercial game uses, maps
 * exactly onto itself. The core reads the entries from where a measured unit's servo settled,
 * `VB_COLUMN_TABLE_START`; `vbGetColumnLengths` returns those of the image shown
 */
export declare const VB_COLUMN_TABLE: readonly number[];
export declare const VB_COLUMN_TABLE_START: readonly [number, number];
export declare const VB_COLUMN_GROUPS = 96;
export interface MirrorState {
    stretch: number;
}
export declare function isReferenceColumns(lengths: ArrayLike<number>, eye: number): boolean;
export declare function columnEdges(lengths: ArrayLike<number>, eye: number, state?: MirrorState): Float64Array;
export interface SpinUpFrame extends MirrorState {
    light: number;
}
/**
 * The display unit coming to life after power on; undefined once settled. Measured on hardware
 * (`column-table-fx`, cold start filmed twice, real time and 240fps): nothing for about 4s whatever the program
 * does, then the full picture at full brightness. The left edge stays put; the right edge starts a little wide,
 * goes 6% short, 3.5% wide at 1.75s, a little short again, settled after some 5s. The first second differed
 * between starts (the other began 10% wide), the later breathing did not. The 4s wait is shortened unless
 * `fullDelay` asks for it; the settling is as measured
 */
export declare function mirrorSpinUp(frame: number, fullDelay?: boolean): SpinUpFrame | undefined;
/**
 * How each screen pixel of one eye is lit: for pixel x, columns `columns[offsets[x]] … columns[offsets[x + 1] - 1]`,
 * each times its `weights` entry. A column is only lit for a pulse at its start (the brightness duration, a
 * fraction of a microsecond against ten or more), so its light is a thin line where the mirror stood, not a
 * band; on hardware a much longer column shows as a line with a gap after it. Each line lights the one pixel
 * it is nearest to, so the picture stays as sharp as the hardware's: sharing it between the two nearest pixels
 * smeared every column of a table only slightly off Nintendo's (SD Gundam's and V-Tetris' right eye, a few
 * pixels over) across two. Nintendo's table puts every column exactly on its own. Where columns are crowded
 * (closer than CROWDED) they add up; where they are a little further apart than a pixel and rounding leaves one
 * out, it takes the nearer column's light (a gap of at most GAP), and only a wider gap stays dark. What falls
 * off the 384 pixels is not seen
 */
export interface ColumnSpread {
    offsets: Uint32Array;
    columns: Uint16Array;
    weights: Float32Array;
}
export declare function columnSpread(edges: Float64Array): ColumnSpread;
//# sourceMappingURL=vb-column-geometry.d.ts.map