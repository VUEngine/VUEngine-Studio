/** Buttons held from one frame to another, both included. */
export interface InputSpan {
    from: number;
    to: number;
    keys: number;
}
/**
 * What the machine is told is held, frame by frame.
 *
 * Spans and a movie can be combined: spans win where they cover a frame, and
 * where several do their buttons are held together. A frame neither covers is
 * left to the machine's own `keys`, which is how "hold nothing, except press A
 * at frame 120" is written without spelling out every frame in between.
 *
 * Frames are the machine's — see `VbMachine.frame` — which are the app's too:
 * a movie recorded in VUEPort replays here frame for frame.
 */
export declare class VbInput {
    protected readonly spans: InputSpan[];
    protected movie: number[];
    protected movieStart: number;
    constructor(spans?: InputSpan[]);
    /**
     * One span from `120-180:A+RIGHT`, `120:A` (that frame alone) or
     * `120+30:A` (thirty frames from 120).
     */
    static parseSpan(spec: string): InputSpan;
    add(span: InputSpan): this;
    /**
     * Play a movie's frames from `start` on.
     *
     * The frames are VbKey masks, as `parseVesMovie` reads them; the signature
     * bit is added here the way the app's movie player adds it.
     */
    setMovie(frames: number[], start?: number): this;
    /** What is held at a frame, or undefined for a frame nothing here covers. */
    keysAt(frame: number): number | undefined;
    /** The last frame anything here covers, or -1 for an empty script. */
    get end(): number;
}
//# sourceMappingURL=vb-input.d.ts.map