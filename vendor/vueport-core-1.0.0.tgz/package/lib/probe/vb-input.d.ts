export interface InputSpan {
    from: number;
    to: number;
    keys: number;
}
export declare class VbInput {
    protected readonly spans: InputSpan[];
    protected movie: number[];
    protected movieStart: number;
    constructor(spans?: InputSpan[]);
    static parseSpan(spec: string): InputSpan;
    add(span: InputSpan): this;
    setMovie(frames: number[], start?: number): this;
    keysAt(frame: number): number | undefined;
    get end(): number;
}
//# sourceMappingURL=vb-input.d.ts.map