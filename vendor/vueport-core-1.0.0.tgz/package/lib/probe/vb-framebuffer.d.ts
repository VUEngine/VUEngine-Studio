import { VbMachine } from './vb-machine';
import { VbPicture } from './vb-picture';
/**
 * The frame buffers as the VIP keeps them, before brightness, palettes and the display get to them.
 * The VIP's own four (left/right eye, buffer 0/1) hold a shade of 0-3 per pixel, four pixels to a byte, a column
 * of 224 pixels in 64 bytes (56 used). A VB Color game's Color Framebuffer has a byte per pixel beside each,
 * a palette id: the colour shown is `CRAM[id * 4 + shade]`.
 */
export type VbFrameBufferEye = 'left' | 'right';
export interface VbFrameBufferPlace {
    color: boolean;
    eye: VbFrameBufferEye;
    buffer: 0 | 1;
    x: number;
    y: number;
    rows: number;
}
export declare function legacyFrameBufferBase(eye: VbFrameBufferEye, buffer: 0 | 1): number;
export declare function colorFrameBufferBase(eye: VbFrameBufferEye, buffer: 0 | 1): number;
export declare function frameBufferPlace(address: number): VbFrameBufferPlace | undefined;
export declare function readFrameBuffer(vb: VbMachine, eye: VbFrameBufferEye, buffer: 0 | 1, color: boolean): Uint8Array;
export declare function frameBufferPicture(values: Uint8Array, color: boolean): VbPicture;
//# sourceMappingURL=vb-framebuffer.d.ts.map