import { VbMachine } from './vb-machine';
import { VbPicture } from './vb-picture';
/**
 * The frame buffers as the VIP keeps them, rather than the picture made of
 * them: what a pixel *is* before brightness, palettes and the display get to
 * it.
 *
 * Two kinds. The VIP's own four — left and right eye, buffer 0 and 1 — hold a
 * shade of 0 to 3 per pixel, four pixels to a byte, a column of 224 pixels in
 * 64 bytes (56 used). A VB Color game's Color Framebuffer has a byte per pixel
 * beside each of them, a palette id: the colour shown is
 * `CRAM[id * 4 + shade]`, so the two together say everything.
 */
export type VbFrameBufferEye = 'left' | 'right';
/** Where a byte of a frame buffer lands on the screen. */
export interface VbFrameBufferPlace {
    /** The VB Color framebuffer, rather than the VIP's own. */
    color: boolean;
    eye: VbFrameBufferEye;
    buffer: 0 | 1;
    x: number;
    /** The first row the byte holds: four rows from here for the VIP's, one for VB Color's. */
    y: number;
    rows: number;
}
/** Where the VIP's buffer of an eye starts: left 0, left 1, right 0, right 1, 32 KiB apart. */
export declare function legacyFrameBufferBase(eye: VbFrameBufferEye, buffer: 0 | 1): number;
/** Where the Color Framebuffer's page of an eye and buffer starts — the same order as the VIP's. */
export declare function colorFrameBufferBase(eye: VbFrameBufferEye, buffer: 0 | 1): number;
/** Which pixels a byte of either kind of frame buffer holds, or nothing for any other address. */
export declare function frameBufferPlace(address: number): VbFrameBufferPlace | undefined;
/**
 * One frame buffer, row by row, a byte per pixel: the shade for the VIP's,
 * the palette id for VB Color's.
 */
export declare function readFrameBuffer(vb: VbMachine, eye: VbFrameBufferEye, buffer: 0 | 1, color: boolean): Uint8Array;
/**
 * A frame buffer as a picture to look at: shades as four greys, palette ids
 * as their own value in grey. Not a picture of the screen — `shot` is that.
 */
export declare function frameBufferPicture(values: Uint8Array, color: boolean): VbPicture;
//# sourceMappingURL=vb-framebuffer.d.ts.map