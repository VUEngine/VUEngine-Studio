/** What a watch looks at: data written, data read, either, or code run. */
export type VbWatchKind = 'write' | 'read' | 'access' | 'exec';
/** An address, a name, or a start and a length in bytes. */
export type VbWatchTarget = number | string | [number | string, number];
export interface VbWatchSpec {
    kind: VbWatchKind;
    /**
     * Where. A bare number is one byte; a name is as big as the build says —
     * a whole `g_stats`, or just `g_stats.lives`. For `exec`, a function's
     * name is its entry, so a hit is a call; give a length to watch more.
     */
    at: VbWatchTarget;
    /** Only hits that satisfy all of these count. */
    when?: {
        /** The value written or read: exactly, or within [min, max]. */
        value?: number | [number, number];
        /** Writes that change what was there. */
        changed?: boolean;
        /** Only from this code: an address, a range, or a function's name for all of it. */
        pc?: VbWatchTarget;
        /** Only in these frames, both included. */
        frames?: [number, number];
    };
    /** Write the hit down and go on (the default), or stop the machine on it. */
    action?: 'log' | 'stop';
    /**
     * What to take down with each hit: `regs` for all program registers, any
     * register by name (`r6`, `sp`, `lp`), and `stack` for the call stack.
     */
    capture?: string[];
    /** Hits kept in {@link VbWatch.hits}; counting goes on past it. Default 1000. */
    limit?: number;
    /** A last say on each hit, for what the fields above cannot express. */
    test?: (hit: VbWatchHit) => boolean;
    /**
     * Something to do on each hit, once the core has returned and the machine
     * can be changed — registers set, memory written. The machine goes on
     * after, unless the watch stops it, in which case this comes first.
     *
     * At an instruction (`exec`) it runs before the instruction does; at an
     * access, in the middle of the instruction making it, which finishes once
     * the machine goes on.
     */
    then?: (hit: VbWatchHit) => void;
    /**
     * Fold hits by place as well as by instruction: the key of the place an
     * address is in — a column of a frame buffer, a block of bytes. See
     * {@link VbWatch.places}.
     */
    fold?: (address: number) => number;
}
export interface VbWatchHit {
    /** The watch's own number. */
    watch: number;
    kind: 'write' | 'read' | 'exec';
    frame: number;
    /** The instruction that made the access, or the one about to run. */
    pc: number;
    address: number;
    /** Bytes the access covered: 1, 2 or 4. Zero for `exec`. */
    size: number;
    /** What was written or read. */
    value?: number;
    /** What was there before a write. */
    old?: number;
    regs?: Record<string, number>;
    /** Call sites, innermost first; see {@link VbMachine.callStack}. */
    stack?: number[];
}
/** Hits from one instruction, folded together. */
export interface VbWatchGroup {
    pc: number;
    count: number;
    firstFrame: number;
    lastFrame: number;
    /** Smallest and largest value seen, where there were values. */
    values?: [number, number];
    /** Lowest and highest address touched. */
    addresses: [number, number];
}
/** Hits on one place, as {@link VbWatchSpec.fold} cuts memory up. */
export interface VbWatchPlace {
    key: number;
    count: number;
    firstFrame: number;
    lastFrame: number;
    /** Lowest and highest address touched. */
    addresses: [number, number];
    /** The instructions that made the hits, with how many each, the busiest first. */
    pcs: {
        pc: number;
        count: number;
    }[];
}
/**
 * One watch on a machine, and everything it has seen.
 *
 * Made by `VbMachine.watch`, which is also what feeds it. The hit list stops
 * growing at the limit so a busy watch cannot eat the heap; the groups never
 * do, since there is one per instruction and not one per hit, and they are
 * what answers "who writes here" for a watch that fired a hundred thousand
 * times.
 */
export declare class VbWatch {
    readonly id: number;
    readonly spec: VbWatchSpec;
    /** The first byte as given, with only the 27 address bits the CPU has. */
    readonly origin: number;
    readonly length: number;
    /** The code the hits have to come from, as a range, if limited. */
    readonly pcRange?: [number, number] | undefined;
    readonly hits: VbWatchHit[];
    /** Every hit, including those past the limit. */
    count: number;
    /** Set by `VbMachine.unwatch`. */
    disposed: boolean;
    protected readonly groups: Map<number, VbWatchGroup>;
    protected readonly placeMap: Map<number, Omit<VbWatchPlace, "pcs"> & {
        pcs: Map<number, number>;
    }>;
    /** First byte covered, after mirrors are folded. */
    start: number;
    /** One past the last byte covered. */
    end: number;
    constructor(id: number, spec: VbWatchSpec, 
    /** The first byte as given, with only the 27 address bits the CPU has. */
    origin: number, length: number, 
    /** The code the hits have to come from, as a range, if limited. */
    pcRange?: [number, number] | undefined);
    /** @internal Fold the range again, for memory whose mirrors have changed. */
    fold(canonical: (address: number) => number): void;
    get limit(): number;
    get stops(): boolean;
    /** Whether an access of this kind is one this watch looks at. */
    covers(kind: 'write' | 'read' | 'exec'): boolean;
    /** Whether a hit passes the conditions that do not need its value. */
    accepts(frame: number, pc: number): boolean;
    /** Whether a value passes the value conditions. */
    acceptsValue(value: number | undefined, old: number | undefined): boolean;
    /** @internal Take a hit down. */
    record(hit: VbWatchHit): void;
    /** The hits folded by instruction, the busiest first. */
    summary(): VbWatchGroup[];
    /** The hits folded by place, in the order of the keys; only with {@link VbWatchSpec.fold}. */
    places(): VbWatchPlace[];
    clear(): void;
}
//# sourceMappingURL=vb-watch.d.ts.map