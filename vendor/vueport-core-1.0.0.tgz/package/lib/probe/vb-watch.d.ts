export type VbWatchKind = 'write' | 'read' | 'access' | 'exec';
export type VbWatchTarget = number | string | [number | string, number];
export interface VbWatchSpec {
    kind: VbWatchKind;
    at: VbWatchTarget;
    when?: {
        value?: number | [number, number];
        changed?: boolean;
        pc?: VbWatchTarget;
        frames?: [number, number];
    };
    action?: 'log' | 'stop';
    capture?: string[];
    limit?: number;
    test?: (hit: VbWatchHit) => boolean;
    then?: (hit: VbWatchHit) => void;
    fold?: (address: number) => number;
}
export interface VbWatchHit {
    watch: number;
    kind: 'write' | 'read' | 'exec';
    frame: number;
    pc: number;
    address: number;
    size: number;
    value?: number;
    old?: number;
    regs?: Record<string, number>;
    stack?: number[];
}
export interface VbWatchGroup {
    pc: number;
    count: number;
    firstFrame: number;
    lastFrame: number;
    values?: [number, number];
    addresses: [number, number];
}
export interface VbWatchPlace {
    key: number;
    count: number;
    firstFrame: number;
    lastFrame: number;
    addresses: [number, number];
    pcs: {
        pc: number;
        count: number;
    }[];
}
export declare class VbWatch {
    readonly id: number;
    readonly spec: VbWatchSpec;
    readonly origin: number;
    readonly length: number;
    readonly pcRange?: [number, number] | undefined;
    readonly hits: VbWatchHit[];
    count: number;
    disposed: boolean;
    protected readonly groups: Map<number, VbWatchGroup>;
    protected readonly placeMap: Map<number, Omit<VbWatchPlace, "pcs"> & {
        pcs: Map<number, number>;
    }>;
    start: number;
    end: number;
    constructor(id: number, spec: VbWatchSpec, origin: number, length: number, pcRange?: [number, number] | undefined);
    fold(canonical: (address: number) => number): void;
    get limit(): number;
    get stops(): boolean;
    covers(kind: 'write' | 'read' | 'exec'): boolean;
    accepts(frame: number, pc: number): boolean;
    acceptsValue(value: number | undefined, old: number | undefined): boolean;
    record(hit: VbWatchHit): void;
    summary(): VbWatchGroup[];
    places(): VbWatchPlace[];
    clear(): void;
}
//# sourceMappingURL=vb-watch.d.ts.map