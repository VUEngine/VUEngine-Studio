import { VbPixelOrigin } from '../common/vb-pixel-origin';
export * from '../common/vb-pixel-origin';
/** One line in the terms of the app's debug panels; `describe` names code addresses. */
export declare function describeOrigin(origin: VbPixelOrigin, describe: (address: number) => string, withPixel?: boolean): string;
//# sourceMappingURL=vb-origin.d.ts.map