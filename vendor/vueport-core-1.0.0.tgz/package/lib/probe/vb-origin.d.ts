import { VbPixelOrigin } from '../common/vb-pixel-origin';
export * from '../common/vb-pixel-origin';
export declare function describeOrigin(origin: VbPixelOrigin, describe: (address: number) => string, withPixel?: boolean): string;
//# sourceMappingURL=vb-origin.d.ts.map