import { VsuChannel } from '../browser/panels/emulator-vsu-memory';
import { RomHeader } from '../browser/emulator-types';
import { VesEmulatorSaveStateIdentity } from '../common/emulator-save-state';
import { Registers } from '../common/vb-protocol';
import { WasmExports } from '../worker/vb-wasm';
import { VsuLayout } from '../worker/vb-vsu-layout';
import { VbInput } from './vb-input';
import { VbEye, VbFrame, VbPicture } from './vb-picture';
import { VbSymbols } from './vb-symbols';
import { VbWatch, VbWatchHit, VbWatchSpec, VbWatchTarget } from './vb-watch';
import { LiveProfileFrame, LiveProfileSnapshot, VesLiveProfileCollector } from '../common/emulator-live-profile';
export interface VbMachineOptions {
    core: Uint8Array;
    rom: Uint8Array;
    sram?: Uint8Array;
    sramWindow?: number;
    elf?: Uint8Array;
    symbols?: VbSymbols;
    hardware?: 'vb' | 'vbc' | 'auto';
    esSound?: boolean;
}
export type VbStopReason = 'breakpoint' | 'step' | 'until' | 'watch' | 'fault';
export type VbVipEvent = 'frame' | 'drawing' | 'drawn' | 'framestart' | 'gamestart' | 'xpend' | 'sbhit' | 'lfbend' | 'rfbend' | 'timeerr' | 'scanerr';
export declare const VB_VIP_EVENTS: VbVipEvent[];
export interface VbBranch {
    from: number;
    to: number;
    exception?: number;
    times?: number;
}
export declare function isFault(cause: number): boolean;
export declare function exceptionName(cause: number): string;
export interface VbStop {
    reason: VbStopReason;
    pc: number;
    frame: number;
    watch?: VbWatch;
    hit?: VbWatchHit;
    exception?: number;
}
export interface VbRunResult {
    frames: number;
    frame: number;
    stop?: VbStop;
    stalled?: boolean;
}
export type VbRunTarget = {
    pc: number | string;
} | {
    frame: number;
} | {
    vip: VbVipEvent;
} | {
    predicate: (machine: VbMachine) => boolean;
};
export interface VbInstruction {
    address: number;
    code: number[];
    mnemonic: string;
    operands: string[];
    text: string;
    symbol?: string;
    comment?: string;
    source?: {
        file: string;
        line: number;
    };
}
export interface VbSnapshot {
    readonly state: Uint8Array;
    readonly frame: number;
    readonly vipFrames: number;
    readonly chunkLeft: number;
    readonly refire?: Refire;
    readonly calls?: StackFrame[];
    readonly gamePakInterrupt?: boolean;
}
interface StackFrame {
    site: number;
    exception?: number;
}
interface Refire {
    kind: 'exec' | 'read' | 'write' | 'exception';
    address: number;
}
export declare class VbMachine {
    protected readonly wasm: WasmExports;
    protected readonly options: VbMachineOptions;
    readonly header: RomHeader;
    readonly vbc: boolean;
    readonly symbols?: VbSymbols;
    readonly romBytes: number;
    frame: number;
    vipFrames: number;
    keys: import("../common/vb-constants").VbKey;
    input?: VbInput;
    protected readonly sim: number;
    protected readonly rom: Uint8Array;
    protected readonly romPointer: number;
    protected readonly ramPointer: number;
    protected readonly ramBytes: number;
    protected readonly samples: number;
    protected readonly clocksPointer: number;
    protected readonly simsPointer: number;
    protected chunkLeft: number;
    protected stopping?: VbStop;
    protected pausing: {
        watch: VbWatch;
        hit: VbWatchHit;
    }[];
    protected refire?: Refire;
    protected readonly breakpointSet: Set<number>;
    protected untilPc?: number;
    protected watchList: VbWatch[];
    protected writeWatches: VbWatch[];
    protected readWatches: VbWatch[];
    protected execWatches: VbWatch[];
    protected nextWatchId: number;
    protected ring?: {
        from: Uint32Array;
        to: Uint32Array;
        cause: Uint16Array;
        times: Uint32Array;
        next: number;
        count: number;
    };
    protected lastExec?: number;
    protected lastNext?: number;
    protected pendingCause: number;
    protected coverageRom?: Uint32Array;
    protected coverageOther?: Map<number, number>;
    protected vipUntil?: {
        event: VbVipEvent;
        last: number;
    };
    protected faultStop: boolean;
    protected foldedMask: number;
    protected calls?: StackFrame[];
    protected stepping?: {
        seen: number;
        target: number;
    };
    protected terminalBytes: number[];
    protected readonly esSound: boolean;
    protected esSoundCommands: number[];
    protected gamePakInterrupt: boolean;
    protected executeSlot: number;
    protected writeSlot: number;
    protected readSlot: number;
    protected exceptionSlot: number;
    protected exceptionInstalled: boolean;
    protected executeInstalled: boolean;
    protected readInstalled: boolean;
    protected constructor(wasm: WasmExports, options: VbMachineOptions);
    static create(options: VbMachineOptions): Promise<VbMachine>;
    clone(): Promise<VbMachine>;
    reset(): void;
    runFrames(count: number): VbRunResult;
    runUntil(target: VbRunTarget, options?: {
        maxFrames?: number;
    }): VbRunResult;
    protected vipSample(event: VbVipEvent): number;
    protected vipHappened(): boolean;
    startProfile(window?: number): void;
    stopProfile(): void;
    profile(): LiveProfileSnapshot | undefined;
    profileFrames(): Omit<LiveProfileFrame, 'functions'>[];
    get frameBudget(): number;
    protected clocksView?: Uint32Array;
    protected live?: {
        collector: VesLiveProfileCollector;
        kinds: Uint8Array;
        left: number;
        cycle: number;
        pictures: number;
        framed: boolean;
    };
    protected liveStep(pc: number): void;
    protected endLiveFrame(force?: boolean): void;
    traceBranches(depth?: number): void;
    branches(): VbBranch[];
    get stopOnFault(): boolean;
    set stopOnFault(stop: boolean);
    startCoverage(): void;
    stopCoverage(): void;
    coverage(): Map<number, number>;
    step(count?: number): VbRunResult;
    get breakpoints(): ReadonlySet<number>;
    addBreakpoint(at: number | string): number;
    removeBreakpoint(at: number | string): void;
    protected runChunk(): 'done' | 'stopped' | 'stalled';
    protected takeGamePakInterrupt(): void;
    protected result(start: number, outcome: 'done' | 'stopped' | 'stalled'): VbRunResult;
    protected requestStop(reason: VbStopReason, refire: Refire, watch?: VbWatch, hit?: VbWatchHit): number;
    protected requestPause(refire: Refire): number;
    protected recordHit(watch: VbWatch, hit: VbWatchHit): void;
    watch(spec: VbWatchSpec): VbWatch;
    unwatch(watch: VbWatch): void;
    get watches(): readonly VbWatch[];
    callStack(): number[];
    followCalls(follow?: boolean): void;
    protected following: boolean;
    protected wantsCalls(): boolean;
    protected extentOf(target: VbWatchTarget, use: 'data' | 'entry' | 'whole'): [number, number];
    canonical(address: number): number;
    protected wramMask(): number;
    protected hitFor(watch: VbWatch, kind: VbWatchHit['kind'], pc: number, address: number, size: number, value?: number, old?: number): VbWatchHit;
    protected offer(watches: VbWatch[], kind: 'write' | 'read', address: number, type: number, valuePointer: number): number;
    protected updateCallbacks(): void;
    protected wantsExecute(): boolean;
    protected wantsRead(): boolean;
    protected onExecute(pc: number, codePointer: number, length: number): number;
    protected followCall(pc: number, code: number): void;
    protected onException(causePointer: number): number;
    protected recordBranch(from: number, to: number): void;
    protected onWrite(address: number, type: number, valuePointer: number): number;
    protected onRead(address: number, type: number, valuePointer: number): number;
    protected takeRefire(kind: Refire['kind'], address: number): boolean;
    read(address: number | string, length: number): Uint8Array;
    read8(address: number | string): number;
    read16(address: number | string): number;
    read32(address: number | string): number;
    write(address: number | string, bytes: ArrayLike<number>): void;
    write8(address: number | string, value: number): void;
    write16(address: number | string, value: number): void;
    write32(address: number | string, value: number): void;
    patch(address: number | string, bytes: ArrayLike<number>): void;
    sram(): Uint8Array;
    get pc(): number;
    registers(): Registers;
    register(name: string): number;
    protected programRegisters(): Record<string, number>;
    setRegister(name: string, value: number): void;
    resolve(spec: number | string): number;
    describe(address: number): string;
    snapshot(): VbSnapshot;
    restore(snapshot: VbSnapshot): void;
    saveState(label?: string): Promise<Uint8Array>;
    loadState(file: Uint8Array, options?: {
        otherRom?: boolean;
    }): Promise<void>;
    clearInstructionCache(): void;
    loadStruct(state: Uint8Array): void;
    protected identity(): VesEmulatorSaveStateIdentity;
    protected restoreStruct(state: Uint8Array): void;
    frameBuffer(): VbFrame;
    picture(eye?: VbEye): VbPicture;
    screenshot(options?: {
        eye?: VbEye;
        scale?: number;
    }): Promise<Uint8Array>;
    displayedBuffer(): 0 | 1;
    keepOrigins(keep?: boolean): void;
    get keepsOrigins(): boolean;
    pixelOrigins(eye: 'left' | 'right', buffer: 0 | 1, region?: {
        x: number;
        y: number;
        width: number;
        height: number;
    }): Uint32Array;
    drawnCharacter(buffer: 0 | 1, index: number): Uint8Array | undefined;
    drawnPalettes(buffer: 0 | 1): number[][] | undefined;
    protected originsPointer: number;
    protected keepingOrigins: boolean;
    protected clearOrigins(): void;
    disassemble(at: number | string, count: number, before?: number): VbInstruction[];
    vsu(): {
        channels: VsuChannel[];
        waveforms: number[][];
        modulation: number[];
    };
    protected vsuLayout?: VsuLayout;
    get terminal(): string;
    takeTerminal(): string;
    takeEsSound(): number[];
    protected copyIn(bytes: Uint8Array): number;
    protected heap(): Uint8Array;
    protected heapView?: Uint8Array;
    protected u32(pointer: number, length?: number): Uint32Array;
}
export declare function accessBytes(type: number): number;
export {};
//# sourceMappingURL=vb-machine.d.ts.map