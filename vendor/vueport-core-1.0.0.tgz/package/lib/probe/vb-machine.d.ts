import { VsuChannel } from '../browser/panels/emulator-vsu-memory';
import { RomHeader } from '../browser/emulator-types';
import { VesEmulatorSaveStateIdentity } from '../common/emulator-save-state';
import { Registers } from '../common/vb-protocol';
import { WasmExports } from '../worker/vb-wasm';
import { VsuLayout } from '../worker/vb-vsu-layout';
import { VbInput } from './vb-input';
import { VbEye, VbFrame, VbPicture } from './vb-picture';
import { VbSymbols } from './vb-symbols';
import { VbWatch, VbWatchHit, VbWatchSpec, VbWatchTarget } from './vb-watch';
import { LiveProfileFrame, LiveProfileSnapshot, VesLiveProfileCollector } from '../common/emulator-live-profile';
export interface VbMachineOptions {
    /** The bytes of `core.wasm`. Copied, never patched in place. */
    core: Uint8Array;
    rom: Uint8Array;
    /** Game Pak RAM to start with, from the bottom of the window up. */
    sram?: Uint8Array;
    /** How much Game Pak RAM the cartridge answers on; the app's default is all 16 MiB of it. */
    sramWindow?: number;
    /** The build's `.elf`, for names. */
    elf?: Uint8Array;
    /** Names already read from one, which wins over `elf` — what a host making many machines of one build passes. */
    symbols?: VbSymbols;
    /** Which console. `auto`, the default, asks the ROM header, as the app does. */
    hardware?: 'vb' | 'vbc' | 'auto';
    /**
     * The cartridge has ESSound on it: its init command is answered with a
     * Game Pak interrupt, as the app answers it for a game with ESSound
     * tracks. A game that waits for that answer waits for ever without it.
     */
    esSound?: boolean;
}
/** Why a run ended before it had run everything it was asked to. */
export type VbStopReason = 'breakpoint' | 'step' | 'until' | 'watch' | 'fault';
/**
 * Moments of the VIP's to run to.
 *
 * `frame` is a frame shown: both eyes out, which is the moment the app counts
 * a VIP frame at. `drawing` and `drawn` are the drawing processor starting
 * and finishing a framebuffer, read off XPSTTS. The rest are interrupt
 * requests, seen as their INTPND bit coming on — a game that never clears
 * one shows it once, and never again.
 */
export type VbVipEvent = 'frame' | 'drawing' | 'drawn' | 'framestart' | 'gamestart' | 'xpend' | 'sbhit' | 'lfbend' | 'rfbend' | 'timeerr' | 'scanerr';
export declare const VB_VIP_EVENTS: VbVipEvent[];
/** One discontinuity in the program's flow: a branch, a call, a return, or an exception taken. */
export interface VbBranch {
    from: number;
    to: number;
    /** The exception code, for one that an exception caused. */
    exception?: number;
    /** How many times in a row it was taken, where more than once: a loop is one entry, not the whole ring. */
    times?: number;
}
/**
 * Exception codes that are a program going wrong rather than an interrupt or
 * a TRAP it asked for: the FPU's four, zero division, an invalid opcode, the
 * address trap and a fault while handling a fault.
 */
export declare function isFault(cause: number): boolean;
/** What an exception code is, in words. */
export declare function exceptionName(cause: number): string;
export interface VbStop {
    reason: VbStopReason;
    /** The instruction the machine is standing on. */
    pc: number;
    frame: number;
    /** For a watch: which, and the hit it stopped on. */
    watch?: VbWatch;
    hit?: VbWatchHit;
    /** For a fault: its exception code. */
    exception?: number;
}
export interface VbRunResult {
    /** Frames completed by this call. */
    frames: number;
    /** The machine's frame count afterwards. */
    frame: number;
    /** Set when something stopped the run early. */
    stop?: VbStop;
    /**
     * Set when the machine stopped advancing at all — a crash into a state the
     * core cannot leave, the way the app's stall guard reports it.
     */
    stalled?: boolean;
}
export type VbRunTarget = {
    pc: number | string;
} | {
    frame: number;
} | {
    vip: VbVipEvent;
} | {
    predicate: (machine: VbMachine) => boolean;
};
/** One decoded instruction, with what the build calls the things it touches. */
export interface VbInstruction {
    address: number;
    /** The instruction's halfwords. */
    code: number[];
    mnemonic: string;
    operands: string[];
    /** `mnemonic operands`, as the app's Disassembly panel writes it. */
    text: string;
    /** The function it is in, as `name+0x1c`, where the build says. */
    symbol?: string;
    /** Names for the addresses its operands lead to. */
    comment?: string;
    /** The source line it came from, where the build says. */
    source?: {
        file: string;
        line: number;
    };
}
/**
 * A moment of the machine, to come back to.
 *
 * Only valid in the machine that took it: the state struct holds absolute
 * pointers into this instance's memory. Game Pak RAM is not in it, the same as
 * the app's save states — a save is the cartridge's, not the moment's.
 */
export interface VbSnapshot {
    readonly state: Uint8Array;
    readonly frame: number;
    readonly vipFrames: number;
    /** @internal Where in a frame's clocks the machine stood. */
    readonly chunkLeft: number;
    /** @internal What the core will report again on resuming, see {@link VbMachine.refire}. */
    readonly refire?: Refire;
    /** @internal The call stack as far as it was being followed. */
    readonly calls?: StackFrame[];
    /** @internal An ESSound answer not taken yet. */
    readonly gamePakInterrupt?: boolean;
}
/**
 * One level of the followed call stack: a call, or an exception taken —
 * an interrupt, a TRAP — which returns by RETI rather than by `jmp [lp]`.
 */
interface StackFrame {
    site: number;
    exception?: number;
}
/** A callback report the core repeats when a refused instruction is resumed. */
interface Refire {
    kind: 'exec' | 'read' | 'write' | 'exception';
    address: number;
}
/**
 * A Virtual Boy to drive from code.
 *
 * The same core and the same frame as the app: a frame is a twentieth of a
 * second of clocks, buttons change at frame boundaries, and the frame count
 * starts at zero with the cartridge. A movie recorded in VUEPort, or an input
 * script written for one, plays out here exactly as it did there.
 *
 * Everything but creating one is synchronous. A run that is stopped partway
 * through a frame — by a breakpoint, a step, a watch — resumes from the same
 * clock, so stopping never shifts the machine against its frames.
 */
export declare class VbMachine {
    protected readonly wasm: WasmExports;
    protected readonly options: VbMachineOptions;
    readonly header: RomHeader;
    readonly vbc: boolean;
    readonly symbols?: VbSymbols;
    /** The cartridge's size in bytes, after padding. */
    readonly romBytes: number;
    /** Frames completed since the cartridge went in or the machine was reset. */
    frame: number;
    /** Pictures the VIP has finished in that time, which is not always the same. */
    vipFrames: number;
    /** What is held on any frame the input script leaves alone. */
    keys: import("../common/vb-constants").VbKey;
    /** Buttons frame by frame; see {@link VbInput}. */
    input?: VbInput;
    protected readonly sim: number;
    protected readonly rom: Uint8Array;
    protected readonly romPointer: number;
    protected readonly ramPointer: number;
    protected readonly ramBytes: number;
    protected readonly samples: number;
    protected readonly clocksPointer: number;
    protected readonly simsPointer: number;
    /** Clocks of the current frame not yet run; zero between frames. */
    protected chunkLeft: number;
    protected stopping?: VbStop;
    /** Hits whose watches have something to do once the core has returned; see {@link VbWatchSpec.then}. */
    protected pausing: {
        watch: VbWatch;
        hit: VbWatchHit;
    }[];
    /**
     * The report the core will make again when the instruction it was refused
     * at is resumed, so that it is not counted, logged or stopped at twice.
     *
     * An execute callback that refuses an instruction leaves the CPU about to
     * ask again for the same one; a read or write callback that refuses an
     * access leaves the instruction half done, and resuming it repeats the
     * access and the callback with it. Measured against the core's `cpu.c`.
     */
    protected refire?: Refire;
    /** Breakpoints, with mirrors folded — see {@link canonical}. */
    protected readonly breakpointSet: Set<number>;
    protected untilPc?: number;
    protected watchList: VbWatch[];
    protected writeWatches: VbWatch[];
    protected readWatches: VbWatch[];
    protected execWatches: VbWatch[];
    protected nextWatchId: number;
    /** The last branches, while they are being kept: a ring of `from`, `to` and exception code. */
    protected ring?: {
        from: Uint32Array;
        to: Uint32Array;
        cause: Uint16Array;
        times: Uint32Array;
        next: number;
        count: number;
    };
    protected lastExec?: number;
    protected lastNext?: number;
    /** An exception taken, to be put on the branch it causes. */
    protected pendingCause: number;
    /** Instructions run, by halfword of the cartridge, and elsewhere by address. */
    protected coverageRom?: Uint32Array;
    protected coverageOther?: Map<number, number>;
    protected vipUntil?: {
        event: VbVipEvent;
        last: number;
    };
    protected faultStop: boolean;
    /** The WRAM size the watch ranges were last folded for. */
    protected foldedMask: number;
    /** The call stack, while anything wants it followed. */
    protected calls?: StackFrame[];
    protected stepping?: {
        seen: number;
        target: number;
    };
    protected terminalBytes: number[];
    protected readonly esSound: boolean;
    protected esSoundCommands: number[];
    /** The ESSound init has been seen and its interrupt not yet taken. */
    protected gamePakInterrupt: boolean;
    protected executeSlot: number;
    protected writeSlot: number;
    protected readSlot: number;
    protected exceptionSlot: number;
    protected exceptionInstalled: boolean;
    protected executeInstalled: boolean;
    protected readInstalled: boolean;
    protected constructor(wasm: WasmExports, options: VbMachineOptions);
    static create(options: VbMachineOptions): Promise<VbMachine>;
    /**
     * Another machine like this one, standing at the same moment: the same
     * core, the cartridge as it is now (patches included), its RAM, and the
     * frame count — a branch to try something on. Watches, breakpoints,
     * buttons and pixel origins stay behind.
     */
    clone(): Promise<VbMachine>;
    /** Power the machine off and on again, which also starts the frame count over. */
    reset(): void;
    /** Run whole frames, or fewer if something stops the machine. */
    runFrames(count: number): VbRunResult;
    /**
     * Run until the machine reaches an instruction, a frame, or a condition
     * checked at the end of every frame — or until `maxFrames` have gone by,
     * whichever is first. A result with no `stop` is one that ran out of
     * frames without getting there.
     */
    runUntil(target: VbRunTarget, options?: {
        maxFrames?: number;
    }): VbRunResult;
    /** What decides a VIP event, as it reads now. */
    protected vipSample(event: VbVipEvent): number;
    /** Whether the VIP event being run to has just happened, judged before an instruction. */
    protected vipHappened(): boolean;
    /**
     * Profile from now on, as the app's CPU Profiler does live: every
     * instruction's cost to the clock, charged to the function it is in, and
     * frame by frame what was work and what was idling — halted, or going
     * round a loop until the interrupt it waited for came (see
     * `emulator-live-profile.ts`). `window` is how many frames are kept.
     *
     * A game frame is as many pictures as `FRMCYC` says, as in the app, so a
     * game drawing every second picture is measured against two pictures'
     * worth of clocks.
     */
    startProfile(window?: number): void;
    stopProfile(): void;
    /** The profile's window, as the app's panel reads it; undefined when not profiling. */
    profile(): LiveProfileSnapshot | undefined;
    /** Each frame of the window: clocks, of them halted and waiting, and instructions. */
    profileFrames(): Omit<LiveProfileFrame, 'functions'>[];
    /** Clocks a game frame has, by FRMCYC as it stands. */
    get frameBudget(): number;
    protected clocksView?: Uint32Array;
    protected live?: {
        collector: VesLiveProfileCollector;
        kinds: Uint8Array;
        /** Clocks of the budget left when the last instruction was reported. */
        left: number;
        cycle: number;
        pictures: number;
        framed: boolean;
    };
    /** One instruction about to run: what the one before it cost goes to whatever was running. */
    protected liveStep(pc: number): void;
    /**
     * A picture is done: the end of a game frame when FRMCYC says so, or
     * with `force` whatever has gathered — a chunk with no picture at all,
     * from a machine whose display is off.
     */
    protected endLiveFrame(force?: boolean): void;
    /**
     * Keep the last `depth` branches the program takes — every place the flow
     * does not go on to the next instruction — or stop keeping them with 0.
     * What a crash report is made of: where it came from on its way to where
     * it fell over.
     */
    traceBranches(depth?: number): void;
    /** The branches kept, oldest first, with mirrors folded. */
    branches(): VbBranch[];
    /**
     * Stop before the CPU takes a fault — see {@link isFault} — with the
     * machine standing where it went wrong and the exception not yet taken.
     */
    get stopOnFault(): boolean;
    set stopOnFault(stop: boolean);
    /** Count every instruction run from now on, for {@link coverage}. Any earlier count is forgotten. */
    startCoverage(): void;
    stopCoverage(): void;
    /** How often each instruction ran since {@link startCoverage}, by address with mirrors folded. */
    coverage(): Map<number, number>;
    /**
     * Run instructions, one by default, and stop on an instruction boundary.
     *
     * Counted from where the machine stands: after a stop at an instruction,
     * that instruction is the first one run; after a stop inside one — a
     * watched access — finishing it is.
     */
    step(count?: number): VbRunResult;
    get breakpoints(): ReadonlySet<number>;
    /** Stop before the instruction at an address runs. Takes a number or a symbol. */
    addBreakpoint(at: number | string): number;
    removeBreakpoint(at: number | string): void;
    /**
     * Run what is left of the current frame, starting a new one if none is
     * under way: buttons are set at the start of a frame and nowhere else.
     */
    protected runChunk(): 'done' | 'stopped' | 'stalled';
    /**
     * The cartridge's answer to ESSound's init: a Game Pak interrupt, raised
     * between two `Emulate` calls because an interrupt is only taken between
     * instructions — the same moment, and the same steps, as the worker's
     * `serviceGamePakInterrupts`. Held over while the CPU will not take it.
     */
    protected takeGamePakInterrupt(): void;
    protected result(start: number, outcome: 'done' | 'stopped' | 'stalled'): VbRunResult;
    /**
     * Stop before the instruction now reported, from inside the core.
     *
     * Only written down here: the drain loop acts on it once the core has
     * returned, which is the only safe place to.
     */
    protected requestStop(reason: VbStopReason, refire: Refire, watch?: VbWatch, hit?: VbWatchHit): number;
    /**
     * Hold the core up for the watches in {@link pausing}, which act once it
     * has returned; it goes on from the same place, as from a stop.
     */
    protected requestPause(refire: Refire): number;
    /** Take a hit down, and keep it for its watch's `then`. */
    protected recordHit(watch: VbWatch, hit: VbWatchHit): void;
    /**
     * Watch memory or code. See {@link VbWatchSpec}; the watch collects its
     * hits as the machine runs, and stops it on one if told to.
     */
    watch(spec: VbWatchSpec): VbWatch;
    unwatch(watch: VbWatch): void;
    get watches(): readonly VbWatch[];
    /**
     * Where the machine is and how it got there, innermost first: the PC, then
     * the call sites above it, with mirrors folded.
     *
     * Followed rather than unwound — calls and returns are seen as they run —
     * so it knows only the calls made since something started following it:
     * a watch capturing `stack`, or {@link followCalls}.
     */
    callStack(): number[];
    /** Follow calls from now on, for {@link callStack}, with or without a watch asking for it. */
    followCalls(follow?: boolean): void;
    protected following: boolean;
    /** Whether anything wants the call stack followed. */
    protected wantsCalls(): boolean;
    /**
     * A watch target as a start and a length: a number is one byte, a name as
     * big as the build says, a pair a start and a length. A function's name is
     * its entry where code is watched — one hit per call — and all of it where
     * it says which code an access has to come from.
     */
    protected extentOf(target: VbWatchTarget, use: 'data' | 'entry' | 'whole'): [number, number];
    /**
     * An address with the mirrors folded out, so that a watch, a breakpoint or
     * a symbol matches however the program reached the memory: the CPU sees
     * only 27 address bits, WRAM repeats every 64 KiB — every 256 KiB once a
     * VB Color game has switched on `WRAMEXT` — and the cartridge repeats at
     * its own size, which is how a program running from the top of memory is
     * running the code the symbol table puts at 0x07000000.
     */
    canonical(address: number): number;
    /** How WRAM repeats now: `MEMCTRL` bit 0 (`WRAMEXT`) decodes 256 KiB of it, as the core's bus does. */
    protected wramMask(): number;
    /** A hit for a watch, with what it asked to take down. */
    protected hitFor(watch: VbWatch, kind: VbWatchHit['kind'], pc: number, address: number, size: number, value?: number, old?: number): VbWatchHit;
    /**
     * Offer an access to the watches of its kind, and say whether one of them
     * stops the machine on it.
     */
    protected offer(watches: VbWatch[], kind: 'write' | 'read', address: number, type: number, valuePointer: number): number;
    /**
     * Install exactly the callbacks something wants, and no others.
     *
     * Each costs a call out of the core per instruction or per access, so an
     * idle machine runs with none but the terminal's. The core keeps them in
     * the state struct, which is why a restore has to come back through here.
     */
    protected updateCallbacks(): void;
    protected wantsExecute(): boolean;
    protected wantsRead(): boolean;
    protected onExecute(pc: number, codePointer: number, length: number): number;
    /**
     * Keep the call stack in step with the instruction about to run.
     *
     * Reported before it runs, so a JAL here is a call about to be made from
     * this site and a `jmp [lp]` a return about to happen. Calls through a
     * register, tail calls and stack switches are not seen — what this follows
     * is the code's ordinary discipline, which is all a compiler emits.
     */
    protected followCall(pc: number, code: number): void;
    /** An exception being taken: an interrupt, a TRAP or a fault. */
    protected onException(causePointer: number): number;
    protected recordBranch(from: number, to: number): void;
    protected onWrite(address: number, type: number, valuePointer: number): number;
    protected onRead(address: number, type: number, valuePointer: number): number;
    /** Whether this report is the repeat of the one a stop was made at. */
    protected takeRefire(kind: Refire['kind'], address: number): boolean;
    /** Bytes as the CPU would read them, without the CPU reading them. */
    read(address: number | string, length: number): Uint8Array;
    read8(address: number | string): number;
    read16(address: number | string): number;
    read32(address: number | string): number;
    write(address: number | string, bytes: ArrayLike<number>): void;
    write8(address: number | string, value: number): void;
    write16(address: number | string, value: number): void;
    write32(address: number | string, value: number): void;
    /**
     * Write bytes where code runs: into the cartridge for a ROM address — which
     * nothing a program does can write — and through the bus anywhere else.
     * The CPU's instruction cache is cleared after, keeping whether it is on,
     * so that patched code is what runs next.
     *
     * A ROM patch belongs to this machine and stays through `restore` and
     * `loadState`, neither of which carries the cartridge.
     */
    patch(address: number | string, bytes: ArrayLike<number>): void;
    /** Game Pak RAM up to the highest byte the game has written, as the app saves it. */
    sram(): Uint8Array;
    get pc(): number;
    /** The registers, shaped as the app's Registers panel gets them. */
    registers(): Registers;
    /** One register by name: `pc`, `r10`, `sp`, `psw` and so on. */
    register(name: string): number;
    protected programRegisters(): Record<string, number>;
    /** Set `pc`, `r10`, `sp`, `psw` and so on. */
    setRegister(name: string, value: number): void;
    /**
     * An address from a number, `0x0701A2B0`, `1234`, or a symbol with an
     * optional offset — `main`, `Actor::update+0x10` — when there is an `.elf`.
     */
    resolve(spec: number | string): number;
    /** `0x0701A2B0`, with the build's name for it where there is one. */
    describe(address: number): string;
    snapshot(): VbSnapshot;
    restore(snapshot: VbSnapshot): void;
    /**
     * The moment as a VUEPort save state file, which the app loads like one of
     * its own — for this ROM, as one machine.
     */
    saveState(label?: string): Promise<Uint8Array>;
    /**
     * Load a VUEPort save state file of this ROM.
     *
     * The frame count carries on from where it was: a state says what the
     * machine was, not how long it had been running. The next frame starts
     * from the state's own clock.
     */
    loadState(file: Uint8Array, options?: {
        otherRom?: boolean;
    }): Promise<void>;
    /** Empty the CPU's instruction cache, keeping whether it is on, so that what runs next is read from memory. */
    clearInstructionCache(): void;
    /**
     * Put back a state struct as the core keeps it — what the app's worker
     * hands over from `Sim.saveState`, without a save state file around it.
     * A fork of a running game starts here, at the start of a frame.
     */
    loadStruct(state: Uint8Array): void;
    /** What a save state is bound to, worked out as the app works it out. */
    protected identity(): VesEmulatorSaveStateIdentity;
    /**
     * Put a state struct back, and repair what it brought with it.
     *
     * The struct holds absolute pointers to the cartridge, its RAM and the
     * sample buffer, the hardware model and the installed callbacks, all of
     * them whatever the machine that took it had. The worker's `restoreFrom`
     * repairs the same things for the same reasons.
     */
    protected restoreStruct(state: Uint8Array): void;
    /** What the VIP is showing now, as the core composites it. */
    frameBuffer(): VbFrame;
    picture(eye?: VbEye): VbPicture;
    /** A PNG of the screen. */
    screenshot(options?: {
        eye?: VbEye;
        scale?: number;
    }): Promise<Uint8Array>;
    /**
     * Which of the two frame buffers the display shows, 0 or 1; the drawing
     * processor draws into the other. See `vb-framebuffer.ts`.
     */
    displayedBuffer(): 0 | 1;
    /**
     * Keep what draws each pixel of the frame buffers from now on, for
     * {@link pixelOrigins}, or stop. Pixels drawn before are `unknown`, and so
     * is everything after a state is loaded or restored, which does not carry
     * them. It costs the drawing about as much again — a little of a frame's
     * time, most of which is the CPU's — and only the frame a buffer is drawn
     * in has to have it on: a survey can run without, and switch it on two
     * frames before the one it reads.
     */
    keepOrigins(keep?: boolean): void;
    get keepsOrigins(): boolean;
    /**
     * What drew each pixel of a frame buffer: two words a pixel, row by row —
     * see `vb-origin.ts` for what they say — of the whole screen, or of a
     * region of it, which is all a survey of a few pixels needs to copy. All
     * zero (`unknown`) for a buffer not drawn since {@link keepOrigins}.
     */
    pixelOrigins(eye: 'left' | 'right', buffer: 0 | 1, region?: {
        x: number;
        y: number;
        width: number;
        height: number;
    }): Uint32Array;
    /**
     * A character as it was when a frame buffer was drawn: its 16 bytes, as
     * character memory holds them (8 rows, 2 bits a pixel, the leftmost pixel
     * lowest). What the pixels {@link pixelOrigins} names were drawn from,
     * whatever the game has loaded into that character since. Undefined while
     * no origins are kept; zeros for a buffer not drawn since.
     */
    drawnCharacter(buffer: 0 | 1, index: number): Uint8Array | undefined;
    /**
     * The palettes as they were when a frame buffer was drawn: GPLT0-3 then
     * JPLT0-3, each the shade its pixel values 0-3 select.
     */
    drawnPalettes(buffer: 0 | 1): number[][] | undefined;
    protected originsPointer: number;
    protected keepingOrigins: boolean;
    /** Forget the origins kept: they were of pictures this machine no longer has. */
    protected clearOrigins(): void;
    /**
     * Instructions from an address, with the build's names where there are
     * any. `before` of the `count` lines are taken from ahead of the address.
     */
    disassemble(at: number | string, count: number, before?: number): VbInstruction[];
    /**
     * The VSU as it stands: each channel decoded, and the waveform and
     * modulation tables.
     *
     * Not read from the VSU's addresses, which are write-only on the real
     * thing: the core keeps its own decoded copy, and this composes the
     * registers back out of it the way the app's VSU panel does — see
     * `vb-vsu-layout.ts`.
     */
    vsu(): {
        channels: VsuChannel[];
        waveforms: number[][];
        modulation: number[];
    };
    protected vsuLayout?: VsuLayout;
    /** Everything written to the debug port since the start, or since {@link takeTerminal}. */
    get terminal(): string;
    takeTerminal(): string;
    /** The commands written to the ESSound port, for a machine made with `esSound`, and forgets them. */
    takeEsSound(): number[];
    protected copyIn(bytes: Uint8Array): number;
    /**
     * The core's memory as bytes, kept between calls: the execute callback
     * reads through it on every instruction, and a view made per call costs
     * more than the instruction. Made again only when the memory has grown,
     * which detaches the old one.
     */
    protected heap(): Uint8Array;
    protected heapView?: Uint8Array;
    protected u32(pointer: number, length?: number): Uint32Array;
}
/** Bytes an access of the core's data type covers. */
export declare function accessBytes(type: number): number;
export {};
//# sourceMappingURL=vb-machine.d.ts.map