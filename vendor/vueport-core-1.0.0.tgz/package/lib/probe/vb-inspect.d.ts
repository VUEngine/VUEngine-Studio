import { VesMemoryPool, VesMemoryPoolUsage } from '../browser/core/emulator-memory-pool';
import { VipWorld } from '../browser/panels/emulator-vip-memory';
import { VbMachine } from './vb-machine';
/**
 * The machine's hardware state as data: what the app's debug panels show,
 * decoded by the same code, for something that reads rather than looks.
 *
 * Read through the machine's debug bus, so nothing here disturbs it.
 */
export interface VbVipState {
    /** Every VIP register by its name in `vip.h`. */
    registers: Record<string, number>;
    /** The four brightness levels, 0-255, as the core lights them. */
    brightness: number[];
    /** GPLT0-3 and JPLT0-3, each as the shades its pixel values 0-3 select. */
    palettes: {
        bgmap: number[][];
        object: number[][];
    };
    /** Object groups as first and last index, or null for an empty one. */
    objectGroups: ({
        first: number;
        last: number;
    } | null)[];
    /** The worlds the VIP draws this frame, from 31 down. */
    worlds: VbWorld[];
    /** VB Color, while a game has switched it on. */
    vbc?: VbVbcState;
}
export interface VbWorld extends VipWorld {
    modeName: string;
    /** For an object world, which group it draws. */
    objectGroup?: number;
    /** VB Color: what the world adds to the palettes of what it draws, under WCEN. */
    paletteOffset?: number;
}
export interface VbObject {
    index: number;
    group?: number;
    x: number;
    y: number;
    parallax: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    left: boolean;
    right: boolean;
    /** VB Color: the CRAM palette it draws with, and the Pixel Color Slot if one applies. */
    color?: {
        palette: number;
        slot: boolean;
    };
}
export interface VbBgMapCell {
    x: number;
    y: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    color?: {
        palette: number;
        slot: boolean;
    };
}
export interface VbVbcState {
    chrext: boolean;
    colen: boolean;
    pcen: boolean;
    wcen: boolean;
    bkren: boolean;
    ccen: boolean;
    wramext: boolean;
    cbkpal: number;
    /** All 256 palettes, four `#rrggbb` colors each. */
    cram: string[][];
}
export interface VbPoolState {
    address: number;
    pools: (VesMemoryPool & VesMemoryPoolUsage)[];
}
export interface VbInstance {
    address: number;
    className: string;
    /** The class and its bases, nearest first. */
    ancestry: string[];
    blockSize: number;
    /** The engine's own name for it, where it has one. */
    name?: string;
    /** Every field, where the build describes the class. */
    fields?: {
        path: string;
        value: string;
    }[];
}
/** The VIP: registers, palettes, groups and the worlds it is drawing. */
export declare function readVip(vb: VbMachine): VbVipState;
/** All 32 world entries, by index. */
export declare function readWorlds(vb: VbMachine): VipWorld[];
/**
 * Objects in OAM: those shown to an eye by default, or all 1024 with `all`.
 *
 * Not filtered by group: the group a register says an object is in is the
 * group as the registers stand now, and plenty of games rewrite SPT0-3 while
 * the VIP draws — Wario Land does — so at the end of a frame the registers
 * describe nothing in particular. `group` is given where they say one.
 */
export declare function readObjects(vb: VbMachine, options?: {
    all?: boolean;
}): VbObject[];
/** One BGMap segment's cells, or a rectangle of them. */
export declare function readBgMap(vb: VbMachine, segment: number, rect?: {
    x: number;
    y: number;
    width: number;
    height: number;
}): VbBgMapCell[];
/** A character's 8x8 pixel values, 0-3, row by row. */
export declare function readCharacter(vb: VbMachine, index: number): number[][];
/**
 * The VB Color unit's switches and CRAM, while a game has unlocked it — the
 * same test the app's panels go by, see `readVbcState`.
 */
export declare function readVbcState(vb: VbMachine): VbVbcState | undefined;
/** How full each of the engine's memory pools is, for a VUEngine build with symbols. */
export declare function readPool(vb: VbMachine): VbPoolState | undefined;
/**
 * The objects living in the engine's memory pools, by class: every one, or
 * those of a class and its subclasses (`Actor`), with their fields where the
 * build describes them.
 */
export declare function readInstances(vb: VbMachine, options?: {
    className?: string;
    fields?: boolean;
}): VbInstance[];
//# sourceMappingURL=vb-inspect.d.ts.map