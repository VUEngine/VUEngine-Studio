import { VesMemoryPool, VesMemoryPoolUsage } from '../browser/core/emulator-memory-pool';
import { VipWorld } from '../browser/panels/emulator-vip-memory';
import { VbMachine } from './vb-machine';
export interface VbVipState {
    registers: Record<string, number>;
    brightness: number[];
    palettes: {
        bgmap: number[][];
        object: number[][];
    };
    objectGroups: ({
        first: number;
        last: number;
    } | null)[];
    worlds: VbWorld[];
    vbc?: VbVbcState;
}
export interface VbWorld extends VipWorld {
    modeName: string;
    objectGroup?: number;
    paletteOffset?: number;
}
export interface VbObject {
    index: number;
    group?: number;
    x: number;
    y: number;
    parallax: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    left: boolean;
    right: boolean;
    color?: {
        palette: number;
        slot: boolean;
    };
}
export interface VbBgMapCell {
    x: number;
    y: number;
    char: number;
    palette: number;
    hFlip: boolean;
    vFlip: boolean;
    color?: {
        palette: number;
        slot: boolean;
    };
}
export interface VbVbcState {
    chrext: boolean;
    colen: boolean;
    pcen: boolean;
    wcen: boolean;
    bkren: boolean;
    ccen: boolean;
    wramext: boolean;
    cbkpal: number;
    cram: string[][];
}
export interface VbPoolState {
    address: number;
    pools: (VesMemoryPool & VesMemoryPoolUsage)[];
}
export interface VbInstance {
    address: number;
    className: string;
    ancestry: string[];
    blockSize: number;
    name?: string;
    fields?: {
        path: string;
        value: string;
    }[];
}
export declare function readVip(vb: VbMachine): VbVipState;
export declare function readWorlds(vb: VbMachine): VipWorld[];
export declare function readObjects(vb: VbMachine, options?: {
    all?: boolean;
}): VbObject[];
export declare function readBgMap(vb: VbMachine, segment: number, rect?: {
    x: number;
    y: number;
    width: number;
    height: number;
}): VbBgMapCell[];
export declare function readCharacter(vb: VbMachine, index: number): number[][];
export declare function readVbcState(vb: VbMachine): VbVbcState | undefined;
export declare function readPool(vb: VbMachine): VbPoolState | undefined;
export declare function readInstances(vb: VbMachine, options?: {
    className?: string;
    fields?: boolean;
}): VbInstance[];
//# sourceMappingURL=vb-inspect.d.ts.map