import { VbMachine } from './vb-machine';
import { VbPicture } from './vb-picture';
/** What a screenshot can have drawn over it. */
export type VbAnnotation = 'worlds' | 'objects';
/**
 * A screenshot with the VIP's own layout drawn over it: a frame and a number
 * for every world drawn, or every object shown — the picture to hold beside a
 * `vip worlds` or `vip objects` listing to tell which is which.
 *
 * Enlarged, so that the numbers can be read; the picture is nearest-neighbour
 * and the drawing goes on at the enlarged size, one output pixel wide.
 */
export declare function annotatedPicture(vb: VbMachine, what: VbAnnotation, eye?: 'left' | 'right', scale?: number): VbPicture;
//# sourceMappingURL=vb-annotate.d.ts.map