import { VbMachine } from './vb-machine';
import { VbPicture } from './vb-picture';
export type VbAnnotation = 'worlds' | 'objects';
export declare function annotatedPicture(vb: VbMachine, what: VbAnnotation, eye?: 'left' | 'right', scale?: number): VbPicture;
//# sourceMappingURL=vb-annotate.d.ts.map