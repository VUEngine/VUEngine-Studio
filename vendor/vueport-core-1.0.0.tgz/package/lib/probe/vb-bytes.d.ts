/** Bytes as text and back, for the probe's JSON: base64 for files, hex for memory. */
export declare function toBase64(bytes: Uint8Array): string;
export declare function fromBase64(text: string): Uint8Array;
export declare function toHex(bytes: Uint8Array): string;
//# sourceMappingURL=vb-bytes.d.ts.map