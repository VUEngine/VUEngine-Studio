/**
 * A V810 assembler for patching a running machine and writing hooks. Reads `dis` output as it came out
 * (addresses and all) and the usual spellings:
 *
 *     loop:  movhi hi(counter), r0, r10
 *            movea lo(counter), r10, r10
 *            ld.w  0[r10], r11
 *            add   1, r11
 *            st.w  r11, [r10]
 *            br    loop
 *
 * Statements end at a newline or `;` (one-line patches on a command line), comments start with `#` or `//`,
 * labels end in `:`. Numbers are decimal or `0x` hex, except branch, `jr` and `jal` targets, where bare hex
 * digits are an address as the disassembler writes them. `hi(x)`/`lo(x)` split an address for a `movhi`/`movea`
 * pair with the sign-extension carry. Directives: `.org`, `.byte`, `.half`, `.word`, `.align`. Tested against the
 * core's disassembler and by running the output, see `tests/asm-probe.mjs`
 */
export interface VbAsmLine {
    address: number;
    bytes: number[];
    source: string;
}
export interface VbAsmResult {
    origin: number;
    bytes: Uint8Array;
    lines: VbAsmLine[];
    labels: Map<string, number>;
}
export interface VbAsmOptions {
    resolve?: (name: string) => number | undefined;
    romSize?: number;
}
export declare function assemble(source: string, origin: number, options?: VbAsmOptions): VbAsmResult;
//# sourceMappingURL=vb-asm.d.ts.map