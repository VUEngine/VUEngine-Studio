/**
 * A V810 assembler, for patching a running machine and for writing hooks.
 *
 * It reads what the disassembler writes — `dis` output, addresses and all,
 * goes back in as it came out — and the usual assembler spellings beside it:
 *
 *     loop:  movhi hi(counter), r0, r10
 *            movea lo(counter), r10, r10
 *            ld.w  0[r10], r11
 *            add   1, r11
 *            st.w  r11, [r10]
 *            br    loop
 *
 * Statements end at a newline or a `;`, so a one-line patch can be given on
 * a command line; comments start with `#` or `//`. Labels end in `:`.
 * Numbers are decimal or `0x` hex, except where an instruction takes an
 * address to go to — a branch, `jr`, `jal` — where a bare run of hex digits
 * is an address, because that is how the disassembler writes them.
 * `hi(x)` and `lo(x)` split an address for a `movhi`/`movea` pair, with the
 * carry `movea`'s sign extension needs; `.org`, `.byte`, `.half`, `.word` and
 * `.align` are the directives.
 *
 * Tested against the core's own disassembler instruction by instruction, and
 * by running what it assembles — see `tests/asm-probe.mjs`.
 */
export interface VbAsmLine {
    address: number;
    bytes: number[];
    source: string;
}
export interface VbAsmResult {
    /** Where the first byte goes. */
    origin: number;
    bytes: Uint8Array;
    lines: VbAsmLine[];
    labels: Map<string, number>;
}
export interface VbAsmOptions {
    /** Names from outside the source — a build's symbols. */
    resolve?: (name: string) => number | undefined;
    /**
     * The cartridge's size, so that a branch to an address in another mirror
     * of the ROM — `FFFC2326` from the disassembler, while assembling at
     * `0x070C0000` — goes to the same code through the mirror it starts in.
     */
    romSize?: number;
}
/** Assemble `source` to run at `origin`. Throws, naming the line, for anything it cannot. */
export declare function assemble(source: string, origin: number, options?: VbAsmOptions): VbAsmResult;
//# sourceMappingURL=vb-asm.d.ts.map