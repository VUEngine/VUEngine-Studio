import { VbKey } from '../common/vb-constants';
/** Nothing held, with the controller present. */
export declare const NO_KEYS = VbKey.SGN;
/**
 * A button mask from `A+RIGHT`, `a,lu`, `0x1004` or `-`.
 *
 * The controller's signature bit is always set: it is what tells a game a
 * controller is plugged in at all, and the app sets it on every mask too — a
 * movie played here and there has to mean the same thing.
 */
export declare function parseKeys(text: string): number;
/** A mask as `A+LR`, or `-` for nothing held. The signature bit is not a button. */
export declare function formatKeys(mask: number): string;
//# sourceMappingURL=vb-keys.d.ts.map