import { VbKey } from '../common/vb-constants';
export declare const NO_KEYS = VbKey.SGN;
export declare function parseKeys(text: string): number;
export declare function formatKeys(mask: number): string;
//# sourceMappingURL=vb-keys.d.ts.map