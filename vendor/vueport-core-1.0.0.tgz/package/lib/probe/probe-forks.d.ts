import { VbMachine } from './vb-machine';
import { VbSymbols } from './vb-symbols';
/**
 * Forks: copies of the game being played, where a tool can stop, step and watch a machine without the player
 * noticing. Each is a VbMachine running the same commands as vbprobe; the machine is a copy of a moment, and files
 * arrive with the request and leave with the answer. Kept apart from any worker: probe-fork-worker.ts is the one
 * VUEPort and VUEngine Studio bundle, probe-session.ts talks to it
 */
export interface ProbeMoment {
    state: ArrayBuffer;
    sram: ArrayBuffer;
    sramWindow: number;
}
export type ProbeForkRequest = {
    id: number;
    op: 'base';
    key: string;
    rom: ArrayBuffer;
    elf?: ArrayBuffer;
    vbc: boolean;
    esSound: boolean;
    wasmUrl: string;
} | {
    id: number;
    op: 'fork';
    name?: string;
    moment?: ProbeMoment;
    from?: string;
} | {
    id: number;
    op: 'cli';
    args: string[];
    inputs: Record<string, string>;
    moment?: ProbeMoment;
    help: string;
    app: string;
} | {
    id: number;
    op: 'drop';
    name: string;
} | {
    id: number;
    op: 'forks';
};
export interface ProbeCliAnswer {
    text: string;
    code: number;
    outputs: Record<string, string>;
}
export declare const FORK_HELP = "commands\n  run                       run, then report where the machine is\n  peek <addr[:len]>...      hex dump memory (len defaults to 64)\n  regs                      program and system registers\n  dis [addr] [count]        disassemble, from the PC by default (count 16);\n  dis <from>..<to>          or all of a range (from-to with plain numbers);\n                            --out <file> writes it instead of printing it\n  shot <file.png>           screenshot\n  fb [left|right] [shown|drawn|0|1] [x,y,w,h]\n                            a frame buffer as the VIP keeps it, not as shown:\n                            shades 0-3, or with --color the VB Color frame\n                            buffer's palette ids (the colour is CRAM[id*4 +\n                            shade]). Left and shown by default; a region\n                            prints its values, --out <file> writes all of\n                            them: .bin a byte a pixel row by row, .json, .png\n  origin [left|right] [shown|drawn|0|1] [x,y | x,y,w,h]\n                            what drew the pixels of a frame buffer: world, BG\n                            map cell or object, character and which of its\n                            pixels, palette \u2014 or the code that wrote them. A\n                            pixel in full, a region by what drew it, the\n                            screen by world; --out <file> writes every pixel\n                            (.json, or .bin: two 32-bit words a pixel, row by\n                            row, as packages/probe/PROBE.md says). Kept from\n                            the first time a machine is asked (or --origins),\n                            so without run options it runs on until that\n                            buffer is drawn\n  compare <ref.png> [x,y,w,h]\n                            the screen held against a picture kept from before\n                            (a shot, or any PNG of the same size \u2014 --scale is\n                            worked out from it): how many pixels differ, where,\n                            by how much; --tolerance <n> lets each channel be n\n                            off, --out <diff.png> marks them. Exits 1 when\n                            pixels differ\n  watch                     run with the watches below and report what they saw\n\n  vip [what]                the VIP: overview (default), registers, worlds,\n                            objects (--all for every one), bgmap <segment>\n                            [x,y,w,h], char <index>\n  vsu                       the sound unit's six channels\n  vbc                       VB Color switches and CRAM (--cram for all of it)\n  pool                      VUEngine's memory pools, by class (needs --elf)\n  actors [class]            VUEngine objects of a class, Actor by default,\n                            with --fields for every field (needs --elf)\n\n  profile                   where the run's time went, frame by frame, as the\n                            app's CPU Profiler measures it: busy, waiting (a\n                            loop going round until an interrupt) and halted\n                            clocks against the frame's budget, the busiest\n                            frames, and functions by their own time; --list\n                            for every frame\n  coverage                  which code ran, by function or by address range;\n                            --coverage-out <file> keeps it, --against <file>\n                            shows what ran now and not then, and the other way\n  search [region]           where a value is kept: wram (default), sram or\n                            start:length. --candidates <file> carries a search\n                            from one call to the next; each call snapshots,\n                            runs, and with --op keeps the addresses whose value\n                            did that: eq ne gt lt (with --value), changed,\n                            unchanged, increased, decreased. --type u8 (default)\n                            s8 u16 s16 u32 s32\n  asm <addr> [source]       assemble into the machine at addr before it runs\n                            (ROM included); statements split by ; or from\n                            --asm-file <file>. --out <file> keeps the bytes,\n                            --dry only lists them. dis output reads back in\n\n  Every command takes its machine, applies --state-in, runs as the run\n  options say, then does its job. Addresses are numbers (0x05000000) or, with\n  the build's .elf, symbols with an optional offset (main, Actor::update+0x10).\n\nstate\n  --state-in <file>         load a VUEPort save state (.vess) first\n  --state-out <file>        save one at the end, loadable in the app\n  --other-rom               take a state made with another ROM too \u2014 another\n                            build of the game, say \u2014 emptying the CPU's\n                            instruction cache after; fine as long as the build\n                            did not move code or memory around\n\nrunning\n  --frames <n>              run n frames (50 per second)\n  --until <addr>            run until the PC reaches addr (gives up after\n                            --frames, default 3000)\n  --keys <from-to:keys>     hold buttons over frames, e.g. 120-180:A+RIGHT,\n                            120:STA, 120+30:B (repeatable)\n  --hold <keys>             hold buttons on every other frame\n  --movie <file>            play a VUEPort/VBjin movie (.mc2) from frame 0\n  --shot <frame:file.png>   screenshot at a frame on the way (repeatable)\n  --until-vip <event>       run until the VIP gets there: frame (a frame shown),\n                            drawing, drawn (the drawing processor starting and\n                            finishing a framebuffer), or an interrupt request:\n                            framestart gamestart xpend sbhit lfbend rfbend\n                            timeerr scanerr (seen as its INTPND bit coming on)\n  --stop-on-fault           stop before the CPU takes a fault: zero division,\n                            invalid opcode, an FPU fault, an address trap\n  --origins                 keep what draws each pixel from now on, for origin\n  --branches <n>            keep the last n branches and print them: how the\n                            program got where it is (or where it fell over)\n  --until-read <addr:len>   run until every byte of a range has been read, as\n                            a block of characters copied out of the ROM is\n                            (by the CPU; the VB Color DMA is not seen)\n  --until-written <addr:len>\n                            run until every byte of a range has been written;\n                            either one stops with that access done\n  --set <what=value>        a register (r6=0x1234, sp=\u2026) or memory (0x05000010=7,\n                            0x05000010:4=\u2026, g_stats.lives=3) set to a value:\n                            at every hit of the watches, before a stop, or\n                            before the run without any (repeatable)\n\nwatches (with any command; several of each are fine)\n  --write <addr[:len]>      who writes here; a name is as big as the build says\n                            (g_stats, g_stats.lives, actors[3]), a number one byte\n  --read <addr[:len]>       who reads here\n  --access <addr[:len]>     either\n  --exec <addr[:len]>       when this code runs; a function's name is its\n                            entry, so each hit is a call\n  --when-value <v|min-max>  only hits writing or reading these values\n  --when-changed            only writes that change the value\n  --when-pc <addr[:len]>    only hits from this code (a function's name works)\n  --when-frames <from-to>   only hits in these frames\n  --capture <what,...>      take down regs, stack, or registers by name (r6,lp)\n  --stop                    stop the machine at the first hit\n  --limit <n>               hits to keep per watch (default 1000)\n  --list | --group          hits one by one, or folded by instruction (the\n                            default when there are more than 20)\n  --fold <how>              hits folded by place as well: column (of a frame\n                            buffer), fb (which frame buffer), or <n> (blocks\n                            of n bytes)\n\noutput\n  --eye <left|right|both>   which eye screenshots show (default left)\n  --scale <n>               enlarge screenshots\n  --annotate <what>         draw worlds or objects, with their numbers, over\n                            screenshots\n  --count <n>               lines for dis\n  --json                    machine-readable output\n  --terminal                print what the game wrote to the debug port\n  --essound                 print the ESSound commands the game sent\n\nbuttons: A B L R STA SEL LU LD LL LR RU RD RL RR, and UP DOWN LEFT RIGHT for\nthe left pad; join with +.\n\nforks\n  --fork <name>             work on a fork that stays, so the next command\n                            carries on where this one left off\n";
interface Base {
    key: string;
    rom: Uint8Array;
    symbols?: VbSymbols;
    vbc: boolean;
    esSound: boolean;
}
export declare class ProbeForks {
    protected core?: Uint8Array;
    protected base?: Base;
    protected readonly forks: Map<string, VbMachine>;
    handle(request: ProbeForkRequest): Promise<unknown>;
    protected commandLine(request: Extract<ProbeForkRequest, {
        op: 'cli';
    }>): Promise<ProbeCliAnswer>;
    protected machineOf(moment: ProbeMoment): Promise<VbMachine>;
    protected nextName(): string;
}
export {};
//# sourceMappingURL=probe-forks.d.ts.map