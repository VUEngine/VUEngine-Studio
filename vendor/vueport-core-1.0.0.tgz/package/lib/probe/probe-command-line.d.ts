/**
 * The end of a command line a host has to work out itself: the line split
 * into arguments, and which arguments name files.
 *
 * `ProbeSession` takes arguments and file contents and gives back text and
 * file contents; where the files are is the host's business. The desktop's
 * client (`probe.rs`) and VUEngine Studio's `emulator` tool follow the same
 * rules, these, so that a command line means the same in both.
 */
/** The largest file a command line sends along. */
export declare const MAX_PROBE_INPUT: number;
/**
 * A command line as a shell splits it, for a tool that gives one string:
 * spaces separate, quotes keep together, and a backslash takes the next
 * character as it is (outside single quotes).
 */
export declare function splitCommandLine(line: string): string[];
/**
 * The path an argument may name: the value of `--option=path`, the file of a
 * frame's `300:shot.png`, or the argument itself. A host sends the file along
 * if there is one, and accepts files back only under the paths a command line
 * named.
 */
export declare function namedPath(arg: string): string;
//# sourceMappingURL=probe-command-line.d.ts.map