export declare const MAX_PROBE_INPUT: number;
export declare function splitCommandLine(line: string): string[];
export declare function namedPath(arg: string): string;
//# sourceMappingURL=probe-command-line.d.ts.map