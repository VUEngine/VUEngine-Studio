import { VesType } from '../browser/core/emulator-dwarf';
import { ElfSymbol } from '../browser/core/emulator-elf';
import { VesLineTable } from '../browser/core/emulator-line-table';
import { SymbolIndex } from '../browser/core/emulator-symbols';
/** A named run of memory: a symbol, or a field or element of one. */
export interface VbExtent {
    address: number;
    /** At least one byte, even for a symbol the linker gave no size. */
    size: number;
    /** What is there, where the build says. */
    type?: VesType;
}
/**
 * A build's names for its addresses, both ways round.
 *
 * Built on the same index the app's debug panels use, so a name here is the
 * name the Disassembly and Profiler panels show — `Actor::update` for a
 * VUEngine method, the bare C name for anything else. With DWARF in the build,
 * a global's fields have names too: `g_stats.lives`, `actors[3].position.x`.
 */
export declare class VbSymbols {
    readonly index: SymbolIndex;
    readonly lines: VesLineTable;
    /** Global variables' types, by their names in C. */
    readonly variables: Map<string, VesType>;
    protected readonly romSize: number;
    /** Every name a symbol answers to, each to the symbol. */
    protected readonly byName: Map<string, ElfSymbol>;
    protected constructor(index: SymbolIndex, lines: VesLineTable, 
    /** Global variables' types, by their names in C. */
    variables: Map<string, VesType>, romSize: number, symbols: ElfSymbol[]);
    /** Read an `.elf`, or undefined for bytes that are not one. */
    static fromElf(bytes: Uint8Array, romSize: number): VbSymbols | undefined;
    /** A symbol by any of its names: `_main`, `main`, `Actor_update` or `Actor::update`. */
    lookup(name: string): ElfSymbol | undefined;
    /**
     * Where a name is and how big: a symbol, or a path into one —
     * `g_stats.lives`, `actors[3]`, `actors[3].position.x`.
     */
    locate(path: string): VbExtent | undefined;
    /**
     * What an address is, as `function+0x1c` for code, `g_stats.lives` or
     * `table[3]+0x2` for data, or undefined where the build names nothing.
     */
    describe(address: number): string | undefined;
    /** The function an address is in, for grouping by routine. */
    functionAt(address: number): ElfSymbol | undefined;
    /** The source line code at an address was compiled from. */
    sourceAt(address: number): {
        file: string;
        line: number;
    } | undefined;
    /** A data symbol's type, where the build describes it. */
    protected typeOf(symbol: ElfSymbol): VesType | undefined;
}
//# sourceMappingURL=vb-symbols.d.ts.map