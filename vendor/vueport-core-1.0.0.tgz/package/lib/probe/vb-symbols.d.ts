import { VesType } from '../browser/core/emulator-dwarf';
import { ElfSymbol } from '../browser/core/emulator-elf';
import { VesLineTable } from '../browser/core/emulator-line-table';
import { SymbolIndex } from '../browser/core/emulator-symbols';
export interface VbExtent {
    address: number;
    size: number;
    type?: VesType;
}
export declare class VbSymbols {
    readonly index: SymbolIndex;
    readonly lines: VesLineTable;
    readonly variables: Map<string, VesType>;
    protected readonly romSize: number;
    protected readonly byName: Map<string, ElfSymbol>;
    protected constructor(index: SymbolIndex, lines: VesLineTable, variables: Map<string, VesType>, romSize: number, symbols: ElfSymbol[]);
    static fromElf(bytes: Uint8Array, romSize: number): VbSymbols | undefined;
    lookup(name: string): ElfSymbol | undefined;
    locate(path: string): VbExtent | undefined;
    describe(address: number): string | undefined;
    functionAt(address: number): ElfSymbol | undefined;
    sourceAt(address: number): {
        file: string;
        line: number;
    } | undefined;
    protected typeOf(symbol: ElfSymbol): VesType | undefined;
}
//# sourceMappingURL=vb-symbols.d.ts.map