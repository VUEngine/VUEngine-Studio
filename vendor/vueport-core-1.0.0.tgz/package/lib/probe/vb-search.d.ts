import { ScanDataType, ScanOperator } from '../common/emulator-cheat-scan';
import { VbMachine } from './vb-machine';
export interface VbSearchState {
    version: 1;
    address: number;
    type: ScanDataType;
    /** The region as it was at the last step, base64. */
    previous: string;
    /** The offsets still in the running, little-endian 32-bit, base64. */
    candidates: string;
    steps: number;
}
export interface VbSearchCandidate {
    address: number;
    value: number;
    previous: number;
}
export declare class VbSearch {
    readonly address: number;
    readonly type: ScanDataType;
    protected previous: Uint8Array;
    protected offsets: Uint32Array;
    steps: number;
    protected constructor(address: number, type: ScanDataType, previous: Uint8Array, offsets: Uint32Array, steps: number);
    /**
     * Start a search over `region` — `wram`, `sram`, or `0x05000000:0x1000` —
     * keeping every address, or only those whose value already answers `op`.
     */
    static start(vb: VbMachine, region: string, type?: ScanDataType, op?: ScanOperator, value?: number): VbSearch;
    static fromState(state: VbSearchState): VbSearch;
    /** Keep the addresses whose value, since the last step, answers `op`. */
    next(vb: VbMachine, op: ScanOperator, value?: number): void;
    get count(): number;
    /** The first `limit` addresses still in the running, with their values now and at the last step. */
    candidates(vb: VbMachine, limit?: number): VbSearchCandidate[];
    toState(): VbSearchState;
}
//# sourceMappingURL=vb-search.d.ts.map