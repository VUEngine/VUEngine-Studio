import { ScanDataType, ScanOperator } from '../common/emulator-cheat-scan';
import { VbMachine } from './vb-machine';
export interface VbSearchState {
    version: 1;
    address: number;
    type: ScanDataType;
    previous: string;
    candidates: string;
    steps: number;
}
export interface VbSearchCandidate {
    address: number;
    value: number;
    previous: number;
}
export declare class VbSearch {
    readonly address: number;
    readonly type: ScanDataType;
    protected previous: Uint8Array;
    protected offsets: Uint32Array;
    steps: number;
    protected constructor(address: number, type: ScanDataType, previous: Uint8Array, offsets: Uint32Array, steps: number);
    static start(vb: VbMachine, region: string, type?: ScanDataType, op?: ScanOperator, value?: number): VbSearch;
    static fromState(state: VbSearchState): VbSearch;
    next(vb: VbMachine, op: ScanOperator, value?: number): void;
    get count(): number;
    candidates(vb: VbMachine, limit?: number): VbSearchCandidate[];
    toState(): VbSearchState;
}
//# sourceMappingURL=vb-search.d.ts.map