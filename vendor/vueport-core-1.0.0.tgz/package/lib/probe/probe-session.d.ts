import type { Sim } from '../browser/core/vb-core';
import { ProbeCliAnswer, ProbeForkRequest } from './probe-forks';
/**
 * A tool's way into a running emulator. The live game can only be looked at, paused, saved or loaded, so the
 * player does not feel a tool at work; stopping, stepping and watching happen on forks, copies driven by the
 * same commands as `vbprobe` in their own worker (`probe-forks.ts`). Host-agnostic: VUEPort desktop serves it on
 * a local socket (`desktop-probe.ts`), VUEngine Studio as an AI agent tool. Disabled in hardcore mode, like the
 * debugger, and while two players are linked
 */
export interface ProbeTarget {
    name: string;
    sim: Sim;
    romAsRun(): Uint8Array;
    elf(): Promise<Uint8Array | undefined>;
    esSoundSnapshot(): unknown;
    esSound: boolean;
    hardcore: boolean;
    linked: boolean;
    paused: boolean;
    setPaused(paused: boolean): Promise<void>;
}
export interface ProbeForkChannel {
    request<T>(request: DistributiveOmit<ProbeForkRequest, 'id'>): Promise<T>;
}
type DistributiveOmit<T, K extends keyof any> = T extends unknown ? Omit<T, K> : never;
export interface ProbeHostCommand {
    usage: string;
    summary: string;
    run(args: string[]): Promise<string>;
}
export interface ProbeSessionOptions {
    app: string;
    version: string;
    usage: string;
    wasmUrl(): string;
    forks(): ProbeForkChannel;
    quit?(): void;
    commands?: ProbeHostCommand[];
}
export declare const PROBE_PROTOCOL = 1;
export declare class ProbeSession {
    protected readonly target: () => ProbeTarget | undefined;
    protected readonly options: ProbeSessionOptions;
    protected handed?: string;
    constructor(target: () => ProbeTarget | undefined, options: ProbeSessionOptions);
    handle(method: string, params?: Record<string, unknown>): Promise<unknown>;
    commandLine(args: string[], inputs?: Record<string, string>): Promise<ProbeCliAnswer>;
    protected liveHelp(): string;
    protected admitted(target: ProbeTarget | undefined): ProbeTarget;
    protected handBase(game: ProbeTarget): Promise<void>;
}
export declare class ProbeForkWorker implements ProbeForkChannel {
    protected readonly worker: Worker;
    protected next: number;
    protected readonly waiting: Map<number, {
        resolve: (value: unknown) => void;
        reject: (error: Error) => void;
    }>;
    constructor(worker: Worker);
    request<T>(request: DistributiveOmit<ProbeForkRequest, 'id'>): Promise<T>;
    dispose(): void;
}
export {};
//# sourceMappingURL=probe-session.d.ts.map