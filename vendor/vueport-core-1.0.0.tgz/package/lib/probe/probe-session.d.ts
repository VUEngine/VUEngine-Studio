import type { Sim } from '../browser/core/vb-core';
import { ProbeCliAnswer, ProbeForkRequest } from './probe-forks';
/**
 * A tool's way into a running emulator: answering what it asks, on the game
 * being played or on forks of it.
 *
 * Two kinds of thing. The game itself can only be looked at, paused, and have
 * a moment taken away or put back: the person playing must not feel a tool at
 * work. Everything that stops, steps or watches a machine instruction by
 * instruction happens on a fork instead — a copy of the moment, driven by the
 * same commands as `vbprobe`, in a worker of its own (`probe-forks.ts`).
 *
 * Host-agnostic: the VUEPort desktop app puts it behind a local socket
 * (`desktop-probe.ts`), and VUEngine Studio behind a tool its AI agents call.
 * A host says what it is called, where the core is, how to reach the fork
 * worker and whether it can be quit, and hands over the game as a
 * `ProbeTarget`.
 *
 * Nothing at all while a game is in hardcore mode, the same as the debugger,
 * and nothing while two players are linked, whose machines have to stay in
 * step with each other.
 */
/** What a running emulator lends a probe session. */
export interface ProbeTarget {
    name: string;
    sim: Sim;
    /** The cartridge as the machine runs it: patches and colorizations applied. */
    romAsRun(): Uint8Array;
    elf(): Promise<Uint8Array | undefined>;
    esSoundSnapshot(): unknown;
    /** Whether the game has ESSound tracks, which is when the emulator answers its init. */
    esSound: boolean;
    hardcore: boolean;
    linked: boolean;
    paused: boolean;
    setPaused(paused: boolean): Promise<void>;
}
/** How a session reaches its forks: `ProbeForkWorker` for one in a worker. */
export interface ProbeForkChannel {
    request<T>(request: DistributiveOmit<ProbeForkRequest, 'id'>): Promise<T>;
}
type DistributiveOmit<T, K extends keyof any> = T extends unknown ? Omit<T, K> : never;
/**
 * A command a host answers itself, beside the game's own: VUEngine Studio's
 * `restart`, say. Answered before the session asks whether a game is
 * running, so it can start one.
 */
export interface ProbeHostCommand {
    /** As the help shows it, name first: `restart`. */
    usage: string;
    summary: string;
    run(args: string[]): Promise<string>;
}
export interface ProbeSessionOptions {
    /** What the host is called, in answers and errors: `VUEPort`, `VUEngine Studio`. */
    app: string;
    version: string;
    /** How a command line is given, for the help: `VUEPort --probe-cli`. */
    usage: string;
    /** Where the fork worker fetches the core from, as an absolute URL. */
    wasmUrl(): string;
    forks(): ProbeForkChannel;
    /** The host's own way out, if a tool may take it. */
    quit?(): void;
    commands?: ProbeHostCommand[];
}
/** The protocol's version, for a tool to check before it relies on a method. */
export declare const PROBE_PROTOCOL = 1;
export declare class ProbeSession {
    protected readonly target: () => ProbeTarget | undefined;
    protected readonly options: ProbeSessionOptions;
    /** Which cartridge the fork worker was last given, so that it is handed over once per game. */
    protected handed?: string;
    constructor(target: () => ProbeTarget | undefined, options: ProbeSessionOptions);
    /**
     * One request of the protocol: `cli` with a whole command line, or one of
     * the methods underneath it — `hello`, `status`, `read`, `registers`,
     * `screenshot`, `pause`, `resume`, `rom`, `elf`, `saveState`,
     * `loadState`, `quit`.
     */
    handle(method: string, params?: Record<string, unknown>): Promise<unknown>;
    /**
     * One command line. The commands about the game itself are answered
     * here; every other one goes to the forks, with a copy of this moment
     * unless `--fork` names a fork that is kept. Files arrive with the line
     * (`inputs`, by the path they were named as) and leave with the answer
     * (`outputs`): the host decides where they are read and written, not the
     * session.
     */
    commandLine(args: string[], inputs?: Record<string, string>): Promise<ProbeCliAnswer>;
    /** The commands about the game itself, which come first in the help. */
    protected liveHelp(): string;
    /** The game, if a tool may touch it now; the reason why not otherwise. */
    protected admitted(target: ProbeTarget | undefined): ProbeTarget;
    /**
     * Give the forks the cartridge as the game runs it, and the build's
     * names, when they are not the ones they have.
     *
     * Keyed by the bytes rather than the name: switching a patch on changes
     * the cartridge a fork has to run without changing what it is called.
     */
    protected handBase(game: ProbeTarget): Promise<void>;
}
/** The forks behind a worker running `probe-fork-worker.ts`. */
export declare class ProbeForkWorker implements ProbeForkChannel {
    protected readonly worker: Worker;
    protected next: number;
    protected readonly waiting: Map<number, {
        resolve: (value: unknown) => void;
        reject: (error: Error) => void;
    }>;
    constructor(worker: Worker);
    request<T>(request: DistributiveOmit<ProbeForkRequest, 'id'>): Promise<T>;
    dispose(): void;
}
export {};
//# sourceMappingURL=probe-session.d.ts.map