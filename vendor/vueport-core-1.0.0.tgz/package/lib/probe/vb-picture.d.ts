/** Which eye a picture shows, or both side by side. */
export type VbEye = 'left' | 'right' | 'both';
/**
 * What the core composited for the current frame.
 *
 * Two formats, as in the app: a plain Virtual Boy's frame is eye-packed —
 * the left eye's brightness in red, the right's in green, both 384 pixels wide
 * — and a VB Color frame is RGB, 768 pixels wide, the left eye in the left
 * half. See `VB_EYE_PACKED_LEFT` and `GetExtColorPixels`.
 */
export interface VbFrame {
    pixels: Uint8Array;
    colorMode: boolean;
}
export interface VbPicture {
    rgba: Uint8ClampedArray;
    width: number;
    height: number;
}
/**
 * A frame as RGBA, one eye or both side by side.
 *
 * A plain Virtual Boy frame comes out in the console's red: the brightness the
 * core computed, in the red channel, which is what the LED would show and what
 * anyone comparing it with a photo of the screen expects. Palettes and display
 * modes are the app's business and not this one's.
 */
export declare function framePicture(frame: VbFrame, eye?: VbEye): VbPicture;
/**
 * A picture as a PNG file.
 *
 * Indexed where it can be, which is nearly always for a Virtual Boy frame, and
 * truecolour for a VB Color frame with more than 256 colours in it.
 */
export declare function encodePng(picture: VbPicture, scale?: number): Promise<Uint8Array>;
//# sourceMappingURL=vb-picture.d.ts.map