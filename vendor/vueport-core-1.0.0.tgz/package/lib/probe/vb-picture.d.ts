export type VbEye = 'left' | 'right' | 'both';
export interface VbFrame {
    pixels: Uint8Array;
    colorMode: boolean;
}
export interface VbPicture {
    rgba: Uint8ClampedArray;
    width: number;
    height: number;
}
export declare function framePicture(frame: VbFrame, eye?: VbEye): VbPicture;
export declare function encodePng(picture: VbPicture, scale?: number): Promise<Uint8Array>;
//# sourceMappingURL=vb-picture.d.ts.map