import { VbPicture } from './vb-picture';
export declare function decodePng(file: Uint8Array): Promise<VbPicture>;
export interface VbPictureDifference {
    pixels: number;
    differing: number;
    box?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    largest: number;
    picture: VbPicture;
}
export declare function comparePictures(actual: VbPicture, expected: VbPicture, options?: {
    tolerance?: number;
    region?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}): VbPictureDifference;
//# sourceMappingURL=vb-compare.d.ts.map