import { VbPicture } from './vb-picture';
/**
 * Pictures read back in and held against each other: a reference image a
 * test or a survey keeps, and the screen as it is now.
 *
 * The decoder takes what tools write — VUEPort's own shots, Pillow's,
 * a paint program's: greyscale, RGB, palette and their alpha forms, at 1 to
 * 8 bits a channel (16 is read by its high byte). Interlaced files are not,
 * which nothing writing a screenshot makes.
 */
/** A PNG file as RGBA, four bytes a pixel. */
export declare function decodePng(file: Uint8Array): Promise<VbPicture>;
/** How two pictures differ, as `comparePictures` sees it. */
export interface VbPictureDifference {
    /** Pixels compared: the region's, or the whole picture's. */
    pixels: number;
    /** Of those, pixels further apart than the tolerance in some channel. */
    differing: number;
    /** The smallest box around them, if there are any. */
    box?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    /** The largest difference of any channel of any pixel. */
    largest: number;
    /** The picture, greyed, with the differing pixels in magenta — for looking at. */
    picture: VbPicture;
}
/**
 * Hold a picture against a reference of the same size, channel by channel;
 * `tolerance` is how far a channel may be off and still count as the same,
 * which a reference that went through a lossy step or a blend wants.
 */
export declare function comparePictures(actual: VbPicture, expected: VbPicture, options?: {
    tolerance?: number;
    region?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
}): VbPictureDifference;
//# sourceMappingURL=vb-compare.d.ts.map