import { VbMachine } from '../vb-machine';
export declare function vipCommand(vb: VbMachine, args: string[], all: boolean, lines: string[]): unknown;
export declare function vsuCommand(vb: VbMachine, lines: string[]): unknown;
export declare function vbcCommand(vb: VbMachine, cram: boolean, lines: string[]): unknown;
export declare function poolCommand(vb: VbMachine, lines: string[]): unknown;
export declare function actorsCommand(vb: VbMachine, args: string[], fields: boolean, lines: string[]): unknown;
//# sourceMappingURL=inspect-commands.d.ts.map