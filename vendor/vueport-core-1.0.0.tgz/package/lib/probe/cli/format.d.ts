/** One line per 16 bytes: the address, the bytes, and the printable ones as text. */
export declare function hexDump(address: number, bytes: Uint8Array): string[];
export declare function hex32(value: number): string;
//# sourceMappingURL=format.d.ts.map