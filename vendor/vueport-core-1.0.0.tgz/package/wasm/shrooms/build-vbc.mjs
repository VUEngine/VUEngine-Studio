#!/usr/bin/env node
import { copyFile, readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const here = dirname(fileURLToPath(import.meta.url));
const source = process.argv[2] ? resolve(process.argv[2]) : undefined;
if (!source) {
    console.error('usage: node packages/core/wasm/shrooms/build-vbc.mjs /path/to/patched/shrooms-vb-core');
    process.exit(2);
}

const test = spawnSync('make', ['vbc-test'], { cwd: source, stdio: 'inherit' });
if (test.status !== 0) {
    process.exit(test.status ?? 1);
}

const build = spawnSync('make', ['wasm'], { cwd: source, stdio: 'inherit' });
if (build.status !== 0) {
    process.exit(build.status ?? 1);
}

const built = resolve(source, 'web/core.wasm');
const bytes = await readFile(built);
const module = await WebAssembly.compile(bytes);
const exports = new Set(WebAssembly.Module.exports(module).map(entry => entry.name));
const required = [
    'GetColorPixels',
    'GetExtColorPixels',
    'GetVideoFormat',
    'SetHardwareMode',
    'GetHardwareMode',
    'vbGetColorEnabled',
    'vbGetColorPixels',
    'CreateSim',
    'vbRead',
];
const missing = required.filter(name => !exports.has(name));
if (missing.length) {
    console.error(`built core is missing VBC exports: ${missing.join(', ')}`);
    process.exit(1);
}

// Reject a VBC 1.0 binary even if it exposes the same transport helpers.
// VB_U16 is data type 3 in the public Shrooms API.
const instance = await WebAssembly.instantiate(module, {
    env: { emscripten_notify_memory_growth() {} },
});
const runtime = instance.exports;
const sim = runtime.CreateSim();
const id0 = runtime.vbRead(sim, 0x0307F800, 3) & 0xffff;
const id1 = runtime.vbRead(sim, 0x0307F802, 3) & 0xffff;
const version = runtime.vbRead(sim, 0x0307F804, 3) & 0xffff;
if (id0 !== 0x4256 || id1 !== 0x2143 || version !== 0x0101) {
    console.error(
        `built core is not VBC 1.1 (ID=${id0.toString(16)}/${id1.toString(16)}, `
        + `VBCVER=${version.toString(16)})`
    );
    process.exit(1);
}

const destination = resolve(here, 'core.wasm');
await copyFile(built, destination);
console.log(`installed VBC Shrooms core: ${destination}`);
