# `wasm/`

Two WebAssembly modules, each in its own directory, both committed as vendored
build output rather than built from source by `yarn build` — the same
arrangement, for the same reason: neither this package nor CI carries the
toolchain either needs.

```
wasm/
  shrooms/
    core.wasm                 the Virtual Boy / VBC core
    build-vbc.mjs             rebuild/install a VBC-capable Shrooms core
  rcheevos/
    rcheevos.js               the RetroAchievements engine  (built; may be absent)
    rcheevos.wasm             "
    build.mjs                 how to (re)build the two above
    smoke.mjs                 exercises the built engine under Node
    shim/                     the C between rc_client and vb-rcheevos.ts
    upstream/                 rcheevos source, fetched by build.mjs (.gitignore'd)
```

## `shrooms/core.wasm`

The Virtual Boy core (Shrooms-VB). No sources in this repository. VUEPort's
worker is backwards-compatible with the legacy vendored binary, but if the
core exposes the VBC video helpers (`GetVideoFormat`, `GetColorPixels` and
`GetExtColorPixels`) it automatically switches the renderer to RGB555 output.

VBC 1.1 requires a Shrooms core built against the 1.1 VCU memory map and 8-bpp Color Framebuffer format. To install the patched VBC 1.1 Shrooms checkout, put Emscripten on `PATH` and run
from the VUEPort repository root:

```sh
node packages/core/wasm/shrooms/build-vbc.mjs /path/to/shrooms-vb-core
```

The script first runs Shrooms' `make vbc-test`, then `make wasm`, verifies the
required VBC exports, and only then replaces the vendored `core.wasm`. Rebuilding is mandatory when moving from VBC 1.0 to 1.1 because the VCU register/CRAM addresses and Color Framebuffer representation changed. The public `.vb` format remains
canonical; the web frontend also accepts `.vbc` as the optional VBC filename
convention.

## `rcheevos/rcheevos.js` + `rcheevos/rcheevos.wasm`

The RetroAchievements engine (`rc_client`, from upstream
[rcheevos](https://github.com/RetroAchievements/rcheevos)), compiled with
Emscripten together with the shim in `rcheevos/shim/vueport-rc.c` — see that
file's own comment for what the shim is and why it exists, and
`packages/core/src/worker/vb-rcheevos.ts` for how the worker loads and drives
it (`importScripts`, then the `createVueportRc` factory).

`rcheevos.js` is a MODULARIZE-but-not-ES6 build on purpose: the emulator worker
is a classic worker, and an ES module would force `import()`, which `tsc`'s
CommonJS output rewrites into a `require()` that throws in a browser.

**Neither file is required for VUEPort to build or run.** Their absence is a
normal, handled state: `vb-rcheevos.ts` reports RetroAchievements
`engineUnavailable` at runtime and the Achievements panel says so, the same
way it says so when the desktop shell cannot reach the server at all. A
checkout with no `rcheevos.wasm` — which is every checkout until someone runs
the build below and commits the result — plays exactly as it did before this
integration existed.

### Building it

Needs the [Emscripten SDK](https://emscripten.org/docs/getting_started/downloads.html)
on `PATH` (`source ./emsdk_env.sh` after installing it) and network access to
fetch rcheevos itself. Then, from the repository root:

```sh
node packages/core/wasm/rcheevos/build.mjs
```

This clones rcheevos at the tag pinned in that script's `RCHEEVOS_TAG` into
`rcheevos/upstream/` (a plain shallow clone — not a submodule; that directory
is `.gitignore`d) if it is not already there, compiles it with the shim, and
writes `rcheevos.js` and `rcheevos.wasm` into `rcheevos/`. Commit both.

Re-run after bumping `RCHEEVOS_TAG`, having first deleted `rcheevos/upstream/`
so the clone picks up the new tag.

### Checking it

Two probes exercise the built engine without a RetroAchievements account:

```sh
node packages/core/wasm/rcheevos/smoke.mjs           # under Node
yarn --cwd packages/web build                        # then, in a real worker:
node packages/web/tests/retroachievements-probe.mjs
```

Both drive a login and a game-load through canned server responses and check
the JSON the shim emits is the shape `vb-rcheevos.ts` parses. `smoke.mjs` also
runs a leaderboard the whole way — it can move the emulated machine's memory,
so an attempt actually starts, tracks and submits. The browser probe
additionally confirms `importScripts` + the `-sENVIRONMENT=worker` wasm fetch
work in a classic worker.

`packages/web/tests/leaderboards-probe.mjs` is the third, and the only one
that goes through the interface: it signs in, loads a set and reads a board's
standings out of the Achievements panel.

None of them can test against the live server — that needs a registered client
and real credentials (see `RETROACHIEVEMENTS_CLIENT` in
`packages/core/src/common/vb-constants.ts`).

### Softcore only

`vueport-rc.c`'s `vrc_create` turns hardcore off immediately after
`rc_client_create` — rc_client defaults it **on**. VUEPort has no hardcore UI
and nothing here should be read as a step toward one on its own; see
`RETROACHIEVEMENTS_CLIENT` for why hardcore needs a conversation with
RetroAchievements first, softcore included.

That also decides what leaderboards do. Their list and their entries come
through the shim in either mode — the list is game data and the entries are a
server query, and reading a board is most of what anyone wants from one — but
rc_client only *runs* a leaderboard (the tracker over the picture, the
submission) while hardcore is on, which is RetroAchievements' own rule.
rc_client has an internal `allow_leaderboards_in_softcore` that would lift it;
the shim deliberately leaves it alone.
