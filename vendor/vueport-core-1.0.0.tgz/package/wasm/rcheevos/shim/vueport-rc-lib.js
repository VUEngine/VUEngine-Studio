/**
 * The JavaScript half of vueport-rc.c's three host hooks, wired in with
 * Emscripten's `--js-library` mechanism (see ../build.mjs).
 *
 * Each function here only decodes wasm-side arguments (a UTF-8 pointer, a
 * byte buffer) into ordinary JS values and forwards them to whatever
 * `vb-rcheevos.ts` set on the module instance before this ever runs
 * (`module.vrcReadMemory`, `module.vrcServerCall`, `module.vrcEmit`) — see
 * `ensureLoaded` there. `Module` here refers to that same instance:
 * Emscripten's MODULARIZE output gives every piece of library code, this
 * included, a closure over the module it was compiled into.
 */
mergeInto(LibraryManager.library, {
    /**
     * `vrc_read_memory` — read up to `numBytes` bytes of the emulated
     * machine's address space into the wasm heap at `buffer`. Returns how
     * many bytes were actually read, which is what
     * `rc_client_read_memory_func_t` itself returns to rc_client.
     */
    vrc_read_memory: function (address, buffer, numBytes) {
        if (typeof Module.vrcReadMemory !== 'function') {
            return 0;
        }
        return Module.vrcReadMemory(address >>> 0, buffer, numBytes >>> 0) >>> 0;
    },

    /**
     * `vrc_server_call` — rc_client wants an HTTP request made. `postData`
     * and `contentType` are 0 (the null pointer) for a GET, matching
     * `rc_api_request_t`'s own "null means GET" convention.
     */
    vrc_server_call: function (requestId, methodPtr, urlPtr, postDataPtr, contentTypePtr) {
        if (typeof Module.vrcServerCall !== 'function') {
            return;
        }
        Module.vrcServerCall(
            requestId,
            UTF8ToString(methodPtr),
            UTF8ToString(urlPtr),
            postDataPtr ? UTF8ToString(postDataPtr) : undefined,
            contentTypePtr ? UTF8ToString(contentTypePtr) : undefined,
        );
    },

    /** `vrc_emit` — one JSON message, decoded and handed up whole. */
    vrc_emit: function (jsonPtr) {
        if (typeof Module.vrcEmit !== 'function') {
            return;
        }
        Module.vrcEmit(UTF8ToString(jsonPtr));
    },
});
