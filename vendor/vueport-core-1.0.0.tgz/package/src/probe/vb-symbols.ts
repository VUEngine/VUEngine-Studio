import { readDwarfVariables, VesType, VesTypeKind } from '../browser/core/emulator-dwarf';
import { ElfSymbol, readElf } from '../browser/core/emulator-elf';
import { EMPTY_LINE_TABLE, parseDwarfLineTable, romOffsetOf, VesLineTable } from '../browser/core/emulator-line-table';
import { findFunctionAt, findSymbolAt, functionDisplayName, indexElfSymbols, SymbolIndex } from '../browser/core/emulator-symbols';

/** A named run of memory: a symbol, or a field or element of one. */
export interface VbExtent {
    address: number;
    /** At least one byte, even for a symbol the linker gave no size. */
    size: number;
    /** What is there, where the build says. */
    type?: VesType;
}

/** How deep a path is followed into nested structs and arrays. */
const MAX_DEPTH = 8;

/**
 * A build's names for its addresses, both ways round.
 *
 * Built on the same index the app's debug panels use, so a name here is the
 * name the Disassembly and Profiler panels show — `Actor::update` for a
 * VUEngine method, the bare C name for anything else. With DWARF in the build,
 * a global's fields have names too: `g_stats.lives`, `actors[3].position.x`.
 */
export class VbSymbols {

    /** Every name a symbol answers to, each to the symbol. */
    protected readonly byName = new Map<string, ElfSymbol>();

    protected constructor(
        readonly index: SymbolIndex,
        readonly lines: VesLineTable,
        /** Global variables' types, by their names in C. */
        readonly variables: Map<string, VesType>,
        protected readonly romSize: number,
        symbols: ElfSymbol[],
    ) {
        for (const symbol of symbols) {
            const bare = symbol.name.replace(/^_/, '');
            for (const name of [symbol.name, bare, functionDisplayName(index, symbol.name)]) {
                // The first wins: a name both a function and a local label
                // carry is the function's.
                if (!this.byName.has(name)) {
                    this.byName.set(name, symbol);
                }
            }
        }
    }

    /** Read an `.elf`, or undefined for bytes that are not one. */
    static fromElf(bytes: Uint8Array, romSize: number): VbSymbols | undefined {
        const image = readElf(bytes);
        if (!image) {
            return undefined;
        }
        const section = image.section('.debug_line');
        const lines = section ? parseDwarfLineTable(section, romSize) : EMPTY_LINE_TABLE;
        return new VbSymbols(indexElfSymbols(image), lines, readDwarfVariables(image), romSize, image.symbols);
    }

    /** A symbol by any of its names: `_main`, `main`, `Actor_update` or `Actor::update`. */
    lookup(name: string): ElfSymbol | undefined {
        return this.byName.get(name);
    }

    /**
     * Where a name is and how big: a symbol, or a path into one —
     * `g_stats.lives`, `actors[3]`, `actors[3].position.x`.
     */
    locate(path: string): VbExtent | undefined {
        const match = /^([^.[\]]+)(.*)$/.exec(path.trim());
        if (!match) {
            return undefined;
        }
        const symbol = this.lookup(match[1]);
        if (!symbol) {
            return undefined;
        }
        let type = this.typeOf(symbol);
        let address = symbol.address >>> 0;
        let size = Math.max(symbol.size, type?.byteSize ?? 0, 1);
        const steps = match[2].match(/\.[A-Za-z_]\w*|\[\d+\]/g) ?? [];
        if (steps.join('') !== match[2]) {
            throw new Error(`Cannot follow "${match[2]}" in "${path}".`);
        }
        for (const step of steps) {
            if (step.startsWith('.')) {
                const name = step.slice(1);
                const member = type?.kind === VesTypeKind.STRUCT ? type.struct?.members.find(candidate => candidate.name === name) : undefined;
                if (!member) {
                    throw new Error(`${path}: ${type ? `${type.name} has no member "${name}"` : 'the build has no type to look members up in'}.`);
                }
                address += member.offset;
                type = member.type;
            } else {
                const index = Number(step.slice(1, -1));
                const element = type?.kind === VesTypeKind.ARRAY ? type.element : undefined;
                if (!element || element.byteSize === 0) {
                    throw new Error(`${path}: ${type ? `${type.name} is not an array` : 'the build has no type to index'}.`);
                }
                if (type?.count !== undefined && index >= type.count) {
                    throw new Error(`${path}: index ${index} is past the end of ${type.name}.`);
                }
                address += index * element.byteSize;
                type = element;
            }
            size = Math.max(type.byteSize, 1);
        }
        return { address: address >>> 0, size, type };
    }

    /**
     * What an address is, as `function+0x1c` for code, `g_stats.lives` or
     * `table[3]+0x2` for data, or undefined where the build names nothing.
     */
    describe(address: number): string | undefined {
        const at = address >>> 0;
        if (isRomAddress(at)) {
            const code = findFunctionAt(this.index, at, this.romSize);
            if (code) {
                const offset = romOffsetOf(at, this.romSize) - romOffsetOf(code.address, this.romSize);
                return withOffset(functionDisplayName(this.index, code.name), offset);
            }
        }
        const data = findSymbolAt(this.index, at);
        if (!data) {
            return undefined;
        }
        const name = data.symbol.name.replace(/^_/, '');
        const type = this.typeOf(data.symbol);
        if (!type) {
            return withOffset(name, data.offset);
        }
        const inside = pathWithin(type, data.offset, 0);
        return withOffset(name + inside.path, inside.within);
    }

    /** The function an address is in, for grouping by routine. */
    functionAt(address: number): ElfSymbol | undefined {
        return findFunctionAt(this.index, address >>> 0, this.romSize);
    }

    /** The source line code at an address was compiled from. */
    sourceAt(address: number): { file: string, line: number } | undefined {
        const entry = this.lines.locate(romOffsetOf(address >>> 0, this.romSize));
        return entry && !entry.end ? { file: entry.file, line: entry.line } : undefined;
    }

    /** A data symbol's type, where the build describes it. */
    protected typeOf(symbol: ElfSymbol): VesType | undefined {
        if (symbol.isFunction) {
            return undefined;
        }
        return this.variables.get(symbol.name.replace(/^_/, '')) ?? this.variables.get(symbol.name);
    }
}

/**
 * The field and element a byte of a value belongs to, as a path to append to
 * its name, and how far into that innermost thing the byte is.
 */
function pathWithin(type: VesType, offset: number, depth: number): { path: string, within: number } {
    if (depth < MAX_DEPTH && type.kind === VesTypeKind.STRUCT && type.struct) {
        for (const member of type.struct.members) {
            const end = member.offset + Math.max(member.type.byteSize, 1);
            if (offset >= member.offset && offset < end) {
                const inner = pathWithin(member.type, offset - member.offset, depth + 1);
                return { path: `.${member.name}${inner.path}`, within: inner.within };
            }
        }
    }
    if (depth < MAX_DEPTH && type.kind === VesTypeKind.ARRAY && type.element && type.element.byteSize > 0) {
        const index = Math.floor(offset / type.element.byteSize);
        if (type.count === undefined || index < type.count) {
            const inner = pathWithin(type.element, offset - index * type.element.byteSize, depth + 1);
            return { path: `[${index}]${inner.path}`, within: inner.within };
        }
    }
    return { path: '', within: offset };
}

/** Whether an address is in the cartridge ROM window or its mirror at the top of memory. */
function isRomAddress(address: number): boolean {
    return (address >>> 24 & 0x07) === 0x07;
}

function withOffset(name: string, offset: number): string {
    return offset === 0 ? name : `${name}+0x${offset.toString(16)}`;
}
