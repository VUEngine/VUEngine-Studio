/**
 * The forks' worker: `ProbeForks` behind a message port, so that a fork run
 * for thousands of frames never holds up the page it was asked from.
 *
 * A host bundles this file as a worker entry of its own — VUEPort's web build
 * and VUEngine Studio both do — and talks to it through `ProbeForkWorker` in
 * `probe-session.ts`. Every message is a `ProbeForkRequest` with an id, and
 * every answer carries the id back with a `result` or an `error`.
 */
import { ProbeForkRequest, ProbeForks } from './probe-forks';

const forks = new ProbeForks();

const scope = self as unknown as {
    onmessage: ((event: MessageEvent<ProbeForkRequest>) => void) | null,
    postMessage(message: unknown): void,
};

scope.onmessage = event => {
    const request = event.data;
    forks.handle(request).then(
        result => scope.postMessage({ id: request.id, result }),
        (error: unknown) => scope.postMessage({ id: request.id, error: error instanceof Error ? error.message : String(error) }),
    );
};
