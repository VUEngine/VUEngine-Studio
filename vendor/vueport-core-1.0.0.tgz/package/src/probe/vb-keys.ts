import { VbKey } from '../common/vb-constants';

/**
 * Buttons by the names a person (or a script) writes them.
 *
 * The canonical names are the ones the controller's own documentation uses —
 * `LU` is the left D-pad's up, `RU` the right one's — with the obvious words
 * as aliases, because `A+RIGHT` is what anybody types first. The left pad is
 * the one games steer with, so the bare directions are its.
 */
const KEY_NAMES: Record<string, number> = {
    A: VbKey.A,
    B: VbKey.B,
    L: VbKey.LT,
    R: VbKey.RT,
    LT: VbKey.LT,
    RT: VbKey.RT,
    STA: VbKey.STA,
    START: VbKey.STA,
    SEL: VbKey.SEL,
    SELECT: VbKey.SEL,
    LU: VbKey.LU,
    LD: VbKey.LD,
    LL: VbKey.LL,
    LR: VbKey.LR,
    UP: VbKey.LU,
    DOWN: VbKey.LD,
    LEFT: VbKey.LL,
    RIGHT: VbKey.LR,
    RU: VbKey.RU,
    RD: VbKey.RD,
    RL: VbKey.RL,
    RR: VbKey.RR,
};

/** The names {@link formatKeys} writes, in the order it writes them. */
const CANONICAL: [string, number][] = [
    ['A', VbKey.A], ['B', VbKey.B], ['L', VbKey.LT], ['R', VbKey.RT],
    ['STA', VbKey.STA], ['SEL', VbKey.SEL],
    ['LU', VbKey.LU], ['LD', VbKey.LD], ['LL', VbKey.LL], ['LR', VbKey.LR],
    ['RU', VbKey.RU], ['RD', VbKey.RD], ['RL', VbKey.RL], ['RR', VbKey.RR],
];

/** Nothing held, with the controller present. */
export const NO_KEYS = VbKey.SGN;

/**
 * A button mask from `A+RIGHT`, `a,lu`, `0x1004` or `-`.
 *
 * The controller's signature bit is always set: it is what tells a game a
 * controller is plugged in at all, and the app sets it on every mask too — a
 * movie played here and there has to mean the same thing.
 */
export function parseKeys(text: string): number {
    const trimmed = text.trim();
    if (trimmed === '' || trimmed === '-' || /^none$/i.test(trimmed)) {
        return NO_KEYS;
    }
    if (/^0x[0-9a-f]+$/i.test(trimmed)) {
        return (parseInt(trimmed, 16) | VbKey.SGN) & 0xffff;
    }
    let mask = VbKey.SGN;
    for (const token of trimmed.split(/[+,|\s]+/)) {
        if (token === '') {
            continue;
        }
        const key = KEY_NAMES[token.toUpperCase()];
        if (key === undefined) {
            throw new Error(`Unknown button "${token}". Known: ${Object.keys(KEY_NAMES).join(' ')}.`);
        }
        mask |= key;
    }
    return mask;
}

/** A mask as `A+LR`, or `-` for nothing held. The signature bit is not a button. */
export function formatKeys(mask: number): string {
    const held = CANONICAL.filter(([, key]) => (mask & key) !== 0).map(([name]) => name);
    return held.length > 0 ? held.join('+') : '-';
}
