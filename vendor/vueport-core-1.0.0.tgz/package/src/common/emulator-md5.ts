/**
 * MD5 of a byte buffer, for the one thing that needs it: naming a ROM the way
 * RetroAchievements names it.
 *
 * RetroAchievements identifies a Virtual Boy dump by the MD5 of the whole file,
 * with no header skipping or transformation — the plain-buffer bucket of
 * rcheevos' `rc_hash`. `crypto.subtle` has no MD5 (and does not exist in an
 * insecure context at all), so it is written out here, the same way `crc32` is
 * in `emulator-cheat-database.ts` and for the same reasons: it is one hash, it
 * is short, and a dependency for it would never be used for anything else.
 *
 * Not a general-purpose hashing utility. MD5 is broken for every purpose that
 * matters and is used here only because it is the identifier a third party
 * already keys its catalog on.
 */

/** Per-round left-rotation amounts, as RFC 1321 tabulates them. */
const SHIFTS = [
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
    5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
];

/** The sine-derived constants `T[i] = floor(2^32 * abs(sin(i + 1)))`. */
const T = (() => {
    const table = new Uint32Array(64);
    for (let i = 0; i < 64; i++) {
        table[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;
    }
    return table;
})();

function rotl(value: number, count: number): number {
    return ((value << count) | (value >>> (32 - count))) >>> 0;
}

/**
 * The MD5 of `bytes`, as 32 lower-case hex digits.
 *
 * Streams the padded message in 64-byte blocks so a whole ROM — up to a couple
 * of megabytes — never needs a second copy.
 */
export function md5Hex(bytes: Uint8Array): string {
    let a0 = 0x67452301;
    let b0 = 0xefcdab89;
    let c0 = 0x98badcfe;
    let d0 = 0x10325476;

    const bitLength = bytes.length * 8;
    // One 0x80 byte, then zeros to 56 mod 64, then the 64-bit little-endian
    // length. Total is always a multiple of 64.
    const padded = new Uint8Array((Math.floor((bytes.length + 8) / 64) + 1) * 64);
    padded.set(bytes);
    padded[bytes.length] = 0x80;
    // JavaScript bit ops are 32-bit; the low word covers any ROM, and the high
    // word is written for completeness.
    new DataView(padded.buffer).setUint32(padded.length - 8, bitLength >>> 0, true);
    new DataView(padded.buffer).setUint32(
        padded.length - 4, Math.floor(bitLength / 0x100000000) >>> 0, true);

    const block = new Uint32Array(16);
    const view = new DataView(padded.buffer);
    for (let offset = 0; offset < padded.length; offset += 64) {
        for (let i = 0; i < 16; i++) {
            block[i] = view.getUint32(offset + i * 4, true);
        }

        let a = a0;
        let b = b0;
        let c = c0;
        let d = d0;

        for (let i = 0; i < 64; i++) {
            let f: number;
            let g: number;
            if (i < 16) {
                f = (b & c) | (~b & d);
                g = i;
            } else if (i < 32) {
                f = (d & b) | (~d & c);
                g = (5 * i + 1) % 16;
            } else if (i < 48) {
                f = b ^ c ^ d;
                g = (3 * i + 5) % 16;
            } else {
                f = c ^ (b | ~d);
                g = (7 * i) % 16;
            }
            f = (f + a + T[i] + block[g]) >>> 0;
            a = d;
            d = c;
            c = b;
            b = (b + rotl(f, SHIFTS[i])) >>> 0;
        }

        a0 = (a0 + a) >>> 0;
        b0 = (b0 + b) >>> 0;
        c0 = (c0 + c) >>> 0;
        d0 = (d0 + d) >>> 0;
    }

    return [a0, b0, c0, d0].map(word => {
        // Each 32-bit word is emitted little-endian, byte by byte.
        let hex = '';
        for (let byte = 0; byte < 4; byte++) {
            hex += ((word >>> (byte * 8)) & 0xff).toString(16).padStart(2, '0');
        }
        return hex;
    }).join('');
}
