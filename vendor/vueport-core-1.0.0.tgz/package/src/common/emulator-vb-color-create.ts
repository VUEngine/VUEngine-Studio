/**
 * Making a colorization for a game nobody has colorized.
 *
 * The four that ship with VUEPort were written by hand against one game each:
 * native code that knows when the game changes scene, which sprite is whose,
 * what a health bar looks like. Nothing here does any of that. What it does is
 * the part that is the same for every Virtual Boy cartridge — get VB Color
 * switched on before the game's first instruction, and put 256 editable
 * palettes somewhere the hardware reads them — and then get out of the way.
 *
 * The compiler is vendored in `vb-color/generic`; see `VENDORED.md` beside it
 * for what it emits and why the ROM comes out twice its size. This module is
 * the seam: it decides whether a ROM can take one, dresses the result up as
 * the format-2 document the rest of VUEPort already knows how to edit, build
 * and export, and encodes the ROM patch that carries it.
 *
 * The result is a starting point and is meant to read as one. A generic
 * bootstrap leaves Color Attribute RAM cleared, so a legacy game goes on
 * selecting BG palettes 0–3 and OBJ palettes 0–3 through the two-bit
 * selectors it always used — eight palettes of the 256, and the rest loaded,
 * editable and selected by nothing. Which of the other 248 belongs to which
 * pixel is the game-specific question, and answering it is what a hand-written
 * patch is for. The panel says so before it makes one.
 *
 * DOM-free, like `emulator-vb-color.ts`, so `tests/vb-color-create-probe.mjs`
 * can run the whole path.
 */

import { VesColorPatch } from './emulator-color-patches';
import { nls } from './emulator-nls';
import { createBpsPatch } from './emulator-rom-patches';
import { VbColorError, VbcPatchDocument } from './emulator-vb-color';
import {
    BG_PALETTE_COUNT,
    GenericPatchError,
    MAX_GENERIC_SOURCE_SIZE,
    MIN_GENERIC_SOURCE_SIZE,
    PALETTE_COUNT,
    createMirrorExpansionBps,
    generateGenericColorPatch,
    validateGenericSourceRom,
} from './vb-color/generic';
import { VbcEditorObject, VbcScene } from './vb-color/vbc-patch-export';

/** Who a created colorization is by, in the places a shipped one names its author. */
export const VB_COLOR_CREATED_AUTHOR = 'VUEPort';

/** The version string a created colorization carries — the compiler's, not VUEPort's. */
export const VB_COLOR_CREATED_VERSION = 'generic bootstrap v1';

/** The prefix a created colorization's catalog id is built from. */
const CREATED_ID_PREFIX = 'color/created';

/**
 * The palettes a legacy game selects on its own once the bootstrap has run.
 *
 * The two-bit GPLTS and JPLTS selectors it already uses, against Color
 * Attribute RAM the bootstrap cleared: BG 0–3, and the first four OBJ
 * palettes, which are global ids 128–131.
 */
export function vbColorGenericSelectsPalette(paletteId: number): boolean {
    const local = paletteId < BG_PALETTE_COUNT ? paletteId : paletteId - BG_PALETTE_COUNT;
    return local < 4;
}

/** The catalog id a colorization created for this ROM is filed under. */
export function createdColorPatchId(romId: string): string {
    return `${CREATED_ID_PREFIX}/${romId.toLowerCase()}`;
}

/** Whether a catalog id names a colorization somebody made here. */
export function isCreatedColorPatchId(id: string): boolean {
    return id.startsWith(`${CREATED_ID_PREFIX}/`);
}

/**
 * Why this ROM cannot take a generic colorization, or undefined if it can.
 *
 * Asked before the button is offered rather than after it is pressed, so the
 * refusal can sit in a tooltip instead of arriving as an error. The compiler's
 * own codes, said in words somebody can act on — the sizes are its limits, not
 * VUEPort's: mirror expansion doubles the image, and VB Color addresses 16 MiB.
 */
export function genericColorRefusal(source: Uint8Array | undefined): string | undefined {
    if (!source) {
        return nls.localize('vueport/vbColor/create/noRom', 'No game is loaded.');
    }
    try {
        validateGenericSourceRom(source);
        return undefined;
    } catch (error) {
        const code = error instanceof GenericPatchError ? error.code : '';
        switch (code) {
            case 'E_ROM_TOO_SMALL':
            case 'E_ROM_HEADER':
                return nls.localize(
                    'vueport/vbColor/create/tooSmall',
                    'This file is smaller than {0} KB, which is too small to be a Virtual Boy cartridge.',
                    String(MIN_GENERIC_SOURCE_SIZE / 1024));
            case 'E_ROM_NOT_POWER_OF_TWO':
                return nls.localize(
                    'vueport/vbColor/create/notPowerOfTwo',
                    'This ROM’s size is not a power of two, so the cartridge would not mirror the way '
                    + 'the game expects. Pad the dump to the next power of two and open it again.');
            case 'E_ROM_MAX_SIZE':
                return nls.localize(
                    'vueport/vbColor/create/tooLarge',
                    'This ROM is larger than {0} MB. Making a colorization doubles the cartridge, and VB Color '
                    + 'addresses {1} MB.',
                    String(MAX_GENERIC_SOURCE_SIZE / (1024 * 1024)),
                    String((MAX_GENERIC_SOURCE_SIZE * 2) / (1024 * 1024)));
            case 'E_ALREADY_VBC':
                return nls.localize(
                    'vueport/vbColor/create/alreadyColor',
                    'This ROM already declares VB Color support, so it has a colorization of its own.');
            default:
                return error instanceof Error ? error.message : String(error);
        }
    }
}

/**
 * The editor's two groups, for a colorization that knows nothing about the game.
 *
 * A shipped document names the things in the game that have colors — Wario,
 * the floor, the results screen — because somebody went and looked. Here there
 * is one fact worth saying and it is the same one for every game: eight of the
 * 256 palettes are the ones the game is actually selecting, and 248 are loaded
 * and waiting for something to select them. That is a scene filter, which the
 * panel already has, so it is said as one rather than as a second kind of
 * label nothing else understands.
 */
const SELECTED_SCENE = 'selected';
const UNMAPPED_SCENE = 'unmapped';

function createdScenes(): VbcScene[] {
    return [
        {
            id: SELECTED_SCENE,
            order: 0,
            name: nls.localize('vueport/vbColor/create/sceneSelected', 'In use by the game'),
            description: nls.localize(
                'vueport/vbColor/create/sceneSelectedDescription',
                'The palettes the game selects through the two-bit selectors it already uses. '
                + 'Editing these changes what is on screen.'),
        },
        {
            id: UNMAPPED_SCENE,
            order: 1,
            name: nls.localize('vueport/vbColor/create/sceneUnmapped', 'Not selected yet'),
            description: nls.localize(
                'vueport/vbColor/create/sceneUnmappedDescription',
                'Loaded and editable, but nothing in the game selects them. Reaching these needs a '
                + 'patch written for this game.'),
        },
    ];
}

function createdObjects(palettes: readonly { id: number, name: string }[]): VbcEditorObject[] {
    return palettes.map(palette => ({
        id: `palette-${palette.id}`,
        name: palette.name,
        sceneId: vbColorGenericSelectsPalette(palette.id) ? SELECTED_SCENE : UNMAPPED_SCENE,
        // The document's own order, so "BG Palette 10" does not sort above
        // "BG Palette 2" the way `vbcObjects` would otherwise arrange them.
        order: palette.id,
        entries: [{ type: 'palette' as const, id: palette.id }],
    }));
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
    const copy = bytes.slice();
    const digest = await crypto.subtle.digest('SHA-256', copy.buffer as ArrayBuffer);
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Compile a colorization for a ROM that has none.
 *
 * The compiler's document, with the editor metadata above laid over it: the
 * palettes and the BPS are its, and both are what every other path in VUEPort
 * reads. Nothing about the result is special-cased downstream — it carries the
 * palette ABI a shipped patch carries, so it is edited, built, live-previewed
 * and exported by the same code.
 *
 * The source ROM's SHA-256 goes into the patch's metadata, which is what stops
 * a document from being applied to a different dump of the same game later.
 */
export async function createGenericColorDocument(
    source: Uint8Array,
    options: { name: string, id?: string },
): Promise<VbcPatchDocument> {
    if (typeof crypto === 'undefined' || crypto.subtle === undefined) {
        throw new VbColorError(nls.localize(
            'vueport/vbColor/create/needsSubtle',
            'Making a color patch needs SHA-256, which this browser only offers on secure pages '
            + '(HTTPS or localhost).'));
    }
    const refusal = genericColorRefusal(source);
    if (refusal) {
        throw new VbColorError(refusal);
    }
    const sourceSha256 = await sha256Hex(source);
    const generated = generateGenericColorPatch(source, {
        name: options.name,
        id: options.id,
        sourceSha256,
    });
    const document = generated.document as unknown as VbcPatchDocument;
    return {
        ...document,
        description: nls.localize(
            'vueport/vbColor/create/description',
            'Made in VUEPort from a generic VB Color bootstrap. All {0} palettes are loaded and editable, '
            + 'but only the ones this game already selects are on screen: a generic patch cannot know which '
            + 'of the others belongs to what.',
            String(PALETTE_COUNT)),
        scenes: createdScenes(),
        objects: createdObjects(document.palettes),
    };
}

/**
 * The catalog entry a created colorization is shown under.
 *
 * The same shape a shipped one has, so the info page, the switch and the
 * per-game settings need to know nothing about where it came from — only
 * `author` and `version` say, which is where somebody would look. Filed as
 * `wip` because that is what it is: eight palettes doing something and 248
 * waiting for a patch that knows the game.
 */
export function createdColorPatchEntry(romId: string, game: string): VesColorPatch {
    return {
        id: createdColorPatchId(romId),
        game,
        crc32: [romId.toLowerCase()],
        author: VB_COLOR_CREATED_AUTHOR,
        version: VB_COLOR_CREATED_VERSION,
        status: 'wip',
        notes: nls.localize(
            'vueport/vbColor/create/notes',
            'Made here from a generic bootstrap rather than written for this game. VB Color is switched '
            + 'on before the game starts and all 256 palettes are loaded, but the game goes on choosing '
            + 'between the eight it always could — the rest are editable and nothing selects them.'),
    };
}

/**
 * The ROM patch that carries a built colorization to the patch store.
 *
 * {@link createBpsPatch} encodes every byte that differs as a literal, which
 * is right for a colorization that changes a ROM in place and wrong for one
 * that doubles it: the whole upper half differs from a source that has no
 * upper half, so a two-megabyte game would produce a two-megabyte patch — and
 * produce it again behind every color somebody changes. The compiler's own
 * encoder says the upper half as a copy of the lower one with the bootstrap,
 * the palette table and the header written over it, which is a few kilobytes
 * whatever the game's size.
 *
 * It only accepts that exact shape, so anything else — every shipped
 * colorization — falls back to the general encoder, which is what it was
 * always given.
 */
export function createColorRomPatch(source: Uint8Array, target: Uint8Array): Uint8Array {
    if (target.length === source.length * 2) {
        try {
            return createMirrorExpansionBps(source, target);
        } catch {
            // Not a mirror expansion after all; the general encoder says it
            // correctly, only at greater length.
        }
    }
    return createBpsPatch(source, target);
}
