/**
 * What the emulator needs from whatever it is running inside: somewhere to keep files, and somewhere to talk to the
 * person using it. Paths are opaque strings, as their meaning is the host's business (workspace-relative in VES,
 * an OPFS key on the web, a real path in a native wrapper); the emulator only composes them with parent, stem and join.
 */

export interface VueportFile {
    // in whatever form the storage understands
    path: string;
    // extension included
    name: string;
    size: number;
}

export interface VueportUsage {
    bytes: number;
    files: number;
}

// files kept beside a ROM: save RAM, save states, cheats, and the audio an ESSound cartridge plays
export interface VueportStorage {
    read(path: string): Promise<Uint8Array>;
    readText(path: string): Promise<string>;
    write(path: string, data: Uint8Array): Promise<void>;
    writeText(path: string, text: string): Promise<void>;
    exists(path: string): Promise<boolean>;
    // a file, or a directory with everything in it; nothing happens when there is no such path
    delete(path: string): Promise<void>;
    // empty when there is no such directory
    list(directory: string): Promise<VueportFile[]>;
    // zero when there is no such directory. Optional: list stops at the first level, so a host without this can only
    // be measured that far
    measure?(directory: string): Promise<VueportUsage>;

    parent(path: string): string;
    // without its extension
    stem(path: string): string;
    // extension included
    name(path: string): string;
    join(directory: string, name: string): string;

    // a file the emulator will not read back (a screenshot, a profile): in VES it lands in the project, on the web it is
    // a download
    export(name: string, data: Uint8Array): Promise<void>;

    // for a large Blob such as a video recording, avoiding two in-memory copies through export. Optional, a caller falls back
    // to export
    exportBlob?(name: string, blob: Blob): Promise<void>;
}

export interface VueportProgress {
    cancel(): void;
}

export interface VueportNotifications {
    info(text: string): void;
    warn(text: string): void;
    error(text: string): void;
    // resolves true if they agreed. `message` may be several paragraphs, laid out by the host, as the emulator builds no
    // DOM for it
    confirm(options: {
        title: string,
        message: string | string[],
        okLabel?: string,
    }): Promise<boolean>;
    progress(text: string): Promise<VueportProgress>;
}

export interface VueportHost {
    readonly storage: VueportStorage;
    readonly notifications: VueportNotifications;
}
