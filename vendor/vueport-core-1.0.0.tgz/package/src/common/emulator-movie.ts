/**
 * Recorded input movies, as the Virtual Boy emulators that make them write
 * them down.
 *
 * A movie is one line per frame saying which buttons were held, and nothing
 * else: no save states, no memory, no timing. Played back from a reset on the
 * same ROM, a deterministic core reproduces the run exactly — which is what
 * makes a tool-assisted run a usable way to drive the machine somewhere far
 * from the title screen.
 *
 * Only VBjin's `.mc2` is read here. It is the format the published Virtual Boy
 * runs are in, it is plain text, and the alternative formats belong to
 * emulators whose cores are not this one.
 *
 * ## What playing one back does not promise
 *
 * A movie reproduces a run exactly on the core it was recorded with, and only
 * there. Two cores that disagree about a single cycle of a single instruction
 * will hold the same buttons and get different games — usually within a minute
 * of real play, because the first thing a run that has drifted does is walk the
 * player into something.
 *
 * That is not a fault in either core or in this reader, and it cannot be
 * corrected by aligning the start: an emulator's idea of what happens between
 * power-on and its first counted frame differs too, and shifting the movie to
 * match only moves where the drift begins. adelikat's published Wario Land run
 * was measured against this checkout's core and comes apart about fifty
 * seconds into the first course whatever the alignment, on the patched
 * cartridge and the original alike. So playback is worth having for what it is
 * — a hands-free way to drive a game a long way from its title screen — and is
 * not a way to reproduce somebody else's run.
 */

/** One frame of a movie: the buttons held, as a VbKey mask. */
export type MovieFrame = number;

export interface Movie {
    /** What wrote it — `VBjin`, and the version it claims. */
    emulator: string;
    emulatorVersion: string;
    /** How many times the author rewound while making it, if it says. */
    rerecordCount?: number;
    /** The free-text `comment` lines, in order, with the keyword kept. */
    comments: string[];
    frames: MovieFrame[];
}

/**
 * Where each column of a movie's button string sits in a VbKey mask.
 *
 * VBjin writes the fourteen buttons from the controller's top bit down, which
 * is to say bit 15 first and bit 2 last; the two low bits are the power and
 * signature lines, which are the machine's business and not a button. Written
 * out rather than computed so that the order is checkable against a movie file
 * by eye — the characters in the comment are the ones the format uses.
 */
const MOVIE_COLUMNS = [
    0x8000, // R-down   .
    0x4000, // R-left   .
    0x2000, // Select   C
    0x1000, // Start    T
    0x0800, // L-up     ^
    0x0400, // L-down   v
    0x0200, // L-left   <
    0x0100, // L-right  >
    0x0080, // R-right  .
    0x0040, // R-up     .
    0x0020, // L-trigger L
    0x0010, // R-trigger R
    0x0008, // B        B
    0x0004, // A        A
];

/** How many buttons a movie line carries. */
export const MOVIE_BUTTON_COLUMNS = MOVIE_COLUMNS.length;

/**
 * Read a VBjin `.mc2`.
 *
 * Lenient about the header, which differs between the versions that wrote
 * these and carries nothing playback depends on, and strict about the frames,
 * which are the movie. A line that is not a frame and not a header line is
 * skipped rather than refused: a movie with a stray blank line is still a
 * movie.
 */
export function parseVesMovie(text: string): Movie {
    const movie: Movie = {
        emulator: '', emulatorVersion: '', comments: [], frames: [],
    };
    for (const raw of text.split(/\r?\n/)) {
        const line = raw.trimEnd();
        if (line.startsWith('|')) {
            // |command|buttons|, where the command column is a reset or a
            // power cycle. Nothing here acts on it — a movie that resets
            // mid-run would need the core to reset on that frame — but the
            // line is still a frame and its buttons still count.
            // `|command|buttons|` splits to four, the first and last empty.
            // A line short of that has lost its button column, and counting it
            // as a frame of nothing would shift every later frame by one —
            // which for a movie is not a blemish but a different game.
            const parts = line.split('|');
            if (parts.length < 4) {
                continue;
            }
            const buttons = parts[2];
            let keys = 0;
            for (let i = 0; i < MOVIE_COLUMNS.length && i < buttons.length; i++) {
                if (buttons[i] !== '.' && buttons[i] !== ' ') {
                    keys |= MOVIE_COLUMNS[i];
                }
            }
            movie.frames.push(keys);
            continue;
        }
        const [keyword, ...rest] = line.split(' ');
        const value = rest.join(' ');
        switch (keyword) {
            case 'emulator': movie.emulator = value; break;
            case 'emuVersion': movie.emulatorVersion = value; break;
            case 'rerecordCount': movie.rerecordCount = Number(value) || undefined; break;
            case 'comment': movie.comments.push(value); break;
            default: break;
        }
    }
    return movie;
}

/** Whether a file looks like a movie this can read, by its first line. */
export function looksLikeVesMovie(text: string): boolean {
    return /^version\s+\d/.test(text) && /\bemulator\s+VBjin\b/i.test(text.slice(0, 200));
}

/** A movie's length as a duration, at the Virtual Boy's fifty frames a second. */
export function formatVesMovieLength(frames: number): string {
    const seconds = Math.round(frames / 50);
    const minutes = Math.floor(seconds / 60);
    return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
}
