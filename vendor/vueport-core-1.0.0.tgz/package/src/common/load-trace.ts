/**
 * TEMPORARY: where the time goes between opening a ROM and its first frame.
 *
 * For a report from Linux of a ROM taking some five seconds to start, in the
 * desktop application and the browser alike. `begin` starts the clock when a
 * ROM is opened; every `mark` after it logs the step's own duration and the
 * running total, so one console dump says which step it is. Remove once that
 * is answered.
 */

let started: number | undefined;
let last = 0;

export function beginLoadTrace(): void {
    started = last = performance.now();
    console.info('[vueport] load trace: begin');
}

export function markLoadTrace(step: string): void {
    if (started === undefined) {
        return;
    }
    const now = performance.now();
    console.info(
        `[vueport] load trace: ${step.padEnd(28)} +${(now - last).toFixed(1).padStart(7)} ms`
        + `  (total ${(now - started).toFixed(1)} ms)`);
    last = now;
}

/** The last mark: logs it and stops, so later restarts do not keep logging. */
export function endLoadTrace(step: string): void {
    markLoadTrace(step);
    started = undefined;
}
