/**
 * The emulator's own settings.
 *
 * Named by what they are rather than by where a host keeps them: `palette`, not
 * `emulator.builtIn.palette`. The host owns the mapping onto its own storage —
 * in VES a Theia preference id, on the web a key in local storage — so
 * the emulator's code never spells out a host's namespace.
 *
 * Only what the emulator itself acts on is here. Which external emulator to
 * launch, whether to queue a run after a build, where a 3DS is on the network:
 * those are VES's, and stay there.
 */

import { DEFAULT_TURBO_RATE, TURBO_RATE_RANGE } from './emulator-turbo';
import type { ReactNode } from 'react';
import { EmulatorDecoration, EmulatorScale, VbHardwareMode } from '../browser/emulator-types';
import { Event } from './emulator-events';
import { GamepadProfile } from './emulator-gamepad-profiles';
import { EmulatorResumeStart } from './emulator-save-state';
import {
    DEFAULT_SAVE_SLOT,
    EmulatorCompanionLocation,
    EmulatorSramInit,
    EmulatorSramWindow,
} from './emulator-sram';
import {
    FrameBlending,
    VB_DEFAULT_ANAGLYPH_PALETTE_ID,
    VB_DEFAULT_PALETTE_ID,
    VbAnaglyphMatrices,
    VbDuboisProfileSelection,
    VbRenderingMode,
} from './vb-constants';

/** A custom palette, as the settings store it. */
export interface CustomPaletteSetting {
    name: string;
    colors: string[];
}

export interface CustomAnaglyphPaletteSetting {
    name: string;
    left: string;
    right: string;
    /** Explicitly `none` for RGB filters, a preset id, or user-edited matrices. */
    duboisProfile?: VbDuboisProfileSelection;
    duboisMatrices?: VbAnaglyphMatrices;
}

export interface VueportConfig {
    /** Master switch for exposing any VB Color hardware/features to software. */
    vbcSupportEnabled: boolean;
    /**
     * Whether a game VUEPort ships a colorization for gets it applied on load.
     *
     * The master switch over the colorizations in `PATCH_DATABASE`: off,
     * none is applied by itself whatever the individual entries say. See
     * `PatchStoreColorizations`.
     */
    vbcAutoApplyColorPatches: boolean;
    /**
     * Colorizations turned off one at a time, by entry id.
     *
     * Opt-out rather than opt-in, so a game that gains a colorization in a
     * later release is colored without anybody having to go and find the new
     * switch. Only read while {@link vbcAutoApplyColorPatches} is on.
     */
    vbcColorPatchesDisabled: string[];
    /** Physical console model: Auto, original Virtual Boy, or VB Color. */
    hardwareMode: string;
    /** Which of the VbRenderingMode values the picture is drawn in. */
    renderingMode: string;
    /** In the rendering modes that show both eyes, show each where the other's would go — see `DisplayMode.swapEyes`. */
    swapEyes: boolean;
    /**
     * Percent of the stereo parallax the picture is drawn with, 0–200 in
     * steps of 5: 100 is the real console, 0 flat, 200 twice as deep. Applied in the core, see `setStereoDepth`.
     */
    stereoDepth: number;
    /** One of FrameBlending: where a frame is shown mixed with the one before it. */
    frameBlending: FrameBlending;
    /**
     * Columns as wide as the game's column table makes them on the real
     * display unit, rather than all evenly. See `setColumnGeometry`.
     */
    columnTable: boolean;
    /**
     * A game loaded or reset comes up the way the display unit does when
     * switched on. Only what is shown; see `setMirrorSpinUp`.
     */
    mirrorSpinUp: boolean;
    /**
     * With `mirrorSpinUp`, dark for the whole 4 seconds a real display unit
     * takes rather than a moment. See `setMirrorSpinUp`.
     */
    mirrorSpinUpDelay: boolean;
    /** Id of the palette in use, built-in or `custom:`-prefixed. */
    palette: string;
    anaglyphPalette: string;
    customPalettes: CustomPaletteSetting[];
    customAnaglyphPalettes: CustomAnaglyphPaletteSetting[];
    /** One of EmulatorScale. */
    scale: string;
    /** One of EmulatorDecoration: what fills the view around the picture. */
    decoration: string;
    /** The halo color for the `ambient` decoration, as #rrggbb. Ignored when `decorationColorFromPalette` is on. */
    decorationColor: string;
    /**
     * Take the `ambient` halo's color from the picture's own palette instead
     * of {@link decorationColor} — the current palette's fully-lit level, or
     * white when Anaglyph is the rendering mode, since that mode has no one
     * palette to take it from.
     */
    decorationColorFromPalette: boolean;
    /** How strong the `ambient` and `immersion` halo is, 0–100. */
    decorationIntensity: number;
    /**
     * Whether a screenshot is taken the way the picture is currently shown.
     *
     * On, and the four settings below are ignored and the screen's own
     * rendering mode, palettes and a scale of one are used. Off, and a
     * screenshot is composed to its own taste — which is what a shot for a
     * web page or a manual usually wants, since that is rarely the mode the
     * game is being played in.
     */
    screenshotUseDisplaySettings: boolean;
    /** One of VbRenderingMode, for screenshots. See `screenshotUseDisplaySettings`. */
    screenshotRenderingMode: string;
    /** One of FrameBlending, for screenshots. See `screenshotUseDisplaySettings`. */
    screenshotFrameBlending: FrameBlending;
    /** Whole-number multiple of the mode's own size a screenshot is written at. */
    screenshotScale: number;
    /** Id of the palette screenshots use, built-in or `custom:`-prefixed. */
    screenshotPalette: string;
    screenshotAnaglyphPalette: string;
    /**
     * Whether a video is recorded the way the picture is currently shown.
     *
     * The screenshot settings' arrangement exactly — see
     * {@link screenshotUseDisplaySettings} — with one difference that comes
     * from a recording having a duration: the mode is settled when recording
     * starts and held to the end, because a stream whose frames change size
     * halfway through is not a file most players will open.
     */
    videoUseDisplaySettings: boolean;
    /** One of VbRenderingMode, for recordings. See `videoUseDisplaySettings`. */
    videoRenderingMode: string;
    /** One of FrameBlending, for recordings. See `videoUseDisplaySettings`. */
    videoFrameBlending: FrameBlending;
    /** Whole-number multiple of the mode's own size a video is recorded at. */
    videoScale: number;
    /** Id of the palette recordings use, built-in or `custom:`-prefixed. */
    videoPalette: string;
    videoAnaglyphPalette: string;
    /** One of VideoQuality: how many bits a second the picture is given. */
    videoQuality: string;
    /**
     * One of VideoFormat: which container a recording prefers.
     *
     * A preference and not a promise — a browser that cannot encode the one
     * asked for records in the other rather than refusing. See
     * `VideoRecorder.mimeTypes`.
     */
    videoFormat: string;
    sramInit: EmulatorSramInit;
    /**
     * How much of Game Pak RAM a cartridge answers on. See
     * `EmulatorSramWindow`, which is also where the reason for narrowing it
     * is written down.
     *
     * One setting for every game rather than one per ROM, like the save slot
     * beside it: it is a statement about what is being built for, not about
     * any one cartridge.
     */
    sramWindow: EmulatorSramWindow;
    /**
     * Which save file a game plays on: "A" through "Z". See
     * `EMULATOR_SAVE_SLOTS` for what a slot is and what each is called.
     *
     * One setting for every game rather than one per ROM, because it is a
     * question about how somebody is playing at the moment — a second run
     * through, a save to experiment in — and not a property of any cartridge.
     */
    saveGameSlot: string;
    /**
     * Whether the emulator takes a state of its own accord, every so often.
     *
     * Off by default: it writes a megabyte or so of the person's storage every
     * interval, which is not something to start doing to somebody without
     * being asked. What it buys is a very coarse rewind that survives a crash
     * — see {@link autoSaveStateInterval} and {@link autoSaveStateCount}.
     */
    autoSaveStatesEnabled: boolean;
    /** Seconds between automatic states. */
    autoSaveStateInterval: number;
    /**
     * How many automatic states are kept. The oldest falls out when a new one
     * arrives; manual states are never touched by the rotation.
     */
    autoSaveStateCount: number;
    /**
     * Whether closing a ROM — or VUEPort itself — writes the state the next
     * launch offers to resume from.
     *
     * On by default, because the state it writes costs nothing until somebody
     * closes a game mid-level, and the alternative in that moment is losing
     * the level. One state per ROM, overwritten every time; the next launch
     * asks before using it, and never uses it in hardcore mode.
     */
    suspendResumeEnabled: boolean;
    /**
     * What opening a game does with the state {@link suspendResumeEnabled}
     * put away for it: ask, or pick it up outright. Means nothing while the
     * feature is off, and nothing in hardcore mode, where no state is loaded
     * at all.
     */
    suspendResumeStart: EmulatorResumeStart;
    /**
     * Where a ROM's save, save states and cheats are written.
     *
     * The default here is the application's own storage, because that is the
     * answer that always works: a host that cannot write beside a ROM — a
     * browser, which is never told where a ROM came from — has nowhere else to
     * go. A host that can, and wants to, says so when it builds its settings.
     */
    companionFiles: EmulatorCompanionLocation;
    /** Whether player two uses player one's key mappings. */
    player2SameControls: boolean;
    /**
     * What each physical controller's buttons do, one entry per device.
     *
     * Kept here rather than with the key mappings because a host's keymap has
     * no notion of a game pad: `VueportInputBindings` is the seam onto one —
     * Theia's keybinding registry in VES — and a pad profile has nothing to
     * hang off a command. See `emulator-gamepad-profiles.ts` for the shape and
     * for why a pad the browser has normalized needs no entry at all.
     */
    gamepadProfiles: GamepadProfile[];
    /**
     * Which player a controller drives, by device key, for a linked pair.
     *
     * Absent for a device means "whichever the connection order implies",
     * which is the right answer for the common case of one pad per person
     * plugged in in the order they sat down.
     */
    gamepadPlayers: Record<string, number>;
    /**
     * Whether a game's rumble is played on the controller when no Rumble Pack
     * is there to play it.
     *
     * How strongly, in percent of what the pad's motors can do; 0 is off.
     *
     * On, and at full, by default: a game that sends rumble commands was
     * written to be felt, and nothing else in the browser will feel them.
     * Full because a great many pads cannot do anything else — SDL's Switch
     * driver says as much, and the 8BitDo 64 bears it out: below a threshold
     * its motor does not start, above it it runs flat out, and pulsing it
     * only rattles. On such a pad a lower setting does not soften anything,
     * it only drops the weak effects. The slider is for pads whose motors do
     * follow it. See `GamepadRumble` for what a pad can do with an effect.
     */
    gamepadRumbleIntensity: number;
    /**
     * How fast a turbo button presses itself, in frames per half period: held
     * for this many frames, released for as many. 2 is about 12.5 presses a
     * second. One rate for every turbo button, keyboard and pad alike.
     */
    turboRate: number;
    rewindEnabled: boolean;
    /** Frames of emulation covered by one entry of rewind history. */
    rewindGranularity: number;
    /** Rewind history budget, in MB. */
    rewindBufferSize: number;
    slowMotionRatio: number;
    fastForwardRatio: number;
    /**
     * Whether to connect to RetroAchievements while playing.
     *
     * Off by default: it needs an account, it makes network calls, and a host
     * that cannot make them at all (a browser — see the RetroAchievements
     * service) shows it fixed off with the reason beside it.
     */
    retroAchievementsEnabled: boolean;
    /**
     * Whether hardcore mode is on: cheats, macros, ROM patches, save-state loading, rewind
     * and Debug mode are all disabled while it is, and the achievement engine
     * runs in hardcore. The switch and the discipline live in
     * `RetroAchievementsService` and the host's hardcore controls.
     *
     * Hardcore *unlocks* are still inert until RetroAchievements approves the
     * VUEPort client — an emulator that ships a memory editor, a disassembler,
     * rewind and save states has a conversation to have with them first — but
     * the client-side restrictions apply now.
     */
    retroAchievementsHardcore: boolean;
    /**
     * How each debug panel was left set up, by `"<panel>.<control>"`.
     *
     * One setting rather than a dozen, and no schema entry, because none of it
     * belongs on a settings page: these are the knobs on the panels themselves
     * — how wide the character atlas is drawn, whether the disassembly follows
     * the program counter — and the only place to change one is the panel it
     * is on. Kept here all the same so that reopening the emulator finds the
     * inspectors the way they were last left, which is what every other part
     * of the layout already does.
     *
     * Sparse: a control that has never been touched is simply absent, and a
     * value whose type no longer matches what the panel expects is ignored.
     * See `VesEmulatorPanel.remembered`.
     */
    debugPanelState: Record<string, string | number | boolean>;
    /** Whether an error notification plays a sound cue alongside the toast. */
    errorSoundEnabled: boolean;
    /** Whether earning an achievement plays a sound cue alongside its toast. */
    achievementSoundEnabled: boolean;
}

/** What every setting is when nothing has been configured. */
export const VUEPORT_DEFAULTS: VueportConfig = {
    vbcSupportEnabled: true,
    vbcAutoApplyColorPatches: false,
    vbcColorPatchesDisabled: [],
    hardwareMode: VbHardwareMode.AUTO,
    renderingMode: VbRenderingMode.LEFT,
    swapEyes: false,
    stereoDepth: 100,
    frameBlending: FrameBlending.SMART,
    columnTable: true,
    mirrorSpinUp: false,
    mirrorSpinUpDelay: true,
    palette: VB_DEFAULT_PALETTE_ID,
    anaglyphPalette: VB_DEFAULT_ANAGLYPH_PALETTE_ID,
    customPalettes: [],
    customAnaglyphPalettes: [],
    scale: EmulatorScale.AUTO,
    decoration: EmulatorDecoration.IMMERSION,
    decorationColor: '#ffffff',
    decorationColorFromPalette: false,
    decorationIntensity: 30,
    screenshotUseDisplaySettings: true,
    screenshotRenderingMode: VbRenderingMode.LEFT,
    screenshotFrameBlending: FrameBlending.SMART,
    screenshotScale: 1,
    screenshotPalette: VB_DEFAULT_PALETTE_ID,
    screenshotAnaglyphPalette: VB_DEFAULT_ANAGLYPH_PALETTE_ID,
    videoUseDisplaySettings: true,
    videoRenderingMode: VbRenderingMode.LEFT,
    videoFrameBlending: FrameBlending.SMART,
    // Two, unlike a screenshot's one: 384x224 is smaller than anything that
    // plays video will show it at, and a player's own scaling is not the
    // nearest-neighbor one the picture wants.
    videoScale: 2,
    videoPalette: VB_DEFAULT_PALETTE_ID,
    videoAnaglyphPalette: VB_DEFAULT_ANAGLYPH_PALETTE_ID,
    videoQuality: 'medium',
    videoFormat: 'auto',
    sramInit: EmulatorSramInit.RANDOM,
    sramWindow: EmulatorSramWindow.AUTO,
    saveGameSlot: DEFAULT_SAVE_SLOT,
    autoSaveStatesEnabled: false,
    autoSaveStateInterval: 60,
    autoSaveStateCount: 5,
    suspendResumeEnabled: false,
    suspendResumeStart: EmulatorResumeStart.ASK,
    companionFiles: EmulatorCompanionLocation.STORAGE,
    player2SameControls: true,
    gamepadProfiles: [],
    gamepadPlayers: {},
    gamepadRumbleIntensity: 100,
    turboRate: DEFAULT_TURBO_RATE,
    rewindEnabled: false,
    rewindGranularity: 1,
    rewindBufferSize: 256,
    slowMotionRatio: 8,
    fastForwardRatio: 4,
    retroAchievementsEnabled: false,
    retroAchievementsHardcore: false,
    debugPanelState: {},
    errorSoundEnabled: true,
    achievementSoundEnabled: true,
};

/** The bounds a host should hold a numeric setting to. */
export const VUEPORT_SETTING_RANGES: Partial<Record<keyof VueportConfig, { min: number, max: number }>> = {
    stereoDepth: { min: 0, max: 200 },
    gamepadRumbleIntensity: { min: 0, max: 100 },
    turboRate: TURBO_RATE_RANGE,
    decorationIntensity: { min: 0, max: 100 },
    screenshotScale: { min: 1, max: 8 },
    videoScale: { min: 1, max: 8 },
    autoSaveStateInterval: { min: 10, max: 900 },
    autoSaveStateCount: { min: 1, max: 20 },
    rewindGranularity: { min: 1, max: 32 },
    rewindBufferSize: { min: 8, max: 1024 },
    slowMotionRatio: { min: 1, max: 32 },
    fastForwardRatio: { min: 1, max: 32 },
};

/**
 * Reading and writing the emulator's settings.
 *
 * `ready` exists because a host may resolve its settings asynchronously — VES's
 * folder-scoped providers are not answering yet when a restored
 * widget is built, and until they are, every read gives back a default. The
 * emulator waits for this once, before it reads anything that decides how it
 * starts up.
 */
export interface VueportSettings {
    /**
     * Settings this host has settled, with the reason for each.
     *
     * A setting listed here is shown fixed rather than hidden: one that simply
     * vanishes in one application looks like a feature that is missing, where
     * one shown with a reason beside it says what the application does and why
     * it has no choice. Absent for a host that settles nothing.
     */
    readonly fixed?: Partial<Record<keyof VueportConfig, string>>;
    /**
     * What this host counts as standard, where that differs from the
     * emulator's own answer.
     *
     * `VUEPORT_DEFAULTS` is what a setting is worth when nobody has an opinion,
     * and some hosts do have one — the desktop keeps a ROM's save beside it,
     * which a browser cannot. "Reset to default" has to mean *this*
     * application's default, or it would offer to undo the way the application
     * ships. Absent for a host that takes the emulator's answers as they come.
     */
    readonly defaults?: Partial<VueportConfig>;
    get<K extends keyof VueportConfig>(key: K): VueportConfig[K];
    set<K extends keyof VueportConfig>(key: K, value: VueportConfig[K]): Promise<void>;
    /** Fires with the setting that changed. */
    readonly onDidChange: Event<keyof VueportConfig>;
    readonly ready: Promise<void>;
}

/**
 * What the emulator needs to know about the keys bound to its commands.
 *
 * Two questions only: what is bound to this, and let the person change it. The
 * emulator does not own a keymap — VES has one already, and a standalone
 * host will have its own — so it asks rather than keeps.
 */
export interface VueportBindableCommand {
    id: string;
    /** Shown as the title of whatever the host asks for a key with. */
    label?: string;
    category?: string;
}

/**
 * What a write to the keymap answers with.
 *
 * Nothing, for a host that keeps its mappings in memory and has them the
 * moment it is told; a promise, for one whose keymap is a file — the studio's
 * is a Theia keymap, written through Monaco and read back into the registry —
 * where the change is not in force until it resolves. Callers that redraw
 * afterwards have to wait for it, or they draw the mappings as they were.
 */
export type VueportBindingWrite = void | Promise<void>;

export interface VueportInputBindings {
    /**
     * The keys bound to a command, ready to show. `compact` asks for the form
     * that goes in a tooltip beside a label rather than on its own.
     */
    label(commandId: string, compact: boolean): string;
    /**
     * The key codes bound to a command, as `KeyboardEvent.code` spells them.
     *
     * Codes rather than the host's own binding objects, because that is all the
     * key handler compares against — and a code is the same everywhere, while a
     * binding object is whatever its keymap happens to be made of.
     */
    keyCodes(commandId: string): string[];
    /**
     * Ask the person for a key and bind it. Resolves true if the binding
     * changed. `when` is the context a new mapping should apply in, which
     * matters for a command that has none to copy from yet.
     *
     * Takes the whole command rather than its id: the host names what it is
     * asking about, and only the command carries that name. `title` overrides
     * that name in the prompt — the input settings pass a node with the D-pad
     * arrow as an icon rather than the glyph the label carries.
     */
    capture(command: VueportBindableCommand, when?: string, title?: ReactNode): Promise<boolean>;
    /**
     * Ask for a key for each command in turn, and bind the whole set at once —
     * or nothing, if the person presses Escape before the last one.
     *
     * Each command is set to exactly the key pressed, replacing whatever it
     * answered to. Nothing is saved until every command has been answered, so
     * an abort leaves the existing mappings untouched. `title` names the step
     * for the prompt — "Start · 6 of 14"; `onStep` is told the index of the
     * command about to be asked for, so the caller can point at it. Resolves
     * true only if the set was saved.
     */
    captureAll(
        commands: VueportBindableCommand[],
        when: string | undefined,
        title: (command: VueportBindableCommand, step: number, total: number) => ReactNode,
        onStep?: (index: number) => void,
    ): Promise<boolean>;
    /**
     * Put every mapping back to the keys the application ships with.
     *
     * Offered as one button in the input settings; the per-command reset lives
     * in the capture prompt.
     */
    resetToDefaults(): VueportBindingWrite;
    /**
     * Add a key to what a command already answers to, without asking for one —
     * the caller already has it. Resolves to whether it was new; a key the
     * command already answers to changes nothing. What {@link capture} does
     * once it has a key, for a caller that reads its own key presses instead
     * of asking this to.
     */
    bind(commandId: string, code: string): boolean | Promise<boolean>;
    /** Drop every key a command answers to. */
    clear(commandId: string): VueportBindingWrite;
    /**
     * Drop one of the keys a command answers to, leaving the rest. Optional: a
     * host without it gets no per-key remove buttons in the capture prompt —
     * Clear All Mappings still empties the command.
     */
    unbind?(commandId: string, code: string): VueportBindingWrite;
    /**
     * What one key is called — `KeyA` as "A" — for a prompt listing a
     * command's keys one at a time. Optional, for the same reason as
     * {@link unbind}; without it the prompt shows {@link label} whole.
     */
    keyLabel?(code: string): string;
    /** Put one command back to the key it ships with. */
    resetToDefault(commandId: string): VueportBindingWrite;
    /**
     * Replace what a whole set of commands answer to, in one write — a fresh
     * layout, or a preset, landing as a single change rather than one per key.
     * What {@link captureAll} does with what it collected, and what a preset
     * applies wholesale.
     */
    replaceAll(codes: Record<string, string>): VueportBindingWrite;
}
