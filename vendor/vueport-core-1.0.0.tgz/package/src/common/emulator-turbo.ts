/**
 * Turbo: a button that, held, presses and releases itself over and over.
 *
 * The rhythm is counted in emulated frames rather than wall-clock time, so that
 * it is the same at any speed and the same in both windows of a linked pair:
 * a turbo button is pressed for `rate` frames and released for `rate` frames,
 * and which half of that a frame falls in depends on nothing but its number.
 */

/** Frames per half period when nothing says otherwise: about 12.5 presses a second. */
export const DEFAULT_TURBO_RATE = 2;

/** The fastest and slowest rates the settings offer, in frames per half period. */
export const TURBO_RATE_RANGE = { min: 1, max: 8 };

/** A rate made safe to count with: a whole number within {@link TURBO_RATE_RANGE}. */
export function clampTurboRate(rate: number): number {
    if (!Number.isFinite(rate)) {
        return DEFAULT_TURBO_RATE;
    }
    return Math.min(TURBO_RATE_RANGE.max, Math.max(TURBO_RATE_RANGE.min, Math.round(rate)));
}

/**
 * Whether turbo buttons are down on this frame.
 *
 * Down for the first half of every period, so a turbo press that starts on a
 * period boundary reaches the game at once.
 */
export function turboPressedOn(frame: number, rate: number): boolean {
    return Math.floor(frame / clampTurboRate(rate)) % 2 === 0;
}

/** The mask a frame runs with: the held buttons, plus the turbo ones while they are down. */
export function withTurbo(keys: number, turboKeys: number, frame: number, rate: number): number {
    return turboKeys !== 0 && turboPressedOn(frame, rate) ? (keys | turboKeys) >>> 0 : keys;
}
