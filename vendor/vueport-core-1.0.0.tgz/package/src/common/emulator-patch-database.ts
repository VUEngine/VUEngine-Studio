import { RomPatchFormat, RomPatchType } from './emulator-rom-patches';

/** A ROM patch shipped with VUEPort. */
export interface BuiltInRomPatch {
    /** Stable key used only to persist the enabled state. */
    id: string;
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: readonly number[];
    description: string;
    author: string;
    type: RomPatchType;
    /** Optional URL of an image shipped with VUEPort. */
    screenshot?: string;
}

/** Patches belonging to one exact, whole-file ROM checksum. */
export interface RomPatchDatabaseEntry {
    game: string;
    crc32: string;
    patches: readonly BuiltInRomPatch[];
}

/**
 * Patches distributed with VUEPort.
 *
 * Like the cheat database, this is keyed by the unmodified ROM's CRC32: an
 * offset patch must never be offered for a merely similar dump.
 */
export const PATCH_DATABASE: RomPatchDatabaseEntry[] = [
    {
        game: 'Space Pinball',
        crc32: '44c2b723',
        patches: [
            {
                id: 'space-pinball/score-reset',
                name: 'Score Reset',
                fileName: 'SpacePinballScoreReset.ips',
                format: 'ips',
                description: 'This patch for Space Pinball, the Galactic Pinball prototype, '
                    + 'resets the score to 0 when a new game is started.',
                author: 'HorvatM',
                type: 'hack',
                data: [
                    0x50, 0x41, 0x54, 0x43, 0x48, 0x0a, 0xc5, 0x84,
                    0x00, 0x0c, 0x20, 0xbc, 0x13, 0x07, 0x21, 0xa0,
                    0x00, 0x80, 0x01, 0x18, 0x00, 0x00, 0x12, 0x80,
                    0x00, 0x00, 0x1a, 0xe3, 0xdf, 0x00, 0x00, 0x08,
                    0xd4, 0x42, 0x00, 0x40, 0xa1, 0x00, 0x01, 0x04,
                    0xdc, 0x90, 0x6f, 0x20, 0xbc, 0x0b, 0x07, 0x21,
                    0xa0, 0x90, 0xc5, 0x01, 0x18, 0x45, 0x4f, 0x46,
                ],
            },
        ],
    },
];

/** Built-ins for one original ROM, copied so callers may own their state. */
export function builtInPatchesFor(
    romId: string | undefined,
    database: readonly RomPatchDatabaseEntry[] = PATCH_DATABASE,
): BuiltInRomPatch[] {
    if (!romId) {
        return [];
    }
    return database.find(entry => entry.crc32.toLowerCase() === romId.toLowerCase())
        ?.patches.map(patch => ({ ...patch, data: [...patch.data] })) ?? [];
}
