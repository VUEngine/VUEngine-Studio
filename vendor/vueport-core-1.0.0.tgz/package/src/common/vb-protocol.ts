/**
 * Message protocol between the DOM thread and the emulator core worker.
 *
 * Every command is a request/response pair correlated by id, so callers get a
 * promise per call instead of relying on strict message ordering.
 */

import { LiveProfileSnapshot } from './emulator-live-profile';
import { DisplayMode } from './vb-constants';

/** Opaque handle to a simulation living inside the worker. */
export type SimHandle = number;

/**
 * A session, small enough to keep and exact enough to replay.
 *
 * The drive loop emulates fixed-size chunks and input only ever changes
 * between them, so the whole of a session's input is the mask in effect at
 * each chunk — and since most chunks change nothing, only the changes are
 * kept.
 */
export interface Recording {
    /** The machine when recording began. */
    state: ArrayBuffer;
    /** Chunks recorded, which is how long the replay runs for. */
    chunks: number;
    /** `[chunk, mask]` pairs, at the chunks where the mask changed. */
    keys: [number, number][];
}

/** One node of a replayed call tree, flattened for the message channel. */
export interface ProfileNode {
    parent: number;
    address: number;
    selfSamples: number;
    totalSamples: number;
}

export interface ProfileResult {
    nodes: ProfileNode[];
    /** Instructions executed, which is what the samples add up to. */
    instructions: number;
    /** Calls dropped for depth, which should be zero on anything sane. */
    overflows: number;
    /**
     * How many times the machine restarted while recording. A profile spanning
     * several reboots describes several runs, and the reader should be told.
     */
    resets: number;
    /** How long the replay took, for reporting against the time recorded. */
    elapsedMs: number;
}

/** A coarse stereo frame used to color the immersion halo. */
export interface Backdrop {
    /** Legacy eye brightness or VBC RGB555, packed like the renderer input. */
    pixels: ArrayBuffer;
    /** True when each RGBA cell contains left RGB555 in R/G and right in B/A. */
    colorMode: boolean;
}

/** One uncomposited video frame, in the renderer's packed transport format. */
export interface Frame {
    /** Legacy eye brightness or VBC RGB555, packed like the renderer input. */
    pixels: ArrayBuffer;
    /** True when the four channels contain two little-endian RGB555 words. */
    colorMode: boolean;
}

/** A frame sent to a main-thread renderer, tagged against canvas replacement. */
export interface VideoFrame extends Frame {
    sim: SimHandle;
    presentation: number;
}

export interface CoreCommands {
    /** Instantiate the WebAssembly core. Must be sent first. */
    init: {
        params: {
            wasmUrl: string;
            /**
             * URL of the RetroAchievements engine's Emscripten glue
             * (`rcheevos.js`), loaded lazily on first use with `importScripts`.
             * Undefined for a host that has none to offer, or a build with no
             * `rcheevos.wasm` bundled — either way RetroAchievements reports
             * itself unavailable rather than failing to start.
             */
            rcheevosModuleUrl?: string;
        };
        result: void;
    };
    /** Create a simulation and return its handle. */
    createSim: { params: Record<string, never>; result: SimHandle };
    /** Destroy a simulation and release its resources. */
    deleteSim: { params: { sim: SimHandle }; result: void };
    /**
     * Attach video presentation.
     *
     * Ordinarily the canvas is transferred and rendered in this worker. A
     * WebKitGTK host instead supplies a small pool of buffers: the worker
     * fills and transfers those to the page's WebGL2 renderer, and the page
     * returns each one after uploading it.
     */
    attachCanvas: {
        params: { sim: SimHandle; canvas: OffscreenCanvas } | {
            sim: SimHandle;
            mainThread: { presentation: number; buffers: ArrayBuffer[] };
        };
        result: void;
    };
    /** Load cartridge ROM. The buffer is transferred. */
    setCartRom: { params: { sim: SimHandle; rom: ArrayBuffer }; result: void };
    /** Load cartridge save RAM. The buffer is transferred. */
    setCartRam: { params: { sim: SimHandle; ram: ArrayBuffer }; result: void };
    /**
     * Read back cartridge save RAM, or the first `length` bytes of it.
     *
     * The window is the whole of Game Pak RAM, so this is a 16 MiB copy
     * through a `postMessage` unless the caller says how much it wants. Every
     * caller that knows — and after `cartRamInfo` they all do — should.
     */
    getCartRam: {
        params: { sim: SimHandle; length?: number };
        result: ArrayBuffer;
    };
    /**
     * How big the cartridge's save window is, and how far into it the game
     * has written.
     *
     * Answered here rather than by reading the buffer out, because the
     * question is a number and the buffer is 16 MiB: the scan runs where the
     * memory already is. See `saveRamHighWater` for why `used` can be known
     * at all without watching every write the game makes.
     */
    cartRamInfo: {
        params: { sim: SimHandle };
        result: { size: number; used: number };
    };
    /**
     * The size of the core's state struct.
     *
     * The cheapest fingerprint of which core build is running, which is what a
     * save state already compares itself against. Two windows that mean to
     * play together check it before they start, so a tab left open across a
     * deploy is refused rather than desyncing.
     */
    stateSize: { params: Record<string, never>; result: number };
    /** Reset a simulation to its power-on state. */
    reset: { params: { sim: SimHandle }; result: void };
    /** Select the physical console model. Does not activate VBCEN. */
    setHardwareMode: { params: { sim: SimHandle; vbc: boolean }; result: boolean };
    /** Set the pressed-button bitmask (see VbKey), effective immediately. */
    setKeys: { params: { sim: SimHandle; keys: number }; result: void };
    /**
     * Set the pressed-button bitmask for a *future* frame.
     *
     * `setKeys` applies whenever its message happens to arrive, which is fine
     * for one machine answering one keyboard but useless for two that have to
     * agree: the same press has to land on the same frame on both, however
     * long the wire took. So a mask can instead be booked against the frame
     * number it belongs to, and the drive loop applies it as that frame comes
     * up. Frames are counted the way the `speed` report counts them.
     *
     * A frame that has already been emulated is refused rather than silently
     * dropped — arriving too late is exactly what a link session needs to
     * hear about.
     */
    queueKeys: {
        params: { sim: SimHandle; frame: number; keys: number };
        result: void;
    };
    /**
     * Refuse to emulate a simulation past the input it has been given.
     *
     * The other half of {@link queueKeys}. Under lockstep the drive loop stops
     * at the first frame it has no booked mask for and says so
     * ({@link Events.awaitingInput}) rather than running on with a stale
     * one, which is what keeps two machines in step at the cost of stalling
     * when one of them falls behind.
     *
     * Off by default; one emulator answering one keyboard never wants it.
     */
    setLockstep: { params: { sim: SimHandle; enabled: boolean }; result: void };
    /**
     * A digest of everything the emulated program can see.
     *
     * For telling two machines that should be identical apart. Taken over the
     * registers and the three writable memory regions rather than over the
     * state struct a save state copies: the struct also holds absolute
     * pointers and an address-hashed cache, which differ harmlessly between
     * two instances of the core and would report a desync that is not one.
     * See `tests/determinism-probe.mjs`, which is where that was established.
     */
    stateDigest: {
        params: { sim: SimHandle };
        result: { frame: number; digest: number };
    };
    /**
     * Take that digest by itself, every `frames` frames, and report it.
     *
     * Asking for one is not enough to compare two machines with: "now" is a
     * different moment in each window, and two digests of different frames say
     * nothing. Taken on a frame number instead, both windows produce theirs at
     * exactly the same point in the emulated run and the two are comparable.
     *
     * Zero turns it off. It costs about 2% of a frame each time.
     */
    setDigestPeriod: { params: { sim: SimHandle; frames: number }; result: void };
    /** Select the display mode, which also resizes the presentation surface. */
    setDisplayMode: { params: { sim: SimHandle; mode: DisplayMode }; result: void };
    /**
     * The presented frame as a PNG.
     *
     * With no `mode` it is exactly what is on screen. With one, the frame is
     * composed again into a renderer of the worker's own — so a screenshot can
     * be a different rendering mode and palette from the one being played in,
     * without the live picture flickering through the change. `scale` is a
     * whole multiple of the mode's own size.
     */
    capture: {
        params: { sim: SimHandle; mode?: DisplayMode; scale?: number };
        result: ArrayBuffer
    };
    /** Set output volume, 0 to 10. */
    setVolume: { params: { sim: SimHandle; volume: number }; result: void };
    /** Set stereo panning, -1 to +1. */
    setPanning: { params: { sim: SimHandle; panning: number }; result: void };
    /** Begin audio-clocked emulation of every attached simulation. */
    run: { params: Record<string, never>; result: void };
    /** Halt emulation. */
    suspend: { params: Record<string, never>; result: void };
    /** Snapshot a simulation's entire state. */
    saveState: { params: { sim: SimHandle }; result: ArrayBuffer };
    /** Restore a snapshot taken by saveState. */
    loadState: { params: { sim: SimHandle; state: ArrayBuffer }; result: void };
    /**
     * Begin recording what a simulation is told to do, so the session can be
     * replayed later and profiled exhaustively. Emulation is deterministic, so
     * the machine's state now plus the input from here on reproduces it
     * exactly. Recording costs a snapshot and a few bytes per chunk.
     */
    startProfileRecording: { params: { sim: SimHandle }; result: void };
    /** Stop recording and hand back what was recorded. */
    stopProfileRecording: { params: { sim: SimHandle }; result: Recording };
    /**
     * Replay a recording on a scratch simulation, following every instruction,
     * and return the call tree it produced.
     *
     * Runs to completion before replying — a minute of play takes some seconds
     * (§6.3) — and never touches the simulation the recording came from.
     */
    replayProfile: {
        params: { sim: SimHandle; recording: Recording };
        result: ProfileResult;
    };
    /**
     * Follow every instruction as it runs and keep a per-frame profile of
     * where the machine's clocks are going.
     *
     * Nothing like `startProfileRecording`, which records input now and
     * collects the profile later: this measures the run as it happens, so the
     * figures move while the game is played. It costs a callback on every
     * instruction — around a fifth of the headroom the core has over real time
     * — so it is off unless something is actually showing the result, and the
     * panel that does switches it off again when it is hidden.
     */
    setLiveProfiler: {
        params: { sim: SimHandle; enabled: boolean; window?: number };
        result: void;
    };
    /**
     * The last window of profiled frames, aggregated.
     *
     * Undefined when nothing is being profiled, which is an ordinary state
     * rather than an error: the panel asks before it has switched profiling on,
     * and after a machine has gone away underneath it.
     */
    readLiveProfile: {
        params: {
            sim: SimHandle;
            /**
             * A frame to unpack as well, by its number since profiling began.
             * The aggregate says a frame overran; this is what was in it.
             * Silently absent once that frame has left the window.
             */
            pin?: number;
        };
        result: LiveProfileSnapshot | undefined;
    };
    /**
     * Emulation rate, where 1 is real time. Above 1 fast forwards, below 1
     * runs in slow motion. Applies to the whole session.
     */
    setSpeed: { params: { speed: number }; result: void };
    /** Advance every simulation by exactly one frame, then stop. */
    stepFrame: { params: Record<string, never>; result: void };
    /** Configure the rewind ring buffer. Disabling it releases the memory. */
    setRewind: {
        params: { enabled: boolean; granularity: number; budgetBytes: number };
        result: void
    };
    /**
     * Step back up to `count` rewind entries, defaulting to one, and present
     * the state that lands. Returns how many entries were actually applied;
     * fewer than asked for means the buffer ran out.
     */
    rewindStep: { params: { count?: number }; result: number };
    /**
     * Wire two simulations together over the link port, or pass a peer of 0 to
     * disconnect. Both must belong to this session.
     *
     * `order` is which end of the cable `sim` is — 1 or 2 — and the peer takes
     * the other. Not a detail: one `Emulate` call advances the pair together
     * and what it produces depends on the order the two are handed over in, so
     * two windows mirroring each other have to name the same one or they
     * emulate the same cable differently. See `orderedSims` in `vb-worker.ts`.
     */
    setPeer: {
        params: { sim: SimHandle; peer: SimHandle; order?: 1 | 2 };
        result: void
    };

    // --- Inspection ---------------------------------------------------------

    /**
     * Read a rectangle of the composited framebuffer as RGBA bytes.
     *
     * The core always composites eye-packed, so the red channel carries the
     * left eye's brightness and the green channel the right eye's. Reads are
     * from the core's own framebuffer rather than from any canvas, so this works
     * whether or not the simulation is being presented anywhere.
     */
    readPixels: {
        params: { sim: SimHandle; x: number; y: number; width: number; height: number };
        result: ArrayBuffer
    };
    /**
     * Average the framebuffer down to a coarse stereo grid — one RGBA quad per
     * cell. Legacy output carries left/right brightness in R/G; VBC output
     * carries left RGB555 in R/G and right RGB555 in B/A, distinguished by the
     * result's `colorMode` flag.
     *
     * For the immersion halo, which wants a handful of colors rather than a
     * picture. Averaging here rather than on the page keeps the whole frame on
     * this side: a 16x10 grid is 640 bytes where the frame is 344 kB, and the
     * pixels are already in this thread's memory.
     */
    readBackdrop: {
        params: { sim: SimHandle; columns: number; rows: number };
        result: Backdrop
    };
    /** Copy the complete packed frame for a main-thread screenshot renderer. */
    /**
     * Recomposite the picture from the machine's current state and present it,
     * without emulating anything.
     *
     * What a paused machine needs after its video state is edited from outside.
     * The drive loop presents at every frame break, so while a game runs a
     * change to Color RAM is on screen a frame later and nothing has to ask;
     * paused, there is no next frame break, and the last composited image
     * stands however much the state behind it has moved. The color editor is
     * the case in point — a palette written while paused would otherwise not
     * appear until the game was let go.
     *
     * Presentation only: nothing is stepped, no state changes, and a machine
     * that was paused stays exactly as paused as it was. This is the same
     * recompositing a restored save state gets, for the same reason.
     */
    refreshFrame: { params: { sim: SimHandle }; result: void };
    readFrame: {
        params: { sim: SimHandle };
        result: Frame;
    };
    /**
     * Mirror every presented frame to the DOM thread, for a video recording.
     *
     * The picture is composed in this worker and never leaves it, which is
     * what makes it cheap — and what leaves nothing on the page to record:
     * a canvas whose control has been transferred to a worker cannot be
     * captured. So a recording asks for the frames themselves, as the same
     * uncomposited transport buffers `attachCanvas` hands a main-thread
     * renderer, and composes them again on the page into a canvas it owns.
     *
     * A tap is additional: the worker goes on rendering the live picture, and
     * a host that already presents on the DOM thread keeps that pool too. Pass
     * no `tap` to stop; the buffers are dropped with it.
     */
    setVideoTap: {
        params: {
            sim: SimHandle;
            tap?: { presentation: number; buffers: ArrayBuffer[] };
        };
        result: void;
    };
    /** Read a window of the address space as the CPU would see it. */
    readMemory: {
        params: { sim: SimHandle; address: number; length: number };
        result: ArrayBuffer
    };
    /** Write bytes into the address space. The buffer is transferred. */
    writeMemory: {
        params: { sim: SimHandle; address: number; data: ArrayBuffer };
        result: void
    };
    /** Program counter, the 32 program registers, and the system registers. */
    readRegisters: { params: { sim: SimHandle }; result: Registers };
    /**
     * Disassemble instructions starting at an address.
     *
     * `before` asks for the listing to begin that many instructions earlier
     * instead, which is the only exact way to go backwards through code whose
     * instructions are not all the same length: the core walks back through
     * its own decoding rather than guessing at where a boundary is.
     */
    disassemble: {
        params: { sim: SimHandle; address: number; count: number; before?: number };
        result: DisassemblyLine[]
    };
    /**
     * Where the machine should stop, as a complete set of addresses.
     *
     * The whole set rather than one at a time, because the worker keeps no
     * identity for a breakpoint and has nothing to remove by: what is sent is
     * what is armed, and an empty list disarms everything and takes the
     * per-instruction callback back off the core.
     *
     * Costs about a sixth of the emulation it watches while armed — see
     * `tests/breakpoint-probe.mjs`, which is where that figure and the whole
     * shape of this come from. The core reports every instruction before it
     * executes and lets the callback refuse it, so a stop lands on the
     * instruction rather than after it.
     */
    setBreakpoints: { params: { sim: SimHandle; addresses: number[] }; result: void };
    /**
     * Run exactly one instruction and stop on the next.
     *
     * Only useful while suspended, like {@link CoreCommands.stepFrame}, and
     * done the same way: a short burst of clocks driven from here rather than
     * by starting the drive loop, so the machine is stopped throughout and
     * nothing has to be told it briefly ran.
     */
    stepInstruction: { params: { sim: SimHandle }; result: void };
    /**
     * Arm a one-shot stop at an address, for the caller to then run into.
     *
     * Arming and running are separate because starting the machine is the
     * host's business — it owns whether the game is paused, drives the audio
     * and has chrome that says so, and a worker that started itself would put
     * all three out of step. So this only lays the trap; the caller resumes.
     *
     * The stop is gone once it is hit, so running to a line leaves no mark on
     * the gutter for somebody to clear afterwards. This is also how stepping
     * over a call is built: the caller arms the instruction after the call
     * and resumes, which treats the whole call as one step.
     */
    runTo: { params: { sim: SimHandle; address: number }; result: void };
    /**
     * Watch the terminal port for output.
     *
     * Off by default, because capturing means a callback on every CPU write and
     * a game performs a great many of those.
     */
    setTerminalCapture: { params: { sim: SimHandle; enabled: boolean }; result: void };
    /**
     * Watch the link port for bytes clocked out of it, so that a peripheral
     * on the other end of a real cable — a rumble pack — can be driven by an
     * emulated game.
     *
     * Off by default, and for a stronger reason than the panels' captures: it
     * costs the same callback on every CPU write, and nothing is listening
     * unless a physical device is actually plugged in.
     */
    setLinkCapture: { params: { sim: SimHandle; enabled: boolean }; result: void };
    /**
     * Report 32-bit writes to one address, so that a pointer variable can be
     * followed as the program assigns it.
     *
     * One address per simulation, and zero to stop watching. Narrower writes
     * to it are ignored: a pointer is stored whole, and half of one is not a
     * value worth reporting.
     */
    setPointerWatch: { params: { sim: SimHandle; address: number }; result: void };
    /**
     * Repeat a set of writes at every frame break, which is what a cheat is:
     * a value the game keeps changing and the cheat keeps putting back.
     *
     * Applied here rather than by the caller writing on a timer, because a
     * cheat has to land every frame — one message a frame per code would be a
     * great deal of traffic for something the drive loop can do in place. An
     * empty list turns them off.
     */
    setCheats: { params: { sim: SimHandle; codes: VbCheatWrite[] }; result: void };
    /**
     * Book a set of writes against the frame they belong to.
     *
     * The write-side twin of {@link queueKeys}, and it exists for the same
     * reason. `setCheats` and `writeMemory` land whenever their message
     * happens to arrive, which is fine for one machine nobody else is
     * watching and useless for two that have to stay identical: a cheat
     * switched on three frames earlier in one window than in the other is two
     * machines running different games from that moment on, and the digest
     * check would report it as a desync without saying what caused it.
     *
     * So a linked session books the write against a frame number both windows
     * can still reach, and each applies it as that frame comes up — exactly
     * the arrangement that already carries the controller masks.
     *
     * Refused for a frame already emulated, like `queueKeys`: arriving too
     * late is precisely what the session needs to hear about rather than
     * quietly absorb.
     */
    queueEdits: {
        params: { sim: SimHandle; frame: number; edits: ScheduledEdit[] };
        result: void;
    };
    /**
     * Watch the address an ESSound cartridge listens on, so the halfwords a
     * game writes there can be played as audio on this side.
     *
     * Same cost and the same opt-in as the captures above: on only while
     * there is something to play, which means only while the ROM has ESSound
     * files beside it.
     */
    setEsSoundCapture: { params: { sim: SimHandle; enabled: boolean }; result: void };
    /**
     * Watch the cartridge's save region for reads as well as writes, so that
     * what a game does with its save data can be watched as it happens.
     *
     * The only capture here that needs both callbacks: a save is written and
     * then read back, and a list showing only half of that would not say
     * whether a game found what it saved. The core reports instruction
     * fetches separately, so the read callback fires only for real loads.
     *
     * The two directions are asked for separately because they are not alike
     * in cost. A game writes its save when somebody saves; a game may read it
     * on every frame forever, and Wario Land does. Somebody watching for a
     * stray write should not have to pay for that, so writes alone install
     * one callback and leave the other off.
     *
     * Both false is the capture off, which is what a closed panel asks for.
     */
    setSramCapture: {
        params: {
            sim: SimHandle;
            /** Whether writes to the save are reported. */
            writes: boolean;
            /** Whether reads of it are. */
            reads: boolean;
        };
        result: void;
    };
    /**
     * The VSU as it stands: VB_VSU_MAP_BYTES starting at VB_VSU_BASE, holding
     * the waveform banks, the modulation table and the six channel register
     * blocks.
     *
     * Nothing is watched or accumulated for this. The range itself cannot be
     * read — no more on this core than on the machine, see VB_VSU_BASE — so
     * the worker composes the map from the core's own decoded copy of the VSU
     * inside the simulation struct, which is the state itself and not a record
     * of what was asked for. A channel that has been playing since before
     * anybody opened a panel reads as playing, and one the hardware switched
     * off when its interval elapsed reads as off.
     *
     * Where the core holds both what a channel was given and what it is doing
     * — an envelope's level, a swept frequency — what it is doing is what
     * comes back. See `worker/vb-vsu-layout.ts`, which also has to find all of
     * this in the first place, and throws through this call if it cannot.
     */
    readVsu: { params: { sim: SimHandle }; result: VsuReading };
    /**
     * Silence channels in the emulator rather than in the game.
     *
     * `channels` is a bitmask, bit `n` for channel `n`; zero is everything
     * audible again, which is what a closing panel sends. Muting is the
     * mixer's business and not the machine's: the game goes on writing
     * whatever it likes to the VSU, and what it wrote is still what the panel
     * shows — {@link VsuReading} carries a muted channel's stereo levels back
     * even while the machine is playing them at zero.
     *
     * Costs nothing when nothing is muted, and while something is, it is two
     * bytes written per muted channel per frame. Given up when the simulation
     * goes away, so a machine that is reset comes back at full voice.
     */
    setVsuMutes: { params: { sim: SimHandle; channels: number }; result: void };
    /**
     * Watch the Color Framebuffer for writes, so that which palettes are
     * actually painting the picture can be known.
     *
     * The only way to know it. A palette id exists in exactly two places: in
     * the register the colorization's native code picks it into, and — for one store
     * instruction — on the bus on its way to the framebuffer, one byte per
     * pixel (see `VBC_COLOR_FRAMEBUFFER_BASE`). Polling memory answers neither
     * question: Color RAM holds the colors and is written once at reset, so it
     * never changes while a game runs, and the framebuffer keeps whatever was
     * last drawn at a pixel long after that pixel stopped being visible.
     *
     * Off by default, like the captures above and for the same reason: on, it
     * is a call out of the core on every CPU write.
     */
    setDrawnPaletteCapture: { params: { sim: SimHandle; enabled: boolean }; result: void };
    /**
     * Which palettes have painted a pixel since this was last called, and
     * which the picture is painted with right now, as a 256-bit set — 32
     * bytes, palette `id` in bit `id & 7` of byte `id >> 3`.
     *
     * Two sources, because colorizations paint two ways. One whose own code
     * draws into the Color Framebuffer shows up in the write watch, a store
     * per pixel. One that colors through the attribute RAMs never stores a
     * palette id at all: the VIP's drawing process writes the Color Source
     * bytes inside the core, where no bus callback sees them — so the left
     * eye's two framebuffer pages are read back as well, at every pixel the
     * legacy framebuffer does not leave blank.
     *
     * Taking it clears the watched half, which is what makes that half a
     * *window* rather than a running total. All zero if capture is not enabled.
     */
    takeDrawnPalettes: { params: { sim: SimHandle }; result: ArrayBuffer };

    // --- RetroAchievements --------------------------------------------------
    //
    // The achievement engine (rcheevos) runs here in the worker, because
    // evaluating a set means reading the machine's memory synchronously once a
    // frame and only the worker can do that without a message round trip. The
    // DOM side keeps the account, shows the panel, and — since a browser cannot
    // reach the RetroAchievements API and only the desktop shell can — performs
    // every server call on the engine's behalf. See `vb-rcheevos.ts`.

    /**
     * Log in with a username and password, returning the account and the API
     * token to keep in its place. Rejects if the credentials are refused or the
     * engine is unavailable.
     */
    raLoginPassword: { params: { username: string; password: string }; result: VesRaUser };
    /** Log in with a username and a stored API token. Same result and failures. */
    raLoginToken: { params: { username: string; token: string }; result: VesRaUser };
    /** Forget the account. Any loaded game is unloaded with it. */
    raLogout: { params: Record<string, never>; result: void };
    /**
     * Identify the ROM by its RetroAchievements hash (whole-file MD5) and load
     * its set for `sim`.
     *
     * Returns at once: identification and loading are a sequence of server
     * calls the DOM has to service, so the outcome arrives as a
     * `retroAchievements` event (`gameLoaded`, then `achievements`) rather than
     * as this call's result.
     */
    raLoadGame: { params: { sim: SimHandle; hash: string }; result: void };
    /** Unload the current set. The account stays logged in. */
    raUnloadGame: { params: Record<string, never>; result: void };
    /**
     * Hand the engine the answer to a server call it asked for through a
     * `serverCall` event. A status of 0 means the call could not be made.
     */
    raProvideResponse: { params: { requestId: number; status: number; body: string }; result: void };
    /** Tell the engine the machine was reset, so a run in progress is abandoned. */
    raReset: { params: Record<string, never>; result: void };
    /**
     * Turn the engine's hardcore flag on or off.
     *
     * Set before {@link raLoadGame} so a fresh set loads in the right mode;
     * also safe to call mid-session to leave hardcore (rc_client keeps the
     * hardcore unlocks already earned). Entering hardcore mid-session is not
     * done — the host restarts the ROM for that — so this never has to
     * re-arm a set that is already running.
     */
    raSetHardcore: { params: { enabled: boolean }; result: void };
    /**
     * Fetch one page of a leaderboard's entries from RetroAchievements.
     *
     * Unlike {@link raLoadGame} this does resolve with its answer rather than
     * arriving as an event: the panel asks for a specific page and waits for
     * that page, so a promise per request is what the caller wants and the
     * engine can tell one outstanding request from another. Still a sequence
     * of server calls the DOM has to service underneath.
     *
     * `firstEntry` is 1-based and ignored when `aroundUser` is set, which asks
     * instead for the page the signed-in player sits in the middle of.
     */
    raFetchLeaderboardEntries: {
        params: { leaderboardId: number; firstEntry: number; count: number; aroundUser: boolean };
        result: VesRaLeaderboardEntries;
    };
}

/** A logged-in RetroAchievements account, as the worker reports it. */
export interface VesRaUser {
    username: string;
    displayName: string;
    /** The API token to store and log in with next time, never the password. */
    token: string;
    /** Full (hardcore) points. */
    score: number;
    softcoreScore: number;
    /** The account's profile picture, on `media.retroachievements.org`, when it has one. */
    avatarUrl?: string;
}

/** The game a loaded set belongs to. */
export interface RaGame {
    id: number;
    title: string;
    /** A badge to show, on `media.retroachievements.org` (needs no CORS). */
    iconUrl: string;
    achievementCount: number;
    pointsTotal: number;
}

/** One achievement of a loaded set, with the player's progress folded in. */
export interface RaAchievement {
    id: number;
    title: string;
    description: string;
    points: number;
    badgeUrl: string;
    /**
     * `unsupported` is an achievement rcheevos could not compile for this
     * console — shown grayed rather than hidden, so the count still adds up.
     */
    state: 'locked' | 'unlocked' | 'unsupported';
    /** True when it was earned in hardcore, which softcore play never sets. */
    unlockedHardcore: boolean;
    /** rc_client's bucket id, for grouping the list the way the site does. */
    bucket: number;
    /** Set for a measured ("progress") achievement, e.g. "12/50". */
    measured?: { percent: number; display: string };
    /**
     * Undefined for an ordinary achievement — rc_client only calls out the
     * three kinds worth a badge of their own; most of a set is none of them.
     */
    type?: 'missable' | 'progression' | 'win';
    /**
     * The percentage of players who have earned it, in softcore and hardcore
     * — RetroAchievements' own "how rare is this" figure. Undefined for a set
     * too fresh for the site to have computed it yet, which a set VUEPort can
     * actually load essentially never is.
     */
    rarity?: number;
    rarityHardcore?: number;
    /** Unix seconds, set only once this account has actually earned it. */
    unlockTime?: number;
}

/**
 * One of the running game's leaderboards.
 *
 * Present whatever mode the client is in — a leaderboard is part of the set
 * the way an achievement is — but `state` is `inactive` for all of them
 * unless hardcore mode is on, because that is the only mode RetroAchievements
 * runs leaderboards in.
 */
export interface RaLeaderboard {
    id: number;
    title: string;
    description: string;
    /**
     * How to read a value on this board: a duration, a score, or a plain
     * number. Every string the engine hands over is already formatted, so
     * this is only for labeling and sorting, never for formatting.
     */
    format: 'time' | 'score' | 'value';
    /** True for a board where a smaller value ranks higher — a speedrun timer. */
    lowerIsBetter: boolean;
    /**
     * `unsupported` is a leaderboard rcheevos could not compile, the
     * counterpart of the same word on {@link RaAchievement}. `inactive` is
     * the ordinary softcore state; `active` is armed and waiting for its start
     * condition, `tracking` an attempt in progress.
     */
    state: 'inactive' | 'active' | 'tracking' | 'unsupported';
    /** The attempt's running value, set only while `state` is `tracking`. */
    value?: string;
}

/** One row of a leaderboard, as RetroAchievements ranks it. */
export interface VesRaLeaderboardEntry {
    rank: number;
    user: string;
    /** The value, already formatted for this board's `format`. */
    display: string;
    /** Unix seconds. */
    submitted: number;
    /** The player's profile picture, on `media.retroachievements.org`. */
    avatarUrl?: string;
}

/** One page of a leaderboard, the answer to {@link CoreCommands.raFetchLeaderboardEntries}. */
export interface VesRaLeaderboardEntries {
    entries: VesRaLeaderboardEntry[];
    /** How many rows the whole board has, not just this page. */
    total: number;
    /**
     * Where the signed-in player is in `entries`, or -1 when this page does
     * not contain them — the ordinary case for the top of a board they are
     * not near the top of.
     */
    userIndex: number;
}

/** One unsolicited message from the achievement engine. */
export type VesRaEvent =
    /** The engine needs an HTTP call made and the answer fed back with raProvideResponse. */
    | {
        kind: 'serverCall';
        requestId: number;
        method: 'GET' | 'POST';
        url: string;
        body?: string;
        contentType?: string;
    }
    /** Identification finished. `game` is undefined when the ROM is not recognized. */
    | { kind: 'gameLoaded'; game: RaGame | undefined; reason?: string }
    /** The whole set, sent after a load and again whenever progress changes. */
    | { kind: 'achievements'; achievements: RaAchievement[] }
    /** An achievement was just earned. */
    | {
        kind: 'unlocked';
        id: number;
        title: string;
        description: string;
        points: number;
        badgeUrl: string;
        hardcore: boolean;
    }
    /** A "close to earning it" indicator appeared or disappeared. */
    | { kind: 'challengeIndicator'; id: number; show: boolean; badgeUrl: string }
    /** The engine lost or regained the server. */
    | { kind: 'connection'; online: boolean }
    /**
     * The running game's leaderboards, whole. Sent after a set loads, and
     * again whenever a state changes — an attempt starting or ending, or
     * hardcore mode going on or off, which is what activates them at all.
     *
     * `reason` is set only when the list is empty because this build's
     * engine cannot produce one at all, which is a different thing from a
     * game that simply has no leaderboards and worth saying differently.
     */
    | { kind: 'leaderboards'; leaderboards: RaLeaderboard[]; reason?: string }
    /** An attempt on one leaderboard began, was abandoned, or was sent in. */
    | {
        kind: 'leaderboardAttempt';
        id: number;
        title: string;
        description: string;
        state: 'started' | 'failed' | 'submitted';
        /** The value the attempt stood at, for `submitted` in particular. */
        value?: string;
    }
    /**
     * A running attempt's value, for the overlay over the picture.
     *
     * `trackerId` is not a leaderboard id: the engine gives several
     * leaderboards reading the same value one shared tracker, so this is what
     * the overlay keys on. Arrives many times a second while an attempt runs.
     */
    | { kind: 'leaderboardTracker'; trackerId: number; show: boolean; display: string }
    /** What the server made of a submission: the new standing, and the top of the board. */
    | {
        kind: 'leaderboardScoreboard';
        id: number;
        submittedScore: string;
        bestScore: string;
        rank: number;
        total: number;
        topEntries: { rank: number; user: string; score: string }[];
    }
    /** The engine could not start at all — most often, this build ships no rcheevos.wasm. */
    | { kind: 'engineUnavailable'; reason: string };

/** One write a cheat repeats: `bytes` wide, little-endian, like the CPU's. */
export interface VbCheatWrite {
    address: number;
    value: number;
    bytes: number;
}

/**
 * One write booked against a frame by {@link CoreCommands.queueEdits}.
 *
 * Both shapes are things a person does to a running machine from outside it —
 * switching a cheat on, poking a value found in memory — rather than anything
 * the emulated program does. They travel between two linked windows unchanged,
 * so they are kept plain: numbers and arrays, nothing that needs transferring.
 */
export type ScheduledEdit =
    /**
     * Replace the repeated writes, exactly as {@link VbCommands.setCheats}
     * does. The whole list rather than a change to it, because that is what
     * makes it idempotent: a window that applies it twice, or applies it
     * having missed the one before, still ends up where the other window is.
     */
    | { kind: 'cheats'; codes: VbCheatWrite[] }
    /**
     * Write bytes into memory once, as {@link VbCommands.writeMemory} does.
     *
     * `bytes` rather than an ArrayBuffer: a poke is a handful of bytes, and a
     * plain array survives being sent on to the other window without anyone
     * having to think about who owns the buffer.
     */
    | { kind: 'memory'; address: number; bytes: number[] };

export interface Registers {
    pc: number;
    /** r0 to r31. */
    program: number[];
    /** Keyed by the names in VbSystemRegister. */
    system: Record<string, number>;
}

export interface DisassemblyLine {
    address: number;
    /** The instruction's own bytes, two or four of them. */
    code: number[];
    /** Whether the program counter is currently here. */
    isPC: boolean;
    mnemonic: string;
    operands: string[];
}

export type CommandName = keyof CoreCommands;
export type Params<K extends CommandName> = CoreCommands[K]['params'];
export type Result<K extends CommandName> = CoreCommands[K]['result'];

export interface Request<K extends CommandName = CommandName> {
    id: number;
    command: K;
    params: Params<K>;
}

export interface Response {
    id: number;
    result?: unknown;
    error?: string;
}

/** Unsolicited worker to DOM notifications. */
/** How fast emulation is actually running. */
/**
 * One reading of the VSU: its state, and how loud what came out of it was.
 *
 * The map is `VB_VSU_MAP_BYTES` from `VB_VSU_BASE` — the waveform banks, the
 * modulation table and the six channel register blocks, laid out as the
 * hardware's own map so that `emulator-vsu-memory.ts` can decode it without
 * knowing where it came from.
 *
 * The peaks are of the machine's own last buffer of sound, one frame long, and
 * are the only part of this that cannot be worked out from the map: a channel's
 * registers say how loud it was asked to be, and these say what the six of them
 * together actually came to. Before the master volume, because this is the
 * VSU's output and not the emulator's.
 *
 * An object rather than the bare buffer this used to be, so the map is now
 * copied to the DOM thread rather than transferred. It is 1,412 bytes ten
 * times a second, which is not worth a second call to keep transferring.
 */
export interface VsuReading {
    map: ArrayBuffer;
    /** Loudest sample of the last buffer, 0 to 1, per side. */
    peakLeft: number;
    peakRight: number;
}

/**
 * One touch of the cartridge's save region.
 *
 * Byte-wide: Game Pak RAM sits on the low half of the bus, so a real cartridge
 * only ever carries one byte per access however wide the instruction was. The
 * width is kept anyway — a game storing a halfword into save RAM is doing
 * something worth seeing, and the panel can only show it if it is recorded.
 */
export interface SramAccess {
    /** Where, as the bus saw it — inside the region, not an offset into it. */
    address: number;
    /** The byte that crossed the bus, read or written. */
    value: number;
    /** True for a write, false for a read. */
    write: boolean;
    /** The instruction's width, as VbDataType spells it. */
    type: number;
    /** The instruction that did it, for saying which code touched the save. */
    pc: number;
}

/**
 * A run of touches one instruction made over one stretch of the save.
 *
 * What actually crosses the wire, rather than {@link SramAccess} itself. A
 * game saving does it in a loop, and a loop is one instruction walking an
 * address: sending that as eight thousand little objects a tick costs more in
 * structured cloning than the emulation it is watching, which is exactly what
 * a game that reads its save every frame — Wario Land does — turns into a
 * stalled interface. So the run is gathered in the worker, where the accesses
 * already are, and arrives as one object and a byte array.
 *
 * Nothing is lost by it: every byte is still here, and where each one went is
 * {@link address} plus its index times {@link stride}.
 */
export interface SramRun {
    /** Where the first touch landed, as the bus saw it. */
    address: number;
    /**
     * How far apart consecutive touches were, which is 2 for a loop walking
     * the save — only the low byte of each halfword is wired to the chip.
     * Zero for an instruction touching one address over and over, and 0 for a
     * run of one, where it says nothing either way.
     */
    stride: number;
    /** The bytes that crossed the bus, in the order they did. */
    values: Uint8Array;
    /** True for writes, false for reads; a run is never a mix of the two. */
    write: boolean;
    /** The instruction's width, as VbDataType spells it. */
    type: number;
    /** The instruction that did it, for saying which code touched the save. */
    pc: number;
}

/**
 * How many runs the worker holds between flushes.
 *
 * Runs rather than accesses, so this is a cap on how many *different* things
 * a tick may have done to the save rather than on how much of it was touched:
 * a game writing its whole save in one sweep is one of them. A batch that
 * arrives full is a batch that was cut short, and the panel says so — which is
 * the only reason the number is here rather than in the worker alone.
 */
export const MAX_SRAM_RUNS = 512;

/** How many bytes one run may gather before the next starts. */
export const MAX_SRAM_RUN_BYTES = 8192;

/**
 * How far apart two touches may be and still belong to one run.
 *
 * Wide enough for a loop walking the save in halfwords or words, and for one
 * running backwards; anything further apart is a second thing happening.
 */
export const MAX_SRAM_STRIDE = 4;

export interface Speed {
    /** Emulated frames a second, against the machine's own VB_FRAME_RATE. */
    framesPerSecond: number;
    /** That rate as a multiple of real time, so 1 is full speed. */
    ratio: number;
    /** The speed being attempted, after any clamp to what is affordable. */
    requested: number;
}

export interface Events {
    /** The worker hit an error outside of a command, e.g. in the drive loop. */
    error: { message: string };
    /** A packed frame for the main-thread renderer. Its buffer is returned after upload. */
    frame: VideoFrame;
    /**
     * Text a simulation wrote to the terminal port, batched rather than sent a
     * byte at a time. Newlines are left in, so a consumer splits on them.
     */
    terminal: { sim: SimHandle; text: string };
    /**
     * Bytes a simulation clocked out of the link port, in the order they were
     * sent and batched the same way terminal output is.
     */
    link: { sim: SimHandle; bytes: number[] };
    /** Values written to the address setPointerWatch is following. */
    pointerWrite: { sim: SimHandle; address: number; values: number[] };
    /**
     * Halfwords a simulation wrote to the ESSound port, in the order it wrote
     * them and batched the same way link bytes are.
     */
    esSound: { sim: SimHandle; commands: number[] };
    /**
     * Accesses to the cartridge's save region, oldest first, batched the same
     * way link bytes are.
     */
    sram: { sim: SimHandle; runs: SramRun[] };
    /**
     * How fast emulation is actually running, sampled about once a second.
     *
     * Reported rather than derived from the requested speed because the two
     * part company: a fast forward ratio the machine cannot sustain is clamped
     * to what fits, so only the worker knows what is really being achieved.
     */
    speed: Speed;
    /**
     * Messages from the achievement engine, batched and flushed on the drive
     * loop's own path the same way terminal and link output are.
     */
    retroAchievements: { events: VesRaEvent[] };
    /**
     * A digest taken at a frame boundary, because
     * {@link CoreCommands.setDigestPeriod} asked for it.
     */
    digest: { sim: SimHandle; frame: number; digest: number };
    /**
     * How far the machine has got, while something is booking input for it.
     *
     * A session that keeps a schedule ahead of the drive loop has to know
     * where the loop actually is, and neither of the other two accounts of
     * that will do: `speed` reports about once a second, far too coarse to
     * schedule against, and `awaitingInput` only fires once the schedule has
     * already run dry. So this reports every few frames, and only while a
     * simulation is under {@link CoreCommands.setLockstep} — a solo emulator
     * has nobody to tell and sends nothing.
     */
    progress: { frame: number };
    /**
     * The drive loop is holding for input it has not been given, or has
     * stopped holding.
     *
     * Only ever fired for a simulation under {@link CoreCommands.setLockstep};
     * see {@link CoreCommands.queueKeys} for why it holds at all. Fired on
     * the change rather than per frame, so a listener can show and clear a
     * "waiting for the other player" state without being flooded.
     */
    awaitingInput: {
        waiting: boolean;
        /** The frame the loop is stopped at. */
        frame: number;
        /** Which simulations have nothing booked for it. Empty when resuming. */
        sims: SimHandle[];
    };
    /**
     * The core stopped advancing, and emulation was suspended.
     *
     * Not an {@link Events.error}: nothing threw and nothing is wrong
     * with the emulator. The core can reach a state where it returns from
     * `Emulate` without spending any of the clock budget it was given, over
     * and over — a program that has run off into memory it cannot execute
     * does it. The loops that drain that budget have no other stopping
     * condition, so the drive loop gives up rather than spinning for ever and
     * taking the whole worker with it.
     *
     * A reset is the way out, which is why this is a event of its own: the
     * chrome can say so, where a generic error could only apologize.
     */
    stalled: {
        /** Frames emulated before it stopped, the same count `speed` carries. */
        frames: number;
    };
    /**
     * The machine stopped on an instruction, and emulation was suspended.
     *
     * Suspended by the worker rather than asked for by the host, which is the
     * whole point of a breakpoint — so the host has to hear about it, or its
     * own idea of whether the game is running would part company with the
     * game. The address is where the machine is now, and that instruction has
     * not been executed yet.
     */
    stopped: {
        sim: SimHandle;
        address: number;
        reason: StopReason;
    };
}

/** Why {@link Events.stopped} fired. */
export enum StopReason {
    /** An address in the armed set was reached. */
    BREAKPOINT = 'breakpoint',
    /** One instruction was asked for and has been run. */
    STEP = 'step',
    /** The machine was told to run to one address and got there. */
    CURSOR = 'cursor',
}

/**
 * One event and its payload.
 *
 * Written as a distributed union rather than a generic interface so that
 * checking `event` narrows `payload` to the matching type.
 */
export type VbEvent = {
    [K in keyof Events]: { event: K; payload: Events[K] }
}[keyof Events];

export type Outbound = Response | VbEvent;

export function isVbEvent(message: Outbound): message is VbEvent {
    return 'event' in message;
}

/** The first message the worker receives, carrying the audio worklet's port. */
export interface Bootstrap {
    audioPort: MessagePort;
}

/**
 * One-way DOM-to-worker message returning a reusable video transfer buffer.
 *
 * Carries the `presentation` the buffer arrived under, which is what tells a
 * main-thread renderer's pool from a recording tap's — see `setVideoTap`.
 */
export interface VideoFrameReturn {
    videoFrame: {
        sim: SimHandle;
        presentation: number;
        pixels: ArrayBuffer;
    };
}
