/**
 * Something read once and kept — unless the read could not answer.
 *
 * The distinction this exists for is between "there is nothing there" and "I
 * could not tell". Both come back as no value, and a cache that treats them
 * alike remembers a passing problem as a fact: the emulator's symbol table is
 * read from a `.elf` beside the ROM, and a read that happened while the build
 * was still writing that file, or before the workspace had resolved, used to
 * leave every feature built on symbols reporting there were none for as long
 * as the ROM was open.
 *
 * So a read says which it was. An answer is kept for good; a failure to answer
 * is forgotten, and the next asker tries again — but not immediately, because
 * the things that ask tend to ask on a timer and the thing being read tends to
 * be large.
 */

/** What a read concluded. `settled` means this is the answer, not a stumble. */
export interface CachedAnswerRead<T> {
    value?: T;
    settled: boolean;
}

export class CachedAnswer<T> {

    /** The answer, or a read still in flight. */
    protected pending: Promise<T | undefined> | undefined;
    /** When a read that could not answer may be tried again. */
    protected retryAfter = 0;

    constructor(
        protected readonly read: () => Promise<CachedAnswerRead<T>>,
        /** How long to wait before retrying a read that could not answer. */
        protected readonly retryDelay: number,
        /** The clock, so a test does not have to wait out the delay. */
        protected readonly now: () => number = () => Date.now(),
    ) { }

    /**
     * The answer, reading it if this is the first ask.
     *
     * Concurrent askers share one read: the promise is what is kept, not the
     * result, so a second ask arriving mid-read waits on the first rather than
     * starting another.
     */
    get(): Promise<T | undefined> {
        if (this.pending) {
            return this.pending;
        }
        if (this.now() < this.retryAfter) {
            return Promise.resolve(undefined);
        }

        const attempt: Promise<T | undefined> = this.read().then(
            outcome => {
                if (!outcome.settled) {
                    this.forget(attempt);
                }
                return outcome.value;
            },
            error => {
                // A read that threw is the plainest kind of "could not tell".
                this.forget(attempt);
                throw error;
            },
        );
        this.pending = attempt;
        return attempt;
    }

    /** Whether an answer is being held — as opposed to none having been read. */
    get isAnswered(): boolean {
        return this.pending !== undefined;
    }

    /** Throw away whatever is held, and any wait before the next attempt. */
    clear(): void {
        this.pending = undefined;
        this.retryAfter = 0;
    }

    /**
     * Drop a read that could not answer, and hold off the next one.
     *
     * Only if it is still the current read: a `clear` while it was in flight
     * means something has moved on, and this must not undo that.
     */
    protected forget(attempt: Promise<T | undefined>): void {
        if (this.pending !== attempt) {
            return;
        }
        this.pending = undefined;
        this.retryAfter = this.now() + this.retryDelay;
    }
}
