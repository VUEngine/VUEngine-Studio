// a value read once and kept, unless the read could not tell. A failed read (e.g. the symbol `.elf` read while
// the build was still writing it) used to be cached as "no symbols" for as long as the ROM was open, so
// failures are forgotten and retried after a delay, as askers tend to poll and reads tend to be large

// `settled` means this is the answer, not a stumble
export interface CachedAnswerRead<T> {
    value?: T;
    settled: boolean;
}

export class CachedAnswer<T> {

    // the answer, or a read still in flight
    protected pending: Promise<T | undefined> | undefined;
    // when a read that could not answer may be tried again
    protected retryAfter = 0;

    constructor(
        protected readonly read: () => Promise<CachedAnswerRead<T>>,
        protected readonly retryDelay: number,
        // injectable, so a test does not have to wait out the delay
        protected readonly now: () => number = () => Date.now(),
    ) { }

    // concurrent askers share one read, as the promise is kept rather than the result
    get(): Promise<T | undefined> {
        if (this.pending) {
            return this.pending;
        }
        if (this.now() < this.retryAfter) {
            return Promise.resolve(undefined);
        }

        const attempt: Promise<T | undefined> = this.read().then(
            outcome => {
                if (!outcome.settled) {
                    this.forget(attempt);
                }
                return outcome.value;
            },
            error => {
                // a read that threw is the plainest kind of "could not tell"
                this.forget(attempt);
                throw error;
            },
        );
        this.pending = attempt;
        return attempt;
    }

    // as opposed to none having been read
    get isAnswered(): boolean {
        return this.pending !== undefined;
    }

    // also drops any wait before the next attempt
    clear(): void {
        this.pending = undefined;
        this.retryAfter = 0;
    }

    // only if it is still the current read, as a `clear` in the meantime must not be undone
    protected forget(attempt: Promise<T | undefined>): void {
        if (this.pending !== attempt) {
            return;
        }
        this.pending = undefined;
        this.retryAfter = this.now() + this.retryDelay;
    }
}
