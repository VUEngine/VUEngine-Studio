/**
 * Profiling a game while it is being played, rather than replaying it after.
 *
 * `VesProfileCollector` next door answers "where did the last thirty seconds
 * go", exhaustively, from a recording — which is the right shape for a report
 * and the wrong one for a panel: nothing is on screen until the run is over
 * and replayed. This answers "where is *this frame* going", every frame, while
 * the game runs, so the number moves when the developer changes something.
 *
 * Three measurements decided that this is affordable, all of them taken
 * against the vendored core rather than assumed:
 *
 * - An execute callback costs 1.03x with nothing in it and 1.17x with a set
 *   lookup per instruction (`tests/breakpoint-probe.mjs`). The core runs about
 *   five times faster than the machine it emulates, so there is room.
 * - The clock budget `Emulate` is given is decremented *as it runs* and can be
 *   read from inside the callback: 398, 391, 386, 381 over the first four
 *   instructions of a boot. So each instruction's cost is knowable to the
 *   clock, and time here is real time rather than an instruction count
 *   standing in for it.
 * - `halt` parks the processor and lets the clock run on, which is what makes
 *   an idle figure measurable without knowing what the game's wait loop looks
 *   like — see {@link VesInstructionKind.HALT}. Most games do not halt, and
 *   {@link VesLiveProfileCollector.harvestWait} is what finds the rest: a loop
 *   that was still going round when the interrupt arrived was waiting for it.
 *
 * Nothing here runs the machine or knows what a function is called. The worker
 * feeds it program counters and clocks; the panel puts names to the addresses
 * with the build's symbols. Both ends stay ignorant of the other.
 */

import { VesInstructionKind } from './emulator-profile';
import { VB_INTERRUPT_VECTOR_BASE, VbInterrupt } from './vb-constants';

/**
 * The address a frame's own time is charged to when nothing called it.
 *
 * Profiling starts in the middle of a game, several calls deep in a stack that
 * was built before anything was watching. Those frames cannot be named — they
 * were entered before the first callback — so their time collects here, under
 * one row the panel labels for what it is. It shrinks to the current function
 * within a call or two and never goes away entirely, since the game's own main
 * loop is one of the frames that was already open.
 *
 * Zero rather than a negative sentinel because every other address travels as
 * an unsigned 32-bit number, and the Virtual Boy executes nothing at zero: the
 * bottom of the map is the VIP's register window. A program that has run off
 * into it would land in this row, which is as good a place as any for it.
 */
export const VES_LIVE_PROFILE_ROOT = 0;

/**
 * Where the Virtual Boy's interrupt vectors live.
 *
 * Hardware enters a handler by jumping here, without a call, so the shadow
 * stack sees the program counter leap somewhere it has no frame for. Left
 * alone, everything the handler does is charged to whatever the game happened
 * to be executing when the interrupt arrived — and on a VUEngine game a good
 * part of the frame's work is in the VIP handler, so that is not a rounding
 * error but the wrong answer. Arriving at one of them opens a frame of its own,
 * which `reti` closes.
 *
 * At one of them, not anywhere in the range: the table is code, sixteen bytes
 * per level, and the handler stub's own instructions are inside it. Treating
 * every address in the range as an entry pushed a frame per instruction of the
 * stub and left them open, since only one `reti` ever came back — which the
 * probe caught as a stack that grew a level per instruction.
 */
const VECTOR_BASE = VB_INTERRUPT_VECTOR_BASE;
const VECTOR_STRIDE = 0x10;
const VECTOR_END = VECTOR_BASE + (VbInterrupt.VPU + 1) * VECTOR_STRIDE;
/** Hardware only ever jumps to the start of one, so only a start is an entry. */
const VECTOR_STRIDE_MASK = VECTOR_STRIDE - 1;

/** Where the machine begins, and begins again — see `VesProfileCollector`. */
const RESET_VECTOR = 0xfffffff0;

/** How deep the shadow stack may get before it stops pushing. */
const MAX_DEPTH = 256;

/**
 * How far a stretch of instructions may range and still be one loop.
 *
 * A wait is a handful of instructions going round: `while(!flag);` compiles to
 * a load, a compare and a branch. The span is what separates that from a
 * function working its way through a page of code, and it is generous on
 * purpose — a loop with a little unrolling in it is still a loop, while a
 * program getting on with something moves further than this within a few
 * instructions.
 */
const QUIET_SPAN = 256;

/**
 * How long a quiet stretch has to run before it is called waiting.
 *
 * A hundred microseconds, which is half a percent of a frame and some seven
 * hundred instructions of going round in circles. A real wait is tens of
 * thousands of clocks — a frame is four hundred thousand — so the threshold
 * costs nothing to find one, and what it buys is that a short loop an
 * interrupt happened to land in stays charged as the work it probably was.
 */
const MIN_WAIT_CLOCKS = 2000;

/**
 * How often a loop may write and still be a loop that is waiting.
 *
 * Writing nothing at all would be the clean test, and it is the wrong one:
 * VUEngine's frame loop stores a byte on every pass, and a loop polling a
 * controller has to write to the hardware to read it. What separates those
 * from a copy is how *dense* the writing is — a `memcpy` stores on one
 * instruction in three, a wait on one in a dozen or not at all. One in six is
 * the line, which no wait loop seen here comes near and no copy loop stays
 * under.
 */
const QUIET_STORE_RATIO = 6;

/** One function's share of one frame, as the collector accumulates it. */
interface LiveRow {
    address: number;
    /** Clocks spent in this function itself, this frame. */
    self: number;
    /** Clocks spent in it and everything it called, this frame. */
    total: number;
    /** Times it was entered this frame. */
    calls: number;
    /** Whether it has been touched since the last frame was closed. */
    touched: boolean;
}

/** What one function did over the window a snapshot covers. */
export interface LiveProfileFunction {
    /** Where the function starts, as the machine reports the program counter. */
    address: number;
    /** Clocks in the function itself, in the most recent frame. */
    self: number;
    selfAvg: number;
    selfPeak: number;
    /** Clocks in it and everything it called, in the most recent frame. */
    total: number;
    totalAvg: number;
    totalPeak: number;
    /** The cheapest frame it appeared in at all, which is not the same as zero. */
    totalMin: number;
    /** Times it was entered in the most recent frame. */
    calls: number;
    callsAvg: number;
    /** Frames of the window it ran in at all, which is what the averages divide by. */
    frames: number;
}

/** What one function did in one frame, with nothing of the window in it. */
export interface LiveProfileFrameFunction {
    address: number;
    /** Clocks in the function itself. */
    self: number;
    /** Clocks in it and everything it called. */
    total: number;
    /** Times it was entered. */
    calls: number;
}

/**
 * One finished frame, as it was recorded.
 *
 * The window's averages answer "what does a frame cost here". This answers
 * "what was in *that* frame", which is the question a spike raises and the one
 * an average is least able to answer — a frame that overran by half is one
 * frame in a hundred, and the mean moves by half a percent.
 *
 * Only ever readable while the frame is still in the window, which is a couple
 * of seconds of play, so whoever wants to keep one keeps the answer rather
 * than the number.
 */
export interface LiveProfileFrame {
    /** Which frame this is, counted from when profiling began. The first is 1. */
    number: number;
    /**
     * Clocks accounted for, of which `halted` were spent with the processor
     * stopped and `waited` going round a loop until an interrupt came.
     */
    clocks: number;
    halted: number;
    waited: number;
    /** Where the longest wait of the frame was, or 0 if it had none. */
    waitAt: number;
    instructions: number;
    functions: LiveProfileFrameFunction[];
}

/** Everything the panel draws one refresh from. */
export interface LiveProfileSnapshot {
    /** Frames these figures were taken over. Zero means nothing has run yet. */
    frames: number;
    /** Frames profiled since it was switched on, for a panel that wants to say. */
    framesSeen: number;
    /** Clocks in a frame at the machine's own rate — what a share is a share of. */
    frameClocks: number;
    /** Clocks accounted for in the most recent frame. */
    clocks: number;
    clocksAvg: number;
    clocksPeak: number;
    /** Of those, clocks the processor spent halted rather than working. */
    halted: number;
    haltedAvg: number;
    haltedPeak: number;
    /**
     * And clocks spent going round a loop until an interrupt arrived, which is
     * how most games wait — see {@link VesLiveProfileCollector.harvestWait}.
     * Waiting is not work, so the busy figure is the frame less both of these.
     */
    waiting: number;
    waitingAvg: number;
    waitingPeak: number;
    /** Where the most recent frame's longest wait was, or 0 if it had none. */
    waitingAt: number;
    /** Instructions retired, which says how much work the clocks bought. */
    instructions: number;
    instructionsAvg: number;
    /**
     * Busy clocks — everything the frame was not idling — for each frame of
     * the window, oldest first.
     *
     * The shape of the window, which no average beside it can show: a frame
     * that overran is one bar above the budget, and dividing it by a hundred
     * good ones is exactly what hides it. The newest of these is the frame
     * numbered {@link framesSeen}.
     */
    frameBusy: number[];
    /** The frame a reader asked for by number, if it is still in the window. */
    pinned?: LiveProfileFrame;
    functions: LiveProfileFunction[];
    /** Machine restarts seen, which end every frame that was open. */
    resets: number;
    /** Calls dropped for depth, which should be zero on anything sane. */
    overflows: number;
}

/**
 * One frame, flattened.
 *
 * Four numbers per function — address, self, total, calls — in one typed array
 * rather than a map of objects, because a window is a hundred of these and
 * they are only ever written once and read in bulk. A frame's own totals ride
 * alongside in {@link VesLiveFrame}.
 */
type VesLiveFrameRows = Int32Array;

interface VesLiveFrame {
    rows: VesLiveFrameRows;
    clocks: number;
    halted: number;
    /** Clocks spent in a loop that was waiting for an interrupt. */
    waited: number;
    /** Where the longest of those waits was, or 0 if there was none. */
    waitAt: number;
    instructions: number;
}

/**
 * Turns a running game's program counters into a per-frame profile.
 *
 * Feed it every instruction in order, along with what the *previous* one cost
 * — the callback fires before an instruction executes, so its price is only
 * known when the next one arrives — and close each frame as the machine
 * reaches it. It keeps a shadow stack exactly as the replay collector does,
 * charging clocks to whichever frame is on top, and hands back a window of
 * finished frames on demand.
 */
export class VesLiveProfileCollector {

    /** Every function seen since profiling began, by address. */
    protected readonly rows = new Map<number, LiveRow>();
    /**
     * Rows written since the last frame was closed.
     *
     * The map is kept across frames — the set of functions a game runs settles
     * within a second, and rebuilding it fifty times a second would allocate
     * for no reason — so something has to say which of its rows this frame
     * actually touched. This is that, and it is also what gets zeroed.
     */
    protected readonly touched: LiveRow[] = [];

    // The shadow stack, as parallel arrays: one object per frame per level
    // would be an allocation on every call the game makes.
    protected readonly stackRow: LiveRow[] = [];
    protected readonly stackReturn: number[] = [];
    protected readonly stackEnter: number[] = [];
    /**
     * Whether each level is the outermost activation of its function.
     *
     * Inclusive time is only counted for the outermost one: a recursive
     * function is inside itself, and adding every level's span would count the
     * same clocks once per level and report more time than the frame has.
     */
    protected readonly stackOutermost: boolean[] = [];
    /** How many activations of each function are on the stack right now. */
    protected readonly active = new Map<number, number>();

    /** Monotonic clock since profiling began, which every span is measured on. */
    protected cycle = 0;
    /** Set by a call, resolved on the next instruction — see `VesProfileCollector`. */
    protected pendingReturn = -1;
    /**
     * Whether the instruction whose cost is about to arrive was a `halt`.
     *
     * Its clocks are the machine waiting rather than the function working, and
     * they are what the CPU load figure is measured against, so they are
     * charged to the frame's idle total instead of to the function the `halt`
     * happens to sit in.
     */
    protected halting = false;

    /**
     * The row a quiet stretch is running in, and where it began.
     *
     * A "quiet" stretch is execution that writes nothing, calls nothing and
     * stays within {@link QUIET_SPAN} bytes — which is what a program looks
     * like when it has finished and is waiting for the next interrupt. It is
     * only *called* waiting once something ends it that nothing else could
     * have: see {@link harvestWait}.
     */
    protected quietRow?: LiveRow;
    protected quietSince = 0;
    protected quietLow = 0;
    protected quietHigh = 0;
    /** Instructions in the stretch, and how many of them wrote. */
    protected quietSteps = 0;
    protected quietStores = 0;

    protected frameClocksSpent = 0;
    protected frameHalted = 0;
    protected frameWaited = 0;
    protected frameWaitTop = 0;
    protected frameWaitAt = 0;
    protected frameInstructions = 0;

    protected resets = 0;
    protected overflowed = 0;
    protected framesSeen = 0;

    /** The window of finished frames, oldest first, capped at `capacity`. */
    protected readonly frames: VesLiveFrame[] = [];

    /**
     * @param capacity how many frames the window holds. Two seconds of play is
     *     enough for a peak to be a peak rather than a hiccup, and short
     *     enough that a change made in the game is visible in the averages
     *     within a moment of making it.
     */
    constructor(protected readonly capacity: number) {
        // The frame everything that was already running is charged to.
        this.push(VES_LIVE_PROFILE_ROOT, false);
    }

    /**
     * Charge an instruction, and follow it if it enters or leaves a frame.
     *
     * The hot path of the whole feature: this runs once per emulated
     * instruction, twenty million times a second of play, so it does its own
     * bookkeeping rather than calling out to anything.
     *
     * @param address where the instruction about to run is
     * @param kind what it does, from the ROM's decoded table
     * @param clocks what the *previous* instruction cost
     */
    step(address: number, kind: VesInstructionKind, clocks: number): void {
        this.charge(clocks);
        this.halting = kind === VesInstructionKind.HALT;
        this.frameInstructions++;

        if (address === RESET_VECTOR) {
            // Everything that was running is gone: a reset is not a return and
            // nothing below it will come back. Close the open frames rather
            // than dropping them, so their time is not lost from the frame.
            this.unwind(1);
            this.pendingReturn = -1;
            this.resets++;
        }

        if (this.pendingReturn >= 0) {
            this.push(address, false, this.pendingReturn);
            this.pendingReturn = -1;
        } else if (address >= VECTOR_BASE && address < VECTOR_END
            && (address & VECTOR_STRIDE_MASK) === 0) {
            // An interrupt. Nothing called it, so there is no return address to
            // wait for; `reti` is what closes it.
            //
            // Also the moment a wait is proved to have been one: whatever was
            // going round in circles was still going round when the interrupt
            // it could only have been waiting for arrived.
            this.harvestWait();
            this.push(address, true);
        } else {
            this.unwindTo(address);
        }

        if (kind === VesInstructionKind.CALL) {
            // JAL is two halfwords, so this is the instruction after it.
            this.pendingReturn = (address + 4) >>> 0;
        } else if (kind === VesInstructionKind.RETI) {
            this.leaveInterrupt();
        }

        // Is the program still going round in circles? Calling something,
        // halting, leaving the neighbourhood or writing hard enough to be
        // copying all say it is not, and the count starts again from here.
        const row = this.stackRow[this.stackRow.length - 1];
        const low = address < this.quietLow ? address : this.quietLow;
        const high = address > this.quietHigh ? address : this.quietHigh;
        const stores = kind === VesInstructionKind.STORE
            ? this.quietStores + 1
            : this.quietStores;
        if (row !== this.quietRow
            || kind === VesInstructionKind.CALL
            || kind === VesInstructionKind.HALT
            || high - low > QUIET_SPAN
            || stores * QUIET_STORE_RATIO > this.quietSteps) {
            this.quietRow = row;
            this.quietSince = this.cycle;
            this.quietLow = address;
            this.quietHigh = address;
            this.quietSteps = 1;
            this.quietStores = kind === VesInstructionKind.STORE ? 1 : 0;
        } else {
            this.quietLow = low;
            this.quietHigh = high;
            this.quietSteps++;
            this.quietStores = stores;
        }
    }

    /**
     * Charge a finished wait to the frame rather than to the code it was in.
     *
     * Called where a quiet stretch has been ended by something outside the
     * program — an interrupt, or the frame boundary itself — and nowhere else.
     * That is the whole test. A loop that finishes on its own was doing
     * something, however little it wrote; a loop that was still going when the
     * interrupt arrived was waiting for it, which is the same thing `halt`
     * says in one instruction and which most Virtual Boy games say by spinning
     * instead — VUEngine's frame loop is a bare `while(!hasGameFrameStarted())`.
     *
     * The clocks have already been charged to the function the loop is in, so
     * they are taken back out of it: a wait is not work, and a table that
     * shows the engine's idle loop as the most expensive thing in the frame is
     * a table nobody can read a frame's cost off.
     */
    protected harvestWait(): void {
        const row = this.quietRow;
        if (row === undefined) {
            return;
        }
        const waited = this.cycle - this.quietSince;
        this.quietSince = this.cycle;
        if (waited < MIN_WAIT_CLOCKS) {
            return;
        }
        // Never more than the row was charged this frame, so that the rows,
        // the idling and the waiting still add up to exactly the frame.
        const taken = Math.min(waited, row.self);
        if (taken <= 0) {
            return;
        }
        row.self -= taken;
        this.frameWaited += taken;
        if (taken > this.frameWaitTop) {
            this.frameWaitTop = taken;
            this.frameWaitAt = row.address;
        }
        if (!row.touched) {
            row.touched = true;
            this.touched.push(row);
        }
    }

    /**
     * Charge clocks to whatever is running, and to the idle total if that is
     * a `halt`.
     *
     * Every clock the machine spends passes through here exactly once, which
     * is what lets a frame's rows plus its idle time add up to the frame — see
     * the accounting check in `tests/live-profile-probe.mjs`.
     */
    protected charge(clocks: number): void {
        if (clocks <= 0) {
            return;
        }
        this.cycle += clocks;
        this.frameClocksSpent += clocks;
        if (this.halting) {
            this.frameHalted += clocks;
            // Already idle, and never charged to a row — so they are not a
            // quiet stretch's to claim a second time.
            this.quietSince = this.cycle;
            return;
        }
        const row = this.stackRow[this.stackRow.length - 1];
        row.self += clocks;
        if (!row.touched) {
            row.touched = true;
            this.touched.push(row);
        }
    }

    /**
     * Close the frame the machine has just finished and start the next.
     *
     * Called when the core reports a frame break, so the figures are per
     * displayed frame — the same boundary the game's own work is bounded by —
     * rather than per audio buffer, which is the same length but not the same
     * moment.
     *
     * @param spent what the instruction now executing has run up so far. The
     *     callback only ever learns an instruction's cost when the next one
     *     arrives, and the instruction a frame ends inside is very often a
     *     `halt` waiting for the very interrupt that ends it — which would
     *     otherwise charge a frame's worth of idling to the frame after, and
     *     leave a game that spends most of its time waiting reporting almost
     *     nothing at all.
     */
    endFrame(spent = 0): void {
        this.charge(spent);
        // The frame boundary is the other thing a program cannot have ended a
        // loop with itself: a game that is still going round when the picture
        // it was waiting for arrives was waiting for it.
        this.harvestWait();
        // Frames still open have been running for part of this frame and will
        // go on running into the next: `main` and the game loop never return.
        // Settling them here is what lets a function that spans the boundary
        // report the share of *this* frame it took, rather than nothing at all
        // until the day it finally returns.
        for (let depth = 1; depth < this.stackRow.length; depth++) {
            if (this.stackOutermost[depth]) {
                const row = this.stackRow[depth];
                row.total += this.cycle - this.stackEnter[depth];
                this.stackEnter[depth] = this.cycle;
                if (!row.touched) {
                    row.touched = true;
                    this.touched.push(row);
                }
            }
        }

        const rows = new Int32Array(this.touched.length * 4);
        for (let at = 0; at < this.touched.length; at++) {
            const row = this.touched[at];
            const base = at * 4;
            rows[base] = row.address;
            rows[base + 1] = row.self;
            rows[base + 2] = row.total;
            rows[base + 3] = row.calls;
            row.self = 0;
            row.total = 0;
            row.calls = 0;
            row.touched = false;
        }
        this.touched.length = 0;

        if (this.frames.length >= this.capacity) {
            this.frames.shift();
        }
        this.frames.push({
            rows,
            clocks: this.frameClocksSpent,
            halted: this.frameHalted,
            waited: this.frameWaited,
            waitAt: this.frameWaitAt,
            instructions: this.frameInstructions,
        });
        this.framesSeen++;
        this.frameClocksSpent = 0;
        this.frameHalted = 0;
        this.frameWaited = 0;
        this.frameWaitTop = 0;
        this.frameWaitAt = 0;
        this.frameInstructions = 0;
    }

    /**
     * The window as one set of figures.
     *
     * Aggregated on the way out rather than as frames arrive, because the
     * window is read a handful of times a second and written fifty: whatever
     * work can wait for a reader should.
     */
    snapshot(frameClocks: number, pin?: number): LiveProfileSnapshot {
        const functions = new Map<number, LiveProfileFunction>();
        const last = this.frames.length - 1;
        const frameBusy: number[] = [];
        let clocksTotal = 0;
        let clocksPeak = 0;
        let haltedTotal = 0;
        let haltedPeak = 0;
        let waitedTotal = 0;
        let waitedPeak = 0;
        let instructionsTotal = 0;

        for (let index = 0; index < this.frames.length; index++) {
            const frame = this.frames[index];
            frameBusy.push(frame.clocks - frame.halted - frame.waited);
            clocksTotal += frame.clocks;
            clocksPeak = Math.max(clocksPeak, frame.clocks);
            haltedTotal += frame.halted;
            haltedPeak = Math.max(haltedPeak, frame.halted);
            waitedTotal += frame.waited;
            waitedPeak = Math.max(waitedPeak, frame.waited);
            instructionsTotal += frame.instructions;

            const { rows } = frame;
            for (let at = 0; at < rows.length; at += 4) {
                // Written through an Int32Array, so anything in the ROM's
                // mirror at the top of memory comes back negative.
                const address = rows[at] >>> 0;
                const self = rows[at + 1];
                const total = rows[at + 2];
                const calls = rows[at + 3];
                let entry = functions.get(address);
                if (!entry) {
                    entry = {
                        address,
                        self: 0, selfAvg: 0, selfPeak: 0,
                        total: 0, totalAvg: 0, totalPeak: 0, totalMin: Number.MAX_SAFE_INTEGER,
                        calls: 0, callsAvg: 0, frames: 0,
                    };
                    functions.set(address, entry);
                }
                // The averages hold sums until the pass is over.
                entry.selfAvg += self;
                entry.callsAvg += calls;
                entry.totalAvg += total;
                entry.selfPeak = Math.max(entry.selfPeak, self);
                entry.totalPeak = Math.max(entry.totalPeak, total);
                entry.totalMin = Math.min(entry.totalMin, total);
                entry.frames++;
                if (index === last) {
                    entry.self = self;
                    entry.total = total;
                    entry.calls = calls;
                }
            }
        }

        const count = this.frames.length;
        for (const entry of functions.values()) {
            // Divided by the frames of the window, not by the frames the
            // function appeared in: a function that runs every third frame
            // costs a third of what it costs when it runs, and a table sorted
            // on the other reading puts rare, expensive work at the top of a
            // list of things to optimize where it does not belong.
            entry.selfAvg /= count;
            entry.totalAvg /= count;
            entry.callsAvg /= count;
            if (entry.totalMin === Number.MAX_SAFE_INTEGER) {
                entry.totalMin = 0;
            }
        }

        return {
            frames: count,
            framesSeen: this.framesSeen,
            frameClocks,
            clocks: count > 0 ? this.frames[last].clocks : 0,
            clocksAvg: count > 0 ? clocksTotal / count : 0,
            clocksPeak,
            halted: count > 0 ? this.frames[last].halted : 0,
            haltedAvg: count > 0 ? haltedTotal / count : 0,
            haltedPeak,
            waiting: count > 0 ? this.frames[last].waited : 0,
            waitingAvg: count > 0 ? waitedTotal / count : 0,
            waitingPeak: waitedPeak,
            waitingAt: count > 0 ? this.frames[last].waitAt : 0,
            instructions: count > 0 ? this.frames[last].instructions : 0,
            instructionsAvg: count > 0 ? instructionsTotal / count : 0,
            frameBusy,
            pinned: pin === undefined ? undefined : this.frameDetail(pin),
            functions: [...functions.values()],
            resets: this.resets,
            overflows: this.overflowed,
        };
    }

    /**
     * One frame of the window, unpacked, or nothing if it has scrolled out.
     *
     * By frame number rather than by index, because the window moves fifty
     * times a second and an index means something different by the time the
     * answer arrives. A number that has fallen off the back is not an error:
     * it is what happens to every frame a couple of seconds after it ran, and
     * the caller is expected to have kept whatever it needed.
     */
    protected frameDetail(number: number): LiveProfileFrame | undefined {
        const index = number - (this.framesSeen - this.frames.length + 1);
        if (index < 0 || index >= this.frames.length) {
            return undefined;
        }
        const frame = this.frames[index];
        const functions: LiveProfileFrameFunction[] = [];
        const { rows } = frame;
        for (let at = 0; at < rows.length; at += 4) {
            functions.push({
                // Written through an Int32Array, so the ROM's mirror at the
                // top of memory comes back negative — as in the window pass.
                address: rows[at] >>> 0,
                self: rows[at + 1],
                total: rows[at + 2],
                calls: rows[at + 3],
            });
        }
        return {
            number,
            clocks: frame.clocks,
            halted: frame.halted,
            waited: frame.waited,
            waitAt: frame.waitAt,
            instructions: frame.instructions,
            functions,
        };
    }

    /** Throw the window away, keeping the shadow stack the machine is in. */
    clear(): void {
        this.frames.length = 0;
        this.framesSeen = 0;
        this.resets = 0;
        this.overflowed = 0;
    }

    /** A row for an address, made on first sight and kept for good. */
    protected rowFor(address: number): LiveRow {
        let row = this.rows.get(address);
        if (!row) {
            row = { address, self: 0, total: 0, calls: 0, touched: false };
            this.rows.set(address, row);
        }
        return row;
    }

    protected push(address: number, interrupt: boolean, returnTo = -1): void {
        if (this.stackRow.length >= MAX_DEPTH) {
            this.overflowed++;
            return;
        }
        const row = this.rowFor(address);
        const activations = this.active.get(address) ?? 0;
        this.active.set(address, activations + 1);
        row.calls++;
        if (!row.touched) {
            row.touched = true;
            this.touched.push(row);
        }
        this.stackRow.push(row);
        // An interrupt frame is closed by `reti`, so it is marked with a return
        // address no instruction can ever have — the vectors are halfword
        // aligned and -1 is not an address at all.
        this.stackReturn.push(interrupt ? -1 : returnTo);
        this.stackEnter.push(this.cycle);
        this.stackOutermost.push(activations === 0);
    }

    /**
     * Leave every frame that was waiting for this address.
     *
     * More than one at a time because a return can skip levels — see
     * `VesProfileCollector.unwindTo`, which this is the clock-charging twin of.
     */
    protected unwindTo(address: number): void {
        for (let depth = this.stackRow.length - 1; depth > 0; depth--) {
            if (this.stackReturn[depth] === address) {
                this.unwind(depth);
                return;
            }
        }
    }

    /** The innermost interrupt frame, and anything left open underneath it. */
    protected leaveInterrupt(): void {
        for (let depth = this.stackRow.length - 1; depth > 0; depth--) {
            if (this.stackReturn[depth] === -1) {
                this.unwind(depth);
                return;
            }
        }
    }

    /** Close every frame from `depth` up, charging each its span. */
    protected unwind(depth: number): void {
        for (let at = this.stackRow.length - 1; at >= depth; at--) {
            const row = this.stackRow[at];
            const activations = (this.active.get(row.address) ?? 1) - 1;
            if (activations > 0) {
                this.active.set(row.address, activations);
            } else {
                this.active.delete(row.address);
            }
            if (this.stackOutermost[at]) {
                row.total += this.cycle - this.stackEnter[at];
                if (!row.touched) {
                    row.touched = true;
                    this.touched.push(row);
                }
            }
        }
        this.stackRow.length = depth;
        this.stackReturn.length = depth;
        this.stackEnter.length = depth;
        this.stackOutermost.length = depth;
    }
}
