/**
 * The colorization patches that ship with VUEPort, and which games they are for.
 *
 * A VB Color patch is an ordinary ROM patch in the end: a format-2 document
 * (`VBC_PATCH_FORMAT.md`) whose embedded BPS gives an original Virtual Boy
 * title everything the VB Color hardware needs, plus the palettes a player may
 * recolor before it is applied. Nothing about applying one is special; what
 * is special is that a player should not have to go and find it. And because
 * it is a ROM patch, it is switched off in hardcore mode like any other.
 *
 * Two switches decide whether one is applied *when a game is opened*, and they
 * nest. `vbcAutoApplyColorPatches` is the master: off, nothing here comes on by
 * itself. On, each entry answers for itself — a player who wants color
 * everywhere except in one game turns that one off rather than the feature.
 * `vbcColorPatchesDisabled` holds the ids they opted out of, so the default
 * state of a newly shipped entry is on.
 *
 * Neither decides whether a colorization is *known*. The Colors panel offers
 * the switch for the running game and writes both of these when it is used, so
 * a game whose colorization is switched off still has one — it is off, which is
 * a thing the panel has to be able to say and to undo. That is why the lookup
 * below takes no choice: finding the colorization and choosing to apply it are
 * two questions, and answering them together is what made the panel unable to
 * show a switch for a game somebody had turned off.
 *
 * Keyed by CRC32 of the whole file, for the reason `emulator-cheat-database.ts`
 * gives: it is what the preservation catalogs key on, it is cheap, and it
 * works in an insecure context where `crypto.subtle` does not. One game has one
 * CRC32 per padding, which is why an entry carries a list of them. Each CRC32
 * below is the source CRC in the footer of the entry's own BPS, so a match here
 * is a ROM the patch will accept.
 */

/** How far along a game's colorization is. */
export type VesColorPatchStatus =
    /** Finished and verified against the game from start to end. */
    | 'complete'
    /** Playable and color-correct in most places, with known gaps. */
    | 'partial'
    /** Being worked on; listed so it can be tried, not so it can be relied on. */
    | 'wip';

/** One game's colorization. */
export interface VesColorPatch {
    /**
     * Stable for the life of the entry: renaming the game is fine, changing
     * this is not, because whether a player turned it off — and every color
     * they changed — is filed under it.
     */
    id: string;
    /** The game, as its catalog entry names it. */
    game: string;
    /** Lower-case, eight hex digits, one per known ROM of this game. */
    crc32: string[];
    /** Who did the colorization. */
    author?: string;
    /** The patch's own version, which moves independently of VUEPort's. */
    version?: string;
    status: VesColorPatchStatus;
    /**
     * What is worth knowing before turning it on — which revision it was made
     * against, what is not colored yet, anything that looks wrong on purpose.
     */
    notes?: string;
    /**
     * The patch document, relative to where the host serves its assets. Absent
     * while an entry is a placeholder, which is what
     * {@link isVesColorPatchReady} tests for.
     */
    config?: string;
}

/**
 * Whether an entry can actually do anything yet.
 *
 * An entry with no document and no ROMs to match is a promise rather than a
 * feature: {@link colorPatchForRom} passes over it, so nothing can be offered
 * as something to switch on before there is anything behind the switch.
 */
export function isVesColorPatchReady(patch: VesColorPatch): boolean {
    return patch.config !== undefined && patch.crc32.length > 0;
}

export const COLOR_PATCH_DATABASE: VesColorPatch[] = [
    {
        id: 'color/red-alarm',
        game: 'Red Alarm (USA)',
        // One dump only: a patch must never be offered for a merely similar one.
        crc32: [
            'aa10a7b4', // US
        ],
        author: 'VUEPort',
        version: 'v0.2',
        status: 'partial',
        notes: 'Wireframe passes and effects are colored. The HUD and the briefing '
            + 'screens are still monochrome.',
        config: 'vb-color/red-alarm.json',
    },
    {
        id: 'color/zero-racers',
        game: 'Zero Racers (JU)',
        crc32: ['71553796'],
        author: 'VUEPort',
        version: 'v1.4-dev29',
        status: 'partial',
        notes: 'Race geometry, the HUD, the status overlay, the results screen and the '
            + 'post-race menu are colored.',
        config: 'vb-color/zero-racers.json',
    },
    /*
     * Galactic Pinball keeps a set of colors per table: most of its palettes
     * carry variants — menu, Cosmic, Bonus, Colony, UFO, Alien, the high-score
     * screen — which the patch chooses between itself. The editor offers all of
     * them; see `VbColorPaletteView.variants`.
     */
    {
        id: 'color/galactic-pinball',
        game: 'Galactic Pinball (JU)',
        crc32: [
            'c9710a36', // US, JP
        ],
        author: 'VUEPort',
        version: 'v0.25-dev25',
        status: 'partial',
        notes: 'The menu and the Cosmic, Colony, UFO, Alien and Bonus tables are colored, '
            + 'each in colors of its own, as is the high-score screen.',
        config: 'vb-color/galactic-pinball.json',
    },
    {
        id: 'color/virtual-boy-wario-land',
        game: 'Virtual Boy Wario Land (USA)',
        crc32: [
            '133e9372', // US, JP
        ],
        author: 'VUEPort',
        version: 'v1.10-dev51',
        status: 'partial',
        notes: 'Wario himself is colored per form, including the headgear colors that '
            + 'follow it and the eye treatment; backgrounds and enemies use shared palettes.',
        config: 'vb-color/virtual-boy-wario-land.json',
    },
];

/** Both switches that decide whether a colorization is applied. */
export interface VesColorPatchChoice {
    /** The master switch, `vbcAutoApplyColorPatches`. */
    autoApply: boolean;
    /** The ids turned off individually, `vbcColorPatchesDisabled`. */
    disabled: readonly string[];
}

/**
 * The colorization for a ROM, if one ships for it.
 *
 * Nothing is returned for an entry that is not ready, so a placeholder can
 * never be offered as something to switch on. Whether it *is* switched on is
 * {@link colorPatchAutoApplied}'s question, deliberately kept apart — see this
 * module's own note.
 */
export function colorPatchForRom(crc32: string): VesColorPatch | undefined {
    const key = crc32.toLowerCase();
    return COLOR_PATCH_DATABASE.find(patch =>
        isVesColorPatchReady(patch) && patch.crc32.includes(key));
}

/**
 * Whether the settings say this one should come on when its game is opened.
 *
 * The master switch is read here rather than left to the caller, so that the
 * rule — off means off, whatever the individual entries say — is stated once
 * instead of once per place that loads a ROM.
 */
export function colorPatchAutoApplied(
    patch: VesColorPatch,
    choice: VesColorPatchChoice,
): boolean {
    return choice.autoApply && !choice.disabled.includes(patch.id);
}
