/**
 * The colorization patches that ship with VUEPort, and which games they are for.
 *
 * A VB Color patch is an ordinary ROM patch: one compiled BPS, made against
 * the original ROM, that gives a Virtual Boy title everything the VB Color
 * hardware needs. VUEPort ships it as its authors built it and applies it as
 * it is; there is nothing in it to edit. Nothing about applying one is
 * special; what is special is that a player should not have to go and find
 * it. And because it is a ROM patch, it is switched off in hardcore mode like
 * any other.
 *
 * Two switches decide whether one is applied *when a game is opened*, and they
 * nest. `vbcAutoApplyColorPatches` is the master: off, nothing here comes on by
 * itself. On, each entry answers for itself — a player who wants color
 * everywhere except in one game turns that one off rather than the feature.
 * `vbcColorPatchesDisabled` holds the ids they opted out of, so the default
 * state of a newly shipped entry is on.
 *
 * Neither decides whether a colorization is *known*. The Patches panel lists
 * every colorization for the running game and writes both of these when one
 * is switched, so a game whose colorization is switched off still has one —
 * it is off, which is a thing the panel has to be able to say and to undo.
 * That is why the lookup below takes no choice: finding the colorizations and
 * choosing to apply one are two questions, and answering them together is what
 * once made the panel unable to show a switch for a game somebody had turned
 * off.
 *
 * A game may have several. They are alternatives rather than layers — each
 * one's BPS is made against the original ROM, so two of them cannot be
 * chained — and so at most one is applied at a time. Which one comes on by
 * itself is the first in catalog order that the switches leave on; switching
 * one on in the panel switches its siblings off in those same settings, so
 * the choice holds the next time the game is opened.
 *
 * Keyed by CRC32 of the whole file, for the reason `emulator-cheat-database.ts`
 * gives: it is what the preservation catalogs key on, it is cheap, and it
 * works in an insecure context where `crypto.subtle` does not. One game has one
 * CRC32 per padding, which is why an entry carries a list of them. Each CRC32
 * below is the source CRC in the footer of the entry's own BPS, so a match here
 * is a ROM the patch will accept.
 */

/** How far along a game's colorization is. */
export type VesColorPatchStatus =
    /** Finished and verified against the game from start to end. */
    | 'complete'
    /** Playable and color-correct in most places, with known gaps. */
    | 'partial'
    /** Being worked on; listed so it can be tried, not so it can be relied on. */
    | 'wip';

/** One game's colorization. */
export interface VesColorPatch {
    /**
     * Stable for the life of the entry: renaming the game is fine, changing
     * this is not, because whether a player turned it off — and every color
     * they changed — is filed under it.
     */
    id: string;
    /** The game, as its catalog entry names it. */
    game: string;
    /** What the Patches panel lists it as. */
    name: string;
    /** Lower-case, eight hex digits, one per known ROM of this game. */
    crc32: string[];
    /** Who did the colorization. */
    author?: string;
    /** The patch's own version, which moves independently of VUEPort's. */
    version?: string;
    status: VesColorPatchStatus;
    /**
     * What is worth knowing before turning it on — which revision it was made
     * against, what is not colored yet, anything that looks wrong on purpose.
     */
    notes?: string;
    /**
     * The BPS, relative to where the host serves its assets. Absent while an
     * entry is a placeholder, which is what {@link isVesColorPatchReady} tests
     * for.
     */
    file?: string;
}

/**
 * Whether an entry can actually do anything yet.
 *
 * An entry with no BPS and no ROMs to match is a promise rather than a
 * feature: {@link colorPatchesForRom} passes over it, so nothing can be offered
 * as something to switch on before there is anything behind the switch.
 */
export function isVesColorPatchReady(patch: VesColorPatch): boolean {
    return patch.file !== undefined && patch.crc32.length > 0;
}

export const COLOR_PATCH_DATABASE: VesColorPatch[] = [
    {
        id: 'color/red-alarm',
        game: 'Red Alarm (USA)',
        name: 'Red Alarm – VB Color',
        // One dump only: a patch must never be offered for a merely similar one.
        crc32: [
            'aa10a7b4', // US
        ],
        author: 'VUEPort',
        version: 'v0.5',
        status: 'partial',
        notes: 'Wireframe passes and effects are colored. The HUD and the briefing '
            + 'screens are still monochrome. v0.4 copies an RGB888 palette table into '
            + 'the 32-bit Color RAM of VB Color 1.0 (October 13, 2026 revision); v0.5 '
            + 'draws the colour lines with about half the CPU time.',
        file: 'vb-color/red-alarm.bps',
    },
    {
        id: 'color/zero-racers-compiled',
        game: 'Zero Racers (JU)',
        name: 'Zero Racers – VB Color',
        crc32: ['71553796'],
        author: 'VUEPort',
        version: 'v1.9-dev97',
        status: 'wip',
        notes: 'Newer than the v1.4 colorization: extra racers on the machine select, '
            + 'the title, machine details and a polished HUD, and fades that darken the colors. '
            + 'dev97 writes the RGB888 Color RAM of VB Color 1.0 (October 13, 2026) directly.',
        file: 'vb-color/zero-racers-compiled.bps',
    },
    {
        id: 'color/zero-racers',
        game: 'Zero Racers (JU)',
        name: 'Zero Racers – VB Color (v1.4)',
        crc32: ['71553796'],
        author: 'VUEPort',
        version: 'v1.4-dev29',
        status: 'partial',
        notes: 'Race geometry, the HUD, the status overlay, the results screen and the '
            + 'post-race menu are colored. Not adapted to the shared 256-palette space '
            + 'of VB Color 1.0 (October 2026): on a current core its objects show BG '
            + 'palettes. Superseded by the compiled v1.9 colorization.',
        file: 'vb-color/zero-racers.bps',
    },
    /*
     * The hand-made Galactic Pinball colorization v0.25-dev25 (id `color/galactic-pinball`)
     * was made for a draft register map and never switches color on with a VB Color 1.0
     * core; it is no longer listed.
     */
    {
        id: 'color/virtual-boy-wario-land',
        game: 'Virtual Boy Wario Land (USA)',
        name: 'Virtual Boy Wario Land – VB Color',
        crc32: [
            '133e9372', // US, JP
        ],
        author: 'VUEPort',
        version: 'v1.10-dev55',
        status: 'partial',
        notes: 'Wario himself is colored per form, including the headgear colors that '
            + 'follow it and the eye treatment; backgrounds and enemies use shared palettes. '
            + 'dev52 keeps the OBJ palettes reachable in the shared 256-palette space of '
            + 'VB Color 1.0 (October 2026) through World Color Attribute offsets (CXCTRL.WCEN); '
            + 'dev54 writes the RGB888 Color RAM (October 13, 2026) directly from RGB888 tables in a 4 MB ROM. '
            + 'dev55 colors the title screen and Wario in the intro pixel by pixel (Pixel Color Extension, Character '
            + 'Color Attributes) and classifies sprites once per character instead of once per sprite, which frees up CPU time.',
        file: 'vb-color/virtual-boy-wario-land.bps',
    },
    {
        id: 'color/bound-high',
        game: 'Bound High (JU)',
        name: 'Bound High! – VB Color',
        crc32: [
            'e365ddd3', // Retail
        ],
        author: 'VUEPort',
        version: 'v0.8-dev37',
        status: 'partial',
        notes: 'Colored up to and including the final boss, and the game\'s fades darken the '
            + 'colors too. dev37 uses the RGB888 Color RAM of VB Color 1.0 (October 13, 2026).',
        file: 'vb-color/bound-high.bps',
    },
    {
        id: 'color/dragon-hopper',
        game: 'Dragon Hopper (JU)',
        name: 'Dragon Hopper – VB Color',
        crc32: ['193c1a2f'],
        author: 'VUEPort',
        version: 'dev138',
        status: 'partial',
        notes: 'The title and its new logo, the intro and story pictures, the overworld and the '
            + 'stages are colored. The patched ROM is 4 MB. dev138 colors level tiles and HUD sprites '
            + 'by character (Character Color Attribute RAM) and Seline\'s face by pixel (Pixel Color '
            + 'Extension) of VB Color 1.0 (October 13, 2026).',
        file: 'vb-color/dragon-hopper.bps',
    },
    {
        id: 'color/hyper-fighting',
        game: 'Hyper Fighting',
        name: 'Hyper Fighting – VB Color',
        crc32: [
            '3f2a6ba2', // v1.0, homebrew
        ],
        author: 'VUEPort',
        version: 'v0.72-dev72',
        status: 'partial',
        notes: 'Every fighter in every frame, all twelve stages, the HUD and the menu screens are '
            + 'colored. The patched ROM is 8 MB. dev72 uses the RGB888 Color RAM of VB Color 1.0 '
            + '(October 13, 2026).',
        file: 'vb-color/hyper-fighting.bps',
    },
    {
        id: 'color/marios-tennis',
        game: "Mario's Tennis (JU)",
        name: 'Mario\'s Tennis – VB Color',
        crc32: [
            '7ce7460d', // Retail
        ],
        author: 'VUEPort',
        version: 'dev24',
        status: 'partial',
        notes: 'Mario, Luigi, Peach and Yoshi are colored down to their poses; Donkey Kong and '
            + 'Koopa are still being worked on. dev24 expands its palettes into the RGB888 Color '
            + 'RAM of VB Color 1.0 (October 13, 2026).',
        file: 'vb-color/marios-tennis.bps',
    },
    {
        id: 'color/test-chamber',
        game: 'Test Chamber',
        name: 'Test Chamber – VB Color',
        crc32: ['bd530920'],
        author: 'VUEPort',
        version: 'v0.10-dev32',
        status: 'partial',
        notes: 'The chambers, crates and doors are colored. dev32 uses the RGB888 Color RAM of '
            + 'VB Color 1.0 (October 13, 2026) and colors the software-rendered walls with less CPU '
            + 'time (about 13 % more frames per second).',
        file: 'vb-color/test-chamber.bps',
    },
    {
        id: 'color/jack-bros',
        game: 'Jack Bros. (USA)',
        name: 'Jack Bros. – VB Color',
        crc32: [
            'a44de03c', // Retail
        ],
        author: 'VUEPort',
        version: 'v0.2-dev2',
        status: 'partial',
        notes: 'Hand-made: the three Jacks, Pixie, all six areas, the enemies and the six bosses, the HUD '
            + 'and dialogs, the title, the select screen, the opening and the ending with its staff roll are '
            + 'colored. Colors follow each graphic\'s source in the ROM (Character Color Attribute RAM of VB '
            + 'Color 1.0, October 13, 2026); the Jacks, Pixie, the select screen and the ending pictures are '
            + 'refined pixel by pixel (Pixel Color Extension). The patched ROM is 2 MB.',
        file: 'vb-color/jack-bros.bps',
    },
];

/** Both switches that decide whether a colorization is applied. */
export interface VesColorPatchChoice {
    /** The master switch, `vbcAutoApplyColorPatches`. */
    autoApply: boolean;
    /** The ids turned off individually, `vbcColorPatchesDisabled`. */
    disabled: readonly string[];
}

/**
 * Every colorization that ships for a ROM, in catalog order.
 *
 * Nothing is returned for an entry that is not ready, so a placeholder can
 * never be offered as something to switch on. Whether one *is* switched on is
 * {@link colorPatchAutoApplied}'s question, deliberately kept apart — see this
 * module's own note.
 */
export function colorPatchesForRom(crc32: string): VesColorPatch[] {
    const key = crc32.toLowerCase();
    return COLOR_PATCH_DATABASE.filter(patch =>
        isVesColorPatchReady(patch) && patch.crc32.includes(key));
}

/**
 * Whether the settings say this one should come on when its game is opened.
 *
 * The master switch is read here rather than left to the caller, so that the
 * rule — off means off, whatever the individual entries say — is stated once
 * instead of once per place that loads a ROM.
 */
export function colorPatchAutoApplied(
    patch: VesColorPatch,
    choice: VesColorPatchChoice,
): boolean {
    return choice.autoApply && !choice.disabled.includes(patch.id);
}
