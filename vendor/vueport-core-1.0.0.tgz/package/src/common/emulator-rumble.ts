/**
 * The rumble pack, as the emulator sees it.
 *
 * A copy of the parts of VES's rumble pack support that the emulator
 * needs — the protocol's shapes and its effect names — so that nothing under
 * `emulator/` reaches into `rumble-pack/`. VES keeps its own copy for
 * flashing firmware and for the effect editor; the two are expected to drift
 * apart rather than be kept in step, since one describes a device the emulator
 * pretends to be and the other drives a real one.
 */

import { Disposable, Emitter, Event } from './emulator-events';
import { nls } from './emulator-nls';

/** One decoded command from the byte stream a game sends. */
export interface RumbleCommand {
    bytes: number[];
    label: string;
    /** True for a byte that means nothing in this protocol. */
    unknown?: boolean;
    /** When it was decoded, as `Date.now()` reads. */
    at: number;
}

/** What the game has asked the pack to be doing. */
export interface RumbleState {
    effect?: number;
    frequency?: number;
    playing?: boolean;
    /**
     * When the last Play was decoded, as `Date.now()` reads.
     *
     * Kept because a game is not obliged to end what it started: the pack's
     * effects have a length of their own and stop on their own, so a Stop is
     * something a game sends when it wants one cut short. See
     * {@link isRumblePlaying}, which is where that turns into an answer.
     */
    playingSince?: number;
    /**
     * How many Plays have been decoded since the stream was reset.
     *
     * A counter as well as a timestamp because the two answer different
     * questions. {@link playingSince} says how far into an effect we are,
     * which is what the ceiling needs; this one says *which* Play it is, which
     * is what anybody acting once per effect needs — and two Plays that land
     * in the same millisecond share a timestamp but not a number.
     */
    plays?: number;
    chain?: number;
}

/**
 * How long an effect counts as playing when nothing says otherwise.
 *
 * Not the usual case any more: the 123 effects have measured lengths now (see
 * {@link RUMBLE_EFFECT_SHAPES}), and each is played for its own. This is what
 * is left over — the one effect built to run until it is stopped, and a Play
 * whose effect number the game never sent. Both need an end, and neither has
 * one of its own.
 */
export const RUMBLE_EFFECT_MAX_MS = 1000;

/**
 * Whether the motor should still be turning, as far as this side can tell.
 *
 * `state.playing` on its own only ever says what the game last asked for, and
 * a game that never sends a Stop would leave it true for the rest of the
 * session — the pack's effects end themselves, so a Stop is what a game sends
 * to cut one short rather than what ends it.
 *
 * How long the effect had is its own, and measured: a click is over in a tenth
 * of a second where an alert runs three quarters of one. See
 * {@link rumbleEffectMs}. The ceiling is what answers for the two cases with
 * no length — the buzz meant to be stopped, and a Play whose effect was never
 * chosen.
 *
 * `now` is a parameter so that a caller drawing several things in one pass
 * gets one answer for all of them, and so that a test can say when it is.
 */
export function isRumblePlaying(state: RumbleState, now = Date.now()): boolean {
    if (state.playing !== true || state.playingSince === undefined) {
        // No stamp is an effect from before this was recorded, which is
        // nothing anybody is waiting on: over, rather than running forever.
        return false;
    }
    // The effect's own measured length, uncapped: the 1000 ms alert runs a
    // little past a second and cutting it at the ceiling would be the one
    // effect whose length is beyond doubt reported wrong.
    return now - state.playingSince < rumbleEffectMs(rumbleEffectShape(state.effect));
}

/** The address a game's rumble effect spec was found at. */
export interface EmulatedRumbleSpec {
    address: number;
    /** Only set when a symbol covers the address. */
    name?: string;
}

/**
 * The pack's 123 built-in effects, by name.
 *
 * Built on first use rather than at import, because the host installs its
 * localization during start-up and a table built while this module loaded would
 * be English for the life of the process. Cached afterwards: changing language
 * needs a reload either way.
 */
let effectNames: string[] | undefined;

export function builtInRumbleEffects(): string[] {
    if (!effectNames) {
        effectNames = [
    `1) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} - 100 %`,
    `2) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} - 60 % `,
    `3) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} - 30 % `,
    `4) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpClick', 'Sharp Click')} - 100 % `,
    `5) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpClick', 'Sharp Click')} - 60 % `,
    `6) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpClick', 'Sharp Click')} - 30 % `,
    `7) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/softBump', 'Soft Bump')} - 100 % `,
    `8) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/softBump', 'Soft Bump')} - 60 % `,
    `9) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/softBump', 'Soft Bump')} - 30 % `,
    `10) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/doubleClick', 'Double Click')} - 100 % `,
    `11) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/doubleClick', 'Double Click')} - 60 % `,
    `12) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/tripleClick', 'Triple Click')} - 100 % `,
    `13) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/softFuzz', 'Soft Fuzz')} - 60 % `,
    `14) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongBuzz', 'Strong Buzz')} - 100 % `,
    `15) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/750MsAlert', '750 ms Alert')} 100 % `,
    `16) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/1000MsAlert', '1000 ms Alert')} 100 % `,
    `17) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} 1 - 100 % `,
    `18) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} 2 - 80 % `,
    `19) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} 3 - 60 % `,
    `20) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/strongClick', 'Strong Click')} 4 - 30 % `,
    `21) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/mediumClick', 'Medium Click')} 1 - 100 % `,
    `22) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/mediumClick', 'Medium Click')} 2 - 80 % `,
    `23) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/mediumClick', 'Medium Click')} 3 - 60 % `,
    `24) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpTick', 'Sharp Tick')} 1 - 100 % `,
    `25) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpTick', 'Sharp Tick')} 2 - 80 % `,
    `26) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/sharpTick', 'Sharp Tick')} 3 – 60 % `,
    `27) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickStrong', 'Short Double Click Strong')} 1 – 100 % `,
    `28) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickStrong', 'Short Double Click Strong')} 2 – 80 % `,
    `29) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickStrong', 'Short Double Click Strong')} 3 – 60 % `,
    `30) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickStrong', 'Short Double Click Strong')} 4 – 30 % `,
    `31) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickMedium', 'Short Double Click Medium')} 1 – 100 % `,
    `32) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickMedium', 'Short Double Click Medium')} 2 – 80 % `,
    `33) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleClickMedium', 'Short Double Click Medium')} 3 – 60 % `,
    `34) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleSharpTick', 'Short Double Sharp Tick')} 1 – 100 % `,
    `35) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleSharpTick', 'Short Double Sharp Tick')} 2 – 80 % `,
    `36) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/shortDoubleSharpTick', 'Short Double Sharp Tick')} 3 – 60 % `,
    `37) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickStrong', 'Long Double Sharp Click Strong')} 1 – 100 % `,
    `38) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickStrong', 'Long Double Sharp Click Strong')} 2 – 80 % `,
    `39) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickStrong', 'Long Double Sharp Click Strong')} 3 – 60 % `,
    `40) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickStrong', 'Long Double Sharp Click Strong')} 4 – 30 % `,
    `41) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickMedium', 'Long Double Sharp Click Medium')} 1 – 100 % `,
    `42) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickMedium', 'Long Double Sharp Click Medium')} 2 – 80 % `,
    `43) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpClickMedium', 'Long Double Sharp Click Medium')} 3 – 60 % `,
    `44) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpTick', 'Long Double Sharp Tick')} 1 – 100 % `,
    `45) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpTick', 'Long Double Sharp Tick')} 2 – 80 % `,
    `46) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longDoubleSharpTick', 'Long Double Sharp Tick')} 3 – 60 % `,
    `47) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/buzz', 'Buzz')} 1 – 100 % `,
    `48) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/buzz', 'Buzz')} 2 – 80 % `,
    `49) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/buzz', 'Buzz')} 3 – 60 % `,
    `50) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/buzz', 'Buzz')} 4 – 40 % `,
    `51) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/buzz', 'Buzz')} 5 – 20 % `,
    `52) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingStrong', 'Pulsing Strong')} 1 – 100 % `,
    `53) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingStrong', 'Pulsing Strong')} 2 – 60 % `,
    `54) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingMedium', 'Pulsing Medium')} 1 – 100 % `,
    `55) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingMedium', 'Pulsing Medium')} 2 – 60 % `,
    `56) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingSharp', 'Pulsing Sharp')} 1 – 100 % `,
    `57) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/pulsingSharp', 'Pulsing Sharp')} 2 – 60 % `,
    `58) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 1 – 100 % `,
    `59) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 2 – 80 % `,
    `60) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 3 – 60 % `,
    `61) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 4 – 40 % `,
    `62) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 5 – 20 % `,
    `63) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionClick', 'Transition Click')} 6 – 10 % `,
    `64) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 1 – 100 % `,
    `65) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 2 – 80 % `,
    `66) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 3 – 60 % `,
    `67) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 4 – 40 % `,
    `68) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 5 – 20 % `,
    `69) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionHum', 'Transition Hum')} 6 – 10 % `,
    `70) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSmooth', 'Transition Ramp Down Long Smooth')} 1 – 100 to 0 % `,
    `71) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSmooth', 'Transition Ramp Down Long Smooth')} 2 – 100 to 0 % `,
    `72) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSmooth', 'Transition Ramp Down Medium Smooth')} 1 – 100 to 0 % `,
    `73) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSmooth', 'Transition Ramp Down Medium Smooth')} 2 – 100 to 0 % `,
    `74) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSmooth', 'Transition Ramp Down Short Smooth')} 1 – 100 to 0 % `,
    `75) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSmooth', 'Transition Ramp Down Short Smooth')} 2 – 100 to 0 % `,
    `76) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSharp', 'Transition Ramp Down Long Sharp')} 1 – 100 to 0 % `,
    `77) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSharp', 'Transition Ramp Down Long Sharp')} 2 – 100 to 0 % `,
    `78) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSharp', 'Transition Ramp Down Medium Sharp')} 1 – 100 to 0 % `,
    `79) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSharp', 'Transition Ramp Down Medium Sharp')} 2 – 100 to 0 % `,
    `80) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSharp', 'Transition Ramp Down Short Sharp')} 1 – 100 to 0 % `,
    `81) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSharp', 'Transition Ramp Down Short Sharp')} 2 – 100 to 0 % `,
    `82) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSmooth', 'Transition Ramp Up Long Smooth')} 1 – 0 to 100 % `,
    `83) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSmooth', 'Transition Ramp Up Long Smooth')} 2 – 0 to 100 % `,
    `84) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSmooth', 'Transition Ramp Up Medium Smooth')} 1 – 0 to 100 % `,
    `85) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSmooth', 'Transition Ramp Up Medium Smooth')} 2 – 0 to 100 % `,
    `86) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSmooth', 'Transition Ramp Up Short Smooth')} 1 – 0 to 100 % `,
    `87) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSmooth', 'Transition Ramp Up Short Smooth')} 2 – 0 to 100 % `,
    `88) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSharp', 'Transition Ramp Up Long Sharp')} 1 – 0 to 100 % `,
    `89) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSharp', 'Transition Ramp Up Long Sharp')} 2 – 0 to 100 % `,
    `90) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSharp', 'Transition Ramp Up Medium Sharp')} 1 – 0 to 100 % `,
    `91) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSharp', 'Transition Ramp Up Medium Sharp')} 2 – 0 to 100 % `,
    `92) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSharp', 'Transition Ramp Up Short Sharp')} 1 – 0 to 100 % `,
    `93) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSharp', 'Transition Ramp Up Short Sharp')} 2 – 0 to 100 % `,
    `94) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSmooth', 'Transition Ramp Down Long Smooth')} 1 – 50 to 0 % `,
    `95) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSmooth', 'Transition Ramp Down Long Smooth')} 2 – 50 to 0 % `,
    `96) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSmooth', 'Transition Ramp Down Medium Smooth')} 1 – 50 to 0 % `,
    `97) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSmooth', 'Transition Ramp Down Medium Smooth')} 2 – 50 to 0 % `,
    `98) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSmooth', 'Transition Ramp Down Short Smooth')} 1 – 50 to 0 % `,
    `99) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSmooth', 'Transition Ramp Down Short Smooth')} 2 – 50 to 0 % `,
    `100) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSharp', 'Transition Ramp Down Long Sharp')} 1 – 50 to 0 % `,
    `101) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownLongSharp', 'Transition Ramp Down Long Sharp')} 2 – 50 to 0 % `,
    `102) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSharp', 'Transition Ramp Down Medium Sharp')} 1 – 50 to 0 % `,
    `103) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownMediumSharp', 'Transition Ramp Down Medium Sharp')} 2 – 50 to 0 % `,
    `104) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSharp', 'Transition Ramp Down Short Sharp')} 1 – 50 to 0 % `,
    `105) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampDownShortSharp', 'Transition Ramp Down Short Sharp')} 2 – 50 to 0 % `,
    `106) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSmooth', 'Transition Ramp Up Long Smooth')} 1 – 0 to 50 % `,
    `107) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSmooth', 'Transition Ramp Up Long Smooth')} 2 – 0 to 50 % `,
    `108) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSmooth', 'Transition Ramp Up Medium Smooth')} 1 – 0 to 50 % `,
    `109) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSmooth', 'Transition Ramp Up Medium Smooth')} 2 – 0 to 50 % `,
    `110) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSmooth', 'Transition Ramp Up Short Smooth')} 1 – 0 to 50 % `,
    `111) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSmooth', 'Transition Ramp Up Short Smooth')} 2 – 0 to 50 % `,
    `112) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSharp', 'Transition Ramp Up Long Sharp')} 1 – 0 to 50 % `,
    `113) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpLongSharp', 'Transition Ramp Up Long Sharp')} 2 – 0 to 50 % `,
    `114) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSharp', 'Transition Ramp Up Medium Sharp')} 1 – 0 to 50 % `,
    `115) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpMediumSharp', 'Transition Ramp Up Medium Sharp')} 2 – 0 to 50 % `,
    `116) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSharp', 'Transition Ramp Up Short Sharp')} 1 – 0 to 50 % `,
    `117) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/transitionRampUpShortSharp', 'Transition Ramp Up Short Sharp')} 2 – 0 to 50 % `,
    `118) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/longBuzzForProgrammaticStopping', 'Long buzz for programmatic stopping')} – 100 % `,
    `119) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/smoothHum', 'Smooth Hum {0} (No kick or brake pulse)', 1)} – 50 % `,
    `120) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/smoothHum', 'Smooth Hum {0} (No kick or brake pulse)', 2)} – 40 % `,
    `121) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/smoothHum', 'Smooth Hum {0} (No kick or brake pulse)', 3)} – 30 % `,
    `122) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/smoothHum', 'Smooth Hum {0} (No kick or brake pulse)', 4)} – 20 % `,
    `123) ${nls.localize('vueport/debug/panels/rumblePack/effects/names/smoothHum', 'Smooth Hum {0} (No kick or brake pulse)', 5)} – 10 % `,
        ];
    }
    return effectNames;
}

/**
 * What one of the 123 built-in effects does: how hard it pulls, and how long.
 *
 * The lengths are measured, not looked up. They are Immersion's, held in the
 * haptic driver's ROM and published by nobody — TI's datasheets print the
 * names and not one duration, and TI's own answer to the question is to
 * measure it. So they were: `packages/web/tools/rumble-durations.html` plays
 * every effect into a microphone and times the sound, and
 * `rumble-effect-durations.json` beside it is the run these numbers come from.
 *
 * Two of the 123 carry their length in their name, which is what makes the
 * rest trustworthy: the 750 ms alert measured 789 and the 1000 ms alert 1037,
 * both about 38 ms long. That excess is the motor still moving after it stops
 * being driven, and it is kept rather than subtracted — what a player feels is
 * the vibration, not the drive.
 *
 * What the names claimed, and measuring disproved: a Strong Buzz is a quarter
 * of a second and not a whole one, a Smooth Hum stops by itself after half a
 * second rather than running on, and the Short, Medium and Long in the 48 ramp
 * names say nothing at all about their length — Ramp Down Long Smooth 1 and
 * Ramp Down Short Smooth 1 are both about 320 ms, while the 1 and 2 variants
 * of the same name differ by 200. Guessing from the names would have been
 * wrong for more than half the library.
 */
export interface RumbleEffectShape {
    /** How hard, 0 to 1, as the name's percentage says. Where a ramp starts. */
    amplitude: number;
    /** Where a ramp ends. Only a ramp has one. */
    rampTo?: number;
    /**
     * How long it runs, measured, in milliseconds.
     *
     * Absent for the one effect that has no length of its own: 118 is named
     * "Long buzz for programmatic stopping" and runs until a Stop, which the
     * measurement confirmed by hitting its three-second cap.
     */
    ms?: number;
}

/** An effect with a length of its own, which is all but one of them. */
const fixed = (amplitude: number, ms: number): RumbleEffectShape => ({ amplitude, ms });
const ramp = (from: number, to: number, ms: number): RumbleEffectShape =>
    ({ amplitude: from, rampTo: to, ms });
const untilStopped = (amplitude: number): RumbleEffectShape => ({ amplitude });

/**
 * The 123 effects, as shapes rather than as words.
 *
 * In step with `builtInRumbleEffects` above, entry for entry — the comments
 * carry the same numbers and family names, and `rumble-effects-probe` reads
 * the English names and fails if the two ever disagree about an amplitude.
 * Written out rather than derived from the names at run time: those names are
 * translated, and a program that reads its own interface text is a program
 * that breaks in German.
 */
export const RUMBLE_EFFECT_SHAPES: readonly RumbleEffectShape[] = [
    /* 1–3 Strong Click */ fixed(1, 91), fixed(0.6, 96), fixed(0.3, 88),
    /* 4–6 Sharp Click */ fixed(1, 72), fixed(0.6, 85), fixed(0.3, 75),
    /* 7–9 Soft Bump */ fixed(1, 123), fixed(0.6, 117), fixed(0.3, 117),
    /* 10–11 Double Click */ fixed(1, 213), fixed(0.6, 203),
    /* 12 Triple Click */ fixed(1, 264),
    /* 13 Soft Fuzz */ fixed(0.6, 232),
    /* 14 Strong Buzz */ fixed(1, 235),
    /* 15 750 ms Alert */ fixed(1, 789),
    /* 16 1000 ms Alert */ fixed(1, 1037),
    /* 17–20 Strong Click */ fixed(1, 117), fixed(0.8, 115), fixed(0.6, 120), fixed(0.3, 120),
    /* 21–23 Medium Click */ fixed(1, 109), fixed(0.8, 115), fixed(0.6, 107),
    /* 24–26 Sharp Tick */ fixed(1, 69), fixed(0.8, 72), fixed(0.6, 69),
    /* 27–30 Short Double Click Strong */ fixed(1, 149), fixed(0.8, 147), fixed(0.6, 152),
    fixed(0.3, 147),
    /* 31–33 Short Double Click Medium */ fixed(1, 152), fixed(0.8, 165), fixed(0.6, 157),
    /* 34–36 Short Double Sharp Tick */ fixed(1, 144), fixed(0.8, 152), fixed(0.6, 149),
    /* 37–40 Long Double Sharp Click Strong */ fixed(1, 184), fixed(0.8, 189), fixed(0.6, 197),
    fixed(0.3, 192),
    /* 41–43 Long Double Sharp Click Medium */ fixed(1, 179), fixed(0.8, 165), fixed(0.6, 179),
    /* 44–46 Long Double Sharp Tick */ fixed(1, 197), fixed(0.8, 211), fixed(0.6, 197),
    /* 47–51 Buzz */ fixed(1, 285), fixed(0.8, 288), fixed(0.6, 285), fixed(0.4, 283),
    fixed(0.2, 285),
    /* 52–53 Pulsing Strong */ fixed(1, 349), fixed(0.6, 347),
    /* 54–55 Pulsing Medium */ fixed(1, 211), fixed(0.6, 213),
    /* 56–57 Pulsing Sharp */ fixed(1, 168), fixed(0.6, 160),
    /* 58–63 Transition Click */ fixed(1, 533), fixed(0.8, 528), fixed(0.6, 528),
    fixed(0.4, 528), fixed(0.2, 539), fixed(0.1, 533),
    /* 64–69 Transition Hum */ fixed(1, 512), fixed(0.8, 517), fixed(0.6, 515),
    fixed(0.4, 520), fixed(0.2, 517), fixed(0.1, 515),
    /* 70–71 Transition Ramp Down Long Smooth */ ramp(1, 0, 323), ramp(1, 0, 517),
    /* 72–73 Transition Ramp Down Medium Smooth */ ramp(1, 0, 323), ramp(1, 0, 517),
    /* 74–75 Transition Ramp Down Short Smooth */ ramp(1, 0, 317), ramp(1, 0, 384),
    /* 76–77 Transition Ramp Down Long Sharp */ ramp(1, 0, 299), ramp(1, 0, 320),
    /* 78–79 Transition Ramp Down Medium Sharp */ ramp(1, 0, 304), ramp(1, 0, 325),
    /* 80–81 Transition Ramp Down Short Sharp */ ramp(1, 0, 301), ramp(1, 0, 325),
    /* 82–83 Transition Ramp Up Long Smooth */ ramp(0, 1, 227), ramp(0, 1, 475),
    /* 84–85 Transition Ramp Up Medium Smooth */ ramp(0, 1, 237), ramp(0, 1, 421),
    /* 86–87 Transition Ramp Up Short Smooth */ ramp(0, 1, 253), ramp(0, 1, 384),
    /* 88–89 Transition Ramp Up Long Sharp */ ramp(0, 1, 317), ramp(0, 1, 560),
    /* 90–91 Transition Ramp Up Medium Sharp */ ramp(0, 1, 315), ramp(0, 1, 504),
    /* 92–93 Transition Ramp Up Short Sharp */ ramp(0, 1, 315), ramp(0, 1, 440),
    /* 94–95 Transition Ramp Down Long Smooth */ ramp(0.5, 0, 315), ramp(0.5, 0, 488),
    /* 96–97 Transition Ramp Down Medium Smooth */ ramp(0.5, 0, 309), ramp(0.5, 0, 475),
    /* 98–99 Transition Ramp Down Short Smooth */ ramp(0.5, 0, 299), ramp(0.5, 0, 336),
    /* 100–101 Transition Ramp Down Long Sharp */ ramp(0.5, 0, 304), ramp(0.5, 0, 320),
    /* 102–103 Transition Ramp Down Medium Sharp */ ramp(0.5, 0, 307), ramp(0.5, 0, 320),
    /* 104–105 Transition Ramp Down Short Sharp */ ramp(0.5, 0, 307), ramp(0.5, 0, 320),
    /* 106–107 Transition Ramp Up Long Smooth */ ramp(0, 0.5, 216), ramp(0, 0.5, 443),
    /* 108–109 Transition Ramp Up Medium Smooth */ ramp(0, 0.5, 224), ramp(0, 0.5, 381),
    /* 110–111 Transition Ramp Up Short Smooth */ ramp(0, 0.5, 243), ramp(0, 0.5, 347),
    /* 112–113 Transition Ramp Up Long Sharp */ ramp(0, 0.5, 320), ramp(0, 0.5, 563),
    /* 114–115 Transition Ramp Up Medium Sharp */ ramp(0, 0.5, 317), ramp(0, 0.5, 509),
    /* 116–117 Transition Ramp Up Short Sharp */ ramp(0, 0.5, 317), ramp(0, 0.5, 443),
    /* 118 Long buzz for programmatic stopping */ untilStopped(1),
    /* 119–123 Smooth Hum */ fixed(0.5, 515), fixed(0.4, 512), fixed(0.3, 504),
    fixed(0.2, 501), fixed(0.1, 549),
];

/** What effect `effect` is, or undefined for a number the pack does not have. */
export function rumbleEffectShape(effect: number | undefined): RumbleEffectShape | undefined {
    return effect === undefined ? undefined : RUMBLE_EFFECT_SHAPES[effect - 1];
}

/**
 * How long an effect runs, in milliseconds.
 *
 * Its measured length, and the ceiling for the two cases where there is none:
 * the effect that runs until it is stopped, and a Play whose effect number was
 * never chosen.
 */
export function rumbleEffectMs(shape: RumbleEffectShape | undefined): number {
    return shape?.ms ?? RUMBLE_EFFECT_MAX_MS;
}

/**
 * How hard an effect is pulling at one point along its length.
 *
 * `progress` runs 0 to 1 over the effect. A flat effect answers the same all
 * the way through; a ramp is read off the line between where it starts and
 * where it ends, which for the 48 ramps in the library is the whole of what
 * makes them ramps.
 *
 * Shared, so that a pad's motors and the panel's little box are never two
 * different opinions about what the game asked for.
 */
export function rumbleEffectAmplitudeAt(
    shape: RumbleEffectShape | undefined,
    progress: number,
): number {
    if (shape === undefined) {
        // Nothing chosen, so nothing to be quiet about: full strength is the
        // only honest answer to a Play with no effect behind it.
        return 1;
    }
    if (shape.rampTo === undefined) {
        return shape.amplitude;
    }
    const along = Math.min(1, Math.max(0, progress));
    return shape.amplitude + (shape.rampTo - shape.amplitude) * along;
}

export function getRumbleEffectName(effect: number): string {
    return builtInRumbleEffects()[effect - 1]?.trim() ?? `${effect}`;
}

/**
 * A rumble pack the emulator can drive.
 *
 * Narrower than VES's service, which also flashes firmware and keeps a
 * log widget: this is only what it takes to forward a game's link port traffic
 * to a real pack and to show what it is asking for. A host with no pack — or no
 * WebSerial — can implement this as a permanently disconnected one.
 */
export interface VueportRumblePack {
    readonly connected: boolean;
    /**
     * Whether this host could ever have one attached.
     *
     * False for a page, which cannot reach a serial port however many packs
     * are plugged into the machine it is running on. It is the difference
     * between a pack that is not there yet and one that can never be, and the
     * panel needs it to know whether offering a Detect button is honest.
     *
     * Optional so that a host written before this existed still reads as one
     * that can, which is what every host that implements this interface at all
     * used to be.
     */
    readonly canConnect?: boolean;
    /** The device's name, when it is one we recognize. */
    readonly deviceName: string | undefined;
    /** The connected device's USB ids, for the panel to show. */
    readonly deviceIds: { vendor?: number, product?: number } | undefined;
    readonly onDidChangeConnected: Event<void>;
    /** Ask the person to pick a port, and open it. */
    detect(): Promise<void>;

    /** Whether the emulator is forwarding the game's link traffic to it. */
    forwarding: boolean;
    /**
     * Whether a link cable has the port instead, which is the one reason a
     * pack that is plugged in and has a game running is still left alone.
     *
     * Set by the emulator alongside {@link forwarding}, because only it knows
     * what the port is carrying. It is the difference between "nothing is
     * running" and "something else is using the one port", and a player looking
     * for their missing rumble needs to be told which.
     *
     * Optional so that a host with no way to link two machines can leave it
     * alone and read as never cabled.
     */
    linkPortInUse?: boolean;
    /** The effect spec the running game last started, if it is known. */
    emulatedSpec: EmulatedRumbleSpec | undefined;
    readonly emulatedCommands: RumbleCommand[];
    readonly emulatedRumbleState: RumbleState;
    readonly emulatedByteCount: number;
    /** What the pack itself last said, where an unknown command shows up. */
    readonly lastReply: string | undefined;
    /**
     * Commands dropped because the game asked for them faster than the wire
     * and the board could take them. See `SerialRumblePack.MAX_QUEUED`.
     *
     * Optional, like the rest of what only a host with hardware can answer.
     * Worth showing where it is not zero: it is the difference between a pack
     * that is behaving oddly and a game that is asking for more than a pack
     * can do.
     */
    readonly droppedCommands?: number;
    clearEmulatedTraffic(): void;
    sendByte(byte: number): Promise<void>;
    /**
     * Silence the motor, without the game having asked for it.
     *
     * Needed because forwarding can be taken away mid-effect — a cable goes in,
     * or the game is closed while something is playing — and the Stop the game
     * would eventually have sent is exactly what is no longer being carried.
     * A pack left like that buzzes until it is unplugged.
     *
     * Outside the forwarded stream on purpose: the byte is ours rather than the
     * game's, so it is not counted or decoded into the traffic the panel shows.
     *
     * Optional, like {@link linkPortInUse}: a host that cannot take the port
     * away has nothing to stop.
     */
    stop?(): Promise<void>;
}

/** A pack that is never plugged in, for a host that cannot talk to one. */
export const NO_RUMBLE_PACK: VueportRumblePack = {
    connected: false,
    canConnect: false,
    deviceName: undefined,
    deviceIds: undefined,
    onDidChangeConnected: () => Disposable.NULL,
    detect: async () => { },
    forwarding: false,
    linkPortInUse: false,
    emulatedSpec: undefined,
    emulatedCommands: [],
    emulatedRumbleState: {},
    emulatedByteCount: 0,
    lastReply: undefined,
    clearEmulatedTraffic: () => { },
    sendByte: async () => { },
    stop: async () => { },
};

/** How much of the game's traffic the panel keeps, matching the studio's. */
const HISTORY_LENGTH = 16;

/**
 * The half of a rumble pack that needs no rumble pack.
 *
 * Counting the bytes a game clocks out of the link port and decoding them into
 * effects is arithmetic: it needs the protocol and nothing else, which is why
 * it lives here rather than in a host. What a host adds is the device — a port
 * to open, bytes to write to it, a reply to read back — and that is the whole
 * of what {@link forward} and the overridable getters are for.
 *
 * Used directly by a host that has no way to reach a pack, and there it is not
 * a stub: the panel's readings are about what the game is asking for, and a
 * game asks for it whether or not anything is listening. A page gets the
 * commands, the effect and the motor that would be running; what it does not
 * get is the buzz.
 */
export class DecodingRumblePack implements VueportRumblePack {

    protected readonly onDidChangeConnectedEmitter = new Emitter<void>();
    readonly onDidChangeConnected: Event<void> = this.onDidChangeConnectedEmitter.event;

    protected readonly decoder = new RumbleStreamDecoder();
    protected commands: RumbleCommand[] = [];
    protected bytes = 0;

    forwarding = false;
    linkPortInUse = false;
    emulatedSpec: EmulatedRumbleSpec | undefined;

    /** Overridden by a host that can open a port. */
    get canConnect(): boolean {
        return false;
    }

    get connected(): boolean {
        return false;
    }

    get deviceName(): string | undefined {
        return undefined;
    }

    get deviceIds(): { vendor?: number, product?: number } | undefined {
        return undefined;
    }

    get lastReply(): string | undefined {
        return undefined;
    }

    get emulatedCommands(): RumbleCommand[] {
        return this.commands;
    }

    get emulatedRumbleState(): RumbleState {
        return this.decoder.state;
    }

    get emulatedByteCount(): number {
        return this.bytes;
    }

    /** Nothing is sent, so nothing is ever given up on. */
    get droppedCommands(): number {
        return 0;
    }

    /** Nothing to look for. A host that has somewhere to look overrides this. */
    async detect(): Promise<void> { }

    clearEmulatedTraffic(): void {
        this.commands = [];
        this.bytes = 0;
        this.decoder.reset();
        this.onDidChangeConnectedEmitter.fire();
    }

    /**
     * One byte the running game clocked out of its link port.
     *
     * Decoded first and handed on second, so that what the panel shows is the
     * same whether or not the handing on goes anywhere.
     *
     * Every byte fires the change event. That is what keeps the panel live —
     * it polls once a second and would otherwise show an effect after it had
     * finished — and it is affordable because the traffic is a handful of
     * bytes per effect, not a stream.
     */
    async sendByte(byte: number): Promise<void> {
        this.bytes++;
        const command = this.decoder.push(byte);
        if (command) {
            this.commands.push(command);
            if (this.commands.length > HISTORY_LENGTH) {
                this.commands.shift();
            }
        }
        this.onDidChangeConnectedEmitter.fire();
        await this.forward(byte);
    }

    /** Hand the byte to the hardware. There is none here. */
    protected async forward(_byte: number): Promise<void> { }
}

/** One revision of the board, by the USB ids it reports. */
export interface RumblePackDevice {
    /** Which revision this is, as the studio names it. */
    name: string;
    vendor: number;
    product: number;
}

/**
 * The boards that are a Rumble Pack.
 *
 * The studio's table (`ves-rumble-pack-types.ts`) and the desktop shell's
 * (`rumble.rs`) say the same, and have to: a pack recognized by one
 * application and not by another would be a bug nobody could explain. The
 * final board reports itself as an Arduino Leonardo, which it is built on.
 */
export const RUMBLE_PACK_IDS: readonly RumblePackDevice[] = [
    { name: 'Final', vendor: 0x2341, product: 0x8036 },
    { name: 'Prototype', vendor: 0x9999, product: 0x9999 },
];

/** Which board these ids are, or undefined for something that is not a pack. */
export function rumblePackName(vendor?: number, product?: number): string | undefined {
    return RUMBLE_PACK_IDS.find(id => id.vendor === vendor && id.product === product)?.name;
}

/**
 * A pack on a serial line, whatever is carrying the line.
 *
 * Everything above the transport: which board is on the other end, the text
 * protocol it speaks, and the lines it answers with. A host adds the line
 * itself — a port the desktop shell opened, or one `navigator.serial` handed
 * the page — by implementing {@link write} and calling {@link attached} once
 * it has one.
 *
 * Here rather than in each host because it is the same firmware answering
 * either way, and a protocol spelled out twice is a protocol that drifts: the
 * `<VB nnn>` a packaged build sends and the one a browser sends have to stay
 * the same eight characters. See {@link send} for what those are.
 */
export abstract class SerialRumblePack extends DecodingRumblePack {

    /**
     * The least time between two commands, in ms.
     *
     * The board is an ATmega32u4 with a 64-byte serial buffer, and every
     * command it reads turns into an I2C transaction with the motor driver —
     * so it empties that buffer far slower than a 115200-baud line fills it.
     * Eight commands back to back is all the buffer holds, and a game in the
     * middle of something can easily ask for more: the overflow lands
     * mid-command, the parser is left waiting for a `>` that was eaten, and
     * from then on the pack takes nothing and answers nothing until it is
     * unplugged from power.
     *
     * So the wire is paced. Two hundred commands a second is far more than any
     * game asks for — a whole effect is four or five — and far less than the
     * board can be made to choke on.
     */
    protected static readonly WRITE_GAP_MS = 5;

    /**
     * How many commands may be waiting before the oldest are given up on.
     *
     * A bound rather than a queue that grows: haptics that arrive late are not
     * haptics, and a game that outruns the wire for a second and a half is one
     * whose backlog is worth dropping rather than playing out minutes later.
     */
    protected static readonly MAX_QUEUED = 32;

    /** The board on the other end, once there is one. */
    protected current: RumblePackDevice | undefined;
    protected reply: string | undefined;
    /** Bytes the pack has sent that have not yet ended in a newline. */
    protected replyBuffer = '';
    /** Commands waiting for the wire, oldest first. */
    protected queue: string[] = [];
    /** The drain in progress, which is what keeps writes one at a time. */
    protected draining: Promise<void> | undefined;
    protected dropped = 0;

    /** Commands given up on because the game outran the wire. */
    override get droppedCommands(): number {
        return this.dropped;
    }

    override get connected(): boolean {
        return this.current !== undefined;
    }

    override get deviceName(): string | undefined {
        return this.current?.name;
    }

    override get deviceIds(): { vendor?: number, product?: number } | undefined {
        return this.current && { vendor: this.current.vendor, product: this.current.product };
    }

    override get lastReply(): string | undefined {
        return this.reply;
    }

    /** Put text on the wire, exactly as given. The framing is {@link send}'s. */
    protected abstract write(text: string): Promise<void>;

    /**
     * One command, framed the way the firmware reads them, onto the queue.
     *
     * Angle brackets and nothing else — no newline. This is the firmware's
     * own framing and it is not negotiable: VUEngine Studio has driven the
     * hardware this way for years (`ves-rumble-pack-service.ts`), and a
     * newline-terminated `VB 124` is read as no command at all. A pack sent
     * those connects, answers nothing and sits perfectly still, which is a
     * hard fault to see. See the `<VB nnn>` check in `rumble-panel-probe`.
     *
     * Queued rather than written, and the queue is the point — see
     * {@link drain}. Returns as soon as the command is on it: the caller is
     * the emulator's link-port callback, and holding that up would be holding
     * up the game.
     */
    protected async send(command: string): Promise<void> {
        if (this.queue.length >= SerialRumblePack.MAX_QUEUED) {
            // The oldest, because it is the one least worth playing now.
            this.queue.shift();
            this.dropped++;
        }
        this.queue.push(`<${command}>`);
        this.startDraining();
    }

    /**
     * Put the queue on the wire, one command at a time, no faster than
     * {@link WRITE_GAP_MS}.
     *
     * One at a time is not only pacing. The desktop shell writes through a
     * Tauri command, and two of those in flight are two calls on a thread pool
     * that take the port's lock in whatever order they get it — so unawaited
     * writes can reach the pack in the wrong order, which is a frequency
     * arriving as an effect number and an effect as a frequency. A single
     * drain is what makes the order the game's order on every transport.
     */
    protected startDraining(): void {
        this.draining ??= this.drain().finally(() => {
            this.draining = undefined;
        });
    }

    protected async drain(): Promise<void> {
        while (this.queue.length > 0 && this.current) {
            await this.write(this.queue.shift()!);
            if (this.queue.length > 0 && this.current) {
                await new Promise(resolve => {
                    setTimeout(resolve, SerialRumblePack.WRITE_GAP_MS);
                });
            }
        }
        if (!this.current) {
            // Nothing to write to. What is left was for a pack that has gone.
            this.queue.length = 0;
        }
    }

    /**
     * Pick up a pack that is already attached, and watch for one arriving.
     *
     * Called once at start-up, before anything is running. Separate from
     * {@link detect} because this one may not ask the person anything: a pack
     * found here was found without being looked for.
     */
    abstract start(): Promise<void>;

    /** Called by a host once a port is open and answering. */
    protected attached(device: RumblePackDevice): void {
        this.queue.length = 0;
        this.dropped = 0;
        this.current = device;
        this.onDidChangeConnectedEmitter.fire();
    }

    /** Called by a host when the port closes, whoever closed it. */
    protected detached(): void {
        if (!this.current) {
            return;
        }
        this.current = undefined;
        this.replyBuffer = '';
        this.queue.length = 0;
        this.onDidChangeConnectedEmitter.fire();
    }

    /**
     * What the pack said.
     *
     * Kept as whole lines: the firmware answers in text terminated by a
     * newline, and half a line is not something worth showing anyone.
     */
    protected receive(text: string): void {
        this.replyBuffer += text;
        const lines = this.replyBuffer.split(/\r?\n/);
        this.replyBuffer = lines.pop() ?? '';
        let said = false;
        for (const line of lines) {
            if (line.trim().length > 0) {
                this.reply = line.trim();
                said = true;
            }
        }
        if (said) {
            this.onDidChangeConnectedEmitter.fire();
        }
    }

    /** One byte the game sent, relayed as the pack's own `<VB nnn>`. */
    protected override async forward(byte: number): Promise<void> {
        if (!this.current) {
            return;
        }
        await this.send(`VB ${byte.toString().padStart(3, '0')}`);
    }

    /**
     * Stop whatever the motor is doing, on our own account.
     *
     * `STP` rather than a forwarded `VB 000`: the emulator is commanding the
     * device here, not relaying a byte the game sent, and the traffic the
     * panel shows should stay the game's own. Silent with no pack attached —
     * there is nothing running to stop.
     */
    async stop(): Promise<void> {
        if (!this.current) {
            return;
        }
        // Ahead of whatever is waiting, and instead of it: the queue is bytes
        // from a game that is no longer being listened to, and playing them
        // out before stopping would be the motor running on for another
        // second and a half of commands nobody is owed.
        this.queue.length = 0;
        await this.send('STP');
    }
}

/**
 * The command bytes a game sends to the pack.
 *
 * The same protocol VUEngine Studio speaks to the real hardware; the numbers
 * are the device's, not ours.
 */
export const RUMBLE_CMD = {
    STOP: 0x00,
    MIN_EFFECT: 0x01,
    MAX_EFFECT: 0x7b,
    PLAY: 0x7c,
    CHAIN_EFFECT_0: 0x80,
    CHAIN_EFFECT_4: 0x84,
    OVERDRIVE: 0xa0,
    SUSTAIN_POS: 0xa1,
    SUSTAIN_NEG: 0xa2,
    BREAK: 0xa3,
    WRITE_EFFECT_CHAIN: 0xb0,
    WRITE_EFFECT_LOOPS_CHAIN: 0xb1,
    EFFECT_CHAIN_END: 0xff,
} as const;

/** The bytes that select a vibration frequency, and the frequency each means. */
export const RUMBLE_CMD_FREQUENCIES: Record<number, number> = {
    0x87: 50,
    0x88: 95,
    0x89: 130,
    0x90: 160,
    0x91: 240,
    0x92: 320,
    0x93: 400,
};

/** The commands whose meaning is completed by the byte after them. */
function valueCommands(): Record<number, string> {
    return {
        [RUMBLE_CMD.OVERDRIVE]: nls.localize('vueport/debug/panels/rumblePack/effects/overdrive', 'Overdrive'),
        [RUMBLE_CMD.SUSTAIN_POS]: nls.localize('vueport/debug/panels/rumblePack/effects/sustainPos', 'Sustain (Pos.)'),
        [RUMBLE_CMD.SUSTAIN_NEG]: nls.localize('vueport/debug/panels/rumblePack/effects/sustainNeg', 'Sustain (Neg.)'),
        [RUMBLE_CMD.BREAK]: nls.localize('vueport/debug/panels/rumblePack/effects/break', 'Break'),
    };
}

/**
 * Turns the byte stream a game sends into the effect it describes.
 *
 * Stateful because the protocol is: four of the commands take their value from
 * the byte that follows, and the rest accumulate into one effect configuration
 * that the pack plays when told to.
 *
 * In `vueport-core` rather than in a host because there is nothing
 * host-specific about it — it is bytes in, `RumbleCommand` and `RumbleState`
 * out, both of which are declared here.
 */
export class RumbleStreamDecoder {

    protected pending: number | undefined;

    state: RumbleState = {};

    reset(): void {
        this.pending = undefined;
        this.state = {};
    }

    /** Feed one byte. Returns a command once one is complete. */
    /**
     * One byte of the stream, and the command it completed if it completed one.
     *
     * The time is stamped here rather than in each of `decode`'s many answers:
     * one place to be right, and the moment a command is understood is as
     * close to when the game sent it as this side can see.
     */
    push(byte: number): RumbleCommand | undefined {
        const at = Date.now();
        const command = this.decode(byte, at);
        return command && { ...command, at };
    }

    /** `at` is the reading `push` took, so that a Play is stamped by that one. */
    protected decode(byte: number, at: number): Omit<RumbleCommand, 'at'> | undefined {
        if (this.pending !== undefined) {
            const command = this.pending;
            this.pending = undefined;
            return this.applyValue(command, byte);
        }

        if (valueCommands()[byte] !== undefined) {
            this.pending = byte;
            return undefined;
        }

        if (byte === RUMBLE_CMD.STOP) {
            this.state.playing = false;
            this.state.playingSince = undefined;
            return { bytes: [byte], label: nls.localize('vueport/debug/panels/rumblePack/effects/stop', 'Stop') };
        }

        if (byte === RUMBLE_CMD.PLAY) {
            this.state.playing = true;
            // Restamped and counted on every Play, including one that arrives
            // while an effect is already running: a game replaying the same
            // effect is starting it again, and it runs its own length from
            // here.
            this.state.playingSince = at;
            this.state.plays = (this.state.plays ?? 0) + 1;
            return { bytes: [byte], label: nls.localize('vueport/debug/panels/rumblePack/effects/play', 'Play') };
        }

        if (byte >= RUMBLE_CMD.MIN_EFFECT && byte <= RUMBLE_CMD.MAX_EFFECT) {
            this.state.effect = byte;
            return {
                bytes: [byte],
                label: `${nls.localize('vueport/debug/panels/rumblePack/effects/effect', 'Effect')}: ${getRumbleEffectName(byte)}`,
            };
        }

        const frequency = RUMBLE_CMD_FREQUENCIES[byte];
        if (frequency !== undefined) {
            this.state.frequency = frequency;
            return {
                bytes: [byte],
                label: `${nls.localize('vueport/debug/panels/rumblePack/effects/frequency', 'Frequency')}: ${frequency} Hz`,
            };
        }

        if (byte >= RUMBLE_CMD.CHAIN_EFFECT_0 && byte <= RUMBLE_CMD.CHAIN_EFFECT_4) {
            this.state.chain = byte - RUMBLE_CMD.CHAIN_EFFECT_0;
            return {
                bytes: [byte],
                label: nls.localize('vueport/debug/panels/rumblePack/effects/chainEffect', 'Chain Effect {0}', this.state.chain),
            };
        }

        if (byte === RUMBLE_CMD.WRITE_EFFECT_CHAIN || byte === RUMBLE_CMD.WRITE_EFFECT_LOOPS_CHAIN) {
            return {
                bytes: [byte],
                label: nls.localize('vueport/debug/panels/rumblePack/effects/writeEffectChain', 'Write Effect Chain'),
            };
        }

        if (byte === RUMBLE_CMD.EFFECT_CHAIN_END) {
            return {
                bytes: [byte],
                label: nls.localize('vueport/debug/panels/rumblePack/effects/effectChainEnd', 'End of Effect Chain'),
            };
        }

        return {
            bytes: [byte],
            label: nls.localize('vueport/debug/panels/rumblePack/effects/unknownCommand', 'Unknown command'),
            unknown: true,
        };
    }

    /**
     * Names a value command, and swallows the byte that carries its value.
     *
     * None of the four settings survives on current packs — the editor no
     * longer offers them and the engine no longer sends them — so none of them
     * lands in {@link RumbleState}. The decoding stays because older ROMs do
     * send them, and a pair of bytes read as one command is the difference
     * between a log that says `Overdrive: 126` and one that claims effect 126
     * was selected.
     */
    protected applyValue(command: number, value: number): Omit<RumbleCommand, 'at'> {
        return { bytes: [command, value], label: `${valueCommands()[command]}: ${value}` };
    }
}
