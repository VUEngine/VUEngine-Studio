/**
 * Searching memory for the address behind a number on screen.
 *
 * The Action Replay loop, and the half of the Cheats panel that was missing: a
 * cheat is a write to an address (see `emulator-cheats.ts`), and until now
 * VUEPort could only apply one somebody else had already worked out. This is
 * how the address is found in the first place.
 *
 * The method is elimination rather than insight. Take a copy of memory; say
 * something about the value being looked for; keep every address that agrees.
 * Play until the number changes; say what it did; keep every address that
 * agrees with that too. Repeat, and the survivors converge on the one the game
 * actually keeps its lives, its rings or its health in.
 *
 * Two kinds of question can be asked, which is what makes this usable on a game
 * that shows a bar rather than a number:
 *
 *   - against a value the player typed, when the number is on screen to read;
 *   - against what the address held last time, when it is not — "it went down"
 *     is a fact about a health bar even when nobody knows what it went down
 *     *from*.
 *
 * The second kind is why a first pass may start with every address a candidate:
 * with no value to match, nothing has been ruled out yet, and the first real
 * narrowing happens on the pass after it.
 *
 * Everything here is pure — snapshots in, candidate offsets out — so the search
 * can be reasoned about, and tested, without an emulator or a browser.
 */

/**
 * How to read the bytes at an address.
 *
 * The Virtual Boy is little-endian, so a halfword at offset n is
 * `bytes[n] | bytes[n+1] << 8`, and the signed types are the same bytes read as
 * two's complement. Both spellings are offered because a game's counter is
 * usually unsigned and its coordinates usually are not, and searching for -1 in
 * a u16 finds nothing.
 */
export enum ScanDataType {
    U8 = 'u8',
    S8 = 's8',
    U16 = 'u16',
    S16 = 's16',
    U32 = 'u32',
    S32 = 's32',
}

/** The order they are offered in, narrowest first. */
export const SCAN_DATA_TYPES: ScanDataType[] = [
    ScanDataType.U8,
    ScanDataType.S8,
    ScanDataType.U16,
    ScanDataType.S16,
    ScanDataType.U32,
    ScanDataType.S32,
];

/**
 * What is being asked of each candidate.
 *
 * The first four compare against a number the player gave; the last four
 * compare against what the same address held at the previous pass, and need no
 * number at all.
 */
export type ScanOperator =
    | 'eq'
    | 'ne'
    | 'gt'
    | 'lt'
    | 'changed'
    | 'unchanged'
    | 'increased'
    | 'decreased';

export const SCAN_OPERATORS: ScanOperator[] = [
    'eq', 'ne', 'gt', 'lt', 'changed', 'unchanged', 'increased', 'decreased',
];

/**
 * Whether this operator needs a number typed in beside it.
 *
 * The panel asks so it can disable the value box rather than ignore what is in
 * it: a box that accepts a number nothing reads is a box that lies.
 */
export function scanOperatorNeedsValue(op: ScanOperator): boolean {
    return op === 'eq' || op === 'ne' || op === 'gt' || op === 'lt';
}

/** How wide a value of this type is. */
export function scanValueBytes(type: ScanDataType): 1 | 2 | 4 {
    switch (type) {
        case ScanDataType.U8:
        case ScanDataType.S8:
            return 1;
        case ScanDataType.U16:
        case ScanDataType.S16:
            return 2;
        case ScanDataType.U32:
        case ScanDataType.S32:
            return 4;
    }
}

/** Whether this type reads as two's complement. */
export function scanTypeIsSigned(type: ScanDataType): boolean {
    return type === ScanDataType.S8 || type === ScanDataType.S16 || type === ScanDataType.S32;
}

/**
 * The value at an offset, as this type reads it.
 *
 * Little-endian, and sign-extended for the signed types, so what comes back is
 * the number the program running on the machine would see. An offset with fewer
 * bytes after it than the type needs reads as 0 rather than throwing: the
 * callers below never generate one, and a snapshot truncated by something else
 * should not take the panel down.
 */
export function readScanValue(bytes: Uint8Array, offset: number, type: ScanDataType): number {
    const width = scanValueBytes(type);
    if (offset < 0 || offset + width > bytes.length) {
        return 0;
    }
    let value = 0;
    for (let i = 0; i < width; i++) {
        value |= bytes[offset + i] << (i * 8);
    }
    if (scanTypeIsSigned(type)) {
        // The shifts above already sign-extend a 32-bit value; the narrower
        // ones have to be told where their sign bit is.
        const bits = width * 8;
        return bits === 32 ? value | 0 : (value << (32 - bits)) >> (32 - bits);
    }
    return value >>> 0;
}

/**
 * Whether one reading answers the question.
 *
 * `previous` is only consulted by the four relative operators, and `value` only
 * by the four absolute ones, so a caller that has neither to offer can still
 * ask the other kind.
 */
function matches(
    current: number,
    previous: number,
    op: ScanOperator,
    value: number | undefined,
): boolean {
    switch (op) {
        case 'eq':
            return value !== undefined && current === value;
        case 'ne':
            return value !== undefined && current !== value;
        case 'gt':
            return value !== undefined && current > value;
        case 'lt':
            return value !== undefined && current < value;
        case 'changed':
            return current !== previous;
        case 'unchanged':
            return current === previous;
        case 'increased':
            return current > previous;
        case 'decreased':
            return current < previous;
    }
}

/**
 * Every offset a value of this type can start at.
 *
 * Aligned, for the wider types. The V810 wants aligned loads and a compiler
 * gives it them, so a halfword counter sits on an even address and a word one
 * on a multiple of four — and scanning the offsets in between would only invent
 * candidates straddling two unrelated variables. It also cuts the work, and the
 * list the panel has to show, by half or three quarters.
 */
function alignedOffsets(length: number, width: number): number[] {
    const offsets: number[] = [];
    for (let offset = 0; offset + width <= length; offset += width) {
        offsets.push(offset);
    }
    return offsets;
}

/**
 * The first pass: every offset in the snapshot that answers the question.
 *
 * A relative operator has nothing to be relative to yet, so it keeps
 * everything — that is what "I do not know what the value is" means, and the
 * narrowing starts with `scanNext` once the number has been made to move.
 */
export function scanFirst(
    current: Uint8Array,
    type: ScanDataType,
    op: ScanOperator,
    value?: number,
): Uint32Array {
    const width = scanValueBytes(type);
    const offsets = alignedOffsets(current.length, width);
    if (!scanOperatorNeedsValue(op)) {
        return Uint32Array.from(offsets);
    }
    const kept: number[] = [];
    for (const offset of offsets) {
        const reading = readScanValue(current, offset, type);
        if (matches(reading, reading, op, value)) {
            kept.push(offset);
        }
    }
    return Uint32Array.from(kept);
}

/**
 * A later pass: the candidates that still answer the question.
 *
 * `previous` is the snapshot the last pass was made against, so "decreased"
 * means decreased since then rather than since the machine started. Candidates
 * are only ever removed, which is what makes the search converge — and why the
 * panel keeps the sets it has been through, so a pass that narrowed too far can
 * be taken back.
 */
export function scanNext(
    candidates: Uint32Array,
    previous: Uint8Array,
    current: Uint8Array,
    type: ScanDataType,
    op: ScanOperator,
    value?: number,
): Uint32Array {
    const kept: number[] = [];
    for (const offset of candidates) {
        const before = readScanValue(previous, offset, type);
        const after = readScanValue(current, offset, type);
        if (matches(after, before, op, value)) {
            kept.push(offset);
        }
    }
    return Uint32Array.from(kept);
}
