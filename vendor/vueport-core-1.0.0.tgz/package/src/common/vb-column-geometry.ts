/**
 * Where the Virtual Boy's columns land on screen, from the column table.
 *
 * The display unit draws a column at a time onto an oscillating mirror, and
 * the column table says how long each group of 4 columns is lit. Measured on
 * hardware with `column-table-test` (see the vb projects folder): the display
 * period follows the table exactly — Column Length + 1, in units of 200ns —
 * and the mirror swings sinusoidally once per 20ms frame. Nintendo's table is
 * that sinusoid's inverse speed to within a pixel, which is what keeps its
 * columns evenly spaced. Another table therefore spaces them differently: a
 * column given longer leaves a gap before the next, and one shown past the end
 * of the swing comes back the other way.
 *
 * The mirror's motion is not a guess: it is fitted to Nintendo's table, as
 * x(t) = a + b·sin ωt + c·cos ωt with ω from the 20ms frame, and what the fit
 * misses of that table (under a pixel, the table being in whole steps of
 * 200ns) is added back as a correction, so that Nintendo's table maps every
 * column exactly onto itself. Every commercial game uses it, and for those
 * nothing here changes a pixel.
 *
 * Which entries the display uses is up to the servo. The core reads them from
 * where a measured unit settled, `VB_COLUMN_TABLE_START`; the lengths it hands
 * over (`vbGetColumnLengths`) are those of the image shown.
 */

/** Nintendo's recommended column table, Column Length only, as every commercial game loads it. */
export const VB_COLUMN_TABLE: readonly number[] = [
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xE0, 0xBC,
    0xA6, 0x96, 0x8A, 0x82, 0x7A, 0x74, 0x6E, 0x6A, 0x66, 0x62, 0x60, 0x5C, 0x5A, 0x58, 0x56, 0x54,
    0x52, 0x50, 0x50, 0x4E, 0x4C, 0x4C, 0x4A, 0x4A, 0x48, 0x48, 0x46, 0x46, 0x46, 0x44, 0x44, 0x44,
    0x42, 0x42, 0x42, 0x40, 0x40, 0x40, 0x40, 0x40, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x3C,
    0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C,
    0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C, 0x3C,
    0x3C, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x3E, 0x40, 0x40, 0x40, 0x40, 0x40, 0x42, 0x42, 0x42,
    0x44, 0x44, 0x44, 0x46, 0x46, 0x46, 0x48, 0x48, 0x4A, 0x4A, 0x4C, 0x4C, 0x4E, 0x50, 0x50, 0x52,
    0x54, 0x56, 0x58, 0x5A, 0x5C, 0x60, 0x62, 0x66, 0x6A, 0x6E, 0x74, 0x7A, 0x82, 0x8A, 0x96, 0xA6,
    0xBC, 0xE0, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
    0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE, 0xFE,
];

/**
 * The entry each eye's display begins with, left eye first: where the servo of
 * a measured unit settled. Must match the core's reset values of CTA.
 */
export const VB_COLUMN_TABLE_START: readonly [number, number] = [0xB1, 0xAE];

/** Column groups per eye: one table entry per 4 columns. */
export const VB_COLUMN_GROUPS = 96;
const COLUMNS = VB_COLUMN_GROUPS * 4;
/** Seconds per unit of Column Length. */
const UNIT = 200e-9;
/** The mirror's angular frequency: one swing per 20ms frame. */
const OMEGA = 2 * Math.PI / 0.020;

/** One eye's mirror: the fitted sinusoid and what it misses of Nintendo's table. */
interface Mirror {
    a: number;
    b: number;
    c: number;
    /** Column edge times under Nintendo's table, and the fit's error at each. */
    times: Float64Array;
    residuals: Float64Array;
}

/** When each of the 385 column edges is reached, from the start of the eye's display. */
function edgeTimes(lengths: ArrayLike<number>): Float64Array {
    const times = new Float64Array(COLUMNS + 1);
    for (let column = 0; column < COLUMNS; column++) {
        times[column + 1] = times[column] + (lengths[column >> 2] + 1) * UNIT;
    }
    return times;
}

/** The lengths Nintendo's table gives an eye, from where its display begins. */
function referenceLengths(eye: number): number[] {
    const start = VB_COLUMN_TABLE_START[eye];
    return Array.from({ length: VB_COLUMN_GROUPS }, (_, group) => VB_COLUMN_TABLE[(start - group) & 0xFF]);
}

/** Least squares of x = a + b·sin ωt + c·cos ωt through (time, column) pairs. */
function fitMirror(times: Float64Array): Mirror {
    const m = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
    const v = [0, 0, 0];
    times.forEach((time, column) => {
        const f = [1, Math.sin(OMEGA * time), Math.cos(OMEGA * time)];
        for (let i = 0; i < 3; i++) {
            v[i] += f[i] * column;
            for (let j = 0; j < 3; j++) {
                m[i][j] += f[i] * f[j];
            }
        }
    });
    // Gauss-Jordan with partial pivoting on the 3×3 normal equations.
    const rows = m.map((row, i) => [...row, v[i]]);
    for (let i = 0; i < 3; i++) {
        let pivot = i;
        for (let r = i + 1; r < 3; r++) {
            if (Math.abs(rows[r][i]) > Math.abs(rows[pivot][i])) {
                pivot = r;
            }
        }
        [rows[i], rows[pivot]] = [rows[pivot], rows[i]];
        for (let r = 0; r < 3; r++) {
            if (r !== i) {
                const factor = rows[r][i] / rows[i][i];
                for (let col = i; col < 4; col++) {
                    rows[r][col] -= factor * rows[i][col];
                }
            }
        }
    }
    const [a, b, c] = [0, 1, 2].map(i => rows[i][3] / rows[i][i]);
    const residuals = new Float64Array(times.length);
    times.forEach((time, column) => {
        residuals[column] = column - (a + b * Math.sin(OMEGA * time) + c * Math.cos(OMEGA * time));
    });
    return { a, b, c, times, residuals };
}

const mirrors: Mirror[] = [];

function mirrorOf(eye: number): Mirror {
    return mirrors[eye] ??= fitMirror(edgeTimes(referenceLengths(eye)));
}

/**
 * The mirror while it is not yet in step with the display, see
 * `mirrorSpinUp`: the picture `stretch` times as wide as once settled, about
 * its left edge, which stays where it is.
 */
export interface MirrorState {
    stretch: number;
}

const SETTLED: MirrorState = { stretch: 1 };

/** Where the mirror puts light emitted this long after the eye's display began. */
function positionAt(mirror: Mirror, time: number): number {
    const { times, residuals } = mirror;
    // The fit's error, interpolated between Nintendo's edges and held beyond them.
    let correction: number;
    if (time <= times[0]) {
        correction = residuals[0];
    } else if (time >= times[COLUMNS]) {
        correction = residuals[COLUMNS];
    } else {
        let lo = 0;
        let hi = COLUMNS;
        while (hi - lo > 1) {
            const mid = (lo + hi) >> 1;
            if (times[mid] <= time) {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        const share = (time - times[lo]) / (times[hi] - times[lo]);
        correction = residuals[lo] + (residuals[hi] - residuals[lo]) * share;
    }
    return mirror.a + mirror.b * Math.sin(OMEGA * time) + mirror.c * Math.cos(OMEGA * time) + correction;
}

/** Whether an eye was shown with exactly the lengths Nintendo's table gives it. */
export function isReferenceColumns(lengths: ArrayLike<number>, eye: number): boolean {
    const start = VB_COLUMN_TABLE_START[eye];
    for (let group = 0; group < VB_COLUMN_GROUPS; group++) {
        if (lengths[group] !== VB_COLUMN_TABLE[(start - group) & 0xFF]) {
            return false;
        }
    }
    return true;
}

/**
 * The screen position of each of an eye's 385 column edges, in pixels, for
 * the lengths it was shown with. Nintendo's table gives 0, 1, … 384.
 */
export function columnEdges(lengths: ArrayLike<number>, eye: number, state: MirrorState = SETTLED): Float64Array {
    const mirror = mirrorOf(eye);
    // The first column is at 0, which a stretch leaves where it is.
    return edgeTimes(lengths).map(time => positionAt(mirror, time) * state.stretch);
}

/** How the picture looks some frames after the machine is switched on: a mirror state, and how much light is let through. */
export interface SpinUpFrame extends MirrorState {
    light: number;
}

/**
 * The display unit coming to life, frame by frame from power on; undefined
 * once it has settled.
 *
 * Measured on hardware (`column-table-fx`, display switched on at once, cold
 * start filmed twice, in real time and at 240fps): nothing at all for about
 * 4s, whatever the program does, then the whole picture at full brightness,
 * every frame. Its left edge stays put; the rest is stretched from it, the
 * right edge first a little wide, then 6% short, 3.5% wide at 1.75s and a
 * little short again, settled after some 5s. How the first second goes
 * differed between the two starts (the other began 10% wide and came down
 * slowly); the later breathing did not. Four seconds is long to look at
 * nothing every time a game is loaded, so unless `fullDelay` asks for it the
 * wait is shortened; the settling is as measured either way.
 */
export function mirrorSpinUp(frame: number, fullDelay = false): SpinUpFrame | undefined {
    const since = frame / 50 - (fullDelay ? 4 : 0.4);
    if (since < 0) {
        return { stretch: 1, light: 0 };
    }
    if (since > 6.5) {
        return undefined;
    }
    // A damped swing of the width about where it settles, period 2.74s, and
    // the first frames' extra width dying away. Fitted to the real-time video.
    const stretch = 1
        - 0.117 * Math.exp(-since / 1.45) * Math.cos(2 * Math.PI * since / 2.74 - 1.06)
        + 0.093 * Math.exp(-since / 0.4);
    return { stretch, light: 1 };
}

/**
 * How each screen pixel of one eye is lit by the columns: for pixel x, the
 * columns `columns[offsets[x]] … columns[offsets[x + 1] - 1]`, each times its
 * `weights` entry.
 *
 * A column is not lit for the whole of its time but for a pulse at its start
 * — the brightness duration, repeated, a fraction of a microsecond against
 * the ten or more the column lasts — so its light is a thin line where the
 * mirror stood then, not a band across the time it was given. On hardware a
 * column given far more time than its neighbours shows as a line with a gap
 * after it, not as a wider pixel. Each column's light goes to the pixel at
 * its position, shared with the next one by how far between the two it fell;
 * Nintendo's table puts every column exactly on its own pixel. Columns that
 * fall closer than a pixel apart add up there, as light does, and what falls
 * off the screen's 384 pixels is not seen.
 */
export interface ColumnSpread {
    offsets: Uint32Array;
    columns: Uint16Array;
    weights: Float32Array;
}

export function columnSpread(edges: Float64Array): ColumnSpread {
    const lists: { column: number; weight: number }[][] = Array.from({ length: COLUMNS }, () => []);
    const add = (pixel: number, column: number, weight: number): void => {
        if (pixel >= 0 && pixel < COLUMNS && weight > 1e-6) {
            lists[pixel].push({ column, weight });
        }
    };
    for (let column = 0; column < COLUMNS; column++) {
        const position = edges[column];
        const pixel = Math.floor(position);
        const share = position - pixel;
        add(pixel, column, 1 - share);
        add(pixel + 1, column, share);
    }
    const offsets = new Uint32Array(COLUMNS + 1);
    lists.forEach((list, pixel) => {
        offsets[pixel + 1] = offsets[pixel] + list.length;
    });
    const columns = new Uint16Array(offsets[COLUMNS]);
    const weights = new Float32Array(offsets[COLUMNS]);
    lists.forEach((list, pixel) => {
        list.forEach((entry, index) => {
            columns[offsets[pixel] + index] = entry.column;
            weights[offsets[pixel] + index] = entry.weight;
        });
    });
    return { offsets, columns, weights };
}
