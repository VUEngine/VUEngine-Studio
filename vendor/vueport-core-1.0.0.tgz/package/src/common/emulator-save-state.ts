/**
 * The save state file format, and the save RAM a fresh cartridge starts with.
 *
 * Pure functions over buffers: no core, no files, no host. That is deliberate —
 * the container is the one part of saving that has to stay readable across
 * versions of the emulator, so it is worth being able to test it directly and
 * worth keeping it somewhere that a reader can take in whole.
 */

import { EmulatorSramInit, EmulatorSramWindow } from './emulator-sram';
import { VB_REGION_BYTES } from './vb-constants';

/**
 * Save state container.
 *
 * The header guards against loading a state into the wrong game, or one
 * produced by a core whose state layout differs, either of which would
 * otherwise restore convincing nonsense.
 *
 * ```
 *  0  'VESS'
 *  4  version
 *  8  the ROM's size in MBit
 * 12  bytes per machine, as the core hands them over
 * 16  the ROM's 32-byte header
 * 48  how many machines
 * 52  metadata length   ┐
 * 56  thumbnail length  │  the sections, in this order,
 * 60  ESSound length    │  straight after the header
 * 64  body length       ┘
 * ```
 *
 * Everything the save-state browser draws a row from comes before the body,
 * so that it can be read without inflating — or one day without fetching —
 * the machine behind it.
 *
 * Every length is spelt out rather than any of them being implied by the size
 * of the file, because the body is compressed and its size says nothing about
 * how many machines are in it. A file is only taken for a state when its
 * sections add up to exactly its length, which is also what keeps a file of
 * an earlier pre-release layout — one of them was numbered 1 as well — from
 * being read as one.
 */
export const STATE_MAGIC = 0x56455353; // 'VESS'
/** Written into every file, and the only version read back. */
export const STATE_VERSION = 1;
export const STATE_HEADER_BYTES = 68;

/** Where in the header the machine count and the section lengths are. */
const AT_MACHINES = 48;
const AT_META = 52;
const AT_THUMBNAIL = 56;
const AT_ES_SOUND = 60;
const AT_BODY = 64;
/** The section lengths, in the order the sections follow the header. */
const AT_SECTIONS = [AT_META, AT_THUMBNAIL, AT_ES_SOUND, AT_BODY];

/**
 * How the body is compressed.
 *
 * gzip rather than raw deflate, for the eight bytes at its end: a checksum and
 * the length it inflates to, which turn a file damaged on disk or on its way
 * between machines into a refusal rather than a machine restored from garbage.
 * It is built into every browser this runs in and into Node, so it costs no
 * library — and the core's state is mostly tables derived from video memory
 * and pictures of the screen, which is why it shrinks by fifteen to sixty
 * times.
 */
const STATE_COMPRESSION: CompressionFormat = 'gzip';

/**
 * How much of the save window comes up the way a real cartridge's SRAM does.
 *
 * This is a size in the cartridge's *address space*, not a count of storage
 * cells: only the low byte of each halfword is wired to the SRAM chip on every
 * game pak ever made, so the 8 KiB one actually holds spans 16 KiB of bus.
 * Lemur, which runs the same core, allocates the same 16 KiB.
 *
 * A cartridge is given the whole of {@link SAVE_RAM_WINDOW} rather than this,
 * so the figure is no longer a capacity — it is the line between the part of
 * the window that powers up like a chip and the part that is not a chip at
 * all. See {@link freshSaveRam}, which fills the two differently, and
 * {@link saveRamHighWater}, which is only able to tell what a game used
 * because it does.
 */
export const DEFAULT_SAVE_RAM_SIZE = 16384;

/**
 * The save RAM a cartridge is actually given: the whole of Game Pak RAM.
 *
 * The Virtual Boy decodes an address on three bits, so region 6 is 16 MiB
 * wide however little of it a cartridge answers on. Handing over all of it
 * means no game can ever run out, which is the only way to be right about a
 * size that a Virtual Boy ROM has nowhere to declare — and it costs nothing
 * on disk, because {@link saveRamHighWater} trims the file back to what was
 * used.
 *
 * What it does cost is mirroring: with the whole region backed, no address in
 * it aliases onto another, so a cartridge that answers on 16 KiB is not
 * emulated as one. A deliberate trade, and one that only shows in a game that
 * reads a datum back through a different address than it wrote it through —
 * but it does mean a game asking the hardware how much save RAM it has is
 * told all of it, which on a real cartridge it would not be. Narrowing the
 * window for somebody developing against real hardware is still to be built;
 * `setCartRam` already takes any power of two, so it is a setting and a call,
 * not a change here.
 */
export const SAVE_RAM_WINDOW = VB_REGION_BYTES;

/**
 * Where a state came from, which is the whole of how the browser treats it.
 *
 * `manual` is one somebody asked for. `auto` is one of the rotating snapshots
 * the emulator takes on a timer — a very coarse rewind, kept only until the
 * next few push it out. `suspend` is the single state a ROM is put away with,
 * which the next launch offers to resume from.
 */
export type SaveStateKind = 'manual' | 'auto' | 'suspend';

/**
 * What opening a game does with the `suspend` state it was put away with.
 *
 * Asking is the default, and is what the feature shipped as: opening a game is
 * as often "start this again" as it is "carry on", and a launch that silently
 * dropped somebody back into last night's boss fight would be answering a
 * question nobody was asked. Somebody who only ever means "carry on" says so
 * here once instead of dismissing the same dialog every time.
 *
 * Ignoring is the third answer, and the reason it is not the same as turning
 * the feature off: the state goes on being written every time a game is put
 * away, so the net is still there and the moment is still in the save-state
 * browser to load by hand. What stops is being asked about it — for somebody
 * playing a game from the start for a while who does not want the question at
 * every launch, and does not want to give up the state to be rid of it.
 */
export enum EmulatorResumeStart {
    /** Offer the moment back, and discard it when the offer is declined. */
    ASK = 'ask',
    /** Pick the game up where it was left, without asking. */
    RESUME = 'resume',
    /** Start the game, say nothing, and leave the moment where it is. */
    IGNORE = 'ignore',
}

/**
 * What a state says about itself: when it was taken, what took it, and what
 * the game looked like at that moment.
 *
 * Inside the file rather than beside it, because a state exported to another
 * machine that arrived without its picture and its date would be a row in the
 * browser with nothing to recognize it by — which is the whole of what the
 * browser is for. See {@link STATE_MAGIC} for where in the file it is.
 */
export interface VesEmulatorSaveStateMeta {
    kind: SaveStateKind;
    /** When the state was taken, in milliseconds since the epoch. */
    created: number;
    /** What the person renamed it to, if they did. */
    label?: string;
    /**
     * A PNG of the picture at that moment.
     *
     * Its own section of the file rather than a field of the JSON beside it:
     * spelt out as text it was a third larger than the picture itself.
     */
    thumbnail?: Uint8Array;
    /** The ROM this was taken from, for a state that arrives from elsewhere. */
    romName?: string;
}

/** What `unwrapSaveState` recovers from a file. */
export interface VesEmulatorSaveState {
    states: ArrayBuffer[];
    /** The ESSound section, absent when the state was taken without one. */
    esSound: string | undefined;
    /** The metadata section, absent when it is empty. */
    meta: VesEmulatorSaveStateMeta | undefined;
}

/** What the header binds a state to, so it cannot be loaded into another game. */
export interface VesEmulatorSaveStateIdentity {
    /** The ROM's 32-byte header. */
    romIdentity: Uint8Array;
    /** The ROM's size in MBit. */
    romSize: number;
}

/**
 * The file a save state is written as: a header, what the state says about
 * itself, what ESSound was playing, and one block per simulation of the
 * session, compressed together.
 *
 * A linked pair is snapshotted as a unit: restoring one machine but not the
 * other leaves them disagreeing about the conversation on the link port. The
 * blocks are all the same size, so the header holds that size once and the
 * number of them.
 *
 * The audio is played on the DOM side rather than by the core, so its state is
 * nowhere in the blocks the core hands over — without its section, loading a
 * state would leave whatever was playing before running on.
 */
export async function wrapSaveState(
    states: ArrayBuffer[],
    identity: VesEmulatorSaveStateIdentity,
    esSoundSnapshot: unknown,
    meta?: VesEmulatorSaveStateMeta,
): Promise<Uint8Array> {
    const size = states[0].byteLength;
    const machine = new Uint8Array(size * states.length);
    states.forEach((state, index) => {
        machine.set(new Uint8Array(state), size * index);
    });
    const header = new Uint8Array(STATE_HEADER_BYTES);
    const view = new DataView(header.buffer);
    view.setUint32(0, STATE_MAGIC);
    view.setUint32(4, STATE_VERSION);
    view.setUint32(8, identity.romSize);
    view.setUint32(12, size);
    header.set(identity.romIdentity, 16);
    view.setUint32(AT_MACHINES, states.length);
    return assemble(
        header,
        meta,
        new TextEncoder().encode(JSON.stringify(esSoundSnapshot)),
        await pipe(machine, new CompressionStream(STATE_COMPRESSION)),
    );
}

/**
 * The same file with different metadata, and everything else as it was.
 *
 * What naming a state does, and importing one: neither the machine nor the
 * sound is unpacked for it, the sections after the picture are copied across
 * as they are, still compressed. Throws for any file
 * {@link describeSaveState} would not describe.
 */
export function rewriteSaveStateMeta(stored: Uint8Array, next: VesEmulatorSaveStateMeta): Uint8Array {
    const layout = readLayout(stored);
    if (typeof layout === 'string') {
        throw new Error(layout);
    }
    return assemble(stored, next, layout.esSound, layout.body);
}

/**
 * Read a file back, or say why it cannot be.
 *
 * `expectedCount` is how many simulations are running now, which has to match
 * how many the file holds — see `wrapSaveState`.
 */
export async function unwrapSaveState(
    stored: Uint8Array,
    expectedCount: number,
    identity: VesEmulatorSaveStateIdentity,
): Promise<VesEmulatorSaveState> {
    const layout = readLayout(stored);
    if (typeof layout === 'string') {
        throw new Error(layout);
    }

    const stamp = stored.subarray(16, 16 + identity.romIdentity.length);
    if (!identity.romIdentity.every((byte, index) => byte === stamp[index])) {
        throw new Error('This save state belongs to a different ROM.');
    }

    const count = layout.machines;
    if (count !== expectedCount) {
        throw new Error(count > expectedCount
            ? 'This save state was made by a linked pair of emulators and needs both to be running.'
            : 'This save state was made by a single emulator and cannot be loaded into a linked pair.');
    }

    // Both a stream gzip refuses — its checksum, its stated length — and one
    // that inflates to the wrong size for the header are a file that has been
    // damaged since it was written, and neither is anything to restore.
    const machine = await pipe(layout.body, new DecompressionStream(STATE_COMPRESSION))
        .catch(() => undefined);
    if (!machine || machine.length !== layout.size * count) {
        throw new Error('This save state file is damaged.');
    }

    return {
        // Copies out of a buffer that was inflated for this and nothing else,
        // so each is an ArrayBuffer of its own that can be transferred into
        // the worker without taking another machine's block with it.
        states: Array.from({ length: count }, (unused, index) =>
            machine.buffer.slice(layout.size * index, layout.size * (index + 1))),
        esSound: layout.esSound.length > 0
            ? new TextDecoder().decode(layout.esSound)
            : undefined,
        meta: readMeta(layout),
    };
}

/**
 * How many machines a state holds, and what it says about itself, without
 * taking the body apart.
 *
 * What the save-state browser lists a folder with: it needs the picture, the
 * date and the kind of every state, and has no use at all for the machine
 * behind each one — which is never inflated here. Answers undefined for
 * anything that is not a state file, because a folder beside a ROM is full of
 * files that are not — and a list is a better thing to show than an error
 * about somebody else's file.
 *
 * Deliberately no identity check: this describes a file, it does not load it,
 * and a state belonging to another ROM is exactly what the browser wants to
 * be able to say. `unwrapSaveState` is still the only way in.
 */
export function describeSaveState(stored: Uint8Array): {
    machines: number,
    meta: VesEmulatorSaveStateMeta | undefined,
} | undefined {
    const layout = readLayout(stored);
    return typeof layout === 'string'
        ? undefined
        : { machines: layout.machines, meta: readMeta(layout) };
}

/** A file's sections, as views into it. */
interface StateLayout {
    /** Bytes per machine, uncompressed. */
    size: number;
    machines: number;
    meta: Uint8Array;
    thumbnail: Uint8Array;
    esSound: Uint8Array;
    body: Uint8Array;
}

/**
 * Where everything is in a file, or why it is not a state this build reads.
 *
 * Checked to the byte: the sections must add up to exactly the file, which is
 * what refuses a file cut short, one with something appended, and one of an
 * earlier layout that happens to carry the same version number.
 */
function readLayout(stored: Uint8Array): StateLayout | string {
    if (stored.length < STATE_HEADER_BYTES) {
        return 'This save state file is truncated.';
    }
    const header = new DataView(stored.buffer, stored.byteOffset, STATE_HEADER_BYTES);
    if (header.getUint32(0) !== STATE_MAGIC) {
        return 'This is not a save state file.';
    }
    if (header.getUint32(4) !== STATE_VERSION) {
        return 'This save state was written by a different emulator version.';
    }
    const lengths = AT_SECTIONS.map(word => header.getUint32(word));
    const total = lengths.reduce((sum, length) => sum + length, STATE_HEADER_BYTES);
    if (total > stored.length) {
        return 'This save state file is truncated.';
    }
    const size = header.getUint32(12);
    const machines = header.getUint32(AT_MACHINES);
    if (total < stored.length || size === 0 || machines === 0 || lengths[3] === 0) {
        return 'This save state file is malformed.';
    }
    let at = STATE_HEADER_BYTES;
    const [meta, thumbnail, esSound, body] = lengths.map(length => stored.subarray(at, at += length));
    return { size, machines, meta, thumbnail, esSound, body };
}

/**
 * A file: the header given, with its section lengths filled in, and then the
 * sections in the order {@link STATE_MAGIC} lists them.
 *
 * Only the first {@link STATE_HEADER_BYTES} of `header` are used, so a whole
 * stored file is a header too — which is how renaming keeps its identity.
 */
function assemble(
    header: Uint8Array,
    meta: VesEmulatorSaveStateMeta | undefined,
    esSound: Uint8Array,
    body: Uint8Array,
): Uint8Array {
    const empty = new Uint8Array(0);
    let described = empty;
    if (meta) {
        const { thumbnail, ...text } = meta;
        described = new TextEncoder().encode(JSON.stringify(text));
    }
    const picture = meta?.thumbnail ?? empty;
    const sections = [described, picture, esSound, body];
    const out = new Uint8Array(sections.reduce((sum, section) => sum + section.length, STATE_HEADER_BYTES));
    out.set(header.subarray(0, STATE_HEADER_BYTES), 0);
    const view = new DataView(out.buffer);
    AT_SECTIONS.forEach((word, index) => {
        view.setUint32(word, sections[index].length);
    });
    let at = STATE_HEADER_BYTES;
    for (const section of sections) {
        out.set(section, at);
        at += section.length;
    }
    return out;
}

/**
 * `bytes` through a compression stream, or back through a decompression one.
 *
 * The write is not awaited: it only settles once the other end has been read,
 * which is what the last line does. A stream that fails says so there as
 * well, so the write's own rejection is only kept from being reported as
 * unhandled.
 */
async function pipe(
    bytes: Uint8Array,
    through: CompressionStream | DecompressionStream,
): Promise<Uint8Array<ArrayBuffer>> {
    const writer = through.writable.getWriter();
    writer.write(bytes as BufferSource).catch(() => undefined);
    writer.close().catch(() => undefined);
    return new Uint8Array(await new Response(through.readable).arrayBuffer());
}

/**
 * The metadata section, or nothing at all.
 *
 * Every field is checked, because this is the one part of the file a person
 * can put anything into: a state edited by hand, or written by a version that
 * kept different things here, must leave the browser with a row it can draw
 * rather than a crash.
 */
function readMeta(layout: StateLayout): VesEmulatorSaveStateMeta | undefined {
    if (layout.meta.length === 0) {
        return undefined;
    }
    try {
        const parsed = JSON.parse(new TextDecoder().decode(layout.meta)) as Partial<VesEmulatorSaveStateMeta>;
        const kind = parsed.kind === 'auto' || parsed.kind === 'suspend' ? parsed.kind : 'manual';
        return {
            kind,
            created: typeof parsed.created === 'number' && Number.isFinite(parsed.created)
                ? parsed.created : 0,
            label: typeof parsed.label === 'string' ? parsed.label : undefined,
            // A copy, so that a description kept for the browser does not
            // keep the whole file it was read from alive with it — and made
            // by construction rather than `slice`, which is a view for the
            // `Buffer` some hosts polyfill.
            thumbnail: layout.thumbnail.length > 0 ? new Uint8Array(layout.thumbnail) : undefined,
            romName: typeof parsed.romName === 'string' ? parsed.romName : undefined,
        };
    } catch {
        return undefined;
    }
}

/**
 * The window a cartridge answers on, in bytes, from what the setting says.
 *
 * Anything unrecognized is the whole region. A setting is a string out of a
 * file somebody may have edited, and the whole region is the answer that can
 * never lose a game its save — narrowing on a typo could.
 */
export function saveRamWindowBytes(window: string): number {
    switch (window) {
        case EmulatorSramWindow.W16K: return 16 * 1024;
        case EmulatorSramWindow.W32K: return 32 * 1024;
        case EmulatorSramWindow.W64K: return 64 * 1024;
        case EmulatorSramWindow.W128K: return 128 * 1024;
        case EmulatorSramWindow.W256K: return 256 * 1024;
        case EmulatorSramWindow.W512K: return 512 * 1024;
        case EmulatorSramWindow.W1M: return 1024 * 1024;
        case EmulatorSramWindow.W2M: return 2 * 1024 * 1024;
        case EmulatorSramWindow.W4M: return 4 * 1024 * 1024;
        case EmulatorSramWindow.W8M: return 8 * 1024 * 1024;
        default: return SAVE_RAM_WINDOW;
    }
}

/**
 * The save RAM a cartridge with no save file yet comes up with.
 *
 * Random rather than zeroed by default, because a real cartridge's SRAM powers
 * up holding whatever it happens to hold, and a game that mistakes zeroes for
 * a valid save is a bug worth finding on the developer's machine rather than
 * the player's.
 *
 * Only up to {@link DEFAULT_SAVE_RAM_SIZE} though, and the rest is zero on
 * purpose even when the setting says random. Two reasons, and they point the
 * same way: an uninitialized cell holds noise, but an address beyond the chip
 * is not a cell at all, so zero is the more honest answer for it; and zero is
 * what lets {@link saveRamHighWater} tell afterwards how much of the window a
 * game really used. Randomizing all 16 MiB would cost a measurable pause at
 * every launch, make every save file incompressible, and leave nothing to
 * measure against.
 */
export function freshSaveRam(
    fill: EmulatorSramInit,
    size: number = SAVE_RAM_WINDOW,
): Uint8Array {
    const ram = new Uint8Array(size);
    if (fill === EmulatorSramInit.ZEROES) {
        return ram;
    }
    // Even bytes only: the odd ones are not wired to the chip on any cartridge
    // that exists, so noise in them would be noise the hardware cannot hold.
    // A custom cartridge wiring the full 16 bits is still free to use them —
    // the core addresses the buffer by byte either way — it simply does not
    // find them powered up with anything.
    const chip = Math.min(size, DEFAULT_SAVE_RAM_SIZE);
    for (let i = 0; i < chip; i += 2) {
        ram[i] = Math.floor(Math.random() * 256);
    }
    return ram;
}

/**
 * How far into the window a game has written, in bytes.
 *
 * Reads the answer out of the buffer rather than watching the game write,
 * which is what makes it free: everything above {@link DEFAULT_SAVE_RAM_SIZE}
 * starts as zero (see {@link freshSaveRam}), so a byte that is not zero up
 * there is one a game put there.
 *
 * Never less than the baseline, because below it nothing can be concluded —
 * the region comes up holding noise, and a save file is never written shorter
 * than that anyway.
 *
 * Trimming on this is lossless, which is not obvious and is worth saying
 * plainly: a zero a game wrote into a region that was already zero is not
 * distinguishable from one it never wrote, and the region is zeroed again on
 * the way back in, so cutting at the last non-zero byte cannot lose anything
 * the game would be able to read back.
 */
export function saveRamHighWater(ram: Uint8Array): number {
    const baseline = Math.min(ram.length, DEFAULT_SAVE_RAM_SIZE);
    // A word at a time, which is both faster and how the buffer is aligned.
    // The tail is untouched in the ordinary case, so this walks the whole of
    // it — a few million comparisons, paid only when a save is written out.
    // A view needs both of these; a buffer that is neither is not one this
    // emulator produced, and is walked a byte at a time instead.
    if ((ram.byteOffset & 3) !== 0 || (ram.length & 3) !== 0) {
        for (let at = ram.length - 1; at >= baseline; at--) {
            if (ram[at] !== 0) {
                return at + 1;
            }
        }
        return baseline;
    }
    const start = baseline >> 2;
    const words = new Uint32Array(ram.buffer, ram.byteOffset, ram.length >> 2);
    for (let i = words.length - 1; i >= start; i--) {
        if (words[i] === 0) {
            continue;
        }
        const at = i << 2;
        for (let byte = 3; byte >= 0; byte--) {
            if (ram[at + byte] !== 0) {
                return at + byte + 1;
            }
        }
    }
    return baseline;
}

/**
 * How large the save file for a cartridge that has been written this far is.
 *
 * Rounded up to a power of two because that is what the core accepts back,
 * and floored at the baseline so that a save written by this emulator is
 * always one another Virtual Boy emulator can read.
 *
 * Never smaller than a file that is already there. A save on disk holds what
 * previous sessions wrote, which may reach further up the window than this
 * one ever looked — shrinking it to fit the current session would throw that
 * away, and a save file is the one thing here that must not be lost.
 */
export function saveRamFileSize(used: number, existing = 0): number {
    let size = DEFAULT_SAVE_RAM_SIZE;
    // `existing` is a file length, so it is whatever is on disk rather than
    // something this emulator chose: a hand-edited one is rounded up here
    // instead of being handed to the core, which only accepts powers of two.
    const wanted = Math.max(used, existing);
    while (size < wanted && size < SAVE_RAM_WINDOW) {
        size *= 2;
    }
    return size;
}
