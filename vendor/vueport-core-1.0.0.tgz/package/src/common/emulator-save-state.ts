/**
 * The save state file format, and the save RAM a fresh cartridge starts with.
 *
 * Pure functions over buffers: no core, no files, no host. That is deliberate —
 * the container is the one part of saving that has to stay readable across
 * versions of the emulator, so it is worth being able to test it directly and
 * worth keeping it somewhere that a reader can take in whole.
 */

import { EmulatorSramInit, EmulatorSramWindow } from './emulator-sram';
import { VB_REGION_BYTES } from './vb-constants';

/**
 * Save state container.
 *
 * The header guards against loading a state into the wrong game, or one
 * produced by a core whose state layout differs, either of which would
 * otherwise restore convincing nonsense.
 */
export const STATE_MAGIC = 0x56455353; // 'VESS'
/**
 * Version 2 added the ESSound section; version 3 added the metadata one.
 * Files of either older version are still read — a version 1 file simply
 * restores no audio, and neither of them says when it was taken.
 */
export const STATE_VERSION = 3;
export const STATE_HEADER_BYTES = 48;
/** The current version's extra header words: the ESSound length, then the metadata length. */
export const STATE_EXTRA_BYTES = 8;

/**
 * How many bytes of header words a file of this version carries past
 * {@link STATE_HEADER_BYTES}, which is also where its blocks begin.
 */
function extraBytes(version: number): number {
    return version >= 3 ? 8 : version >= 2 ? 4 : 0;
}

/**
 * How much of the save window comes up the way a real cartridge's SRAM does.
 *
 * This is a size in the cartridge's *address space*, not a count of storage
 * cells: only the low byte of each halfword is wired to the SRAM chip on every
 * game pak ever made, so the 8 KiB one actually holds spans 16 KiB of bus.
 * Lemur, which runs the same core, allocates the same 16 KiB.
 *
 * A cartridge is given the whole of {@link SAVE_RAM_WINDOW} rather than this,
 * so the figure is no longer a capacity — it is the line between the part of
 * the window that powers up like a chip and the part that is not a chip at
 * all. See {@link freshSaveRam}, which fills the two differently, and
 * {@link saveRamHighWater}, which is only able to tell what a game used
 * because it does.
 */
export const DEFAULT_SAVE_RAM_SIZE = 16384;

/**
 * The save RAM a cartridge is actually given: the whole of Game Pak RAM.
 *
 * The Virtual Boy decodes an address on three bits, so region 6 is 16 MiB
 * wide however little of it a cartridge answers on. Handing over all of it
 * means no game can ever run out, which is the only way to be right about a
 * size that a Virtual Boy ROM has nowhere to declare — and it costs nothing
 * on disk, because {@link saveRamHighWater} trims the file back to what was
 * used.
 *
 * What it does cost is mirroring: with the whole region backed, no address in
 * it aliases onto another, so a cartridge that answers on 16 KiB is not
 * emulated as one. A deliberate trade, and one that only shows in a game that
 * reads a datum back through a different address than it wrote it through —
 * but it does mean a game asking the hardware how much save RAM it has is
 * told all of it, which on a real cartridge it would not be. Narrowing the
 * window for somebody developing against real hardware is still to be built;
 * `setCartRam` already takes any power of two, so it is a setting and a call,
 * not a change here.
 */
export const SAVE_RAM_WINDOW = VB_REGION_BYTES;

/**
 * Where a state came from, which is the whole of how the browser treats it.
 *
 * `manual` is one somebody asked for. `auto` is one of the rotating snapshots
 * the emulator takes on a timer — a very coarse rewind, kept only until the
 * next few push it out. `suspend` is the single state a ROM is put away with,
 * which the next launch offers to resume from.
 */
export type SaveStateKind = 'manual' | 'auto' | 'suspend';

/**
 * What opening a game does with the `suspend` state it was put away with.
 *
 * Asking is the default, and is what the feature shipped as: opening a game is
 * as often "start this again" as it is "carry on", and a launch that silently
 * dropped somebody back into last night's boss fight would be answering a
 * question nobody was asked. Somebody who only ever means "carry on" says so
 * here once instead of dismissing the same dialog every time.
 *
 * Ignoring is the third answer, and the reason it is not the same as turning
 * the feature off: the state goes on being written every time a game is put
 * away, so the net is still there and the moment is still in the save-state
 * browser to load by hand. What stops is being asked about it — for somebody
 * playing a game from the start for a while who does not want the question at
 * every launch, and does not want to give up the state to be rid of it.
 */
export enum EmulatorResumeStart {
    /** Offer the moment back, and discard it when the offer is declined. */
    ASK = 'ask',
    /** Pick the game up where it was left, without asking. */
    RESUME = 'resume',
    /** Start the game, say nothing, and leave the moment where it is. */
    IGNORE = 'ignore',
}

/**
 * What a state says about itself: when it was taken, what took it, and what
 * the game looked like at that moment.
 *
 * Inside the file rather than beside it, because a state exported to another
 * machine that arrived without its picture and its date would be a row in the
 * browser with nothing to recognize it by — which is the whole of what the
 * browser is for. The cost is that the picture is read back with the state,
 * which is why the section is last: everything before it is fixed-size, so a
 * reader that only wants the metadata still has to take the file, but never
 * has to understand the blocks.
 */
export interface VesEmulatorSaveStateMeta {
    kind: SaveStateKind;
    /** When the state was taken, in milliseconds since the epoch. */
    created: number;
    /** What the person renamed it to, if they did. */
    label?: string;
    /** A PNG of the picture at that moment, as a `data:` URL. */
    thumbnail?: string;
    /** The ROM this was taken from, for a state that arrives from elsewhere. */
    romName?: string;
}

/** What `unwrapSaveState` recovers from a file. */
export interface VesEmulatorSaveState {
    states: ArrayBuffer[];
    /** The ESSound section, absent in files written before version 2. */
    esSound: string | undefined;
    /** The metadata section, absent in files written before version 3. */
    meta: VesEmulatorSaveStateMeta | undefined;
}

/** What the header binds a state to, so it cannot be loaded into another game. */
export interface VesEmulatorSaveStateIdentity {
    /** The ROM's 32-byte header. */
    romIdentity: Uint8Array;
    /** The ROM's size in MBit. */
    romSize: number;
}

/**
 * The file a save state is written as: a header, one block per simulation of
 * the session, what ESSound was playing, and what the state says about itself.
 *
 * A linked pair is snapshotted as a unit: restoring one machine but not the
 * other leaves them disagreeing about the conversation on the link port. The
 * blobs are all the same size, so their count is implied by the file length and
 * needs no field of its own.
 *
 * The audio is played on the DOM side rather than by the core, so its state is
 * nowhere in the blocks the core hands over — without this last section,
 * loading a state would leave whatever was playing before running on.
 */
export function wrapSaveState(
    states: ArrayBuffer[],
    identity: VesEmulatorSaveStateIdentity,
    esSoundSnapshot: unknown,
    meta?: VesEmulatorSaveStateMeta,
): Uint8Array {
    const size = states[0].byteLength;
    const encoder = new TextEncoder();
    const esSound = encoder.encode(JSON.stringify(esSoundSnapshot));
    const described = meta ? encoder.encode(JSON.stringify(meta)) : new Uint8Array(0);
    const start = STATE_HEADER_BYTES + STATE_EXTRA_BYTES;
    const out = new Uint8Array(
        start + size * states.length + esSound.length + described.length);
    const header = new DataView(out.buffer, 0, start);
    header.setUint32(0, STATE_MAGIC);
    header.setUint32(4, STATE_VERSION);
    header.setUint32(8, identity.romSize);
    header.setUint32(12, size);
    out.set(identity.romIdentity, 16);
    header.setUint32(STATE_HEADER_BYTES, esSound.length);
    header.setUint32(STATE_HEADER_BYTES + 4, described.length);
    states.forEach((state, index) => {
        out.set(new Uint8Array(state), start + size * index);
    });
    out.set(esSound, start + size * states.length);
    out.set(described, start + size * states.length + esSound.length);
    return out;
}

/**
 * Read a file back, or say why it cannot be.
 *
 * `expectedCount` is how many simulations are running now, which has to match
 * how many the file holds — see `wrapSaveState`.
 */
/**
 * `size` bytes from `at`, in an ArrayBuffer of their own.
 *
 * Written out rather than `subarray(...).buffer` — which would be the whole
 * stored buffer — and rather than `slice(...).buffer`, which looks like a copy
 * and is one for a `Uint8Array` but not for a `Buffer`, whose `slice` is
 * `subarray`. A host that polyfills `Buffer` (esbuild does, for VUEngine
 * Studio's frontend) hands back a view either way, and each of these is then
 * transferred into the worker: the first `loadState` would detach the stored
 * save state and the second would find nothing left of it.
 */
function ownedSlice(stored: Uint8Array, at: number, size: number): ArrayBuffer {
    const copy = new Uint8Array(size);
    copy.set(stored.subarray(at, at + size));
    return copy.buffer;
}

export function unwrapSaveState(
    stored: Uint8Array,
    expectedCount: number,
    identity: VesEmulatorSaveStateIdentity,
): VesEmulatorSaveState {
    if (stored.length <= STATE_HEADER_BYTES) {
        throw new Error('This save state file is truncated.');
    }
    // Over the whole file rather than the fixed header: the length words of
    // versions 2 and 3 sit just past it.
    const header = new DataView(stored.buffer, stored.byteOffset, stored.byteLength);
    if (header.getUint32(0) !== STATE_MAGIC) {
        throw new Error('This is not a save state file.');
    }
    const version = header.getUint32(4);
    if (version > STATE_VERSION || version < 1) {
        throw new Error('This save state was written by a different emulator version.');
    }

    const stamp = stored.subarray(16, 16 + identity.romIdentity.length);
    if (!identity.romIdentity.every((byte, index) => byte === stamp[index])) {
        throw new Error('This save state belongs to a different ROM.');
    }

    const size = header.getUint32(12);
    // Version 1 had no sections after the blocks and no words to say how long
    // they are; version 2 had one of each.
    const start = STATE_HEADER_BYTES + extraBytes(version);
    if (stored.length <= start) {
        throw new Error('This save state file is truncated.');
    }
    const esSoundBytes = version >= 2 ? header.getUint32(STATE_HEADER_BYTES) : 0;
    const metaBytes = version >= 3 ? header.getUint32(STATE_HEADER_BYTES + 4) : 0;
    const body = stored.length - start - esSoundBytes - metaBytes;
    if (size === 0 || body <= 0 || body % size !== 0) {
        throw new Error('This save state file is malformed.');
    }

    const count = body / size;
    if (count !== expectedCount) {
        throw new Error(count > expectedCount
            ? 'This save state was made by a linked pair of emulators and needs both to be running.'
            : 'This save state was made by a single emulator and cannot be loaded into a linked pair.');
    }

    const decoder = new TextDecoder();
    return {
        states: Array.from({ length: count }, (unused, index) => {
            const from = start + size * index;
            return ownedSlice(stored, from, size);
        }),
        esSound: esSoundBytes > 0
            ? decoder.decode(stored.subarray(start + body, start + body + esSoundBytes))
            : undefined,
        meta: metaBytes > 0
            ? readMeta(decoder.decode(
                stored.subarray(start + body + esSoundBytes, start + body + esSoundBytes + metaBytes)))
            : undefined,
    };
}

/**
 * How many machines a state holds, and what it says about itself, without
 * taking the blocks apart.
 *
 * What the save-state browser lists a folder with: it needs the picture, the
 * date and the kind of every state, and has no use at all for the megabyte of
 * machine behind each one. Answers undefined for anything that is not a state
 * file, because a folder beside a ROM is full of files that are not — and a
 * list is a better thing to show than an error about somebody else's file.
 *
 * Deliberately no identity check: this describes a file, it does not load it,
 * and a state belonging to another ROM is exactly what the browser wants to
 * be able to say. `unwrapSaveState` is still the only way in.
 */
export function describeSaveState(stored: Uint8Array): {
    version: number,
    machines: number,
    meta: VesEmulatorSaveStateMeta | undefined,
} | undefined {
    if (stored.length <= STATE_HEADER_BYTES + 4) {
        return undefined;
    }
    const header = new DataView(stored.buffer, stored.byteOffset, stored.byteLength);
    if (header.getUint32(0) !== STATE_MAGIC) {
        return undefined;
    }
    const version = header.getUint32(4);
    if (version < 1 || version > STATE_VERSION) {
        return undefined;
    }
    const size = header.getUint32(12);
    const start = STATE_HEADER_BYTES + extraBytes(version);
    const esSoundBytes = version >= 2 ? header.getUint32(STATE_HEADER_BYTES) : 0;
    const metaBytes = version >= 3 ? header.getUint32(STATE_HEADER_BYTES + 4) : 0;
    const body = stored.length - start - esSoundBytes - metaBytes;
    if (size === 0 || body <= 0 || body % size !== 0) {
        return undefined;
    }
    return {
        version,
        machines: body / size,
        meta: metaBytes > 0
            ? readMeta(new TextDecoder().decode(
                stored.subarray(start + body + esSoundBytes, start + body + esSoundBytes + metaBytes)))
            : undefined,
    };
}

/**
 * The metadata section, or nothing at all.
 *
 * Every field is checked, because this is the one part of the file a person
 * can put anything into: a state edited by hand, or written by a version that
 * kept different things here, must leave the browser with a row it can draw
 * rather than a crash.
 */
function readMeta(json: string): VesEmulatorSaveStateMeta | undefined {
    try {
        const parsed = JSON.parse(json) as Partial<VesEmulatorSaveStateMeta>;
        const kind = parsed.kind === 'auto' || parsed.kind === 'suspend' ? parsed.kind : 'manual';
        return {
            kind,
            created: typeof parsed.created === 'number' && Number.isFinite(parsed.created)
                ? parsed.created : 0,
            label: typeof parsed.label === 'string' ? parsed.label : undefined,
            thumbnail: typeof parsed.thumbnail === 'string' && parsed.thumbnail.startsWith('data:image/')
                ? parsed.thumbnail : undefined,
            romName: typeof parsed.romName === 'string' ? parsed.romName : undefined,
        };
    } catch {
        return undefined;
    }
}

/**
 * The window a cartridge answers on, in bytes, from what the setting says.
 *
 * Anything unrecognized is the whole region. A setting is a string out of a
 * file somebody may have edited, and the whole region is the answer that can
 * never lose a game its save — narrowing on a typo could.
 */
export function saveRamWindowBytes(window: string): number {
    switch (window) {
        case EmulatorSramWindow.W16K: return 16 * 1024;
        case EmulatorSramWindow.W32K: return 32 * 1024;
        case EmulatorSramWindow.W64K: return 64 * 1024;
        case EmulatorSramWindow.W128K: return 128 * 1024;
        case EmulatorSramWindow.W256K: return 256 * 1024;
        case EmulatorSramWindow.W512K: return 512 * 1024;
        case EmulatorSramWindow.W1M: return 1024 * 1024;
        case EmulatorSramWindow.W2M: return 2 * 1024 * 1024;
        case EmulatorSramWindow.W4M: return 4 * 1024 * 1024;
        case EmulatorSramWindow.W8M: return 8 * 1024 * 1024;
        default: return SAVE_RAM_WINDOW;
    }
}

/**
 * The save RAM a cartridge with no save file yet comes up with.
 *
 * Random rather than zeroed by default, because a real cartridge's SRAM powers
 * up holding whatever it happens to hold, and a game that mistakes zeroes for
 * a valid save is a bug worth finding on the developer's machine rather than
 * the player's.
 *
 * Only up to {@link DEFAULT_SAVE_RAM_SIZE} though, and the rest is zero on
 * purpose even when the setting says random. Two reasons, and they point the
 * same way: an uninitialized cell holds noise, but an address beyond the chip
 * is not a cell at all, so zero is the more honest answer for it; and zero is
 * what lets {@link saveRamHighWater} tell afterwards how much of the window a
 * game really used. Randomizing all 16 MiB would cost a measurable pause at
 * every launch, make every save file incompressible, and leave nothing to
 * measure against.
 */
export function freshSaveRam(
    fill: EmulatorSramInit,
    size: number = SAVE_RAM_WINDOW,
): Uint8Array {
    const ram = new Uint8Array(size);
    if (fill === EmulatorSramInit.ZEROES) {
        return ram;
    }
    // Even bytes only: the odd ones are not wired to the chip on any cartridge
    // that exists, so noise in them would be noise the hardware cannot hold.
    // A custom cartridge wiring the full 16 bits is still free to use them —
    // the core addresses the buffer by byte either way — it simply does not
    // find them powered up with anything.
    const chip = Math.min(size, DEFAULT_SAVE_RAM_SIZE);
    for (let i = 0; i < chip; i += 2) {
        ram[i] = Math.floor(Math.random() * 256);
    }
    return ram;
}

/**
 * How far into the window a game has written, in bytes.
 *
 * Reads the answer out of the buffer rather than watching the game write,
 * which is what makes it free: everything above {@link DEFAULT_SAVE_RAM_SIZE}
 * starts as zero (see {@link freshSaveRam}), so a byte that is not zero up
 * there is one a game put there.
 *
 * Never less than the baseline, because below it nothing can be concluded —
 * the region comes up holding noise, and a save file is never written shorter
 * than that anyway.
 *
 * Trimming on this is lossless, which is not obvious and is worth saying
 * plainly: a zero a game wrote into a region that was already zero is not
 * distinguishable from one it never wrote, and the region is zeroed again on
 * the way back in, so cutting at the last non-zero byte cannot lose anything
 * the game would be able to read back.
 */
export function saveRamHighWater(ram: Uint8Array): number {
    const baseline = Math.min(ram.length, DEFAULT_SAVE_RAM_SIZE);
    // A word at a time, which is both faster and how the buffer is aligned.
    // The tail is untouched in the ordinary case, so this walks the whole of
    // it — a few million comparisons, paid only when a save is written out.
    // A view needs both of these; a buffer that is neither is not one this
    // emulator produced, and is walked a byte at a time instead.
    if ((ram.byteOffset & 3) !== 0 || (ram.length & 3) !== 0) {
        for (let at = ram.length - 1; at >= baseline; at--) {
            if (ram[at] !== 0) {
                return at + 1;
            }
        }
        return baseline;
    }
    const start = baseline >> 2;
    const words = new Uint32Array(ram.buffer, ram.byteOffset, ram.length >> 2);
    for (let i = words.length - 1; i >= start; i--) {
        if (words[i] === 0) {
            continue;
        }
        const at = i << 2;
        for (let byte = 3; byte >= 0; byte--) {
            if (ram[at + byte] !== 0) {
                return at + byte + 1;
            }
        }
    }
    return baseline;
}

/**
 * How large the save file for a cartridge that has been written this far is.
 *
 * Rounded up to a power of two because that is what the core accepts back,
 * and floored at the baseline so that a save written by this emulator is
 * always one another Virtual Boy emulator can read.
 *
 * Never smaller than a file that is already there. A save on disk holds what
 * previous sessions wrote, which may reach further up the window than this
 * one ever looked — shrinking it to fit the current session would throw that
 * away, and a save file is the one thing here that must not be lost.
 */
export function saveRamFileSize(used: number, existing = 0): number {
    let size = DEFAULT_SAVE_RAM_SIZE;
    // `existing` is a file length, so it is whatever is on disk rather than
    // something this emulator chose: a hand-edited one is rounded up here
    // instead of being handed to the core, which only accepts powers of two.
    const wanted = Math.max(used, existing);
    while (size < wanted && size < SAVE_RAM_WINDOW) {
        size *= 2;
    }
    return size;
}
