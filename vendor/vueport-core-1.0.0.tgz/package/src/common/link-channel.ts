import { Disposable, Emitter, Event } from './emulator-events';
import { ScheduledEdit } from './vb-protocol';

/**
 * What travels between two linked windows.
 *
 * Only inputs, and the little that is needed to agree on what is being played.
 * Not frames, not audio, not machine state: both windows run the whole pair of
 * machines themselves and stay identical because the core is deterministic
 * given the same cartridge and the same inputs on the same frames — which
 * `packages/core/tests/determinism-probe.mjs` is the evidence for.
 *
 * That is why the messages are tiny, and why the same protocol works over a
 * BroadcastChannel between two tabs, over the desktop shell between two
 * windows, and over a data channel between two machines.
 */
export type LinkMessage =
    | LinkHello
    | LinkWelcome
    | LinkBegin
    | LinkResume
    | LinkInput
    | LinkEdit
    | LinkDigest
    | LinkGoodbye;

/** Which end of the cable a window is. */
export type LinkSeat = 1 | 2;

/**
 * Bumped whenever the meaning of anything below changes.
 *
 * Two windows that disagree here cannot play together, and saying so is much
 * better than desyncing three minutes in.
 */
export const LINK_PROTOCOL_VERSION = 3;

/** Sent by a joining window, repeatedly, until it is answered. */
export interface LinkHello {
    kind: 'hello';
    seat: LinkSeat;
    protocol: number;
    /**
     * The cartridge, as the CRC32 string the rest of the emulator identifies
     * a ROM by.
     *
     * Two different games cannot be linked, and the failure if they were would
     * look like a desync rather than like the mistake it is.
     */
    rom: string;
    /**
     * The size of the core's state struct, which is the cheapest thing that
     * changes when the core does. Two windows on different builds would drift
     * apart, so they are stopped here instead.
     */
    core: number;
}

/** The answer, from the window already in the session. */
export interface LinkWelcome {
    kind: 'welcome';
    seat: LinkSeat;
    protocol: number;
    rom: string;
    core: number;
    /**
     * Frames between a button being pressed and the machines acting on it.
     *
     * Decided by the window that answers, so both sides use one number. It
     * buys the time a message needs to cross: too little and the machines
     * stall waiting for each other, too much and the controls feel loose.
     */
    delay: number;
}

/**
 * Start both windows' machines from the same place, at frame zero.
 *
 * Without this there is nothing to be in step *with*. Two windows that just
 * started running would be hundreds of frames apart — one has been playing,
 * the other just opened — and each would be booking input for frames the
 * other had long since passed or not yet reached.
 *
 * So the session begins by putting all four machines back to power-on and
 * restarting the frame count. The cartridge's save RAM travels with it because
 * it is the one piece of a fresh machine that is *not* the same on both sides:
 * one window has the player's save, the other has whatever its own copy of the
 * game came up with, and two machines that disagree about their save disagree
 * about everything a moment later.
 *
 * Sent by player 1's window only, which is why one of the two is the one that
 * answers a hello rather than both answering each other.
 */
export interface LinkBegin {
    kind: 'begin';
    seat: LinkSeat;
    /**
     * The authority's cartridge save RAM, for both windows to start from.
     *
     * Only as far up the window as the game has written, not the window
     * itself: that is 16 MiB by default and this is a message between two
     * windows. What is left out is zero on both sides — see `expandCartRam`.
     */
    cartRam: ArrayBuffer;
    /**
     * How wide the authority's save window is.
     *
     * Sent because it is a setting, and the two windows are two applications
     * whose settings need not agree: a save that answered on 16 KiB in one and
     * 16 MiB in the other would mirror in one and not the other, and the two
     * would part company the first time either read past the smaller. The
     * authority's answer is the one both use, the way its save is.
     *
     * Optional so that a window running a build from before this was sent is
     * understood rather than refused; it means the whole region, which is what
     * that build would have used.
     */
    cartRamWindow?: number;
    /** Always zero: this *is* the first run. See {@link LinkInput.epoch}. */
    epoch: number;
}

/**
 * Put both windows back to a saved moment, and start counting again from
 * there.
 *
 * Loading a save state in a linked session is not something one window can do
 * on its own: a snapshot of one machine says nothing about where its partner
 * was, and two windows resuming from different moments have not resumed at
 * all. So a state covers *both* machines, named by which player each belongs
 * to rather than by whose window they are in — player 1's window has p1 as its
 * own and p2 as its mirror, and player 2's window the other way round.
 */
export interface LinkResume {
    kind: 'resume';
    seat: LinkSeat;
    epoch: number;
    /** Player 1's machine, as `saveState` produced it. */
    p1: ArrayBuffer;
    /** Player 2's machine. */
    p2: ArrayBuffer;
}

/** One seat's controller mask for one frame. The hot path, and the whole point. */
export interface LinkInput {
    kind: 'input';
    seat: LinkSeat;
    frame: number;
    keys: number;
    /**
     * Which run of the session this belongs to.
     *
     * Frame numbers start again at zero every time the session restarts, so
     * without this a message still in flight when a save state is loaded would
     * be taken as input for a frame of the *new* run — the same number, a
     * different moment. Counted up on every restart and ignored if it does not
     * match.
     */
    epoch: number;
}

/**
 * A change made to one of the two machines from outside it, booked against
 * the frame it takes effect on.
 *
 * Cheats and debugger pokes are not something the emulated program does, so
 * nothing carries them from one window to the other the way the cable carries
 * a controller mask — and a change made in one window only is two machines
 * running different games from that frame on. The digest check would notice,
 * and end the session; before this existed that is precisely what switching a
 * cheat on mid-session did.
 *
 * The seat names *the machine being changed*, not the window asking. That is
 * what lets either window aim a poke at either machine: player 1's window
 * sending `seat: 2` is editing its own mirror and player 2's own machine, and
 * both apply it at the same frame. See `scheduleEdits` in `link-session.ts`
 * for how that frame is chosen.
 */
export interface LinkEdit {
    kind: 'edit';
    /** Whose machine is being changed — not who is changing it. */
    seat: LinkSeat;
    /** Which run this belongs to — see {@link LinkInput.epoch}. */
    epoch: number;
    /** The frame both windows apply it on. */
    frame: number;
    edits: ScheduledEdit[];
}

/**
 * What one window's machine looked like at one frame.
 *
 * The safety net under the whole arrangement. Two windows staying identical is
 * a claim about the core being deterministic, and a claim like that should be
 * checked rather than trusted: this window's own machine at frame N is the
 * other window's mirror at frame N, so if the two digests differ, they have
 * come apart and playing on would only make it worse.
 *
 * Cheap enough to send about once a second — a digest costs some 2% of a
 * frame to take.
 */
export interface LinkDigest {
    kind: 'digest';
    seat: LinkSeat;
    /** Which run this is a digest of — see {@link LinkInput.epoch}. */
    epoch: number;
    frame: number;
    digest: number;
}

/**
 * Sent when a window leaves, so the other stops waiting for it.
 *
 * `leaving` is the difference between hanging up and walking out, and the
 * window that hears it can only act sensibly if it is told which: a player who
 * unlinked is still sitting there with the game open and can be linked to
 * again in a moment, so the other window goes back to waiting with its end of
 * the cable still plugged in. A window that is closing is gone, and waiting
 * for it would be waiting for nobody.
 */
export interface LinkGoodbye {
    kind: 'bye';
    seat: LinkSeat;
    /** `session` — unlinked, still open. `window` — going away. */
    leaving: 'session' | 'window';
}

/**
 * A way for two windows to exchange {@link LinkMessage}s.
 *
 * The seam the transports plug into. `BroadcastChannelLink` below is the one
 * for two tabs of the same origin; the desktop shell and netplay are others,
 * and neither changes anything above this line.
 */
export interface LinkChannel extends Disposable {
    send(message: LinkMessage): void;
    readonly onMessage: Event<LinkMessage>;
}

/**
 * Two tabs of the same origin, over a BroadcastChannel.
 *
 * A channel per session id, so two link sessions in one browser do not hear
 * each other. The browser does not deliver a channel's own messages back to
 * the sender, so nothing has to be filtered out here.
 */
export class BroadcastChannelLink implements LinkChannel {

    protected readonly channel: BroadcastChannel;
    protected readonly onMessageEmitter = new Emitter<LinkMessage>();
    readonly onMessage: Event<LinkMessage> = this.onMessageEmitter.event;
    /**
     * Set the moment this end is given up, which is before the channel is
     * actually closed — see {@link dispose}.
     *
     * A closed channel throws on `postMessage` rather than ignoring it, and a
     * session being taken down is exactly when a last input booking can still
     * be on its way out. The throw reached the page as an uncaught error; a
     * window with nothing left to say simply says nothing.
     */
    protected closed = false;

    constructor(sessionId: string) {
        this.channel = new BroadcastChannel(`vueport.link.${sessionId}`);
        this.channel.onmessage = event => {
            const message = event.data as LinkMessage;
            if (message && typeof message.kind === 'string') {
                this.onMessageEmitter.fire(message);
            }
        };
    }

    send(message: LinkMessage): void {
        if (this.closed) {
            return;
        }
        this.channel.postMessage(message);
    }

    /**
     * Stop listening, and close the channel — but not in the same task.
     *
     * `postMessage` hands a message to the browser to deliver and returns; the
     * delivery happens afterwards. Closing the channel in the same task can
     * take a message posted a moment earlier with it, and the one message that
     * is always posted a moment before a channel is disposed of is the
     * goodbye — so the other window would go on believing it was still linked
     * to a session that had ended, which is exactly what it did. The handler
     * comes off at once, so nothing more is heard either way.
     */
    dispose(): void {
        this.channel.onmessage = null;
        this.closed = true;
        setTimeout(() => this.channel.close(), 0);
        this.onMessageEmitter.dispose();
    }
}
