import { Disposable, Emitter, Event } from './emulator-events';
import { ScheduledEdit } from './vb-protocol';

/**
 * What travels between two linked windows.
 *
 * Only inputs, and the little that is needed to agree on what is being played.
 * Not frames, not audio, not machine state: both windows run the whole pair of
 * machines themselves and stay identical because the core is deterministic
 * given the same cartridge and the same inputs on the same frames — which
 * `packages/core/tests/determinism-probe.mjs` is the evidence for.
 *
 * That is why the messages are tiny, and why the same protocol works over a
 * BroadcastChannel between two tabs, over the desktop shell between two
 * windows, and over a data channel between two machines.
 */
export type LinkMessage =
    | LinkHello
    | LinkWelcome
    | LinkBegin
    | LinkHandover
    | LinkResume
    | LinkRestart
    | LinkPause
    | LinkCall
    | LinkInput
    | LinkEdit
    | LinkDigest
    | LinkGoodbye;

/** Which end of the cable a window is. */
export type LinkSeat = 1 | 2;

/**
 * Bumped whenever the meaning of anything below changes.
 *
 * Two windows that disagree here cannot play together, and saying so is much
 * better than desyncing three minutes in.
 */
export const LINK_PROTOCOL_VERSION = 5;

/** Sent by a joining window, repeatedly, until it is answered. */
export interface LinkHello {
    kind: 'hello';
    seat: LinkSeat;
    protocol: number;
    /**
     * The cartridge, as the CRC32 string the rest of the emulator identifies
     * a ROM by.
     *
     * Two different games cannot be linked, and the failure if they were would
     * look like a desync rather than like the mistake it is.
     */
    rom: string;
    /**
     * The size of the core's state struct, which is the cheapest thing that
     * changes when the core does. Two windows on different builds would drift
     * apart, so they are stopped here instead.
     */
    core: number;
    /**
     * What this window's machine is running — `Sim.runningCartridge`. With
     * {@link rejoin}, what decides whether the session can pick up both games
     * where they are rather than restart them: see {@link LinkBegin.hot}.
     */
    running?: string;
    /**
     * Whether this is two windows that have played together linking again,
     * rather than a first link. Only then are two running games picked up as
     * they are: a first link has the second window at the title screen of a
     * game it has just opened, and restarting both is what makes sense.
     */
    rejoin?: boolean;
}

/**
 * One machine as it stands, for the other window's mirror of it: the core's
 * state, and the part of its save the game has written, with the window it
 * answers on. The save travels separately because a state does not hold it.
 */
export interface LinkMachine {
    state: ArrayBuffer;
    cartRam: ArrayBuffer;
    cartRamWindow: number;
}

/** The answer, from the window already in the session. */
export interface LinkWelcome {
    kind: 'welcome';
    seat: LinkSeat;
    protocol: number;
    rom: string;
    core: number;
    /**
     * Frames between a button being pressed and the machines acting on it.
     *
     * Decided by the window that answers, so both sides use one number. It
     * buys the time a message needs to cross: too little and the machines
     * stall waiting for each other, too much and the controls feel loose.
     */
    delay: number;
}

/**
 * Start both windows' machines from the same place, at frame zero.
 *
 * Without this there is nothing to be in step *with*. Two windows that just
 * started running would be hundreds of frames apart — one has been playing,
 * the other just opened — and each would be booking input for frames the
 * other had long since passed or not yet reached.
 *
 * So the session begins by putting all four machines back to power-on and
 * restarting the frame count. The cartridge's save RAM travels with it because
 * it is the one piece of a fresh machine that is *not* the same on both sides:
 * one window has the player's save, the other has whatever its own copy of the
 * game came up with, and two machines that disagree about their save disagree
 * about everything a moment later.
 *
 * Sent by player 1's window only, which is why one of the two is the one that
 * answers a hello rather than both answering each other.
 */
export interface LinkBegin {
    kind: 'begin';
    seat: LinkSeat;
    /**
     * The authority's cartridge save RAM, for both windows to start from.
     *
     * Only as far up the window as the game has written, not the window
     * itself: that is 16 MiB by default and this is a message between two
     * windows. What is left out is zero on both sides — see `expandCartRam`.
     */
    cartRam: ArrayBuffer;
    /**
     * How wide the authority's save window is.
     *
     * Sent because it is a setting, and the two windows are two applications
     * whose settings need not agree: a save that answered on 16 KiB in one and
     * 16 MiB in the other would mirror in one and not the other, and the two
     * would part company the first time either read past the smaller. The
     * authority's answer is the one both use, the way its save is.
     */
    cartRamWindow: number;
    /**
     * The cartridge as the authority's machine runs it, when that is not the
     * file both windows opened — which is what a ROM patch or a VB Color
     * colorization makes it.
     *
     * The hello only checks that both windows opened the same file, and the
     * joining window's own patches are its own business until it links. From
     * then on the authority's image is the game for all four machines: two
     * copies of one machine running different code are a desync from the
     * first instruction the patch touched. Absent when the authority runs the
     * file unpatched.
     */
    image?: ArrayBuffer;
    /**
     * Whether the machines are VB Color consoles. The authority's answer,
     * because a colorized image asks for one in its header and the joining
     * window's settings may say otherwise.
     */
    vbc?: boolean;
    /**
     * Whether the cartridge has an ESSound chip, which is what having tracks
     * beside the ROM amounts to: the chip answers the game's init with an
     * interrupt, and a machine with one and a machine without are running
     * different programs from that moment. The authority's answer, so all four
     * machines agree even when only one window can play the tracks.
     */
    esSound?: boolean;
    /**
     * Player 1's machine as it stands, when the session picks both games up
     * where they are instead of restarting them.
     *
     * Only when relinking two windows that are running the very same code —
     * see {@link LinkHello.rejoin} and {@link LinkHello.running}. Each window
     * then keeps its own machine exactly as it was, save and all, and builds
     * its mirror of the other from the other's state; `cartRam` above and the
     * cartridge fields are ignored. Player 2 answers with a
     * {@link LinkHandover}, and player 1 begins once it has it.
     */
    hot?: LinkMachine;
    /** Always zero: this *is* the first run. See {@link LinkInput.epoch}. */
    epoch: number;
}

/**
 * Player 2's machine as it stands, answering a {@link LinkBegin} that carried
 * player 1's — the other half of picking two running games up as they are.
 */
export interface LinkHandover {
    kind: 'handover';
    seat: LinkSeat;
    machine: LinkMachine;
}

/**
 * Put both windows back to a saved moment, and start counting again from
 * there.
 *
 * Loading a save state in a linked session is not something one window can do
 * on its own: a snapshot of one machine says nothing about where its partner
 * was, and two windows resuming from different moments have not resumed at
 * all. So a state covers *both* machines, named by which player each belongs
 * to rather than by whose window they are in — player 1's window has p1 as its
 * own and p2 as its mirror, and player 2's window the other way round.
 */
export interface LinkResume {
    kind: 'resume';
    seat: LinkSeat;
    epoch: number;
    /** Player 1's machine, as `saveState` produced it. */
    p1: ArrayBuffer;
    /** Player 2's machine. */
    p2: ArrayBuffer;
}

/**
 * Press the reset button on both consoles at once.
 *
 * A reset in one window only would put one copy of a machine back to power-on
 * and leave the other running, and in the worker it also throws away every
 * booking of the run — so it is a restart of the session instead: every
 * machine in both windows back to power-on, the frame count at zero, and the
 * save RAM as it stands, which both windows hold identically.
 */
export interface LinkRestart {
    kind: 'restart';
    seat: LinkSeat;
    /** The run this starts — see {@link LinkInput.epoch}. */
    epoch: number;
}

/**
 * One player paused, or carried on.
 *
 * A paused window books no input, so without this the other one would sit
 * waiting and, ten seconds later, decide the player had gone. Said instead,
 * both windows pause together and either one can carry on for both.
 */
export interface LinkPause {
    kind: 'pause';
    seat: LinkSeat;
    paused: boolean;
}

/**
 * A player pressed link, and is asking the other window to take part again.
 *
 * The hello cannot do this: only player 2 says it, and only a window with a
 * session running says anything. After a session ended by itself — a desync,
 * a player who stopped answering — neither window has one, so without this
 * both players had to press. A window whose session ended that way listens
 * for this, and joins; one whose player unlinked on purpose does not.
 */
export interface LinkCall {
    kind: 'call';
    seat: LinkSeat;
}

/** One seat's controller mask for one frame. The hot path, and the whole point. */
export interface LinkInput {
    kind: 'input';
    seat: LinkSeat;
    frame: number;
    keys: number;
    /**
     * Which run of the session this belongs to.
     *
     * Frame numbers start again at zero every time the session restarts, so
     * without this a message still in flight when a save state is loaded would
     * be taken as input for a frame of the *new* run — the same number, a
     * different moment. Counted up on every restart and ignored if it does not
     * match.
     */
    epoch: number;
}

/**
 * A change made to one of the two machines from outside it, booked against
 * the frame it takes effect on.
 *
 * Cheats and debugger pokes are not something the emulated program does, so
 * nothing carries them from one window to the other the way the cable carries
 * a controller mask — and a change made in one window only is two machines
 * running different games from that frame on. The digest check would notice,
 * and end the session; before this existed that is precisely what switching a
 * cheat on mid-session did.
 *
 * The seat names *the machine being changed*, not the window asking. That is
 * what lets either window aim a poke at either machine: player 1's window
 * sending `seat: 2` is editing its own mirror and player 2's own machine, and
 * both apply it at the same frame. See `scheduleEdits` in `link-session.ts`
 * for how that frame is chosen.
 */
export interface LinkEdit {
    kind: 'edit';
    /** Whose machine is being changed — not who is changing it. */
    seat: LinkSeat;
    /** Which run this belongs to — see {@link LinkInput.epoch}. */
    epoch: number;
    /** The frame both windows apply it on. */
    frame: number;
    edits: ScheduledEdit[];
}

/**
 * What one window's machine looked like at one frame.
 *
 * The safety net under the whole arrangement. Two windows staying identical is
 * a claim about the core being deterministic, and a claim like that should be
 * checked rather than trusted: this window's own machine at frame N is the
 * other window's mirror at frame N, so if the two digests differ, they have
 * come apart and playing on would only make it worse.
 *
 * Cheap enough to send about once a second — a digest costs some 2% of a
 * frame to take.
 */
export interface LinkDigest {
    kind: 'digest';
    seat: LinkSeat;
    /** Which run this is a digest of — see {@link LinkInput.epoch}. */
    epoch: number;
    frame: number;
    digest: number;
}

/**
 * Sent when a window leaves, so the other stops waiting for it.
 *
 * `leaving` is the difference between hanging up and walking out, and the
 * window that hears it can only act sensibly if it is told which: a player who
 * unlinked is still sitting there with the game open and can be linked to
 * again in a moment, so the other window goes back to waiting with its end of
 * the cable still plugged in. A window that is closing is gone, and waiting
 * for it would be waiting for nobody.
 */
export interface LinkGoodbye {
    kind: 'bye';
    seat: LinkSeat;
    /**
     * `session` — unlinked, still open. `window` — going away. `ended` — the
     * session ended by itself on that side (a desync, a player who stopped
     * answering), and the window is still open: both players then pick it
     * back up with one press in either window, see {@link LinkCall}.
     */
    leaving: 'session' | 'window' | 'ended';
}

/**
 * A way for two windows to exchange {@link LinkMessage}s.
 *
 * The seam the transports plug into. `BroadcastChannelLink` below is the one
 * for two tabs of the same origin; the desktop shell and netplay are others,
 * and neither changes anything above this line.
 */
export interface LinkChannel extends Disposable {
    send(message: LinkMessage): void;
    readonly onMessage: Event<LinkMessage>;
}

/**
 * Two tabs of the same origin, over a BroadcastChannel.
 *
 * A channel per session id, so two link sessions in one browser do not hear
 * each other. The browser does not deliver a channel's own messages back to
 * the sender, so nothing has to be filtered out here.
 */
export class BroadcastChannelLink implements LinkChannel {

    protected readonly channel: BroadcastChannel;
    protected readonly onMessageEmitter = new Emitter<LinkMessage>();
    readonly onMessage: Event<LinkMessage> = this.onMessageEmitter.event;
    /**
     * Set the moment this end is given up, which is before the channel is
     * actually closed — see {@link dispose}.
     *
     * A closed channel throws on `postMessage` rather than ignoring it, and a
     * session being taken down is exactly when a last input booking can still
     * be on its way out. The throw reached the page as an uncaught error; a
     * window with nothing left to say simply says nothing.
     */
    protected closed = false;

    constructor(sessionId: string) {
        this.channel = new BroadcastChannel(`vueport.link.${sessionId}`);
        this.channel.onmessage = event => {
            const message = event.data as LinkMessage;
            if (message && typeof message.kind === 'string') {
                this.onMessageEmitter.fire(message);
            }
        };
    }

    send(message: LinkMessage): void {
        if (this.closed) {
            return;
        }
        this.channel.postMessage(message);
    }

    /**
     * Stop listening, and close the channel — but not in the same task.
     *
     * `postMessage` hands a message to the browser to deliver and returns; the
     * delivery happens afterwards. Closing the channel in the same task can
     * take a message posted a moment earlier with it, and the one message that
     * is always posted a moment before a channel is disposed of is the
     * goodbye — so the other window would go on believing it was still linked
     * to a session that had ended, which is exactly what it did. The handler
     * comes off at once, so nothing more is heard either way.
     */
    dispose(): void {
        this.channel.onmessage = null;
        this.closed = true;
        setTimeout(() => this.channel.close(), 0);
        this.onMessageEmitter.dispose();
    }
}
