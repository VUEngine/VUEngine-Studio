# Vendored: the VB Color format-2 exporter and schema

`vbc-patch-export.ts` and `vbc-patch-format.schema.json` are copies from the
"scenes restored" package (`__patches-scenes-restored-COLCTRL-fixed`): exporter
SHA-256 `5de0cf5d…`, schema `d96ee7fb…`. They add the optional editor metadata —
`channels`, `scenes`, `objects` — to the format described by
`VBC_PATCH_FORMAT.md` at the repository root, which is the earlier
"Simplified VB Color Format 2" package's text and does not mention them yet; the
export algorithm is unchanged. The four documents in `src/data/vb-color/` are
that package's, unchanged.

One type-only change on copying: `sha256Hex` passes `bytes as
Uint8Array<ArrayBuffer>` to `crypto.subtle.digest`. TypeScript 5.9's DOM types
no longer accept a `Uint8Array` that might sit on a `SharedArrayBuffer` as a
`BufferSource`; the emitted JavaScript is identical. Re-apply it when the
exporter is updated.

## What it is

Format 2 is palettes plus one compiled BPS. The exporter is the whole of what
turns a document into a ROM: apply the BPS and verify its CRCs, read the palette
ABI from its metadata, write the document's palettes into that table.
`emulator-vb-color.ts` calls it once per build — when a colorization is switched
on, or its edits are applied — and never while the game runs. Nothing of the
patch executes beside the emulator.

It is not VUEPort's code to edit. The exporter is what the patch authors verify
their patches with, and a second copy that drifted from theirs would make
VUEPort run something other than what they tested. Documents, schema and
exporter move together, with no compatibility layer for earlier formats.

The schema is here rather than in `src/data/vb-color/` on purpose: that
directory is copied wholesale into the web build, and a schema is for whoever
writes a patch document, not for anyone running one.

## What used to be here

Until 2026-09-11 this directory held the Phase 1.6 V810 runtime generator and
the declarative format-2 runtime that colorized a game from outside, once a
frame. Both are gone: all game-specific logic is now compiled into the patch's
own BPS by its authors.
