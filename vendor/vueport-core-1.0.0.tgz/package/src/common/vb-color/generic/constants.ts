/** VB Color 1.1 addresses used by the generic bootstrap. */
export const VBC = Object.freeze({
  VBCID0: 0x0307F800,
  VBCID1: 0x0307F802,
  VBCVER: 0x0307F804,
  VBCCTRL: 0x0307F806,
  CPUSPD: 0x0307F808,
  COLCTRL: 0x0307F80A,
  CBKPAL: 0x0307F80C,
  LNKCTRL: 0x0307F80E,
  CHRCTRL: 0x0307F810,
  MEMCTRL: 0x0307F812,
  CELL_ATTR_RAM: 0x03060000,
  OBJ_ATTR_RAM: 0x03070000,
  CRAM: 0x03079000,
  CRAM_BG: 0x03079000,
  CRAM_OBJ: 0x03079400,
});

export const VBCID0_VALUE = 0x4256;
export const VBCID1_VALUE = 0x2143;
export const VBC_ENABLE_KEY = 0xC001;
export const VBC_SUPPORT_ENHANCED = 0x80;

/** CPU-visible base of Game Pak ROM. */
export const ROM_CPU_BASE = 0x07000000;
export const ROM_CPU_END_EXCLUSIVE = 0x08000000;
/** VBC 1.1 permits up to 16 MiB directly addressable ROM. */
export const MAX_ROM_SIZE = 0x01000000;
/** Generic mirror-expansion strategy doubles the input, so source may be at most 8 MiB. */
export const MAX_GENERIC_SOURCE_SIZE = MAX_ROM_SIZE >>> 1;
export const MIN_GENERIC_SOURCE_SIZE = 0x00010000;

/** Header offsets are relative to the physical end of the ROM image. */
export const VBC_SUPPORT_CODE_FROM_END = 0x20C;
export const RESET_VECTOR_FROM_END = 0x10;

export const BG_PALETTE_COUNT = 128;
export const OBJ_PALETTE_COUNT = 128;
export const PALETTE_COUNT = 256;
export const COLORS_PER_PALETTE = 4;
export const CRAM_ENTRY_COUNT = PALETTE_COUNT * COLORS_PER_PALETTE;
export const CRAM_TABLE_BYTES = CRAM_ENTRY_COUNT * 2;

export const GENERATOR_ID = 'vbc-generic-bootstrap-v1';
export const FORMAT_VERSION = 2 as const;
