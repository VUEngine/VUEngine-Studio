/** Tiny V810 encoder containing only the instructions needed by the bootstrap. */

const OP = Object.freeze({
  CMP: 0x03,
  JMP: 0x06,
  MOV_IMM5: 0x10,
  ADD_IMM5: 0x11,
  MOVEA: 0x28,
  ORI: 0x2C,
  MOVHI: 0x2F,
  LD_H: 0x31,
  ST_H: 0x35,
  ST_W: 0x37,
});

export const COND = Object.freeze({
  V: 0x0,
  C: 0x1,
  Z: 0x2,
  NH: 0x3,
  S: 0x4,
  T: 0x5,
  LT: 0x6,
  LE: 0x7,
  NV: 0x8,
  NC: 0x9,
  NZ: 0xA,
  H: 0xB,
  NS: 0xC,
  F: 0xD,
  GE: 0xE,
  GT: 0xF,
});

interface BranchFixup {
  at: number;
  condition: number;
  label: string;
}

export class V810Emitter {
  private readonly data: number[] = [];
  private readonly labels = new Map<string, number>();
  private readonly branches: BranchFixup[] = [];

  get offset(): number {
    return this.data.length;
  }

  private checkReg(reg: number): void {
    if (!Number.isInteger(reg) || reg < 0 || reg > 31) throw new Error(`Invalid V810 register r${reg}.`);
  }

  emit16(word: number): void {
    const value = word & 0xFFFF;
    this.data.push(value & 0xFF, (value >>> 8) & 0xFF);
  }

  private formatI(op: number, r1: number, r2: number): number {
    this.checkReg(r1); this.checkReg(r2);
    return ((op & 0x3F) << 10) | ((r2 & 31) << 5) | (r1 & 31);
  }

  private formatV(op: number, r1: number, r2: number, imm16: number): void {
    this.emit16(this.formatI(op, r1, r2));
    this.emit16(imm16);
  }

  label(name: string): void {
    if (this.labels.has(name)) throw new Error(`Duplicate V810 label '${name}'.`);
    this.labels.set(name, this.offset);
  }

  cmp(r1: number, r2: number): void { this.emit16(this.formatI(OP.CMP, r1, r2)); }
  jmp(reg: number): void { this.checkReg(reg); this.emit16((OP.JMP << 10) | reg); }
  movImm5(value: number, r2: number): void {
    this.checkReg(r2);
    if (!Number.isInteger(value) || value < -16 || value > 15) throw new Error('MOV imm5 out of range.');
    this.emit16((OP.MOV_IMM5 << 10) | ((r2 & 31) << 5) | (value & 31));
  }
  addImm5(value: number, r2: number): void {
    this.checkReg(r2);
    if (!Number.isInteger(value) || value < -16 || value > 15) throw new Error('ADD imm5 out of range.');
    this.emit16((OP.ADD_IMM5 << 10) | ((r2 & 31) << 5) | (value & 31));
  }
  movea(imm16: number, r1: number, r2: number): void { this.formatV(OP.MOVEA, r1, r2, imm16); }
  ori(imm16: number, r1: number, r2: number): void { this.formatV(OP.ORI, r1, r2, imm16); }
  movhi(imm16: number, r1: number, r2: number): void { this.formatV(OP.MOVHI, r1, r2, imm16); }
  ldH(disp16: number, base: number, dest: number): void { this.formatV(OP.LD_H, base, dest, disp16); }
  stH(src: number, disp16: number, base: number): void { this.formatV(OP.ST_H, base, src, disp16); }
  stW(src: number, disp16: number, base: number): void { this.formatV(OP.ST_W, base, src, disp16); }

  loadU32(value: number, reg: number): void {
    const v = value >>> 0;
    this.movhi((v >>> 16) & 0xFFFF, 0, reg);
    this.ori(v & 0xFFFF, reg, reg);
  }

  loadU16(value: number, reg: number): void {
    this.movhi(0, 0, reg);
    this.ori(value & 0xFFFF, reg, reg);
  }

  branch(condition: number, label: string): void {
    if (!Number.isInteger(condition) || condition < 0 || condition > 15) throw new Error('Invalid V810 condition.');
    const at = this.offset;
    this.emit16(0);
    this.branches.push({ at, condition, label });
  }

  nop(): void { this.emit16(0); }

  finish(): Uint8Array {
    for (const fixup of this.branches) {
      const target = this.labels.get(fixup.label);
      if (target === undefined) throw new Error(`Unresolved V810 label '${fixup.label}'.`);
      const disp = target - fixup.at;
      if ((disp & 1) !== 0 || disp < -256 || disp > 254) {
        throw new Error(`V810 branch to '${fixup.label}' out of disp9 range: ${disp}.`);
      }
      const word = 0x8000 | ((fixup.condition & 0xF) << 9) | (disp & 0x1FF);
      this.data[fixup.at] = word & 0xFF;
      this.data[fixup.at + 1] = (word >>> 8) & 0xFF;
    }
    return Uint8Array.from(this.data);
  }
}

/** 16-byte reset vector: load absolute address into r10, JMP [r10], NOP padding. */
export function buildAbsoluteJumpVector(targetAddress: number): Uint8Array {
  const e = new V810Emitter();
  e.loadU32(targetAddress, 10);
  e.jmp(10);
  while (e.offset < 16) e.nop();
  if (e.offset !== 16) throw new Error(`Reset vector encoder produced ${e.offset} bytes, expected 16.`);
  return e.finish();
}
