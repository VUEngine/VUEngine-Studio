import {
  FORMAT_VERSION,
  GENERATOR_ID,
  MAX_GENERIC_SOURCE_SIZE,
  MIN_GENERIC_SOURCE_SIZE,
  PALETTE_COUNT,
  RESET_VECTOR_FROM_END,
  ROM_CPU_BASE,
  ROM_CPU_END_EXCLUSIVE,
  VBC_SUPPORT_CODE_FROM_END,
  VBC_SUPPORT_ENHANCED,
} from './constants';
import { buildVbcBootstrap } from './bootstrap';
import { applyBps, createMirrorExpansionBps, inspectBps } from './bps';
import { buildAbsoluteJumpVector } from './v810';
import {
  encodeCramTable,
  makeDefaultPalettes,
  normalizePalettes,
  type VbcPalette,
} from './palette';

export interface EmbeddedBpsPatch {
  type: 'bps';
  encoding: 'hex';
  dataHex: string;
}

export interface VbcColorPatchDocument {
  version: 2;
  id: string;
  name: string;
  description: string;
  palettes: VbcPalette[];
  patch: EmbeddedBpsPatch;
}

export interface GeneratorOptions {
  id?: string;
  name?: string;
  description?: string;
  sourceSha256?: string;
  palettes?: readonly VbcPalette[];
}

export interface GenericPatchLayout {
  sourceSize: number;
  targetSize: number;
  upperMirrorOffset: number;
  stubOffset: number;
  stubSize: number;
  paletteTableOffset: number;
  paletteTableSize: number;
  supportCodeOffset: number;
  resetVectorOffset: number;
  stubCpuAddress: number;
  paletteTableCpuAddress: number;
  originalResetCpuAddress: number;
}

export interface GeneratedColorPatch {
  document: VbcColorPatchDocument;
  targetRom: Uint8Array;
  bps: Uint8Array;
  stub: Uint8Array;
  paletteTable: Uint8Array;
  layout: GenericPatchLayout;
}

export class GenericPatchError extends Error {
  constructor(readonly code: string, message: string) {
    super(`${code}: ${message}`);
    this.name = 'GenericPatchError';
  }
}

function align(value: number, alignment: number): number {
  return Math.ceil(value / alignment) * alignment;
}

function isPowerOfTwo(value: number): boolean {
  return value > 0 && (value & (value - 1)) === 0;
}

function slugify(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'new-vb-color-patch';
}

export function bytesToHex(data: Uint8Array): string {
  let out = '';
  for (const byte of data) out += byte.toString(16).padStart(2, '0');
  return out;
}

export function hexToBytes(hex: string): Uint8Array {
  const clean = hex.trim();
  if ((clean.length & 1) !== 0 || !/^[0-9a-fA-F]*$/.test(clean)) throw new Error('Invalid hexadecimal byte string.');
  const out = new Uint8Array(clean.length / 2);
  for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  return out;
}

export function validateGenericSourceRom(sourceRom: Uint8Array): void {
  const size = sourceRom.length;
  if (size < MIN_GENERIC_SOURCE_SIZE) {
    throw new GenericPatchError('E_ROM_TOO_SMALL', `ROM is ${size} bytes; generic bootstrap requires at least ${MIN_GENERIC_SOURCE_SIZE}.`);
  }
  if (!isPowerOfTwo(size)) {
    throw new GenericPatchError('E_ROM_NOT_POWER_OF_TWO', `ROM size ${size} is not a power of two. Pad/normalize the image before using the generic generator.`);
  }
  if (size > MAX_GENERIC_SOURCE_SIZE) {
    throw new GenericPatchError('E_ROM_MAX_SIZE', `ROM is ${size} bytes. Mirror expansion would exceed the 16 MiB VBC ROM aperture; source must be <= 8 MiB.`);
  }
  if (size <= VBC_SUPPORT_CODE_FROM_END || size <= RESET_VECTOR_FROM_END) {
    throw new GenericPatchError('E_ROM_HEADER', 'ROM is too small to contain the standard Virtual Boy header/reset vector.');
  }
  const supportCode = sourceRom[size - VBC_SUPPORT_CODE_FROM_END];
  if (supportCode === 0x80 || supportCode === 0xC0) {
    throw new GenericPatchError('E_ALREADY_VBC', `Source ROM already declares VB Color support code 0x${supportCode.toString(16).toUpperCase()}.`);
  }
}

/**
 * Compute the deterministic mirror-expansion layout.
 * The upper half is a byte-for-byte mirror of the original except for:
 * bootstrap, CRAM table, VBC support byte, and reset vector.
 */
export function computeGenericLayout(sourceSize: number): GenericPatchLayout {
  if (!isPowerOfTwo(sourceSize) || sourceSize < MIN_GENERIC_SOURCE_SIZE || sourceSize > MAX_GENERIC_SOURCE_SIZE) {
    throw new GenericPatchError('E_ROM_SIZE', `Unsupported generic source size ${sourceSize}.`);
  }
  const targetSize = sourceSize * 2;
  const upperMirrorOffset = sourceSize;
  const stubOffset = align(upperMirrorOffset + 0x1000, 16);

  // First pass only establishes deterministic stub size; addresses do not change instruction count.
  const provisional = buildVbcBootstrap({
    paletteTableCpuAddress: ROM_CPU_BASE + stubOffset + 0x400,
    originalResetCpuAddress: ROM_CPU_END_EXCLUSIVE - sourceSize - RESET_VECTOR_FROM_END,
  });
  const paletteTableOffset = align(stubOffset + provisional.length, 16);
  const paletteTableSize = 2048;
  const supportCodeOffset = targetSize - VBC_SUPPORT_CODE_FROM_END;
  const resetVectorOffset = targetSize - RESET_VECTOR_FROM_END;
  if (paletteTableOffset + paletteTableSize >= supportCodeOffset) {
    throw new GenericPatchError('E_LAYOUT_OVERFLOW', 'Bootstrap/palette table collides with ROM header in expanded mirror.');
  }

  const stubCpuAddress = ROM_CPU_BASE + stubOffset;
  const paletteTableCpuAddress = ROM_CPU_BASE + paletteTableOffset;
  const originalResetCpuAddress = ROM_CPU_END_EXCLUSIVE - sourceSize - RESET_VECTOR_FROM_END;
  const finalStub = buildVbcBootstrap({ paletteTableCpuAddress, originalResetCpuAddress });
  if (finalStub.length !== provisional.length) throw new Error('Bootstrap size changed after address relocation.');

  return {
    sourceSize,
    targetSize,
    upperMirrorOffset,
    stubOffset,
    stubSize: finalStub.length,
    paletteTableOffset,
    paletteTableSize,
    supportCodeOffset,
    resetVectorOffset,
    stubCpuAddress,
    paletteTableCpuAddress,
    originalResetCpuAddress,
  };
}

function defaultDescription(sourceSha256?: string): string {
  const hash = sourceSha256 ? ` Source ROM SHA-256 ${sourceSha256}.` : '';
  return `Generic VB Color 1.1 bootstrap patch generated by ${GENERATOR_ID}.${hash} ` +
    'The embedded BPS contains the ROM-side bootstrap and complete 256-palette RGB555 table; the JSON exposes only editable BG/OBJ palettes.';
}

function makeMetadata(layout: GenericPatchLayout, sourceSha256?: string): Record<string, unknown> {
  return {
    vbcFormat: FORMAT_VERSION,
    generator: GENERATOR_ID,
    strategy: 'mirror-expand-bootstrap',
    sts: '1.1',
    sourceSize: layout.sourceSize,
    targetSize: layout.targetSize,
    sourceSha256: sourceSha256 ?? null,
    /*
     * The palette ABI in the shape VUEPort's exporter reads — see
     * `VENDORED.md` beside this file, and `VBC_PATCH_FORMAT.md` at the
     * repository root. The generic table is the whole of Color RAM in order,
     * so a palette's id is its entry index; `paletteAbi` below says the same
     * thing in the kit's own words and is what its CLI reports.
     */
    paletteTable: {
      offset: layout.paletteTableOffset,
      entrySize: 8,
      encoding: 'rgb555le',
      entries: Array.from({ length: PALETTE_COUNT }, (_unused, id) => ({ paletteId: id, index: id })),
    },
    paletteAbi: {
      kind: 'cram-table',
      targetOffset: layout.paletteTableOffset,
      cpuAddress: `0x${layout.paletteTableCpuAddress.toString(16).padStart(8, '0')}`,
      paletteCount: 256,
      colorsPerPalette: 4,
      entryEncoding: 'rgb555-le',
      bytesPerPalette: 8,
    },
    bootstrap: {
      targetOffset: layout.stubOffset,
      cpuAddress: `0x${layout.stubCpuAddress.toString(16).padStart(8, '0')}`,
      size: layout.stubSize,
      originalResetCpuAddress: `0x${layout.originalResetCpuAddress.toString(16).padStart(8, '0')}`,
      supportCode: '0x80',
      enables: ['VBCEN', 'COLEN'],
      intentionallyLeavesDisabled: ['CPUSPD.FAST', 'LNKCTRL.LFAST', 'CHRCTRL.CHREXT', 'MEMCTRL.WRAMEXT'],
    },
  };
}

export function generateGenericColorPatch(sourceRom: Uint8Array, options: GeneratorOptions = {}): GeneratedColorPatch {
  validateGenericSourceRom(sourceRom);
  const layout = computeGenericLayout(sourceRom.length);
  const palettes = normalizePalettes(options.palettes ?? makeDefaultPalettes());
  const paletteTable = encodeCramTable(palettes);
  const stub = buildVbcBootstrap({
    paletteTableCpuAddress: layout.paletteTableCpuAddress,
    originalResetCpuAddress: layout.originalResetCpuAddress,
  });

  const targetRom = new Uint8Array(layout.targetSize);
  targetRom.set(sourceRom, 0);
  targetRom.set(sourceRom, layout.upperMirrorOffset);
  targetRom.set(stub, layout.stubOffset);
  targetRom.set(paletteTable, layout.paletteTableOffset);
  targetRom[layout.supportCodeOffset] = VBC_SUPPORT_ENHANCED;
  targetRom.set(buildAbsoluteJumpVector(layout.stubCpuAddress), layout.resetVectorOffset);

  const metadata = makeMetadata(layout, options.sourceSha256);
  const bps = createMirrorExpansionBps(sourceRom, targetRom, metadata);
  // Internal round-trip assertion catches encoder/layout errors before a patch is handed to VUEPort.
  const roundTrip = applyBps(sourceRom, bps);
  if (roundTrip.length !== targetRom.length || roundTrip.some((v, i) => v !== targetRom[i])) {
    throw new Error('Internal BPS round-trip verification failed.');
  }

  const name = options.name ?? 'New VB Color Patch';
  const document: VbcColorPatchDocument = {
    version: FORMAT_VERSION,
    id: options.id ?? slugify(name),
    name,
    description: options.description ?? defaultDescription(options.sourceSha256),
    palettes,
    patch: { type: 'bps', encoding: 'hex', dataHex: bytesToHex(bps) },
  };
  return { document, targetRom, bps, stub, paletteTable, layout };
}

/** Recompile the embedded BPS from an edited format-v2 document. */
export function rebuildGenericColorPatch(
  sourceRom: Uint8Array,
  document: VbcColorPatchDocument,
  sourceSha256?: string,
): GeneratedColorPatch {
  validateColorPatchDocument(document, true);
  return generateGenericColorPatch(sourceRom, {
    id: document.id,
    name: document.name,
    description: document.description,
    sourceSha256,
    palettes: document.palettes,
  });
}

/** Verify and apply the BPS embedded in a finished format-v2 document. */
export function applyEmbeddedColorPatch(sourceRom: Uint8Array, document: VbcColorPatchDocument): Uint8Array {
  validateColorPatchDocument(document, false);
  return applyBps(sourceRom, hexToBytes(document.patch.dataHex));
}

export function inspectEmbeddedColorPatch(document: VbcColorPatchDocument): ReturnType<typeof inspectBps> {
  validateColorPatchDocument(document, false);
  return inspectBps(hexToBytes(document.patch.dataHex));
}

/** `allowDraft=true` accepts an empty BPS only for the editor's new-document template. */
export function validateColorPatchDocument(document: VbcColorPatchDocument, allowDraft = false): void {
  if (!document || document.version !== 2) throw new Error('VB Color document must use version 2.');
  if (typeof document.id !== 'string' || !document.id) throw new Error('VB Color document id is required.');
  if (typeof document.name !== 'string' || !document.name) throw new Error('VB Color document name is required.');
  normalizePalettes(document.palettes);
  if (!document.patch || document.patch.type !== 'bps' || document.patch.encoding !== 'hex') {
    throw new Error('VB Color v2 document must contain a hex-encoded BPS patch.');
  }
  if (!allowDraft && document.patch.dataHex.length === 0) throw new Error('Finished VB Color document has an empty BPS payload.');
  if (document.patch.dataHex.length > 0) inspectBps(hexToBytes(document.patch.dataHex));
}
