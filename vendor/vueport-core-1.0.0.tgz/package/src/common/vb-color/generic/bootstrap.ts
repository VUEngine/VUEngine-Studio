import {
  CRAM_ENTRY_COUNT,
  VBC,
  VBC_ENABLE_KEY,
  VBCID0_VALUE,
  VBCID1_VALUE,
} from './constants';
import { COND, V810Emitter } from './v810';

export interface BootstrapLayout {
  paletteTableCpuAddress: number;
  originalResetCpuAddress: number;
}

/**
 * Build the ROM-side bootstrap. It is deliberately conservative:
 * - detects VBC before touching VBC state;
 * - enables only VBCEN and COLEN;
 * - leaves CPUSPD, LNKCTRL, CHRCTRL and MEMCTRL at reset defaults;
 * - clears Cell/OBJ Color Attribute RAM so legacy GPLTS/JPLTS select palettes 0..3;
 * - uploads all 1024 RGB555 CRAM entries;
 * - jumps to the original, byte-unchanged reset vector.
 *
 * No stack or WRAM is used, so this can execute before the original game's startup.
 */
export function buildVbcBootstrap(layout: BootstrapLayout): Uint8Array {
  const e = new V810Emitter();
  const R_BASE = 10;
  const R_TMP = 11;
  const R_COUNT = 12;
  const R_SRC = 13;
  const R_DST = 14;

  // VBC presence check using VBCID0 / VBCID1.
  e.loadU32(VBC.VBCID0, R_BASE);
  e.ldH(0, R_BASE, R_TMP);
  e.loadU16(VBCID0_VALUE, R_COUNT);
  e.cmp(R_COUNT, R_TMP);
  e.branch(COND.NZ, 'passthrough');

  e.ldH(2, R_BASE, R_TMP);
  e.loadU16(VBCID1_VALUE, R_COUNT);
  e.cmp(R_COUNT, R_TMP);
  e.branch(COND.NZ, 'passthrough');

  // Master VBC gate. Extended character and WRAM decoding remain opt-in/off.
  e.loadU16(VBC_ENABLE_KEY, R_TMP);
  e.stH(R_TMP, VBC.VBCCTRL - VBC.VBCID0, R_BASE);

  // Clear 64 KiB Cell Color Attribute RAM as 16,384 words.
  e.loadU32(VBC.CELL_ATTR_RAM, R_BASE);
  e.loadU16(0x4000, R_COUNT);
  e.label('clear_cell');
  e.stW(0, 0, R_BASE);
  e.addImm5(4, R_BASE);
  e.addImm5(-1, R_COUNT);
  e.branch(COND.NZ, 'clear_cell');

  // Clear 1 KiB OBJ Color Attribute RAM as 256 words.
  e.loadU32(VBC.OBJ_ATTR_RAM, R_BASE);
  e.loadU16(0x0100, R_COUNT);
  e.label('clear_obj');
  e.stW(0, 0, R_BASE);
  e.addImm5(4, R_BASE);
  e.addImm5(-1, R_COUNT);
  e.branch(COND.NZ, 'clear_obj');

  // Copy 1024 RGB555 words from ROM into VBC Color RAM.
  e.loadU32(layout.paletteTableCpuAddress, R_SRC);
  e.loadU32(VBC.CRAM, R_DST);
  e.loadU16(CRAM_ENTRY_COUNT, R_COUNT);
  e.label('copy_cram');
  e.ldH(0, R_SRC, R_TMP);
  e.stH(R_TMP, 0, R_DST);
  e.addImm5(2, R_SRC);
  e.addImm5(2, R_DST);
  e.addImm5(-1, R_COUNT);
  e.branch(COND.NZ, 'copy_cram');

  // At hardware reset the display/XP are inactive, so COLEN may be enabled safely here.
  e.loadU32(VBC.VBCID0, R_BASE);
  e.movImm5(1, R_TMP);
  e.stH(R_TMP, VBC.COLCTRL - VBC.VBCID0, R_BASE);

  // Both successful VBC init and non-VBC passthrough continue at the original reset vector.
  e.label('passthrough');
  e.loadU32(layout.originalResetCpuAddress, R_BASE);
  e.jmp(R_BASE);

  return e.finish();
}
