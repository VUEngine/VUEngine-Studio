import {
  BG_PALETTE_COUNT,
  COLORS_PER_PALETTE,
  CRAM_TABLE_BYTES,
  PALETTE_COUNT,
  VBC,
} from './constants';

export type ChannelId = 'bg' | 'obj';
export type HexColor = `#${string}`;

export interface VbcPalette {
  id: number;
  name: string;
  channelId: ChannelId;
  colors: [HexColor, HexColor, HexColor, HexColor];
}

export const DEFAULT_VB_RED_RAMP: readonly HexColor[] = [
  '#000000',
  '#520000',
  '#AD0000',
  '#FF0000',
] as const;

function normalizeHex(color: string): string {
  const s = color.trim();
  if (!/^#[0-9a-fA-F]{6}$/.test(s)) {
    throw new Error(`Invalid RGB color '${color}'. Expected #RRGGBB.`);
  }
  return s.toUpperCase();
}

export function rgb888ToRgb555(color: string): number {
  const c = normalizeHex(color);
  const r8 = Number.parseInt(c.slice(1, 3), 16);
  const g8 = Number.parseInt(c.slice(3, 5), 16);
  const b8 = Number.parseInt(c.slice(5, 7), 16);
  const r5 = Math.round((r8 * 31) / 255) & 31;
  const g5 = Math.round((g8 * 31) / 255) & 31;
  const b5 = Math.round((b8 * 31) / 255) & 31;
  return r5 | (g5 << 5) | (b5 << 10);
}

export function rgb555ToRgb888(value: number): HexColor {
  const r5 = value & 31;
  const g5 = (value >>> 5) & 31;
  const b5 = (value >>> 10) & 31;
  const expand = (v: number) => ((v << 3) | (v >>> 2)) & 0xFF;
  const hex = (v: number) => v.toString(16).padStart(2, '0').toUpperCase();
  return `#${hex(expand(r5))}${hex(expand(g5))}${hex(expand(b5))}`;
}

export function makeDefaultPalettes(): VbcPalette[] {
  const ramp = DEFAULT_VB_RED_RAMP as [HexColor, HexColor, HexColor, HexColor];
  const palettes: VbcPalette[] = [];
  for (let id = 0; id < PALETTE_COUNT; id += 1) {
    const isBg = id < BG_PALETTE_COUNT;
    const local = isBg ? id : id - BG_PALETTE_COUNT;
    palettes.push({
      id,
      name: `${isBg ? 'BG' : 'OBJ'} Palette ${local}`,
      channelId: isBg ? 'bg' : 'obj',
      colors: [...ramp] as [HexColor, HexColor, HexColor, HexColor],
    });
  }
  return palettes;
}

export function validatePalette(palette: VbcPalette): void {
  if (!Number.isInteger(palette.id) || palette.id < 0 || palette.id >= PALETTE_COUNT) {
    throw new Error(`Palette id ${palette.id} is outside 0..255.`);
  }
  const expected: ChannelId = palette.id < BG_PALETTE_COUNT ? 'bg' : 'obj';
  if (palette.channelId !== expected) {
    throw new Error(`Palette ${palette.id} must use channel '${expected}', not '${palette.channelId}'.`);
  }
  if (!Array.isArray(palette.colors) || palette.colors.length !== COLORS_PER_PALETTE) {
    throw new Error(`Palette ${palette.id} must contain exactly four colors.`);
  }
  for (const color of palette.colors) normalizeHex(color);
}

export function normalizePalettes(palettes: readonly VbcPalette[]): VbcPalette[] {
  const result = makeDefaultPalettes();
  const seen = new Set<number>();
  for (const palette of palettes) {
    validatePalette(palette);
    if (seen.has(palette.id)) throw new Error(`Duplicate palette id ${palette.id}.`);
    seen.add(palette.id);
    result[palette.id] = {
      ...palette,
      colors: palette.colors.map(normalizeHex) as [HexColor, HexColor, HexColor, HexColor],
    };
  }
  return result;
}

/** Encode all 256 four-color palettes as 1024 little-endian RGB555 words. */
export function encodeCramTable(palettes: readonly VbcPalette[]): Uint8Array {
  const normalized = normalizePalettes(palettes);
  const out = new Uint8Array(CRAM_TABLE_BYTES);
  let p = 0;
  for (const palette of normalized) {
    for (const color of palette.colors) {
      const value = rgb888ToRgb555(color);
      out[p++] = value & 0xFF;
      out[p++] = (value >>> 8) & 0x7F;
    }
  }
  return out;
}

export interface PaletteSelector {
  channelId: ChannelId;
  globalPaletteId: number;
  localPalette: number;
  legacyPalette: number;
  colorAttribute: number;
}

/**
 * Convert a global palette id to VBC 1.1's split selector:
 * low two bits stay in GPLTS/JPLTS, high five bits go to Color Attribute RAM.
 */
export function paletteSelector(globalPaletteId: number): PaletteSelector {
  if (!Number.isInteger(globalPaletteId) || globalPaletteId < 0 || globalPaletteId >= PALETTE_COUNT) {
    throw new Error(`Palette id ${globalPaletteId} is outside 0..255.`);
  }
  const channelId: ChannelId = globalPaletteId < BG_PALETTE_COUNT ? 'bg' : 'obj';
  const localPalette = channelId === 'bg' ? globalPaletteId : globalPaletteId - BG_PALETTE_COUNT;
  return {
    channelId,
    globalPaletteId,
    localPalette,
    legacyPalette: localPalette & 3,
    colorAttribute: (localPalette >>> 2) & 0x1F,
  };
}

/** CPU address of the first RGB555 entry for a global palette id. */
export function cramAddressForPalette(globalPaletteId: number): number {
  paletteSelector(globalPaletteId); // range validation
  return VBC.CRAM + globalPaletteId * 8;
}

/** Four direct 16-bit CRAM writes useful for live editor preview; persistence still goes into the BPS. */
export function palettePreviewWrites(palette: VbcPalette): Array<{ address: number; value: number }> {
  validatePalette(palette);
  const base = cramAddressForPalette(palette.id);
  return palette.colors.map((color, i) => ({
    address: base + i * 2,
    value: rgb888ToRgb555(color),
  }));
}
