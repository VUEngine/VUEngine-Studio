/** Minimal dependency-free BPS encoder/decoder with CRC verification. */

const ACTION_SOURCE_READ = 0;
const ACTION_TARGET_READ = 1;
const ACTION_SOURCE_COPY = 2;
const ACTION_TARGET_COPY = 3;

function concat(chunks: readonly Uint8Array[]): Uint8Array {
  let length = 0;
  for (const c of chunks) length += c.length;
  const out = new Uint8Array(length);
  let p = 0;
  for (const c of chunks) { out.set(c, p); p += c.length; }
  return out;
}

export function crc32(data: Uint8Array): number {
  let crc = 0xFFFFFFFF;
  for (const byte of data) {
    crc ^= byte;
    for (let i = 0; i < 8; i += 1) {
      crc = (crc >>> 1) ^ ((crc & 1) ? 0xEDB88320 : 0);
    }
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function u32le(value: number): Uint8Array {
  const v = value >>> 0;
  return Uint8Array.of(v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF);
}

function readU32le(data: Uint8Array, offset: number): number {
  return (data[offset] | (data[offset + 1] << 8) | (data[offset + 2] << 16) | (data[offset + 3] << 24)) >>> 0;
}

/** BPS's biased little-endian base-128 integer. */
export function encodeNumber(input: number): Uint8Array {
  if (!Number.isSafeInteger(input) || input < 0) throw new Error(`Invalid BPS integer ${input}.`);
  let value = input;
  const out: number[] = [];
  while (true) {
    const x = value & 0x7F;
    value = Math.floor(value / 128);
    if (value === 0) {
      out.push(x | 0x80);
      break;
    }
    out.push(x);
    value -= 1;
  }
  return Uint8Array.from(out);
}

function encodeSigned(value: number): Uint8Array {
  const mapped = value < 0 ? ((-value) * 2 + 1) : (value * 2);
  return encodeNumber(mapped);
}

class Reader {
  constructor(readonly data: Uint8Array, public p = 0) {}
  byte(): number {
    if (this.p >= this.data.length) throw new Error('Unexpected end of BPS patch.');
    return this.data[this.p++];
  }
  number(): number {
    let data = 0;
    let shift = 1;
    while (true) {
      const x = this.byte();
      data += (x & 0x7F) * shift;
      if ((x & 0x80) !== 0) return data;
      shift *= 128;
      data += shift;
      if (!Number.isSafeInteger(data)) throw new Error('BPS integer overflow.');
    }
  }
  signed(): number {
    const v = this.number();
    const magnitude = Math.floor(v / 2);
    return (v & 1) ? -magnitude : magnitude;
  }
  bytes(length: number): Uint8Array {
    const end = this.p + length;
    if (end > this.data.length) throw new Error('Unexpected end of BPS patch.');
    const out = this.data.slice(this.p, end);
    this.p = end;
    return out;
  }
}

interface DiffRange { start: number; end: number; }

function findMergedDiffRanges(source: Uint8Array, upper: Uint8Array, mergeGap = 8): DiffRange[] {
  if (source.length !== upper.length) throw new Error('Mirror halves differ in size.');
  const raw: DiffRange[] = [];
  let i = 0;
  while (i < source.length) {
    if (source[i] === upper[i]) { i += 1; continue; }
    const start = i;
    while (i < source.length && source[i] !== upper[i]) i += 1;
    raw.push({ start, end: i });
  }
  if (raw.length < 2) return raw;
  const merged: DiffRange[] = [raw[0]];
  for (let n = 1; n < raw.length; n += 1) {
    const prev = merged[merged.length - 1];
    const next = raw[n];
    if (next.start - prev.end <= mergeGap) prev.end = next.end;
    else merged.push({ ...next });
  }
  return merged;
}

function action(length: number, type: number): Uint8Array {
  if (length <= 0) throw new Error('BPS action length must be positive.');
  return encodeNumber(((length - 1) * 4) + type);
}

export interface BpsMetadata {
  [key: string]: unknown;
}

/**
 * Compact encoder specialized for a target of exactly source||modified(source).
 * The lower half is SourceRead; the upper half is mostly TargetCopy from the lower half,
 * with only changed bootstrap/palette/header/vector regions encoded as TargetRead.
 */
export function createMirrorExpansionBps(
  source: Uint8Array,
  target: Uint8Array,
  metadata: BpsMetadata = {},
): Uint8Array {
  if (target.length !== source.length * 2) throw new Error('Mirror BPS target must be exactly 2x source size.');
  for (let i = 0; i < source.length; i += 1) {
    if (target[i] !== source[i]) throw new Error('Mirror BPS requires an untouched source lower half.');
  }

  const metadataBytes = new TextEncoder().encode(JSON.stringify(metadata));
  const chunks: Uint8Array[] = [
    new TextEncoder().encode('BPS1'),
    encodeNumber(source.length),
    encodeNumber(target.length),
    encodeNumber(metadataBytes.length),
    metadataBytes,
    action(source.length, ACTION_SOURCE_READ),
  ];

  const upper = target.subarray(source.length);
  const ranges = findMergedDiffRanges(source, upper);
  let cursor = 0;
  let targetRelativeOffset = 0;

  const emitTargetCopy = (start: number, length: number) => {
    if (length <= 0) return;
    chunks.push(action(length, ACTION_TARGET_COPY));
    chunks.push(encodeSigned(start - targetRelativeOffset));
    targetRelativeOffset = start + length;
  };

  for (const range of ranges) {
    emitTargetCopy(cursor, range.start - cursor);
    chunks.push(action(range.end - range.start, ACTION_TARGET_READ));
    chunks.push(upper.slice(range.start, range.end));
    cursor = range.end;
  }
  emitTargetCopy(cursor, source.length - cursor);

  const body = concat(chunks);
  const withCrcs = concat([body, u32le(crc32(source)), u32le(crc32(target))]);
  return concat([withCrcs, u32le(crc32(withCrcs))]);
}

export interface ParsedBpsInfo {
  sourceSize: number;
  targetSize: number;
  metadataText: string;
  metadata: unknown;
}

export function inspectBps(patch: Uint8Array): ParsedBpsInfo {
  if (patch.length < 16) throw new Error('BPS patch is too short.');
  const expectedPatchCrc = readU32le(patch, patch.length - 4);
  const actualPatchCrc = crc32(patch.subarray(0, patch.length - 4));
  if (expectedPatchCrc !== actualPatchCrc) throw new Error('BPS patch CRC mismatch.');
  const r = new Reader(patch);
  const magic = new TextDecoder().decode(r.bytes(4));
  if (magic !== 'BPS1') throw new Error('Not a BPS1 patch.');
  const sourceSize = r.number();
  const targetSize = r.number();
  const metadataText = new TextDecoder().decode(r.bytes(r.number()));
  let metadata: unknown = metadataText;
  try { metadata = JSON.parse(metadataText); } catch { /* text metadata is valid too */ }
  return { sourceSize, targetSize, metadataText, metadata };
}

export function applyBps(source: Uint8Array, patch: Uint8Array): Uint8Array {
  if (patch.length < 16) throw new Error('BPS patch is too short.');
  const expectedPatchCrc = readU32le(patch, patch.length - 4);
  if (crc32(patch.subarray(0, patch.length - 4)) !== expectedPatchCrc) throw new Error('BPS patch CRC mismatch.');

  const r = new Reader(patch);
  if (new TextDecoder().decode(r.bytes(4)) !== 'BPS1') throw new Error('Not a BPS1 patch.');
  const sourceSize = r.number();
  const targetSize = r.number();
  r.bytes(r.number()); // metadata
  if (source.length !== sourceSize) throw new Error(`BPS source size mismatch: expected ${sourceSize}, got ${source.length}.`);

  const footerStart = patch.length - 12;
  const target = new Uint8Array(targetSize);
  let out = 0;
  let sourceRelativeOffset = 0;
  let targetRelativeOffset = 0;

  while (out < targetSize) {
    if (r.p >= footerStart) throw new Error('BPS actions ended before target was complete.');
    const data = r.number();
    const type = data & 3;
    const length = Math.floor(data / 4) + 1;
    if (out + length > targetSize) throw new Error('BPS action overruns target size.');

    if (type === ACTION_SOURCE_READ) {
      for (let i = 0; i < length; i += 1) target[out + i] = source[out + i];
      out += length;
    } else if (type === ACTION_TARGET_READ) {
      target.set(r.bytes(length), out);
      out += length;
    } else if (type === ACTION_SOURCE_COPY) {
      sourceRelativeOffset += r.signed();
      for (let i = 0; i < length; i += 1) {
        if (sourceRelativeOffset < 0 || sourceRelativeOffset >= source.length) throw new Error('BPS SourceCopy out of range.');
        target[out++] = source[sourceRelativeOffset++];
      }
    } else if (type === ACTION_TARGET_COPY) {
      targetRelativeOffset += r.signed();
      for (let i = 0; i < length; i += 1) {
        if (targetRelativeOffset < 0 || targetRelativeOffset >= out) throw new Error('BPS TargetCopy out of range.');
        target[out++] = target[targetRelativeOffset++];
      }
    }
  }

  if (r.p !== footerStart) throw new Error(`BPS parser stopped at ${r.p}, footer begins at ${footerStart}.`);
  const expectedSourceCrc = readU32le(patch, footerStart);
  const expectedTargetCrc = readU32le(patch, footerStart + 4);
  if (crc32(source) !== expectedSourceCrc) throw new Error('BPS source CRC mismatch.');
  if (crc32(target) !== expectedTargetCrc) throw new Error('BPS target CRC mismatch.');
  return target;
}
