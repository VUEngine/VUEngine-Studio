# Vendored: the VB Color new-patch kit

`constants.ts`, `v810.ts`, `bootstrap.ts`, `palette.ts`, `bps.ts` and
`generator.ts` are the `src/` of the "VB Color — New Patch Kit v1"
(`@vueport/vbc-new-patch-kit` 1.0.0), which ships its own reference assembly,
CLI, schema and two test harnesses. Like the exporter one directory up, this is
not VUEPort's code to rewrite: it is what a patch author checks a generated
patch against, and a copy that drifted would make VUEPort run something other
than what they tested.

## What it makes

A colorization for a game nobody has colorized. There is no VUEPort-side
runtime and no game-specific analysis; creation is a compile step, run once:

1. the source ROM is doubled, the lower half byte-identical and the upper half
   starting as a mirror of it, so the game's high-address vectors and data
   still exist where it looks for them;
2. a 168-byte V810 bootstrap, a 2 KiB RGB555 Color RAM table, the VB Color
   support byte and a new reset vector go into the upper mirror;
3. the bootstrap detects VB Color, enables it, clears Cell and OBJ Color
   Attribute RAM, uploads the table and jumps to the game's own reset code,
   which is never moved or disassembled. On a plain Virtual Boy the detection
   fails and it jumps straight there, so the patched ROM still runs;
4. the difference between the two ROMs is written out as an ordinary BPS,
   which is what the format-2 document carries.

What it cannot do is choose *which* palette is shown where. Cleared Color
Attribute RAM leaves a legacy game selecting BG palettes 0–3 and OBJ palettes
0–3 (global ids 128–131) through its existing GPLTS/JPLTS; the other 248
palettes are loaded and editable but nothing selects them. Assigning them is
game-specific work, and belongs in a hand-written patch — which is why the
panel says so before it makes one.

## Changes on copying

- Relative imports lost their `.js` extensions, to match this repository's
  module resolution. `index.ts` is VUEPort's, and leaves out the kit's
  `vueport-adapter.ts`: `emulator-vb-color.ts` is that layer here.
- `makeMetadata` in `generator.ts` gained a `paletteTable` block beside the
  kit's own `paletteAbi`. It is the same table said in the shape
  `VBC_PATCH_FORMAT.md` defines and `vbc-patch-export.ts` reads, so a generated
  document is edited, built and exported by exactly the path a shipped one is —
  and the kit's `rebuild` step is not needed here at all. A palette's id is its
  entry index, the table being the whole of Color RAM in order.

Re-apply both when the kit is updated.

## What is not here

The kit's `bin/`, `boot/`, `examples/`, `schema/`, `template/` and `test/`.
`boot/vbc-generic-bootstrap.S` is the readable form of what `bootstrap.ts`
emits and is worth keeping beside the kit rather than in the emulator's source;
`tests/vb-color-create-probe.mjs` is VUEPort's own check that the generator
still produces what this repository's exporter and patch store accept.
