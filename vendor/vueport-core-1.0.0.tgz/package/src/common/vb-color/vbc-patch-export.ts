export type HexColor = `#${string}`;

export interface VbcPalette {
  id: number;
  name: string;
  channelId: "bg" | "obj";
  colors: [HexColor, HexColor, HexColor, HexColor];
  variants?: Record<string, [HexColor, HexColor, HexColor, HexColor]>;
}

export interface VbcChannel {
  id: "bg" | "obj";
  name: string;
}

export interface VbcScene {
  id: string;
  name: string;
  order?: number;
  description?: string;
}

export interface VbcObjectPaletteEntry {
  type: "palette";
  id: number;
  role?: string;
  variant?: string;
}

export interface VbcEditorObject {
  id: string;
  name: string;
  sceneId: string;
  kind?: string;
  order?: number;
  entries: VbcObjectPaletteEntry[];
}

export interface VbcPatchDocument {
  version: 2;
  id: string;
  name: string;
  description?: string;
  channels?: VbcChannel[];
  palettes: VbcPalette[];
  scenes?: VbcScene[];
  objects?: VbcEditorObject[];
  patch: {
    type: "bps";
    encoding: "hex";
    dataHex: string;
    sha256?: string;
  };
}

interface PaletteBinding {
  paletteId: number;
  variant?: string;
  index: number;
}

interface VbcBpsMetadata {
  vbcFormat: 2;
  sourceSha256?: string;
  paletteTable: {
    offset: number;
    entrySize: 8;
    encoding: "rgb555le";
    entries: PaletteBinding[];
  };
}

function decodeHex(hex: string): Uint8Array {
  if (hex.length === 0 || (hex.length & 1) !== 0 || !/^[0-9a-f]+$/i.test(hex)) {
    throw new Error("Invalid hexadecimal BPS payload");
  }
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (const b of bytes) {
    crc ^= b;
    for (let i = 0; i < 8; i++) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function readU32LE(data: Uint8Array, offset: number): number {
  return (data[offset]! | (data[offset + 1]! << 8) | (data[offset + 2]! << 16) | (data[offset + 3]! << 24)) >>> 0;
}

function decodeNumber(data: Uint8Array, state: { pos: number }): number {
  let value = 0;
  let shift = 1;
  while (true) {
    if (state.pos >= data.length) throw new Error("Truncated BPS variable integer");
    const x = data[state.pos++]!;
    value += (x & 0x7f) * shift;
    if (x & 0x80) return value;
    shift <<= 7;
    value += shift;
  }
}

function decodeSigned(data: Uint8Array, state: { pos: number }): number {
  const value = decodeNumber(data, state);
  const magnitude = value >>> 1;
  return (value & 1) !== 0 ? -magnitude : magnitude;
}

export interface AppliedBps {
  target: Uint8Array;
  metadataBytes: Uint8Array;
}

export function applyBps(source: Uint8Array, patch: Uint8Array): AppliedBps {
  if (patch.length < 16 || String.fromCharCode(...patch.subarray(0, 4)) !== "BPS1") {
    throw new Error("Not a BPS1 patch");
  }

  const expectedPatchCrc = readU32LE(patch, patch.length - 4);
  const actualPatchCrc = crc32(patch.subarray(0, patch.length - 4));
  if (actualPatchCrc !== expectedPatchCrc) throw new Error("BPS patch CRC mismatch");

  const state = { pos: 4 };
  const sourceSize = decodeNumber(patch, state);
  const targetSize = decodeNumber(patch, state);
  const metadataSize = decodeNumber(patch, state);
  if (source.length !== sourceSize) throw new Error(`Source size mismatch: expected ${sourceSize}, got ${source.length}`);

  const metadataBytes = patch.slice(state.pos, state.pos + metadataSize);
  state.pos += metadataSize;

  const target = new Uint8Array(targetSize);
  let out = 0;
  let sourceRelative = 0;
  let targetRelative = 0;
  const actionsEnd = patch.length - 12;

  while (out < targetSize) {
    if (state.pos >= actionsEnd) throw new Error("Truncated BPS action stream");
    const action = decodeNumber(patch, state);
    const mode = action & 3;
    const length = (action >>> 2) + 1;
    if (out + length > targetSize) throw new Error("BPS action exceeds target size");

    if (mode === 0) {
      if (out + length > source.length) throw new Error("BPS SourceRead exceeds source");
      target.set(source.subarray(out, out + length), out);
      out += length;
    } else if (mode === 1) {
      if (state.pos + length > actionsEnd) throw new Error("BPS TargetRead literal exceeds patch");
      target.set(patch.subarray(state.pos, state.pos + length), out);
      state.pos += length;
      out += length;
    } else if (mode === 2) {
      sourceRelative += decodeSigned(patch, state);
      if (sourceRelative < 0 || sourceRelative + length > source.length) throw new Error("BPS SourceCopy exceeds source");
      target.set(source.subarray(sourceRelative, sourceRelative + length), out);
      sourceRelative += length;
      out += length;
    } else {
      targetRelative += decodeSigned(patch, state);
      if (targetRelative < 0 || targetRelative >= out) throw new Error("Invalid BPS TargetCopy origin");
      for (let i = 0; i < length; i++) {
        const src = targetRelative + i;
        if (src < 0 || src >= out + i) throw new Error("Invalid BPS TargetCopy range");
        target[out + i] = target[src]!;
      }
      targetRelative += length;
      out += length;
    }
  }

  const sourceCrc = readU32LE(patch, patch.length - 12);
  const targetCrc = readU32LE(patch, patch.length - 8);
  if (crc32(source) !== sourceCrc) throw new Error("BPS source CRC mismatch");
  if (crc32(target) !== targetCrc) throw new Error("BPS target CRC mismatch");
  return { target, metadataBytes };
}

function rgb888ToRgb555(color: string): number {
  if (!/^#[0-9a-f]{6}$/i.test(color)) throw new Error(`Invalid color ${color}`);
  const r = Number.parseInt(color.slice(1, 3), 16);
  const g = Number.parseInt(color.slice(3, 5), 16);
  const b = Number.parseInt(color.slice(5, 7), 16);
  const r5 = Math.round((r * 31) / 255);
  const g5 = Math.round((g * 31) / 255);
  const b5 = Math.round((b * 31) / 255);
  return r5 | (g5 << 5) | (b5 << 10);
}

function parseMetadata(bytes: Uint8Array): VbcBpsMetadata {
  if (bytes.length === 0) throw new Error("Compiled BPS has no VBC palette metadata; recompile it for the simplified Format 2 palette ABI");
  let value: unknown;
  try {
    value = JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    throw new Error("BPS metadata is not valid VBC JSON metadata");
  }
  const m = value as Partial<VbcBpsMetadata>;
  if (m.vbcFormat !== 2 || !m.paletteTable || m.paletteTable.entrySize !== 8 || m.paletteTable.encoding !== "rgb555le") {
    throw new Error("Unsupported or missing VBC Format 2 palette-table metadata");
  }
  return m as VbcBpsMetadata;
}

function key(id: number, variant?: string): string {
  return `${id}\u0000${variant ?? ""}`;
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", bytes as Uint8Array<ArrayBuffer>);
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, "0")).join("");
}

export async function exportPatchedRom(sourceRom: Uint8Array, document: VbcPatchDocument): Promise<Uint8Array> {
  if (document.version !== 2) throw new Error("Only Format 2 is supported");
  const bps = decodeHex(document.patch.dataHex);
  if (document.patch.sha256) {
    const actual = await sha256Hex(bps);
    if (actual.toLowerCase() !== document.patch.sha256.toLowerCase()) throw new Error("Embedded BPS SHA-256 mismatch");
  }

  const { target, metadataBytes } = applyBps(sourceRom, bps);
  const metadata = parseMetadata(metadataBytes);
  if (metadata.sourceSha256) {
    const actualSource = await sha256Hex(sourceRom);
    if (actualSource.toLowerCase() !== metadata.sourceSha256.toLowerCase()) throw new Error("Source ROM SHA-256 mismatch");
  }

  const bindings = new Map<string, number>();
  for (const entry of metadata.paletteTable.entries) {
    const k = key(entry.paletteId, entry.variant);
    if (bindings.has(k)) throw new Error(`Duplicate compiled palette binding for ${entry.paletteId}/${entry.variant ?? "base"}`);
    bindings.set(k, entry.index);
  }

  const seen = new Set<number>();
  const writeColors = (paletteId: number, variant: string | undefined, colors: readonly string[]) => {
    const index = bindings.get(key(paletteId, variant));
    if (index === undefined) throw new Error(`Compiled BPS has no palette binding for ${paletteId}/${variant ?? "base"}`);
    const offset = metadata.paletteTable.offset + index * 8;
    if (offset < 0 || offset + 8 > target.length) throw new Error("Compiled palette table exceeds target ROM");
    for (let i = 0; i < 4; i++) {
      const value = rgb888ToRgb555(colors[i]!);
      target[offset + i * 2] = value & 0xff;
      target[offset + i * 2 + 1] = value >>> 8;
    }
  };

  for (const palette of document.palettes) {
    if (seen.has(palette.id)) throw new Error(`Duplicate JSON palette id ${palette.id}`);
    seen.add(palette.id);
    writeColors(palette.id, undefined, palette.colors);
    if (palette.variants) {
      for (const [variant, colors] of Object.entries(palette.variants)) writeColors(palette.id, variant, colors);
    }
  }

  return target;
}
