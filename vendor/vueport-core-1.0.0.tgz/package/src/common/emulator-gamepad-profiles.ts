/**
 * What a physical controller's buttons do, per device. The Gamepad API gives raw indices, and they are not portable:
 * Chrome and Firefox enumerate the same pad differently (Firefox reports an extra axis, shifting every index after
 * it), and an unrecognized pad comes in its HID descriptor's order. Portable is `mapping === 'standard'`: both
 * browsers normalize pads they recognize (Chromium's gamepad_standard_mappings.cc, Firefox since bug 1542893), so the
 * built-in presets are semantic, on the standard layout, differing only in face buttons and names. An unrecognized pad
 * gets no guess but the guided walk-through in the Game Pads settings, remembered per device.
 * Free of DOM, so the whole resolution path can be exercised from tests/gamepad-profile-probe.mjs.
 */

import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';
import vbUsbAdapter from '../data/gamepad-profiles/vb-usb-adapter.json';
import EightBitDo64BtGecko from '../data/gamepad-profiles/8bitdo-64-bt-gecko.json';
import EightBitDo64BtChromium from '../data/gamepad-profiles/8bitdo-64-bt-chromium.json';
import EightBitDo64BtSdl from '../data/gamepad-profiles/8bitdo-64-bt-sdl.json';
import NintendoN64ControllerSdl from '../data/gamepad-profiles/nintendo-n64-controller-sdl.json';

// spelled out rather than read from EMULATOR_GAMEPAD_INPUTS, which would pull the command table and its localization
// in. Typed against the button union, so a new button will not compile here until it is given a code
const GAMEPAD_BUTTON_KEY_CODES: Record<EmulatorGamePadButton, EmulatorGamePadKeyCode> = {
    a: EmulatorGamePadKeyCode.A,
    b: EmulatorGamePadKeyCode.B,
    start: EmulatorGamePadKeyCode.Start,
    select: EmulatorGamePadKeyCode.Select,
    lUp: EmulatorGamePadKeyCode.LUp,
    lRight: EmulatorGamePadKeyCode.LRight,
    lDown: EmulatorGamePadKeyCode.LDown,
    lLeft: EmulatorGamePadKeyCode.LLeft,
    rUp: EmulatorGamePadKeyCode.RUp,
    rRight: EmulatorGamePadKeyCode.RRight,
    rDown: EmulatorGamePadKeyCode.RDown,
    rLeft: EmulatorGamePadKeyCode.RLeft,
    lTrigger: EmulatorGamePadKeyCode.LT,
    rTrigger: EmulatorGamePadKeyCode.RT,
};

// the same set as EMULATOR_GAMEPAD_BUTTONS; the order does not matter, the Record type guarantees completeness
const GAMEPAD_BUTTONS = Object.keys(GAMEPAD_BUTTON_KEY_CODES) as EmulatorGamePadButton[];

export function vbKeyForButton(button: EmulatorGamePadButton): VbKey {
    return GAMEPAD_KEY_TO_VB_KEY[GAMEPAD_BUTTON_KEY_CODES[button]];
}

// here rather than beside the keyboard handling, as both keyboard and pad must end up as the same mask and this
// module is reachable from both. Re-exported from emulator-input.ts
export const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey> = {
    [EmulatorGamePadKeyCode.A]: VbKey.A,
    [EmulatorGamePadKeyCode.B]: VbKey.B,
    [EmulatorGamePadKeyCode.Start]: VbKey.STA,
    [EmulatorGamePadKeyCode.Select]: VbKey.SEL,
    [EmulatorGamePadKeyCode.LUp]: VbKey.LU,
    [EmulatorGamePadKeyCode.LRight]: VbKey.LR,
    [EmulatorGamePadKeyCode.LDown]: VbKey.LD,
    [EmulatorGamePadKeyCode.LLeft]: VbKey.LL,
    [EmulatorGamePadKeyCode.RUp]: VbKey.RU,
    [EmulatorGamePadKeyCode.RRight]: VbKey.RR,
    [EmulatorGamePadKeyCode.RDown]: VbKey.RD,
    [EmulatorGamePadKeyCode.RLeft]: VbKey.RL,
    [EmulatorGamePadKeyCode.LT]: VbKey.LT,
    [EmulatorGamePadKeyCode.RT]: VbKey.RT,
};

/**
 * One physical control: a button, one end of an axis, or one direction of a hat switch. An axis carries the sign of
 * the deflection that counts as pressed, as the two halves of a stick are two VB buttons. A hat is a d-pad given as a
 * single axis (Chrome and Firefox do this for unmapped pads, e.g. the 8BitDo 64): eight positions evenly spaced from
 * -1 (up) clockwise to 1 (up-left), resting outside -1…1 (23/7 on the 8BitDo 64, in both). Read as a stick it is
 * nonsense: resting looks like full deflection, left and right sit at 5/7 and -3/7.
 */
export type GamepadSource =
    | { kind: 'button', index: number }
    | { kind: 'axis', index: number, direction: -1 | 1 }
    | { kind: 'hat', index: number, direction: GamepadHatDirection };

export type GamepadHatDirection = 'up' | 'right' | 'down' | 'left';

const HAT_DIRECTIONS: readonly GamepadHatDirection[] = ['up', 'right', 'down', 'left'];

// for comparing and as a key
export function gamepadSourceId(source: GamepadSource): string {
    switch (source.kind) {
        case 'button':
            return `b${source.index}`;
        case 'axis':
            return `a${source.index}${source.direction < 0 ? '-' : '+'}`;
        case 'hat':
            return `h${source.index}${source.direction[0]}`;
    }
}

// undefined if it is not one
export function parseGamepadSource(id: string): GamepadSource | undefined {
    const asButton = /^b(\d+)$/.exec(id);
    if (asButton) {
        return { kind: 'button', index: Number(asButton[1]) };
    }
    const asAxis = /^a(\d+)([-+])$/.exec(id);
    if (asAxis) {
        return { kind: 'axis', index: Number(asAxis[1]), direction: asAxis[2] === '-' ? -1 : 1 };
    }
    const asHat = /^h(\d+)([urdl])$/.exec(id);
    if (asHat) {
        const direction = HAT_DIRECTIONS.find(candidate => candidate[0] === asHat[2])!;
        return { kind: 'hat', index: Number(asHat[1]), direction };
    }
    return undefined;
}

export function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean {
    return gamepadSourceId(a) === gamepadSourceId(b);
}

// not cosmetic: a Nintendo pad's A sits where an Xbox pad's B does, PlayStation calls them ○ and ✕. VB A is the
// rightmost face button, so it lands on a differently named button per family
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';

const GAMEPAD_FAMILIES: readonly GamepadFamily[] = ['xbox', 'playstation', 'nintendo', 'generic'];

// a raw recording must be kept apart per engine: the 8BitDo 64 shows its d-pad as axis 0 of 7 in Firefox and as a
// later axis in Chrome. `sdl` is the desktop shell reading pads through SDL, numbering raw pads SDL's way; such pads
// say so via GamepadDescriptor.engine, as the shell's webview is WebKit
export type GamepadEngine = 'chromium' | 'gecko' | 'webkit' | 'sdl';

const GAMEPAD_ENGINES: readonly GamepadEngine[] = ['chromium', 'gecko', 'webkit', 'sdl'];

// undefined outside a browser. Asked of the user agent, not the pad id: Safari writes `vendor-product-name` like
// Firefox
export function hostGamepadEngine(): GamepadEngine | undefined {
    if (typeof navigator === 'undefined' || !navigator.userAgent) {
        return undefined;
    }
    const agent = navigator.userAgent;
    if (/firefox\//i.test(agent)) {
        return 'gecko';
    }
    // every Chromium says AppleWebKit too, so Chrome is asked first; every browser on iOS is WebKit whatever it says
    if (/chrome\/|chromium\/|crios\//i.test(agent) && !/iphone|ipad|ipod/i.test(agent)) {
        return 'chromium';
    }
    return /applewebkit\//i.test(agent) ? 'webkit' : undefined;
}

// part of a raw layout like the engine: each engine reads pads through a different backend per system (IOKit,
// Raw Input, joydev), each numbering its own way
export type GamepadPlatform = 'macos' | 'windows' | 'linux' | 'chromeos' | 'android' | 'ios';

const GAMEPAD_PLATFORMS: readonly GamepadPlatform[] = ['macos', 'windows', 'linux', 'chromeos', 'android', 'ios'];

// undefined outside a browser. The id carries no trace of it
export function hostGamepadPlatform(): GamepadPlatform | undefined {
    if (typeof navigator === 'undefined') {
        return undefined;
    }
    const hinted = (navigator as { userAgentData?: { platform?: string } }).userAgentData?.platform;
    const text = `${hinted ?? ''} ${navigator.userAgent ?? ''}`;
    // iPadOS asks for desktop pages as a Mac; the touch screen gives it away
    if (/iphone|ipad|ipod/i.test(text) || (/mac/i.test(text) && (navigator.maxTouchPoints ?? 0) > 1)) {
        return 'ios';
    }
    if (/android/i.test(text)) {
        return 'android';
    }
    if (/cros|chrome os/i.test(text)) {
        return 'chromeos';
    }
    if (/mac/i.test(text)) {
        return 'macos';
    }
    if (/win/i.test(text)) {
        return 'windows';
    }
    if (/linux/i.test(text)) {
        return 'linux';
    }
    return undefined;
}

// opens the host's command palette, if it has one. The host reads it on its own loop, as it must work with no game
// running and while the palette is taking the input
export type GamepadUiAction = 'commandPalette';

export const GAMEPAD_UI_ACTIONS: readonly GamepadUiAction[] = ['commandPalette'];

// plays whichever macro sits in a slot (see setSlot in the macro store); eight, as the Macros panel numbers them
export type GamepadMacroAction =
    'macro1' | 'macro2' | 'macro3' | 'macro4' | 'macro5' | 'macro6' | 'macro7' | 'macro8';

export const GAMEPAD_MACRO_ACTIONS: readonly GamepadMacroAction[] =
    ['macro1', 'macro2', 'macro3', 'macro4', 'macro5', 'macro6', 'macro7', 'macro8'];

// 1-based; undefined for any other action
export function gamepadMacroSlot(action: string): number | undefined {
    const index = (GAMEPAD_MACRO_ACTIONS as readonly string[]).indexOf(action);
    return index === -1 ? undefined : index + 1;
}

// 1-based slot
export function gamepadMacroAction(slot: number): GamepadMacroAction {
    return GAMEPAD_MACRO_ACTIONS[slot - 1];
}

export type GamepadPadAction = EmulatorAction | GamepadUiAction | GamepadMacroAction;

const GAMEPAD_PAD_ACTIONS: readonly GamepadPadAction[] = [
    ...GAMEPAD_UI_ACTIONS,
    ...Object.values(EmulatorAction),
    ...GAMEPAD_MACRO_ACTIONS,
];

const isUiAction = (action: string): action is GamepadUiAction =>
    (GAMEPAD_UI_ACTIONS as readonly string[]).includes(action);

// by VB button, plain or on turbo
export type GamepadButtonMap = Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;

export interface GamepadProfile {
    // `vendor:product` in lower-case hex ("054c:05c4") when the id carries them, otherwise the whole id. See
    // gamepadDeviceKey
    device: string;
    // the browser's id cleaned up, or the database's name
    label?: string;
    // the built-in preset it started as, for "reset to preset"; absent for a profile built by hand
    preset?: string;
    family: GamepadFamily;
    // several sources per button on purpose: the standard presets put both d-pad and left stick on the VB's left cross
    buttons: GamepadButtonMap;
    // VB buttons pressed and released over and over while the source is held. A source drives this or `buttons`,
    // never both
    turbo?: GamepadButtonMap;
    // emulator actions (pause, save state, rewind), the host's own (GamepadUiAction) and macro slots
    // (GamepadMacroAction). Usually only the host's
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    // 0-1, generous by default, as the control it stands in for is digital
    deadZone: number;
}

export const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;

// the narrowest and widest dead zone the settings offer
export const GAMEPAD_DEAD_ZONE_RANGE = { min: 0.1, max: 0.9 };

// analog buttons still need a digital answer
const BUTTON_THRESHOLD = 0.5;

const padButton = (index: number): GamepadSource => ({ kind: 'button', index });
const padAxis = (index: number, direction: -1 | 1): GamepadSource =>
    ({ kind: 'axis', index, direction });

// the d-pad (12-15) and the left stick (axes 0/1) drive the left cross, the right stick (axes 2/3) the right one.
// VB A is the rightmost face button: button 1, with button 0 below it as B. Shoulders and triggers both reach LT/RT
const STANDARD_BUTTONS: Record<EmulatorGamePadButton, GamepadSource[]> = {
    a: [padButton(1)],
    b: [padButton(0)],
    select: [padButton(8)],
    start: [padButton(9)],
    lTrigger: [padButton(4), padButton(6)],
    rTrigger: [padButton(5), padButton(7)],
    lUp: [padButton(12), padAxis(1, -1)],
    lDown: [padButton(13), padAxis(1, 1)],
    lLeft: [padButton(14), padAxis(0, -1)],
    lRight: [padButton(15), padAxis(0, 1)],
    rUp: [padAxis(3, -1)],
    rDown: [padAxis(3, 1)],
    rLeft: [padAxis(2, -1)],
    rRight: [padAxis(2, 1)],
};

/**
 * The standard layout's controls the VB has no use for. Home opens the command palette (nothing in a game uses it),
 * face buttons 2 and 3 take rewind and fast forward, the stick clicks pause and a screenshot. Saving and loading
 * states are left off on purpose: a stray press overwrites a save or loses half an hour, and stick clicks get
 * pressed by accident.
 */
const STANDARD_ACTIONS: Partial<Record<GamepadPadAction, GamepadSource[]>> = {
    commandPalette: [padButton(16)],
    [EmulatorAction.Rewind]: [padButton(2)],
    [EmulatorAction.ToggleFastForward]: [padButton(3)],
    [EmulatorAction.PauseToggle]: [padButton(10)],
    [EmulatorAction.Screenshot]: [padButton(11)],
};

// offered in the settings, and applied on detection
export interface GamepadPreset {
    id: string;
    // English; the settings localize it through gamepadPresetLabel
    name: string;
    family: GamepadFamily;
    // only offered by hand, never the automatic answer for a detected pad
    manualOnly?: boolean;
    // set only on a bundled preset for one particular device (see GamepadProfileFile): offered and detected only for
    // that pad, and only while the browser reports it the way it did when recorded
    match?: GamepadDeviceMatch;
    // when it is not the default
    deadZone?: number;
    buttons: GamepadButtonMap;
    // see GamepadProfile.turbo
    turbo?: GamepadButtonMap;
    // the emulator's actions, and Home opening the palette
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    // a device's control labels by source id ("b8": "C↑"), for pads whose layout is not one of the families', e.g. an
    // N64 pad with its C buttons on the standard layout's Back and face buttons
    labels?: Record<string, string>;
}

// a raw pad's table stops being right once a browser normalizes it, so `mapping` must agree, and browsers disagree on
// raw pads (extra axes, hats as an axis or four buttons). A pad showing different button or axis counts than when
// recorded gets no guess rather than a wrong one
export interface GamepadDeviceMatch {
    // as gamepadDeviceKey files it
    device?: string;
    // as gamepadName reads it; any case
    name?: string;
    // `'standard'`, or `''` for raw
    mapping: string;
    // set, the preset applies in that engine only, as two engines can show a raw pad with the same counts in a
    // different order. Absent means any, right only for a pad laid out the same everywhere, like the VB USB Adapter's
    // buttons
    engine?: GamepadEngine;
    // absent means any, as with `engine`
    platform?: GamepadPlatform;
    buttons?: number;
    axes?: number;
}

// what the Game Pads settings export, and what ships in src/data/gamepad-profiles/. The same shape on purpose:
// bundling is dropping an export into that folder and listing it in BUNDLED_GAMEPAD_PROFILES
export interface GamepadProfileFile {
    format: typeof GAMEPAD_PROFILE_FORMAT;
    version: 1;
    // the preset id it becomes; a stored profile's `preset` names it
    id: string;
    name: string;
    family: GamepadFamily;
    match: GamepadDeviceMatch;
    deadZone: number;
    buttons: GamepadButtonMap;
    // see GamepadProfile.turbo
    turbo?: GamepadButtonMap;
    // see gamepadProfileFile
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    // see GamepadPreset.labels
    labels?: Record<string, string>;
}

export const GAMEPAD_PROFILE_FORMAT = 'vueport-gamepad-profile';

// adding one is a new file in src/data/gamepad-profiles/ and a line here
const BUNDLED_GAMEPAD_PROFILES: unknown[] = [
    vbUsbAdapter,
    EightBitDo64BtGecko,
    EightBitDo64BtChromium,
    EightBitDo64BtSdl,
    // Nintendo's Switch Online N64 controller, and the 8BitDo 64 in Switch mode. Read by SDL's Switch driver, the same
    // on every system, so no platform: C buttons on Back, West, North and Misc 2, no minus or stick click. Measured off
    // the 8BitDo with the shell's raw log, 2026-10-08
    NintendoN64ControllerSdl,
];

/**
 * The standard presets share one button table and differ only in family, which decides the glyphs.
 * `standard-nofaceswap` is for pads (mostly Nintendo layouts mapped positionally by the browser) that end up with A
 * and B swapped against the print; offered by hand only, as the id cannot tell. The bundled ones are one device's
 * recorded mapping, matched by `match`.
 */
export const GAMEPAD_PRESETS: GamepadPreset[] = [
    {
        id: 'standard-xbox',
        name: 'Xbox',
        family: 'xbox',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    {
        id: 'standard-playstation',
        name: 'PlayStation',
        family: 'playstation',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    {
        id: 'standard-nintendo',
        name: 'Nintendo',
        family: 'nintendo',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    { id: 'standard-generic', name: 'Standard', family: 'generic', buttons: STANDARD_BUTTONS, actions: STANDARD_ACTIONS },
    {
        id: 'standard-nofaceswap',
        name: 'Standard (A/B swapped)',
        family: 'generic',
        manualOnly: true,
        buttons: { ...STANDARD_BUTTONS, a: [padButton(0)], b: [padButton(1)] },
        actions: STANDARD_ACTIONS,
    },
    ...BUNDLED_GAMEPAD_PROFILES.map(file => {
        const preset = gamepadPresetFromFile(file);
        if (!preset) {
            // a bundled file that does not read is a build mistake, not something to skip quietly; the probe reads
            // every one
            throw new Error(`Bundled game pad profile does not read: ${JSON.stringify(file).slice(0, 80)}`);
        }
        return preset;
    }),
];

export function gamepadPreset(id: string | undefined): GamepadPreset | undefined {
    return id === undefined ? undefined : GAMEPAD_PRESETS.find(preset => preset.id === id);
}

export interface GamepadIdentity {
    // four lower-case hex digits, when the id carries them
    vendor?: string;
    product?: string;
    // the readable part, with the identifiers stripped off both ends
    name: string;
    // what a profile for this device is filed under
    key: string;
}

// Chrome: `Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 05c4)`, ids in a trailing parenthetical.
// Firefox: `054c-05c4-Wireless Controller`, ids in front. An id in neither shape is a name with no ids, and the
// whole id is then the key
export function gamepadIdentity(id: string): GamepadIdentity {
    let vendor: string | undefined;
    let product: string | undefined;

    const chrome = /vendor:\s*([0-9a-f]{4}).*?product:\s*([0-9a-f]{4})/i.exec(id);
    if (chrome) {
        vendor = chrome[1].toLowerCase();
        product = chrome[2].toLowerCase();
    }
    const firefox = /^([0-9a-f]{4})-([0-9a-f]{4})-/i.exec(id);
    if (firefox) {
        vendor = firefox[1].toLowerCase();
        product = firefox[2].toLowerCase();
    }

    return {
        vendor,
        product,
        name: gamepadName(id),
        key: vendor && product ? `${vendor}:${product}` : id,
    };
}

// takes the name back out of the id, or returns the id untouched if its shape is unknown
export function gamepadName(id: string): string {
    // the trailing parenthetical when it is the API talking: vendor and product ids, or the layout it maps to
    let name = id.replace(
        /\s*\([^()]*\b(?:vendor:|product:|standard gamepad)[^()]*\)\s*$/i, '');
    // Firefox leads with the same pair again, as `054c-05c4-`
    name = name.replace(/^[0-9a-f]{4}-[0-9a-f]{4}-/i, '').trim();
    return name || id;
}

export function gamepadDeviceKey(id: string): string {
    return gamepadIdentity(id).key;
}

// only vendors where the id alone settles it. 8BitDo (2dc8) ships Nintendo, Xbox and PlayStation pads under one id,
// so its models are told apart by name below or by the harvested database
const FAMILY_BY_VENDOR: Record<string, GamepadFamily> = {
    '045e': 'xbox',        // Microsoft
    '054c': 'playstation', // Sony
    '057e': 'nintendo',    // Nintendo
    '0f0d': 'nintendo',    // Hori, near enough always a Nintendo layout
    '0e6f': 'xbox',        // PDP
    '24c6': 'xbox',        // PowerA / ThrustMaster Xbox line
};

// names that give the family away when the vendor id does not
const FAMILY_BY_NAME: { pattern: RegExp, family: GamepadFamily }[] = [
    { pattern: /xbox|xinput|x-?input/i, family: 'xbox' },
    { pattern: /dual\s*sense|dual\s*shock|playstation|\bps[345]\b/i, family: 'playstation' },
    { pattern: /switch|joy-?con|nintendo|\bsnes\b|\bnes\b|wii/i, family: 'nintendo' },
    // 8BitDo names its Nintendo-layout pads after the consoles they copy
    { pattern: /\bsn30\b|\bsf30\b|\bn30\b/i, family: 'nintendo' },
];

// one entry of the harvested device database (see scripts/fetch-controller-db.mjs), keyed by `vendor:product`
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}

export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;

// the database first (harvested from people with the device in hand), then the vendor id, then the name. Falls back
// to `generic`, which shows bare indices rather than a wrong glyph
export function detectGamepadFamily(
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadFamily {
    const entry = database?.[identity.key];
    if (entry?.family) {
        return entry.family;
    }
    if (identity.vendor && FAMILY_BY_VENDOR[identity.vendor]) {
        return FAMILY_BY_VENDOR[identity.vendor];
    }
    const name = entry?.name ?? identity.name;
    for (const { pattern, family } of FAMILY_BY_NAME) {
        if (pattern.test(name)) {
            return family;
        }
    }
    return 'generic';
}

// just enough of a Gamepad to resolve a profile for it
export interface GamepadDescriptor {
    id: string;
    // `'standard'` when the browser has normalized the pad, `''` when not
    mapping: string;
    // only counted, to tell layouts apart; see GamepadDeviceMatch
    buttons?: ArrayLike<unknown>;
    axes?: ArrayLike<unknown>;
    // the host's own when not given
    engine?: GamepadEngine;
    platform?: GamepadPlatform;
}

// whether a device preset was recorded on this pad, shown the way it is now
function matchesDevice(match: GamepadDeviceMatch, pad: GamepadDescriptor, identity: GamepadIdentity): boolean {
    if ((match.mapping === 'standard') !== (pad.mapping === 'standard')) {
        return false;
    }
    if (match.engine !== undefined && match.engine !== (pad.engine ?? hostGamepadEngine())) {
        return false;
    }
    if (match.platform !== undefined && match.platform !== (pad.platform ?? hostGamepadPlatform())) {
        return false;
    }
    const sameDevice = match.device !== undefined && match.device === identity.key;
    const sameName = match.name !== undefined && match.name.toLowerCase() === identity.name.toLowerCase();
    if (!sameDevice && !sameName) {
        return false;
    }
    if (match.buttons !== undefined && pad.buttons && pad.buttons.length !== match.buttons) {
        return false;
    }
    return match.axes === undefined || !pad.axes || pad.axes.length === match.axes;
}

function devicePresetsFor(pad: GamepadDescriptor, identity: GamepadIdentity): GamepadPreset[] {
    return GAMEPAD_PRESETS.filter(preset => preset.match && matchesDevice(preset.match, pad, identity));
}

// the settings page shows the reason
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    // `stored` is the person's own, `preset` was detected, `unmapped` means the browser does not recognize the pad and
    // nothing was recorded yet: the one case with no working mapping, which the settings page asks to fix
    origin: 'stored' | 'preset' | 'unmapped';
    // the preset it would reset to, when there is one
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}

// undefined for a pad the browser has not normalized, as no table here can know its HID order: a wrong guess looks
// configured, which is worse than asking to be set up. A bundled device mapping (see `match`) wins over the general
// presets, for a normalized pad too
export function detectGamepadPreset(
    pad: GamepadDescriptor,
    database?: GamepadDatabase,
): GamepadPreset | undefined {
    const identity = gamepadIdentity(pad.id);
    const own = devicePresetsFor(pad, identity)[0];
    if (own || pad.mapping !== 'standard') {
        return own;
    }
    const family = detectGamepadFamily(identity, database);
    return GAMEPAD_PRESETS.find(preset =>
        !preset.manualOnly && !preset.match && preset.family === family)
        ?? gamepadPreset('standard-generic');
}

// every standard one, the A/B-swapped one only where the standard layout is in force, and a device's own only for
// that device while shown as recorded (first, as it fits)
export function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[] {
    const standard = pad.mapping === 'standard';
    const own = devicePresetsFor(pad, gamepadIdentity(pad.id));
    const general = GAMEPAD_PRESETS.filter(preset =>
        !preset.match && (!preset.manualOnly || standard));
    return [...own, ...general];
}

export function profileFromPreset(
    preset: GamepadPreset,
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    return {
        device: identity.key,
        label: database?.[identity.key]?.name ?? identity.name,
        preset: preset.id,
        family: preset.family,
        // copied rather than shared: every preset points at one STANDARD_BUTTONS, and a profile is about to be edited
        buttons: cloneButtons(preset.buttons),
        ...nonEmpty('turbo', cloneButtons(preset.turbo ?? {})),
        ...(preset.actions ? { actions: cloneActions(preset.actions) } : {}),
        deadZone: preset.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE,
    };
}

// everything bound travels, buttons and actions: a shipped profile is somebody's whole setup of a pad
export function gamepadProfileFile(profile: GamepadProfile, pad: GamepadDescriptor): GamepadProfileFile {
    const identity = gamepadIdentity(pad.id);
    const name = profile.label ?? identity.name;
    const actions = profile.actions ? cloneActions(profile.actions) : undefined;
    const engine = pad.engine ?? hostGamepadEngine();
    const platform = pad.platform ?? hostGamepadPlatform();
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'gamepad';
    return {
        format: GAMEPAD_PROFILE_FORMAT,
        version: 1,
        // engine and system in the id too, as the same pad recorded under two has to bundle as two presets
        id: [slug, engine, platform].filter(Boolean).join('-'),
        name,
        family: profile.family,
        match: {
            device: identity.vendor && identity.product ? identity.key : undefined,
            name: identity.name,
            mapping: pad.mapping === 'standard' ? 'standard' : '',
            engine,
            platform,
            buttons: pad.buttons?.length,
            axes: pad.axes?.length,
        },
        deadZone: profile.deadZone,
        buttons: cloneButtons(profile.buttons),
        ...nonEmpty('turbo', cloneButtons(profile.turbo ?? {})),
        ...(actions && Object.keys(actions).length > 0 ? { actions } : {}),
    };
}

// undefined if it is not one
export function gamepadPresetFromFile(file: unknown): GamepadPreset | undefined {
    if (typeof file !== 'object' || file === null) {
        return undefined;
    }
    const candidate = file as Partial<GamepadProfileFile>;
    const match = candidate.match;
    if (candidate.format !== GAMEPAD_PROFILE_FORMAT || candidate.version !== 1
        || typeof candidate.id !== 'string' || !candidate.id
        || typeof candidate.name !== 'string'
        || typeof match !== 'object' || match === null
        || (typeof match.device !== 'string' && typeof match.name !== 'string')) {
        return undefined;
    }
    const count = (value: unknown): number | undefined =>
        Number.isInteger(value) && (value as number) >= 0 ? value as number : undefined;
    const buttons = normalizeButtons(candidate.buttons);
    const turbo = normalizeButtons(candidate.turbo);
    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const action of GAMEPAD_PAD_ACTIONS) {
        const sources = normalizeSources(candidate.actions?.[action]);
        if (sources.length > 0) {
            actions[action] = sources;
        }
    }
    // short strings on real source ids only: they are drawn on the picture
    const labels: Record<string, string> = {};
    for (const [id, label] of Object.entries(candidate.labels ?? {})) {
        if (parseGamepadSource(id) && typeof label === 'string' && label.length > 0 && label.length <= 8) {
            labels[id] = label;
        }
    }
    return {
        id: candidate.id,
        name: candidate.name,
        family: GAMEPAD_FAMILIES.includes(candidate.family as GamepadFamily)
            ? candidate.family as GamepadFamily
            : 'generic',
        match: {
            device: typeof match.device === 'string' ? match.device.toLowerCase() : undefined,
            name: typeof match.name === 'string' ? match.name : undefined,
            mapping: match.mapping === 'standard' ? 'standard' : '',
            engine: GAMEPAD_ENGINES.find(engine => engine === match.engine),
            platform: GAMEPAD_PLATFORMS.find(platform => platform === match.platform),
            buttons: count(match.buttons),
            axes: count(match.axes),
        },
        deadZone: typeof candidate.deadZone === 'number'
            ? Math.min(GAMEPAD_DEAD_ZONE_RANGE.max, Math.max(GAMEPAD_DEAD_ZONE_RANGE.min, candidate.deadZone))
            : undefined,
        buttons,
        ...nonEmpty('turbo', turbo),
        ...(Object.keys(actions).length > 0 ? { actions } : {}),
        ...(Object.keys(labels).length > 0 ? { labels } : {}),
    };
}

// or nothing when the map is empty, for an optional field
function nonEmpty<K extends string>(key: K, map: GamepadButtonMap): { [P in K]?: GamepadButtonMap } {
    return Object.keys(map).length > 0 ? { [key]: map } as { [P in K]?: GamepadButtonMap } : {};
}

// from something untrusted: known buttons and valid sources only
function normalizeButtons(buttons: unknown): GamepadButtonMap {
    const result: GamepadButtonMap = {};
    if (typeof buttons !== 'object' || buttons === null) {
        return result;
    }
    for (const key of GAMEPAD_BUTTONS) {
        const sources = normalizeSources((buttons as GamepadButtonMap)[key]);
        if (sources.length > 0) {
            result[key] = sources;
        }
    }
    return result;
}

// copied, the known ones only
function cloneActions(
    actions: Partial<Record<GamepadPadAction, GamepadSource[]>>,
): Partial<Record<GamepadPadAction, GamepadSource[]>> {
    const copy: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const action of GAMEPAD_PAD_ACTIONS) {
        const sources = actions[action];
        if (sources && sources.length > 0) {
            copy[action] = sources.map(source => ({ ...source }));
        }
    }
    return copy;
}

function cloneButtons(buttons: GamepadButtonMap): GamepadButtonMap {
    const copy: GamepadButtonMap = {};
    for (const key of GAMEPAD_BUTTONS) {
        const sources = buttons[key];
        if (sources && sources.length > 0) {
            copy[key] = sources.map(source => ({ ...source }));
        }
    }
    return copy;
}

// what was stored for it, what its preset says, or nothing. In `stored` the first entry filed under the device wins
export function resolveGamepadProfile(
    pad: GamepadDescriptor,
    stored: GamepadProfile[] = [],
    database?: GamepadDatabase,
): ResolvedGamepadProfile {
    const identity = gamepadIdentity(pad.id);
    const preset = detectGamepadPreset(pad, database);
    const mine = stored.find(profile => profile.device === identity.key);
    if (mine) {
        return {
            profile: normalizeProfile(mine, identity, database),
            origin: 'stored',
            // what it would go back to: the preset it was built from if that still exists, else what the pad detects
            // as now
            preset: gamepadPreset(mine.preset) ?? preset,
            identity,
        };
    }
    if (preset) {
        return { profile: profileFromPreset(preset, identity, database), origin: 'preset', preset, identity };
    }
    return {
        profile: {
            device: identity.key,
            label: database?.[identity.key]?.name ?? identity.name,
            family: detectGamepadFamily(identity, database),
            buttons: {},
            deadZone: DEFAULT_GAMEPAD_DEAD_ZONE,
        },
        origin: 'unmapped',
        identity,
    };
}

// settings come from localStorage and an editable file, so anything unusable is dropped before reaching the input
// loop, where a malformed index would silently stop a button working
export function normalizeProfile(
    profile: GamepadProfile,
    identity?: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    const buttons = normalizeButtons(profile.buttons);
    const turbo = normalizeButtons(profile.turbo);

    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (!(GAMEPAD_PAD_ACTIONS as readonly string[]).includes(action)) {
            continue;
        }
        const normalized = normalizeSources(sources);
        if (normalized.length > 0) {
            actions[action as GamepadPadAction] = normalized;
        }
    }

    const deadZone = typeof profile.deadZone === 'number' && Number.isFinite(profile.deadZone)
        ? Math.min(GAMEPAD_DEAD_ZONE_RANGE.max, Math.max(GAMEPAD_DEAD_ZONE_RANGE.min, profile.deadZone))
        : DEFAULT_GAMEPAD_DEAD_ZONE;

    const deviceKey = identity?.key ?? profile.device;
    return {
        device: deviceKey,
        label: profile.label ?? database?.[deviceKey]?.name ?? identity?.name,
        preset: gamepadPreset(profile.preset)?.id,
        family: profile.family ?? (identity ? detectGamepadFamily(identity, database) : 'generic'),
        buttons,
        ...nonEmpty('turbo', turbo),
        ...(Object.keys(actions).length > 0 ? { actions } : {}),
        deadZone,
    };
}

function normalizeSources(sources: unknown): GamepadSource[] {
    if (!Array.isArray(sources)) {
        return [];
    }
    const seen = new Set<string>();
    const result: GamepadSource[] = [];
    for (const source of sources) {
        const valid = normalizeSource(source);
        if (!valid) {
            continue;
        }
        const id = gamepadSourceId(valid);
        if (!seen.has(id)) {
            seen.add(id);
            result.push(valid);
        }
    }
    return result;
}

function normalizeSource(source: unknown): GamepadSource | undefined {
    if (typeof source !== 'object' || source === null) {
        return undefined;
    }
    const candidate = source as Partial<GamepadSource> & { direction?: number };
    if (!Number.isInteger(candidate.index) || (candidate.index as number) < 0) {
        return undefined;
    }
    if (candidate.kind === 'button') {
        return { kind: 'button', index: candidate.index as number };
    }
    if (candidate.kind === 'axis') {
        return {
            kind: 'axis',
            index: candidate.index as number,
            direction: ((candidate.direction as number | undefined) ?? 0) < 0 ? -1 : 1,
        };
    }
    if (candidate.kind === 'hat') {
        const direction = HAT_DIRECTIONS.find(known => known === candidate.direction);
        return direction ? { kind: 'hat', index: candidate.index as number, direction } : undefined;
    }
    return undefined;
}

// as much of one pad as reading it needs
export interface GamepadReading {
    buttons: readonly { pressed: boolean, value: number }[];
    axes: readonly number[];
}

// a stick never leaves -1…1; a hat rests beyond it (23/7 on the 8BitDo 64)
const HAT_REST_MARGIN = 0.05;

// out of any stick's range: a hat with nothing pressed
function isHatAtRest(value: number): boolean {
    return Math.abs(value) > 1 + HAT_REST_MARGIN;
}

// the eight positions are 2/7 apart; this is well under half of that
const HAT_POSITION_TOLERANCE = 0.06;

// positions run clockwise from up at -1 to up-left at 1, 2/7 apart, found by rounding, but only a value actually
// near one counts: Chrome reports every axis as 0 until the pad is first used, halfway between down-left and down,
// so an untouched 8BitDo 64 held its d-pad down
function hatDirections(value: number): GamepadHatDirection[] {
    if (isHatAtRest(value) || Number.isNaN(value)) {
        return [];
    }
    const steps = (value + 1) * 3.5;
    if (Math.abs(steps - Math.round(steps)) / 3.5 > HAT_POSITION_TOLERANCE) {
        return [];
    }
    const position = Math.round(steps) & 7;
    // each cardinal owns its own position and the diagonal on either side
    return HAT_DIRECTIONS.filter((_, cardinal) => {
        const offset = (position - cardinal * 2 + 8) & 7;
        return offset === 0 || offset === 1 || offset === 7;
    });
}

export function isSourcePressed(
    reading: GamepadReading,
    source: GamepadSource,
    deadZone: number,
): boolean {
    if (source.kind === 'button') {
        const held = reading.buttons[source.index];
        return held !== undefined && (held.pressed || held.value > BUTTON_THRESHOLD);
    }
    const value = reading.axes[source.index];
    if (value === undefined) {
        return false;
    }
    if (source.kind === 'hat') {
        return hatDirections(value).includes(source.direction);
    }
    // out of range is a hat at rest bound as a stick, which would otherwise hold its button while nothing is pressed
    if (isHatAtRest(value)) {
        return false;
    }
    return source.direction < 0 ? value <= -deadZone : value >= deadZone;
}

/**
 * Every source held, as ids, for the settings page to notice presses and light up held controls. Axes go through the
 * profile's dead zone, so the settings show what the game feels. `hats` is the caller's to keep across readings and
 * this grows it: a hat can only be told from a stick at rest (out of a stick's range), and a d-pad rests long before
 * anyone presses it.
 */
export function pressedGamepadSources(
    reading: GamepadReading,
    deadZone: number,
    hats: Set<number> = new Set(),
): Set<string> {
    const pressed = new Set<string>();
    reading.buttons.forEach((held, index) => {
        if (held && (held.pressed || held.value > BUTTON_THRESHOLD)) {
            pressed.add(gamepadSourceId({ kind: 'button', index }));
        }
    });
    reading.axes.forEach((value, index) => {
        if (isHatAtRest(value)) {
            hats.add(index);
            return;
        }
        if (hats.has(index)) {
            for (const direction of hatDirections(value)) {
                pressed.add(gamepadSourceId({ kind: 'hat', index, direction }));
            }
            return;
        }
        if (value <= -deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: -1 }));
        } else if (value >= deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: 1 }));
        }
    });
    return pressed;
}

export interface GamepadContribution {
    keys: number;
    // a set, so edges can be found
    actions: Set<EmulatorAction>;
    // the host's own actions, kept apart from the emulator's
    uiActions: Set<GamepadUiAction>;
    // as a key mask
    turboKeys: number;
    // 1-based
    macroSlots: Set<number>;
}

export function readGamepadContribution(
    reading: GamepadReading,
    profile: GamepadProfile,
): GamepadContribution {
    const held = (sources: GamepadSource[] | undefined): boolean =>
        sources?.some(source => isSourcePressed(reading, source, profile.deadZone)) ?? false;
    let keys = 0;
    let turboKeys = 0;
    for (const key of GAMEPAD_BUTTONS) {
        if (held(profile.buttons[key])) {
            keys |= vbKeyForButton(key);
        }
        if (held(profile.turbo?.[key])) {
            turboKeys |= vbKeyForButton(key);
        }
    }

    const actions = new Set<EmulatorAction>();
    const uiActions = new Set<GamepadUiAction>();
    const macroSlots = new Set<number>();
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (held(sources)) {
            const slot = gamepadMacroSlot(action);
            if (slot !== undefined) {
                macroSlots.add(slot);
            } else if (isUiAction(action)) {
                uiActions.add(action);
            } else {
                actions.add(action as EmulatorAction);
            }
        }
    }

    return { keys, actions, uiActions, turboKeys, macroSlots };
}

// takes a source off everything it drives (buttons, turbo, actions); every assignment starts from this, as one
// button driving two things is never wanted and hard to notice
function withSourceFreed(profile: GamepadProfile, source: GamepadSource): {
    buttons: GamepadButtonMap,
    turbo: GamepadButtonMap,
    actions: Partial<Record<GamepadPadAction, GamepadSource[]>>,
} {
    const strip = (map: GamepadButtonMap | undefined): GamepadButtonMap => {
        const result: GamepadButtonMap = {};
        for (const key of GAMEPAD_BUTTONS) {
            const remaining = withoutSource(map?.[key], source);
            if (remaining.length > 0) {
                result[key] = remaining;
            }
        }
        return result;
    };
    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        const remaining = withoutSource(sources, source);
        if (remaining.length > 0) {
            actions[action as GamepadPadAction] = remaining;
        }
    }
    return { buttons: strip(profile.buttons), turbo: strip(profile.turbo), actions };
}

// the turbo map is left out when empty
function withMaps(
    profile: GamepadProfile,
    maps: ReturnType<typeof withSourceFreed>,
): GamepadProfile {
    const { turbo: unused, ...rest } = profile;
    // the preset it came from is kept even after hand edits: that is where "reset to preset" goes back to
    return { ...rest, buttons: maps.buttons, ...nonEmpty('turbo', maps.turbo), actions: maps.actions };
}

// replacing by default, as pressing a button in the settings usually means only that one; `add` is the deliberate
// second step, for a d-pad and a stick on the same cross. The source is freed first either way (withSourceFreed)
export function assignGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.buttons[target] = add ? [...(maps.buttons[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

export function assignGamepadTurbo(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.turbo[target] = add ? [...(maps.turbo[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

// for an emulator action or a macro slot
export function assignGamepadAction(
    profile: GamepadProfile,
    target: GamepadPadAction,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.actions[target] = add ? [...(maps.actions[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

function withoutSource(sources: GamepadSource[] | undefined, source: GamepadSource): GamepadSource[] {
    return (sources ?? []).filter(existing => !sameGamepadSource(existing, source));
}

// the way to drop one of several on a control; a source only ever drives one control
export function removeGamepadSource(profile: GamepadProfile, source: GamepadSource): GamepadProfile {
    return withMaps(profile, withSourceFreed(profile, source));
}

export function clearGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
): GamepadProfile {
    const buttons = { ...profile.buttons };
    delete buttons[target];
    return { ...profile, buttons };
}

export function clearGamepadTurbo(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
): GamepadProfile {
    const { turbo, ...rest } = profile;
    const remaining = { ...(turbo ?? {}) };
    delete remaining[target];
    return { ...rest, ...nonEmpty('turbo', remaining) };
}

export function clearGamepadAction(
    profile: GamepadProfile,
    target: GamepadPadAction,
): GamepadProfile {
    const actions = { ...(profile.actions ?? {}) };
    delete actions[target];
    return { ...profile, actions };
}

// the list is the whole setting and every edit goes through this: exactly one entry per device
export function storeGamepadProfile(
    stored: GamepadProfile[],
    profile: GamepadProfile,
): GamepadProfile[] {
    const others = stored.filter(existing => existing.device !== profile.device);
    return [...others, profile];
}

// whether a profile binds every control and sets the dead zone exactly as the preset does
export function gamepadProfileMatchesPreset(profile: GamepadProfile, preset: GamepadPreset): boolean {
    const ids = (sources: GamepadSource[] | undefined): string =>
        (sources ?? []).map(gamepadSourceId).sort().join();
    return profile.deadZone === (preset.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE)
        && GAMEPAD_BUTTONS.every(key => ids(profile.buttons[key]) === ids(preset.buttons[key]))
        && GAMEPAD_BUTTONS.every(key => ids(profile.turbo?.[key]) === ids(preset.turbo?.[key]))
        && GAMEPAD_PAD_ACTIONS.every(action => ids(profile.actions?.[action]) === ids(preset.actions?.[action]));
}

// so it goes back to whatever is detected
export function forgetGamepadProfile(
    stored: GamepadProfile[],
    device: string,
): GamepadProfile[] {
    return stored.filter(existing => existing.device !== device);
}
