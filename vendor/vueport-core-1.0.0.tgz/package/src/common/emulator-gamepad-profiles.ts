/**
 * What a physical controller's buttons do, per device.
 *
 * The Gamepad API hands a page raw indices — `buttons[3]`, `axes[1]` — and says
 * nothing about what the person holding the pad would call them. A *profile* is
 * the table that closes that gap for one device: which index drives which
 * Virtual Boy button, which drives which emulator action, and how far a stick
 * has to move before it counts as a press.
 *
 * The reason this is a table rather than the fixed mapping it replaces is that
 * the raw indices are not portable. Chrome and Firefox enumerate the same pad
 * differently — Firefox reports an extra axis, so every axis index after it
 * shifts by one — and a pad the browser does not recognize is reported in
 * whatever order its HID descriptor happens to list.
 *
 * What *is* portable is `Gamepad.mapping === 'standard'`: both browsers carry
 * their own remapping tables (Chromium's `gamepad_standard_mappings.cc`,
 * Firefox since bug 1542893) and normalize every pad they recognize to the W3C
 * standard layout. That covers the large majority of controllers, and it is why
 * the built-in presets here are *semantic* rather than per-device: they all sit
 * on the standard layout and differ only in which face button is which and what
 * it is called. A pad the browser does not recognize gets no guess at all — it
 * gets the guided walk-through in the Game Pads settings, whose result is
 * verified rather than inferred, and is then remembered for that device.
 *
 * Deliberately free of DOM: everything here takes plain data, so the whole
 * resolution path can be exercised from `tests/gamepad-profile-probe.mjs`.
 */

import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';
import vbUsbAdapter from '../data/gamepad-profiles/vb-usb-adapter.json';
import EightBitDo64BtGecko from '../data/gamepad-profiles/8bitdo-64-bt-gecko.json';
import EightBitDo64BtChromium from '../data/gamepad-profiles/8bitdo-64-bt-chromium.json';
import EightBitDo64BtSdl from '../data/gamepad-profiles/8bitdo-64-bt-sdl.json';
import NintendoN64ControllerSdl from '../data/gamepad-profiles/nintendo-n64-controller-sdl.json';

/**
 * Which pad code each button presses.
 *
 * Spelled out rather than read from `EMULATOR_GAMEPAD_INPUTS`, which carries
 * `Command` objects and would pull the whole command table — and its
 * localization — into a module that only wants to know which bit a button
 * sets. Typed against the button union, so a button added to the emulator will
 * not compile here until it is given a code.
 */
const GAMEPAD_BUTTON_KEY_CODES: Record<EmulatorGamePadButton, EmulatorGamePadKeyCode> = {
    a: EmulatorGamePadKeyCode.A,
    b: EmulatorGamePadKeyCode.B,
    start: EmulatorGamePadKeyCode.Start,
    select: EmulatorGamePadKeyCode.Select,
    lUp: EmulatorGamePadKeyCode.LUp,
    lRight: EmulatorGamePadKeyCode.LRight,
    lDown: EmulatorGamePadKeyCode.LDown,
    lLeft: EmulatorGamePadKeyCode.LLeft,
    rUp: EmulatorGamePadKeyCode.RUp,
    rRight: EmulatorGamePadKeyCode.RRight,
    rDown: EmulatorGamePadKeyCode.RDown,
    rLeft: EmulatorGamePadKeyCode.RLeft,
    lTrigger: EmulatorGamePadKeyCode.LT,
    rTrigger: EmulatorGamePadKeyCode.RT,
};

/**
 * Every button, for iterating over. The same set as
 * `EMULATOR_GAMEPAD_BUTTONS`, in whatever order the table above lists them —
 * nothing here depends on the order, only on the set being complete, which the
 * `Record` type guarantees.
 */
const GAMEPAD_BUTTONS = Object.keys(GAMEPAD_BUTTON_KEY_CODES) as EmulatorGamePadButton[];

/** The mask bit one button contributes. */
export function vbKeyForButton(button: EmulatorGamePadButton): VbKey {
    return GAMEPAD_KEY_TO_VB_KEY[GAMEPAD_BUTTON_KEY_CODES[button]];
}

/**
 * The game pad codes the mappings speak, as the mask bits the core wants.
 *
 * Lives here rather than beside the keyboard handling because both the keyboard
 * and a physical pad have to end up as the same mask, and this is the module
 * both can reach without one depending on the other. Re-exported from
 * `emulator-input.ts`, which is where it used to live.
 */
export const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey> = {
    [EmulatorGamePadKeyCode.A]: VbKey.A,
    [EmulatorGamePadKeyCode.B]: VbKey.B,
    [EmulatorGamePadKeyCode.Start]: VbKey.STA,
    [EmulatorGamePadKeyCode.Select]: VbKey.SEL,
    [EmulatorGamePadKeyCode.LUp]: VbKey.LU,
    [EmulatorGamePadKeyCode.LRight]: VbKey.LR,
    [EmulatorGamePadKeyCode.LDown]: VbKey.LD,
    [EmulatorGamePadKeyCode.LLeft]: VbKey.LL,
    [EmulatorGamePadKeyCode.RUp]: VbKey.RU,
    [EmulatorGamePadKeyCode.RRight]: VbKey.RR,
    [EmulatorGamePadKeyCode.RDown]: VbKey.RD,
    [EmulatorGamePadKeyCode.RLeft]: VbKey.RL,
    [EmulatorGamePadKeyCode.LT]: VbKey.LT,
    [EmulatorGamePadKeyCode.RT]: VbKey.RT,
};

/**
 * One physical control: a button, one end of an axis, or one direction of a
 * hat switch.
 *
 * An axis carries a direction because a stick is being used as a d-pad here,
 * and the two halves of one axis are two different buttons as far as the
 * Virtual Boy is concerned. `direction` is the sign of the deflection that
 * counts as pressed.
 *
 * A hat is a d-pad that the browser hands over as a single axis rather than as
 * four buttons — Chrome and Firefox both do this for a pad they have no mapping
 * for, the 8BitDo 64 among them. The axis then holds one of eight positions,
 * evenly spaced from -1 (up) clockwise to 1 (up-left), and rests *outside*
 * -1…1 when nothing is pressed (23/7 on the 8BitDo 64, in both). Read as a
 * stick it is nonsense: resting, it looks like a full deflection; and left and
 * right sit at 5/7 and -3/7, one of which is under any sensible dead zone and
 * the other of which is the same sign as resting, so it never shows up as a
 * new press.
 */
export type GamepadSource =
    | { kind: 'button', index: number }
    | { kind: 'axis', index: number, direction: -1 | 1 }
    | { kind: 'hat', index: number, direction: GamepadHatDirection };

export type GamepadHatDirection = 'up' | 'right' | 'down' | 'left';

const HAT_DIRECTIONS: readonly GamepadHatDirection[] = ['up', 'right', 'down', 'left'];

/** A source as a string, for comparing and for using as a key. */
export function gamepadSourceId(source: GamepadSource): string {
    switch (source.kind) {
        case 'button':
            return `b${source.index}`;
        case 'axis':
            return `a${source.index}${source.direction < 0 ? '-' : '+'}`;
        case 'hat':
            return `h${source.index}${source.direction[0]}`;
    }
}

/** Parse back what {@link gamepadSourceId} wrote; undefined if it is not one. */
export function parseGamepadSource(id: string): GamepadSource | undefined {
    const asButton = /^b(\d+)$/.exec(id);
    if (asButton) {
        return { kind: 'button', index: Number(asButton[1]) };
    }
    const asAxis = /^a(\d+)([-+])$/.exec(id);
    if (asAxis) {
        return { kind: 'axis', index: Number(asAxis[1]), direction: asAxis[2] === '-' ? -1 : 1 };
    }
    const asHat = /^h(\d+)([urdl])$/.exec(id);
    if (asHat) {
        const direction = HAT_DIRECTIONS.find(candidate => candidate[0] === asHat[2])!;
        return { kind: 'hat', index: Number(asHat[1]), direction };
    }
    return undefined;
}

export function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean {
    return gamepadSourceId(a) === gamepadSourceId(b);
}

/**
 * Whose button glyphs a pad wears.
 *
 * Not cosmetic: the families disagree about which face button is which. A
 * Nintendo pad's A sits where an Xbox pad's B does, and a PlayStation pad calls
 * the same two ○ and ✕. Since a Virtual Boy's A is the *rightmost* face button,
 * "VB A" lands on a differently-named button depending on the family, and a
 * settings page that showed the wrong name would be worse than one that showed
 * a bare index.
 */
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';

const GAMEPAD_FAMILIES: readonly GamepadFamily[] = ['xbox', 'playstation', 'nintendo', 'generic'];

/**
 * The browser engine a raw pad is recorded under. A raw recording has to be
 * kept apart between them: the 8BitDo 64 shows its d-pad as axis 0 of 7 in
 * Firefox and as a later axis in Chrome.
 *
 * `sdl` is not a browser: it is the desktop shell reading pads through SDL
 * instead of through its webview, which numbers a raw pad SDL's way. A pad
 * read like that says so itself — see `engine` on {@link GamepadDescriptor},
 * which the desktop's pads carry — since the webview it runs in is WebKit.
 */
export type GamepadEngine = 'chromium' | 'gecko' | 'webkit' | 'sdl';

const GAMEPAD_ENGINES: readonly GamepadEngine[] = ['chromium', 'gecko', 'webkit', 'sdl'];

/**
 * The engine this page runs in; undefined outside a browser.
 *
 * Asked of the user agent rather than read off the pad's id, although the ids
 * do differ in shape: Safari writes `vendor-product-name` like Firefox, so a
 * pad whose ids happen to be four digits long would pass for Firefox.
 */
export function hostGamepadEngine(): GamepadEngine | undefined {
    if (typeof navigator === 'undefined' || !navigator.userAgent) {
        return undefined;
    }
    const agent = navigator.userAgent;
    if (/firefox\//i.test(agent)) {
        return 'gecko';
    }
    // Every Chromium says AppleWebKit too, so Chrome is asked first; and every
    // browser on iOS is WebKit whatever it calls itself.
    if (/chrome\/|chromium\/|crios\//i.test(agent) && !/iphone|ipad|ipod/i.test(agent)) {
        return 'chromium';
    }
    return /applewebkit\//i.test(agent) ? 'webkit' : undefined;
}

/**
 * The operating system a raw pad is recorded on. As much a part of a raw
 * layout as the engine: each engine reads pads through a different backend
 * per system — IOKit on macOS, Raw Input on Windows, joydev on Linux — and
 * each backend numbers what it finds its own way.
 */
export type GamepadPlatform = 'macos' | 'windows' | 'linux' | 'chromeos' | 'android' | 'ios';

const GAMEPAD_PLATFORMS: readonly GamepadPlatform[] = ['macos', 'windows', 'linux', 'chromeos', 'android', 'ios'];

/**
 * The system this page runs on, as far as the browser says; undefined outside
 * one. The id carries no trace of it, so it is asked of `navigator`.
 */
export function hostGamepadPlatform(): GamepadPlatform | undefined {
    if (typeof navigator === 'undefined') {
        return undefined;
    }
    const hinted = (navigator as { userAgentData?: { platform?: string } }).userAgentData?.platform;
    const text = `${hinted ?? ''} ${navigator.userAgent ?? ''}`;
    // iPadOS asks for desktop pages as a Mac; the touch screen gives it away.
    if (/iphone|ipad|ipod/i.test(text) || (/mac/i.test(text) && (navigator.maxTouchPoints ?? 0) > 1)) {
        return 'ios';
    }
    if (/android/i.test(text)) {
        return 'android';
    }
    if (/cros|chrome os/i.test(text)) {
        return 'chromeos';
    }
    if (/mac/i.test(text)) {
        return 'macos';
    }
    if (/win/i.test(text)) {
        return 'windows';
    }
    if (/linux/i.test(text)) {
        return 'linux';
    }
    return undefined;
}

/**
 * What a pad button can do outside the game and outside the emulator: open
 * the host's command palette. The host decides whether it has one — the
 * standalone build does, a host without one leaves the binding unused — and
 * reads it on its own loop, since it has to work with no game running and
 * while the palette it opened is taking the input.
 */
export type GamepadUiAction = 'commandPalette';

export const GAMEPAD_UI_ACTIONS: readonly GamepadUiAction[] = ['commandPalette'];

/**
 * Playing whichever macro sits in a slot — see `setSlot` in the macro store.
 * Eight, as the Macros panel numbers them.
 */
export type GamepadMacroAction =
    'macro1' | 'macro2' | 'macro3' | 'macro4' | 'macro5' | 'macro6' | 'macro7' | 'macro8';

export const GAMEPAD_MACRO_ACTIONS: readonly GamepadMacroAction[] =
    ['macro1', 'macro2', 'macro3', 'macro4', 'macro5', 'macro6', 'macro7', 'macro8'];

/** The slot (1-based) a macro action plays, or undefined for any other action. */
export function gamepadMacroSlot(action: string): number | undefined {
    const index = (GAMEPAD_MACRO_ACTIONS as readonly string[]).indexOf(action);
    return index === -1 ? undefined : index + 1;
}

/** The action that plays a slot (1-based). */
export function gamepadMacroAction(slot: number): GamepadMacroAction {
    return GAMEPAD_MACRO_ACTIONS[slot - 1];
}

/** Anything a pad control can be bound to besides a Virtual Boy button. */
export type GamepadPadAction = EmulatorAction | GamepadUiAction | GamepadMacroAction;

/** Every action a pad control can be bound to, the host's and the emulator's. */
const GAMEPAD_PAD_ACTIONS: readonly GamepadPadAction[] = [
    ...GAMEPAD_UI_ACTIONS,
    ...Object.values(EmulatorAction),
    ...GAMEPAD_MACRO_ACTIONS,
];

const isUiAction = (action: string): action is GamepadUiAction =>
    (GAMEPAD_UI_ACTIONS as readonly string[]).includes(action);

/** The buttons a pad control is bound to, by Virtual Boy button — plain or on turbo. */
export type GamepadButtonMap = Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;

/** One device's mapping, as it is stored and as the input loop reads it. */
export interface GamepadProfile {
    /**
     * What this profile is filed under: `vendor:product` in lower-case hex
     * ("054c:05c4") when the browser's id carries them, and the whole id
     * otherwise. See {@link gamepadDeviceKey}.
     */
    device: string;
    /** The name to show. The browser's id cleaned up, or the database's. */
    label?: string;
    /**
     * Which built-in preset this started as, so "reset to preset" knows where
     * back is. Absent for a profile built entirely by hand.
     */
    preset?: string;
    family: GamepadFamily;
    /**
     * More than one source per button on purpose: the standard presets put both
     * the d-pad and the left stick on the Virtual Boy's left cross, which is
     * what makes a modern pad feel right on a machine that has two of them.
     */
    buttons: GamepadButtonMap;
    /**
     * Virtual Boy buttons held on turbo: pressed and released over and over
     * for as long as the source is held. Same shape as `buttons`, and a source
     * drives one or the other, never both.
     */
    turbo?: GamepadButtonMap;
    /**
     * Emulator actions — pause, save state, rewind — on the pad, and the
     * host's own (see {@link GamepadUiAction}), and the macro slots (see
     * {@link GamepadMacroAction}). Usually only the host's.
     */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /**
     * How far a stick must move before it reads as pressed, 0–1.
     *
     * Generous by default, because the control it stands in for is digital and
     * a partial press has no meaning to the machine.
     */
    deadZone: number;
}

/** What a stick deflection has to reach before it counts, when nothing says otherwise. */
export const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;

/** The narrowest and widest dead zone the settings will offer. */
export const GAMEPAD_DEAD_ZONE_RANGE = { min: 0.1, max: 0.9 };

/** Analog buttons still need a digital answer. */
const BUTTON_THRESHOLD = 0.5;

const padButton = (index: number): GamepadSource => ({ kind: 'button', index });
const padAxis = (index: number, direction: -1 | 1): GamepadSource =>
    ({ kind: 'axis', index, direction });

/**
 * The W3C standard layout, as the Virtual Boy wants it.
 *
 * Both the d-pad (12–15) and the left stick (axes 0/1) drive the left cross,
 * and the right stick (axes 2/3) drives the right one — the Virtual Boy's
 * second d-pad has no equivalent on a modern pad, and the right stick is the
 * closest thing to one. A and B follow the machine's own arrangement, where A
 * is the rightmost of the two face buttons; on the standard layout that is
 * button 1, with button 0 below it as B.
 *
 * Shoulders and triggers both reach LT/RT, so it does not matter which pair a
 * given pad puts where.
 */
const STANDARD_BUTTONS: Record<EmulatorGamePadButton, GamepadSource[]> = {
    a: [padButton(1)],
    b: [padButton(0)],
    select: [padButton(8)],
    start: [padButton(9)],
    lTrigger: [padButton(4), padButton(6)],
    rTrigger: [padButton(5), padButton(7)],
    lUp: [padButton(12), padAxis(1, -1)],
    lDown: [padButton(13), padAxis(1, 1)],
    lLeft: [padButton(14), padAxis(0, -1)],
    lRight: [padButton(15), padAxis(0, 1)],
    rUp: [padAxis(3, -1)],
    rDown: [padAxis(3, 1)],
    rLeft: [padAxis(2, -1)],
    rRight: [padAxis(2, 1)],
};

/**
 * What the standard layout's other controls do: the ones the Virtual Boy has
 * no use for.
 *
 * Home — Guide, PS, the Nintendo house — opens the command palette: the one
 * control on a pad nothing else in a game ever uses. The two face buttons the
 * machine does not have (left and top, 2 and 3) take the two things done most
 * while playing, rewinding and fast forward; the two stick clicks take pause
 * and a screenshot.
 *
 * Saving and loading a state are left off on purpose. Both are a stray press
 * away from overwriting a save or throwing away the last half hour, and the
 * stick clicks in particular get pressed by accident by anyone steering with
 * the stick.
 */
const STANDARD_ACTIONS: Partial<Record<GamepadPadAction, GamepadSource[]>> = {
    commandPalette: [padButton(16)],
    [EmulatorAction.Rewind]: [padButton(2)],
    [EmulatorAction.ToggleFastForward]: [padButton(3)],
    [EmulatorAction.PauseToggle]: [padButton(10)],
    [EmulatorAction.Screenshot]: [padButton(11)],
};

/** A preset offered in the settings, and applied on detection. */
export interface GamepadPreset {
    id: string;
    /** English; the settings localize it through {@link gamepadPresetLabel}. */
    name: string;
    family: GamepadFamily;
    /** Only offered by hand — never the automatic answer for a detected pad. */
    manualOnly?: boolean;
    /**
     * Set only on a preset written for one particular device rather than for
     * the standard layout — a bundled profile file, see
     * {@link GamepadProfileFile}. Such a preset is offered, and detected, only
     * for the pad it was recorded on, and only while the browser reports that
     * pad the way it did then.
     */
    match?: GamepadDeviceMatch;
    /** The dead zone it was recorded with, when it is not the default. */
    deadZone?: number;
    buttons: GamepadButtonMap;
    /** Buttons held on turbo; see {@link GamepadProfile.turbo}. */
    turbo?: GamepadButtonMap;
    /** What the pad's other controls do — the emulator's actions, and Home opening the palette. */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /**
     * What a device's controls are printed with, by source id ("b8": "C↑").
     * For the settings page: the families' names are the standard layout's,
     * and a pad whose layout is not one of theirs — an N64 pad, its C buttons
     * on the standard layout's Back and face buttons — would be labelled with
     * buttons it does not have.
     */
    labels?: Record<string, string>;
}

/**
 * Which one device a bundled profile is for, and how the browser showed it.
 *
 * The how matters as much as the which. A pad the browser has not normalized
 * arrives in its own HID order, and a table recorded in that order stops being
 * right the moment a browser learns the pad and remaps it to the standard
 * layout — so `mapping` has to agree. And the browsers disagree among
 * themselves about a raw pad: Firefox reports an extra axis on some, which
 * shifts every index after it, and a hat is an axis in one and four buttons in
 * another. The counts are what catch that: a pad showing a different number of
 * buttons or axes than it did when recorded is not laid out the same way, and
 * gets no guess rather than a wrong one.
 */
export interface GamepadDeviceMatch {
    /** `vendor:product`, as {@link gamepadDeviceKey} files it. */
    device?: string;
    /** The name the device reports, as {@link gamepadName} reads it; any case. */
    name?: string;
    /** `Gamepad.mapping` when it was recorded: `'standard'`, or `''` for raw. */
    mapping: string;
    /**
     * The engine it was recorded in. Set, the preset applies in that engine
     * only: two engines can show a raw pad with the same counts and still in a
     * different order. Absent means any — right only for a pad whose layout
     * is known to be the same everywhere, like the VB USB Adapter's buttons.
     */
    engine?: GamepadEngine;
    /** The system it was recorded on; absent means any, as with `engine`. */
    platform?: GamepadPlatform;
    buttons?: number;
    axes?: number;
}

/**
 * One controller's mapping as a file: what the Game Pads settings export, and
 * what ships with VUEPort in `src/data/gamepad-profiles/`.
 *
 * The same shape both ways on purpose — bundling a mapping somebody recorded is
 * dropping their export into that folder and listing it in
 * {@link BUNDLED_GAMEPAD_PROFILES}, with nothing to translate in between.
 */
export interface GamepadProfileFile {
    format: typeof GAMEPAD_PROFILE_FORMAT;
    version: 1;
    /** The preset id it becomes; a stored profile's `preset` names it. */
    id: string;
    name: string;
    family: GamepadFamily;
    match: GamepadDeviceMatch;
    deadZone: number;
    buttons: GamepadButtonMap;
    /** Buttons held on turbo; see {@link GamepadProfile.turbo}. */
    turbo?: GamepadButtonMap;
    /** The emulator's and the host's actions; see {@link gamepadProfileFile}. */
    actions?: Partial<Record<GamepadPadAction, GamepadSource[]>>;
    /** What the controls are printed with; see {@link GamepadPreset.labels}. */
    labels?: Record<string, string>;
}

export const GAMEPAD_PROFILE_FORMAT = 'vueport-gamepad-profile';

/**
 * The profile files that ship with VUEPort. Adding one is a new file in
 * `src/data/gamepad-profiles/` and a line here.
 */
const BUNDLED_GAMEPAD_PROFILES: unknown[] = [
    vbUsbAdapter,
    EightBitDo64BtGecko,
    EightBitDo64BtChromium,
    EightBitDo64BtSdl,
    // Nintendo's Switch Online N64 controller, and the 8BitDo 64 in its Switch
    // mode, which presents as one. Read by SDL's own Switch driver, whose
    // layout is the same on every system — so no platform. That driver puts
    // the C buttons on Back, West, North and Misc 2, and there is no minus or
    // stick click to put anywhere: the pad it copies has neither. Measured off
    // the 8BitDo with the shell's raw log, 2026-10-08.
    NintendoN64ControllerSdl,
];

/**
 * What a preset is worth applying to.
 *
 * All the standard ones share one button table and differ only in family, since
 * the browser has already done the physical-to-semantic translation by the time
 * `mapping === 'standard'` holds. The family is what decides the glyphs, and
 * the glyphs are the whole visible difference.
 *
 * `standard-nofaceswap` is the exception that earns its place: a handful of
 * pads — mostly Nintendo layouts driven through a browser that maps them
 * positionally rather than by label — end up with A and B the other way round
 * from what is printed on the shell. It is offered by hand rather than
 * detected, because there is no way to tell from the id which it will be.
 *
 * The bundled ones are the other kind: one device's mapping, recorded off the
 * device and matched by its `match`.
 */
export const GAMEPAD_PRESETS: GamepadPreset[] = [
    {
        id: 'standard-xbox',
        name: 'Xbox',
        family: 'xbox',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    {
        id: 'standard-playstation',
        name: 'PlayStation',
        family: 'playstation',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    {
        id: 'standard-nintendo',
        name: 'Nintendo',
        family: 'nintendo',
        buttons: STANDARD_BUTTONS,
        actions: STANDARD_ACTIONS,
    },
    { id: 'standard-generic', name: 'Standard', family: 'generic', buttons: STANDARD_BUTTONS, actions: STANDARD_ACTIONS },
    {
        id: 'standard-nofaceswap',
        name: 'Standard (A/B swapped)',
        family: 'generic',
        manualOnly: true,
        buttons: { ...STANDARD_BUTTONS, a: [padButton(0)], b: [padButton(1)] },
        actions: STANDARD_ACTIONS,
    },
    ...BUNDLED_GAMEPAD_PROFILES.map(file => {
        const preset = gamepadPresetFromFile(file);
        if (!preset) {
            // A file in the repository that does not read is a build mistake,
            // not something to skip past quietly; the probe reads every one.
            throw new Error(`Bundled game pad profile does not read: ${JSON.stringify(file).slice(0, 80)}`);
        }
        return preset;
    }),
];

export function gamepadPreset(id: string | undefined): GamepadPreset | undefined {
    return id === undefined ? undefined : GAMEPAD_PRESETS.find(preset => preset.id === id);
}

/** What the browser's id says about a device. */
export interface GamepadIdentity {
    /** Four lower-case hex digits, when the id carries them. */
    vendor?: string;
    product?: string;
    /** The readable part, with the identifiers stripped off both ends. */
    name: string;
    /** What a profile for this device is filed under. */
    key: string;
}

/**
 * Take a device apart into the name a person would read and the ids a lookup
 * needs.
 *
 * The two browsers write the same information in different shapes. Chrome:
 * `Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 05c4)`, with the
 * identifiers in a trailing parenthetical. Firefox: `054c-05c4-Wireless
 * Controller`, with them in front. Both are handled, and an id in neither shape
 * comes back as a name with no ids — which still works, since the whole id is
 * then the key.
 */
export function gamepadIdentity(id: string): GamepadIdentity {
    let vendor: string | undefined;
    let product: string | undefined;

    const chrome = /vendor:\s*([0-9a-f]{4}).*?product:\s*([0-9a-f]{4})/i.exec(id);
    if (chrome) {
        vendor = chrome[1].toLowerCase();
        product = chrome[2].toLowerCase();
    }
    const firefox = /^([0-9a-f]{4})-([0-9a-f]{4})-/i.exec(id);
    if (firefox) {
        vendor = firefox[1].toLowerCase();
        product = firefox[2].toLowerCase();
    }

    return {
        vendor,
        product,
        name: gamepadName(id),
        key: vendor && product ? `${vendor}:${product}` : id,
    };
}

/**
 * What to call a controller.
 *
 * The browser's id is built for matching rather than for reading, so this takes
 * the name back out and returns the id untouched if it is not in a shape it
 * recognizes: an odd name is better than an empty one.
 */
export function gamepadName(id: string): string {
    // The trailing parenthetical, whenever it is the API talking rather than
    // the manufacturer: the vendor and product ids, or the layout it maps to.
    let name = id.replace(
        /\s*\([^()]*\b(?:vendor:|product:|standard gamepad)[^()]*\)\s*$/i, '');
    // Firefox leads with the same pair again, as `054c-05c4-`.
    name = name.replace(/^[0-9a-f]{4}-[0-9a-f]{4}-/i, '').trim();
    return name || id;
}

/** What a profile for this device is filed under. */
export function gamepadDeviceKey(id: string): string {
    return gamepadIdentity(id).key;
}

/**
 * Vendors whose pads wear one family's glyphs throughout.
 *
 * Only the ones where the vendor id alone settles it. 8BitDo (2dc8) is
 * deliberately absent: it ships Nintendo-, Xbox- and PlayStation-labeled pads
 * under one vendor id, so its models are told apart by name below, or by the
 * harvested database.
 */
const FAMILY_BY_VENDOR: Record<string, GamepadFamily> = {
    '045e': 'xbox',        // Microsoft
    '054c': 'playstation', // Sony
    '057e': 'nintendo',    // Nintendo
    '0f0d': 'nintendo',    // Hori, near enough always a Nintendo layout
    '0e6f': 'xbox',        // PDP
    '24c6': 'xbox',        // PowerA / ThrustMaster Xbox line
};

/** Names that give the family away when the vendor id does not. */
const FAMILY_BY_NAME: { pattern: RegExp, family: GamepadFamily }[] = [
    { pattern: /xbox|xinput|x-?input/i, family: 'xbox' },
    { pattern: /dual\s*sense|dual\s*shock|playstation|\bps[345]\b/i, family: 'playstation' },
    { pattern: /switch|joy-?con|nintendo|\bsnes\b|\bnes\b|wii/i, family: 'nintendo' },
    // 8BitDo names its Nintendo-layout pads after the consoles they copy.
    { pattern: /\bsn30\b|\bsf30\b|\bn30\b/i, family: 'nintendo' },
];

/**
 * One entry of the harvested device database — see
 * `scripts/fetch-controller-db.mjs`. Keyed by `vendor:product`.
 */
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}

export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;

/**
 * Which family a pad belongs to.
 *
 * The database first, since it was harvested from people who had the device in
 * hand; then the vendor id; then the name. Everything falls back to `generic`,
 * which shows bare indices rather than a wrong glyph.
 */
export function detectGamepadFamily(
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadFamily {
    const entry = database?.[identity.key];
    if (entry?.family) {
        return entry.family;
    }
    if (identity.vendor && FAMILY_BY_VENDOR[identity.vendor]) {
        return FAMILY_BY_VENDOR[identity.vendor];
    }
    const name = entry?.name ?? identity.name;
    for (const { pattern, family } of FAMILY_BY_NAME) {
        if (pattern.test(name)) {
            return family;
        }
    }
    return 'generic';
}

/** Just enough of a `Gamepad` to resolve a profile for it. */
export interface GamepadDescriptor {
    id: string;
    /** `'standard'` when the browser has normalized the pad; `''` when not. */
    mapping: string;
    /** Only counted, to tell layouts apart — see {@link GamepadDeviceMatch}. */
    buttons?: ArrayLike<unknown>;
    axes?: ArrayLike<unknown>;
    /** The engine and system it is seen in; the host's own when not given. */
    engine?: GamepadEngine;
    platform?: GamepadPlatform;
}

/** Whether a device preset was recorded on this pad, shown the way it is now. */
function matchesDevice(match: GamepadDeviceMatch, pad: GamepadDescriptor, identity: GamepadIdentity): boolean {
    if ((match.mapping === 'standard') !== (pad.mapping === 'standard')) {
        return false;
    }
    if (match.engine !== undefined && match.engine !== (pad.engine ?? hostGamepadEngine())) {
        return false;
    }
    if (match.platform !== undefined && match.platform !== (pad.platform ?? hostGamepadPlatform())) {
        return false;
    }
    const sameDevice = match.device !== undefined && match.device === identity.key;
    const sameName = match.name !== undefined && match.name.toLowerCase() === identity.name.toLowerCase();
    if (!sameDevice && !sameName) {
        return false;
    }
    if (match.buttons !== undefined && pad.buttons && pad.buttons.length !== match.buttons) {
        return false;
    }
    return match.axes === undefined || !pad.axes || pad.axes.length === match.axes;
}

/** The device presets recorded on this pad, if any. */
function devicePresetsFor(pad: GamepadDescriptor, identity: GamepadIdentity): GamepadPreset[] {
    return GAMEPAD_PRESETS.filter(preset => preset.match && matchesDevice(preset.match, pad, identity));
}

/** What resolution decided, and why — the settings page shows the reason. */
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    /**
     * Where the mapping came from. `stored` is the person's own, `preset` was
     * detected, and `unmapped` means the browser does not recognize the pad and
     * nothing has been recorded for it yet — the one case with no working
     * mapping, and the one the settings page asks somebody to fix.
     */
    origin: 'stored' | 'preset' | 'unmapped';
    /** The preset it would reset to, when there is one. */
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}

/**
 * Which preset a pad should start on, or undefined if it cannot be guessed.
 *
 * Undefined is the honest answer for a pad the browser has not normalized: its
 * indices are in whatever order the device's HID descriptor lists them, and no
 * table written here could know that order. Guessing would produce a mapping
 * that looks configured and is wrong, which is worse than one that asks to be
 * set up. See the note at the top of this file. The exception is a device
 * whose mapping somebody has recorded and bundled — see `match` on the presets
 * — which wins over the general presets for a normalized pad too.
 */
export function detectGamepadPreset(
    pad: GamepadDescriptor,
    database?: GamepadDatabase,
): GamepadPreset | undefined {
    const identity = gamepadIdentity(pad.id);
    const own = devicePresetsFor(pad, identity)[0];
    if (own || pad.mapping !== 'standard') {
        return own;
    }
    const family = detectGamepadFamily(identity, database);
    return GAMEPAD_PRESETS.find(preset =>
        !preset.manualOnly && !preset.match && preset.family === family)
        ?? gamepadPreset('standard-generic');
}

/**
 * The presets the settings offer for one pad.
 *
 * Every standard one; the A/B-swapped one only where the standard layout is
 * actually in force; and a device's own only for that device, and only while
 * the browser shows it the way it was recorded — first, since it is the one
 * that fits.
 */
export function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[] {
    const standard = pad.mapping === 'standard';
    const own = devicePresetsFor(pad, gamepadIdentity(pad.id));
    const general = GAMEPAD_PRESETS.filter(preset =>
        !preset.match && (!preset.manualOnly || standard));
    return [...own, ...general];
}

/** Build a fresh profile for a device from a preset. */
export function profileFromPreset(
    preset: GamepadPreset,
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    return {
        device: identity.key,
        label: database?.[identity.key]?.name ?? identity.name,
        preset: preset.id,
        family: preset.family,
        // Copied rather than shared: every preset above points at one
        // `STANDARD_BUTTONS`, and a profile is about to be edited.
        buttons: cloneButtons(preset.buttons),
        ...nonEmpty('turbo', cloneButtons(preset.turbo ?? {})),
        ...(preset.actions ? { actions: cloneActions(preset.actions) } : {}),
        deadZone: preset.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE,
    };
}

/**
 * A profile as a file for bundling, recorded off the pad it is in force for.
 *
 * Everything bound travels: the buttons, and the actions with them — Home
 * opening the palette, and the emulator's own, rewind and the rest. A profile
 * that ships is somebody's whole setup of a pad, and one that leaves the
 * other controls doing nothing is the worse default for the next person.
 */
export function gamepadProfileFile(profile: GamepadProfile, pad: GamepadDescriptor): GamepadProfileFile {
    const identity = gamepadIdentity(pad.id);
    const name = profile.label ?? identity.name;
    const actions = profile.actions ? cloneActions(profile.actions) : undefined;
    const engine = pad.engine ?? hostGamepadEngine();
    const platform = pad.platform ?? hostGamepadPlatform();
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'gamepad';
    return {
        format: GAMEPAD_PROFILE_FORMAT,
        version: 1,
        // Engine and system in the id too, since a recording holds for one of
        // each and the same pad recorded under two has to bundle as two presets.
        id: [slug, engine, platform].filter(Boolean).join('-'),
        name,
        family: profile.family,
        match: {
            device: identity.vendor && identity.product ? identity.key : undefined,
            name: identity.name,
            mapping: pad.mapping === 'standard' ? 'standard' : '',
            engine,
            platform,
            buttons: pad.buttons?.length,
            axes: pad.axes?.length,
        },
        deadZone: profile.deadZone,
        buttons: cloneButtons(profile.buttons),
        ...nonEmpty('turbo', cloneButtons(profile.turbo ?? {})),
        ...(actions && Object.keys(actions).length > 0 ? { actions } : {}),
    };
}

/** Read a profile file back as a preset; undefined if it is not one. */
export function gamepadPresetFromFile(file: unknown): GamepadPreset | undefined {
    if (typeof file !== 'object' || file === null) {
        return undefined;
    }
    const candidate = file as Partial<GamepadProfileFile>;
    const match = candidate.match;
    if (candidate.format !== GAMEPAD_PROFILE_FORMAT || candidate.version !== 1
        || typeof candidate.id !== 'string' || !candidate.id
        || typeof candidate.name !== 'string'
        || typeof match !== 'object' || match === null
        || (typeof match.device !== 'string' && typeof match.name !== 'string')) {
        return undefined;
    }
    const count = (value: unknown): number | undefined =>
        Number.isInteger(value) && (value as number) >= 0 ? value as number : undefined;
    const buttons = normalizeButtons(candidate.buttons);
    const turbo = normalizeButtons(candidate.turbo);
    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const action of GAMEPAD_PAD_ACTIONS) {
        const sources = normalizeSources(candidate.actions?.[action]);
        if (sources.length > 0) {
            actions[action] = sources;
        }
    }
    // Short strings on real source ids only: they are drawn on the picture.
    const labels: Record<string, string> = {};
    for (const [id, label] of Object.entries(candidate.labels ?? {})) {
        if (parseGamepadSource(id) && typeof label === 'string' && label.length > 0 && label.length <= 8) {
            labels[id] = label;
        }
    }
    return {
        id: candidate.id,
        name: candidate.name,
        family: GAMEPAD_FAMILIES.includes(candidate.family as GamepadFamily)
            ? candidate.family as GamepadFamily
            : 'generic',
        match: {
            device: typeof match.device === 'string' ? match.device.toLowerCase() : undefined,
            name: typeof match.name === 'string' ? match.name : undefined,
            mapping: match.mapping === 'standard' ? 'standard' : '',
            engine: GAMEPAD_ENGINES.find(engine => engine === match.engine),
            platform: GAMEPAD_PLATFORMS.find(platform => platform === match.platform),
            buttons: count(match.buttons),
            axes: count(match.axes),
        },
        deadZone: typeof candidate.deadZone === 'number'
            ? Math.min(GAMEPAD_DEAD_ZONE_RANGE.max, Math.max(GAMEPAD_DEAD_ZONE_RANGE.min, candidate.deadZone))
            : undefined,
        buttons,
        ...nonEmpty('turbo', turbo),
        ...(Object.keys(actions).length > 0 ? { actions } : {}),
        ...(Object.keys(labels).length > 0 ? { labels } : {}),
    };
}

/** `{ [key]: map }`, or nothing at all when the map is empty — for an optional field. */
function nonEmpty<K extends string>(key: K, map: GamepadButtonMap): { [P in K]?: GamepadButtonMap } {
    return Object.keys(map).length > 0 ? { [key]: map } as { [P in K]?: GamepadButtonMap } : {};
}

/** A button map read from something untrusted: known buttons and valid sources only. */
function normalizeButtons(buttons: unknown): GamepadButtonMap {
    const result: GamepadButtonMap = {};
    if (typeof buttons !== 'object' || buttons === null) {
        return result;
    }
    for (const key of GAMEPAD_BUTTONS) {
        const sources = normalizeSources((buttons as GamepadButtonMap)[key]);
        if (sources.length > 0) {
            result[key] = sources;
        }
    }
    return result;
}

/** The actions out of a set of bound ones, copied — the known ones only. */
function cloneActions(
    actions: Partial<Record<GamepadPadAction, GamepadSource[]>>,
): Partial<Record<GamepadPadAction, GamepadSource[]>> {
    const copy: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const action of GAMEPAD_PAD_ACTIONS) {
        const sources = actions[action];
        if (sources && sources.length > 0) {
            copy[action] = sources.map(source => ({ ...source }));
        }
    }
    return copy;
}

function cloneButtons(buttons: GamepadButtonMap): GamepadButtonMap {
    const copy: GamepadButtonMap = {};
    for (const key of GAMEPAD_BUTTONS) {
        const sources = buttons[key];
        if (sources && sources.length > 0) {
            copy[key] = sources.map(source => ({ ...source }));
        }
    }
    return copy;
}

/**
 * The mapping in force for one pad: what was stored for it, what its preset
 * says, or nothing at all.
 *
 * `stored` is whatever the settings hold, in no particular order; the first
 * entry filed under this device wins.
 */
export function resolveGamepadProfile(
    pad: GamepadDescriptor,
    stored: GamepadProfile[] = [],
    database?: GamepadDatabase,
): ResolvedGamepadProfile {
    const identity = gamepadIdentity(pad.id);
    const preset = detectGamepadPreset(pad, database);
    const mine = stored.find(profile => profile.device === identity.key);
    if (mine) {
        return {
            profile: normalizeProfile(mine, identity, database),
            origin: 'stored',
            // What it would go back to: the preset it was built from if that
            // is still a preset, otherwise whatever the pad detects as now.
            preset: gamepadPreset(mine.preset) ?? preset,
            identity,
        };
    }
    if (preset) {
        return { profile: profileFromPreset(preset, identity, database), origin: 'preset', preset, identity };
    }
    return {
        profile: {
            device: identity.key,
            label: database?.[identity.key]?.name ?? identity.name,
            family: detectGamepadFamily(identity, database),
            buttons: {},
            deadZone: DEFAULT_GAMEPAD_DEAD_ZONE,
        },
        origin: 'unmapped',
        identity,
    };
}

/**
 * Make a stored profile safe to read.
 *
 * Settings come from `localStorage` and from a file the person can edit, so
 * every field is treated as a suggestion: a missing dead zone, a button holding
 * something that is not a source, a preset id that names no preset. Anything
 * unusable is dropped rather than allowed to reach the input loop, where a
 * malformed index would silently stop a button working.
 */
export function normalizeProfile(
    profile: GamepadProfile,
    identity?: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    const buttons = normalizeButtons(profile.buttons);
    const turbo = normalizeButtons(profile.turbo);

    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (!(GAMEPAD_PAD_ACTIONS as readonly string[]).includes(action)) {
            continue;
        }
        const normalized = normalizeSources(sources);
        if (normalized.length > 0) {
            actions[action as GamepadPadAction] = normalized;
        }
    }

    const deadZone = typeof profile.deadZone === 'number' && Number.isFinite(profile.deadZone)
        ? Math.min(GAMEPAD_DEAD_ZONE_RANGE.max, Math.max(GAMEPAD_DEAD_ZONE_RANGE.min, profile.deadZone))
        : DEFAULT_GAMEPAD_DEAD_ZONE;

    const deviceKey = identity?.key ?? profile.device;
    return {
        device: deviceKey,
        label: profile.label ?? database?.[deviceKey]?.name ?? identity?.name,
        preset: gamepadPreset(profile.preset)?.id,
        family: profile.family ?? (identity ? detectGamepadFamily(identity, database) : 'generic'),
        buttons,
        ...nonEmpty('turbo', turbo),
        ...(Object.keys(actions).length > 0 ? { actions } : {}),
        deadZone,
    };
}

function normalizeSources(sources: unknown): GamepadSource[] {
    if (!Array.isArray(sources)) {
        return [];
    }
    const seen = new Set<string>();
    const result: GamepadSource[] = [];
    for (const source of sources) {
        const valid = normalizeSource(source);
        if (!valid) {
            continue;
        }
        const id = gamepadSourceId(valid);
        if (!seen.has(id)) {
            seen.add(id);
            result.push(valid);
        }
    }
    return result;
}

function normalizeSource(source: unknown): GamepadSource | undefined {
    if (typeof source !== 'object' || source === null) {
        return undefined;
    }
    const candidate = source as Partial<GamepadSource> & { direction?: number };
    if (!Number.isInteger(candidate.index) || (candidate.index as number) < 0) {
        return undefined;
    }
    if (candidate.kind === 'button') {
        return { kind: 'button', index: candidate.index as number };
    }
    if (candidate.kind === 'axis') {
        return {
            kind: 'axis',
            index: candidate.index as number,
            direction: ((candidate.direction as number | undefined) ?? 0) < 0 ? -1 : 1,
        };
    }
    if (candidate.kind === 'hat') {
        const direction = HAT_DIRECTIONS.find(known => known === candidate.direction);
        return direction ? { kind: 'hat', index: candidate.index as number, direction } : undefined;
    }
    return undefined;
}

/** The buttons and axes of one pad, as much as reading it needs. */
export interface GamepadReading {
    buttons: readonly { pressed: boolean, value: number }[];
    axes: readonly number[];
}

/**
 * How far past ±1 an axis has to read to be a hat at rest rather than a stick.
 * A stick never leaves -1…1; a hat rests beyond it — 23/7 on the 8BitDo 64.
 */
const HAT_REST_MARGIN = 0.05;

/** Whether an axis value is out of any stick's range — a hat with nothing pressed. */
function isHatAtRest(value: number): boolean {
    return Math.abs(value) > 1 + HAT_REST_MARGIN;
}

/**
 * How near one of the eight positions a hat axis has to read to be held there.
 * They are 2/7 apart; this is well under half of that.
 */
const HAT_POSITION_TOLERANCE = 0.06;

/**
 * Which directions a hat axis is held in: one, or two on a diagonal.
 *
 * The eight positions run clockwise from up at -1 to up-left at 1, 2/7 apart,
 * so the nearest one is found by rounding rather than by comparing against
 * fixed values a browser might store slightly differently — but only a value
 * actually near one counts. Chrome reports every axis of a pad as 0 until the
 * pad is first used, and 0 is exactly halfway between down-left and down:
 * rounded, an untouched 8BitDo 64 held its d-pad down until somebody pressed
 * something.
 */
function hatDirections(value: number): GamepadHatDirection[] {
    if (isHatAtRest(value) || Number.isNaN(value)) {
        return [];
    }
    const steps = (value + 1) * 3.5;
    if (Math.abs(steps - Math.round(steps)) / 3.5 > HAT_POSITION_TOLERANCE) {
        return [];
    }
    const position = Math.round(steps) & 7;
    // Each cardinal owns its own position and the diagonal on either side.
    return HAT_DIRECTIONS.filter((_, cardinal) => {
        const offset = (position - cardinal * 2 + 8) & 7;
        return offset === 0 || offset === 1 || offset === 7;
    });
}

/** Whether one source is being held on a given reading. */
export function isSourcePressed(
    reading: GamepadReading,
    source: GamepadSource,
    deadZone: number,
): boolean {
    if (source.kind === 'button') {
        const held = reading.buttons[source.index];
        return held !== undefined && (held.pressed || held.value > BUTTON_THRESHOLD);
    }
    const value = reading.axes[source.index];
    if (value === undefined) {
        return false;
    }
    if (source.kind === 'hat') {
        return hatDirections(value).includes(source.direction);
    }
    // Out of range is a hat at rest that somebody bound as a stick, and would
    // otherwise hold its button down for as long as nothing is pressed.
    if (isHatAtRest(value)) {
        return false;
    }
    return source.direction < 0 ? value <= -deadZone : value >= deadZone;
}

/**
 * Every source currently held, as ids — what the settings page reads to notice
 * a button being pressed, and to light the picture up while one is held.
 *
 * Axes are reported through the profile's own dead zone so that what the
 * settings show is what the game will feel.
 *
 * `hats` is which axes are hat switches. It is the caller's to keep across
 * readings, and this grows it: a hat can only be told from a stick while it
 * rests, out of a stick's range, and the reading that matters is the later one
 * where a direction is pressed and the value looks like any other deflection.
 * A pad's d-pad is at rest long before anyone presses it, so by the time it is
 * pressed its axis is already known.
 */
export function pressedGamepadSources(
    reading: GamepadReading,
    deadZone: number,
    hats: Set<number> = new Set(),
): Set<string> {
    const pressed = new Set<string>();
    reading.buttons.forEach((held, index) => {
        if (held && (held.pressed || held.value > BUTTON_THRESHOLD)) {
            pressed.add(gamepadSourceId({ kind: 'button', index }));
        }
    });
    reading.axes.forEach((value, index) => {
        if (isHatAtRest(value)) {
            hats.add(index);
            return;
        }
        if (hats.has(index)) {
            for (const direction of hatDirections(value)) {
                pressed.add(gamepadSourceId({ kind: 'hat', index, direction }));
            }
            return;
        }
        if (value <= -deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: -1 }));
        } else if (value >= deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: 1 }));
        }
    });
    return pressed;
}

/** What one pad is contributing this frame. */
export interface GamepadContribution {
    /** The Virtual Boy key mask. */
    keys: number;
    /** Emulator actions whose source is held — a set, so edges can be found. */
    actions: Set<EmulatorAction>;
    /** The host's own actions whose source is held, kept apart from the emulator's. */
    uiActions: Set<GamepadUiAction>;
    /** The Virtual Boy buttons held on turbo, as a key mask. */
    turboKeys: number;
    /** The macro slots (1-based) whose source is held. */
    macroSlots: Set<number>;
}

/** Fold one pad's reading through its profile. */
export function readGamepadContribution(
    reading: GamepadReading,
    profile: GamepadProfile,
): GamepadContribution {
    const held = (sources: GamepadSource[] | undefined): boolean =>
        sources?.some(source => isSourcePressed(reading, source, profile.deadZone)) ?? false;
    let keys = 0;
    let turboKeys = 0;
    for (const key of GAMEPAD_BUTTONS) {
        if (held(profile.buttons[key])) {
            keys |= vbKeyForButton(key);
        }
        if (held(profile.turbo?.[key])) {
            turboKeys |= vbKeyForButton(key);
        }
    }

    const actions = new Set<EmulatorAction>();
    const uiActions = new Set<GamepadUiAction>();
    const macroSlots = new Set<number>();
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (held(sources)) {
            const slot = gamepadMacroSlot(action);
            if (slot !== undefined) {
                macroSlots.add(slot);
            } else if (isUiAction(action)) {
                uiActions.add(action);
            } else {
                actions.add(action as EmulatorAction);
            }
        }
    }

    return { keys, actions, uiActions, turboKeys, macroSlots };
}

/**
 * A profile with one source taken off everything it drives — the plain
 * buttons, the turbo ones and the actions alike.
 *
 * What every assignment starts from: one physical button driving two things
 * is never what somebody wanted and is very hard to notice afterwards.
 */
function withSourceFreed(profile: GamepadProfile, source: GamepadSource): {
    buttons: GamepadButtonMap,
    turbo: GamepadButtonMap,
    actions: Partial<Record<GamepadPadAction, GamepadSource[]>>,
} {
    const strip = (map: GamepadButtonMap | undefined): GamepadButtonMap => {
        const result: GamepadButtonMap = {};
        for (const key of GAMEPAD_BUTTONS) {
            const remaining = withoutSource(map?.[key], source);
            if (remaining.length > 0) {
                result[key] = remaining;
            }
        }
        return result;
    };
    const actions: Partial<Record<GamepadPadAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        const remaining = withoutSource(sources, source);
        if (remaining.length > 0) {
            actions[action as GamepadPadAction] = remaining;
        }
    }
    return { buttons: strip(profile.buttons), turbo: strip(profile.turbo), actions };
}

/** A profile with these three maps, the turbo one left out when empty. */
function withMaps(
    profile: GamepadProfile,
    maps: ReturnType<typeof withSourceFreed>,
): GamepadProfile {
    const { turbo: unused, ...rest } = profile;
    // Which preset it came from is kept even though it has now been edited by
    // hand: that is where "reset to preset" goes back to.
    return { ...rest, buttons: maps.buttons, ...nonEmpty('turbo', maps.turbo), actions: maps.actions };
}

/**
 * Put a source on a button, replacing whatever was there — or, with `add`,
 * beside it.
 *
 * Replacing by default, because this is what a person pressing a button in the
 * settings usually means: the one they just pressed, and not also the one that
 * happened to be there. Adding is the deliberate second step, for a d-pad and a
 * stick on the same cross. Either way the same source is taken off everything
 * else first; see {@link withSourceFreed}.
 */
export function assignGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.buttons[target] = add ? [...(maps.buttons[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

/** The same, for a button held on turbo. */
export function assignGamepadTurbo(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.turbo[target] = add ? [...(maps.turbo[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

/** The same, for an emulator action or a macro slot. */
export function assignGamepadAction(
    profile: GamepadProfile,
    target: GamepadPadAction,
    source: GamepadSource,
    add = false,
): GamepadProfile {
    const maps = withSourceFreed(profile, source);
    maps.actions[target] = add ? [...(maps.actions[target] ?? []), source] : [source];
    return withMaps(profile, maps);
}

function withoutSource(sources: GamepadSource[] | undefined, source: GamepadSource): GamepadSource[] {
    return (sources ?? []).filter(existing => !sameGamepadSource(existing, source));
}

/**
 * Take one source off whatever it drives — the way to drop one of several on a
 * control. Wherever it is, since a source only ever drives one control.
 */
export function removeGamepadSource(profile: GamepadProfile, source: GamepadSource): GamepadProfile {
    return withMaps(profile, withSourceFreed(profile, source));
}

/** Take everything off one button. */
export function clearGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
): GamepadProfile {
    const buttons = { ...profile.buttons };
    delete buttons[target];
    return { ...profile, buttons };
}

/** Take everything off one turbo button. */
export function clearGamepadTurbo(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
): GamepadProfile {
    const { turbo, ...rest } = profile;
    const remaining = { ...(turbo ?? {}) };
    delete remaining[target];
    return { ...rest, ...nonEmpty('turbo', remaining) };
}

/** Take everything off one action. */
export function clearGamepadAction(
    profile: GamepadProfile,
    target: GamepadPadAction,
): GamepadProfile {
    const actions = { ...(profile.actions ?? {}) };
    delete actions[target];
    return { ...profile, actions };
}

/**
 * Store a profile, replacing any earlier one for the same device.
 *
 * The list is the whole setting, so this is what every edit goes through: it
 * keeps exactly one entry per device and leaves the others alone.
 */
export function storeGamepadProfile(
    stored: GamepadProfile[],
    profile: GamepadProfile,
): GamepadProfile[] {
    const others = stored.filter(existing => existing.device !== profile.device);
    return [...others, profile];
}

/** Whether a profile binds every control, and sets the dead zone, exactly as the preset does. */
export function gamepadProfileMatchesPreset(profile: GamepadProfile, preset: GamepadPreset): boolean {
    const ids = (sources: GamepadSource[] | undefined): string =>
        (sources ?? []).map(gamepadSourceId).sort().join();
    return profile.deadZone === (preset.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE)
        && GAMEPAD_BUTTONS.every(key => ids(profile.buttons[key]) === ids(preset.buttons[key]))
        && GAMEPAD_BUTTONS.every(key => ids(profile.turbo?.[key]) === ids(preset.turbo?.[key]))
        && GAMEPAD_PAD_ACTIONS.every(action => ids(profile.actions?.[action]) === ids(preset.actions?.[action]));
}

/** Forget a device's profile, so it goes back to whatever is detected. */
export function forgetGamepadProfile(
    stored: GamepadProfile[],
    device: string,
): GamepadProfile[] {
    return stored.filter(existing => existing.device !== device);
}
