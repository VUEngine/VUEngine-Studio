/**
 * What a physical controller's buttons do, per device.
 *
 * The Gamepad API hands a page raw indices — `buttons[3]`, `axes[1]` — and says
 * nothing about what the person holding the pad would call them. A *profile* is
 * the table that closes that gap for one device: which index drives which
 * Virtual Boy button, which drives which emulator action, and how far a stick
 * has to move before it counts as a press.
 *
 * The reason this is a table rather than the fixed mapping it replaces is that
 * the raw indices are not portable. Chrome and Firefox enumerate the same pad
 * differently — Firefox reports an extra axis, so every axis index after it
 * shifts by one — and a pad the browser does not recognize is reported in
 * whatever order its HID descriptor happens to list.
 *
 * What *is* portable is `Gamepad.mapping === 'standard'`: both browsers carry
 * their own remapping tables (Chromium's `gamepad_standard_mappings.cc`,
 * Firefox since bug 1542893) and normalize every pad they recognize to the W3C
 * standard layout. That covers the large majority of controllers, and it is why
 * the built-in presets here are *semantic* rather than per-device: they all sit
 * on the standard layout and differ only in which face button is which and what
 * it is called. A pad the browser does not recognize gets no guess at all — it
 * gets the guided walk-through in the Game Pads settings, whose result is
 * verified rather than inferred, and is then remembered for that device.
 *
 * Deliberately free of DOM: everything here takes plain data, so the whole
 * resolution path can be exercised from `tests/gamepad-profile-probe.mjs`.
 */

import type { EmulatorGamePadButton } from '../browser/emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from '../browser/emulator-types';
import { VbKey } from './vb-constants';

/**
 * Which pad code each button presses.
 *
 * Spelled out rather than read from `EMULATOR_GAMEPAD_INPUTS`, which carries
 * `Command` objects and would pull the whole command table — and its
 * localization — into a module that only wants to know which bit a button
 * sets. Typed against the button union, so a button added to the emulator will
 * not compile here until it is given a code.
 */
const GAMEPAD_BUTTON_KEY_CODES: Record<EmulatorGamePadButton, EmulatorGamePadKeyCode> = {
    a: EmulatorGamePadKeyCode.A,
    b: EmulatorGamePadKeyCode.B,
    start: EmulatorGamePadKeyCode.Start,
    select: EmulatorGamePadKeyCode.Select,
    lUp: EmulatorGamePadKeyCode.LUp,
    lRight: EmulatorGamePadKeyCode.LRight,
    lDown: EmulatorGamePadKeyCode.LDown,
    lLeft: EmulatorGamePadKeyCode.LLeft,
    rUp: EmulatorGamePadKeyCode.RUp,
    rRight: EmulatorGamePadKeyCode.RRight,
    rDown: EmulatorGamePadKeyCode.RDown,
    rLeft: EmulatorGamePadKeyCode.RLeft,
    lTrigger: EmulatorGamePadKeyCode.LT,
    rTrigger: EmulatorGamePadKeyCode.RT,
};

/**
 * Every button, for iterating over. The same set as
 * `EMULATOR_GAMEPAD_BUTTONS`, in whatever order the table above lists them —
 * nothing here depends on the order, only on the set being complete, which the
 * `Record` type guarantees.
 */
const GAMEPAD_BUTTONS = Object.keys(GAMEPAD_BUTTON_KEY_CODES) as EmulatorGamePadButton[];

/** The mask bit one button contributes. */
export function vbKeyForButton(button: EmulatorGamePadButton): VbKey {
    return GAMEPAD_KEY_TO_VB_KEY[GAMEPAD_BUTTON_KEY_CODES[button]];
}

/**
 * The game pad codes the mappings speak, as the mask bits the core wants.
 *
 * Lives here rather than beside the keyboard handling because both the keyboard
 * and a physical pad have to end up as the same mask, and this is the module
 * both can reach without one depending on the other. Re-exported from
 * `emulator-input.ts`, which is where it used to live.
 */
export const GAMEPAD_KEY_TO_VB_KEY: Record<EmulatorGamePadKeyCode, VbKey> = {
    [EmulatorGamePadKeyCode.A]: VbKey.A,
    [EmulatorGamePadKeyCode.B]: VbKey.B,
    [EmulatorGamePadKeyCode.Start]: VbKey.STA,
    [EmulatorGamePadKeyCode.Select]: VbKey.SEL,
    [EmulatorGamePadKeyCode.LUp]: VbKey.LU,
    [EmulatorGamePadKeyCode.LRight]: VbKey.LR,
    [EmulatorGamePadKeyCode.LDown]: VbKey.LD,
    [EmulatorGamePadKeyCode.LLeft]: VbKey.LL,
    [EmulatorGamePadKeyCode.RUp]: VbKey.RU,
    [EmulatorGamePadKeyCode.RRight]: VbKey.RR,
    [EmulatorGamePadKeyCode.RDown]: VbKey.RD,
    [EmulatorGamePadKeyCode.RLeft]: VbKey.RL,
    [EmulatorGamePadKeyCode.LT]: VbKey.LT,
    [EmulatorGamePadKeyCode.RT]: VbKey.RT,
};

/**
 * One physical control: a button, or one end of an axis.
 *
 * An axis carries a direction because a stick is being used as a d-pad here,
 * and the two halves of one axis are two different buttons as far as the
 * Virtual Boy is concerned. `direction` is the sign of the deflection that
 * counts as pressed.
 */
export type GamepadSource =
    | { kind: 'button', index: number }
    | { kind: 'axis', index: number, direction: -1 | 1 };

/** A source as a string, for comparing and for using as a key. */
export function gamepadSourceId(source: GamepadSource): string {
    return source.kind === 'button'
        ? `b${source.index}`
        : `a${source.index}${source.direction < 0 ? '-' : '+'}`;
}

/** Parse back what {@link gamepadSourceId} wrote; undefined if it is not one. */
export function parseGamepadSource(id: string): GamepadSource | undefined {
    const asButton = /^b(\d+)$/.exec(id);
    if (asButton) {
        return { kind: 'button', index: Number(asButton[1]) };
    }
    const asAxis = /^a(\d+)([-+])$/.exec(id);
    if (asAxis) {
        return { kind: 'axis', index: Number(asAxis[1]), direction: asAxis[2] === '-' ? -1 : 1 };
    }
    return undefined;
}

export function sameGamepadSource(a: GamepadSource, b: GamepadSource): boolean {
    return gamepadSourceId(a) === gamepadSourceId(b);
}

/**
 * Whose button glyphs a pad wears.
 *
 * Not cosmetic: the families disagree about which face button is which. A
 * Nintendo pad's A sits where an Xbox pad's B does, and a PlayStation pad calls
 * the same two ○ and ✕. Since a Virtual Boy's A is the *rightmost* face button,
 * "VB A" lands on a differently-named button depending on the family, and a
 * settings page that showed the wrong name would be worse than one that showed
 * a bare index.
 */
export type GamepadFamily = 'xbox' | 'playstation' | 'nintendo' | 'generic';

/** One device's mapping, as it is stored and as the input loop reads it. */
export interface GamepadProfile {
    /**
     * What this profile is filed under: `vendor:product` in lower-case hex
     * ("054c:05c4") when the browser's id carries them, and the whole id
     * otherwise. See {@link gamepadDeviceKey}.
     */
    device: string;
    /** The name to show. The browser's id cleaned up, or the database's. */
    label?: string;
    /**
     * Which built-in preset this started as, so "reset to preset" knows where
     * back is. Absent for a profile built entirely by hand.
     */
    preset?: string;
    family: GamepadFamily;
    /**
     * More than one source per button on purpose: the standard presets put both
     * the d-pad and the left stick on the Virtual Boy's left cross, which is
     * what makes a modern pad feel right on a machine that has two of them.
     */
    buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>>;
    /** Emulator actions — pause, save state, rewind — on the pad. Usually empty. */
    actions?: Partial<Record<EmulatorAction, GamepadSource[]>>;
    /**
     * How far a stick must move before it reads as pressed, 0–1.
     *
     * Generous by default, because the control it stands in for is digital and
     * a partial press has no meaning to the machine.
     */
    deadZone: number;
}

/** What a stick deflection has to reach before it counts, when nothing says otherwise. */
export const DEFAULT_GAMEPAD_DEAD_ZONE = 0.5;

/** The narrowest and widest dead zone the settings will offer. */
export const GAMEPAD_DEAD_ZONE_RANGE = { min: 0.1, max: 0.9 };

/** Analog buttons still need a digital answer. */
const BUTTON_THRESHOLD = 0.5;

const padButton = (index: number): GamepadSource => ({ kind: 'button', index });
const padAxis = (index: number, direction: -1 | 1): GamepadSource =>
    ({ kind: 'axis', index, direction });

/**
 * The W3C standard layout, as the Virtual Boy wants it.
 *
 * Both the d-pad (12–15) and the left stick (axes 0/1) drive the left cross,
 * and the right stick (axes 2/3) drives the right one — the Virtual Boy's
 * second d-pad has no equivalent on a modern pad, and the right stick is the
 * closest thing to one. A and B follow the machine's own arrangement, where A
 * is the rightmost of the two face buttons; on the standard layout that is
 * button 1, with button 0 below it as B.
 *
 * Shoulders and triggers both reach LT/RT, so it does not matter which pair a
 * given pad puts where.
 */
const STANDARD_BUTTONS: Record<EmulatorGamePadButton, GamepadSource[]> = {
    a: [padButton(1)],
    b: [padButton(0)],
    select: [padButton(8)],
    start: [padButton(9)],
    lTrigger: [padButton(4), padButton(6)],
    rTrigger: [padButton(5), padButton(7)],
    lUp: [padButton(12), padAxis(1, -1)],
    lDown: [padButton(13), padAxis(1, 1)],
    lLeft: [padButton(14), padAxis(0, -1)],
    lRight: [padButton(15), padAxis(0, 1)],
    rUp: [padAxis(3, -1)],
    rDown: [padAxis(3, 1)],
    rLeft: [padAxis(2, -1)],
    rRight: [padAxis(2, 1)],
};

/**
 * A Virtual Boy controller on a VB USB Adapter.
 *
 * No browser knows the adapter, so it arrives un-normalized, in its own HID
 * order: both d-pads as plain buttons — 0–3 on the left, 10–13 on the right —
 * and no axes at all. The table was read off the device itself rather than
 * inferred, which is what makes it safe to apply on detection where no other
 * un-normalized pad gets a guess.
 */
const VB_USB_ADAPTER_BUTTONS: Record<EmulatorGamePadButton, GamepadSource[]> = {
    lUp: [padButton(0)],
    lDown: [padButton(1)],
    lLeft: [padButton(2)],
    lRight: [padButton(3)],
    a: [padButton(4)],
    b: [padButton(5)],
    start: [padButton(6)],
    select: [padButton(7)],
    rTrigger: [padButton(8)],
    lTrigger: [padButton(9)],
    rUp: [padButton(10)],
    rRight: [padButton(11)],
    rDown: [padButton(12)],
    rLeft: [padButton(13)],
};

/** A preset offered in the settings, and applied on detection. */
export interface GamepadPreset {
    id: string;
    /** English; the settings localize it through {@link gamepadPresetLabel}. */
    name: string;
    family: GamepadFamily;
    /** Only offered by hand — never the automatic answer for a detected pad. */
    manualOnly?: boolean;
    /**
     * Set only on a preset written for one particular device rather than for
     * the standard layout: the name that device reports itself by, as
     * {@link gamepadName} reads it out of the browser's id. Such a preset is
     * offered, and detected, only for a pad the browser has *not* normalized —
     * its table is that device's raw HID order, which stops being right the
     * moment a browser learns the pad and remaps it to the standard layout.
     */
    deviceName?: RegExp;
    buttons: Record<EmulatorGamePadButton, GamepadSource[]>;
}

/**
 * What a preset is worth applying to.
 *
 * All the standard ones share one button table and differ only in family, since
 * the browser has already done the physical-to-semantic translation by the time
 * `mapping === 'standard'` holds. The family is what decides the glyphs, and
 * the glyphs are the whole visible difference.
 *
 * `standard-nofaceswap` is the exception that earns its place: a handful of
 * pads — mostly Nintendo layouts driven through a browser that maps them
 * positionally rather than by label — end up with A and B the other way round
 * from what is printed on the shell. It is offered by hand rather than
 * detected, because there is no way to tell from the id which it will be.
 *
 * The ones with a `deviceName` are the other kind: one device's raw order,
 * recorded off the device, for a pad no browser normalizes.
 */
export const GAMEPAD_PRESETS: GamepadPreset[] = [
    {
        id: 'standard-xbox',
        name: 'Xbox',
        family: 'xbox',
        buttons: STANDARD_BUTTONS
    },
    {
        id: 'standard-playstation',
        name: 'PlayStation',
        family: 'playstation',
        buttons: STANDARD_BUTTONS,
    },
    {
        id: 'standard-nintendo',
        name: 'Nintendo',
        family: 'nintendo',
        buttons: STANDARD_BUTTONS,
    },
    { id: 'standard-generic', name: 'Standard', family: 'generic', buttons: STANDARD_BUTTONS },
    {
        id: 'standard-nofaceswap',
        name: 'Standard (A/B swapped)',
        family: 'generic',
        manualOnly: true,
        buttons: { ...STANDARD_BUTTONS, a: [padButton(0)], b: [padButton(1)] },
    },
    {
        id: 'vb-usb-adapter',
        name: 'VB USB Adapter',
        family: 'generic',
        deviceName: /^VB USB Adapter$/i,
        buttons: VB_USB_ADAPTER_BUTTONS,
    },
];

export function gamepadPreset(id: string | undefined): GamepadPreset | undefined {
    return id === undefined ? undefined : GAMEPAD_PRESETS.find(preset => preset.id === id);
}

/** What the browser's id says about a device. */
export interface GamepadIdentity {
    /** Four lower-case hex digits, when the id carries them. */
    vendor?: string;
    product?: string;
    /** The readable part, with the identifiers stripped off both ends. */
    name: string;
    /** What a profile for this device is filed under. */
    key: string;
}

/**
 * Take a device apart into the name a person would read and the ids a lookup
 * needs.
 *
 * The two browsers write the same information in different shapes. Chrome:
 * `Wireless Controller (STANDARD GAMEPAD Vendor: 054c Product: 05c4)`, with the
 * identifiers in a trailing parenthetical. Firefox: `054c-05c4-Wireless
 * Controller`, with them in front. Both are handled, and an id in neither shape
 * comes back as a name with no ids — which still works, since the whole id is
 * then the key.
 */
export function gamepadIdentity(id: string): GamepadIdentity {
    let vendor: string | undefined;
    let product: string | undefined;

    const chrome = /vendor:\s*([0-9a-f]{4}).*?product:\s*([0-9a-f]{4})/i.exec(id);
    if (chrome) {
        vendor = chrome[1].toLowerCase();
        product = chrome[2].toLowerCase();
    }
    const firefox = /^([0-9a-f]{4})-([0-9a-f]{4})-/i.exec(id);
    if (firefox) {
        vendor = firefox[1].toLowerCase();
        product = firefox[2].toLowerCase();
    }

    return {
        vendor,
        product,
        name: gamepadName(id),
        key: vendor && product ? `${vendor}:${product}` : id,
    };
}

/**
 * What to call a controller.
 *
 * The browser's id is built for matching rather than for reading, so this takes
 * the name back out and returns the id untouched if it is not in a shape it
 * recognizes: an odd name is better than an empty one.
 */
export function gamepadName(id: string): string {
    // The trailing parenthetical, whenever it is the API talking rather than
    // the manufacturer: the vendor and product ids, or the layout it maps to.
    let name = id.replace(
        /\s*\([^()]*\b(?:vendor:|product:|standard gamepad)[^()]*\)\s*$/i, '');
    // Firefox leads with the same pair again, as `054c-05c4-`.
    name = name.replace(/^[0-9a-f]{4}-[0-9a-f]{4}-/i, '').trim();
    return name || id;
}

/** What a profile for this device is filed under. */
export function gamepadDeviceKey(id: string): string {
    return gamepadIdentity(id).key;
}

/**
 * Vendors whose pads wear one family's glyphs throughout.
 *
 * Only the ones where the vendor id alone settles it. 8BitDo (2dc8) is
 * deliberately absent: it ships Nintendo-, Xbox- and PlayStation-labeled pads
 * under one vendor id, so its models are told apart by name below, or by the
 * harvested database.
 */
const FAMILY_BY_VENDOR: Record<string, GamepadFamily> = {
    '045e': 'xbox',        // Microsoft
    '054c': 'playstation', // Sony
    '057e': 'nintendo',    // Nintendo
    '0f0d': 'nintendo',    // Hori, near enough always a Nintendo layout
    '0e6f': 'xbox',        // PDP
    '24c6': 'xbox',        // PowerA / ThrustMaster Xbox line
};

/** Names that give the family away when the vendor id does not. */
const FAMILY_BY_NAME: { pattern: RegExp, family: GamepadFamily }[] = [
    { pattern: /xbox|xinput|x-?input/i, family: 'xbox' },
    { pattern: /dual\s*sense|dual\s*shock|playstation|\bps[345]\b/i, family: 'playstation' },
    { pattern: /switch|joy-?con|nintendo|\bsnes\b|\bnes\b|wii/i, family: 'nintendo' },
    // 8BitDo names its Nintendo-layout pads after the consoles they copy.
    { pattern: /\bsn30\b|\bsf30\b|\bn30\b/i, family: 'nintendo' },
];

/**
 * One entry of the harvested device database — see
 * `scripts/fetch-controller-db.mjs`. Keyed by `vendor:product`.
 */
export interface GamepadDatabaseEntry {
    name: string;
    family?: GamepadFamily;
}

export type GamepadDatabase = Record<string, GamepadDatabaseEntry>;

/**
 * Which family a pad belongs to.
 *
 * The database first, since it was harvested from people who had the device in
 * hand; then the vendor id; then the name. Everything falls back to `generic`,
 * which shows bare indices rather than a wrong glyph.
 */
export function detectGamepadFamily(
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadFamily {
    const entry = database?.[identity.key];
    if (entry?.family) {
        return entry.family;
    }
    if (identity.vendor && FAMILY_BY_VENDOR[identity.vendor]) {
        return FAMILY_BY_VENDOR[identity.vendor];
    }
    const name = entry?.name ?? identity.name;
    for (const { pattern, family } of FAMILY_BY_NAME) {
        if (pattern.test(name)) {
            return family;
        }
    }
    return 'generic';
}

/** Just enough of a `Gamepad` to resolve a profile for it. */
export interface GamepadDescriptor {
    id: string;
    /** `'standard'` when the browser has normalized the pad; `''` when not. */
    mapping: string;
}

/** What resolution decided, and why — the settings page shows the reason. */
export interface ResolvedGamepadProfile {
    profile: GamepadProfile;
    /**
     * Where the mapping came from. `stored` is the person's own, `preset` was
     * detected, and `unmapped` means the browser does not recognize the pad and
     * nothing has been recorded for it yet — the one case with no working
     * mapping, and the one the settings page asks somebody to fix.
     */
    origin: 'stored' | 'preset' | 'unmapped';
    /** The preset it would reset to, when there is one. */
    preset?: GamepadPreset;
    identity: GamepadIdentity;
}

/**
 * Which preset a pad should start on, or undefined if it cannot be guessed.
 *
 * Undefined is the honest answer for a pad the browser has not normalized: its
 * indices are in whatever order the device's HID descriptor lists them, and no
 * table written here could know that order. Guessing would produce a mapping
 * that looks configured and is wrong, which is worse than one that asks to be
 * set up. See the note at the top of this file. The one exception is a device
 * whose raw order somebody has recorded — see `deviceName` on the presets.
 */
export function detectGamepadPreset(
    pad: GamepadDescriptor,
    database?: GamepadDatabase,
): GamepadPreset | undefined {
    const identity = gamepadIdentity(pad.id);
    if (pad.mapping !== 'standard') {
        return GAMEPAD_PRESETS.find(preset => preset.deviceName?.test(identity.name));
    }
    const family = detectGamepadFamily(identity, database);
    return GAMEPAD_PRESETS.find(preset =>
        !preset.manualOnly && !preset.deviceName && preset.family === family)
        ?? gamepadPreset('standard-generic');
}

/**
 * The presets the settings offer for one pad.
 *
 * Every standard one; the A/B-swapped one only where the standard layout is
 * actually in force; and a device's own only for that device, and only while
 * the browser leaves it un-normalized — first, since it is the one that fits.
 */
export function offeredGamepadPresets(pad: GamepadDescriptor): GamepadPreset[] {
    const standard = pad.mapping === 'standard';
    const { name } = gamepadIdentity(pad.id);
    const own = GAMEPAD_PRESETS.filter(preset =>
        !standard && preset.deviceName?.test(name));
    const general = GAMEPAD_PRESETS.filter(preset =>
        !preset.deviceName && (!preset.manualOnly || standard));
    return [...own, ...general];
}

/** Build a fresh profile for a device from a preset. */
export function profileFromPreset(
    preset: GamepadPreset,
    identity: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    return {
        device: identity.key,
        label: database?.[identity.key]?.name ?? identity.name,
        preset: preset.id,
        family: preset.family,
        // Copied rather than shared: every preset above points at one
        // `STANDARD_BUTTONS`, and a profile is about to be edited.
        buttons: cloneButtons(preset.buttons),
        deadZone: DEFAULT_GAMEPAD_DEAD_ZONE,
    };
}

function cloneButtons(
    buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>>,
): Partial<Record<EmulatorGamePadButton, GamepadSource[]>> {
    const copy: Partial<Record<EmulatorGamePadButton, GamepadSource[]>> = {};
    for (const key of GAMEPAD_BUTTONS) {
        const sources = buttons[key];
        if (sources) {
            copy[key] = sources.map(source => ({ ...source }));
        }
    }
    return copy;
}

/**
 * The mapping in force for one pad: what was stored for it, what its preset
 * says, or nothing at all.
 *
 * `stored` is whatever the settings hold, in no particular order; the first
 * entry filed under this device wins.
 */
export function resolveGamepadProfile(
    pad: GamepadDescriptor,
    stored: GamepadProfile[] = [],
    database?: GamepadDatabase,
): ResolvedGamepadProfile {
    const identity = gamepadIdentity(pad.id);
    const preset = detectGamepadPreset(pad, database);
    const mine = stored.find(profile => profile.device === identity.key);
    if (mine) {
        return {
            profile: normalizeProfile(mine, identity, database),
            origin: 'stored',
            // What it would go back to: the preset it was built from if that
            // is still a preset, otherwise whatever the pad detects as now.
            preset: gamepadPreset(mine.preset) ?? preset,
            identity,
        };
    }
    if (preset) {
        return { profile: profileFromPreset(preset, identity, database), origin: 'preset', preset, identity };
    }
    return {
        profile: {
            device: identity.key,
            label: database?.[identity.key]?.name ?? identity.name,
            family: detectGamepadFamily(identity, database),
            buttons: {},
            deadZone: DEFAULT_GAMEPAD_DEAD_ZONE,
        },
        origin: 'unmapped',
        identity,
    };
}

/**
 * Make a stored profile safe to read.
 *
 * Settings come from `localStorage` and from a file the person can edit, so
 * every field is treated as a suggestion: a missing dead zone, a button holding
 * something that is not a source, a device key from an older build. Anything
 * unusable is dropped rather than allowed to reach the input loop, where a
 * malformed index would silently stop a button working.
 */
export function normalizeProfile(
    profile: GamepadProfile,
    identity?: GamepadIdentity,
    database?: GamepadDatabase,
): GamepadProfile {
    const buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>> = {};
    for (const key of GAMEPAD_BUTTONS) {
        const sources = normalizeSources(profile.buttons?.[key]);
        if (sources.length > 0) {
            buttons[key] = sources;
        }
    }

    const actions: Partial<Record<EmulatorAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        const normalized = normalizeSources(sources);
        if (normalized.length > 0) {
            actions[action as EmulatorAction] = normalized;
        }
    }

    const deadZone = typeof profile.deadZone === 'number' && Number.isFinite(profile.deadZone)
        ? Math.min(GAMEPAD_DEAD_ZONE_RANGE.max, Math.max(GAMEPAD_DEAD_ZONE_RANGE.min, profile.deadZone))
        : DEFAULT_GAMEPAD_DEAD_ZONE;

    const deviceKey = identity?.key ?? profile.device;
    return {
        device: deviceKey,
        label: profile.label ?? database?.[deviceKey]?.name ?? identity?.name,
        preset: gamepadPreset(profile.preset)?.id,
        family: profile.family ?? (identity ? detectGamepadFamily(identity, database) : 'generic'),
        buttons,
        ...(Object.keys(actions).length > 0 ? { actions } : {}),
        deadZone,
    };
}

function normalizeSources(sources: unknown): GamepadSource[] {
    if (!Array.isArray(sources)) {
        return [];
    }
    const seen = new Set<string>();
    const result: GamepadSource[] = [];
    for (const source of sources) {
        const valid = normalizeSource(source);
        if (!valid) {
            continue;
        }
        const id = gamepadSourceId(valid);
        if (!seen.has(id)) {
            seen.add(id);
            result.push(valid);
        }
    }
    return result;
}

function normalizeSource(source: unknown): GamepadSource | undefined {
    if (typeof source !== 'object' || source === null) {
        return undefined;
    }
    const candidate = source as Partial<GamepadSource> & { direction?: number };
    if (!Number.isInteger(candidate.index) || (candidate.index as number) < 0) {
        return undefined;
    }
    if (candidate.kind === 'button') {
        return { kind: 'button', index: candidate.index as number };
    }
    if (candidate.kind === 'axis') {
        return {
            kind: 'axis',
            index: candidate.index as number,
            direction: (candidate.direction ?? 0) < 0 ? -1 : 1,
        };
    }
    return undefined;
}

/** The buttons and axes of one pad, as much as reading it needs. */
export interface GamepadReading {
    buttons: readonly { pressed: boolean, value: number }[];
    axes: readonly number[];
}

/** Whether one source is being held on a given reading. */
export function isSourcePressed(
    reading: GamepadReading,
    source: GamepadSource,
    deadZone: number,
): boolean {
    if (source.kind === 'button') {
        const held = reading.buttons[source.index];
        return held !== undefined && (held.pressed || held.value > BUTTON_THRESHOLD);
    }
    const value = reading.axes[source.index];
    if (value === undefined) {
        return false;
    }
    return source.direction < 0 ? value <= -deadZone : value >= deadZone;
}

/**
 * Every source currently held, as ids — what the settings page reads to notice
 * a button being pressed, and to light the picture up while one is held.
 *
 * Axes are reported through the profile's own dead zone so that what the
 * settings show is what the game will feel.
 */
export function pressedGamepadSources(reading: GamepadReading, deadZone: number): Set<string> {
    const pressed = new Set<string>();
    reading.buttons.forEach((held, index) => {
        if (held && (held.pressed || held.value > BUTTON_THRESHOLD)) {
            pressed.add(gamepadSourceId({ kind: 'button', index }));
        }
    });
    reading.axes.forEach((value, index) => {
        if (value <= -deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: -1 }));
        } else if (value >= deadZone) {
            pressed.add(gamepadSourceId({ kind: 'axis', index, direction: 1 }));
        }
    });
    return pressed;
}

/** What one pad is contributing this frame. */
export interface GamepadContribution {
    /** The Virtual Boy key mask. */
    keys: number;
    /** Emulator actions whose source is held — a set, so edges can be found. */
    actions: Set<EmulatorAction>;
}

/** Fold one pad's reading through its profile. */
export function readGamepadContribution(
    reading: GamepadReading,
    profile: GamepadProfile,
): GamepadContribution {
    let keys = 0;
    for (const key of GAMEPAD_BUTTONS) {
        const sources = profile.buttons[key];
        if (sources?.some(source => isSourcePressed(reading, source, profile.deadZone))) {
            keys |= vbKeyForButton(key);
        }
    }

    const actions = new Set<EmulatorAction>();
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (sources?.some(source => isSourcePressed(reading, source, profile.deadZone))) {
            actions.add(action as EmulatorAction);
        }
    }

    return { keys, actions };
}

/**
 * Put a source on a button, replacing whatever was there.
 *
 * Replacing rather than adding, because this is what a person pressing a button
 * in the settings means: the one they just pressed, and not also the one that
 * happened to be there. The same source is taken off every *other* button
 * first, since one physical button driving two Virtual Boy buttons is never
 * what somebody wanted and is very hard to notice afterwards.
 */
export function assignGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
    source: GamepadSource,
): GamepadProfile {
    const buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>> = {};
    for (const key of GAMEPAD_BUTTONS) {
        if (key === target) {
            continue;
        }
        const remaining = (profile.buttons[key] ?? [])
            .filter(existing => !sameGamepadSource(existing, source));
        if (remaining.length > 0) {
            buttons[key] = remaining;
        }
    }
    buttons[target] = [source];

    const actions: Partial<Record<EmulatorAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        const remaining = (sources ?? []).filter(existing => !sameGamepadSource(existing, source));
        if (remaining.length > 0) {
            actions[action as EmulatorAction] = remaining;
        }
    }

    // Which preset it came from is kept even though it has now been edited by
    // hand: that is where "reset to preset" goes back to.
    return { ...profile, buttons, actions };
}

/** The same, for an emulator action. */
export function assignGamepadAction(
    profile: GamepadProfile,
    target: EmulatorAction,
    source: GamepadSource,
): GamepadProfile {
    const buttons: Partial<Record<EmulatorGamePadButton, GamepadSource[]>> = {};
    for (const key of GAMEPAD_BUTTONS) {
        const remaining = (profile.buttons[key] ?? [])
            .filter(existing => !sameGamepadSource(existing, source));
        if (remaining.length > 0) {
            buttons[key] = remaining;
        }
    }

    const actions: Partial<Record<EmulatorAction, GamepadSource[]>> = {};
    for (const [action, sources] of Object.entries(profile.actions ?? {})) {
        if (action === target) {
            continue;
        }
        const remaining = (sources ?? []).filter(existing => !sameGamepadSource(existing, source));
        if (remaining.length > 0) {
            actions[action as EmulatorAction] = remaining;
        }
    }
    actions[target] = [source];

    return { ...profile, buttons, actions };
}

/** Take everything off one button. */
export function clearGamepadButton(
    profile: GamepadProfile,
    target: EmulatorGamePadButton,
): GamepadProfile {
    const buttons = { ...profile.buttons };
    delete buttons[target];
    return { ...profile, buttons };
}

/** Take everything off one action. */
export function clearGamepadAction(
    profile: GamepadProfile,
    target: EmulatorAction,
): GamepadProfile {
    const actions = { ...(profile.actions ?? {}) };
    delete actions[target];
    return { ...profile, actions };
}

/**
 * Store a profile, replacing any earlier one for the same device.
 *
 * The list is the whole setting, so this is what every edit goes through: it
 * keeps exactly one entry per device and leaves the others alone.
 */
export function storeGamepadProfile(
    stored: GamepadProfile[],
    profile: GamepadProfile,
): GamepadProfile[] {
    const others = stored.filter(existing => existing.device !== profile.device);
    return [...others, profile];
}

/** Forget a device's profile, so it goes back to whatever is detected. */
export function forgetGamepadProfile(
    stored: GamepadProfile[],
    device: string,
): GamepadProfile[] {
    return stored.filter(existing => existing.device !== device);
}
