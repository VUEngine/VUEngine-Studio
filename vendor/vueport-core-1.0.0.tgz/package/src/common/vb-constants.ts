/**
 * Constants for the Shrooms-VB core.
 *
 * Mirrors the values in the vendored core's Constants.js, which is the
 * authority. Kept as a TypeScript module so that the worker, the audio worklet
 * and the frontend can share them without pulling in the vendored shim.
 */

/** Virtual Boy master clock, in Hz. */
export const VB_CLOCK_RATE = 20000000;

/** Sample rate the core produces audio at, in Hz. */
export const VB_SAMPLE_RATE = 41700;

/** Frames the display is driven at, in Hz. One audio buffer covers one frame. */
export const VB_FRAME_RATE = 50;

/**
 * Number of emulated clocks per audio buffer. 400000 clocks is 0.02 seconds at
 * 20 MHz, which is exactly VB_SAMPLES_PER_BUFFER samples.
 */
export const VB_CLOCKS_PER_BUFFER = VB_CLOCK_RATE / VB_FRAME_RATE;

/** Stereo frames per audio buffer. */
export const VB_SAMPLES_PER_BUFFER = VB_SAMPLE_RATE / VB_FRAME_RATE;

/**
 * Audio buffers cycled between the core worker and the audio worklet. Three
 * buffers is ~60ms of latency, matching the vendored shim.
 */
export const VB_AUDIO_BUFFER_COUNT = 3;

/**
 * How many `Emulate` calls in a row may spend none of the clock budget before
 * the core is taken to be stuck.
 *
 * Draining a budget means calling `Emulate` until nothing is left, and the
 * core can reach a state where it returns having spent nothing, for ever — a
 * program that has run off into memory it cannot execute does it. The loops
 * that drain the budget have no other stopping condition, so without a limit
 * the worker spins and the tab goes with it, silently.
 *
 * Measured rather than guessed: a healthy chunk drains in a single call and
 * never spends nothing at all, across every ROM `tests/stall-guard-probe.mjs`
 * puts through it. The headroom here is three orders of magnitude.
 */
export const VB_MAX_IDLE_EMULATE_CALLS = 1000;

/** Display dimensions, per eye. */
export const VB_SCREEN_WIDTH = 384;
export const VB_SCREEN_HEIGHT = 224;

/** Name the audio worklet processor is registered under. */
export const VB_AUDIO_PROCESSOR = 'ves-vb-audio';

/** Controller button bits, as accepted by vbSetKeys. */
export enum VbKey {
    PWR = 0x0001,
    SGN = 0x0002,
    A = 0x0004,
    B = 0x0008,
    RT = 0x0010,
    LT = 0x0020,
    RU = 0x0040,
    RR = 0x0080,
    LR = 0x0100,
    LL = 0x0200,
    LD = 0x0400,
    LU = 0x0800,
    STA = 0x1000,
    SEL = 0x2000,
    RL = 0x4000,
    RD = 0x8000,
}

/** Data types for vbRead/vbWrite and vbSetSamples. */
export enum VbDataType {
    S8 = 0,
    U8 = 1,
    S16 = 2,
    U16 = 3,
    S32 = 4,
    F32 = 5,
}

/** System register indices. */
export enum VbSystemRegister {
    EIPC = 0,
    EIPSW = 1,
    FEPC = 2,
    FEPSW = 3,
    ECR = 4,
    PSW = 5,
    PIR = 6,
    TKCW = 7,
    CHCW = 24,
    ADTRE = 25,
}

/**
 * Game Pak RAM, where a cartridge keeps its save data.
 *
 * The core drops every access to this region — writes as well as reads — until
 * a simulation has been given cartridge RAM with setCartRam.
 */
export const VB_CART_RAM_BASE = 0x06000000;

/**
 * Whether an address lands in Game Pak RAM.
 *
 * By region rather than by range: the Virtual Boy decodes memory on three bits
 * of the address, so the save region is not 8 KB at one address but the whole
 * of region 6, with the cartridge's actual RAM mirrored across it. A game
 * reaching its save through a mirror — which some do, the region being far
 * larger than any cartridge fills — is still touching its save.
 */
export function isCartRam(address: number): boolean {
    return ((address >>> 24) & 7) === 6;
}

/**
 * Main system RAM (WRAM), the Virtual Boy's 64 KB of work memory.
 *
 * The bus decodes on three bits the same way the save region does, so WRAM is
 * the whole of region 5 with the 64 KB mirrored across it. This is also the
 * Memory panel's own default base.
 */
export const VB_WRAM_BASE = 0x05000000;

/** Video RAM, region 0, of which the Virtual Boy has 128 KB. */
export const VB_VRAM_BASE = 0x00000000;
export const VB_VRAM_SIZE = 0x20000;

/** WRAM's own size, the 64 KB mirrored across region 5. */
export const VB_WRAM_SIZE = 0x10000;

/**
 * How wide one of the bus' eight regions is.
 *
 * The Virtual Boy decodes an address on three bits, so the space is eight
 * regions of 16 MB and everything above `0x08000000` is the whole map again.
 * What a region actually answers with is usually far smaller than 16 MB and
 * repeats across it — see {@link isCartRam}, which is why that test is written
 * on the region and not on a range.
 */
export const VB_REGION_BYTES = 0x1000000;

/**
 * The most bytes one `readMemory` may ask for.
 *
 * Reads go through vbRead a byte at a time, so windows are bounded. The
 * ceiling is a whole bank of WRAM, which is the largest contiguous region in
 * the address space anything here inspects, because two callers want a
 * structure whole rather than in pieces and a partial read would show up as
 * corrupt data rather than as an error: the graphics inspectors read a
 * character segment, a BGMap, the whole of OAM, or a whole frame buffer
 * (0x6000 bytes), and the Memory Pools panel reads VUEngine's pool struct,
 * which is sized per project and takes most of WRAM on a real game. Bounded
 * still: a byte at a time over 64 KiB costs nothing, but an unbounded request
 * would be a way to stall the worker.
 *
 * Shared rather than the worker's own, because a caller that reads memory in
 * windows — the Memory panel's search walks the whole cartridge — has to know
 * how wide a window may be, and a second copy of the number would be a second
 * copy to get wrong. The worker still refuses anything over it: this is what
 * the limit is, not a promise that callers respect it.
 */
export const VB_MAX_MEMORY_READ = 0x10000;

/**
 * Whether an address lands in WRAM, by region rather than by range — the same
 * decoding as {@link isCartRam}, and for the same reason.
 */
export function isWram(address: number): boolean {
    return ((address >>> 24) & 7) === 5;
}

/**
 * The client string RetroAchievements sees.
 *
 * RetroAchievements allowlists integrations by this string server-side and
 * refuses any it does not recognize with `unsupported_client` — softcore
 * included. Registering it with them is what turns the integration on; nothing
 * in the code changes at that point. Kept here so the worker, the desktop
 * shell's HTTP command and anything logging it all quote the same one.
 */
export const RETROACHIEVEMENTS_CLIENT = 'VUEPort/1.0.0';

/** RetroAchievements' console identifier for the Virtual Boy (`RC_CONSOLE_VIRTUAL_BOY`). */
export const RETROACHIEVEMENTS_CONSOLE_ID = 28;

/**
 * Where the engine writes terminal output.
 *
 * `Terminal::print` stores a string here one byte at a time and follows it with
 * a newline, so this is a byte-wide port rather than an address holding a
 * value. See `vuengine/core/source/Debugging/Terminal/Terminal.c`; it is
 * compiled out of shipping builds, so a released ROM writes nothing.
 */
export const VB_TERMINAL_PORT = 0x02000030;

/**
 * The link port's control register, CCR.
 *
 * A byte leaves the machine in two steps: the payload is stored to
 * VB_LINK_TRANSMIT_PORT, then this register is written with VB_LINK_START set,
 * which clocks it out. Watching the payload register alone would therefore
 * report bytes that were never sent — `Communications::reset` clears it
 * without transmitting, for one.
 */
export const VB_LINK_CONTROL_PORT = 0x02000000;

/** The link port's transmit data register, CDTR. */
export const VB_LINK_TRANSMIT_PORT = 0x02000008;

/**
 * The address an ESSound cartridge listens on.
 *
 * ESSound is an expansion that plays MP3 and WAV files from the cartridge
 * folder, driven entirely by halfword writes to this one address — the
 * hardware selects on `/ES`, so the whole `0x04......` range reaches it and a
 * single address is all the protocol needs. See `vueport-essound.ts` for
 * what the halfwords mean.
 */
export const VB_ES_SOUND_PORT = 0x04000000;

/**
 * The CCR bit that starts a transfer, `__COM_START`.
 *
 * See `Communications::startTransmissions` and
 * `Communications::startClockSignal` in
 * `applications/electron/vb/vuengine/platforms/VirtualBoy/source/Hardware/Communications.c`,
 * and `libgccvb/source/hw.h` for the register map itself.
 */
export const VB_LINK_START = 0x04;

/**
 * The VSU's waveform tables, MODDATA and the six channel register blocks
 * (`applications/electron/vb/libgccvb/source/audio.h`), up to but not
 * including SSTOP.
 *
 * Real hardware never lets these be read back, and this core matches that:
 * confirmed directly against it (see `tests/vsu-state-probe.mjs`) that
 * vbRead on any address in this range always comes back 0, whether the value
 * arrived through an actual CPU store instruction or the debug vbWrite
 * primitive.
 *
 * The VSU panel does not read this range, then. It reads the core's own
 * decoded copy of it out of the simulation struct and composes the map below
 * from that — see `worker/vb-vsu-layout.ts`, which also covers why the write
 * watching this used to rely on could never answer the question the panel is
 * opened to ask.
 */
export const VB_VSU_BASE = 0x01000000;
/**
 * How much of the map the worker reports, which runs far enough to include
 * SSTOP, one word past the last channel's registers.
 *
 * SSTOP holds nothing to report — it is a write-only switch, not a register —
 * but the range is quoted as "up to and including" everywhere else, and
 * stopping one word short of it would invite the question every time.
 */
export const VB_VSU_MAP_BYTES = 0x584;

/**
 * The register block's own geometry.
 *
 * The panel decodes the blocks themselves — see
 * `panels/emulator-vsu-memory.ts`, which is where the bit layouts and their
 * sourcing live. These are here because the *worker* composes the map it
 * decodes, and that file is browser-side.
 */
export const VB_VSU_REGISTERS = 0x01000400;
export const VB_VSU_CHANNEL_STRIDE = 0x40;
export const VB_VSU_CHANNELS = 6;
/** `SxINT` bit 7: the channel is switched on. */
export const VB_VSU_CHANNEL_ENABLE = 0x80;
/** Write-only, and one word past the last channel: any write with bit 0 set silences them all. */
export const VB_VSU_SSTOP = 0x01000580;

/**
 * The cartridge ROM as the CPU sees it: region 7, mirrored across it.
 *
 * Only readable to the game, but the core's debug write reaches it too — which
 * is how the color editor puts an edited palette into the palette table a
 * colorization's native code copies from. See `emulator-vb-color-store.ts`.
 */
export const VB_ROM_BASE = 0x07000000;

/** VB Color Color RAM: 256 palettes of four RGB555 colors, BG 0-127 then OBJ 128-255. */
export const VBC_CRAM_BASE = 0x03079000;
export const VBC_CRAM_PALETTES = 256;
export const VBC_CRAM_PALETTE_BYTES = 8;

/**
 * The VB Color unit's Color Framebuffer, and what its bytes mean.
 *
 * Four pages of 384x256 pixels at one byte per pixel, the byte being a *palette
 * id* rather than a color: the VCU looks the final pixel up as
 * `CRAM[byte * 4 + legacy shade]`, which is why a colorization can tint a game
 * it never re-renders.
 *
 * Worth stating plainly because it is the only place a palette id survives in
 * memory. Color RAM says what the colors *are*; this says which palette is
 * painting, and it is the only thing that does — the colorization's own store
 * into it is where `setDrawnPaletteCapture` reads the id off the bus.
 */
export const VBC_COLOR_FRAMEBUFFER_BASE = 0x03000000;
export const VBC_COLOR_FRAMEBUFFER_PAGE_BYTES = 384 * 256;
export const VBC_COLOR_FRAMEBUFFER_PAGES = 4;
export const VBC_COLOR_FRAMEBUFFER_BYTES =
    VBC_COLOR_FRAMEBUFFER_PAGE_BYTES * VBC_COLOR_FRAMEBUFFER_PAGES;

/**
 * Whether an address lands in the Color Framebuffer.
 *
 * By region and offset, the way {@link isCartRam} is and for the same reason:
 * the bus decodes three bits, so the VCU is the whole of region 3 with its
 * aperture mirrored across it. The framebuffer is the first
 * `VBC_COLOR_FRAMEBUFFER_BYTES` of that aperture; the attribute RAMs, Color RAM
 * and the register block sit above it and are deliberately outside this test.
 */
export function isVbcColorFramebuffer(address: number): boolean {
    return ((address >>> 24) & 7) === 3
        && (address & 0x00ffffff) < VBC_COLOR_FRAMEBUFFER_BYTES;
}

/**
 * The CPU's interrupt levels, in the order the hardware vectors them.
 *
 * Confirmed by the engine's own vector table (`vuengine/core/source/Runtime/
 * crt0.s`, section `.vbvectors`), which labels them KEY, TIM, CRO, COM and
 * VPU at sixteen-byte intervals. CRO is the expansion port's, which is what an
 * ESSound cartridge pulses to say it is there.
 */
export enum VbInterrupt {
    KEY = 0,
    TIM = 1,
    CRO = 2,
    COM = 3,
    VPU = 4,
}

/**
 * Where the CPU jumps for interrupt level n: this plus `n * 0x10`.
 *
 * The addresses the ROM links its table at (`0x07FFFE00`) are the same memory
 * seen through the cartridge mirror.
 */
export const VB_INTERRUPT_VECTOR_BASE = 0xfffffe00;

/** The exception code an interrupt of level n writes to ECR's low halfword. */
export function vbInterruptExceptionCode(level: VbInterrupt): number {
    return 0xfe00 | (level << 4);
}

/**
 * PSW bits, per the V810's program status word.
 *
 * The interrupt level mask occupies bits 16 to 19, which the engine's
 * `set_intlevel` in `libgccvb/source/asm.c` reads and writes the same way.
 */
export enum VbPsw {
    /** Interrupts are disabled. */
    ID = 0x1000,
    /** Address trap enable. */
    AE = 0x2000,
    /** An exception is being handled. */
    EP = 0x4000,
    /** A non-maskable interrupt is being handled. */
    NP = 0x8000,
}
export const VB_PSW_INTERRUPT_LEVEL_SHIFT = 16;
export const VB_PSW_INTERRUPT_LEVEL_MASK = 0x000f0000;

/** Core option keys for vbSetOption/vbGetOption. */
export enum VbOption {
    PSEUDO_HALT = 0,
}

/** Break condition bits returned by GetBreaks. */
export enum VbBreak {
    FRAME = 1,
    POINT = 2,
}

/**
 * Anaglyph configuration that packs the left eye's brightness into the red
 * channel and the right eye's into the green channel, both unscaled.
 *
 * The core's mixer assigns RGB channels to eyes independently, so this yields a
 * single RGBA framebuffer carrying both eyes at full 8-bit precision. Every
 * display mode is then derived in a shader from one texture, without per-eye
 * passes or decoding VIP framebuffers. The core is always configured this way;
 * color is applied entirely by the renderer.
 */
export const VB_EYE_PACKED_LEFT = 0xff0000;
export const VB_EYE_PACKED_RIGHT = 0x00ff00;

/**
 * Tints the built-in anaglyph pairs are made of.
 *
 * Green and magenta are the core's own constants (see Constants.js); the rest
 * are full-saturation equivalents, which is what a filter passes best. Nothing
 * here affects emulation.
 */
export const VB_COLORS = {
    RED: 0xff0000,
    BLUE: 0x0000ff,
    CYAN: 0x00ffff,
    GREEN: 0x00b400,
    MAGENTA: 0xc800ff,
    AMBER: 0xffff00,
};

/**
 * Where the display's four brightness levels land in the framebuffer's 0..1
 * range, with the brightness registers a VUEngine game configures by default
 * (BRTA 32, BRTB 64, BRTC 32 — see __BRIGHTNESS_DARK/MEDIUM/BRIGHT_RED).
 *
 * The core resolves a pixel's brightness before the renderer sees it, and does
 * so on a gamma-like curve rather than proportionally:
 * `scripts/brightness-probe.mjs` measures level 1 at 105, level 2 at 162 and
 * level 3 at 250 out of 255. The renderer interpolates the palette between
 * these stops, so a display at the standard brightness shows the four palette
 * colors exactly, while a game dimming the brightness registers — a fade —
 * slides smoothly down through them instead of banding.
 */
export const VB_LEVEL_STOPS = [0, 105 / 255, 162 / 255, 250 / 255];
export const VB_LEVELS = 4;

export type VbDuboisProfile = 'red-cyan' | 'green-magenta' | 'amber-blue';
export type VbDuboisProfileSelection = 'none' | VbDuboisProfile | 'custom';

/** Two 3x3 color transforms, stored column-major for WebGL. */
export interface VbAnaglyphMatrices {
    left: number[];
    right: number[];
}

export interface VbAnaglyphPalette {
    left: number;
    right: number;
    /** Explicit built-in calibration; absent for RGB channel filters and custom matrices. */
    duboisProfile?: VbDuboisProfile;
    /** Explicit user calibration. Takes precedence over a built-in profile when present. */
    duboisMatrices?: VbAnaglyphMatrices;
}

export type VbPalette = [number, number, number, number];
export const VB_PALETTE_GROUPS: Record<string, VbPalette>[] = [
    {
        'default': [0x000000, 0x78010d, 0xa80016, 0xff0024],
        'red': [0x000000, 0x550000, 0xAA0000, 0xFF0000],
        'white': [0x000000, 0x555555, 0xaaaaaa, 0xffffff],
        'gray': [0x1A1A1A, 0x5C5C5C, 0x9E9E9E, 0xE0E0E0],
        'green': [0x0E1F0F, 0x3E5F40, 0x6EA071, 0x9EE0A2],
        'cyan': [0x0E1D1E, 0x3B5D5F, 0x699DA0, 0x96DDE1],
        'blue': [0x141A2D, 0x3E4A6E, 0x6979AF, 0x93A9F0],
        'magenta': [0x2B1427, 0x6A4363, 0xA8739F, 0xE7A2DB],
        'coral': [0x2B1613, 0x6E423D, 0xB26E66, 0xF59A90],
        'yellow': [0x1D1A0D, 0x615A38, 0xA59964, 0xE9D98F],
    },
    {
        'gb': [0x0F380F, 0x306230, 0x9BBC0F, 0x8BAC0F],
        'gbp': [0x1F211A, 0x4C533C, 0x8B966C, 0xC4CFA1],
        'gbl': [0x005038, 0x00694A, 0x009A73, 0x00b284],
    },
    {
        'sgb-1a': [0x301850, 0xA82820, 0xD89048, 0xF8E8C8],
        'sgb-1b': [0x000000, 0xAD5111, 0xC8B06F, 0xD7D9BF],
        'sgb-1c': [0x383998, 0x973761, 0xE8984F, 0xF7C0FA],
        'sgb-1d': [0x501900, 0xFA0000, 0xC27F48, 0xF8F8A6],
        'sgb-1e': [0x5A3721, 0x69873F, 0x78BF77, 0xF8D8B3],
        'sgb-1f': [0x003E10, 0xA80000, 0xE1884F, 0xD9E8F8],
        'sgb-1g': [0xF7F858, 0x787700, 0x00A0E7, 0x000050],
        'sgb-1h': [0x2F1800, 0x7F4100, 0xF9B887, 0xF9E8E0],
        'sgb-2a': [0x00000E, 0x2B7303, 0xC58652, 0xE6C899],
        'sgb-2b': [0x450363, 0xF63000, 0xE6EB33, 0xFAFAEC],
        'sgb-2c': [0x282897, 0x7831E8, 0xE88989, 0xF7C0FA],
        'sgb-2d': [0x0A0046, 0xEF3200, 0x04F820, 0xF4FFB0],
        'sgb-2e': [0x0C0414, 0x221251, 0x90AAD6, 0xE5BE7D],
        'sgb-2f': [0x180000, 0xA00300, 0xF09660, 0xD2EEDD],
        'sgb-2g': [0x031900, 0xE6B38A, 0xDC5145, 0x5DBE39],
        'sgb-2h': [0x000000, 0x6E6E6E, 0xB7B7B7, 0xFCFCFC],
        'sgb-3a': [0x3D3871, 0xF55B28, 0x53C2C7, 0xFFCBA3],
        'sgb-3b': [0x02120E, 0x094C00, 0xD78942, 0xF0DBBE],
        'sgb-3c': [0x1B235F, 0x02B3FF, 0xF7FF85, 0xDCA7CE],
        'sgb-3d': [0x000308, 0x00CF00, 0xDBA970, 0xDEF9B0],
        'sgb-3e': [0x56437F, 0xA67D20, 0xD6AB65, 0xF0FAC5],
        'sgb-3f': [0x3F4139, 0xF2D20D, 0xF46DF0, 0x8275C4],
        'sgb-3g': [0x2E0600, 0xC62B2C, 0xF0F0EE, 0x61D352],
        'sgb-3h': [0x021900, 0x46892B, 0x7FCA3E, 0xE5FBB3],
        'sgb-4a': [0x00087D, 0xD101C9, 0x7BA9FA, 0xE7B366],
        'sgb-4b': [0x160A07, 0x377F33, 0xEAA665, 0xE9DBD4],
        'sgb-4c': [0x0B0007, 0x9BA2D7, 0xD1A1D0, 0xF0DCD2],
        'sgb-4d': [0x072250, 0x456874, 0x7CCDC8, 0xF4F1B2],
        'sgb-4e': [0x002334, 0x7F5694, 0xDBA971, 0xEED5A4],
        'sgb-4f': [0x430000, 0x7605AB, 0xCF7ED5, 0xBFC6C9],
        'sgb-4g': [0x048166, 0x241402, 0xA72548, 0xB8D90A],
        'sgb-4h': [0x3F5023, 0x808447, 0xBECA5F, 0xEBECBF],
    },
];

/** Every shipped palette, in the order the groups list them. */
export const VB_PALETTES: Record<string, VbPalette> = Object.assign({}, ...VB_PALETTE_GROUPS);

export const VB_DEFAULT_PALETTE_ID = Object.keys(VB_PALETTES)[0];

/** The palette everything falls back to, which is the first one shipped. */
export const VB_DEFAULT_PALETTE = VB_PALETTES[VB_DEFAULT_PALETTE_ID];

/**
 * Published Dubois least-squares calibrations.
 *
 * They operate on linear RGB and are column-major here so the arrays can be
 * uploaded to WebGL without a transpose. Keeping the coefficients in common
 * code also lets a custom calibration start as an editable copy of a preset.
 * Method and calibration limitations: https://www.site.uottawa.ca/~edubois/anaglyph/
 * Red/cyan coefficients: https://github.com/mrdoob/three.js/blob/dev/examples/jsm/effects/AnaglyphEffect.js
 * Green/magenta LCD profile: https://www.flickr.com/photos/e_dubois/5132528166/
 * Amber/blue LCD / ColorCode profile: https://www.flickr.com/photos/e_dubois/5230654930/
 */
export const VB_DUBOIS_MATRICES: Record<VbDuboisProfile, VbAnaglyphMatrices> = {
    'red-cyan': {
        left: [
            0.456100, -0.0400822, -0.0152161,
            0.500484, -0.0378246, -0.0205971,
            0.176381, -0.0157589, -0.00546856,
        ],
        right: [
            -0.0434706, 0.378476, -0.0721527,
            -0.0879388, 0.733640, -0.112961,
            -0.00155529, -0.0184503, 1.226400,
        ],
    },
    'green-magenta': {
        left: [
            -0.062, 0.284, -0.015,
            -0.158, 0.668, -0.027,
            -0.039, 0.143, 0.021,
        ],
        right: [
            0.529, -0.016, 0.009,
            0.705, -0.015, 0.075,
            0.024, -0.065, 0.937,
        ],
    },
    'amber-blue': {
        left: [
            1.062, -0.026, -0.038,
            -0.205, 0.908, -0.173,
            0.299, 0.068, 0.022,
        ],
        right: [
            -0.016, 0.006, 0.094,
            -0.123, 0.062, 0.185,
            -0.017, -0.017, 0.911,
        ],
    },
};

export const VB_ANAGLYPH_PALETTES: Record<string, VbAnaglyphPalette> = {
    'red-cyan': { left: VB_COLORS.RED, right: VB_COLORS.CYAN, duboisProfile: 'red-cyan' },
    'red-blue': { left: VB_COLORS.RED, right: VB_COLORS.BLUE },
    'red-green': { left: VB_COLORS.RED, right: VB_COLORS.GREEN },
    'green-magenta': { left: VB_COLORS.GREEN, right: VB_COLORS.MAGENTA, duboisProfile: 'green-magenta' },
    // The published profile is calibrated for amber/blue (ColorCode) glasses.
    'amber-blue': { left: VB_COLORS.AMBER, right: VB_COLORS.BLUE, duboisProfile: 'amber-blue' },
};

export const VB_DEFAULT_ANAGLYPH_PALETTE_ID = 'red-cyan';

export enum VbStereoLayout {
    OVERLAY,
    SIDE_BY_SIDE,
    CYBERSCOPE,
    HLI,
    VLI,
}

export enum VbEyes {
    LEFT = 0,
    RIGHT = 1,
    BOTH = 2,
}

export enum VbRenderingMode {
    LEFT = 'left',
    RIGHT = 'right',
    ANAGLYPH = 'anaglyph',
    SIDE_BY_SIDE = 'side-by-side',
    CYBERSCOPE = 'cyberscope',
    HLI = 'hli',
    VLI = 'vli',
}

interface VbRenderingGeometry {
    layout: VbStereoLayout;
    eyes: VbEyes;
    width: number;
    height: number;
}

const VB_RENDERING_GEOMETRIES: Record<VbRenderingMode, VbRenderingGeometry> = {
    [VbRenderingMode.LEFT]: {
        layout: VbStereoLayout.OVERLAY,
        eyes: VbEyes.LEFT,
        width: VB_SCREEN_WIDTH,
        height: VB_SCREEN_HEIGHT,
    },
    [VbRenderingMode.RIGHT]: {
        layout: VbStereoLayout.OVERLAY,
        eyes: VbEyes.RIGHT,
        width: VB_SCREEN_WIDTH,
        height: VB_SCREEN_HEIGHT,
    },
    [VbRenderingMode.ANAGLYPH]: {
        layout: VbStereoLayout.OVERLAY,
        eyes: VbEyes.BOTH,
        width: VB_SCREEN_WIDTH,
        height: VB_SCREEN_HEIGHT,
    },
    [VbRenderingMode.SIDE_BY_SIDE]: {
        layout: VbStereoLayout.SIDE_BY_SIDE,
        eyes: VbEyes.BOTH,
        width: VB_SCREEN_WIDTH * 2,
        height: VB_SCREEN_HEIGHT,
    },
    [VbRenderingMode.CYBERSCOPE]: {
        layout: VbStereoLayout.CYBERSCOPE,
        eyes: VbEyes.BOTH,
        // Each eye is squeezed to 256 columns, which the accessory's prisms expand.
        width: 512,
        height: VB_SCREEN_HEIGHT,
    },
    [VbRenderingMode.HLI]: {
        layout: VbStereoLayout.HLI,
        eyes: VbEyes.BOTH,
        width: VB_SCREEN_WIDTH,
        height: VB_SCREEN_HEIGHT * 2,
    },
    [VbRenderingMode.VLI]: {
        layout: VbStereoLayout.VLI,
        eyes: VbEyes.BOTH,
        width: VB_SCREEN_WIDTH * 2,
        height: VB_SCREEN_HEIGHT,
    },
};

/**
 * Everything the renderer needs to present a frame: the geometry the rendering
 * mode dictates, plus the colors chosen for it. The color palette resolves
 * every legacy eye image before composition; in Anaglyph mode the resolved
 * images are then passed through the selected left/right filters. VBC frames
 * already carry full RGB555 colors and bypass the legacy palette.
 */
export interface DisplayMode extends VbRenderingGeometry {
    palette: VbPalette;
    anaglyph: VbAnaglyphPalette;
}

export function isRenderingMode(mode: string): mode is VbRenderingMode {
    return mode in VB_RENDERING_GEOMETRIES;
}

export const VB_DEFAULT_RENDERING_MODE = VbRenderingMode.LEFT;

export function buildDisplayMode(
    mode: string,
    palette: VbPalette,
    anaglyph: VbAnaglyphPalette
): DisplayMode {
    const geometry = VB_RENDERING_GEOMETRIES[
        isRenderingMode(mode) ? mode : VB_DEFAULT_RENDERING_MODE
    ];
    return { ...geometry, palette, anaglyph };
}

export const VB_DEFAULT_DISPLAY_MODE = buildDisplayMode(
    VB_DEFAULT_RENDERING_MODE,
    VB_DEFAULT_PALETTE,
    VB_ANAGLYPH_PALETTES[VB_DEFAULT_ANAGLYPH_PALETTE_ID]
);
