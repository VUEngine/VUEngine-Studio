/**
 * Cheats, and the `.cht` files they live in.
 *
 * A cheat is a set of RAM writes the emulator repeats every frame, which is
 * what makes a value stay put however hard the game tries to change it — the
 * "RAM Write" codes gamehacking.org publishes for the Virtual Boy. A code is
 * written `ADDRESS:VALUE`, both hexadecimal, e.g. `50091A4:0001` for "write 1
 * to 0x050091A4 every frame". The number of digits in the value is how wide
 * the write is: two for a byte, four for a halfword, eight for a word.
 *
 * The file format is RetroArch's: a `cheats` count followed by `cheatN_desc`,
 * `cheatN_code` and `cheatN_enable` for each, with several codes in one cheat
 * separated by `+`. Reading is deliberately lenient — unknown keys, missing
 * quotes, a wrong or absent count, blank lines and `;` comments are all
 * tolerated — because these files are written by hand and by other tools as
 * often as by this one. Writing produces the canonical form.
 *
 * `cheatN_notes` is this application's own addition, an optional free-text
 * explanation beside a cheat — why it needs the value it does, what it does
 * not cover, a caveat about when it takes effect. It is not part of
 * RetroArch's format, but an unknown key is exactly what the leniency above is
 * for: a tool that only knows the standard keys reads a `.cht` this writes and
 * ignores the line, keeping every cheat — only the explanation goes missing,
 * never the cheat itself. Omitted entirely for a cheat with no notes, so a
 * file that uses none of this looks exactly as it always has.
 *
 * Everything here is pure, so it can be reasoned about, and tested, without a
 * running emulator or a file system.
 */

/** One `ADDRESS:VALUE` write. */
export interface CheatCode {
    /** Where to write, in the CPU's address space. */
    address: number;
    value: number;
    /** The value's width in hexadecimal digits: 2, 4 or 8. */
    digits: number;
}

export interface Cheat {
    description: string;
    enabled: boolean;
    codes: CheatCode[];
    /**
     * An optional explanation, shown beside the cheat rather than folded into
     * its name — see the module doc comment for the line it lives on in the
     * file. Free text, and may be several lines; nothing here parses it.
     */
    notes?: string;
    /**
     * Set for a cheat that came from the built-in database rather than from
     * the file beside the ROM.
     *
     * Such a cheat can be switched on and off but not edited or removed: it is
     * not the player's to change, and the next release may correct it. Only
     * whether it is on is remembered in browser state — see the cheat store.
     */
    readonly builtIn?: boolean;
    /**
     * A built-in's identity, stable across releases, which is what its
     * remembered on/off state is filed under. Absent on a player's own cheats,
     * which use a definition-derived identity in browser state.
     */
    readonly id?: string;
}

/** The widths a code's value may be written at, and what they mean in bytes. */
export const CHEAT_DIGITS = [2, 4, 8];
export const CHEAT_DEFAULT_DIGITS = 4;

export function vesCheatCodeBytes(code: CheatCode): number {
    return Math.max(1, Math.min(4, code.digits / 2));
}

/** The largest value a code of this width can hold. */
export function vesCheatMaxValue(digits: number): number {
    return digits >= 8 ? 0xffffffff : (1 << (digits * 4)) - 1;
}

/**
 * Read one `ADDRESS:VALUE` code, or undefined if it is not one.
 *
 * The address is masked to 32 bits rather than rejected when it is longer,
 * since published codes routinely leave off leading zeroes and occasionally
 * carry a stray one.
 */
export function parseVesCheatCode(text: string): CheatCode | undefined {
    const match = /^\s*([0-9a-f]{1,8})\s*:\s*([0-9a-f]{1,8})\s*$/i.exec(text);
    if (!match) {
        return undefined;
    }
    const digits = match[2].length <= 2 ? 2 : match[2].length <= 4 ? 4 : 8;
    return {
        address: parseInt(match[1], 16) >>> 0,
        value: parseInt(match[2], 16) >>> 0,
        digits,
    };
}

export function formatVesCheatCode(code: CheatCode): string {
    const address = (code.address >>> 0).toString(16).toUpperCase();
    const value = (code.value >>> 0).toString(16).toUpperCase().padStart(code.digits, '0');
    return `${address}:${value}`;
}

/** All of a cheat's codes, in the `+`-separated form the file holds. */
export function formatVesCheatCodes(cheat: Cheat): string {
    return cheat.codes.map(formatVesCheatCode).join('+');
}

/**
 * Parse all of a cheat's codes from the `+`-separated form the files use, and
 * that published cheat lists are written in. Anything unparseable is dropped
 * rather than failing the rest.
 */
export function parseVesCheatCodes(text: string): CheatCode[] {
    return text.split('+')
        .map(parseVesCheatCode)
        .filter((parsed): parsed is CheatCode => parsed !== undefined);
}

/** Parse the `.cht` file next to a ROM. */
export function parseVesCheatFile(text: string): Cheat[] {
    const values = new Map<string, string>();
    for (const line of text.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (trimmed.length === 0 || trimmed.startsWith(';') || trimmed.startsWith('#')) {
            continue;
        }
        const separator = trimmed.indexOf('=');
        if (separator === -1) {
            continue;
        }
        const key = trimmed.slice(0, separator).trim().toLowerCase();
        const value = trimmed.slice(separator + 1).trim().replace(/^"(.*)"$/, '$1');
        values.set(key, value);
    }

    // The declared count is a hint rather than the authority: a file whose
    // count is stale or missing still has its entries read, and one that
    // overstates it does not produce empty cheats at the end.
    const declared = parseInt(values.get('cheats') ?? '', 10);
    const cheats: Cheat[] = [];
    for (let index = 0; index < Math.max(Number.isNaN(declared) ? 0 : declared, values.size); index++) {
        const description = values.get(`cheat${index}_desc`);
        const code = values.get(`cheat${index}_code`);
        if (description === undefined && code === undefined) {
            continue;
        }
        // Unescaped back into real newlines on the way in — see the module
        // doc comment and serializeVesCheatFile's own escaping, which is what
        // keeps a multi-line note to the one physical line every other key
        // here holds to.
        const notes = values.get(`cheat${index}_notes`);
        cheats.push({
            description: description ?? '',
            enabled: (values.get(`cheat${index}_enable`) ?? 'false').toLowerCase() === 'true',
            codes: parseVesCheatCodes(code ?? ''),
            notes: notes ? notes.replace(/\\n/g, '\n') : undefined,
        });
    }
    return cheats;
}

export function serializeVesCheatFile(cheats: Cheat[]): string {
    const lines = [`cheats = ${cheats.length}`];
    cheats.forEach((cheat, index) => {
        lines.push(
            '',
            `cheat${index}_desc = "${cheat.description.replace(/"/g, '')}"`,
            `cheat${index}_code = "${formatVesCheatCodes(cheat)}"`,
            `cheat${index}_enable = ${cheat.enabled}`
        );
        // Omitted for a cheat with no notes, so a file that uses none of this
        // is byte-for-byte what it always was — no reader, standard or this
        // one, sees a key it has to account for. Real newlines are escaped so
        // the note still holds to one physical line, the same as every other
        // key: an embedded one would otherwise read as the start of a new key.
        if (cheat.notes) {
            lines.push(
                `cheat${index}_notes = "${cheat.notes.replace(/"/g, '').replace(/\r?\n/g, '\\n')}"`);
        }
    });
    return `${lines.join('\n')}\n`;
}

/** The writes the enabled cheats add up to, in the order they are listed. */
export function enabledVesCheatCodes(cheats: ReadonlyArray<Cheat>): CheatCode[] {
    return cheats.filter(cheat => cheat.enabled).flatMap(cheat => cheat.codes);
}
