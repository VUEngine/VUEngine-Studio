/**
 * How a cartridge's save RAM comes up when there is no save file for it yet.
 *
 * In `common/` rather than beside the other emulator types because the save
 * state format depends on it, and that format is host-free.
 */
export enum EmulatorSramInit {
    RANDOM = 'random',
    ZEROES = 'zeroes',
}

/**
 * How much of Game Pak RAM a cartridge answers on.
 *
 * `AUTO` is the whole of it, which is what a cartridge gets unless somebody
 * says otherwise, and it is the only answer that can never be too small: a
 * Virtual Boy ROM has nowhere to declare how much save RAM its cartridge has,
 * so guessing lower is guessing.
 *
 * The rest are for somebody building for real hardware, and what they buy is
 * mirroring. A cartridge answering on 16 KiB has every address above it fold
 * back onto the bottom, and a game that asks the hardware how much save RAM
 * it has — by writing a pattern and seeing where it reappears — gets the
 * answer the real cartridge would give rather than 16 MiB. That question is
 * the whole reason this setting exists: without it, the emulator would quietly
 * tell a developer they have a hundred times the save RAM they will ship with.
 *
 * These are *window* sizes, not chip sizes. Only the low byte of each halfword
 * is wired to the chip, so the 8 KiB a standard game pak holds is the 16 KiB
 * window — which is why that is where the list starts and what it is called.
 */
export enum EmulatorSramWindow {
    /** All 16 MiB of the region. */
    AUTO = 'auto',
    /** What a standard game pak answers on: an 8 KiB chip across 16 KiB of bus. */
    W16K = '16k',
    W32K = '32k',
    W64K = '64k',
    W128K = '128k',
    W256K = '256k',
    W512K = '512k',
    W1M = '1m',
    W2M = '2m',
    W4M = '4m',
    W8M = '8m',
}

/**
 * Where a ROM's companion files are kept — its save, its save states, its
 * cheats.
 *
 * Two answers, and which is right depends on the application rather than on
 * the person using it. Beside the ROM is what an emulator conventionally does
 * and what somebody keeping a shelf of cartridges expects: the save travels
 * with the game, and copying the folder copies the progress. In the
 * application's own storage is what a browser has no choice about, and what a
 * host wants when the ROM sits somewhere it should not be writing — a build
 * output directory, a read-only volume, a project under version control.
 */
export enum EmulatorCompanionLocation {
    /** Beside the ROM file itself. */
    ROM = 'rom',
    /** In the application's own store: its config directory, or the browser's. */
    STORAGE = 'storage',
}

/**
 * The save-game slots a cartridge can be played on, "A" through "Z".
 *
 * A slot is a save file, not a save state: it holds what the game itself wrote
 * to the cartridge, so a slot is a second cartridge of the same game rather
 * than a snapshot of a moment in it.
 *
 * "A" keeps the name the save file has always had — `<rom>.p1.sram` — which is
 * the one another emulator would read and the one every save written before
 * slots existed is already in. The rest carry the letter: `<rom>.p1.B.sram`.
 * So a shelf that never touches this is unaffected, and a slot is a file
 * anybody can copy, back up or delete by hand.
 */
export const EMULATOR_SAVE_SLOTS: readonly string[] =
    Array.from({ length: 26 }, (unused, index) => String.fromCharCode('A'.charCodeAt(0) + index));

/** The slot a save file is in when nobody has chosen one. */
export const DEFAULT_SAVE_SLOT = 'A';

/**
 * The slot a stored value names, or the default when it names none.
 *
 * Settings are strings from a file that a person may have edited, so this is
 * the one place that decides what counts as a slot; everything else takes the
 * answer. A lower-case letter is the slot it spells — nothing is gained by
 * refusing "b" — and anything else is slot A, which is where a save that
 * belongs to no slot in particular lives.
 */
export function emulatorSaveSlot(value: unknown): string {
    const slot = typeof value === 'string' ? value.trim().toUpperCase() : '';
    return EMULATOR_SAVE_SLOTS.includes(slot) ? slot : DEFAULT_SAVE_SLOT;
}
