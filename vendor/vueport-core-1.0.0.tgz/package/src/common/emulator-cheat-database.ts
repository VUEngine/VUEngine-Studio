/**
 * Cheats that ship with the emulator.
 *
 * Keyed by the CRC32 of the whole ROM, which is what the Virtual Boy's
 * preservation catalogs (No-Intro, and libretro's own cheat lists) key on —
 * so an entry here can be taken from those without a translation step. It is
 * also cheap, needs no crypto API, and works in an insecure context, which
 * `crypto.subtle` does not.
 *
 * A CRC32 covers a whole file, and a Virtual Boy ROM is routinely padded up to
 * the next power of two — the header lives at `size - 544`, so it floats with
 * the end and parsing is unaffected, but the checksum is not. The same game
 * therefore has one CRC32 per padding, which is why an entry carries a list of
 * them rather than one.
 */

/** One cheat the emulator knows about without being told. */
export interface BuiltInCheat {
    /**
     * Stable for the life of the cheat: renaming its description is fine,
     * changing this is not, because a player's on/off state is filed under it.
     */
    id: string;
    description: string;
    /**
     * The codes, in the `+`-separated form the `.cht` files use — so an entry
     * can be pasted from a published list unchanged.
     */
    codes: string;
    /**
     * What is worth knowing beyond the name — a caveat about when the codes
     * take effect, why a game needs two variants, what was tried and did not
     * work. Optional, and shown but not editable, the same as the description
     * and the codes: see `Cheat.notes` for where it ends up.
     */
    notes?: string;
}

/** One game, and every ROM of it these cheats apply to. */
export interface CheatDatabaseEntry {
    /** For whoever is reading the database; never shown. */
    game: string;
    /** Lower-case, eight hex digits, one per known ROM of this game. */
    crc32: string[];
    cheats: BuiltInCheat[];
}

export const CHEAT_DATABASE: CheatDatabaseEntry[] = [
    {
        game: '3-D Tetris (USA)',
        crc32: ['bb71b522'],
        cheats: [
            {
                id: '3d-tetris/max-score',
                description: 'Max Score',
                codes: '5003AFC:E0FF+5003AFE:05F5',
            },
        ],
    },
    {
        game: 'Bound High (Japan, USA)',
        crc32: ['e365ddd3', 'e81a3703'],
        cheats: [
            {
                id: 'bound-high/unlimited-lives',
                description: 'Unlimited Lives',
                codes: '5000020:00FF'
            }
        ],
    },
    {
        game: 'Dragon Hopper (Japan, USA)',
        crc32: ['193c1a2f'],
        cheats: [
            {
                id: 'dragon-hopper/debug-mode',
                description: 'Debug Mode',
                notes: 'Requires Restart',
                codes: '7031D44:0001'
            },
            {
                id: 'dragon-hopper/unlimited-health',
                description: 'Unlimited Health',
                codes: '500CC5E:1000'
            }
        ],
    },
    {
        game: 'Galactic Pinball (Japan, USA)',
        crc32: [
            'c9710a36' // US, JP
        ],
        cheats: [
            {
                id: 'galactic-pinball/bonus-game',
                description: 'Bonus Game',
                codes: '5004F80:0005',
            },
            {
                id: 'galactic-pinball/infinite-pucks',
                description: 'Infinite Pucks',
                codes: '5006F30:0009',
            },
        ],
    },
    {
        game: 'Jack Bros. (USA)',
        crc32: ['a44de03c'],
        cheats: [
            {
                id: 'jack-bros/infinite-time',
                description: 'Infinite Time',
                codes: '5000112:0046',
            },
            {
                id: 'jack-bros/invincible-etc',
                description: 'Invincible, Etc.',
                codes: '5000150:FFFF',
            },
        ],
    },
    {
        game: 'Mario Clash (Japan, USA)',
        crc32: ['a47de78c'],
        cheats: [
            {
                id: 'mario-clash/unlimited-time',
                description: 'Unlimited Time',
                codes: '5009AE0:00C8',
            },
            {
                id: 'mario-clash/unlimited-lives',
                description: 'Unlimited Lives',
                codes: '5009A77:0064',
            },
            {
                id: 'mario-clash/select-any-level',
                description: 'Select Any Level',
                codes: '70E7A26:0063+70E7B02:0063',
            },
        ],
    },
    {
        game: 'Mario\'s Tennis (Japan, USA)',
        crc32: ['7ce7460d'],
        cheats: [
            {
                id: 'marios-tennis/player-6-points',
                description: 'Player 6 Points (Set 1)',
                codes: '05002090:06',
            },
            {
                id: 'marios-tennis/cpu-6-points',
                description: 'CPU 6 Points (Set 1)',
                codes: '05002091:06',
            },
        ],
    },
    {
        game: 'Panic Bomber (USA)',
        crc32: ['19bb2dfb'],
        cheats: [
            {
                id: 'panic-bomber/debug-mode',
                description: 'Debug Mode',
                codes: '70006B4:00AC+70006B6:9403+700090C:0020+7000958:00A0+70009B6:0040+7000D0A:F8A4+7000D38:F8A4+7000D64:F8A4',
            },
            {
                id: 'panic-bomber/stage-select',
                description: 'Stage Select',
                codes: '70006B2:E841+70006B4:02AC+70006B6:4C79+7028000:E4D1+7028002:D6A6+7028004:E141+7028006:E4D1+7028008:F8A4+702800A:1F18',
            },
        ],
    },
    {
        game: 'Red Alarm (Japan, USA)',
        crc32: [
            'aa10a7b4', // US
            '7e85c45d', // JP
        ],
        cheats: [
            {
                id: 'red-alarm/debug-menu',
                description: 'Debug Menu',
                notes: 'L, R, Select, A in-game shows a debug menu',
                codes: '703C7EC:24',
            },
            {
                id: 'red-alarm/no-ads',
                description: 'No Ads',
                codes: '702E5B0:4900+702E5C4:4900+702E5E4:4500+702E600:2600+702E610:5200+702E62C:4900+702E640:4900',
            },
        ],
    },
    {
        game: 'SD Gundam Dimension War (Japan)',
        crc32: ['44788197'],
        cheats: [
            {
                id: 'sd-gundam-dimension-war/infinite-time',
                description: 'Infinite Time',
                codes: '05000300:09',
            },
        ],
    },
    {
        game: 'Space Invaders - Virtual Collection (Japan)',
        crc32: ['fa44402d'],
        cheats: [
            {
                id: 'space-invaders-virtual-collection/infinite-lives',
                description: 'Infinite Lives',
                codes: '700D326:4045',
            },
        ],
    },
    {
        game: 'Space Squash (Japan)',
        crc32: ['60895693'],
        cheats: [
            {
                id: 'space-squash/infinite-hp',
                description: 'Infinite HP',
                codes: '5000130:0004',
            },
        ],
    },
    {
        game: 'Teleroboxer (Japan, USA)',
        crc32: [
            '36103000' // Retail
        ],
        cheats: [
            {
                id: 'teleroboxer/1-hit-knock-outs',
                description: '1-Hit Knock Outs',
                codes: '5004780:0001',
            },
            {
                id: 'teleroboxer/infinite-health',
                description: 'Infinite Health',
                codes: '500477C:007F',
            },
        ],
    },
    {
        game: 'Vertical Force (USA)',
        crc32: ['4c32ba5e'],
        cheats: [
            {
                id: 'vertical-force/debug-menu',
                description: 'Debug Menu',
                codes: '700B330:0022',
            },
            {
                id: 'vertical-force/infinite-energy',
                description: 'Infinite Energy',
                codes: '5003F6D:0008',
            },
        ],
    },
    {
        game: 'Virtual Bowling (Japan)',
        crc32: ['20688279'],
        cheats: [
            {
                id: 'virtual-bowling/debug-menu',
                description: 'Debug Menu',
                codes: '7003EFA:0041',
            },
        ],
    },
    {
        game: 'Virtual Boy Wario Land (Japan, USA)',
        crc32: [
            '133e9372', // US, JP
        ],
        cheats: [
            {
                id: 'virtual-boy-wario-land/99-hearts',
                description: '99 Hearts',
                codes: '50087A6:0063',
            },
            {
                id: 'virtual-boy-wario-land/9999-coins',
                description: '9999 Coins',
                codes: '50087A8:270F',
            },
            {
                id: 'virtual-boy-wario-land/helmet-cap',
                description: 'Helmet Cap',
                codes: '5001087:0001',
            },
            {
                id: 'virtual-boy-wario-land/bull-cap',
                description: 'Bull Cap',
                codes: '5001087:0002',
            },
            {
                id: 'virtual-boy-wario-land/sea-dragon-cap',
                description: 'Sea Dragon Cap',
                codes: '5001087:0003',
            },
            {
                id: 'virtual-boy-wario-land/eagle-cap',
                description: 'Eagle Cap',
                codes: '5001087:0004',
            },
            {
                id: 'virtual-boy-wario-land/king-dragon-cap',
                description: 'King Dragon Cap',
                codes: '5001087:0005',
            },
            {
                id: 'virtual-boy-wario-land/infinite-flight-time',
                description: 'Infinite Flight Time',
                codes: '500103F:0000',
            },
            {
                id: 'virtual-boy-wario-land/infinite-lives',
                description: 'Infinite Lives',
                codes: '50087A4:0009',
            },
            {
                id: 'virtual-boy-wario-land/infinite-time',
                description: 'Infinite Time',
                codes: '50087AA:0E0F',
            },
            {
                id: 'virtual-boy-wario-land/invincibility',
                description: 'Invincibility',
                codes: '5001063:0001',
            },
            {
                id: 'virtual-boy-wario-land/have-key',
                description: 'Have Key',
                codes: '50087B0:0001',
            },
            {
                id: 'virtual-boy-wario-land/have-all-treasures-quest-1',
                description: 'Have All First Quest Treasures',
                codes: '50091A4:0001+50091A8:0001+50091AC:0001+50091B0:0001+50091B4:0001+50091B8:0001+50091BC:0001+50091C0:0001+50091C4:0001+50091C8:0001',
            },
            {
                id: 'virtual-boy-wario-land/have-all-treasures-quest-2',
                description: 'Have All Second Quest Treasures',
                codes: '50091A4:0002+50091A8:0002+50091AC:0002+50091B0:0002+50091B4:0002+50091B8:0002+50091BC:0002+50091C0:0002+50091C4:0002+50091C8:0002',
            },
        ],
    },
    {
        game: 'Virtual League Baseball 2 (USA)',
        crc32: [
            '8daea1bf' // USA Prototype
        ],
        cheats: [
            {
                id: 'virtual-league-baseball-2/max-custom-team-points',
                description: 'Max Custom Team Points',
                codes: '7036FDC:0695',
            },
        ],
    },
    {
        game: 'Waterworld (USA)',
        crc32: ['82a95e51'],
        cheats: [
            {
                id: 'waterworld/infinite-lives-ram',
                description: 'Infinite Lives (RAM)',
                codes: '5009B62:0003',
            },
            {
                id: 'waterworld/infinite-lives-rom',
                description: 'Infinite Lives (ROM)',
                codes: '701654E:C144',
            },
        ],
    },
    {
        game: 'Zero Racers (USA, Japan)',
        crc32: [
            '71553796' // Retail
        ],
        cheats: [
            {
                id: 'zero-racers/unlock-extra-racers',
                description: 'Unlock Extra Racers',
                codes: '701A769:008A',
            },
            {
                id: 'zero-racers/unlimited-rapids',
                description: 'Unlimited Rapids',
                codes: '500DD20:0003',
            },
        ],
    },
];

/** The CRC32 of a ROM, lower-case and eight digits, as the database spells it. */
/**
 * CRC-32 of a ROM, which is how the preservation catalogs the cheat database
 * is drawn from identify a dump.
 *
 * Written out rather than taken from a package: it is twenty lines, and this
 * is the only checksum the emulator needs — a host that already has one is
 * free to compute the number itself and call `formatRomId`.
 */
export function crc32(bytes: Uint8Array): number {
    let table = CRC32_TABLE;
    if (!table) {
        table = CRC32_TABLE = new Uint32Array(256);
        for (let i = 0; i < 256; i++) {
            let value = i;
            for (let bit = 0; bit < 8; bit++) {
                value = value & 1 ? (value >>> 1) ^ 0xedb88320 : value >>> 1;
            }
            table[i] = value >>> 0;
        }
    }
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
        crc = (crc >>> 8) ^ table[(crc ^ bytes[i]) & 0xff];
    }
    return (crc ^ 0xffffffff) >>> 0;
}

let CRC32_TABLE: Uint32Array | undefined;

export function formatRomId(checksum: number): string {
    return (checksum >>> 0).toString(16).padStart(8, '0');
}

/**
 * The cheats shipped for a ROM, or none for one nothing is known about — which
 * is the ordinary case for homebrew and for anything still being built.
 */
export function builtInCheatsFor(
    romId: string | undefined,
    database: CheatDatabaseEntry[] = CHEAT_DATABASE,
): BuiltInCheat[] {
    if (!romId) {
        return [];
    }
    const wanted = romId.toLowerCase();
    return database
        .filter(entry => entry.crc32.some(crc => crc.toLowerCase() === wanted))
        .flatMap(entry => entry.cheats);
}
