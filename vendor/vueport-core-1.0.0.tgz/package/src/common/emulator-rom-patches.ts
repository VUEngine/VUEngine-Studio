import Bunzip = require('seek-bzip');
import { crc32 } from './emulator-cheat-database';

/** Patch formats accepted by the emulator. */
export type RomPatchFormat = 'ips' | 'ups' | 'bps' | 'bsdiff';

/** What kind of change a ROM patch makes. */
export const ROM_PATCH_TYPES = ['hack', 'debug', 'trainer', 'translation'] as const;
export type RomPatchType = typeof ROM_PATCH_TYPES[number];

/** A patch ready to be applied to a ROM. */
export interface RomPatch {
    name: string;
    fileName: string;
    format: RomPatchFormat;
    data: Uint8Array;
    enabled: boolean;
    description?: string;
    author?: string;
    type: RomPatchType;
    /** Asset URL or data URL displayed by the patch detail view. */
    screenshot?: string;
    builtIn?: boolean;
    id?: string;
    /**
     * VUEPort built this patch in-process rather than reading it from a file.
     *
     * Currently only the VB Color colorizations, and the reason it is worth a
     * field is that they have a panel of their own: the Patches panel lists
     * what a player registered for this ROM, and a colorization is not that.
     * It is switched on from the Colors panel, its name and version come from
     * the colorization catalog rather than from a file, and removing it there
     * would mean nothing — so listing it beside imported patches would offer
     * three controls that either lie or do nothing. Set by
     * `VesEmulatorPatchStore.setGeneratedPatch`.
     */
    generated?: boolean;
}

/** A malformed patch, or one made for a different source ROM. */
export class RomPatchError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'RomPatchError';
    }
}

const text = (bytes: Uint8Array, offset: number, length: number): string =>
    String.fromCharCode(...bytes.subarray(offset, offset + length));

const requireBytes = (bytes: Uint8Array, offset: number, length: number, what: string): void => {
    if (offset < 0 || length < 0 || offset + length > bytes.length) {
        throw new RomPatchError(`Unexpected end of ${what}.`);
    }
};

/** Detect by signature; extensions are deliberately not trusted. */
export function detectRomPatchFormat(data: Uint8Array): RomPatchFormat {
    if (text(data, 0, 5) === 'PATCH') {
        return 'ips';
    }
    if (text(data, 0, 4) === 'UPS1') {
        return 'ups';
    }
    if (text(data, 0, 4) === 'BPS1') {
        return 'bps';
    }
    if (text(data, 0, 8) === 'BSDIFF40') {
        return 'bsdiff';
    }
    throw new RomPatchError('Unsupported or unrecognized ROM patch format.');
}

function readU24BE(data: Uint8Array, offset: number): number {
    requireBytes(data, offset, 3, 'IPS patch');
    return data[offset] * 0x10000 + data[offset + 1] * 0x100 + data[offset + 2];
}

function readU16BE(data: Uint8Array, offset: number): number {
    requireBytes(data, offset, 2, 'IPS patch');
    return data[offset] * 0x100 + data[offset + 1];
}

function resizedCopy(source: Uint8Array, size: number): Uint8Array {
    if (!Number.isSafeInteger(size) || size < 0) {
        throw new RomPatchError('Invalid patched ROM size.');
    }
    const result = new Uint8Array(size);
    result.set(source.subarray(0, Math.min(source.length, size)));
    return result;
}

function grow(source: Uint8Array, size: number): Uint8Array {
    return size <= source.length ? source : resizedCopy(source, size);
}

function applyIps(source: Uint8Array, patch: Uint8Array): Uint8Array {
    let output: Uint8Array = source.slice();
    let cursor = 5;
    while (true) {
        requireBytes(patch, cursor, 3, 'IPS patch');
        if (text(patch, cursor, 3) === 'EOF') {
            cursor += 3;
            break;
        }
        const offset = readU24BE(patch, cursor);
        const length = readU16BE(patch, cursor + 3);
        cursor += 5;
        if (length === 0) {
            const runLength = readU16BE(patch, cursor);
            requireBytes(patch, cursor + 2, 1, 'IPS patch');
            cursor += 3;
            output = grow(output, offset + runLength);
            output.fill(patch[cursor - 1], offset, offset + runLength);
        } else {
            requireBytes(patch, cursor, length, 'IPS patch');
            output = grow(output, offset + length);
            output.set(patch.subarray(cursor, cursor + length), offset);
            cursor += length;
        }
    }
    // The optional three bytes after EOF truncate or extend the target.
    if (patch.length - cursor === 3) {
        output = resizedCopy(output, readU24BE(patch, cursor));
    } else if (patch.length !== cursor) {
        throw new RomPatchError('Invalid data after IPS EOF marker.');
    }
    return output;
}

class PatchReader {
    offset: number;

    constructor(readonly data: Uint8Array, offset = 0, readonly end = data.length) {
        this.offset = offset;
    }

    byte(what: string): number {
        if (this.offset >= this.end) {
            throw new RomPatchError(`Unexpected end of ${what}.`);
        }
        return this.data[this.offset++];
    }

    variable(what: string): number {
        let value = 0;
        let shift = 1;
        while (true) {
            const next = this.byte(what);
            value += (next & 0x7f) * shift;
            if (!Number.isSafeInteger(value)) {
                throw new RomPatchError(`${what} contains a value that is too large.`);
            }
            if ((next & 0x80) !== 0) {
                return value;
            }
            shift *= 0x80;
            value += shift;
            if (!Number.isSafeInteger(shift) || !Number.isSafeInteger(value)) {
                throw new RomPatchError(`${what} contains a value that is too large.`);
            }
        }
    }
}

function readU32LE(data: Uint8Array, offset: number): number {
    requireBytes(data, offset, 4, 'patch checksum');
    return (data[offset]
        | data[offset + 1] << 8
        | data[offset + 2] << 16
        | data[offset + 3] << 24) >>> 0;
}

function verifyChecksums(source: Uint8Array, patch: Uint8Array): { target: number, bodyEnd: number } {
    if (patch.length < 16) {
        throw new RomPatchError('Patch is too short.');
    }
    const footer = patch.length - 12;
    const sourceCrc = readU32LE(patch, footer);
    const targetCrc = readU32LE(patch, footer + 4);
    const patchCrc = readU32LE(patch, footer + 8);
    if (crc32(patch.subarray(0, patch.length - 4)) !== patchCrc) {
        throw new RomPatchError('Patch checksum does not match.');
    }
    if (crc32(source) !== sourceCrc) {
        throw new RomPatchError('Patch was made for a different ROM.');
    }
    return { target: targetCrc, bodyEnd: footer };
}

function verifyTarget(output: Uint8Array, expected: number): Uint8Array {
    if (crc32(output) !== expected) {
        throw new RomPatchError('Patched ROM checksum does not match.');
    }
    return output;
}

function applyUps(source: Uint8Array, patch: Uint8Array): Uint8Array {
    const checksums = verifyChecksums(source, patch);
    const reader = new PatchReader(patch, 4, checksums.bodyEnd);
    const sourceSize = reader.variable('UPS patch');
    const targetSize = reader.variable('UPS patch');
    if (sourceSize !== source.length) {
        throw new RomPatchError('UPS patch was made for a differently sized ROM.');
    }
    const output = resizedCopy(source, targetSize);
    let outputOffset = 0;
    while (reader.offset < reader.end) {
        outputOffset += reader.variable('UPS patch');
        if (outputOffset >= output.length) {
            throw new RomPatchError('UPS patch writes beyond the target ROM.');
        }
        while (true) {
            const value = reader.byte('UPS patch');
            if (value === 0) {
                outputOffset++;
                break;
            }
            if (outputOffset >= output.length) {
                throw new RomPatchError('UPS patch writes beyond the target ROM.');
            }
            output[outputOffset] = (source[outputOffset] ?? 0) ^ value;
            outputOffset++;
        }
    }
    return verifyTarget(output, checksums.target);
}

function signedVariable(reader: PatchReader, what: string): number {
    const encoded = reader.variable(what);
    const magnitude = Math.floor(encoded / 2);
    return (encoded & 1) === 0 ? magnitude : -magnitude;
}

function applyBps(source: Uint8Array, patch: Uint8Array): Uint8Array {
    const checksums = verifyChecksums(source, patch);
    const reader = new PatchReader(patch, 4, checksums.bodyEnd);
    const sourceSize = reader.variable('BPS patch');
    const targetSize = reader.variable('BPS patch');
    const metadataSize = reader.variable('BPS patch');
    if (sourceSize !== source.length) {
        throw new RomPatchError('BPS patch was made for a differently sized ROM.');
    }
    if (reader.offset + metadataSize > reader.end) {
        throw new RomPatchError('Invalid BPS metadata size.');
    }
    reader.offset += metadataSize;
    const output = new Uint8Array(targetSize);
    let outputOffset = 0;
    let sourceRelativeOffset = 0;
    let targetRelativeOffset = 0;
    while (outputOffset < output.length) {
        const action = reader.variable('BPS patch');
        const length = Math.floor(action / 4) + 1;
        const mode = action & 3;
        if (outputOffset + length > output.length) {
            throw new RomPatchError('BPS action writes beyond the target ROM.');
        }
        if (mode === 0) {
            if (outputOffset + length > source.length) {
                throw new RomPatchError('BPS action reads beyond the source ROM.');
            }
            output.set(source.subarray(outputOffset, outputOffset + length), outputOffset);
        } else if (mode === 1) {
            if (reader.offset + length > reader.end) {
                throw new RomPatchError('Unexpected end of BPS target data.');
            }
            output.set(patch.subarray(reader.offset, reader.offset + length), outputOffset);
            reader.offset += length;
        } else if (mode === 2) {
            sourceRelativeOffset += signedVariable(reader, 'BPS source copy');
            if (sourceRelativeOffset < 0 || sourceRelativeOffset + length > source.length) {
                throw new RomPatchError('BPS action reads beyond the source ROM.');
            }
            output.set(source.subarray(sourceRelativeOffset, sourceRelativeOffset + length), outputOffset);
            sourceRelativeOffset += length;
        } else {
            targetRelativeOffset += signedVariable(reader, 'BPS target copy');
            if (targetRelativeOffset < 0 || targetRelativeOffset >= outputOffset) {
                throw new RomPatchError('BPS action reads beyond produced target data.');
            }
            for (let i = 0; i < length; i++) {
                if (targetRelativeOffset >= outputOffset + i) {
                    throw new RomPatchError('BPS target copy references unavailable data.');
                }
                output[outputOffset + i] = output[targetRelativeOffset++];
            }
        }
        outputOffset += length;
    }
    if (reader.offset !== reader.end) {
        throw new RomPatchError('Unused data remains in BPS patch.');
    }
    return verifyTarget(output, checksums.target);
}

/** BSDiff's signed-magnitude, little-endian 64-bit integer. */
function readBsdiffInt(data: Uint8Array, offset: number): number {
    requireBytes(data, offset, 8, 'BSDiff patch');
    let value = data[offset + 7] & 0x7f;
    for (let i = 6; i >= 0; i--) {
        value = value * 0x100 + data[offset + i];
        if (!Number.isSafeInteger(value)) {
            throw new RomPatchError('BSDiff patch contains a value that is too large.');
        }
    }
    return (data[offset + 7] & 0x80) !== 0 ? -value : value;
}

/**
 * The whole of `Buffer` that `seek-bzip` actually asks for.
 *
 * The decoder targets Node and reaches for `Buffer` as a global: it allocates
 * with `new Buffer(length)`, indexes, reads `length`, copies one into another,
 * and — in the bit reader, to compare a block's magic — renders six bytes as
 * hex. That is all of it, and all of it is `Uint8Array` plus a dozen lines.
 * The `buffer` package answers the same shape in twenty-five kilobytes, which
 * is a lot of bundle to carry for a code path that only runs when someone
 * applies a BSDiff patch.
 */
class BunzipBuffer extends Uint8Array {
    copy(target: Uint8Array, targetStart = 0, sourceStart = 0, sourceEnd = this.length): number {
        const slice = this.subarray(sourceStart, sourceEnd);
        target.set(slice, targetStart);
        return slice.length;
    }

    /*
     * `Uint8Array`'s own `toString` gives a comma-separated list, which the
     * bit reader would compare against a block magic and never match — the
     * failure reads as "not bzip data" on perfectly good input.
     */
    toString(encoding?: string): string {
        if (encoding !== 'hex') {
            return super.toString();
        }
        let hex = '';
        for (let i = 0; i < this.length; i++) {
            hex += this[i].toString(16).padStart(2, '0');
        }
        return hex;
    }
}

function bunzip(data: Uint8Array): Uint8Array {
    // Supplied as the global the decoder expects, and only when the host does
    // not already have one — under Node the real `Buffer` is there and is left
    // alone, so nothing outside this decode sees a substitute.
    const scope = globalThis as unknown as { Buffer?: unknown };
    if (!scope.Buffer) {
        scope.Buffer = BunzipBuffer;
    }
    try {
        // `decode` only indexes its input and reads its length, so the ROM's
        // own bytes go in as they are.
        return new Uint8Array(Bunzip.decode(data));
    } catch (error) {
        throw new RomPatchError(`BSDiff data could not be decompressed: ${String(error)}`);
    }
}

function applyBsdiff(source: Uint8Array, patch: Uint8Array): Uint8Array {
    requireBytes(patch, 0, 32, 'BSDiff patch');
    const controlLength = readBsdiffInt(patch, 8);
    const diffLength = readBsdiffInt(patch, 16);
    const targetSize = readBsdiffInt(patch, 24);
    if (controlLength < 0 || diffLength < 0 || targetSize < 0
        || 32 + controlLength + diffLength > patch.length) {
        throw new RomPatchError('Invalid BSDiff header.');
    }
    const control = bunzip(patch.subarray(32, 32 + controlLength));
    const diff = bunzip(patch.subarray(32 + controlLength, 32 + controlLength + diffLength));
    const extra = bunzip(patch.subarray(32 + controlLength + diffLength));
    const output = new Uint8Array(targetSize);
    let controlOffset = 0;
    let diffOffset = 0;
    let extraOffset = 0;
    let sourceOffset = 0;
    let targetOffset = 0;
    while (targetOffset < targetSize) {
        requireBytes(control, controlOffset, 24, 'BSDiff control stream');
        const diffCount = readBsdiffInt(control, controlOffset);
        const extraCount = readBsdiffInt(control, controlOffset + 8);
        const sourceAdvance = readBsdiffInt(control, controlOffset + 16);
        controlOffset += 24;
        if (diffCount < 0 || extraCount < 0
            || targetOffset + diffCount + extraCount > targetSize
            || diffOffset + diffCount > diff.length
            || extraOffset + extraCount > extra.length) {
            throw new RomPatchError('Invalid BSDiff control data.');
        }
        for (let i = 0; i < diffCount; i++) {
            const old = sourceOffset + i >= 0 && sourceOffset + i < source.length
                ? source[sourceOffset + i]
                : 0;
            output[targetOffset + i] = (old + diff[diffOffset + i]) & 0xff;
        }
        targetOffset += diffCount;
        sourceOffset += diffCount;
        diffOffset += diffCount;
        output.set(extra.subarray(extraOffset, extraOffset + extraCount), targetOffset);
        targetOffset += extraCount;
        extraOffset += extraCount;
        sourceOffset += sourceAdvance;
    }
    return output;
}

/**
 * Apply one patch.
 *
 * The format algorithms follow RomPatcher.js (MIT, Marc Robledo) and their
 * respective public specifications, adapted to typed arrays and strict bounds
 * checking for VUEPort.
 */
export function applyRomPatch(source: Uint8Array, patch: Uint8Array): Uint8Array {
    switch (detectRomPatchFormat(patch)) {
        case 'ips': return applyIps(source, patch);
        case 'ups': return applyUps(source, patch);
        case 'bps': return applyBps(source, patch);
        case 'bsdiff': return applyBsdiff(source, patch);
    }
}

/** Apply enabled patches in list order, each one seeing the prior result. */
export function applyRomPatches(source: Uint8Array, patches: readonly RomPatch[]): Uint8Array {
    return patches.filter(patch => patch.enabled)
        .reduce((rom, patch) => applyRomPatch(rom, patch.data), source.slice());
}

/**
 * Encode a BPS patch that turns `source` into `target`.
 *
 * For patches VUEPort builds itself — a VB Color colorization, which is a whole
 * ROM by the time it is built and has to reach the patch store as a delta like
 * every other patch. Linear and deliberately simple: a run of bytes matching
 * the source at the same offset is a SourceRead, anything else goes in as a
 * TargetRead. For a target that is the source with some regions rewritten,
 * which is all this is used for, that is as small as a BPS gets without
 * searching for anything.
 */
export function createBpsPatch(source: Uint8Array, target: Uint8Array): Uint8Array {
    const out: number[] = [0x42, 0x50, 0x53, 0x31]; // BPS1
    const variable = (value: number): void => {
        let data = value;
        for (;;) {
            const low = data % 128;
            data = Math.floor(data / 128);
            if (data === 0) {
                out.push(low | 0x80);
                return;
            }
            out.push(low);
            data -= 1;
        }
    };
    const u32 = (value: number): void => {
        out.push(value & 0xff, (value >>> 8) & 0xff, (value >>> 16) & 0xff, (value >>> 24) & 0xff);
    };
    const matches = (offset: number): boolean => offset < source.length && source[offset] === target[offset];

    variable(source.length);
    variable(target.length);
    variable(0); // no metadata
    let at = 0;
    while (at < target.length) {
        const same = matches(at);
        let end = at + 1;
        while (end < target.length && matches(end) === same) {
            end += 1;
        }
        variable((end - at - 1) * 4 + (same ? 0 : 1));
        if (!same) {
            for (let i = at; i < end; i += 1) {
                out.push(target[i]);
            }
        }
        at = end;
    }
    u32(crc32(source));
    u32(crc32(target));
    u32(crc32(Uint8Array.from(out)));
    return Uint8Array.from(out);
}
