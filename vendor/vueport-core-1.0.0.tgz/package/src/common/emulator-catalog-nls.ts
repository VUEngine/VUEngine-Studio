/**
 * The shipped catalogs — cheats, ROM patches, colorizations — and the
 * RetroAchievements achievements in the player's language.
 *
 * The catalogs hold English, and each entry's texts are translated under keys
 * derived from its id: `vueport/cheatDatabase/<id>/title`,
 * `vueport/patchDatabase/<id>/name` and so on. A colorization is a patch like
 * the others, so its texts sit beside theirs, under its own id
 * (`vueport/patchDatabase/color/red-alarm/name`), its notes as the description
 * the Patches panel shows them as. The id is what the player's switches are
 * filed under anyway, so it is already the one thing about an entry that does
 * not move; the English stays the default, so an entry nobody has translated
 * yet still reads.
 *
 * The keys are built, not written out, which `yarn nls-extract` cannot follow:
 * it reports these calls and skips them. Their entries in `i18n/nls.json` are
 * kept by hand instead — the extractor merges into that file rather than
 * replacing it — and `tests/catalog-nls-probe.mjs` checks that every catalog
 * entry has them, in English and in every shipped language.
 *
 * Called when an entry is shown or loaded, never while a module loads; see
 * the timing note in `emulator-nls.ts`.
 *
 * Achievements are not VUEPort's catalog but RetroAchievements', whose authors
 * may reword one at any time without its id changing. So an achievement's key
 * also carries the CRC32 of the English it was translated from —
 * `vueport/achievementDatabase/56777/title-<crc32>` — and a reworded one simply
 * finds no translation and is shown in the new English until it is translated
 * again, rather than in a translation of what it used to say.
 */

import { BuiltInCheat, crc32, formatRomId } from './emulator-cheat-database';
import { VesColorPatch } from './emulator-color-patches';
import { nls } from './emulator-nls';
import { BuiltInRomPatch } from './emulator-patch-database';

/** A shipped cheat's title. */
export function cheatTitle(cheat: BuiltInCheat): string {
    return nls.localize(`vueport/cheatDatabase/${cheat.id}/title`, cheat.description);
}

/** A shipped cheat's notes, if it has any. */
export function cheatNotes(cheat: BuiltInCheat): string | undefined {
    return cheat.notes === undefined
        ? undefined
        : nls.localize(`vueport/cheatDatabase/${cheat.id}/notes`, cheat.notes);
}

/** A shipped ROM patch's name. */
export function patchName(patch: BuiltInRomPatch): string {
    return nls.localize(`vueport/patchDatabase/${patch.id}/name`, patch.name);
}

/** A shipped ROM patch's description. */
export function patchDescription(patch: BuiltInRomPatch): string {
    return nls.localize(`vueport/patchDatabase/${patch.id}/description`, patch.description);
}

/** A colorization's name. */
export function colorPatchName(patch: VesColorPatch): string {
    return nls.localize(`vueport/patchDatabase/${patch.id}/name`, patch.name);
}

/** A colorization's notes, which the Patches panel shows as its description. */
export function colorPatchNotes(patch: VesColorPatch): string | undefined {
    return patch.notes === undefined
        ? undefined
        : nls.localize(`vueport/patchDatabase/${patch.id}/description`, patch.notes);
}

/** The key an achievement text is translated under: its id, which text, and the English's CRC32. */
export function achievementTextKey(id: number, field: 'title' | 'description', english: string): string {
    return `vueport/achievementDatabase/${id}/${field}-${formatRomId(crc32(new TextEncoder().encode(english)))}`;
}

/**
 * An achievement with its title and description in the player's language,
 * where there is a translation of exactly the English it carries.
 */
export function localizeAchievement<T extends { id: number, title: string, description: string }>(achievement: T): T {
    return {
        ...achievement,
        title: nls.localize(achievementTextKey(achievement.id, 'title', achievement.title), achievement.title),
        description: nls.localize(
            achievementTextKey(achievement.id, 'description', achievement.description), achievement.description),
    };
}
