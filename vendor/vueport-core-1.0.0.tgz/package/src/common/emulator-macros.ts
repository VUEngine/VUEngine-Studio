/**
 * Macros: recorded button sequences, and the file they live in.
 *
 * A macro is what the controller did, written down — a list of moments and the
 * buttons held from each of them. Played back, the emulator holds those same
 * buttons at those same moments, so a sequence somebody worked out once (a
 * fighting game's combo, a level's opening, a code typed on the title screen)
 * can be repeated exactly, any number of times.
 *
 * Deliberately a list of *states* rather than of presses and releases. A press
 * without its release is a stuck button, and a release without its press does
 * nothing, so a format that can express either separately can express a macro
 * that is wrong. Here every entry says what is held from that moment until the
 * next one, which makes both impossible: playback is "find the last entry that
 * has happened and hold exactly that".
 *
 * Two invariants, established by `finishMacro` and relied on everywhere
 * else:
 *
 *   - the first entry is at 0, so a macro starts the moment it is played
 *     rather than after however long the person took to press anything;
 *   - the last entry holds nothing, and `duration` is its moment — so a macro
 *     always ends with its buttons released, and a looping one is simply
 *     `elapsed % duration`.
 *
 * Times are milliseconds of *emulated* running time: the clock that measures
 * them stops with the machine (see the macro store), so a recording is not
 * lengthened by the pause somebody took in the middle of it.
 *
 * Everything here is pure, so it can be reasoned about, and tested, without a
 * running emulator or a file system.
 */

/** One moment in a macro, and the buttons held from it. */
export interface MacroStep {
    /** Milliseconds from the start of the macro. */
    at: number;
    /**
     * The buttons held from this moment on, as a VbKey mask.
     *
     * The player's buttons only: the "controller present" bit and the low
     * battery signal are the machine's business and are folded in by whatever
     * pushes a mask into the core, not recorded here.
     */
    keys: number;
}

export interface Macro {
    name: string;
    steps: MacroStep[];
    /** How long it runs, in milliseconds, which is its last step's moment. */
    duration: number;
    /** Play it again from the top, until something stops it. */
    loop?: boolean;
    /**
     * Whether this macro belongs to every game rather than to one.
     *
     * Which file it is kept in, said on the object so the list can mark it —
     * not part of the recording, and so not written into either file: the file
     * a macro is in is what makes it global, and a flag saying otherwise could
     * only ever contradict it. `loop` is left out of the files for the same
     * reason and a different one; see `serializeMacroFile`.
     */
    global?: boolean;
}

/** What the file says it is, so a later format can be told from this one. */
export const MACRO_FILE_VERSION = 1;

/** A macro with nothing in it — what an empty recording finishes as. */
export function emptyMacro(name: string): Macro {
    return { name, steps: [], duration: 0 };
}

/** Whether there is anything to play: at least one step that holds a button. */
export function macroIsEmpty(macro: Macro): boolean {
    return macro.duration <= 0 || !macro.steps.some(step => step.keys !== 0);
}

/**
 * Turn a raw recording into a macro that satisfies both invariants above.
 *
 * `steps` are as they were observed, timed from when recording started;
 * `stoppedAt` is when it stopped, on the same clock. Leading dead time is cut
 * — the wait between pressing Record and pressing the first button belongs to
 * nobody — and a release is appended if the recording ended with something
 * still held, so playback can never leave a button down.
 */
export function finishMacro(name: string, steps: MacroStep[], stoppedAt: number): Macro {
    const first = steps.findIndex(step => step.keys !== 0);
    if (first === -1) {
        // Recorded, but nothing was pressed. An empty macro rather than a
        // pause of a particular length: there is nothing here to play.
        return emptyMacro(name);
    }

    const offset = steps[first].at;
    const shifted: MacroStep[] = [];
    for (const step of steps.slice(first)) {
        const at = Math.max(0, Math.round(step.at - offset));
        const previous = shifted[shifted.length - 1];
        if (previous && previous.keys === step.keys) {
            // Nothing changed — a gamepad reporting the same mask twice, or a
            // key repeating. Merging keeps the file honest about what happened.
            continue;
        }
        if (previous && previous.at === at) {
            // Two changes inside the same millisecond: only the later one was
            // ever actually held, so it replaces the other.
            previous.keys = step.keys;
            continue;
        }
        shifted.push({ at, keys: step.keys });
    }

    const last = shifted[shifted.length - 1];
    const end = Math.max(Math.round(stoppedAt - offset), last.at);
    if (last.keys !== 0) {
        shifted.push({ at: end, keys: 0 });
    }
    return { name, steps: shifted, duration: shifted[shifted.length - 1].at };
}

/**
 * The buttons a macro holds `elapsed` milliseconds in.
 *
 * A linear scan from the front, which is what playback wants anyway: it steps
 * forward a frame at a time and would gain nothing from a search. Past the end
 * nothing is held, which the closing step already says.
 */
export function macroKeysAt(macro: Macro, elapsed: number): number {
    let keys = 0;
    for (const step of macro.steps) {
        if (step.at > elapsed) {
            break;
        }
        keys = step.keys;
    }
    return keys;
}

/** Every button the macro ever holds, as one mask — for saying what it uses. */
export function macroKeysUsed(macro: Macro): number {
    return macro.steps.reduce((keys, step) => keys | step.keys, 0);
}

/**
 * The presses it makes, in order: what each step *adds* to what was already
 * held, as a mask per press.
 *
 * A press is a button going down, which is not the same as a step — releases
 * are not presses, and letting go of one of two buttons is not a new one. Two
 * buttons going down together are one press of two, which is why this is a
 * list of masks rather than of single buttons: a chord is a thing somebody did
 * once, and splitting it would read as two.
 *
 * This is the sequence a person would read out loud from watching the
 * recording, which is what the list shows under a macro's name.
 */
export function macroPresses(macro: Macro): number[] {
    const presses: number[] = [];
    let held = 0;
    for (const step of macro.steps) {
        const pressed = step.keys & ~held;
        if (pressed !== 0) {
            presses.push(pressed);
        }
        held = step.keys;
    }
    return presses;
}

/** How many presses it contains. */
export function macroPressCount(macro: Macro): number {
    return macroPresses(macro).length;
}

/** A duration, as short as it can be said: `0.4 s`, `12.5 s`, `1:03.2`. */
export function formatMacroDuration(milliseconds: number): string {
    const seconds = Math.max(0, milliseconds) / 1000;
    if (seconds < 60) {
        return `${seconds.toFixed(1)} s`;
    }
    const minutes = Math.floor(seconds / 60);
    const rest = seconds - minutes * 60;
    return `${minutes}:${rest.toFixed(1).padStart(4, '0')}`;
}

/**
 * Read the macros file beside a ROM.
 *
 * Lenient in the same way the cheat reader is, and for a weaker version of the
 * same reason: this format is the emulator's own, but a file can still be
 * hand-edited, truncated by a browser that ran out of quota, or left behind by
 * a future version. Anything that does not parse as a macro is dropped, and
 * the rest are kept — losing one macro beats losing the file.
 */
export function parseMacroFile(text: string): Macro[] {
    let parsed: unknown;
    try {
        parsed = JSON.parse(text);
    } catch {
        return [];
    }
    const macros = (parsed as { macros?: unknown })?.macros;
    if (!Array.isArray(macros)) {
        return [];
    }
    return macros
        .map(readMacro)
        .filter((macro): macro is Macro => macro !== undefined);
}

function readMacro(value: unknown): Macro | undefined {
    const raw = value as Partial<Macro> | undefined;
    if (!raw || typeof raw.name !== 'string' || !Array.isArray(raw.steps)) {
        return undefined;
    }
    const steps: MacroStep[] = [];
    for (const entry of raw.steps) {
        const step = entry as Partial<MacroStep>;
        if (typeof step?.at !== 'number' || typeof step?.keys !== 'number'
            || !Number.isFinite(step.at) || !Number.isFinite(step.keys)) {
            continue;
        }
        steps.push({ at: Math.max(0, Math.round(step.at)), keys: step.keys >>> 0 });
    }
    // Sorted rather than trusted: playback reads them in order, and a file
    // whose entries are out of order would otherwise hold the wrong buttons.
    steps.sort((a, b) => a.at - b.at);
    if (steps.length === 0) {
        return { name: raw.name, steps: [], duration: 0, ...loopOf(raw) };
    }
    // The closing release is the invariant the rest of this module rests on,
    // so it is restored rather than assumed — a file that lost it would
    // otherwise play a macro that never lets go.
    if (steps[steps.length - 1].keys !== 0) {
        steps.push({ at: steps[steps.length - 1].at, keys: 0 });
    }
    const declared = typeof raw.duration === 'number' && Number.isFinite(raw.duration)
        ? Math.round(raw.duration) : 0;
    return {
        name: raw.name,
        steps,
        duration: Math.max(declared, steps[steps.length - 1].at),
        ...loopOf(raw),
    };
}

function loopOf(raw: Partial<Macro>): { loop?: boolean } {
    return raw.loop ? { loop: true } : {};
}

export function serializeMacroFile(macros: ReadonlyArray<Macro>): string {
    // `loop` is a browser preference and `global` is which file this is, not
    // part of the recording a person made. Both are built out rather than
    // deleted, so a field added to a macro is never written by accident.
    const definitions = macros.map(macro => ({
        name: macro.name,
        steps: macro.steps,
        duration: macro.duration,
    }));
    return JSON.stringify({ version: MACRO_FILE_VERSION, macros: definitions }, undefined, 2) + '\n';
}
