/**
 * The device's Back (Android's button or gesture, a browser's back button) as a way back inside VUEPort rather than
 * off the page: from a settings pane to the list of panes, out of a sheet or a window, out of a game to the library.
 *
 * Whatever can be gone back from registers a handler; the most recent is the one Back runs. While there is any, one
 * extra entry sits on the page's history (the guard), so Back pops that instead of leaving, and the handler runs on
 * the popstate. Once nothing is left to go back from, the guard is taken off again, so the next Back leaves the page
 * as it would have. Opt-in (allowBackNavigation), as only the standalone build owns its page's history; the studio's
 * is Theia's.
 */

interface BackHandler {
    run: () => void;
}

const handlers: BackHandler[] = [];
let allowed = false;
// whether the guard entry is on the history right now
let guarded = false;
// a popstate this module caused itself, by taking the guard off, which must not run a handler
let unguarding = false;
let scheduled = false;

const GUARD_STATE = { vueportBack: true };

function sync(): void {
    scheduled = false;
    if (!allowed) {
        return;
    }
    if (handlers.length > 0 && !guarded && !unguarding) {
        history.pushState(GUARD_STATE, '');
        guarded = true;
    } else if (handlers.length === 0 && guarded && !unguarding) {
        unguarding = true;
        history.back();
    }
}

// after the current task, so a window replaced by another in one render (closing one, opening the next) neither
// takes the guard off nor puts a second one on
function schedule(): void {
    if (!scheduled) {
        scheduled = true;
        setTimeout(sync, 0);
    }
}

function onPopState(): void {
    if (unguarding) {
        unguarding = false;
        guarded = false;
        schedule();
        return;
    }
    if (!guarded) {
        return;
    }
    guarded = false;
    const top = handlers[handlers.length - 1];
    top?.run();
    // the handler usually takes itself away once React has rendered; whatever is left gets a fresh guard
    schedule();
}

// for the host that owns the page's history; once, at start-up
export function allowBackNavigation(): void {
    if (allowed || typeof window === 'undefined') {
        return;
    }
    allowed = true;
    window.addEventListener('popstate', onPopState);
    schedule();
}

/**
 * Registers what Back does while this is the most recent thing open, until the returned function takes it away. Taken
 * away by identity, as React unmounts in its own order and a handler above may go first
 */
export function pushBackHandler(run: () => void): () => void {
    const handler: BackHandler = { run };
    handlers.push(handler);
    schedule();
    return () => {
        const at = handlers.lastIndexOf(handler);
        if (at !== -1) {
            handlers.splice(at, 1);
            schedule();
        }
    };
}
