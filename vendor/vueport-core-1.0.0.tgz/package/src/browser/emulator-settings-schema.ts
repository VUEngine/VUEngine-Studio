import { nls } from '../common/emulator-nls';
import { VueportConfig } from '../common/emulator-settings';
import { VB_LEVELS } from '../common/vb-constants';
import { EMULATOR_SAVE_SLOTS } from '../common/emulator-sram';
import {
  emulationRenderingModeDescriptions,
  emulationRenderingModeNames,
  emulationRenderingModes,
  emulatorHardwareModeLabels,
  emulatorCompanionLocationLabels,
  emulatorDecorationDescriptions,
  emulatorDecorationLabels,
  emulatorResumeStartLabels,
  emulatorScaleOptions,
  emulatorSramInitLabels,
  emulatorSramWindowLabels,
  emulatorVideoFormatLabels,
  emulatorVideoQualityLabels,
} from './emulator-types';

/**
 * How each setting should be presented, for a host that builds a settings
 * screen from this rather than listing the controls by hand.
 *
 * Plain JSON Schema, which is what both hosts want: Theia's preference schema
 * takes it almost as-is (see `VesEmulatorPreferenceSchema`), and a standalone
 * settings window can switch on `type`.
 *
 * Here rather than in `common/` because the enum labels come from the display
 * tables, which are browser-side. The contract itself — `VueportConfig`, the
 * defaults, the ranges — has no such dependency and stays in `common/`.
 */
export interface VueportSettingSchema {
  type: 'string' | 'number' | 'integer' | 'boolean' | 'array';
  title: string;
  description?: string;
  enum?: string[];
  enumItemLabels?: string[];
  /**
   * What each choice does, one per `enum` entry.
   *
   * A setting's own `description` says what the setting is for; this says what
   * picking a given answer gets you, which a standalone window can show under
   * the control for whichever one is chosen rather than making somebody try
   * all of them. Optional: most settings' choices explain themselves.
   */
  enumItemDescriptions?: string[];
  /**
   * Each choice's name written out in full, one per `enum` entry, where the
   * control's own label is an abbreviation it has no room to expand — `HLI`
   * on a card, `Horizontal Line Interlaced` in the line beneath it. Optional,
   * and falls back to `enumItemLabels` per choice.
   */
  enumItemNames?: string[];
  items?: unknown;
  multipleOf?: number;
  minimum?: number;
  maximum?: number;
  /**
   * A presentational hint for a string setting. `color` asks for a color well
   * rather than a text field; the stored value is still a `#rrggbb` string.
   */
  format?: 'color';
}

let schema: Record<keyof VueportConfig, VueportSettingSchema> | undefined;

/**
 * The emulator's settings, described.
 *
 * Built on first use rather than at import, because the titles are localized
 * and the host installs its localization during start-up. Carries no default,
 * scope or preference id: what a setting *is* belongs here, where a host keeps
 * it belongs to the host — see `VUEPORT_DEFAULTS` and `VUEPORT_PREFERENCE_IDS`.
 */
export function vueportSettingsSchema(): Record<keyof VueportConfig, VueportSettingSchema> {
  return schema ??= {
    gamepadRumbleEnabled: {
      type: 'boolean',
      title: nls.localize('vueport/preferences/gamepadRumbleEnabledTitle', 'Game Pad Vibration'),
      description: nls.localize(
        'vueport/preferences/gamepadRumbleEnabledDescription',
        'Play a game\'s rumble effects on your controller when no Rumble Pack is connected. \
An approximation: the Rumble Pack\'s effects have lengths and shapes of their own that \
the protocol does not carry, so each one becomes a short pulse on the pad.'
      ),
    },
    vbcSupportEnabled: {
      type: 'boolean',
      title: nls.localize('vueport/preferences/vbcSupportEnabledTitle', 'VB Color Support'),
      description: nls.localize(
        'vueport/preferences/vbcSupportEnabledDescription',
        'Expose VB Color hardware and features. When disabled, VUEPort behaves as an original '
        + 'Virtual Boy regardless of the ROM header or Hardware Mode.'
      ),
    },
    vbcAutoApplyColorPatches: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/vbcAutoApplyColorPatchesTitle', 'Auto-Apply Color Patches'),
      description: nls.localize(
        'vueport/preferences/vbcAutoApplyColorPatchesDescription',
        'Automatically colorize games VUEPort ships a color patch for, by patching the ROM \
on the fly. A specific game\'s patch can be toggled from the Colors panel.'
      ),
    },
    hardwareMode: {
      type: 'string',
      title: nls.localize('vueport/preferences/hardwareModeTitle', 'Hardware Mode'),
      description: nls.localize(
        'vueport/preferences/hardwareModeDescription',
        'Which console VUEPort emulates. Auto selects VB Color for ROMs marked Enhanced (80) or '
        + 'VBC Only (C0), and original Virtual Boy otherwise.'
      ),
      enum: Object.keys(emulatorHardwareModeLabels()),
      enumItemLabels: Object.values(emulatorHardwareModeLabels()),
    },
    renderingMode: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInRenderingModeTitle',
        'Rendering Mode',
      ),
      description: nls.localize(
        'vueport/preferences/builtInRenderingModeDescription',
        'How the built-in emulator presents the two eyes. The colors each mode is shown in are configured separately.'
      ),
      enum: Object.keys(emulationRenderingModes()),
      enumItemLabels: Object.values(emulationRenderingModes()),
      enumItemDescriptions: Object.values(emulationRenderingModeDescriptions()),
      enumItemNames: Object.values(emulationRenderingModeNames()),
    },
    palette: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInPaletteTitle',
        'Color Palette',
      ),
      description: nls.localize(
        'vueport/preferences/builtInPaletteDescription',
        'Colors the built-in emulator shows the four display brightness levels in, in every rendering mode but Anaglyph. '
        + 'Can be one of the built-in palettes or, as "custom:<name>", one defined in Custom Color Palettes.'
      ),
    },
    anaglyphPalette: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInAnaglyphPaletteTitle',
        'Anaglyph Colors',
      ),
      description: nls.localize(
        'vueport/preferences/builtInAnaglyphPaletteDescription',
        'Tints the built-in emulator assigns to the eyes in the Anaglyph rendering mode. Pick the pair your glasses filter. '
        + 'Can be one of the built-in pairs or, as "custom:<name>", one defined in Custom Anaglyph Colors.'
      ),
    },
    customPalettes: {
      type: 'array',
      title: nls.localize(
        'vueport/preferences/builtInCustomPalettesTitle',
        'Custom Color Palettes'
      ),
      description: nls.localize(
        'vueport/preferences/builtInCustomPalettesDescription',
        'User-defined palettes, offered alongside the built-in ones.'
      ),
      items: {
        type: 'object',
        title: 'Custom color palette',
        properties: {
          name: {
            type: 'string',
            description: 'Name of the palette.',
            title: 'Name',
          },
          colors: {
            type: 'array',
            description: "The display's four brightness levels, from unlit to fully lit, as #rrggbb.",
            title: 'Colors',
            items: {
              type: 'string',
            },
            minItems: VB_LEVELS,
            maxItems: VB_LEVELS,
          },
        },
      },
    },
    customAnaglyphPalettes: {
      type: 'array',
      title: nls.localize(
        'vueport/preferences/builtInCustomAnaglyphPalettesTitle',
        'Custom Anaglyph Colors'
      ),
      description: nls.localize(
        'vueport/preferences/builtInCustomAnaglyphPalettesDescription',
        'User-defined anaglyph colors and optional Dubois calibrations, offered alongside the built-in ones.'
      ),
      items: {
        type: 'object',
        title: 'Custom anaglyph colors',
        properties: {
          name: {
            type: 'string',
            description: 'Name of the color pair.',
            title: 'Name',
          },
          left: {
            type: 'string',
            description: 'Tint of the left eye, as #rrggbb.',
            title: 'Left',
          },
          right: {
            type: 'string',
            description: 'Tint of the right eye, as #rrggbb.',
            title: 'Right',
          },
          duboisProfile: {
            type: 'string',
            description: 'RGB channel filters, a built-in Dubois profile, or a custom calibration.',
            title: 'Dubois profile',
            enum: ['none', 'red-cyan', 'green-magenta', 'amber-blue', 'custom'],
          },
          duboisMatrices: {
            type: 'object',
            description: 'Column-major 3x3 transforms for the left and right images.',
            title: 'Custom Dubois matrices',
            properties: {
              left: {
                type: 'array',
                items: { type: 'number' },
                minItems: 9,
                maxItems: 9,
              },
              right: {
                type: 'array',
                items: { type: 'number' },
                minItems: 9,
                maxItems: 9,
              },
            },
          },
        },
      },
    },
    scale: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInScalingModeTitle',
        'Scale'
      ),
      description: nls.localize(
        'vueport/preferences/builtInScalingModeDescription',
        'Scaling mode of built-in emulator.'
      ),
      enum: emulatorScaleOptions().map(option => option.value),
      enumItemLabels: emulatorScaleOptions().map(option => option.label),
      enumItemDescriptions: emulatorScaleOptions().map(option => option.description),
    },
    decoration: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/decorationTitle',
        'Screen Decoration',
      ),
      // No longer an inventory of the four: each one says what it does under
      // the control once it is picked — see `emulatorDecorationDescriptions`.
      description: nls.localize(
        'vueport/preferences/decorationDescription',
        'What fills the view around the picture while playing.'
      ),
      enum: Object.keys(emulatorDecorationLabels()),
      enumItemLabels: Object.values(emulatorDecorationLabels()),
      enumItemDescriptions: Object.values(emulatorDecorationDescriptions()),
    },
    decorationColor: {
      type: 'string',
      format: 'color',
      title: nls.localize(
        'vueport/preferences/decorationColorTitle',
        'Decoration Color',
      ),
      description: nls.localize(
        'vueport/preferences/decorationColorDescription',
        'The color of the halo cast by the Ambient decoration.'
      ),
    },
    decorationColorFromPalette: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/decorationColorFromPaletteTitle',
        'Decoration Color From Palette',
      ),
      description: nls.localize(
        'vueport/preferences/decorationColorFromPaletteDescription',
        "Take the Ambient halo's color from the current color palette's fully-lit level instead of "
        + 'Decoration Color. A theme-appropriate neutral color is used in Anaglyph and on VB Color '
        + 'hardware, where there is no one palette color to take it from.'
      ),
    },
    decorationIntensity: {
      type: 'number',
      title: nls.localize(
        'vueport/preferences/decorationIntensityTitle',
        'Decoration Intensity',
      ),
      description: nls.localize(
        'vueport/preferences/decorationIntensityDescription',
        'Strength of the Ambient and Immersion halos.'
      ),
      minimum: 0,
      maximum: 100,
    },
    screenshotUseDisplaySettings: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/screenshotUseDisplayTitle',
        'Same Display Settings as Emulator',
      ),
      description: nls.localize(
        'vueport/preferences/screenshotUseDisplayDescription',
        'Use the current emulator display settings for screenshots.'
      ),
    },
    screenshotRenderingMode: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInRenderingModeTitle',
        'Rendering Mode',
      ),
      description: nls.localize(
        'vueport/preferences/screenshotRenderingModeDescription',
        'How a screenshot presents the two eyes.'
      ),
      enum: Object.keys(emulationRenderingModes()),
      enumItemLabels: Object.values(emulationRenderingModes()),
      enumItemDescriptions: Object.values(emulationRenderingModeDescriptions()),
      enumItemNames: Object.values(emulationRenderingModeNames()),
    },
    screenshotScale: {
      type: 'integer',
      title: nls.localize(
        'vueport/preferences/screenshotScaleTitle',
        'Scale',
      ),
      description: nls.localize(
        'vueport/preferences/screenshotScaleDescription',
        'How many times the mode\'s own size a screenshot is written at.'
      ),
      minimum: 1,
      maximum: 8,
    },
    videoUseDisplaySettings: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/videoUseDisplayTitle',
        'Same Display Settings as Emulator',
      ),
      description: nls.localize(
        'vueport/preferences/videoUseDisplayDescription',
        'Use the current emulator display settings for video recordings.'
      ),
    },
    videoRenderingMode: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/builtInRenderingModeTitle',
        'Rendering Mode',
      ),
      description: nls.localize(
        'vueport/preferences/videoRenderingModeDescription',
        'How a video recording presents the two eyes.'
      ),
      enum: Object.keys(emulationRenderingModes()),
      enumItemLabels: Object.values(emulationRenderingModes()),
      enumItemDescriptions: Object.values(emulationRenderingModeDescriptions()),
      enumItemNames: Object.values(emulationRenderingModeNames()),
    },
    videoScale: {
      type: 'integer',
      title: nls.localize(
        'vueport/preferences/videoScaleTitle',
        'Scale',
      ),
      description: nls.localize(
        'vueport/preferences/videoScaleDescription',
        'How many times the mode\'s own size a video is recorded at.'
      ),
      minimum: 1,
      maximum: 8,
    },
    videoQuality: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/videoQualityTitle',
        'Quality',
      ),
      description: nls.localize(
        'vueport/preferences/videoQualityDescription',
        'How many bits a second the recorded picture is given. The sound is unaffected.'
      ),
      enum: Object.keys(emulatorVideoQualityLabels()),
      enumItemLabels: Object.values(emulatorVideoQualityLabels()),
    },
    videoFormat: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/videoFormatTitle',
        'File Format',
      ),
      description: nls.localize(
        'vueport/preferences/videoFormatDescription',
        'Target file format for new video recordings. Available formats depend on OS/browser.'
      ),
      enum: Object.keys(emulatorVideoFormatLabels()),
      enumItemLabels: Object.values(emulatorVideoFormatLabels()),
    },
    sramInit: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/sramInitTitle',
        'New Save File Contents'
      ),
      description: nls.localize(
        'vueport/preferences/sramInitDescription',
        'What a save file is filled with before a game has written to it.'
      ),
      enum: Object.keys(emulatorSramInitLabels()),
      enumItemLabels: Object.values(emulatorSramInitLabels()),
    },
    sramWindow: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/sramWindowTitle',
        'Cartridge Save Size'
      ),
      description: nls.localize(
        'vueport/preferences/sramWindowDescription',
        'How much save RAM a cartridge answers on. Full is the whole of Game Pak RAM, '
        + 'which no game can run out of; a fixed size mirrors above itself the way real '
        + 'hardware does, which is what a game detecting its own save size would see. '
        + 'Save files are trimmed to what a game writes either way.'
      ),
      enum: Object.keys(emulatorSramWindowLabels()),
      enumItemLabels: Object.values(emulatorSramWindowLabels()),
    },
    saveGameSlot: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/saveGameSlotTitle',
        'Save Game Slot'
      ),
      description: nls.localize(
        'vueport/preferences/saveGameSlotDescription',
        'Which save file a game plays on. A slot represents a whole cartridge save.'
      ),
      enum: [...EMULATOR_SAVE_SLOTS],
      enumItemLabels: EMULATOR_SAVE_SLOTS.map(slot => nls.localize(
        'vueport/preferences/saveGameSlotItem', 'Slot {0}', slot)),
    },
    autoSaveStatesEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/autoSaveStatesEnabledTitle',
        'Automatic Save States'
      ),
      description: nls.localize(
        'vueport/preferences/autoSaveStatesEnabledDescription',
        'Take a save state every so often while a game runs, and keep the last few of them.'
      ),
    },
    autoSaveStateInterval: {
      type: 'integer',
      title: nls.localize(
        'vueport/preferences/autoSaveStateIntervalTitle',
        'Automatic Save State Interval'
      ),
      description: nls.localize(
        'vueport/preferences/autoSaveStateIntervalDescription',
        'Seconds of play between automatic save states. Time spent paused does not count.'
      ),
      minimum: 10,
      maximum: 900,
    },
    autoSaveStateCount: {
      type: 'integer',
      title: nls.localize(
        'vueport/preferences/autoSaveStateCountTitle',
        'Automatic Save States Kept'
      ),
      description: nls.localize(
        'vueport/preferences/autoSaveStateCountDescription',
        'How many automatic save states to keep per game.'
      ),
      minimum: 1,
      maximum: 20,
    },
    suspendResumeEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/suspendResumeEnabledTitle',
        'Suspend and Resume'
      ),
      description: nls.localize(
        'vueport/preferences/suspendResumeEnabledDescription',
        'Save the running game when you close it, or close VUEPort, and offer to pick it up where \
you left off the next time you open it.'
      ),
    },
    suspendResumeStart: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/suspendResumeStartTitle',
        'Opening a Suspended Game'
      ),
      description: nls.localize(
        'vueport/preferences/suspendResumeStartDescription',
        'How VUEPort should behave when opening a game that has a S&R state.'
      ),
      enum: Object.keys(emulatorResumeStartLabels()),
      enumItemLabels: Object.values(emulatorResumeStartLabels()),
    },
    companionFiles: {
      type: 'string',
      title: nls.localize(
        'vueport/preferences/companionFilesTitle',
        'Storage Location'
      ),
      description: nls.localize(
        'vueport/preferences/companionFilesDescription',
        'Where a ROM\'s companion files like saves, save states or cheats are written.'
      ),
      enum: Object.keys(emulatorCompanionLocationLabels()),
      enumItemLabels: Object.values(emulatorCompanionLocationLabels()),
    },
    player2SameControls: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/player2SameControlsTitle',
        'Player 2 Uses Player 1 Controls'
      ),
      description: nls.localize(
        'vueport/preferences/player2SameControlsDescription',
        'Whether the second emulator of a link session answers to the same keys as the first. \
Turn this off to map a separate set of keys for player 2.'
      ),
    },
    rewindEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/builtInEnableRewindTitle',
        'Enable Rewind'
      ),
      description: nls.localize(
        'vueport/preferences/builtInEnableRewindDescription',
        'Enable rewinding the emulator. Will cause a performance hit when playing.'
      ),
    },
    rewindGranularity: {
      type: 'number',
      title: nls.localize(
        'vueport/preferences/builtInRewindGranularityTitle',
        'Rewind Granularity'
      ),
      description: nls.localize(
        'vueport/preferences/builtInRewindGranularityDescription',
        'Defines how many frames per step the rewind function should go back at a time. '
        + 'Higher values cover more time with the same amount of memory, at a coarser resolution.'
      ),
      multipleOf: 1,
      minimum: 1,
      maximum: 32,
    },
    rewindBufferSize: {
      type: 'number',
      title: nls.localize(
        'vueport/preferences/builtInRewindBufferSizeTitle',
        'Rewind Buffer Size'
      ),
      description: nls.localize(
        'vueport/preferences/builtInRewindBufferSizeDescription',
        'Maximum memory in MB the rewind history may use. Only what changes between steps is '
        + 'stored, which measures at around 16 KB per step, so the default holds roughly 80 '
        + 'seconds at a granularity of 1 and proportionally longer above that.'
      ),
      multipleOf: 1,
      minimum: 8,
      maximum: 1024,
    },
    slowMotionRatio: {
      type: 'number',
      title: nls.localize(
        'vueport/preferences/builtInSlowMotionRatioTitle',
        'Slow Motion Ratio'
      ),
      description: nls.localize(
        'vueport/preferences/builtInSlowMotionRatioDescription',
        'When using slow motion, content will slow down by this factor. High values might render the emulator unresponsive.'
      ),
      multipleOf: 0.5,
      minimum: 1.0,
      maximum: 32.0,
    },
    fastForwardRatio: {
      type: 'number',
      title: nls.localize(
        'vueport/preferences/builtInFastForwardRatioTitle',
        'Fast Forward Ratio'
      ),
      description: nls.localize(
        'vueport/preferences/builtInFastForwardRatioDescription',
        'The rate at which content will be run when using fast forward.'
      ),
      multipleOf: 0.5,
      minimum: 1.0,
      maximum: 32.0,
    },
    retroAchievementsEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/retroAchievementsEnabledTitle',
        'RetroAchievements'
      ),
      description: nls.localize(
        'vueport/preferences/retroAchievementsEnabledDescription',
        'Connect to RetroAchievements while playing, so a game that has an achievement set tracks \
your progress through it and unlocks achievements as you earn them. Needs an account, which is \
entered on the Achievements settings page.'
      ),
    },
    retroAchievementsHardcore: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/retroAchievementsHardcoreTitle',
        'RetroAchievements Hardcore Mode'
      ),
      description: nls.localize(
        'vueport/preferences/retroAchievementsHardcoreDescription',
        'Play for hardcore achievements: cheats, macros, patches, save-state loading, rewind and Debug mode \
are disabled while this is on. Turning it on restarts the ROM. Hardcore unlocks can not be credited \
until RetroAchievements approves the VUEPort client, but the restrictions apply now.'
      ),
    },
    errorSoundEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/errorSoundEnabledTitle',
        'Error Sound'
      ),
      description: nls.localize(
        'vueport/preferences/errorSoundEnabledDescription',
        'Play a short sound cue alongside an error notification.'
      ),
    },
    achievementSoundEnabled: {
      type: 'boolean',
      title: nls.localize(
        'vueport/preferences/achievementSoundEnabledTitle',
        'Achievement Sound'
      ),
      description: nls.localize(
        'vueport/preferences/achievementSoundEnabledDescription',
        'Play a short sound cue when an achievement is earned, alongside its toast.'
      ),
    },
  } as Record<keyof VueportConfig, VueportSettingSchema>;
}
