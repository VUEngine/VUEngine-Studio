import { originDrawnBy, VbCellArea, VbCharacterSpan, VbPixelSource } from '../../common/vb-pixel-origin';
import { VesScreenRect } from '../panels/emulator-screen-panel';
import { ancestryOf, isSubclassOf } from './emulator-classes';
import { readStructFields, VesFieldValue, VesStruct } from './emulator-dwarf';
import {
    BLOCK_HEADER_BYTES,
    parseMemoryPoolLayout,
    readMemoryPoolBlocks,
    symbolsMatchRunningBuild,
    VesMemoryPoolBlock,
    VesMemoryPoolLayout,
} from './emulator-memory-pool';
import { findSymbolAt, structNameOf, SymbolIndex } from './emulator-symbols';
import { Sim } from './vb-core';

/**
 * Every actor a VUEngine game has alive, read out of its memory pools.
 *
 * Actors live in the same pools everything else does — so the engine has no
 * list of them, only blocks that happen to hold one. Finding them means three
 * things the build already knows: which blocks are occupied, which class each
 * occupant is (its vTable pointer), and whether that class descends from
 * `Actor` (the chain of `getBaseClass` stubs). A project's own `PlayerRacer` is
 * therefore found the same way the engine's own classes are, without knowing
 * anything about it.
 *
 * Shared by the Actors panel, which lists them, and the screen inspector,
 * which finds the one that drew a pixel.
 */

/** The class every actor descends from, whatever the project calls its own. */
const ACTOR_CLASS = 'Actor';

/** Fields read into columns of their own, looked up by DWARF path. */
const NAME_FIELD = 'name';
const ID_FIELD = 'internalId';
const POSITION_FIELDS = ['transformation.position.x', 'transformation.position.y', 'transformation.position.z'];
const HIDDEN_FIELD = 'hidden';
const SPEC_FIELD = 'actorSpec';
/** `Container::parent`: the stage, or the actor this one was spawned as a child of. */
const PARENT_FIELD = 'parent';

/** The class every component descends from, and the ones that draw. */
const COMPONENT_CLASS = 'Component';
const SPRITE_CLASS = 'Sprite';
const BGMAP_SPRITE_CLASS = 'BgmapSprite';
const OBJECT_SPRITE_CLASS = 'ObjectSprite';
/** Where a component records the entity it is attached to. */
const OWNER_FIELD = 'owner';
/** The engine's set of characters, which older versions call a char set. */
const TILE_SET_CLASSES = ['TileSet', 'CharSet'];
/** The characters there are, past the last set: the VIP's own, before VB Color's. */
const CHARACTERS = 2048;

/**
 * The fields a sprite's on-screen rectangle is made of.
 *
 * `BgmapSprite::doRender` builds the world it hands the VIP out of exactly
 * these — `gx = position.x + displacement.x - halfWidth`, and the width is
 * `halfWidth << 1` — so reading them back gives the rectangle the engine
 * itself drew, with no projection to redo.
 */
const SPRITE_RECT_FIELDS = {
    x: 'position.x',
    y: 'position.y',
    parallax: 'position.parallax',
    displacementX: 'displacement.x',
    displacementY: 'displacement.y',
    displacementParallax: 'displacement.parallax',
    halfWidth: 'halfWidth',
    halfHeight: 'halfHeight',
};

/** Why there are no actors to show, when there are none. */
export enum VesActorsStatus {
    OK = 'ok',
    NO_SYMBOLS = 'noSymbols',
    NO_LAYOUTS = 'noLayouts',
    NOT_INITIALIZED = 'notInitialized',
    STALE_SYMBOLS = 'staleSymbols',
}

/** One component attached to an actor. */
export interface VesActorComponent {
    address: number;
    className: string;
    /** Set for a sprite: where the engine last drew it. */
    rect?: VesScreenRect;
    /** Sprites only: whether it is being shown and was rendered. */
    shown?: boolean;
    /** Sprites only: the DRAM block it configures, or -1 when unassigned. */
    index?: number;
    /** The worlds it is drawn into: a BG map sprite's one, while it has one. */
    worlds: number[];
    /** The objects it is drawn with: an object sprite's run of them. */
    objects: number[];
    /**
     * Where its picture is kept: a BG map sprite's texture cells, an object
     * sprite's characters. What it is told by on the picture, since unlike
     * its world or objects these stay its own from one frame to the next.
     */
    cells?: VbCellArea;
    characters?: VbCharacterSpan;
}

/** One live actor, as read out of the block it occupies. */
export interface VesActor {
    objectAddress: number;
    blockAddress: number;
    blockSize: number;
    className: string;
    /** The class this was read as, which is a base when the exact one is unknown. */
    readAs: string;
    /** The class and everything above it, for saying what it is. */
    ancestry: string[];
    components: VesActorComponent[];
    fields: VesFieldValue[];
    namePointer?: number;
    /** The spec it was built from, as the project named it. */
    spec?: string;
    /** Where in that spec the pointer landed, which is normally its start. */
    specOffset?: number;
    specAddress?: number;
    internalId?: number;
    hidden?: boolean;
    position: (number | undefined)[];
    /** The container it is a child of, or 0 for none. */
    parent: number;
}

export interface VesActorsRead {
    status: VesActorsStatus;
    actors: VesActor[];
    /**
     * The class of every object in the pools, by address — what names a
     * parent that is not an actor, which the stage never is.
     */
    classes: Map<number, string>;
}

/**
 * What to call a spec, from the symbol the linker recorded.
 *
 * The ABI's leading underscore goes, and so does the generated suffix that is
 * on every one of them — `_PlayerRacerActorSpec` is the project's `PlayerRacer`.
 * A name that is nothing but the suffix keeps it, since an empty column would
 * say less than an ugly one.
 */
export function specDisplayName(symbol: string): string {
    const trimmed = symbol.replace(/^_/, '');
    const shortened = trimmed.replace(/ActorSpec$/, '').replace(/Spec$/, '');
    return shortened === '' ? trimmed : shortened;
}

/** Read the actors out of the machine's pools, or say why there are none to read. */
export async function readActors(sim: Sim, symbols: SymbolIndex | undefined): Promise<VesActorsRead> {
    const none = (status: VesActorsStatus): VesActorsRead => ({ status, actors: [], classes: new Map() });
    if (!symbols?.memoryPool) {
        return none(VesActorsStatus.NO_SYMBOLS);
    }
    if (symbols.structs.size === 0) {
        // Without the debug sections there are no field offsets, and an
        // actor is only an address — not worth a list.
        return none(VesActorsStatus.NO_LAYOUTS);
    }

    const region = new Uint8Array(await sim.readMemory(symbols.memoryPool.address, symbols.memoryPool.size));
    const layout = parseMemoryPoolLayout(symbols.memoryPool.address, region);
    if (!layout) {
        return none(VesActorsStatus.NOT_INITIALIZED);
    }
    if (!symbolsMatchRunningBuild(layout, symbols.vTables)) {
        // Every part of this rests on the symbols describing the ROM in the
        // machine: which class a vTable is, where its fields are. From
        // another build they would all be wrong together.
        return none(VesActorsStatus.STALE_SYMBOLS);
    }

    const blocks = readMemoryPoolBlocks(layout, region);
    const classes = new Map<number, string>();
    for (const block of blocks) {
        const className = symbols.vTables.get(block.vTable);
        if (className !== undefined) {
            classes.set(block.objectAddress, className);
        }
    }
    const context: ReadContext = { symbols, region, layout, classes, tileSets: [] };
    context.tileSets = tileSetOffsets(context, blocks);
    const actors = collect(context, blocks);
    markShared(actors);
    return { status: VesActorsStatus.OK, actors, classes };
}

/** What reading one object out of the pools takes. */
interface ReadContext {
    symbols: SymbolIndex;
    region: Uint8Array;
    layout: VesMemoryPoolLayout;
    /** The class of every object in the pools, by address. */
    classes: Map<number, string>;
    /** Where every set of characters starts, in order; see {@link tileSetOffsets}. */
    tileSets: number[];
}

/** The fields of the object at an address in the pools, read by its own class' layout, or none. */
function readObject(context: ReadContext, address: number | undefined): VesFieldValue[] | undefined {
    if (address === undefined || address === 0) {
        return undefined;
    }
    const className = context.classes.get(address >>> 0);
    const block = blockSizeAt(context.layout, address >>> 0);
    if (className === undefined || block === undefined) {
        return undefined;
    }
    const struct = layoutFor(context.symbols, className, block - BLOCK_HEADER_BYTES);
    return struct && readStructFields(struct, context.region, (address >>> 0) - context.layout.base);
}

function fieldOf(fields: VesFieldValue[] | undefined, path: string): number | undefined {
    return fields?.find(field => field.path === path)?.value;
}

/**
 * Where each set of characters starts in character memory, in order.
 *
 * A set's length is in its spec, in ROM; but the engine hands out character
 * memory in one run and packs it as sets come and go, so a set ends where the
 * next one begins — which the pools already say.
 */
function tileSetOffsets(context: ReadContext, blocks: VesMemoryPoolBlock[]): number[] {
    const offsets = new Set<number>();
    for (const block of blocks) {
        const className = context.classes.get(block.objectAddress);
        if (className === undefined
            || !TILE_SET_CLASSES.some(base => isSubclassOf(context.symbols.classes, className, base))) {
            continue;
        }
        const offset = fieldOf(readObject(context, block.objectAddress), 'offset');
        if (offset !== undefined) {
            offsets.add(offset);
        }
    }
    return [...offsets].sort((a, b) => a - b);
}

/**
 * Mark the cells and characters more than one actor draws from — a level's
 * coins, sharing one set of characters — with where each actor's sprite is,
 * which is then what tells their pixels apart.
 */
function markShared(actors: VesActor[]): void {
    const owners = (key: string, actor: VesActor, counts: Map<string, Set<VesActor>>): void => {
        counts.set(key, (counts.get(key) ?? new Set()).add(actor));
    };
    const cells = new Map<string, Set<VesActor>>();
    const characters = new Map<string, Set<VesActor>>();
    const cellKey = (area: VbCellArea): string => `${area.segment}:${area.x}:${area.y}`;
    const characterKey = (span: VbCharacterSpan): string => `${span.from}`;
    for (const actor of actors) {
        for (const component of actor.components) {
            if (component.cells) {
                owners(cellKey(component.cells), actor, cells);
            }
            if (component.characters) {
                owners(characterKey(component.characters), actor, characters);
            }
        }
    }
    for (const actor of actors) {
        for (const component of actor.components) {
            if (component.cells && (cells.get(cellKey(component.cells))?.size ?? 0) > 1) {
                component.cells.near = component.rect;
            }
            if (component.characters && (characters.get(characterKey(component.characters))?.size ?? 0) > 1) {
                component.characters.near = component.rect;
            }
        }
    }
}

/** Turn the occupied blocks into the ones that hold actors. */
function collect(context: ReadContext, blocks: VesMemoryPoolBlock[]): VesActor[] {
    const { symbols, region } = context;
    const components = groupComponents(context, blocks);
    const actors: VesActor[] = [];
    for (const block of blocks) {
        const className = symbols.vTables.get(block.vTable);
        if (className === undefined || !isSubclassOf(symbols.classes, className, ACTOR_CLASS)) {
            continue;
        }

        // The engine allocated a block big enough for the real class, so a
        // layout that does not fit one cannot be the right layout.
        const struct = layoutFor(symbols, className, block.blockSize - BLOCK_HEADER_BYTES, ACTOR_CLASS);
        if (!struct) {
            continue;
        }
        const fields = readStructFields(struct, region, block.objectOffset);
        const valueOf = (path: string): number | undefined =>
            fields.find(entry => entry.path === path)?.value;

        actors.push({
            objectAddress: block.objectAddress,
            blockAddress: block.address,
            blockSize: block.blockSize,
            className,
            readAs: struct.name.replace(/_str$/, ''),
            ancestry: ancestryOf(symbols.classes, className),
            components: components.get(block.objectAddress) ?? [],
            fields,
            namePointer: valueOf(NAME_FIELD),
            ...specOf(symbols, valueOf(SPEC_FIELD)),
            internalId: valueOf(ID_FIELD),
            hidden: valueOf(HIDDEN_FIELD) !== 0,
            position: POSITION_FIELDS.map(valueOf),
            parent: (valueOf(PARENT_FIELD) ?? 0) >>> 0,
        });
    }
    return actors;
}

/** Where a named member sits in a struct, or undefined if it has none. */
function memberOffset(struct: VesStruct, name: string): number | undefined {
    return struct.members.find(member => member.name === name)?.offset;
}

/** The block size of the pool an address falls in, if it falls in one. */
function blockSizeAt(layout: VesMemoryPoolLayout, address: number): number | undefined {
    for (const pool of layout.pools) {
        if (address >= pool.address && address < pool.address + pool.poolSize) {
            return pool.blockSize;
        }
    }
    return undefined;
}

/**
 * Every live component, grouped by the actor it belongs to.
 *
 * Components are pool allocations like everything else, and each one records
 * its `owner`, so the blocks already read contain all of them and the grouping
 * is a scan rather than a traversal. This deliberately does not go through
 * `Entity::components`: that array is a cache the engine fills the first time
 * the game asks for a type, so it is NULL on most actors and complete on
 * almost none.
 */
function groupComponents(context: ReadContext, blocks: VesMemoryPoolBlock[]): Map<number, VesActorComponent[]> {
    const { symbols, region } = context;
    const grouped = new Map<number, VesActorComponent[]>();
    const component = symbols.structs.get(structNameOf(COMPONENT_CLASS));
    const ownerAt = component && memberOffset(component, OWNER_FIELD);
    if (ownerAt === undefined) {
        return grouped;
    }
    const view = new DataView(region.buffer, region.byteOffset, region.byteLength);

    for (const block of blocks) {
        const className = symbols.vTables.get(block.vTable);
        if (className === undefined || !isSubclassOf(symbols.classes, className, COMPONENT_CLASS)) {
            continue;
        }
        const at = block.objectOffset + ownerAt;
        if (at < 0 || at + 4 > region.byteLength) {
            continue;
        }
        // Inherited fields sit at the same offset in every subclass, so one
        // lookup on Component reads the owner of any of them.
        const owner = view.getUint32(at, true) >>> 0;
        if (owner === 0) {
            continue;
        }
        const entries = grouped.get(owner) ?? [];
        entries.push(readComponent(context, block.objectAddress, className));
        grouped.set(owner, entries);
    }
    return grouped;
}

/** One component, with its rectangle and its worlds or objects when it is something that draws. */
function readComponent(context: ReadContext, address: number, className: string): VesActorComponent {
    const { symbols, region, layout } = context;
    const entry: VesActorComponent = { address, className, worlds: [], objects: [] };
    if (!isSubclassOf(symbols.classes, className, SPRITE_CLASS)) {
        return entry;
    }

    const block = blockSizeAt(layout, address);
    const struct = block === undefined
        ? undefined
        : layoutFor(symbols, className, block - BLOCK_HEADER_BYTES, SPRITE_CLASS);
    if (!struct) {
        return entry;
    }

    const fields = readStructFields(struct, region, address - layout.base);
    const valueOf = (path: string): number | undefined => fields.find(f => f.path === path)?.value;
    const halfWidth = valueOf(SPRITE_RECT_FIELDS.halfWidth) ?? 0;
    const halfHeight = valueOf(SPRITE_RECT_FIELDS.halfHeight) ?? 0;

    entry.shown = (valueOf('show') ?? 0) !== 0;
    entry.index = valueOf('index');
    if (halfWidth > 0 && halfHeight > 0) {
        entry.rect = {
            x: (valueOf(SPRITE_RECT_FIELDS.x) ?? 0) + (valueOf(SPRITE_RECT_FIELDS.displacementX) ?? 0) - halfWidth,
            y: (valueOf(SPRITE_RECT_FIELDS.y) ?? 0) + (valueOf(SPRITE_RECT_FIELDS.displacementY) ?? 0) - halfHeight,
            width: halfWidth * 2,
            height: halfHeight * 2,
            parallax: (valueOf(SPRITE_RECT_FIELDS.parallax) ?? 0)
                + (valueOf(SPRITE_RECT_FIELDS.displacementParallax) ?? 0),
        };
    }

    // Where the picture is kept, from the texture: a BG map texture's block
    // of cells, sized as the sprite is drawn, or the set of characters an
    // object texture's objects use.
    const isBgmap = isSubclassOf(symbols.classes, className, BGMAP_SPRITE_CLASS);
    const isObject = isSubclassOf(symbols.classes, className, OBJECT_SPRITE_CLASS);
    const texture = readObject(context, valueOf('texture'));
    if (isBgmap) {
        const segment = fieldOf(texture, 'segment');
        const x = fieldOf(texture, 'xOffset');
        const y = fieldOf(texture, 'yOffset');
        if (segment !== undefined && segment >= 0 && x !== undefined && y !== undefined && halfWidth > 0 && halfHeight > 0) {
            entry.cells = { segment, x, y, cols: Math.ceil(halfWidth / 4), rows: Math.ceil(halfHeight / 4) };
        }
    } else if (isObject) {
        const tileSet = readObject(context, fieldOf(texture, 'tileSet') ?? fieldOf(texture, 'charSet'));
        const from = fieldOf(tileSet, 'offset');
        if (from !== undefined) {
            const to = context.tileSets.find(offset => offset > from) ?? CHARACTERS;
            entry.characters = { from, to };
        }
    }

    // Otherwise the slot it was last rendered into: `index`, -1 for none,
    // in the hardware's own numbering, since the engine's world and object
    // caches are copied to the VIP one for one. A BG map sprite has a world
    // of its own; an object sprite writes its tiles downwards from `index`,
    // one object per cell of its `rows` by `cols` frame. Good only for the
    // frame it was read in: the engine may hand them out again on the next.
    const index = entry.index;
    if (index !== undefined && index >= 0) {
        if (isBgmap && !entry.cells) {
            entry.worlds = [index];
        } else if (isObject && !entry.characters) {
            const count = Math.max(1, (valueOf('rows') ?? 1) * (valueOf('cols') ?? 1));
            for (let object = index; object > index - count && object >= 0; object--) {
                entry.objects.push(object);
            }
        }
    }
    return entry;
}

/**
 * Which spec an actor was built from.
 *
 * `Actor::constructor` keeps the spec it was configured with, and a spec is a
 * global the project wrote — `_PlayerRacerActorSpec` and 878 others in a real
 * game — so the pointer names it. That is worth more than anything else on an
 * actor for telling one from another: the engine's own `name` field is
 * optional and usually NULL, while every actor built from a spec has one of
 * these.
 */
function specOf(
    index: SymbolIndex, pointer: number | undefined
): { spec?: string, specOffset?: number, specAddress?: number } {
    if (pointer === undefined || pointer === 0) {
        return {};
    }
    // A spec built at runtime, in a block of its own, would otherwise be
    // named after the one symbol around the whole heap.
    const pool = index.memoryPool;
    const inPool = pool !== undefined && pointer >= pool.address && pointer < pool.address + pool.size;
    const found = inPool ? undefined : findSymbolAt(index, pointer);
    if (!found) {
        // A spec built at runtime rather than written as a global; the
        // address is still worth keeping, since it is what tells two of them
        // apart.
        return { specAddress: pointer };
    }
    return { spec: specDisplayName(found.symbol.name), specOffset: found.offset, specAddress: pointer };
}

/**
 * The layout to read an object by: its own class', or the nearest ancestor the
 * build described that fits in the block, no further up than `floor` if given.
 *
 * Two things send this up the chain. A class whose struct the debug sections
 * do not carry — one the compiler never had to lay out — still has everything
 * its base has at the same offsets, because the class macro puts inherited
 * fields first. And a layout larger than the block holding it cannot be the
 * right one, since the allocator picked a block the real class fits in;
 * reading it anyway would present the next block's bytes as this object's
 * fields. Either way the fallback reads fewer fields, never wrong ones.
 */
function layoutFor(
    index: SymbolIndex, className: string, availableBytes: number, floor?: string
): VesStruct | undefined {
    for (const ancestor of ancestryOf(index.classes, className)) {
        const struct = index.structs.get(structNameOf(ancestor));
        if (struct && struct.byteSize <= availableBytes) {
            return struct;
        }
        if (ancestor === floor) {
            return undefined;
        }
    }
    return undefined;
}

/** What some components drew, as the screen inspector lights it; undefined for ones that draw nothing. */
function spritesSource(components: VesActorComponent[]): VbPixelSource | undefined {
    const source: VbPixelSource = {
        kind: 'sprites',
        cells: components.flatMap(component => component.cells ? [component.cells] : []),
        characters: components.flatMap(component => component.characters ? [component.characters] : []),
        worlds: components.flatMap(component => component.worlds),
        objects: components.flatMap(component => component.objects),
    };
    return source.cells.length + source.characters.length + source.worlds.length + source.objects.length > 0
        ? source
        : undefined;
}

/** What an actor drew: everything its sprites did. */
export function actorPixelSource(actor: VesActor): VbPixelSource | undefined {
    return spritesSource(actor.components);
}

/** What one component drew. */
export function componentPixelSource(component: VesActorComponent): VbPixelSource | undefined {
    return spritesSource([component]);
}

/**
 * The actor that drew a pixel, from the two words the core keeps of it and
 * where on which eye it is: the one whose sprite's cells or characters drew
 * it — see {@link VbPixelSource} for why not its world or objects.
 */
export function actorDrawing(
    actors: VesActor[], what: number, where: number, x: number, y: number, eye: 0 | 1
): VesActor | undefined {
    return actors.find(actor => {
        const source = actorPixelSource(actor);
        return source !== undefined && originDrawnBy(what, where, source, x, y, eye);
    });
}

/**
 * The actor whose sprite rectangle a point of one eye falls in, the smallest
 * where several do — what the picture says when the core does not, as for a
 * pixel nothing has drawn since Debug mode came on.
 */
export function actorAtPoint(actors: VesActor[], x: number, y: number, eye: 0 | 1): VesActor | undefined {
    let best: { actor: VesActor, area: number } | undefined;
    for (const actor of actors) {
        for (const { rect } of actor.components) {
            if (!rect) {
                continue;
            }
            const left = rect.x + (eye === 0 ? -rect.parallax : rect.parallax);
            if (x >= left && x < left + rect.width && y >= rect.y && y < rect.y + rect.height) {
                const area = rect.width * rect.height;
                if (!best || area < best.area) {
                    best = { actor, area };
                }
            }
        }
    }
    return best?.actor;
}

/**
 * What identifies an actor in a list: its spec, which nearly every actor has
 * and which is stable across runs, or else its class — an actor built from a
 * spec made at runtime is better known by what it is than by an address.
 */
export function actorLabel(actor: VesActor): string {
    return actor.spec ?? actor.className;
}
