/**
 * The line table a build carries, as a two-way index.
 *
 * A debugger needs both directions: a line to put a breakpoint at, and an
 * address to name in a stack frame. Two ways in are offered because two
 * situations call for them. {@link parseDwarfLineTable} reads `.debug_line`
 * out of the `.elf` itself, which is what a host that already has the image
 * should use — it needs no toolchain, and it is the only one that knows about
 * `is_stmt` and where a sequence ends. {@link parseDecodedLineTable} reads
 * what `v810-objdump --dwarf=decodedline` prints, for a host that has the
 * tool but not the image. `v810-addr2line` is the wrong tool for either: it
 * only goes one way, and costs a process per lookup.
 */

/** One row: an address, and the source line that generated it. */
export interface VesLineEntry {
    /** Offset into the ROM, not an address — see `romOffsetOf`. */
    offset: number;
    file: string;
    line: number;
    /**
     * True for the row that closes a sequence rather than opening a line.
     *
     * `.debug_line` is a series of sequences, each ending with a row that
     * marks the first address *past* the code it described. Without it an
     * address in a gap between two functions would be attributed to whatever
     * line happened to come last, which is how a debugger ends up pointing at
     * a line that has nothing to do with where the machine is.
     */
    end?: boolean;
}

export interface VesLineTable {
    /** Every source file the table mentions, as mapped. */
    readonly files: string[];
    /** Rows, ordered by address, for resolving a program counter. */
    readonly entries: VesLineEntry[];
    /**
     * Where to put a breakpoint for a line: the lowest address generated for
     * it, or for the next line below it that generated any code at all.
     *
     * The fallback is what makes a breakpoint on a blank line, a comment or a
     * declaration land somewhere sensible instead of being rejected.
     */
    resolve(file: string, line: number): VesLineEntry | undefined;
    /** The source line an address belongs to, for naming a stack frame. */
    locate(offset: number): VesLineEntry | undefined;
}

/** A line table with nothing in it, for a build that carries no line data. */
export const EMPTY_LINE_TABLE: VesLineTable = {
    files: [],
    entries: [],
    resolve: () => undefined,
    locate: () => undefined,
};

/**
 * How far past a requested line a breakpoint may slide to find code.
 *
 * Enough to clear a comment block or a run of declarations, short enough that
 * a breakpoint never silently lands in the next function.
 */
const MAX_LINE_SLIDE = 25;

/** `CU: /path/to/file.c:` — starts a unit and sets the current file. */
const UNIT_PATTERN = /^CU:\s*(.*?):?\s*$/;
/** A bare `/path/to/file.h:`, switching files inside a unit. */
const FILE_PATTERN = /^(\/.*?|[A-Za-z]:[\\/].*?|[^\s:]+\.[ch]):\s*$/;
/** `Name.c   123   0x7000abc`, the rows themselves. */
const ROW_PATTERN = /^(\S+)\s+(\d+)\s+0x([0-9a-fA-F]+)\s*$/;

/**
 * The cartridge window, which is where a build's addresses are.
 *
 * The program counter is not: the Virtual Boy mirrors the cartridge across the
 * top of the address space and boots from 0xFFFFFFF0, so a running program
 * reports addresses like 0xFFFFFFC0 for code DWARF calls 0x070FFFC0. Comparing
 * the two literally never matches, so everything here is keyed by offset into
 * the ROM instead.
 */
const CART_WINDOW_MASK = 0x00ffffff;

/**
 * Where in the ROM an address points, whichever window it came through.
 *
 * @param romSize the ROM's size in bytes, which is what it mirrors at
 */
export function romOffsetOf(address: number, romSize: number): number {
    const withinWindow = (address >>> 0) & CART_WINDOW_MASK;
    return romSize > 0 ? withinWindow % romSize : withinWindow;
}

/**
 * Read `v810-objdump --dwarf=decodedline` output into an index.
 *
 * @param text the tool's stdout
 * @param romSize the ROM's size, for keying rows by offset
 * @param mapPath turns the path the build recorded into the one the user edits
 */
export function parseDecodedLineTable(
    text: string,
    romSize: number,
    mapPath: (recorded: string) => string = path => path
): VesLineTable {
    const entries: VesLineEntry[] = [];
    const files = new Set<string>();
    const mapped = new Map<string, string>();
    let current = '';

    for (const raw of text.split('\n')) {
        const line = raw.trimEnd();
        if (line === '') {
            continue;
        }

        const unit = UNIT_PATTERN.exec(line);
        const file = unit ? undefined : FILE_PATTERN.exec(line);
        if (unit || file) {
            const recorded = (unit?.[1] ?? file?.[1]) as string;
            let resolved = mapped.get(recorded);
            if (resolved === undefined) {
                resolved = mapPath(recorded);
                mapped.set(recorded, resolved);
            }
            current = resolved;
            files.add(current);
            continue;
        }

        const row = ROW_PATTERN.exec(line);
        // A row before any path line has nothing to attach to; the tool always
        // prints the unit first, so this only skips the column header.
        if (!row || current === '') {
            continue;
        }
        entries.push({
            offset: romOffsetOf(parseInt(row[3], 16), romSize),
            file: current,
            line: parseInt(row[2], 10),
        });
    }

    return buildLineTable(entries, files);
}

/**
 * Index rows into the table both directions are answered from.
 *
 * Shared by the two readers because the rows are the same thing however they
 * were obtained, and because getting either direction subtly wrong is the
 * kind of bug that shows up as a debugger pointing at the wrong line.
 */
function buildLineTable(entries: VesLineEntry[], files: Set<string>): VesLineTable {
    entries.sort((a, b) => a.offset - b.offset || (a.end ? 1 : 0) - (b.end ? 1 : 0));

    // Lowest address per (file, line), which is where a breakpoint goes. A
    // line generates code in several places — a loop header, an inlined body —
    // and the first is the one that reads as "the line ran".
    const byLine = new Map<string, VesLineEntry>();
    for (const entry of entries) {
        if (entry.end) {
            continue;
        }
        const key = `${entry.file} ${entry.line}`;
        const existing = byLine.get(key);
        if (existing === undefined || entry.offset < existing.offset) {
            byLine.set(key, entry);
        }
    }

    return {
        files: [...files].sort(),
        entries,
        resolve(file: string, line: number): VesLineEntry | undefined {
            for (let at = line; at <= line + MAX_LINE_SLIDE; at++) {
                const found = byLine.get(`${file} ${at}`);
                if (found) {
                    return found;
                }
            }
            return undefined;
        },
        locate(offset: number): VesLineEntry | undefined {
            // The last row at or before the address: rows mark where a line's
            // code starts, so an address belongs to the row it follows.
            let low = 0;
            let high = entries.length - 1;
            let found: VesLineEntry | undefined;
            while (low <= high) {
                const middle = (low + high) >> 1;
                if (entries[middle].offset <= offset) {
                    found = entries[middle];
                    low = middle + 1;
                } else {
                    high = middle - 1;
                }
            }
            // Past the end of a sequence is past the code it described; the
            // row before it belongs to a function that has already finished.
            return found?.end ? undefined : found;
        },
    };
}

/**
 * A cursor over `.debug_line`, which is LEB128 all the way down.
 *
 * Little-endian throughout, because the only target here is one.
 */
class DwarfCursor {
    at: number;
    protected readonly view: DataView;

    constructor(protected readonly bytes: Uint8Array, at = 0) {
        this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        this.at = at;
    }

    get done(): boolean {
        return this.at >= this.bytes.byteLength;
    }

    u8(): number {
        return this.bytes[this.at++];
    }

    i8(): number {
        return (this.bytes[this.at++] << 24) >> 24;
    }

    u16(): number {
        const value = this.view.getUint16(this.at, true);
        this.at += 2;
        return value;
    }

    u32(): number {
        const value = this.view.getUint32(this.at, true);
        this.at += 4;
        return value;
    }

    uleb(): number {
        let result = 0;
        let shift = 0;
        for (;;) {
            const byte = this.bytes[this.at++];
            result += (byte & 0x7f) * Math.pow(2, shift);
            if ((byte & 0x80) === 0) {
                return result;
            }
            shift += 7;
        }
    }

    sleb(): number {
        let result = 0;
        let shift = 0;
        let byte = 0;
        do {
            byte = this.bytes[this.at++];
            result += (byte & 0x7f) * Math.pow(2, shift);
            shift += 7;
        } while ((byte & 0x80) !== 0);
        // Sign-extend from the last byte's sixth bit.
        const limit = Math.pow(2, shift);
        return (byte & 0x40) !== 0 ? result - limit : result;
    }

    /** A NUL-terminated string, and past it. */
    string(): string {
        const start = this.at;
        while (this.at < this.bytes.byteLength && this.bytes[this.at] !== 0) {
            this.at++;
        }
        const text = LATIN1.decode(this.bytes.subarray(start, this.at));
        this.at++;
        return text;
    }
}

/** Paths in this section are bytes, not UTF-8, and never anything but ASCII. */
const LATIN1 = new TextDecoder('latin1');

/** Standard opcodes, of which only the ones that move state are named. */
const DW_LNS_COPY = 1;
const DW_LNS_ADVANCE_PC = 2;
const DW_LNS_ADVANCE_LINE = 3;
const DW_LNS_SET_FILE = 4;
const DW_LNS_CONST_ADD_PC = 8;
const DW_LNS_FIXED_ADVANCE_PC = 9;
const DW_LNE_END_SEQUENCE = 1;
const DW_LNE_SET_ADDRESS = 2;

/** Versions whose header this understands. Five rearranges the file table. */
const MIN_DWARF_VERSION = 2;
const MAX_DWARF_VERSION = 4;

/** One compilation unit's file table, as the program's opcodes index it. */
interface DwarfFiles {
    /** Indexed as the opcodes do: one-based, with 0 meaning the unit itself. */
    names: string[];
}

/**
 * Read `.debug_line` out of a build's own image.
 *
 * The section is not a table but a bytecode program: a little state machine
 * with an address and a line, run once per compilation unit, emitting a row
 * wherever the two are true together. Interpreting it rather than reading a
 * tool's printout is what makes this available to a host that has the `.elf`
 * and nothing else — and it is the only way to see where a sequence ends,
 * which is what keeps an address between two functions from being blamed on
 * whichever line came last.
 *
 * Rows from a unit whose version this does not understand are skipped rather
 * than guessed at; the unit length is in the header, so one unreadable unit
 * costs only itself.
 *
 * @param romSize the cartridge's size, since rows are kept as ROM offsets
 * @param mapPath rewrites a recorded path into one that can be opened
 */
export function parseDwarfLineTable(
    section: Uint8Array,
    romSize: number,
    mapPath: (recorded: string) => string = path => path
): VesLineTable {
    const entries: VesLineEntry[] = [];
    const files = new Set<string>();
    const mapped = new Map<string, string>();
    const resolvePath = (recorded: string): string => {
        let resolved = mapped.get(recorded);
        if (resolved === undefined) {
            resolved = mapPath(recorded);
            mapped.set(recorded, resolved);
        }
        return resolved;
    };

    const cursor = new DwarfCursor(section);
    while (!cursor.done) {
        const unitStart = cursor.at;
        const unitLength = cursor.u32();
        // 0xfffffff0 and up are reserved; 0xffffffff introduces 64-bit DWARF,
        // which a 32-bit target does not produce and this does not read.
        if (unitLength === 0 || unitLength >= 0xfffffff0) {
            break;
        }
        const unitEnd = cursor.at + unitLength;
        if (unitEnd > section.byteLength) {
            break;
        }

        readUnit(cursor, unitEnd, romSize, resolvePath, entries, files);
        cursor.at = unitEnd;
        if (cursor.at <= unitStart) {
            break;
        }
    }

    return buildLineTable(entries, files);
}

/** One compilation unit's header and the program that follows it. */
function readUnit(
    cursor: DwarfCursor,
    unitEnd: number,
    romSize: number,
    resolvePath: (recorded: string) => string,
    entries: VesLineEntry[],
    files: Set<string>
): void {
    const version = cursor.u16();
    if (version < MIN_DWARF_VERSION || version > MAX_DWARF_VERSION) {
        return;
    }

    const headerLength = cursor.u32();
    const programStart = cursor.at + headerLength;
    const minimumInstructionLength = cursor.u8();
    // Only from version four, and only ever one on a machine that does not
    // bundle operations into an instruction word.
    if (version >= 4) {
        cursor.u8();
    }
    cursor.u8(); // default_is_stmt, which nothing here distinguishes on
    const lineBase = cursor.i8();
    const lineRange = cursor.u8();
    const opcodeBase = cursor.u8();

    // How many operands each standard opcode takes, so an opcode this does
    // not act on can still be stepped over.
    const operands: number[] = [0];
    for (let opcode = 1; opcode < opcodeBase; opcode++) {
        operands.push(cursor.u8());
    }

    const directories: string[] = [''];
    for (;;) {
        const directory = cursor.string();
        if (directory === '') {
            break;
        }
        directories.push(directory);
    }

    const table: DwarfFiles = { names: [''] };
    for (;;) {
        const name = cursor.string();
        if (name === '') {
            break;
        }
        const directory = cursor.uleb();
        cursor.uleb(); // modification time
        cursor.uleb(); // length
        table.names.push(joinPath(directories[directory] ?? '', name));
    }

    cursor.at = programStart;
    runProgram(
        cursor, unitEnd, { lineBase, lineRange, opcodeBase, minimumInstructionLength },
        operands, table, romSize, resolvePath, entries, files);
}

/** A path as the two halves of a file table entry make it. */
function joinPath(directory: string, name: string): string {
    if (name.startsWith('/') || /^[A-Za-z]:[\\/]/.test(name) || directory === '') {
        return name;
    }
    return `${directory.replace(/[\\/]+$/, '')}/${name}`;
}

interface DwarfLineHeader {
    lineBase: number;
    lineRange: number;
    opcodeBase: number;
    minimumInstructionLength: number;
}

/**
 * The state machine itself.
 *
 * Address and line start where the standard says and move by opcodes until
 * the unit runs out. A row is emitted wherever an opcode says the two are
 * true together — which is most of them, since the common case is one special
 * opcode advancing both at once.
 */
function runProgram(
    cursor: DwarfCursor,
    unitEnd: number,
    header: DwarfLineHeader,
    operands: number[],
    table: DwarfFiles,
    romSize: number,
    resolvePath: (recorded: string) => string,
    entries: VesLineEntry[],
    files: Set<string>
): void {
    let address = 0;
    let file = 1;
    let line = 1;

    const emit = (end = false): void => {
        const name = table.names[file];
        if (name === undefined || name === '') {
            return;
        }
        const path = resolvePath(name);
        files.add(path);
        entries.push({
            offset: romOffsetOf(address, romSize),
            file: path,
            line,
            ...(end ? { end: true } : {}),
        });
    };

    while (cursor.at < unitEnd) {
        const opcode = cursor.u8();

        if (opcode >= header.opcodeBase) {
            const adjusted = opcode - header.opcodeBase;
            address += header.minimumInstructionLength * Math.floor(adjusted / header.lineRange);
            line += header.lineBase + (adjusted % header.lineRange);
            emit();
            continue;
        }

        if (opcode === 0) {
            // Extended: a length, then a sub-opcode that fills it.
            const length = cursor.uleb();
            const next = cursor.at + length;
            const sub = length === 0 ? 0 : cursor.u8();
            if (sub === DW_LNE_END_SEQUENCE) {
                emit(true);
                address = 0;
                file = 1;
                line = 1;
            } else if (sub === DW_LNE_SET_ADDRESS) {
                address = cursor.u32();
            }
            cursor.at = next;
            continue;
        }

        switch (opcode) {
            case DW_LNS_COPY:
                emit();
                break;
            case DW_LNS_ADVANCE_PC:
                address += header.minimumInstructionLength * cursor.uleb();
                break;
            case DW_LNS_ADVANCE_LINE:
                line += cursor.sleb();
                break;
            case DW_LNS_SET_FILE:
                file = cursor.uleb();
                break;
            case DW_LNS_CONST_ADD_PC:
                address += header.minimumInstructionLength
                    * Math.floor((255 - header.opcodeBase) / header.lineRange);
                break;
            case DW_LNS_FIXED_ADVANCE_PC:
                // The one advance that is not scaled, and not a LEB128.
                address += cursor.u16();
                break;
            default:
                // Everything else only sets flags this does not read.
                for (let left = operands[opcode] ?? 0; left > 0; left--) {
                    cursor.uleb();
                }
        }
    }
}

/**
 * Where a recorded source path might actually be, best guess first.
 *
 * DWARF records a path as the compiler saw it, which for this toolchain is
 * relative to the directory the build ran in — `build/working/objects/...`
 * and nothing to say where that begins. The compilation directory is in
 * `.debug_info` rather than `.debug_line`, and reading it would mean decoding
 * abbreviations and attribute forms for one string.
 *
 * So the candidates are worked out from the one absolute path already in
 * hand: the ROM's own. A VUEngine build puts the ROM in `build/` and runs
 * from the project above it, which is what the two relative candidates are.
 * A host tries them in order and takes the first that opens; an absolute path
 * is already the answer and stands alone.
 *
 * @param romDirectory the folder the ROM sits in, with no trailing slash
 */
export function sourcePathCandidates(recorded: string, romDirectory: string): string[] {
    const path = recorded.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
    if (path.startsWith('/') || /^[A-Za-z]:\//.test(path)) {
        return [path];
    }
    const directory = romDirectory.replace(/\\/g, '/').replace(/\/+$/, '');
    const parent = directory.replace(/\/[^/]+$/, '');
    return [
        // The build ran from the project, which is the folder above the ROM's.
        `${parent}/${path}`,
        `${directory}/${path}`,
    ];
}

/** A part of a build — the game, the engine, or a plugin — and its sources. */
export interface VesSourceRoot {
    /** As the build names it, which is what appears in the generated path. */
    name: string;
    /** Absolute path the component's own `source/` sits under. */
    root: string;
}

/**
 * Turn the path a build recorded into the file someone can actually open.
 *
 * Note what this does *not* do, and no longer has to: the line number.
 * VUEngine compiles the preprocessor's output, so DWARF counts lines in the
 * generated file — and that file now has the same numbering as the source it
 * came from. It did not always: seven of the engine's eighty sources used to
 * drift, because the preprocessor left its folding marks in the prototypes it
 * injects ahead of the code and each one spent a newline the source never
 * had. That is fixed in the preprocessor, where it belongs, and kept fixed by
 * a test of its own; see its `readme.md` under "Deviations".
 *
 * A ROM built before that fix still has the old generated files, so an
 * address can still resolve to a line that is a little off. Nothing here
 * tries to make up the difference — aligning the two files by their content
 * was tried and got four line numbers in five to five in six, which is not
 * enough to be worth a heuristic that would have to be maintained. Rebuilding
 * is the answer, and it is the same answer for anything else stale in a
 * build's debug information.
 *
 * DWARF names the *generated* file — the Virtual C preprocessor's output under
 * `build/working` — rather than the source it came from. The same rewrite the
 * build already applies to compiler diagnostics (`processGCCOutput.sh`) undoes
 * it: everything up to and including `build/working/objects/<mode>/<component>`
 * or `build/working/headers/<component>` is replaced by that component's root.
 *
 * A build whose preprocessor emits `#line` directives records the original path
 * already, and those fall through this untouched — nothing matches.
 */
export function makeSourcePathMapper(roots: VesSourceRoot[]): (recorded: string) => string {
    // Longest name first, so a component whose name is a prefix of another's
    // cannot claim its paths.
    const ordered = [...roots].sort((a, b) => b.name.length - a.name.length);

    return recorded => {
        // Backslashes to slashes, and repeated slashes collapsed: the build
        // composes these paths by concatenation and leaves `//` behind in
        // places (`config.make` lists plugins as `vuengine//actors/...`), which
        // would otherwise be carried into a path nothing can open.
        const normalized = recorded.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
        for (const { name, root } of ordered) {
            const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const pattern = new RegExp(
                `^.*build/working/(?:objects/[a-z]+|headers)/${escaped}/(.*)$`
            );
            const match = pattern.exec(normalized);
            if (match) {
                return `${root.replace(/\/+$/, '')}/${match[1]}`.replace(/\/{2,}/g, '/');
            }
        }
        return recorded;
    };
}

/**
 * The recorded path a source file was compiled as, going the other way.
 *
 * {@link makeSourcePathMapper} turns what the build recorded into a file
 * somebody can open, which is the direction a listing needs. A host with
 * editors needs the reverse: it has the path of the file somebody set a
 * breakpoint in, and the line table only knows the compiled one. Rather than
 * invert the rewrite — which is not invertible, since several components can
 * end up under one root — this maps every path the table knows and looks for
 * the one that lands on the file in hand.
 *
 * Linear over the table's files, which is a hundred or so for a real build,
 * and only on the rare occasion that a breakpoint moves.
 */
export function recordedPathFor(
    table: VesLineTable,
    mapPath: (recorded: string) => string,
    source: string
): string | undefined {
    const wanted = source.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
    return table.files.find(file => mapPath(file) === wanted);
}

/** Whether a build's paths still need mapping, or already name their sources. */
export function needsSourcePathMapping(text: string): boolean {
    return /build\/working\/(?:objects|headers)\//.test(text);
}
