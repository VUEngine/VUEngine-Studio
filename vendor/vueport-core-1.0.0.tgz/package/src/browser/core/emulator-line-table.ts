/**
 * A build's line table as a two-way index: a line to break at, and an address to name in a stack frame.
 * parseDwarfLineTable reads `.debug_line` from the `.elf` (no toolchain, and the only one that knows `is_stmt` and
 * sequence ends); parseDecodedLineTable reads `v810-objdump --dwarf=decodedline` output, for a host with the tool
 * but not the image. `v810-addr2line` only goes one way and costs a process per lookup
 */

// an address, and the source line that generated it
export interface VesLineEntry {
    // offset into the ROM, not an address (see romOffsetOf)
    offset: number;
    file: string;
    line: number;
    // true for a row closing a sequence (the first address past its code); without it an address in a gap between
    // two functions would be blamed on whatever line came last
    end?: boolean;
}

export interface VesLineTable {
    // every source file the table mentions, as mapped
    readonly files: string[];
    // ordered by address, for resolving a program counter
    readonly entries: VesLineEntry[];
    // lowest address generated for a line, or for the next line below that generated code, so a breakpoint on a
    // blank line, comment or declaration lands somewhere sensible
    resolve(file: string, line: number): VesLineEntry | undefined;
    // for naming a stack frame
    locate(offset: number): VesLineEntry | undefined;
}

// for a build that carries no line data
export const EMPTY_LINE_TABLE: VesLineTable = {
    files: [],
    entries: [],
    resolve: () => undefined,
    locate: () => undefined,
};

// how far a breakpoint may slide past its line to find code: clears a comment block or declarations, but never
// silently lands in the next function
const MAX_LINE_SLIDE = 25;

// `CU: /path/to/file.c:` starts a unit and sets the current file
const UNIT_PATTERN = /^CU:\s*(.*?):?\s*$/;
// a bare `/path/to/file.h:` switches files inside a unit
const FILE_PATTERN = /^(\/.*?|[A-Za-z]:[\\/].*?|[^\s:]+\.[ch]):\s*$/;
// `Name.c   123   0x7000abc`, the rows themselves
const ROW_PATTERN = /^(\S+)\s+(\d+)\s+0x([0-9a-fA-F]+)\s*$/;

// the cartridge window, where a build's addresses are. The PC is not: the cartridge is mirrored across the top of
// the address space and boots from 0xFFFFFFF0, so code DWARF calls 0x070FFFC0 runs at 0xFFFFFFC0; hence ROM offsets
const CART_WINDOW_MASK = 0x00ffffff;

// where in the ROM an address points, whichever window it came through; romSize is what it mirrors at
export function romOffsetOf(address: number, romSize: number): number {
    const withinWindow = (address >>> 0) & CART_WINDOW_MASK;
    return romSize > 0 ? withinWindow % romSize : withinWindow;
}

// reads `v810-objdump --dwarf=decodedline` stdout; mapPath turns the recorded path into the one the user edits
export function parseDecodedLineTable(
    text: string,
    romSize: number,
    mapPath: (recorded: string) => string = path => path
): VesLineTable {
    const entries: VesLineEntry[] = [];
    const files = new Set<string>();
    const mapped = new Map<string, string>();
    let current = '';

    for (const raw of text.split('\n')) {
        const line = raw.trimEnd();
        if (line === '') {
            continue;
        }

        const unit = UNIT_PATTERN.exec(line);
        const file = unit ? undefined : FILE_PATTERN.exec(line);
        if (unit || file) {
            const recorded = (unit?.[1] ?? file?.[1]) as string;
            let resolved = mapped.get(recorded);
            if (resolved === undefined) {
                resolved = mapPath(recorded);
                mapped.set(recorded, resolved);
            }
            current = resolved;
            files.add(current);
            continue;
        }

        const row = ROW_PATTERN.exec(line);
        // a row before any path line has nothing to attach to; the tool prints the unit first, so this only skips the header
        if (!row || current === '') {
            continue;
        }
        entries.push({
            offset: romOffsetOf(parseInt(row[3], 16), romSize),
            file: current,
            line: parseInt(row[2], 10),
        });
    }

    return buildLineTable(entries, files);
}

// shared by both readers, as the rows are the same however obtained and either direction subtly wrong points the
// debugger at the wrong line
function buildLineTable(entries: VesLineEntry[], files: Set<string>): VesLineTable {
    entries.sort((a, b) => a.offset - b.offset || (a.end ? 1 : 0) - (b.end ? 1 : 0));

    // lowest address per (file, line), where a breakpoint goes: a line generates code in several places (loop header,
    // inlined body), and the first reads as "the line ran"
    const byLine = new Map<string, VesLineEntry>();
    for (const entry of entries) {
        if (entry.end) {
            continue;
        }
        const key = `${entry.file} ${entry.line}`;
        const existing = byLine.get(key);
        if (existing === undefined || entry.offset < existing.offset) {
            byLine.set(key, entry);
        }
    }

    return {
        files: [...files].sort(),
        entries,
        resolve(file: string, line: number): VesLineEntry | undefined {
            for (let at = line; at <= line + MAX_LINE_SLIDE; at++) {
                const found = byLine.get(`${file} ${at}`);
                if (found) {
                    return found;
                }
            }
            return undefined;
        },
        locate(offset: number): VesLineEntry | undefined {
            // the last row at or before the address: rows mark where a line's code starts
            let low = 0;
            let high = entries.length - 1;
            let found: VesLineEntry | undefined;
            while (low <= high) {
                const middle = (low + high) >> 1;
                if (entries[middle].offset <= offset) {
                    found = entries[middle];
                    low = middle + 1;
                } else {
                    high = middle - 1;
                }
            }
            // past the end of a sequence is past its code; the row before belongs to a function that has already finished
            return found?.end ? undefined : found;
        },
    };
}

// cursor over `.debug_line`, LEB128 all the way down; little-endian, as the only target is
class DwarfCursor {
    at: number;
    protected readonly view: DataView;

    constructor(protected readonly bytes: Uint8Array, at = 0) {
        this.view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        this.at = at;
    }

    get done(): boolean {
        return this.at >= this.bytes.byteLength;
    }

    u8(): number {
        return this.bytes[this.at++];
    }

    i8(): number {
        return (this.bytes[this.at++] << 24) >> 24;
    }

    u16(): number {
        const value = this.view.getUint16(this.at, true);
        this.at += 2;
        return value;
    }

    u32(): number {
        const value = this.view.getUint32(this.at, true);
        this.at += 4;
        return value;
    }

    uleb(): number {
        let result = 0;
        let shift = 0;
        for (;;) {
            const byte = this.bytes[this.at++];
            result += (byte & 0x7f) * Math.pow(2, shift);
            if ((byte & 0x80) === 0) {
                return result;
            }
            shift += 7;
        }
    }

    sleb(): number {
        let result = 0;
        let shift = 0;
        let byte = 0;
        do {
            byte = this.bytes[this.at++];
            result += (byte & 0x7f) * Math.pow(2, shift);
            shift += 7;
        } while ((byte & 0x80) !== 0);
        // sign-extend from the last byte's sixth bit
        const limit = Math.pow(2, shift);
        return (byte & 0x40) !== 0 ? result - limit : result;
    }

    // a NUL-terminated string, and past it
    string(): string {
        const start = this.at;
        while (this.at < this.bytes.byteLength && this.bytes[this.at] !== 0) {
            this.at++;
        }
        const text = LATIN1.decode(this.bytes.subarray(start, this.at));
        this.at++;
        return text;
    }
}

// paths in this section are bytes, not UTF-8, and only ever ASCII
const LATIN1 = new TextDecoder('latin1');

// standard opcodes; only the ones that move state are named
const DW_LNS_COPY = 1;
const DW_LNS_ADVANCE_PC = 2;
const DW_LNS_ADVANCE_LINE = 3;
const DW_LNS_SET_FILE = 4;
const DW_LNS_CONST_ADD_PC = 8;
const DW_LNS_FIXED_ADVANCE_PC = 9;
const DW_LNE_END_SEQUENCE = 1;
const DW_LNE_SET_ADDRESS = 2;

// versions whose header this understands; five rearranges the file table
const MIN_DWARF_VERSION = 2;
const MAX_DWARF_VERSION = 4;

// one compilation unit's file table, as the program's opcodes index it
interface DwarfFiles {
    // indexed as the opcodes do: one-based, with 0 meaning the unit itself
    names: string[];
}

/**
 * Reads `.debug_line` from a build's own image. The section is a bytecode program, a small state machine run per
 * compilation unit emitting rows; interpreting it serves hosts with only the `.elf` and is the only way to see
 * where sequences end. Units of unknown versions are skipped rather than guessed at, costing only themselves.
 * romSize is the cartridge size (rows are ROM offsets), mapPath rewrites recorded paths into openable ones
 */
export function parseDwarfLineTable(
    section: Uint8Array,
    romSize: number,
    mapPath: (recorded: string) => string = path => path
): VesLineTable {
    const entries: VesLineEntry[] = [];
    const files = new Set<string>();
    const mapped = new Map<string, string>();
    const resolvePath = (recorded: string): string => {
        let resolved = mapped.get(recorded);
        if (resolved === undefined) {
            resolved = mapPath(recorded);
            mapped.set(recorded, resolved);
        }
        return resolved;
    };

    const cursor = new DwarfCursor(section);
    while (!cursor.done) {
        const unitStart = cursor.at;
        const unitLength = cursor.u32();
        // 0xfffffff0 and up are reserved; 0xffffffff introduces 64-bit DWARF, which a 32-bit target does not produce
        if (unitLength === 0 || unitLength >= 0xfffffff0) {
            break;
        }
        const unitEnd = cursor.at + unitLength;
        if (unitEnd > section.byteLength) {
            break;
        }

        readUnit(cursor, unitEnd, romSize, resolvePath, entries, files);
        cursor.at = unitEnd;
        if (cursor.at <= unitStart) {
            break;
        }
    }

    return buildLineTable(entries, files);
}

// one compilation unit's header and the program that follows it
function readUnit(
    cursor: DwarfCursor,
    unitEnd: number,
    romSize: number,
    resolvePath: (recorded: string) => string,
    entries: VesLineEntry[],
    files: Set<string>
): void {
    const version = cursor.u16();
    if (version < MIN_DWARF_VERSION || version > MAX_DWARF_VERSION) {
        return;
    }

    const headerLength = cursor.u32();
    const programStart = cursor.at + headerLength;
    const minimumInstructionLength = cursor.u8();
    // only from version four, and always one on a machine that does not bundle operations into an instruction word
    if (version >= 4) {
        cursor.u8();
    }
    cursor.u8(); // default_is_stmt, which nothing here distinguishes on
    const lineBase = cursor.i8();
    const lineRange = cursor.u8();
    const opcodeBase = cursor.u8();

    // operand count per standard opcode, so one this does not act on can still be stepped over
    const operands: number[] = [0];
    for (let opcode = 1; opcode < opcodeBase; opcode++) {
        operands.push(cursor.u8());
    }

    const directories: string[] = [''];
    for (;;) {
        const directory = cursor.string();
        if (directory === '') {
            break;
        }
        directories.push(directory);
    }

    const table: DwarfFiles = { names: [''] };
    for (;;) {
        const name = cursor.string();
        if (name === '') {
            break;
        }
        const directory = cursor.uleb();
        cursor.uleb(); // modification time
        cursor.uleb(); // length
        table.names.push(joinPath(directories[directory] ?? '', name));
    }

    cursor.at = programStart;
    runProgram(
        cursor, unitEnd, { lineBase, lineRange, opcodeBase, minimumInstructionLength },
        operands, table, romSize, resolvePath, entries, files);
}

// a path as the two halves of a file table entry make it
function joinPath(directory: string, name: string): string {
    if (name.startsWith('/') || /^[A-Za-z]:[\\/]/.test(name) || directory === '') {
        return name;
    }
    return `${directory.replace(/[\\/]+$/, '')}/${name}`;
}

interface DwarfLineHeader {
    lineBase: number;
    lineRange: number;
    opcodeBase: number;
    minimumInstructionLength: number;
}

// the state machine: address and line start where the standard says and move by opcodes; a row is emitted
// wherever an opcode says so, mostly special opcodes advancing both at once
function runProgram(
    cursor: DwarfCursor,
    unitEnd: number,
    header: DwarfLineHeader,
    operands: number[],
    table: DwarfFiles,
    romSize: number,
    resolvePath: (recorded: string) => string,
    entries: VesLineEntry[],
    files: Set<string>
): void {
    let address = 0;
    let file = 1;
    let line = 1;

    const emit = (end = false): void => {
        const name = table.names[file];
        if (name === undefined || name === '') {
            return;
        }
        const path = resolvePath(name);
        files.add(path);
        entries.push({
            offset: romOffsetOf(address, romSize),
            file: path,
            line,
            ...(end ? { end: true } : {}),
        });
    };

    while (cursor.at < unitEnd) {
        const opcode = cursor.u8();

        if (opcode >= header.opcodeBase) {
            const adjusted = opcode - header.opcodeBase;
            address += header.minimumInstructionLength * Math.floor(adjusted / header.lineRange);
            line += header.lineBase + (adjusted % header.lineRange);
            emit();
            continue;
        }

        if (opcode === 0) {
            // extended: a length, then a sub-opcode that fills it
            const length = cursor.uleb();
            const next = cursor.at + length;
            const sub = length === 0 ? 0 : cursor.u8();
            if (sub === DW_LNE_END_SEQUENCE) {
                emit(true);
                address = 0;
                file = 1;
                line = 1;
            } else if (sub === DW_LNE_SET_ADDRESS) {
                address = cursor.u32();
            }
            cursor.at = next;
            continue;
        }

        switch (opcode) {
            case DW_LNS_COPY:
                emit();
                break;
            case DW_LNS_ADVANCE_PC:
                address += header.minimumInstructionLength * cursor.uleb();
                break;
            case DW_LNS_ADVANCE_LINE:
                line += cursor.sleb();
                break;
            case DW_LNS_SET_FILE:
                file = cursor.uleb();
                break;
            case DW_LNS_CONST_ADD_PC:
                address += header.minimumInstructionLength
                    * Math.floor((255 - header.opcodeBase) / header.lineRange);
                break;
            case DW_LNS_FIXED_ADVANCE_PC:
                // the one advance that is not scaled, and not a LEB128
                address += cursor.u16();
                break;
            default:
                // everything else only sets flags this does not read
                for (let left = operands[opcode] ?? 0; left > 0; left--) {
                    cursor.uleb();
                }
        }
    }
}

/**
 * Where a recorded source path might be, best guess first. DWARF paths are relative to where the build ran
 * (`build/working/objects/...`); the compilation directory is in `.debug_info`, which would mean decoding
 * abbreviations for one string. So candidates come from the ROM's own path: a VUEngine build puts the ROM in
 * `build/` and runs from the project above it. Hosts take the first that opens; an absolute path stands alone.
 * romDirectory has no trailing slash
 */
export function sourcePathCandidates(recorded: string, romDirectory: string): string[] {
    const path = recorded.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
    if (path.startsWith('/') || /^[A-Za-z]:\//.test(path)) {
        return [path];
    }
    const directory = romDirectory.replace(/\\/g, '/').replace(/\/+$/, '');
    const parent = directory.replace(/\/[^/]+$/, '');
    return [
        // the build ran from the project, the folder above the ROM's
        `${parent}/${path}`,
        `${directory}/${path}`,
    ];
}

// a part of a build (the game, the engine, or a plugin) and its sources
export interface VesSourceRoot {
    // as the build names it, which appears in the generated path
    name: string;
    // absolute path the component's own `source/` sits under
    root: string;
}

/**
 * Turns the recorded path into a file someone can open. DWARF names the Virtual C preprocessor's output under
 * `build/working`; the rewrite the build applies to compiler diagnostics (processGCCOutput.sh) undoes it,
 * replacing everything up to `build/working/objects/<mode>/<component>` or `build/working/headers/<component>`
 * with that component's root. Paths from `#line` directives match nothing and pass through.
 * Line numbers need no fixing: generated files now number like their sources (the preprocessor's folding marks
 * once shifted seven of eighty engine sources; fixed there and tested, see its readme.md "Deviations"). ROMs built
 * before that may be slightly off; aligning by content only got 5 in 6 right, so rebuilding is the answer
 */
export function makeSourcePathMapper(roots: VesSourceRoot[]): (recorded: string) => string {
    // longest name first, so a component whose name prefixes another's cannot claim its paths
    const ordered = [...roots].sort((a, b) => b.name.length - a.name.length);

    return recorded => {
        // backslashes to slashes and repeated slashes collapsed: the build concatenates paths and leaves `//` behind
        // (config.make lists plugins as `vuengine//actors/...`)
        const normalized = recorded.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
        for (const { name, root } of ordered) {
            const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const pattern = new RegExp(
                `^.*build/working/(?:objects/[a-z]+|headers)/${escaped}/(.*)$`
            );
            const match = pattern.exec(normalized);
            if (match) {
                return `${root.replace(/\/+$/, '')}/${match[1]}`.replace(/\/{2,}/g, '/');
            }
        }
        return recorded;
    };
}

// the reverse of makeSourcePathMapper, for hosts with editors: the rewrite is not invertible (several components
// can share a root), so every known path is mapped and the one landing on the file is taken. Linear over ~100
// files, only when a breakpoint moves
export function recordedPathFor(
    table: VesLineTable,
    mapPath: (recorded: string) => string,
    source: string
): string | undefined {
    const wanted = source.replace(/\\/g, '/').replace(/\/{2,}/g, '/');
    return table.files.find(file => mapPath(file) === wanted);
}

// whether a build's paths still need mapping, or already name their sources
export function needsSourcePathMapping(text: string): boolean {
    return /build\/working\/(?:objects|headers)\//.test(text);
}
