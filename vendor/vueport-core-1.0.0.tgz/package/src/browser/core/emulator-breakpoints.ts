import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { VesLineTable } from './emulator-line-table';

/**
 * Where the machine should stop, shared by the Disassembly panel's gutter and a host with editors (VUEngine
 * Studio) that sets breakpoints on source lines. Keyed by address, as that is what the machine stops at; a
 * breakpoint from a line remembers it, and VesBreakpoints.reresolve carries it across a rebuild.
 */

export interface VesBreakpointOrigin {
    // as the line table names it, which is the file the compiler read
    file: string;
    line: number;
}

export interface VesBreakpoint {
    address: number;
    // off without being forgotten, as an editor lets a breakpoint be disabled rather than removed
    enabled: boolean;
    origin?: VesBreakpointOrigin;
}

// a line a host wants stopped at, before anything has resolved it
export interface VesLineBreakpoint {
    line: number;
    // left out for one that is simply on
    enabled?: boolean;
}

export class VesBreakpoints implements Disposable {

    protected readonly points = new Map<number, VesBreakpoint>();
    protected readonly onDidChangeEmitter = new Emitter<void>();

    // once per change rather than per breakpoint, as both listeners redraw or re-send the whole set
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    // in address order, enabled or not
    all(): VesBreakpoint[] {
        return [...this.points.values()].sort((a, b) => a.address - b.address);
    }

    at(address: number): VesBreakpoint | undefined {
        return this.points.get(address >>> 0);
    }

    // the enabled ones
    armed(): number[] {
        return this.all().filter(point => point.enabled).map(point => point.address);
    }

    has(address: number): boolean {
        return this.points.has(address >>> 0);
    }

    // leaves an existing one alone, so a host re-sending its editor breakpoints cannot re-enable one switched off in
    // the gutter
    add(address: number, origin?: VesBreakpointOrigin): void {
        const at = address >>> 0;
        if (this.points.has(at)) {
            return;
        }
        this.points.set(at, { address: at, enabled: true, origin });
        this.onDidChangeEmitter.fire();
    }

    remove(address: number): void {
        if (this.points.delete(address >>> 0)) {
            this.onDidChangeEmitter.fire();
        }
    }

    toggle(address: number, origin?: VesBreakpointOrigin): void {
        const at = address >>> 0;
        if (this.points.delete(at)) {
            this.onDidChangeEmitter.fire();
            return;
        }
        this.add(at, origin);
    }

    setEnabled(address: number, enabled: boolean): void {
        const point = this.points.get(address >>> 0);
        if (point === undefined || point.enabled === enabled) {
            return;
        }
        point.enabled = enabled;
        this.onDidChangeEmitter.fire();
    }

    clear(): void {
        if (this.points.size === 0) {
            return;
        }
        this.points.clear();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Takes a whole file's breakpoints as an editor has them, so removals become visible: anything held for that file
     * and not sent again is gone. Other files' and address-set ones are left alone.
     * A line without code resolves to the next one that has (VesLineTable.resolve); two lines resolving to the same
     * address collapse into one breakpoint.
     */
    setForFile(file: string, lines: VesLineBreakpoint[], table: VesLineTable): void {
        let changed = false;

        for (const [address, point] of [...this.points]) {
            if (point.origin?.file === file) {
                this.points.delete(address);
                changed = true;
            }
        }

        for (const wanted of lines) {
            const found = table.resolve(file, wanted.line);
            if (found === undefined) {
                continue;
            }
            const address = addressOf(found.offset);
            const existing = this.points.get(address);
            if (existing !== undefined && existing.origin === undefined) {
                // already set by hand at that address; taking it over would lose the gutter's
                continue;
            }
            this.points.set(address, {
                address,
                enabled: wanted.enabled !== false,
                origin: { file, line: found.line },
            });
            changed = true;
        }

        if (changed) {
            this.onDidChangeEmitter.fire();
        }
    }

    // for a rebuild: the source did not move but the code did. Address-set breakpoints are left alone, as nobody but
    // the person who typed one knows what it meant
    reresolve(table: VesLineTable): void {
        let changed = false;
        for (const point of this.all()) {
            const origin = point.origin;
            if (origin === undefined) {
                continue;
            }
            const found = table.resolve(origin.file, origin.line);
            const address = found === undefined ? undefined : addressOf(found.offset);
            if (address === undefined || address === point.address) {
                continue;
            }
            this.points.delete(point.address);
            this.points.set(address, { ...point, address, origin: { ...origin, line: found!.line } });
            changed = true;
        }
        if (changed) {
            this.onDidChangeEmitter.fire();
        }
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}

// where the cartridge is mapped, which is where a build's addresses point
const CART_WINDOW_BASE = 0x07000000;

/**
 * The address a row's ROM offset stands at while the machine runs. The same code is reachable through the
 * cartridge window and the mirror at the top of memory, where the machine boots. Measured over 400 frames of a
 * real game, every program counter was in 0x07xxxxxx; the mirror is used only for the vectors that jump out of it.
 */
function addressOf(offset: number): number {
    return (CART_WINDOW_BASE + offset) >>> 0;
}
