import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { VesLineTable } from './emulator-line-table';

/**
 * Where the machine should stop, kept in one place for everything that sets
 * one.
 *
 * The Disassembly panel's gutter is one way in and not the only one: a host
 * with editors — VUEngine Studio — sets breakpoints on source lines, and both
 * have to mean the same thing to the machine. So the set lives here rather
 * than in the panel that happens to draw it, and whatever arms the core reads
 * it from here.
 *
 * Everything is keyed by address, because that is what the machine can stop
 * at. A breakpoint that came from a line remembers the line it came from, and
 * {@link VesBreakpoints.reresolve} is what carries it across a rebuild, when
 * the same line is at a different address.
 */

/** The source line a breakpoint was set on, for one that was. */
export interface VesBreakpointOrigin {
    /** As the line table names it, which is the file the compiler read. */
    file: string;
    line: number;
}

export interface VesBreakpoint {
    /** Where the machine stops. */
    address: number;
    /**
     * Off without being forgotten.
     *
     * An editor lets a breakpoint be disabled rather than removed, and losing
     * that distinction on the way here would make disabling one the same as
     * deleting it.
     */
    enabled: boolean;
    /** The line it was set on, for one that was set on a line. */
    origin?: VesBreakpointOrigin;
}

/** A line a host wants stopped at, before anything has resolved it. */
export interface VesLineBreakpoint {
    line: number;
    /** Left out for one that is simply on. */
    enabled?: boolean;
}

export class VesBreakpoints implements Disposable {

    protected readonly points = new Map<number, VesBreakpoint>();
    protected readonly onDidChangeEmitter = new Emitter<void>();

    /**
     * Something about the set changed.
     *
     * Fired once per change rather than per breakpoint, because the only two
     * listeners either redraw a gutter or hand the core a whole new set —
     * neither is interested in which one moved.
     */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    /** Every breakpoint, in address order, enabled or not. */
    all(): VesBreakpoint[] {
        return [...this.points.values()].sort((a, b) => a.address - b.address);
    }

    at(address: number): VesBreakpoint | undefined {
        return this.points.get(address >>> 0);
    }

    /** The addresses the core should be stopping at, which is the enabled ones. */
    armed(): number[] {
        return this.all().filter(point => point.enabled).map(point => point.address);
    }

    has(address: number): boolean {
        return this.points.has(address >>> 0);
    }

    /**
     * Put one at an address, or leave the one already there alone.
     *
     * Leaves it alone rather than replacing it so that a host re-sending its
     * editor breakpoints cannot quietly re-enable one somebody switched off
     * in the gutter.
     */
    add(address: number, origin?: VesBreakpointOrigin): void {
        const at = address >>> 0;
        if (this.points.has(at)) {
            return;
        }
        this.points.set(at, { address: at, enabled: true, origin });
        this.onDidChangeEmitter.fire();
    }

    remove(address: number): void {
        if (this.points.delete(address >>> 0)) {
            this.onDidChangeEmitter.fire();
        }
    }

    /** What clicking a gutter does. */
    toggle(address: number, origin?: VesBreakpointOrigin): void {
        const at = address >>> 0;
        if (this.points.delete(at)) {
            this.onDidChangeEmitter.fire();
            return;
        }
        this.add(at, origin);
    }

    setEnabled(address: number, enabled: boolean): void {
        const point = this.points.get(address >>> 0);
        if (point === undefined || point.enabled === enabled) {
            return;
        }
        point.enabled = enabled;
        this.onDidChangeEmitter.fire();
    }

    clear(): void {
        if (this.points.size === 0) {
            return;
        }
        this.points.clear();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Take a whole file's breakpoints, as an editor has them.
     *
     * The whole file rather than one at a time, because that is the shape an
     * editor reports them in and because removals are otherwise invisible:
     * what is sent is what that file has, and anything this held for it and
     * did not hear about again is gone.
     *
     * Breakpoints from other files, and ones set on an address in the gutter,
     * are left alone — a file's editor has no business removing those.
     *
     * A line that generated no code resolves to the next one that did, which
     * is {@link VesLineTable.resolve}'s doing and what makes a breakpoint on
     * a blank line or a comment land somewhere sensible. Two lines resolving
     * to the same address collapse into one breakpoint, which is also what
     * the machine can do about them.
     */
    setForFile(file: string, lines: VesLineBreakpoint[], table: VesLineTable): void {
        let changed = false;

        // Out with this file's old ones, which is what makes a removal in the
        // editor a removal here.
        for (const [address, point] of [...this.points]) {
            if (point.origin?.file === file) {
                this.points.delete(address);
                changed = true;
            }
        }

        for (const wanted of lines) {
            const found = table.resolve(file, wanted.line);
            if (found === undefined) {
                continue;
            }
            const address = addressOf(found.offset);
            const existing = this.points.get(address);
            if (existing !== undefined && existing.origin === undefined) {
                // Already set by hand at that address; the editor's copy of it
                // adds nothing and taking it over would lose the gutter's.
                continue;
            }
            this.points.set(address, {
                address,
                enabled: wanted.enabled !== false,
                origin: { file, line: found.line },
            });
            changed = true;
        }

        if (changed) {
            this.onDidChangeEmitter.fire();
        }
    }

    /**
     * Point every line breakpoint at where its line is now.
     *
     * For a rebuild: the source did not move but the code did, and a
     * breakpoint still aimed at the old address would stop somewhere
     * arbitrary — or, worse, nowhere, and look like a debugger that ignores
     * you. Address-set breakpoints are left alone; nobody but the person who
     * typed one knows what it meant.
     */
    reresolve(table: VesLineTable): void {
        let changed = false;
        for (const point of this.all()) {
            const origin = point.origin;
            if (origin === undefined) {
                continue;
            }
            const found = table.resolve(origin.file, origin.line);
            const address = found === undefined ? undefined : addressOf(found.offset);
            if (address === undefined || address === point.address) {
                continue;
            }
            this.points.delete(point.address);
            this.points.set(address, { ...point, address, origin: { ...origin, line: found!.line } });
            changed = true;
        }
        if (changed) {
            this.onDidChangeEmitter.fire();
        }
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}

/** Where the cartridge is mapped, which is where a build's addresses point. */
const CART_WINDOW_BASE = 0x07000000;

/**
 * The address a row's ROM offset stands at while the machine runs.
 *
 * Rows are kept as offsets because the same code is reachable through two
 * windows — the cartridge's own and the mirror at the top of memory, which is
 * where the machine boots. A breakpoint has to name the one the program
 * counter will actually be in, and for a build like this that is the
 * cartridge window throughout: measured over four hundred frames of a real
 * game, every program counter sampled was in `0x07xxxxxx`, the mirror being
 * used only for the vectors that jump out of it.
 */
function addressOf(offset: number): number {
    return (CART_WINDOW_BASE + offset) >>> 0;
}
