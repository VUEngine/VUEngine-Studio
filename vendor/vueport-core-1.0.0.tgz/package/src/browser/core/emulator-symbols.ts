/**
 * What the emulator's inspectors want out of a build's symbol table.
 *
 * Reading the table means pulling a whole `.elf` — tens of megabytes on a
 * real project — so it happens once per ROM and everything that needs a
 * symbol takes it from here rather than reading again. The index keeps only
 * the handful of things panels actually look up, so the symbol list itself
 * can be dropped as soon as this has been built from it.
 */

import { readClassHierarchy } from './emulator-classes';
import { readDwarfStructs, VesStruct } from './emulator-dwarf';
import { ElfImage, ElfSection, ElfSymbol } from './emulator-elf';
import { romOffsetOf } from './emulator-line-table';
import { isWram } from '../../common/vb-constants';

/** A symbol's address and the size the linker gave it. */
export interface SymbolExtent {
    address: number;
    size: number;
}

/**
 * What kind of thing a run of bytes is, which is all a budget needs to know
 * about it. Finer than the two the linker distinguishes, because "how much of
 * this cartridge is code" and "how much of it is artwork" are different
 * questions to a developer with a full ROM.
 */
export enum MemoryAreaKind {
    CODE = 'code',
    READ_ONLY = 'readOnly',
    DATA = 'data',
    /** Zeroed at startup, so it stands in RAM and costs no ROM. */
    ZEROED = 'zeroed',
    /** VUEngine's heap, carved out of whichever section holds it. */
    POOL = 'pool',
}

/** One run of bytes a build claimed, named as the linker named it. */
export interface MemoryArea {
    /** The section it came from, or `MemoryPool` for the engine's heap. */
    name: string;
    kind: MemoryAreaKind;
    bytes: number;
}

/**
 * How much of each memory a build claimed before it ever ran.
 *
 * Both lists are in the order the linker laid them out, and both are what the
 * `.elf` says rather than what the machine is doing: this is the fixed cost of
 * the build, the part a developer can only change by building again.
 */
export interface MemoryFootprint {
    /** Bytes the cartridge has to carry, `.data`'s initializers included. */
    rom: MemoryArea[];
    /** Bytes standing in WRAM once the machine has started. */
    wram: MemoryArea[];
}

export interface SymbolIndex {
    /**
     * What the build costs the cartridge and WRAM before it runs — see
     * {@link MemoryFootprint}. Empty lists for an image whose sections say
     * nothing, which is not a state any real build is in.
     */
    footprint: MemoryFootprint;
    /**
     * MemoryPool's singleton, which is the whole of the engine's heap: the
     * pools themselves and the bookkeeping that describes them, in one struct.
     */
    memoryPool?: SymbolExtent;
    /**
     * Every class' virtual table, by address, named as the project names the
     * class. This is what turns an allocated block back into the kind of
     * object sitting in it — see `readMemoryPoolUsage`.
     */
    vTables: Map<number, string>;
    /** Address of `Rumble.c`'s `_rumbleEffectSpec`. */
    rumbleSpecPointer?: number;
    /** Every RumbleEffectSpec in the ROM, by the address the linker gave it. */
    rumbleSpecNames: Map<number, string>;
    /**
     * Every class mapped to the one it inherits from, which is what lets an
     * object of some project's own class be recognized as, say, an Actor.
     * `Object` is its own base and ends the chain.
     */
    classes: Map<string, string>;
    /**
     * Field layouts, by the name the engine's class macro gives the struct —
     * `Actor_str` for class `Actor`. Empty for a build with no debug sections,
     * which costs field-level inspection but nothing else.
     */
    structs: Map<string, VesStruct>;
    /**
     * Every data symbol, ordered by address, so a pointer read out of the
     * running machine can be named — see `findSymbolAt`. This is what turns an
     * actor's `actorSpec` back into the spec the project wrote.
     */
    dataSymbols: ElfSymbol[];
    /**
     * Every function, ordered by address, for naming code rather than data —
     * see `findFunctionAt`. This is what turns a profiled address back into
     * the method the developer wrote.
     */
    codeSymbols: ElfSymbol[];
}

/**
 * The function an address is inside.
 *
 * Unlike `findSymbolAt` this does not require the address to fall within the
 * symbol's recorded size: a profiler's addresses land in the middle of a
 * function, and a linker does not always record a size. So the search is for
 * the last function beginning at or before the address, bounded by the size
 * when there is one.
 *
 * Addresses are compared as offsets into the ROM, because a program counter
 * may arrive through the cartridge window or through the mirror at the top of
 * memory while the symbol table only ever names the former.
 */
export function findFunctionAt(
    index: SymbolIndex, address: number, romSize: number
): ElfSymbol | undefined {
    const symbols = index.codeSymbols;
    const target = romOffsetOf(address, romSize);

    let low = 0;
    let high = symbols.length - 1;
    let found: ElfSymbol | undefined;
    while (low <= high) {
        const middle = (low + high) >> 1;
        if (romOffsetOf(symbols[middle].address, romSize) <= target) {
            found = symbols[middle];
            low = middle + 1;
        } else {
            high = middle - 1;
        }
    }
    if (!found) {
        return undefined;
    }
    const start = romOffsetOf(found.address, romSize);
    return found.size === 0 || target < start + found.size ? found : undefined;
}

/**
 * What the developer calls a function, from what the linker calls it.
 *
 * The preprocessor turns `Class::method` into `Class_method` on its way to C,
 * and the linker adds the ABI's underscore on top. Undoing both makes a flame
 * graph read in the language the code was written in. The class list is what
 * makes this safe: only a prefix that really is a class becomes a `::`, so an
 * ordinary function with an underscore in its name is left alone.
 */
export function functionDisplayName(index: SymbolIndex, symbol: string): string {
    const name = symbol.replace(/^_/, '');
    const split = name.indexOf('_');
    if (split <= 0) {
        return name;
    }
    const owner = name.slice(0, split);
    return index.classes.has(owner) ? `${owner}::${name.slice(split + 1)}` : name;
}

/**
 * The symbol a pointer falls in, and how far into it.
 *
 * A spec is usually pointed at by its start, but not always: one embedded in a
 * larger structure — an array of them, or a subclass' spec whose first member
 * is the base one — is pointed at from within the symbol that contains it. So
 * the search is for the symbol whose extent covers the address rather than for
 * one that begins at it, and the offset comes back for the caller to show.
 *
 * A symbol the linker gave no size to can only be matched exactly, since there
 * is nothing to say where it ends.
 */
export function findSymbolAt(
    index: SymbolIndex, address: number
): { symbol: ElfSymbol, offset: number } | undefined {
    const symbols = index.dataSymbols;
    const target = address >>> 0;

    // The last symbol starting at or before the address; anything covering it
    // has to start no later than it does.
    let low = 0;
    let high = symbols.length - 1;
    let found = -1;
    while (low <= high) {
        const middle = (low + high) >> 1;
        if (symbols[middle].address <= target) {
            found = middle;
            low = middle + 1;
        } else {
            high = middle - 1;
        }
    }

    // Several symbols can share an address, and a smaller one can be nested in
    // a larger, so walk back over the run that starts here for the best fit.
    for (let at = found; at >= 0; at--) {
        const symbol = symbols[at];
        const end = symbol.address + Math.max(symbol.size, 1);
        if (target >= symbol.address && target < end) {
            return { symbol, offset: target - symbol.address };
        }
        // Once the candidates start before the widest one seen could reach,
        // there is nothing further back that could cover the address either.
        if (symbol.address + symbol.size < target && symbol.address !== symbols[found]?.address) {
            break;
        }
    }
    return undefined;
}

/** The struct a class' instances are laid out by. */
export function structNameOf(className: string): string {
    return `${className}_str`;
}

/**
 * `MemoryPool`'s singleton instance.
 *
 * `__SINGLETON` declares it as a file-scope static wrapping the instance in a
 * struct that prefixes it with an object footprint, so the name carries the
 * macro's own leading underscore as well as the ABI's, and the symbol is
 * local — which the ELF reader does not mind, but `nm` on the `.map` would,
 * since a map lists globals only.
 */
const MEMORY_POOL_SYMBOL = '__singletonWrapperMemoryPool';

/** What the heap is called where it appears as an area of its own. */
export const MEMORY_POOL_AREA = 'MemoryPool';
const VTABLE_SUFFIX = '_vTable';
const RUMBLE_SPEC_POINTER_SYMBOL = '__rumbleEffectSpec';
const RUMBLE_SPEC_SUFFIX = 'RumbleEffectSpec';

/** Reduce a build's image to what the inspectors can use. */
export function indexElfSymbols(image: ElfImage): SymbolIndex {
    const index: SymbolIndex = {
        footprint: { rom: [], wram: [] },
        vTables: new Map(),
        rumbleSpecNames: new Map(),
        classes: readClassHierarchy(image),
        structs: readDwarfStructs(image),
        dataSymbols: image.symbols
            .filter(symbol => !symbol.isFunction)
            .sort((a, b) => a.address - b.address),
        codeSymbols: image.symbols
            .filter(symbol => symbol.isFunction)
            .sort((a, b) => a.address - b.address),
    };

    for (const symbol of image.symbols) {
        // Only data symbols name anything here; the code ones are what the
        // class hierarchy was read from, and are of no further use.
        if (symbol.isFunction) {
            continue;
        }
        if (symbol.name === MEMORY_POOL_SYMBOL) {
            index.memoryPool = { address: symbol.address, size: symbol.size };
        } else if (symbol.name === RUMBLE_SPEC_POINTER_SYMBOL) {
            index.rumbleSpecPointer = symbol.address;
        } else if (symbol.name.endsWith(VTABLE_SUFFIX)) {
            index.vTables.set(symbol.address, trim(symbol.name, VTABLE_SUFFIX));
        } else if (symbol.name.endsWith(RUMBLE_SPEC_SUFFIX)) {
            index.rumbleSpecNames.set(symbol.address, trim(symbol.name, RUMBLE_SPEC_SUFFIX));
        }
    }

    // After the loop rather than in it: the heap is shown as its own area, and
    // which section it was carved out of is only known once it has been found.
    index.footprint = readMemoryFootprint(image, index.memoryPool);

    return index;
}

/** What the linker's flags make a section, before the heap is carved out. */
function sectionKind(section: ElfSection): MemoryAreaKind {
    if (section.executable) {
        return MemoryAreaKind.CODE;
    }
    if (!section.hasContents) {
        return MemoryAreaKind.ZEROED;
    }
    return section.writable ? MemoryAreaKind.DATA : MemoryAreaKind.READ_ONLY;
}

/**
 * What a build costs its cartridge and its RAM.
 *
 * The two totals are not the same bytes counted twice. A section with contents
 * costs ROM whatever address it runs at, because the cartridge is the only
 * place its initial bytes can come from — which is why `.sdata` appears in
 * both lists — while a section that runs in WRAM costs WRAM whether its bytes
 * were in the file or are about to be zeroed.
 *
 * `MemoryPool` is pulled out of the section holding it and named separately.
 * In a VUEngine game it is most of both figures, and a budget that folded it
 * into `.sdata` would be a bar saying only that the engine is present.
 */
function readMemoryFootprint(image: ElfImage, pool: SymbolExtent | undefined): MemoryFootprint {
    const footprint: MemoryFootprint = { rom: [], wram: [] };
    for (const section of image.sections) {
        if (!section.allocated || section.size === 0) {
            continue;
        }
        const kind = sectionKind(section);
        for (const area of splitAroundPool(section, kind, pool)) {
            if (section.hasContents) {
                footprint.rom.push(area);
            }
            if (isWram(section.address)) {
                footprint.wram.push(area);
            }
        }
    }
    return footprint;
}

/**
 * A section as one area, or as the heap with whatever of the section is left
 * on either side of it.
 *
 * The remainders are kept rather than rounded away: they are what the section
 * actually holds besides the heap, and in a VUEngine build they are a few
 * dozen bytes against fifty kilobytes — a difference worth being able to see.
 */
function splitAroundPool(
    section: ElfSection, kind: MemoryAreaKind, pool: SymbolExtent | undefined
): MemoryArea[] {
    const end = section.address + section.size;
    const from = pool ? Math.max(section.address, pool.address) : end;
    const to = pool ? Math.min(end, pool.address + pool.size) : end;
    if (to <= from) {
        return [{ name: section.name, kind, bytes: section.size }];
    }
    return [
        { name: section.name, kind, bytes: from - section.address },
        { name: MEMORY_POOL_AREA, kind: MemoryAreaKind.POOL, bytes: to - from },
        { name: section.name, kind, bytes: end - to },
    ].filter(area => area.bytes > 0);
}

/**
 * What the project calls the thing a generated symbol belongs to: the ABI's
 * leading underscore and the generated suffix are on every one of them.
 */
function trim(name: string, suffix: string): string {
    return name.replace(/^_/, '').slice(0, -suffix.length);
}
