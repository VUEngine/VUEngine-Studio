import { DisassemblyLine } from '../../common/vb-protocol';
import { romOffsetOf, VesLineTable } from './emulator-line-table';
import { findFunctionAt, findSymbolAt, functionDisplayName, SymbolIndex } from './emulator-symbols';

// what a listing can be told about itself, given the build's symbols. Pure functions of the lines and the symbol
// index, kept apart from the panel so they can be checked against a real build without a browser

// the routine a line belongs to, and what a header says about it
export interface DisassemblyOwner {
    name: string;
    address: number;
    // as the linker recorded it; zero where it recorded none
    size: number;
}

export interface DisassemblyRow {
    line: DisassemblyLine;
    // drawn above the line where the routine changes
    header?: DisassemblyOwner;
    owner?: DisassemblyOwner;
    // operands that are addresses, by operand index, with what to call them
    targets: Map<number, { address: number; label: string }>;
    // what a movhi/movea pair built, once it turns out to name something
    loaded?: { address: number; label: string };
    /**
     * True where this line begins inside the instruction before it. Never with a core that sizes instructions right;
     * one built before vbuCodeSize was corrected sizes a conditional branch at four bytes instead of two and lists the
     * second halfword after every branch, a seventh of a real build. Kept as a check so a non-instruction is never
     * drawn as one, whichever core is loaded.
     */
    adrift?: boolean;
    // the source line this instruction came from, only where it differs from the line before, so a mixed listing
    // reads as one line of C followed by its instructions
    source?: { file: string; line: number };
}

// the registers the disassembler writes by name, so a name can be turned back into a number. Everything else is
// rN and parses as itself
const NAMED_REGISTERS: Record<string, number> = {
    hp: 2, fp: 2, sp: 3, gp: 4, tp: 5, lp: 31,
};

export function registerOf(operand: string): number | undefined {
    const named = NAMED_REGISTERS[operand];
    if (named !== undefined) {
        return named;
    }
    const numbered = /^r(\d{1,2})$/.exec(operand);
    if (!numbered) {
        return undefined;
    }
    const index = Number(numbered[1]);
    return index < 32 ? index : undefined;
}

// a branch or call target: eight bare hex digits. The worker writes immediates with 0x and addresses without,
// which tells them apart without knowing the instruction
export function targetOf(operand: string): number | undefined {
    return /^[0-9A-F]{8}$/.test(operand) ? Number.parseInt(operand, 16) >>> 0 : undefined;
}

// a 0xNNNN immediate's value, sign-extended the way the machine reads it
export function immediateOf(operand: string): number | undefined {
    const match = /^0x([0-9A-F]{1,8})$/.exec(operand);
    if (!match) {
        return undefined;
    }
    const value = Number.parseInt(match[1], 16);
    return match[1].length <= 4 && (value & 0x8000) !== 0 ? value - 0x10000 : value;
}

// decided by the top six bits: below 0x28 one halfword, from 0x28 up two. The same table the CPU fetches by, so
// this is a check on the listing rather than a second opinion
function sizeOf(line: DisassemblyLine): number {
    if (line.code.length < 2) {
        return line.code.length;
    }
    const opcode = ((line.code[1] << 8) | line.code[0]) >>> 10;
    return opcode < 0x28 ? 2 : 4;
}

// written the way the rest of the debugger writes offsets
function offsetText(offset: number): string {
    return `+0x${offset.toString(16).toUpperCase()}`;
}

/**
 * Everything the panel can say about a listing, in one pass, as two of the answers need the surrounding lines: a
 * header appears where the routine changes, and a pointer is built by a movhi and finished by a movea some
 * instructions later. `romBytes` is the cartridge's size, which turns a program counter in the mirror at the top
 * of memory back into a ROM offset.
 */
export function annotateDisassembly(
    lines: DisassemblyLine[], symbols: SymbolIndex | undefined, romBytes: number,
): DisassemblyRow[] {
    const owners = new Map<number, DisassemblyOwner | undefined>();

    const ownerOf = (address: number): DisassemblyOwner | undefined => {
        if (owners.has(address)) {
            return owners.get(address);
        }
        let owner: DisassemblyOwner | undefined;
        if (symbols && romBytes > 0) {
            const found = findFunctionAt(symbols, address, romBytes);
            if (found) {
                owner = {
                    name: functionDisplayName(symbols, found.name),
                    address: found.address,
                    size: found.size,
                };
            }
        }
        owners.set(address, owner);
        return owner;
    };

    // inside the routine being read a target is an offset (a loop going back to its own top); anywhere else it is the
    // routine's name, with an offset only when it is not the entry
    const labelFor = (address: number, within?: DisassemblyOwner): string | undefined => {
        const owner = ownerOf(address);
        if (!owner) {
            return undefined;
        }
        const offset = address - owner.address;
        if (within && owner.address === within.address) {
            return offset === 0 ? owner.name : offsetText(offset);
        }
        return offset === 0 ? owner.name : `${owner.name}${offsetText(offset)}`;
    };

    const dataLabelFor = (address: number): string | undefined => {
        if (!symbols) {
            return undefined;
        }
        const found = findSymbolAt(symbols, address);
        if (!found) {
            return undefined;
        }
        const name = found.symbol.name.replace(/^_/, '');
        return found.offset === 0 ? name : `${name}${offsetText(found.offset)}`;
    };

    const rows: DisassemblyRow[] = [];
    // what each register is known to hold, from the pairs that build addresses. Cleared at a routine boundary
    let held = new Map<number, number>();
    let previous: DisassemblyOwner | undefined;
    let first = true;

    for (const line of lines) {
        const owner = ownerOf(line.address);
        const changed = first || owner?.address !== previous?.address;
        if (changed) {
            held = new Map();
        }

        const row: DisassemblyRow = {
            line,
            owner,
            header: changed && owner ? owner : undefined,
            targets: new Map(),
        };

        line.operands.forEach((operand, index) => {
            const target = targetOf(operand);
            if (target === undefined) {
                return;
            }
            const label = labelFor(target, owner);
            if (label !== undefined) {
                row.targets.set(index, { address: target, label });
            }
        });

        trackPointer(line, held, row, dataLabelFor);

        rows.push(row);
        previous = owner;
        first = false;
    }

    for (let index = 1; index < rows.length; index++) {
        const before = rows[index - 1].line;
        if (rows[index].line.address !== ((before.address + sizeOf(before)) >>> 0)) {
            rows[index].adrift = true;
        }
    }

    return rows;
}

/**
 * Marks the rows where the source line changes. Apart from annotateDisassembly as it needs a build's .debug_line
 * rather than its symbol table. Modifies the rows in place, so a panel can add this when the line table turns up
 * without disassembling again. `romBytes` turns a program counter in the top mirror back into a row's offset.
 */
export function attachSourceLines(
    rows: DisassemblyRow[], lines: VesLineTable | undefined, romBytes: number
): DisassemblyRow[] {
    if (!lines || romBytes <= 0) {
        return rows;
    }
    let previous: { file: string; line: number } | undefined;
    for (const row of rows) {
        const found = lines.locate(romOffsetOf(row.line.address, romBytes));
        if (!found) {
            row.source = undefined;
            // a gap between two functions belongs to neither, so the next row with a line is a change whatever came
            // before
            previous = undefined;
            continue;
        }
        row.source = previous !== undefined
            && previous.file === found.file && previous.line === found.line
            ? undefined
            : { file: found.file, line: found.line };
        previous = { file: found.file, line: found.line };
    }
    return rows;
}

/**
 * Follows the movhi (top half) and movea (bottom half) that build a pointer, often several instructions apart.
 * Anything else writing a register makes it unknown rather than wrong: a name that might be false is worse than
 * no name.
 */
function trackPointer(
    line: DisassemblyLine,
    held: Map<number, number>,
    row: DisassemblyRow,
    dataLabelFor: (address: number) => string | undefined,
): void {
    const mnemonic = line.mnemonic.toLowerCase();
    const isPair = mnemonic === 'movhi' || mnemonic === 'movea';
    const [imm, source, destination] = line.operands;
    const value = isPair && imm !== undefined ? immediateOf(imm) : undefined;
    const from = isPair && source !== undefined ? registerOf(source) : undefined;
    const to = isPair && destination !== undefined ? registerOf(destination) : undefined;

    if (to === undefined || value === undefined || from === undefined) {
        // the destination is the last operand throughout, so this is what anything else writing a register looks like
        const written = registerOf(line.operands[line.operands.length - 1] ?? '');
        if (written !== undefined && written !== 0) {
            held.delete(written);
        }
        return;
    }

    const base = from === 0 ? 0 : held.get(from);
    if (base === undefined) {
        held.delete(to);
        return;
    }
    const built = (mnemonic === 'movhi' ? base + (value << 16) : base + value) >>> 0;
    held.set(to, built);
    if (mnemonic === 'movea') {
        const label = dataLabelFor(built);
        if (label !== undefined) {
            row.loaded = { address: built, label };
        }
    }
}
