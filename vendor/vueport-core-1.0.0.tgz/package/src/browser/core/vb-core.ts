import { Disposable, Emitter, Event } from '../../common/emulator-events';
import { LiveProfileSnapshot } from '../../common/emulator-live-profile';
import {
    DisplayMode,
    VB_AUDIO_PROCESSOR,
    VB_DEFAULT_DISPLAY_MODE,
    VB_SAMPLE_RATE,
    VB_SCREEN_HEIGHT,
    VB_SCREEN_WIDTH,
} from '../../common/vb-constants';
import {
    isVbEvent,
    VbCheatWrite,
    ScheduledEdit,
    CommandName,
    Backdrop,
    DisassemblyLine,
    Frame,
    ProfileResult,
    Recording,
    Registers,
    Outbound,
    Params,
    Request,
    Response,
    Result,
    SimHandle,
    Speed,
    SramRun,
    StopReason,
    VesRaEvent,
    VesRaLeaderboardEntries,
    VesRaUser,
    VsuReading,
} from '../../common/vb-protocol';
import { VbRenderer } from '../../worker/vb-renderer';

export interface CoreOptions {
    /** URL of the bundled core worker. */
    workerUrl: string;
    /** URL of the bundled audio worklet. */
    audioWorkletUrl: string;
    /** URL the core's WebAssembly binary is served from. */
    wasmUrl: string;
    /**
     * URL of the RetroAchievements engine's Emscripten module, if this build
     * carries one. See {@link VbCommands.init}.
     */
    rcheevosModuleUrl?: string;
    /** Keep WebGL on the page and transfer frames out of the worker. */
    mainThreadVideo?: boolean;
}

/**
 * DOM-side handle on one emulation session.
 *
 * A session is one worker holding one or more simulations. Emulation is
 * core-wide: run() and suspend() apply to every simulation in the session at
 * once, which is why unrelated emulators get their own core, and why a linked
 * pair must share one (Phase 3).
 */
/** A pause, for the two the audio check needs. */
const delay = (ms: number): Promise<void> =>
    new Promise(resolve => setTimeout(resolve, ms));

const VIDEO_FRAME_BYTES = VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4;
const VIDEO_TRANSFER_BUFFERS = 3;

export class Core implements Disposable {

    protected readonly worker: Worker;
    protected readonly audioContext: AudioContext;
    protected readonly audioNode: AudioWorkletNode;
    readonly mainThreadVideo: boolean;
    protected readonly mainThreadRenderers = new Map<SimHandle, {
        presentation: number;
        renderer: VbRenderer;
    }>();
    protected nextPresentation = 1;

    /**
     * The renderer screenshots taken on this thread are composed with.
     *
     * Only ever built where presentation lives on the page, and built once:
     * see {@link captureMainThread}.
     */
    protected screenshotRenderer: VbRenderer | undefined;

    /**
     * Who wants a copy of every frame, by simulation — a video recording.
     *
     * Separate from the renderers above: a tap is opened on a machine that is
     * being presented in the worker, which is the ordinary arrangement, as
     * readily as on one presented here. See `setVideoTap` in `vb-protocol.ts`.
     */
    protected readonly videoTaps = new Map<SimHandle, {
        presentation: number;
        handle: (frame: Frame) => void;
    }>();

    /** Stops waiting for the gesture that would start the audio, if one is armed. */
    protected audioUnlock: (() => void) | undefined;

    /** The last attempt to start the audio, for {@link audioStillBlocked} to wait on. */
    protected audioResume: Promise<void> | undefined;

    /** How long a context is given to suspend before {@link driveAudio} moves on. */
    protected static readonly AUDIO_TRANSITION_TIMEOUT_MS = 500;

    /** Whether the audio graph should be producing: what run and suspend want. */
    protected audioWanted = false;

    /** What the context was last actually asked for. See {@link settleAudio}. */
    protected audioApplied = false;

    /** The transition in flight, so that only one is ever under way. */
    protected audioSettling: Promise<void> | undefined;

    protected readonly onDidUnblockAudioEmitter = new Emitter<void>();
    /** Fires when audio the browser was holding back has been let through. */
    readonly onDidUnblockAudio: Event<void> = this.onDidUnblockAudioEmitter.event;

    protected readonly pending = new Map<number, {
        resolve: (result: unknown) => void,
        reject: (error: Error) => void,
    }>();
    protected nextRequestId = 1;

    protected readonly onErrorEmitter = new Emitter<string>();
    readonly onError: Event<string> = this.onErrorEmitter.event;

    protected readonly onTerminalEmitter = new Emitter<{ sim: SimHandle, text: string }>();
    /** Text a simulation wrote to the terminal port, once capture is enabled. */
    readonly onTerminal: Event<{ sim: SimHandle, text: string }> = this.onTerminalEmitter.event;

    protected readonly onLinkEmitter = new Emitter<{ sim: SimHandle, bytes: number[] }>();
    /** Bytes a simulation sent over the link port, once capture is enabled. */
    readonly onLink: Event<{ sim: SimHandle, bytes: number[] }> = this.onLinkEmitter.event;

    protected readonly onEsSoundEmitter = new Emitter<{ sim: SimHandle, commands: number[] }>();
    /** Halfwords a simulation wrote to the ESSound port, once capture is enabled. */
    readonly onEsSound: Event<{ sim: SimHandle, commands: number[] }> = this.onEsSoundEmitter.event;

    protected readonly onSramEmitter =
        new Emitter<{ sim: SimHandle, runs: SramRun[] }>();
    /** Touches of a simulation's save region, once capture is enabled. */
    readonly onSram: Event<{ sim: SimHandle, runs: SramRun[] }> =
        this.onSramEmitter.event;

    protected readonly onSpeedEmitter = new Emitter<Speed>();
    /**
     * How fast emulation is actually running, about once a second and once
     * more when it suspends. Not the requested speed: an unaffordable fast
     * forward is clamped, so this is the only reliable account of it.
     */
    readonly onSpeed: Event<Speed> = this.onSpeedEmitter.event;

    protected readonly onPointerWriteEmitter = new Emitter<{ sim: SimHandle, address: number, values: number[] }>();
    /** Values written to the address a simulation is watching, if any. */
    readonly onPointerWrite: Event<{ sim: SimHandle, address: number, values: number[] }> =
        this.onPointerWriteEmitter.event;

    protected readonly onDigestEmitter =
        new Emitter<{ sim: SimHandle, frame: number, digest: number }>();
    /**
     * A machine's digest, taken at a frame boundary because
     * {@link Sim.setDigestPeriod} asked for one.
     *
     * On the core rather than the simulation because the listener — a link
     * session — wants both of its machines' digests in one place, and has to
     * tell them apart by handle anyway.
     */
    readonly onDigest: Event<{ sim: SimHandle, frame: number, digest: number }> =
        this.onDigestEmitter.event;

    protected readonly onProgressEmitter = new Emitter<{ frame: number }>();
    /**
     * How far the machines have got, a few times a frame's worth apart.
     *
     * Only sent while something is under lockstep — see `progress` in
     * `vb-protocol.ts`. A link session schedules against this.
     */
    readonly onProgress: Event<{ frame: number }> = this.onProgressEmitter.event;

    protected readonly onAwaitingInputEmitter =
        new Emitter<{ waiting: boolean, frame: number, sims: SimHandle[] }>();
    /**
     * The drive loop started or stopped waiting for scheduled input.
     *
     * Only fires for a session running under lockstep — see `queueKeys` in
     * `vb-protocol.ts` — and only on the change, so it can drive a "waiting
     * for the other player" state directly.
     */
    readonly onAwaitingInput: Event<{ waiting: boolean, frame: number, sims: SimHandle[] }> =
        this.onAwaitingInputEmitter.event;

    protected readonly onStoppedEmitter =
        new Emitter<{ sim: SimHandle, address: number, reason: StopReason }>();
    /**
     * A simulation stopped on an instruction, and emulation was suspended.
     *
     * Not something the host asked for, which is why it is an event: a
     * breakpoint suspends the machine from underneath whoever thought it was
     * running, and anything showing whether the game is paused has to hear
     * about it or start lying.
     */
    readonly onStopped: Event<{ sim: SimHandle, address: number, reason: StopReason }> =
        this.onStoppedEmitter.event;

    protected readonly onStalledEmitter = new Emitter<{ frames: number }>();
    /**
     * The core stopped advancing and emulation was suspended by the worker.
     *
     * Rare and not an error — see `stalled` in `vb-protocol.ts`. A listener
     * should say so and offer a reset; the picture is frozen either way.
     */
    readonly onStalled: Event<{ frames: number }> = this.onStalledEmitter.event;

    protected readonly onRetroAchievementsEmitter = new Emitter<VesRaEvent>();
    /**
     * One message at a time from the achievement engine, unpacked from the
     * batches the worker sends. The RetroAchievements service is the only
     * listener; see `emulator-retroachievements.ts`.
     */
    readonly onRetroAchievements: Event<VesRaEvent> = this.onRetroAchievementsEmitter.event;

    protected disposed = false;

    protected constructor(
        worker: Worker,
        audioContext: AudioContext,
        audioNode: AudioWorkletNode,
        mainThreadVideo: boolean,
    ) {
        this.worker = worker;
        this.audioContext = audioContext;
        this.audioNode = audioNode;
        this.mainThreadVideo = mainThreadVideo;
        this.worker.onmessage = event => this.onWorkerMessage(event.data);
    }

    static async create(options: CoreOptions): Promise<Core> {
        // The core produces samples at a fixed rate, so the graph runs at that
        // rate too and no resampling is needed.
        const audioContext = new AudioContext({
            latencyHint: 'interactive',
            sampleRate: VB_SAMPLE_RATE,
        });
        await audioContext.suspend();
        await audioContext.audioWorklet.addModule(options.audioWorkletUrl);

        const audioNode = new AudioWorkletNode(audioContext, VB_AUDIO_PROCESSOR, {
            numberOfInputs: 0,
            numberOfOutputs: 1,
            outputChannelCount: [2],
        });
        audioNode.connect(audioContext.destination);

        // Sample buffers cycle directly between worker and worklet, never
        // passing through the DOM thread.
        const channel = new MessageChannel();
        await new Promise<void>(resolve => {
            audioNode.port.onmessage = () => resolve();
            audioNode.port.postMessage({ core: channel.port1 }, [channel.port1]);
        });
        audioNode.port.onmessage = null;

        const worker = new Worker(options.workerUrl);
        const core = new Core(
            worker, audioContext, audioNode, options.mainThreadVideo ?? false);

        await new Promise<void>((resolve, reject) => {
            core.pending.set(0, { resolve: () => resolve(), reject });
            worker.postMessage({ audioPort: channel.port2 }, [channel.port2]);
        });

        await core.request('init', {
            wasmUrl: options.wasmUrl,
            rcheevosModuleUrl: options.rcheevosModuleUrl,
        });
        return core;
    }

    /**
     * The size of this core build's state struct, as a build fingerprint.
     *
     * See `stateSize` in `vb-protocol.ts`; a link session compares it before
     * agreeing to play.
     */
    async stateSize(): Promise<number> {
        return this.request('stateSize', {});
    }

    async createSim(): Promise<Sim> {
        const handle = await this.request('createSim', {});
        return new Sim(this, handle);
    }

    /** Attach either the ordinary worker renderer or the WebKitGTK page renderer. */
    async attachCanvas(
        sim: SimHandle,
        canvas: HTMLCanvasElement,
        mode: DisplayMode,
    ): Promise<void> {
        this.detachCanvas(sim);
        if (!this.mainThreadVideo) {
            const offscreen = canvas.transferControlToOffscreen();
            await this.request('attachCanvas', { sim, canvas: offscreen }, [offscreen]);
            return;
        }

        const presentation = this.nextPresentation++;
        const renderer = new VbRenderer(canvas, mode);
        this.mainThreadRenderers.set(sim, { presentation, renderer });
        const buffers = Array.from(
            { length: VIDEO_TRANSFER_BUFFERS }, () => new ArrayBuffer(VIDEO_FRAME_BYTES));
        try {
            await this.request(
                'attachCanvas',
                { sim, mainThread: { presentation, buffers } },
                buffers,
            );
        } catch (error) {
            const attached = this.mainThreadRenderers.get(sim);
            if (attached?.presentation === presentation) {
                this.detachCanvas(sim);
            }
            throw error;
        }
    }

    setMainThreadDisplayMode(sim: SimHandle, mode: DisplayMode): void {
        this.mainThreadRenderers.get(sim)?.renderer.setDisplayMode(mode);
    }

    async captureMainThread(
        sim: SimHandle,
        mode?: DisplayMode,
        scale = 1,
    ): Promise<ArrayBuffer> {
        if (!mode) {
            const liveRenderer = this.mainThreadRenderers.get(sim)?.renderer;
            if (!liveRenderer) {
                throw new Error('The emulator has nothing to capture yet.');
            }
            return liveRenderer.capture(scale);
        }

        const frame = await this.request('readFrame', { sim });
        // One renderer, kept and retuned, exactly as the worker's own
        // `capture` keeps one. Here it is a WebGL context on the page, and a
        // screenshot is not a rare thing — every save state and every entry in
        // the Continue list is one — so building a fresh context per capture
        // is how a session runs the browser out of them.
        if (!this.screenshotRenderer) {
            this.screenshotRenderer = new VbRenderer(document.createElement('canvas'), mode);
        } else {
            this.screenshotRenderer.setDisplayMode(mode);
        }
        this.screenshotRenderer.present(new Uint8Array(frame.pixels), frame.colorMode);
        return this.screenshotRenderer.capture(scale);
    }

    detachCanvas(sim: SimHandle): void {
        const attached = this.mainThreadRenderers.get(sim);
        attached?.renderer.dispose();
        this.mainThreadRenderers.delete(sim);
        this.videoTaps.delete(sim);
    }

    /**
     * Take a copy of every frame a machine presents, or pass nothing to stop.
     *
     * What a video recording is built on. The handler is called with the same
     * uncomposited buffer a main-thread renderer would be given and must be
     * done with it when it returns — the buffer goes straight back to the
     * worker to be filled again, so anything worth keeping has to be uploaded
     * or copied there and then.
     */
    async setVideoTap(sim: SimHandle, handle?: (frame: Frame) => void): Promise<void> {
        if (!handle) {
            this.videoTaps.delete(sim);
            await this.request('setVideoTap', { sim });
            return;
        }
        const presentation = this.nextPresentation++;
        this.videoTaps.set(sim, { presentation, handle });
        const buffers = Array.from(
            { length: VIDEO_TRANSFER_BUFFERS }, () => new ArrayBuffer(VIDEO_FRAME_BYTES));
        try {
            await this.request(
                'setVideoTap', { sim, tap: { presentation, buffers } }, buffers);
        } catch (error) {
            if (this.videoTaps.get(sim)?.presentation === presentation) {
                this.videoTaps.delete(sim);
            }
            throw error;
        }
    }

    /**
     * The graph the emulator's own sound is played into.
     *
     * Exposed so that a recording can tap it — and so that anything else
     * playing alongside the machine can be mixed into the same context, which
     * is the only way two sources ever reach one recorded track. Nothing here
     * may retune it: it runs at the core's sample rate on purpose (see
     * {@link Core.create}), and its state follows emulation.
     */
    get audio(): AudioContext {
        return this.audioContext;
    }

    /**
     * Send what the machine is playing to somewhere else as well.
     *
     * Additional to the speakers, never instead of them, and free: the worklet
     * is asked for its quantum once however many things are listening.
     */
    connectAudio(node: AudioNode): void {
        this.audioNode.connect(node);
    }

    disconnectAudio(node: AudioNode): void {
        try {
            this.audioNode.disconnect(node);
        } catch {
            // Disconnecting something that is not connected throws; a
            // recording that has already been torn down is not an error.
        }
    }

    /**
     * Start emulating every simulation in this session.
     *
     * The audio is asked to start but never waited for. A page nobody has
     * touched yet may not play sound, and Firefox says so by leaving the
     * promise from `resume()` pending until someone does touch it — so
     * awaiting it here left the machine unstarted, and the picture black, in
     * the one window that is never clicked first: the second player's, which
     * the first player's window opens. The picture does not depend on the
     * audio, so it no longer waits for it; {@link armAudioUnlock} lets the
     * gesture that does arrive bring the sound with it.
     */
    async run(): Promise<void> {
        this.audioWanted = true;
        // A context nobody here suspended is still a context to start: the
        // browser stops one of its own accord — an autoplay policy, a host
        // that took the audio device away — and this used to ask for the
        // resume unconditionally, which quietly covered that. Forgetting that
        // the last resume was ever asked for is what keeps it covered, and it
        // cannot spin, because it happens once per call rather than once per
        // turn of {@link driveAudio}. `state` is only trusted in this
        // direction; see {@link audioStillBlocked} for why not in the other.
        if (this.audioContext.state !== 'running') {
            this.audioApplied = false;
        }
        this.armAudioUnlock();
        // Not awaited, for the reason above, and before the worker rather than
        // after it so that the graph is already producing when the first chunk
        // is handed to it.
        this.settleAudio();
        await this.request('run', {});
    }

    async suspend(): Promise<void> {
        this.audioWanted = false;
        this.disarmAudioUnlock();
        // The worker first: the audio it has already handed over should play
        // out rather than be cut off mid-buffer.
        await this.request('suspend', {});
        await this.settleAudio();
    }

    /**
     * Put the audio graph where the last caller of {@link run} or
     * {@link suspend} asked for it.
     *
     * Both of those cross the worker before they are done, and the context is
     * the thing on the far side of that wait — so a pause and the resume that
     * follows it a moment later used to reach the context in whichever order
     * their round trips happened to finish in. Lose that race and the graph
     * ends up suspended while the worker emulates, which is not a quiet
     * mismatch: the drive loop is clocked by the worklet asking for samples
     * (see the head of `vb-worker.ts`), so the machine is frozen solid with
     * every control insisting it is running. Only the next pause and resume
     * put it back, which is exactly how long it looks like the emulator has
     * died.
     *
     * So the two say what they want and this applies it, one transition at a
     * time, re-reading the wish on the way out — the last word wins, whichever
     * transition is in flight when it is said.
     */
    protected settleAudio(): Promise<void> {
        this.audioSettling ??= this.driveAudio()
            .finally(() => { this.audioSettling = undefined; });
        return this.audioSettling;
    }

    protected async driveAudio(): Promise<void> {
        while (this.audioWanted !== this.audioApplied) {
            this.audioApplied = this.audioWanted;
            if (this.audioApplied) {
                this.audioResume = this.audioContext.resume().catch(() => undefined);
            } else {
                await Promise.race([
                    this.audioContext.suspend().catch(() => undefined),
                    // A `suspend()` that never settles would wedge this loop,
                    // and with it every resume after it — the one outcome
                    // worse than a pause that keeps the graph alive a while
                    // longer. Nothing is emulated meanwhile either way: the
                    // worker has already stopped.
                    delay(Core.AUDIO_TRANSITION_TIMEOUT_MS),
                ]);
            }
        }
    }

    /**
     * Whether the browser is still holding the audio back, and with it the
     * machine.
     *
     * Not a sound problem: the drive loop is clocked by the audio worklet
     * asking for samples — see the head of `vb-worker.ts` — so a context that
     * is not really producing emulates nothing at all. A window nobody has
     * touched is exactly that, which is why the second player's window shows a
     * black picture until they touch it.
     *
     * Asked of the clock, because `state` cannot answer it: Firefox reports
     * `running` for a context the autoplay policy is still holding back, and
     * `currentTime` standing still is the only thing that gives it away. Two
     * waits, because `resume()` is asynchronous even when it is allowed — the
     * first for the attempt to settle, or for `within` to pass if it never
     * does, and the second for the clock to have had a chance to move.
     */
    async audioStillBlocked(within = 750): Promise<boolean> {
        await Promise.race([this.audioResume ?? Promise.resolve(), delay(within)]);
        const before = this.audioContext.currentTime;
        await delay(250);
        return this.audioContext.currentTime === before;
    }

    /**
     * Start the audio again on the next thing the person does.
     *
     * Armed whenever the machine starts, without first asking whether the
     * audio needs it: `state` is not to be trusted for that — see
     * {@link audioStillBlocked} — and resuming a context that is already
     * producing costs nothing. One listener at a time, taken down by the first
     * gesture, because a second player pressing a button to play has made
     * exactly the gesture the browser was holding out for.
     */
    protected armAudioUnlock(): void {
        if (this.audioUnlock) {
            return;
        }
        const unlock = (): void => {
            this.audioContext.resume()
                .then(() => this.onDidUnblockAudioEmitter.fire())
                .catch(() => undefined);
            this.disarmAudioUnlock();
        };
        // Captured, so a handler that stops the event from traveling — the
        // emulator's own key handling does — cannot swallow the gesture.
        const types = ['pointerdown', 'keydown', 'touchstart'] as const;
        for (const type of types) {
            window.addEventListener(type, unlock, true);
        }
        this.audioUnlock = () => {
            for (const type of types) {
                window.removeEventListener(type, unlock, true);
            }
            this.audioUnlock = undefined;
        };
    }

    protected disarmAudioUnlock(): void {
        this.audioUnlock?.();
    }

    /**
     * Set the emulation rate, where 1 is real time. Above 1 fast forwards,
     * below 1 runs in slow motion.
     */
    async setSpeed(speed: number): Promise<void> {
        await this.request('setSpeed', { speed });
    }

    /** Advance every simulation by one frame. Only useful while suspended. */
    async stepFrame(): Promise<void> {
        await this.request('stepFrame', {});
    }

    /**
     * Configure the rewind history.
     *
     * Snapshots are stored uncompressed, so the budget divided by the state
     * size is how many are kept, and granularity trades resolution for
     * duration.
     */
    async setRewind(enabled: boolean, granularity: number, budgetBytes: number): Promise<void> {
        await this.request('setRewind', { enabled, granularity, budgetBytes });
    }

    /**
     * Step back up to `count` entries of history at once.
     *
     * Returns how many were applied, so a caller pacing playback can tell that
     * the history is exhausted. Stepping several entries in one call keeps the
     * intermediate states off the screen and costs a single round trip.
     */
    async rewindStep(count = 1): Promise<number> {
        return this.request('rewindStep', { count });
    }

    // --- RetroAchievements -------------------------------------------------

    /** Log in with a password; resolves to the account and its API token. */
    async raLoginPassword(username: string, password: string): Promise<VesRaUser> {
        return this.request('raLoginPassword', { username, password });
    }

    /** Log in with a stored API token. */
    async raLoginToken(username: string, token: string): Promise<VesRaUser> {
        return this.request('raLoginToken', { username, token });
    }

    async raLogout(): Promise<void> {
        await this.request('raLogout', {});
    }

    /** Feed the engine the answer to a server call it asked for. */
    async raProvideResponse(requestId: number, status: number, body: string): Promise<void> {
        await this.request('raProvideResponse', { requestId, status, body });
    }

    /** Unload the current set, keeping the account. */
    async raUnloadGame(): Promise<void> {
        await this.request('raUnloadGame', {});
    }

    /** Tell the engine the machine was reset. */
    async raReset(): Promise<void> {
        await this.request('raReset', {});
    }

    /**
     * Turn the achievement engine's hardcore flag on or off. Set before
     * {@link Sim.raLoadGame} so a set loads in the right mode.
     */
    async raSetHardcore(enabled: boolean): Promise<void> {
        await this.request('raSetHardcore', { enabled });
    }

    /**
     * One page of a leaderboard's entries. `firstEntry` is 1-based and
     * ignored when `aroundUser` asks for the page the player is in instead.
     */
    async raFetchLeaderboardEntries(
        leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean,
    ): Promise<VesRaLeaderboardEntries> {
        return this.request('raFetchLeaderboardEntries', { leaderboardId, firstEntry, count, aroundUser });
    }

    async request<K extends CommandName>(
        command: K,
        params: Params<K>,
        transfer: Transferable[] = []
    ): Promise<Result<K>> {
        if (this.disposed) {
            throw new Error('The emulator core has been disposed.');
        }
        const id = this.nextRequestId++;
        return new Promise<Result<K>>((resolve, reject) => {
            this.pending.set(id, { resolve: result => resolve(result as Result<K>), reject });
            const request: Request<K> = { id, command, params };
            this.worker.postMessage(request, transfer);
        });
    }

    protected onWorkerMessage(message: Outbound): void {
        if (isVbEvent(message)) {
            if (message.event === 'error') {
                this.onErrorEmitter.fire(message.payload.message);
            } else if (message.event === 'frame') {
                const frame = message.payload;
                const attached = this.mainThreadRenderers.get(frame.sim);
                const tap = this.videoTaps.get(frame.sim);
                try {
                    if (attached?.presentation === frame.presentation) {
                        attached.renderer.present(new Uint8Array(frame.pixels), frame.colorMode);
                    } else if (tap?.presentation === frame.presentation) {
                        tap.handle(frame);
                    }
                } catch (error) {
                    this.onErrorEmitter.fire(error instanceof Error ? error.message : String(error));
                } finally {
                    this.worker.postMessage({
                        videoFrame: {
                            sim: frame.sim,
                            presentation: frame.presentation,
                            pixels: frame.pixels,
                        },
                    }, [frame.pixels]);
                }
            } else if (message.event === 'terminal') {
                this.onTerminalEmitter.fire(message.payload);
            } else if (message.event === 'link') {
                this.onLinkEmitter.fire(message.payload);
            } else if (message.event === 'esSound') {
                this.onEsSoundEmitter.fire(message.payload);
            } else if (message.event === 'sram') {
                this.onSramEmitter.fire(message.payload);
            } else if (message.event === 'pointerWrite') {
                this.onPointerWriteEmitter.fire(message.payload);
            } else if (message.event === 'speed') {
                this.onSpeedEmitter.fire(message.payload);
            } else if (message.event === 'digest') {
                this.onDigestEmitter.fire(message.payload);
            } else if (message.event === 'progress') {
                this.onProgressEmitter.fire(message.payload);
            } else if (message.event === 'awaitingInput') {
                this.onAwaitingInputEmitter.fire(message.payload);
            } else if (message.event === 'stopped') {
                this.onStoppedEmitter.fire(message.payload);
            } else if (message.event === 'stalled') {
                this.onStalledEmitter.fire(message.payload);
            } else if (message.event === 'retroAchievements') {
                for (const raEvent of message.payload.events) {
                    this.onRetroAchievementsEmitter.fire(raEvent);
                }
            }
            return;
        }

        const response = message as Response;
        const pending = this.pending.get(response.id);
        if (!pending) {
            return;
        }
        this.pending.delete(response.id);
        if (response.error !== undefined) {
            pending.reject(new Error(response.error));
        } else {
            pending.resolve(response.result);
        }
    }

    dispose(): void {
        if (this.disposed) {
            return;
        }
        this.disposed = true;
        for (const pending of this.pending.values()) {
            pending.reject(new Error('The emulator core has been disposed.'));
        }
        this.pending.clear();
        this.disarmAudioUnlock();
        for (const sim of [...this.mainThreadRenderers.keys()]) {
            this.detachCanvas(sim);
        }
        this.screenshotRenderer?.dispose();
        this.screenshotRenderer = undefined;
        this.audioNode.disconnect();
        this.worker.terminate();
        this.audioContext.close();
        this.onDidUnblockAudioEmitter.dispose();
        this.onErrorEmitter.dispose();
        this.onTerminalEmitter.dispose();
        this.onLinkEmitter.dispose();
        this.onPointerWriteEmitter.dispose();
        this.onSpeedEmitter.dispose();
        this.onDigestEmitter.dispose();
        this.onProgressEmitter.dispose();
        this.onAwaitingInputEmitter.dispose();
        this.onStoppedEmitter.dispose();
        this.onStalledEmitter.dispose();
        this.onRetroAchievementsEmitter.dispose();
    }
}

/** One emulated Virtual Boy, belonging to a {@link Core} session. */
export class Sim implements Disposable {

    protected disposed = false;
    /** What this DOM-side handle last asked the worker to emulate. */
    protected vbcHardware = true;
    /** Mirrored so a page-side renderer can be configured before attachment. */
    protected displayMode = VB_DEFAULT_DISPLAY_MODE;

    protected readonly onRestartEmitter = new Emitter<void>();
    /**
     * The machine has started over: reset, or a different cartridge in it.
     *
     * A simulation outlives both, so nothing downstream can tell either of
     * them from the machine simply carrying on — and anything holding a
     * picture of what this machine has done since it started needs to know,
     * because none of it is true any more. Fired here rather than in the
     * worker because both are requests made through this object.
     */
    readonly onRestart: Event<void> = this.onRestartEmitter.event;

    constructor(
        protected readonly core: Core,
        readonly handle: SimHandle
    ) { }

    /**
     * Attach the presentation canvas.
     *
     * Ordinarily control is transferred to the worker. On the Linux desktop
     * the element stays on this thread and receives transferred frame buffers,
     * because WebKitGTK cannot create the worker's WebGL context.
     */
    async attachCanvas(canvas: HTMLCanvasElement): Promise<void> {
        await this.core.attachCanvas(this.handle, canvas, this.displayMode);
    }

    async setCartRom(rom: ArrayBuffer): Promise<void> {
        await this.core.request('setCartRom', { sim: this.handle, rom }, [rom]);
        this.onRestartEmitter.fire();
    }

    async setCartRam(ram: ArrayBuffer): Promise<void> {
        await this.core.request('setCartRam', { sim: this.handle, ram }, [ram]);
    }

    /**
     * Cartridge save RAM, or the first `length` bytes of it.
     *
     * Ask for a length wherever one is known: the window is the whole 16 MiB
     * of Game Pak RAM, and this copies what it is asked for across a worker
     * boundary. {@link cartRamInfo} is how a caller finds out what to ask for.
     */
    async getCartRam(length?: number): Promise<ArrayBuffer> {
        return this.core.request('getCartRam', { sim: this.handle, length });
    }

    /** How big the save window is, and how far into it the game has written. */
    async cartRamInfo(): Promise<{ size: number, used: number }> {
        return this.core.request('cartRamInfo', { sim: this.handle });
    }

    async reset(): Promise<void> {
        await this.core.request('reset', { sim: this.handle });
        this.onRestartEmitter.fire();
    }

    /** Select original Virtual Boy or VB Color hardware; activation remains software-controlled. */
    async setHardwareMode(vbc: boolean): Promise<void> {
        // The worker returns the model the loaded core actually selected. A
        // pre-Phase-5 WASM has no hardware-model switch and therefore reports
        // its always-present VBC model rather than making an old bundled core
        // fail to start. A rebuilt Phase-5 core returns the requested value.
        this.vbcHardware = await this.core.request('setHardwareMode', { sim: this.handle, vbc });
    }

    get isVbcHardware(): boolean {
        return this.vbcHardware;
    }

    /** Set the currently pressed buttons as a VbKey bitmask. */
    /**
     * Book a controller mask against a future frame.
     *
     * The frame-numbered counterpart of {@link setKeys}, for a session where
     * two machines have to see the same press on the same frame. See
     * `queueKeys` in `vb-protocol.ts`.
     */
    async queueKeys(frame: number, keys: number): Promise<void> {
        await this.core.request('queueKeys', { sim: this.handle, frame, keys });
    }

    /**
     * Book writes against a future frame.
     *
     * The frame-numbered counterpart of {@link setCheats} and
     * {@link writeMemory}, for a session where two machines have to see the
     * same change on the same frame. See `queueEdits` in `vb-protocol.ts`.
     */
    async queueEdits(frame: number, edits: ScheduledEdit[]): Promise<void> {
        await this.core.request('queueEdits', { sim: this.handle, frame, edits });
    }

    /** Refuse to run past the input booked with {@link queueKeys}. */
    async setLockstep(enabled: boolean): Promise<void> {
        await this.core.request('setLockstep', { sim: this.handle, enabled });
    }

    /**
     * A digest of everything the emulated program can see, with the frame it
     * was taken at. For telling two machines that should agree apart.
     */
    async stateDigest(): Promise<{ frame: number, digest: number }> {
        return this.core.request('stateDigest', { sim: this.handle });
    }

    /**
     * Report that digest every `frames` frames, or stop, with zero.
     *
     * Taken on a frame number rather than on request, so that two machines
     * that should be identical produce theirs at the same point in the run and
     * can be compared at all. Arrives as {@link Core.onDigest}.
     */
    async setDigestPeriod(frames: number): Promise<void> {
        await this.core.request('setDigestPeriod', { sim: this.handle, frames });
    }

    /** This machine's handle, for telling its events from another's. */
    get id(): SimHandle {
        return this.handle;
    }

    async setKeys(keys: number): Promise<void> {
        await this.core.request('setKeys', { sim: this.handle, keys });
    }

    /**
     * Select the display mode. This also resizes the presentation surface,
     * since the stereo layouts present at different geometries.
     */
    async setDisplayMode(mode: DisplayMode): Promise<void> {
        this.displayMode = mode;
        this.core.setMainThreadDisplayMode(this.handle, mode);
        await this.core.request('setDisplayMode', { sim: this.handle, mode });
    }

    /**
     * Encode the currently presented frame as a PNG.
     *
     * With no `mode` this is what is on screen, at its own size. With one, the
     * frame is composed again to it — a screenshot need not be the mode, the
     * palette or the size the game is being played in.
     */
    async capture(mode?: DisplayMode, scale?: number): Promise<ArrayBuffer> {
        if (this.core.mainThreadVideo) {
            return this.core.captureMainThread(
                this.handle, mode, scale);
        }
        return this.core.request('capture', { sim: this.handle, mode, scale });
    }

    /**
     * Take a copy of every frame this machine presents, for a recording.
     *
     * Pass nothing to stop. See {@link Core.setVideoTap} for what the handler
     * may and may not do with the buffer it is given.
     */
    async setVideoTap(handle?: (frame: Frame) => void): Promise<void> {
        await this.core.setVideoTap(this.handle, handle);
    }

    /** Snapshot the entire machine. */
    async saveState(): Promise<ArrayBuffer> {
        return this.core.request('saveState', { sim: this.handle });
    }

    /** Restore a snapshot. The buffer is transferred. */
    async loadState(state: ArrayBuffer): Promise<void> {
        await this.core.request('loadState', { sim: this.handle, state }, [state]);
    }

    /**
     * Start recording this session so it can be profiled afterwards.
     *
     * Costs a snapshot now and a few bytes per frame after — the input, not
     * the execution. What makes that enough is that emulation is
     * deterministic: replaying the same input from the same state reproduces
     * the run exactly, so the profile can be collected later and exhaustively
     * rather than sampled while the game is trying to run.
     */
    async startProfileRecording(): Promise<void> {
        await this.core.request('startProfileRecording', { sim: this.handle });
    }

    /** Stop recording and take what was recorded. */
    async stopProfileRecording(): Promise<Recording> {
        return this.core.request('stopProfileRecording', { sim: this.handle });
    }

    /**
     * Replay a recording and collect a call tree from every instruction in it.
     *
     * Runs on a simulation of its own, so this one carries on undisturbed, but
     * it occupies the worker until it finishes — roughly a sixth of the time
     * that was recorded.
     */
    async replayProfile(recording: Recording): Promise<ProfileResult> {
        return this.core.request('replayProfile', { sim: this.handle, recording });
    }

    /**
     * Follow every instruction as it runs, keeping a per-frame profile.
     *
     * The other kind of profiling: `startProfileRecording` writes down input
     * now and collects the answer afterwards, this measures the run as it
     * happens so a panel can show where the current frame is going. It costs a
     * callback on every instruction, so whoever switches it on owns switching
     * it off again.
     */
    async setLiveProfiler(enabled: boolean, window?: number): Promise<void> {
        await this.core.request('setLiveProfiler', { sim: this.handle, enabled, window });
    }

    /**
     * The last window of profiled frames, or undefined if none is being kept.
     *
     * @param pin a frame to unpack alongside the aggregate, by its number. It
     *     comes back only while that frame is still in the window.
     */
    async readLiveProfile(pin?: number): Promise<LiveProfileSnapshot | undefined> {
        return this.core.request('readLiveProfile', { sim: this.handle, pin });
    }

    /**
     * Wire this simulation to another over the link port, or pass null to
     * disconnect. The peer must belong to the same session.
     *
     * `order` is which end of the cable *this* simulation is, and the peer
     * takes the other. Both windows of a link session name the same end for
     * the same player's machine, which is what makes them emulate the pair
     * identically — see `setPeer` in `vb-protocol.ts`.
     */
    async setPeer(peer: Sim | undefined, order?: 1 | 2): Promise<void> {
        await this.core.request('setPeer', { sim: this.handle, peer: peer?.handle ?? 0, order });
    }

    /** Read a window of the address space as the CPU sees it. */
    /**
     * Read a rectangle of the composited framebuffer as RGBA bytes.
     *
     * The core composites eye-packed, so the red channel is the left eye's
     * brightness and the green channel the right eye's.
     */
    async readPixels(x: number, y: number, width: number, height: number): Promise<ArrayBuffer> {
        return this.core.request('readPixels', { sim: this.handle, x, y, width, height });
    }

    /**
     * The framebuffer averaged into a stereo grid — legacy brightness or VBC
     * RGB555, as identified by the result. See the protocol for why it is
     * averaged over there rather than here.
     */
    async readBackdrop(columns: number, rows: number): Promise<Backdrop> {
        return this.core.request('readBackdrop', { sim: this.handle, columns, rows });
    }

    /**
     * Recomposite and present this simulation's current video state.
     *
     * Costs one frame's worth of compositing and changes nothing else. Only
     * worth asking for while the machine is paused: running, the next frame
     * break does it anyway.
     */
    async refreshFrame(): Promise<void> {
        await this.core.request('refreshFrame', { sim: this.handle });
    }

    async readMemory(address: number, length: number): Promise<ArrayBuffer> {
        return this.core.request('readMemory', { sim: this.handle, address, length });
    }

    /** Write bytes into the address space. The buffer is transferred. */
    async writeMemory(address: number, data: ArrayBuffer): Promise<void> {
        await this.core.request('writeMemory', { sim: this.handle, address, data }, [data]);
    }

    async readRegisters(): Promise<Registers> {
        return this.core.request('readRegisters', { sim: this.handle });
    }

    /**
     * Disassemble from an address, or from `before` instructions earlier.
     *
     * Going backwards is the core's job rather than ours: instructions here
     * are two or four bytes and nothing in the bytes before an address says
     * which, so only something that decodes forwards from a known point can
     * say where the previous instruction began.
     */
    async disassemble(
        address: number, count: number, before = 0,
    ): Promise<DisassemblyLine[]> {
        return this.core.request('disassemble', { sim: this.handle, address, count, before });
    }

    /**
     * Arm this simulation's breakpoints, as the whole set.
     *
     * An empty list disarms them and takes the per-instruction callback back
     * off the core, which is where the cost of having any lives.
     */
    async setBreakpoints(addresses: number[]): Promise<void> {
        await this.core.request('setBreakpoints', { sim: this.handle, addresses });
    }

    /** Run one instruction and stop on the next. Only while suspended. */
    async stepInstruction(): Promise<void> {
        await this.core.request('stepInstruction', { sim: this.handle });
    }

    /**
     * Arm a one-shot stop at an address. The caller resumes into it.
     *
     * Two calls rather than one because starting the machine belongs to
     * whoever owns the pause — see `runTo` in `vb-protocol.ts`.
     */
    async runTo(address: number): Promise<void> {
        await this.core.request('runTo', { sim: this.handle, address });
    }

    /** This simulation stopping on an instruction; see {@link Core.onStopped}. */
    onStopped(listener: (stop: { address: number, reason: StopReason }) => void): Disposable {
        return this.core.onStopped(event => {
            if (event.sim === this.handle) {
                listener({ address: event.address, reason: event.reason });
            }
        });
    }

    /**
     * Start or stop watching the terminal port for this simulation.
     *
     * Capturing costs a callback on every CPU write, so it should only be on
     * while something is displaying the output.
     */
    async setTerminalCapture(enabled: boolean): Promise<void> {
        await this.core.request('setTerminalCapture', { sim: this.handle, enabled });
    }

    /** Terminal output from this simulation, ignoring any others in the session. */
    onTerminal(listener: (text: string) => void): Disposable {
        return this.core.onTerminal(event => {
            if (event.sim === this.handle) {
                listener(event.text);
            }
        });
    }

    /**
     * Start or stop watching the link port for bytes sent over it.
     *
     * Costs a callback on every CPU write while it is on, so it belongs on
     * only while something is on the other end of the cable to receive them.
     */
    async setLinkCapture(enabled: boolean): Promise<void> {
        await this.core.request('setLinkCapture', { sim: this.handle, enabled });
    }

    /** Link port traffic from this simulation, ignoring any others in the session. */
    onLink(listener: (bytes: number[]) => void): Disposable {
        return this.core.onLink(event => {
            if (event.sim === this.handle) {
                listener(event.bytes);
            }
        });
    }

    /**
     * Watch the ESSound port, or stop watching it. Costs the same callback on
     * every CPU write the captures above do, so it is left off unless the ROM
     * has audio files for it to play.
     */
    async setEsSoundCapture(enabled: boolean): Promise<void> {
        await this.core.request('setEsSoundCapture', { sim: this.handle, enabled });
    }

    /** Halfwords this simulation wrote to the ESSound port, once watched. */
    onEsSound(listener: (commands: number[]) => void): Disposable {
        return this.core.onEsSound(event => {
            if (event.sim === this.handle) {
                listener(event.commands);
            }
        });
    }

    /**
     * Watch the cartridge's save region, or stop watching it.
     *
     * Costs a call out of the core on every access to it, so — like the
     * captures above — it is on only while something is looking, and the two
     * directions are asked for separately because a game reads its save far
     * more often than it writes one. Both false is off.
     */
    async setSramCapture(writes: boolean, reads: boolean): Promise<void> {
        await this.core.request('setSramCapture', { sim: this.handle, writes, reads });
    }

    /** Touches of this simulation's save region, once watched. */
    onSram(listener: (runs: SramRun[]) => void): Disposable {
        return this.core.onSram(event => {
            if (event.sim === this.handle) {
                listener(event.runs);
            }
        });
    }

    /**
     * Follow a pointer variable, reporting each 32-bit value stored to it, or
     * pass 0 to stop. One address at a time, and it costs the same callback on
     * every CPU write that the captures above do.
     */
    /**
     * Repeat these writes at every frame break, or none to stop.
     *
     * The core applies them itself rather than the caller writing on a timer;
     * see the protocol's setCheats.
     */
    async setCheats(codes: VbCheatWrite[]): Promise<void> {
        await this.core.request('setCheats', { sim: this.handle, codes });
    }

    async setPointerWatch(address: number): Promise<void> {
        await this.core.request('setPointerWatch', { sim: this.handle, address });
    }

    /** Values stored to the watched address by this simulation. */
    onPointerWrite(listener: (values: number[]) => void): Disposable {
        return this.core.onPointerWrite(event => {
            if (event.sim === this.handle) {
                listener(event.values);
            }
        });
    }

    /**
     * The VSU as it stands: its map (VB_VSU_BASE, VB_VSU_MAP_BYTES bytes — the
     * waveform banks, the modulation table and the six channel register
     * blocks) and how loud its last frame of sound was.
     *
     * Composed by the worker from the core's own state rather than read out of
     * the VSU's address range, which real hardware and this core both refuse.
     * Rejects, with what it was looking for, on a core whose VSU state cannot
     * be found. See readVsu in `vb-protocol.ts`.
     */
    async readVsu(): Promise<VsuReading> {
        return this.core.request('readVsu', { sim: this.handle });
    }

    /**
     * Silence channels of this machine's VSU without the game knowing, or
     * — with no bits set — let them all sound again.
     *
     * The emulator's own mixer rather than a write to the VSU, so the game's
     * state is left exactly as it was and the panel goes on showing what each
     * muted channel is playing. See setVsuMutes in `vb-protocol.ts`.
     */
    async setVsuMutes(channels: number): Promise<void> {
        await this.core.request('setVsuMutes', { sim: this.handle, channels });
    }

    /**
     * Start or stop noting which palettes are painting the picture.
     *
     * Costs the same callback on every CPU write the captures above do, so it
     * is on only while somebody is looking at the answer — the color editor,
     * which is the only thing that asks.
     */
    async setDrawnPaletteCapture(enabled: boolean): Promise<void> {
        await this.core.request('setDrawnPaletteCapture', { sim: this.handle, enabled });
    }

    /**
     * The palettes drawn since the last call, as a 256-bit set; taking it
     * clears it. All zero until setDrawnPaletteCapture(true).
     */
    async takeDrawnPalettes(): Promise<ArrayBuffer> {
        return this.core.request('takeDrawnPalettes', { sim: this.handle });
    }

    /**
     * Identify this simulation's ROM by its RetroAchievements hash and load its
     * achievement set.
     *
     * Returns as soon as the request is in flight; the outcome arrives on
     * {@link Core.onRetroAchievements}.
     */
    async raLoadGame(hash: string): Promise<void> {
        await this.core.request('raLoadGame', { sim: this.handle, hash });
    }

    /** Output volume, 0 to 10. */
    async setVolume(volume: number): Promise<void> {
        await this.core.request('setVolume', { sim: this.handle, volume });
    }

    /** Stereo panning, -1 to +1. */
    async setPanning(panning: number): Promise<void> {
        await this.core.request('setPanning', { sim: this.handle, panning });
    }

    dispose(): void {
        if (this.disposed) {
            return;
        }
        this.disposed = true;
        this.onRestartEmitter.dispose();
        this.core.detachCanvas(this.handle);
        this.core.request('deleteSim', { sim: this.handle }).catch(() => {
            // The core may already be gone; nothing to release in that case.
        });
    }
}
