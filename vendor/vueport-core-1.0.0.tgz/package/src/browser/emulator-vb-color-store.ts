/**
 * The VB Color colorization for the running game: finding it, building it into
 * a ROM patch, and showing a person's palette edits the moment they make them.
 *
 * A colorization is a format-2 patch document (`VBC_PATCH_FORMAT.md`): the
 * palettes an editor may change, and one compiled BPS carrying everything else
 * — including every decision about which palette is shown when. VUEPort runs
 * none of that itself. It builds the ROM the document makes of the source ROM
 * and hands it to the patch store as one more ROM patch, which is also why it
 * is switched off in hardcore mode like any other.
 *
 * Two paths reach the screen from one set of colors, and the design rests on
 * keeping them apart:
 *
 *   - the **patch** path — document, edits and source ROM through the exporter
 *     into a BPS, handed to the patch store. What a restart runs, and what an
 *     export carries;
 *   - the **live** path — the same colors written into the *running* ROM's
 *     palette table, which the patch's native code copies from, and into
 *     Color RAM when that palette is on show right now.
 *
 * An edit does both. The live write is what makes it visible without
 * interrupting play; the patch is rebuilt behind it, without a restart, so
 * that the next restart runs the same colors.
 *
 * The live path writes the table rather than pinning Color RAM, and that is
 * the difference this format makes. The native code decides which colors sit
 * in which Color RAM slot, and may change its mind — per level, per form, per
 * theme — so a pinned slot would fight it every frame, while an edited table
 * is simply what it copies next. The one direct Color RAM write goes only to a
 * slot that is showing the palette being edited, which is known by the slot
 * holding exactly what the table entry held.
 */

import { Emitter, Event } from '../common/emulator-events';
import {
    VesColorPatch as ColorPatch,
    VesColorPatchChoice,
    colorPatchAutoApplied,
    colorPatchForRom,
} from '../common/emulator-color-patches';
import {
    VB_COLOR_COLORS_PER_PALETTE,
    VbColorError,
    VB_COLOR_MAX_PALETTE_NAME,
    VbColorObject,
    VbColorOverrides,
    VbColorPaletteNames,
    VbColorPaletteTable,
    VbColorPaletteView,
    VbColorScene,
    VbcPatchDocument,
    applyOverrides,
    buildColorizedRom,
    isVbcPatchDocument,
    paletteBytes,
    resolvePalettes,
    sanitizeNames,
    sanitizeOverrides,
    snapToRgb555,
    vbColorOverrideKey,
    vbcObjects,
    vbcPaletteTable,
    vbcPatchBytes,
    vbcScenes,
} from '../common/emulator-vb-color';
import {
    createColorRomPatch,
    createGenericColorDocument,
    createdColorPatchEntry,
    genericColorRefusal,
    isCreatedColorPatchId,
} from '../common/emulator-vb-color-create';
import { parseRomHeader } from './emulator-types';
import {
    VBC_CRAM_BASE,
    VBC_CRAM_PALETTES,
    VBC_CRAM_PALETTE_BYTES,
    VB_ROM_BASE,
} from '../common/vb-constants';
import { PatchStore } from './emulator-patch-store';

/** What the editor needs from the machine, so the store needs no host. */
export interface ColorSim {
    readMemory(address: number, length: number): Promise<ArrayBuffer>;
    writeMemory(address: number, data: ArrayBuffer): Promise<void>;
    /** Watch the Color Framebuffer for the palette ids being drawn into it. */
    setDrawnPaletteCapture(enabled: boolean): Promise<void>;
    /** Those ids as a 256-bit set, since the last call, which this clears. */
    takeDrawnPalettes(): Promise<ArrayBuffer>;
    /** Show the machine's current video state again, having changed none of it. */
    refreshFrame(): Promise<void>;
}

/** How far along the colorization for the running ROM is. */
export type ColorStatus =
    /** No colorization ships for this ROM. */
    | 'none'
    /** Its document is being fetched and built. */
    | 'loading'
    /** Loaded and built; `applied` says whether it is switched on. */
    | 'ready'
    /** The document could not be loaded or built. `error` says why. */
    | 'failed';

/** How long to wait after a color changes before rebuilding the patch. */
const REBUILD_DEBOUNCE_MS = 200;

/**
 * How long a sample collects for.
 *
 * Long enough to be sure of catching a whole frame however the emulator is
 * running at that moment — a dozen at full speed, still several at the slowest
 * speed the time controls offer — and short enough that the button feels like
 * it answered rather than thought about it.
 */
const DRAWN_SAMPLE_MS = 250;

/** Bytes in a drawn-palette set — 256 palettes, one bit each. */
const DRAWN_SET_BYTES = 32;

/** Unpack that set: palette `id` sits in bit `id & 7` of byte `id >> 3`. */
function decodeDrawnPalettes(buffer: ArrayBuffer): Set<number> {
    const bits = new Uint8Array(buffer);
    const drawn = new Set<number>();
    for (let at = 0; at < Math.min(bits.length, DRAWN_SET_BYTES); at += 1) {
        const byte = bits[at];
        if (byte === 0) {
            continue;
        }
        for (let bit = 0; bit < 8; bit += 1) {
            if ((byte & (1 << bit)) !== 0) {
                drawn.add(at * 8 + bit);
            }
        }
    }
    return drawn;
}

/** How long each half of a locate flash lasts. */
const FLASH_STEP_MS = 90;

/** The color a flash paints, chosen because nothing in these games is it. */
const FLASH_COLOR = '#FF00FF';

function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
    return a.length === b.length && a.every((byte, at) => byte === b[at]);
}

export class ColorStore {

    protected readonly onDidChangeEmitter = new Emitter<void>();
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    protected _entry: ColorPatch | undefined;
    protected _document: VbcPatchDocument | undefined;
    /** Where the live path writes; undefined for a patch that cannot be edited. */
    protected table: VbColorPaletteTable | undefined;
    protected _status: ColorStatus = 'none';
    protected _error: string | undefined;
    protected _building = false;
    /**
     * Bumped by every {@link load}, so a load still fetching when the next
     * ROM arrives knows it has been overtaken.
     */
    protected generation = 0;
    /** Bumped by every build, so an older build finishing late cannot replace a newer one. */
    protected builds = 0;
    protected rebuildHandle: ReturnType<typeof setTimeout> | undefined;

    protected sim: ColorSim | undefined;
    /**
     * Whether the machine attached is running the colorized ROM.
     *
     * Decided when the machine arrives, because that is when its ROM was
     * decided. The live path writes into the palette table's place in the
     * running ROM, and doing that to a ROM the patch was never applied to
     * would be writing colors over game code.
     */
    protected simRunsPatch = false;
    /** Live writes, one after another: each reads the slot the one before may have written. */
    protected liveQueue: Promise<void> = Promise.resolve();

    /**
     * The palettes found painting the last time somebody asked, or undefined
     * while nobody has.
     *
     * A snapshot and not a subscription: it changes when {@link sampleDrawn} is
     * called and at no other time, so the list under it holds still to be read.
     */
    protected _drawn: Set<number> | undefined;
    protected _sampling = false;
    protected _paused = false;

    /** Which color set a flash is painting, so a second one cannot start over it. */
    protected flashing: string | undefined;

    /** The running ROM's CRC32, which is what a created colorization is filed under. */
    protected romId: string | undefined;
    /** Whether one is being compiled right now. */
    protected _creating = false;
    /**
     * The four colors somebody last copied, for pasting into another set.
     *
     * Kept here and not in the panel because the panel has two mounts — the
     * strip beside the screen and the docked one — and copying in one to paste
     * in the other is exactly the thing somebody would try. Not persisted: a
     * clipboard that outlived the session would be a surprise, not a feature.
     */
    protected _copied: string[] | undefined;

    constructor(
        protected readonly patches: PatchStore,
        /** Reads and writes the stored overrides — the host's settings. */
        protected readonly overridesFor: (id: string) => VbColorOverrides,
        protected readonly saveOverrides: (id: string, overrides: VbColorOverrides) => void,
        /**
         * Reads and writes what the palettes have been renamed to — the host's
         * settings again, and a record of their own.
         *
         * Apart from the colors because they are a different shape and because
         * putting the colors back is not the same wish as putting the names
         * back. See `VbColorPaletteNames`.
         */
        protected readonly namesFor: (id: string) => VbColorPaletteNames,
        protected readonly saveNames: (id: string, names: VbColorPaletteNames) => void,
        /**
         * Whether auto-apply is on, and which colorizations are switched off.
         *
         * The host's, and also where hardcore mode says no: a colorization is a
         * ROM patch, and must not come on by itself in a hardcore session.
         */
        protected readonly choice: () => VesColorPatchChoice,
        /**
         * Remember whether this game's colorization should be applied, so that
         * the switch in the panel means something the next time it is opened.
         *
         * The host's, because what it writes are settings and this store has no
         * settings — and because "apply this one" has an implication for the
         * master switch that only the host can act on. See its implementation.
         */
        protected readonly rememberApply: (id: string, apply: boolean) => void,
        /**
         * Hand a finished file to the person — the exported colorization.
         *
         * The host's, because where a file goes is the host's question: a
         * download in the browser, a file in the project in the studio. See
         * `VueportStorage.export`.
         */
        protected readonly exportFile: (name: string, data: Uint8Array) => Promise<void>,
        /**
         * Fetches a patch document by the path its catalog entry names.
         *
         * Typed loosely: the host fetches and parses JSON, and {@link load}
         * decides whether what arrived is a document.
         */
        protected readonly loadDocument: (config: string) => Promise<unknown>,
        /**
         * Reads back the colorization made here for the running ROM, if there
         * is one, or undefined.
         *
         * A companion file beside the game, like its saves and its patches,
         * because that is what it is: something that belongs to this ROM and
         * that somebody may want to find, copy or delete without going through
         * VUEPort. The host owns the path — see `EmulatorCompanionFiles`.
         */
        protected readonly loadCreatedDocument: () => Promise<unknown>,
        /** Writes that file, or deletes it when given nothing. */
        protected readonly saveCreatedDocument: (document: VbcPatchDocument | undefined) => Promise<void>,
    ) { }

    get entry(): ColorPatch | undefined {
        return this._entry;
    }

    get document(): VbcPatchDocument | undefined {
        return this._document;
    }

    get status(): ColorStatus {
        return this._status;
    }

    get error(): string | undefined {
        return this._error;
    }

    /** Whether a document is loaded, whatever became of building it. */
    get loaded(): boolean {
        return this._document !== undefined;
    }

    /**
     * Whether its palettes can be edited at all.
     *
     * False for a patch whose BPS has no palette ABI: it runs exactly as it
     * was compiled, and the colors in its document change nothing.
     */
    get editable(): boolean {
        return this.table !== undefined;
    }

    /** Whether a build that switches the colorization on is under way. */
    get building(): boolean {
        return this._building;
    }

    /** Whether the colorization is switched on for the running ROM. */
    get applied(): boolean {
        return this.patches.list.some(patch => patch.id === this.patchId && patch.enabled);
    }

    protected get patchId(): string | undefined {
        return this._entry ? `color:${this._entry.id}` : undefined;
    }

    /** The palettes, in the document's order, with this player's edits over them. */
    get palettes(): VbColorPaletteView[] {
        return this._document ? resolvePalettes(this._document, this.overrides, this.names) : [];
    }

    /** One palette, with this player's edits over it. */
    palette(paletteId: number): VbColorPaletteView | undefined {
        return this.palettes.find(palette => palette.id === paletteId);
    }

    /**
     * This player's edits, as far as they apply to this document.
     *
     * None at all for a patch that cannot be edited, whatever is stored: it
     * would show colors the game will never have.
     */
    protected get overrides(): VbColorOverrides {
        return this._entry && this._document && this.table
            ? sanitizeOverrides(this.overridesFor(this._entry.id), this._document)
            : {};
    }

    /**
     * What this player has renamed the palettes to, as far as they apply.
     *
     * Unlike the colors, a rename is kept for a patch that cannot be edited
     * too: naming what you are looking at is useful whether or not you can
     * change it, and a name reaches no part of the ROM.
     */
    protected get names(): VbColorPaletteNames {
        return this._entry && this._document
            ? sanitizeNames(this.namesFor(this._entry.id), this._document)
            : {};
    }

    /** Whether this palette carries a name of this player's rather than the patch's. */
    isRenamed(paletteId: number): boolean {
        return this.names[String(paletteId)] !== undefined;
    }

    /** How many palettes have been renamed. */
    get renamedCount(): number {
        return Object.keys(this.names).length;
    }

    /**
     * Call a palette something else — or nothing, which gives the patch's own
     * name back.
     *
     * Stored and shown, and that is all that happens: nothing is rebuilt and
     * nothing is written into the running game, because a palette's name is
     * not in the ROM. For a colorization made here, Save folds it into the
     * document like a color; for a shipped one it stays beside the document,
     * as an edit does.
     */
    setPaletteName(paletteId: number, name: string): void {
        const entry = this._entry;
        const palette = this._document?.palettes.find(candidate => candidate.id === paletteId);
        if (!entry || !palette) {
            return;
        }
        const names = { ...this.names };
        const trimmed = name.trim().slice(0, VB_COLOR_MAX_PALETTE_NAME);
        // Empty, or back to what the patch calls it, is the absence of a
        // rename rather than a rename that happens to match.
        if (trimmed.length === 0 || trimmed === palette.name) {
            delete names[String(paletteId)];
        } else {
            names[String(paletteId)] = trimmed;
        }
        this.saveNames(entry.id, names);
        this.onDidChangeEmitter.fire();
    }

    /** What the document says about itself, for the info page. */
    get description(): string | undefined {
        return this._document?.description;
    }

    get scenes(): VbColorScene[] {
        return this._document ? vbcScenes(this._document) : [];
    }

    /**
     * The objects of one scene, or all of them when no scene is given.
     *
     * An object that owns exactly one palette takes that palette's name, so
     * renaming a palette renames the row it is listed under. For a document
     * with no objects of its own, and for one generated here, an object *is* a
     * palette; where an object groups several — Wario, the results screen —
     * the group has a name of its own and keeps it.
     */
    objects(sceneId?: string): VbColorObject[] {
        const names = this.names;
        return (this._document ? vbcObjects(this._document) : [])
            .filter(object => sceneId === undefined || object.sceneId === sceneId)
            .map(object => {
                const renamed = object.palettes.length === 1
                    ? names[String(object.palettes[0])]
                    : undefined;
                return renamed ? { ...object, name: renamed } : object;
            });
    }

    /** Which palettes an object owns — the editor's unit of work. */
    palettesOf(object: VbColorObject): number[] {
        return object.palettes;
    }

    /** Whether a palette, or any of its variants, carries an edit of this player's. */
    isEdited(paletteId: number): boolean {
        return Object.keys(this.overrides).some(key => key.split('/')[0] === String(paletteId));
    }

    /** Whether one color set — the palette itself, or one of its variants — carries one. */
    isSetEdited(paletteId: number, variant?: string): boolean {
        return this.overrides[vbColorOverrideKey(paletteId, variant)] !== undefined;
    }

    /** How many palettes carry an edit, counting a palette once however many of its sets do. */
    get editedCount(): number {
        return new Set(Object.keys(this.overrides).map(key => key.split('/')[0])).size;
    }

    /** What the last sample found, or undefined if none has been taken. */
    get drawn(): ReadonlySet<number> | undefined {
        return this._drawn;
    }

    /** Whether a sample is collecting right now. */
    get sampling(): boolean {
        return this._sampling;
    }

    /**
     * Whether the machine is stopped, and so drawing nothing to sample.
     *
     * Kept here rather than read off a host because the editor has two mounts —
     * the strip beside the screen and the docked panel — and only this fires at
     * both of them. Pushed in rather than polled, so the button goes dead the
     * moment the game is paused instead of at the next tick of something.
     */
    get paused(): boolean {
        return this._paused;
    }

    /**
     * Say whether the machine is running.
     *
     * False by default, which is not an assumption that it is: a store with no
     * machine attached refuses a sample anyway. It is so that a host which
     * never says leaves the button working rather than permanently dead.
     */
    setPaused(paused: boolean): void {
        if (this._paused !== paused) {
            this._paused = paused;
            this.onDidChangeEmitter.fire();
        }
    }

    /**
     * Attach the machine that is running now, or none.
     *
     * A new machine was started from whatever the patch store held at that
     * moment, which a rebuild still under way may not have caught up with — so
     * the edits are said to it again. See {@link reconcile}.
     */
    setSim(sim: ColorSim | undefined): void {
        this.sim = sim;
        this.simRunsPatch = sim !== undefined && this.applied;
        // A sample describes the machine it was taken from, and this is a
        // different one. Any sample in flight is left to find that out for
        // itself — it holds the machine it started on.
        this._drawn = undefined;
        if (sim) {
            this.reconcile();
        }
    }

    /**
     * Find and build the colorization for a ROM, if one ships for it.
     *
     * Built here rather than when it is switched on, so that the patch is on
     * the chain the first run applies — the host calls this after the patch
     * store has the source ROM and before the machine starts — and so that a
     * document that cannot be built says so as the game opens rather than
     * when somebody reaches for it.
     */
    async load(romId: string | undefined, sourceRom: Uint8Array | undefined): Promise<void> {
        const generation = ++this.generation;
        this.cancelRebuild();
        this._entry = undefined;
        this._document = undefined;
        this.table = undefined;
        this._error = undefined;
        this._drawn = undefined;
        this.romId = romId;

        // Found whatever the switches say, and applied only if they say so:
        // the panel has to be able to show a switched-off colorization as
        // switched off rather than as absent. See `colorPatchForRom`.
        const shipped = romId ? colorPatchForRom(romId) : undefined;
        if (!romId || !sourceRom || (shipped && !shipped.config)) {
            this._status = 'none';
            this.onDidChangeEmitter.fire();
            return;
        }
        /*
         * A shipped colorization wins over one made here, and the file made
         * here is left alone rather than deleted.
         *
         * Create is only offered where nothing ships, so the two can only meet
         * if VUEPort later ships one for a game somebody had already made a
         * generic patch for — and a colorization written for the game is
         * better than a generic bootstrap every time. Their file stays where
         * it is; Delete on the info page is what puts a created one away.
         */
        const created = shipped ? undefined : await this.loadCreatedDocument().catch(() => undefined);
        if (generation !== this.generation) {
            return;
        }
        const entry = shipped ?? (created !== undefined
            ? createdColorPatchEntry(romId, this.romTitle(sourceRom))
            : undefined);
        if (!entry) {
            this._status = 'none';
            this.onDidChangeEmitter.fire();
            return;
        }
        this._entry = entry;
        this._status = 'loading';
        this.onDidChangeEmitter.fire();

        try {
            const document = created ?? await this.loadDocument(entry.config as string);
            if (generation !== this.generation) {
                return;
            }
            if (!isVbcPatchDocument(document)) {
                throw new VbColorError(created !== undefined
                    ? 'The color patch saved for this game is not a version 2 VB Color patch document.'
                    : `${entry.config} is not a version 2 VB Color patch document.`);
            }
            this._document = document;
            this.table = vbcPaletteTable(vbcPatchBytes(document));
            const apply = colorPatchAutoApplied(entry, this.choice());
            await this.build(apply, apply);
            if (generation !== this.generation) {
                return;
            }
            this._status = 'ready';
        } catch (error) {
            if (generation !== this.generation) {
                return;
            }
            this._status = 'failed';
            this._error = error instanceof Error ? error.message : String(error);
        }
        this.onDidChangeEmitter.fire();
    }

    /**
     * Build the patch from the document and the edits, and hand it to the
     * patch store.
     *
     * `enable` switches it on, which restarts the game — only wanted when it
     * was not already running. A rebuild behind an edit passes false for
     * `restart` as well: the live path is already showing the result, and
     * restarting the game under it would be the opposite of what an editor is
     * for. The patch store is told to keep the new bytes without announcing
     * them as a change the running ROM needs to catch up with.
     */
    protected async build(enable: boolean, restart: boolean): Promise<void> {
        const entry = this._entry;
        const document = this._document;
        const source = this.patches.rom;
        const id = this.patchId;
        if (!entry || !document || !source || !id) {
            return;
        }
        const overrides = this.overrides;
        const build = ++this.builds;
        const target = await buildColorizedRom(source, document, overrides);
        // The patch store takes a fresh copy of the source for every ROM, so
        // this asks "is it still the same game": a build for the last one must
        // not land on the next. And a newer build has newer edits.
        if (this.patches.rom !== source || this._document !== document || build !== this.builds) {
            return;
        }
        const existing = this.patches.list.find(candidate => candidate.id === id);
        this.patches.setGeneratedPatch({
            id,
            name: document.name,
            fileName: `${entry.id.replace(/^.*\//, '')}.bps`,
            format: 'bps',
            data: createColorRomPatch(source, target),
            enabled: enable || existing?.enabled === true,
            description: document.description,
            author: entry.author,
            type: 'hack',
            builtIn: true,
        }, restart);
    }

    /** {@link build}, for when nobody is waiting on it: failures are reported rather than thrown. */
    protected rebuild(enable: boolean, restart: boolean): void {
        if (enable) {
            this._building = true;
            this.onDidChangeEmitter.fire();
        }
        this.build(enable, restart)
            .then(() => {
                this._error = undefined;
            })
            .catch(error => {
                this._status = 'failed';
                this._error = error instanceof Error ? error.message : String(error);
            })
            .then(() => {
                this._building = false;
                this.onDidChangeEmitter.fire();
            });
    }

    protected scheduleRebuild(): void {
        this.cancelRebuild();
        this.rebuildHandle = setTimeout(() => {
            this.rebuildHandle = undefined;
            // Never enabling and never restarting: see `build`.
            this.rebuild(false, false);
        }, REBUILD_DEBOUNCE_MS);
    }

    protected cancelRebuild(): void {
        if (this.rebuildHandle !== undefined) {
            clearTimeout(this.rebuildHandle);
            this.rebuildHandle = undefined;
        }
    }

    /**
     * Switch the colorization on or off for this game.
     *
     * Both restart it: the patch store rebuilds the machine from the original
     * ROM either way, which is what applying a ROM patch is. Only switching
     * *on* is announced beforehand — the panel's business; see the confirm in
     * `EmulatorColors`. On builds again rather than enabling what is there, so
     * the game comes back with the edits as they stand.
     *
     * The choice is remembered before it is acted on, so that a restart which
     * goes wrong still leaves the setting saying what was asked for.
     */
    setApplied(applied: boolean): void {
        const entry = this._entry;
        if (!entry || !this._document) {
            return;
        }
        this.rememberApply(entry.id, applied);
        if (applied) {
            this.cancelRebuild();
            this.rebuild(true, true);
            return;
        }
        const index = this.patches.list.findIndex(patch => patch.id === this.patchId);
        if (index >= 0 && this.patches.list[index].enabled) {
            this.patches.setEnabled(index, false);
        }
    }

    // ------------------------------------------------------------ creating

    /**
     * Whether the loaded colorization was made here rather than shipped.
     *
     * Read off the catalog id, which is where the difference is recorded
     * anyway — the overrides, the per-game switch and the file beside the ROM
     * are all filed under it.
     */
    get created(): boolean {
        return this._entry !== undefined && isCreatedColorPatchId(this._entry.id);
    }

    /** Whether a colorization is being compiled right now. */
    get creating(): boolean {
        return this._creating;
    }

    /**
     * Why a colorization cannot be made for the running ROM, or undefined if
     * one can.
     *
     * Two reasons and they read differently: this game already has one, which
     * is not a problem, or its ROM is a shape the generic bootstrap cannot
     * expand, which is. Both belong on the button rather than behind it.
     */
    get createRefusal(): string | undefined {
        if (this._entry) {
            return undefined;
        }
        return genericColorRefusal(this.patches.rom);
    }

    /** Whether Create can do anything: a ROM that can take one, and nothing loaded yet. */
    get canCreate(): boolean {
        return !this._entry && !this._creating && this.romId !== undefined
            && this.createRefusal === undefined;
    }

    /** The cartridge's own name, for the entry a created colorization is listed under. */
    protected romTitle(source: Uint8Array): string {
        const name = parseRomHeader(source).name.trim();
        return name.length > 0 ? name : 'Virtual Boy';
    }

    /**
     * Make a colorization for the running ROM, switch it on, and keep it.
     *
     * Compiled once, here, and then it is an ordinary format-2 document: it
     * carries the palette ABI a shipped one carries, so everything after this
     * — editing, the live path, the rebuild behind an edit, Export — is the
     * same code running against it. What makes it different is only where it
     * came from, which the info page says.
     *
     * Written to its file before it is applied. Applying restarts the game,
     * and a colorization that vanished because the restart came first would be
     * a poor trade for a saved file read.
     */
    async create(): Promise<void> {
        const source = this.patches.rom;
        const romId = this.romId;
        if (!source || !romId || this._entry || this._creating) {
            return;
        }
        const generation = this.generation;
        this._creating = true;
        this._error = undefined;
        this._status = 'loading';
        this.onDidChangeEmitter.fire();
        try {
            const title = this.romTitle(source);
            const document = await createGenericColorDocument(source, { name: `${title} (VB Color)` });
            if (generation !== this.generation) {
                return;
            }
            await this.saveCreatedDocument(document);
            const entry = createdColorPatchEntry(romId, title);
            this._entry = entry;
            this._document = document;
            this.table = vbcPaletteTable(vbcPatchBytes(document));
            // Remembered before it is acted on, as in `setApplied`: a restart
            // that goes wrong still leaves the setting saying what was asked.
            this.rememberApply(entry.id, true);
            await this.build(true, true);
            if (generation !== this.generation) {
                return;
            }
            this._status = 'ready';
        } catch (error) {
            if (generation !== this.generation) {
                return;
            }
            this._status = this._entry ? 'failed' : 'none';
            this._error = error instanceof Error ? error.message : String(error);
        } finally {
            this._creating = false;
        }
        this.onDidChangeEmitter.fire();
    }

    /**
     * Write the colors somebody has chosen into the created colorization itself.
     *
     * Until this is pressed an edit lives beside the document, in the settings,
     * as an override — which is right for a colorization VUEPort ships, because
     * a later release of that patch can then arrive with corrected colors
     * without discarding anybody's work. A colorization made here has no later
     * release: it is the person's own file, and the colors they chose belong
     * *in* it, so that the file is the thing they made rather than half of it.
     *
     * So the edits are folded into the document's palettes and the override set
     * is emptied. Nothing about the running game changes and nothing is rebuilt:
     * a build writes the document's palettes and the overrides over them into
     * the same table entries, so the ROM either way holds exactly these colors.
     * What changes is what Reset now means — the colors in the saved patch,
     * which is what somebody who has just saved them would expect it to mean.
     *
     * Only ever a created one. VUEPort's own bundled documents are not its to
     * write into; Export is what takes a copy of one of those.
     *
     * Returns false if there was nothing to save.
     */
    async saveCreated(): Promise<boolean> {
        const entry = this._entry;
        const document = this._document;
        const overrides = this.overrides;
        const names = this.names;
        if (!entry || !document || !this.created
            || (Object.keys(overrides).length === 0 && Object.keys(names).length === 0)) {
            return false;
        }
        const saved = applyOverrides(document, overrides, names);
        await this.saveCreatedDocument(saved);
        // Only once the file is written: an edit that survives in the settings
        // is recoverable, and one thrown away for a write that failed is not.
        this._document = saved;
        this.saveOverrides(entry.id, {});
        this.saveNames(entry.id, {});
        this.onDidChangeEmitter.fire();
        return true;
    }

    /**
     * Throw a created colorization away — the file, the edits and the patch.
     *
     * Only ever a created one. A shipped colorization is not this store's to
     * delete, and switching one off is what the panel offers instead.
     *
     * The game comes back unpatched, which is a restart: taking a ROM patch
     * off is the same operation as putting one on. What is left afterwards is
     * whatever `load` would find now, which for a game VUEPort has since
     * shipped a colorization for is that one.
     */
    async deleteCreated(): Promise<void> {
        const entry = this._entry;
        const id = this.patchId;
        if (!entry || !this.created || !id) {
            return;
        }
        this.cancelRebuild();
        this.saveOverrides(entry.id, {});
        this.saveNames(entry.id, {});
        this.rememberApply(entry.id, false);
        await this.saveCreatedDocument(undefined).catch(() => undefined);
        this.patches.removeGeneratedPatch(id);
        await this.load(this.romId, this.patches.rom);
    }

    /**
     * Save the colorization where the person can get at it.
     *
     * The document, not the ROM or a BPS against it: the document is the
     * colorization itself — it can be opened, edited further and handed to
     * anyone with the game — and it carries the compiled patch anyway. What
     * leaves is the shipped document with this player's edits written into
     * its palettes, exactly what a build hands the exporter.
     *
     * Returns the name it was saved under, or undefined if there was nothing to
     * save. Named for the patch rather than for the file it was fetched from:
     * `vb-color/red-alarm.json` is a path inside VUEPort and would be a
     * baffling thing to find in a downloads folder.
     */
    async exportPatch(): Promise<string | undefined> {
        const document = this._document;
        if (!this._entry || !document) {
            return undefined;
        }
        // Anything a file system might object to.
        const fileName = `${document.name.replace(/[\\/:*?"<>|]+/g, '-')}.json`;
        const edited = applyOverrides(document, this.overrides, this.names);
        const bytes = new TextEncoder().encode(`${JSON.stringify(edited, undefined, 2)}\n`);
        await this.exportFile(fileName, bytes);
        return fileName;
    }

    // ------------------------------------------------------------- editing

    /** The colors a set currently has, with this player's edit over them. */
    protected colorsOf(paletteId: number, variant: string | undefined): string[] | undefined {
        const palette = this.palette(paletteId);
        return variant === undefined
            ? palette?.colors
            : palette?.variants.find(candidate => candidate.name === variant)?.colors;
    }

    /** The colors a set ships with, before any edit of this player's. */
    protected shippedColors(paletteId: number, variant: string | undefined): string[] | undefined {
        const palette = this._document?.palettes.find(candidate => candidate.id === paletteId);
        return variant === undefined ? palette?.colors : palette?.variants?.[variant];
    }

    /**
     * Change one color of a palette, or of one of its variants: store it,
     * show it, and rebuild the patch behind it.
     *
     * In that order on purpose. The live write is what a person sees, and it
     * happens at once; the rebuild is bookkeeping and is debounced, because
     * dragging a color picker produces a great many of these and each one
     * builds a whole ROM. Snapped on the way in, so what is stored is what the
     * hardware shows rather than what the picker offered.
     */
    setColor(paletteId: number, variant: string | undefined, colorIndex: number, color: string): void {
        const current = this.colorsOf(paletteId, variant);
        if (!current || colorIndex < 0 || colorIndex >= current.length) {
            return;
        }
        const colors = [...current];
        colors[colorIndex] = color;
        this.writeColors(paletteId, variant, colors);
    }

    /**
     * Change a whole color set at once — what Paste does.
     *
     * One write rather than four, so the four colors are stored, shown and
     * built together: a set half pasted is not a thing anyone asked for, and
     * four separate edits would also file four undo-sized changes where there
     * was one action.
     */
    setColors(paletteId: number, variant: string | undefined, colors: readonly string[]): void {
        if (colors.length !== VB_COLOR_COLORS_PER_PALETTE) {
            return;
        }
        this.writeColors(paletteId, variant, [...colors]);
    }

    /** Store a set's colors, show them, and rebuild the patch behind them. */
    protected writeColors(paletteId: number, variant: string | undefined, colors: string[]): void {
        const entry = this._entry;
        const current = this.colorsOf(paletteId, variant);
        if (!entry || !this.table || !current) {
            return;
        }
        let snapped: string[];
        try {
            snapped = colors.map(snapToRgb555);
        } catch {
            // A color a picker could not have produced. Nothing is stored
            // rather than a set with one bad value in it.
            return;
        }
        this.saveOverrides(entry.id, {
            ...this.overrides,
            [vbColorOverrideKey(paletteId, variant)]: snapped,
        });
        this.showLive(paletteId, variant, snapped);
        this.scheduleRebuild();
        this.onDidChangeEmitter.fire();
    }

    // ------------------------------------------------------ copy and paste

    /** The four colors last copied, or undefined while nothing has been. */
    get copied(): readonly string[] | undefined {
        return this._copied;
    }

    /** Take a copy of one color set, as it currently stands. */
    copySet(paletteId: number, variant?: string): void {
        const colors = this.colorsOf(paletteId, variant);
        if (!colors || colors.length !== VB_COLOR_COLORS_PER_PALETTE) {
            return;
        }
        this._copied = [...colors];
        this.onDidChangeEmitter.fire();
    }

    /**
     * Put the copied colors into another set.
     *
     * An ordinary edit, and filed as one: it can be Reset like any other, and
     * the patch is rebuilt behind it. Pasting a set onto itself is allowed and
     * does nothing visible, which is cheaper to permit than to explain.
     */
    pasteInto(paletteId: number, variant?: string): void {
        if (this._copied) {
            this.setColors(paletteId, variant, this._copied);
        }
    }

    /**
     * Show a color without keeping it — what a picker being dragged wants.
     *
     * Written live, but not stored and not built: dragging fires many times a
     * second, and the settled color comes through {@link setColor}.
     */
    previewColor(paletteId: number, variant: string | undefined, colorIndex: number, color: string): void {
        const current = this.colorsOf(paletteId, variant);
        if (!this.table || !current || colorIndex < 0 || colorIndex >= current.length) {
            return;
        }
        const colors = [...current];
        colors[colorIndex] = snapToRgb555(color);
        this.showLive(paletteId, variant, colors);
    }

    /**
     * Put one color set back to the colors the patch ships.
     *
     * A set and not a palette: a palette with variants is several sets, each
     * edited on its own beside its own swatches, so each is undone on its own
     * too. Everything at once is {@link resetAll}'s job.
     */
    resetSet(paletteId: number, variant?: string): void {
        const entry = this._entry;
        const key = vbColorOverrideKey(paletteId, variant);
        if (!entry || !this.table || this.overrides[key] === undefined) {
            return;
        }
        const overrides = { ...this.overrides };
        delete overrides[key];
        this.saveOverrides(entry.id, overrides);
        // Put back immediately, or the old color would sit on screen until the
        // game next set the palette up — and that is not the editor's to wait for.
        this.showLive(paletteId, variant, this.shippedColors(paletteId, variant) ?? []);
        this.scheduleRebuild();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Put every palette back to the colors the patch ships.
     *
     * The same as {@link resetSet} for each edited set, and one call
     * rather than a loop over that one for the rebuild's sake. Only the edited
     * sets are written back — an unedited one already holds what ships.
     */
    resetAll(): void {
        const entry = this._entry;
        if (!entry) {
            return;
        }
        // The names go whether or not the colors can: a patch that cannot be
        // edited can still have been renamed.
        const renamed = Object.keys(this.names).length > 0;
        if (renamed) {
            this.saveNames(entry.id, {});
        }
        const edited = this.table ? Object.keys(this.overrides) : [];
        if (edited.length === 0) {
            if (renamed) {
                this.onDidChangeEmitter.fire();
            }
            return;
        }
        this.saveOverrides(entry.id, {});
        for (const key of edited) {
            const [id, variant] = key.split('/');
            this.showLive(Number(id), variant, this.shippedColors(Number(id), variant) ?? []);
        }
        this.scheduleRebuild();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Put one set's colors into the running game.
     *
     * Two writes. The palette table entry in the running ROM, always: that is
     * where the patch's native code copies the set from, so the edit holds
     * whenever the game next sets this palette up — a new level, a reset, a
     * different form. And the Color RAM slot the palette id names, only if that
     * slot is showing this set right now, which it is when it holds exactly
     * what the table entry held: then the edit is on screen at once, without
     * overwriting a slot the native code has put something else in.
     *
     * `known` are colors the slot may also be holding for this set, for
     * {@link reconcile}: after a save state is loaded, Color RAM is whatever it
     * was when the state was saved, and that may be the colors the table held
     * before an edit.
     */
    protected showLive(
        paletteId: number,
        variant: string | undefined,
        colors: readonly string[],
        known: readonly string[][] = [],
    ): void {
        const sim = this.sim;
        const table = this.table;
        const index = table?.index.get(vbColorOverrideKey(paletteId, variant));
        if (!sim || !table || index === undefined || !this.simRunsPatch
            || colors.length !== VBC_CRAM_PALETTE_BYTES / 2) {
            return;
        }
        const bytes = paletteBytes(colors);
        const entryAddress = VB_ROM_BASE + table.offset + index * VBC_CRAM_PALETTE_BYTES;
        const slotAddress = paletteId >= 0 && paletteId < VBC_CRAM_PALETTES
            ? VBC_CRAM_BASE + paletteId * VBC_CRAM_PALETTE_BYTES
            : undefined;
        this.liveQueue = this.liveQueue.then(async () => {
            if (this.sim !== sim) {
                return;
            }
            const entry = new Uint8Array(await sim.readMemory(entryAddress, VBC_CRAM_PALETTE_BYTES));
            await sim.writeMemory(entryAddress, bytes.slice().buffer);
            if (slotAddress === undefined) {
                return;
            }
            const slot = new Uint8Array(await sim.readMemory(slotAddress, VBC_CRAM_PALETTE_BYTES));
            const showing = sameBytes(slot, entry) || known.some(set => sameBytes(slot, paletteBytes(set)));
            if (showing && !sameBytes(slot, bytes)) {
                await sim.writeMemory(slotAddress, bytes.slice().buffer);
                await this.repaint();
            }
        }).catch(() => undefined);
    }

    /**
     * Say every edit to the running game again.
     *
     * For each time the machine may have gone back to colors from before an
     * edit: a new machine started from a patch a rebuild had not caught up
     * with yet, a save state loaded, a rewind. The table is written again —
     * harmless where it already holds the edit — and a Color RAM slot still
     * showing the shipped colors is brought up to date.
     */
    reconcile(): void {
        if (!this.simRunsPatch) {
            return;
        }
        for (const [key, colors] of Object.entries(this.overrides)) {
            const [id, variant] = key.split('/');
            const shipped = this.shippedColors(Number(id), variant);
            this.showLive(Number(id), variant, colors, shipped ? [shipped] : []);
        }
    }

    /**
     * Paint a palette a color nothing in the game uses, twice, and put it back.
     *
     * How you find out which pixels a palette owns without knowing the game by
     * heart, and the other half of the question {@link sampleDrawn} answers.
     * That one says which palettes are painting; this says *where*.
     *
     * Painted the way an edit is shown, and for the same reason — see
     * {@link showLive}. A background palette sits in the Color RAM slot its id
     * names from one scene change to the next, so the slot is what flashes it.
     * An object palette does not: the patch's native code copies it out of the
     * table into Color RAM every frame, and not always into the slot its id
     * names — Wario Land picks each form's colors into shared slots — so a
     * flash written only to the slot was gone before anyone saw it. The table
     * entry is what reaches every slot the palette is copied to. Both are put
     * back exactly as they were found.
     */
    async flash(paletteId: number, variant?: string): Promise<void> {
        const sim = this.sim;
        const key = vbColorOverrideKey(paletteId, variant);
        if (!sim || this.flashing !== undefined || paletteId < 0 || paletteId >= VBC_CRAM_PALETTES) {
            return;
        }
        this.flashing = key;
        const table = this.table;
        const index = this.simRunsPatch ? table?.index.get(key) : undefined;
        const entryAddress = table && index !== undefined
            ? VB_ROM_BASE + table.offset + index * VBC_CRAM_PALETTE_BYTES
            : undefined;
        const slotAddress = VBC_CRAM_BASE + paletteId * VBC_CRAM_PALETTE_BYTES;
        const flash = paletteBytes(new Array(VBC_CRAM_PALETTE_BYTES / 2).fill(FLASH_COLOR));
        const wait = (ms: number): Promise<void> => new Promise(resolve => setTimeout(resolve, ms));
        const run = async (): Promise<void> => {
            const slot = new Uint8Array(await sim.readMemory(slotAddress, VBC_CRAM_PALETTE_BYTES));
            const entry = entryAddress === undefined
                ? undefined
                : new Uint8Array(await sim.readMemory(entryAddress, VBC_CRAM_PALETTE_BYTES));
            // The slot only while it is showing this palette, as for an edit;
            // with no table to compare against, it is all there is.
            const showing = entry === undefined || sameBytes(slot, entry);
            const paint = async (entryBytes: Uint8Array | undefined, slotBytes: Uint8Array): Promise<void> => {
                if (entryAddress !== undefined && entryBytes) {
                    await sim.writeMemory(entryAddress, entryBytes.slice().buffer);
                }
                if (showing) {
                    await sim.writeMemory(slotAddress, slotBytes.slice().buffer);
                }
                // After each half, not at the end: the whole point of a flash
                // is the two states being seen alternately, and a paused
                // machine shows neither of them unless it is asked to.
                await this.repaint();
            };
            for (let pass = 0; pass < 2; pass += 1) {
                await paint(flash, flash);
                await wait(FLASH_STEP_MS);
                await paint(entry, slot);
                await wait(FLASH_STEP_MS);
            }
        };
        // In line with the live writes, so an edit cannot land between a
        // flash and the colors it puts back.
        const flashing = this.liveQueue.then(run);
        this.liveQueue = flashing.catch(() => undefined);
        try {
            await flashing;
        } catch {
            // A machine that went away mid-flash has nothing to put back.
        } finally {
            this.flashing = undefined;
        }
    }

    /**
     * Put what was just written on screen.
     *
     * Only a paused machine needs telling — a running one composites the next
     * frame from Color RAM a moment later, which is what makes editing while
     * playing work at all. Paused there is no next frame, so a write would sit
     * in Color RAM with the old picture in front of it. Asked for
     * unconditionally rather than only when paused: one extra composite is
     * cheaper than knowing.
     */
    protected async repaint(): Promise<void> {
        await this.sim?.refreshFrame().catch(() => undefined);
    }

    // ------------------------------------------------------- what is on screen

    /**
     * Find out which palettes are painting the picture, once.
     *
     * Color RAM says what the colors are, not which of them are in use, so
     * the answer comes from the framebuffer side, in two halves — see
     * `takeDrawnPalettes`. A colorization whose own code draws into the Color
     * Framebuffer is caught at the store instruction, watched for the length
     * of the sample. One colored through the attribute RAMs never stores a
     * palette id — the VIP writes its Color Source bytes inside the core — so
     * the displayed framebuffer is read back as well, at the pixels the legacy
     * framebuffer does not leave blank.
     *
     * On demand rather than continuously, and the cost is why: capture is a
     * call out of the core on every CPU write, so it is switched on for the
     * length of one sample and off again. That the answer then holds still is
     * not a consolation prize — a list that rearranged itself four times a
     * second while being read would be no use for choosing what to edit.
     */
    async sampleDrawn(): Promise<void> {
        const sim = this.sim;
        // Refused while paused rather than answered wrongly: a stopped machine
        // paints nothing, so the only answer available is an empty screen, and
        // an empty list is indistinguishable from a scene that really has
        // nothing in it.
        if (!sim || this._sampling || this._paused) {
            return;
        }
        this._sampling = true;
        this.onDidChangeEmitter.fire();
        try {
            // A fresh set starts empty, so there is nothing to discard first.
            await sim.setDrawnPaletteCapture(true);
            await new Promise<void>(resolve => setTimeout(resolve, DRAWN_SAMPLE_MS));
            const buffer = await sim.takeDrawnPalettes();
            const painting = await this.palettesPainting(sim, decodeDrawnPalettes(buffer));
            // The machine may have been replaced while this collected — see
            // `setSim`. Then the answer is about a machine nobody is looking at.
            if (this.sim === sim) {
                this._drawn = painting;
            }
        } catch {
            // A machine that cannot answer has nothing to report. Left as it
            // was rather than emptied: an empty set means "nothing is being
            // drawn", which is a different claim from "nobody could tell".
        } finally {
            this._sampling = false;
            await sim.setDrawnPaletteCapture(false).catch(() => undefined);
            this.onDidChangeEmitter.fire();
        }
    }

    /**
     * Turn the Color RAM slots found painting into the palettes painting them.
     *
     * The same thing for a background palette, which sits in the slot its id
     * names. Not always for an object palette: the patch's native code copies
     * those into Color RAM every frame, and may put one palette's colors into
     * another's slot. So a slot not holding its own palette's colors is
     * reported as the palettes whose table entry holds them — all of them,
     * where several share a color set, since nothing outside the native code
     * can tell which of those it copied.
     */
    protected async palettesPainting(sim: ColorSim, slots: Set<number>): Promise<Set<number>> {
        const table = this.table;
        if (!table || !this.simRunsPatch || slots.size === 0 || table.index.size === 0) {
            return slots;
        }
        const size = VBC_CRAM_PALETTE_BYTES;
        const last = Math.max(...table.index.values());
        const cram = new Uint8Array(await sim.readMemory(VBC_CRAM_BASE, VBC_CRAM_PALETTES * size));
        const entries = new Uint8Array(await sim.readMemory(VB_ROM_BASE + table.offset, (last + 1) * size));
        const entry = (index: number): Uint8Array => entries.subarray(index * size, (index + 1) * size);
        const painting = new Set<number>();
        for (const slot of slots) {
            const colors = cram.subarray(slot * size, (slot + 1) * size);
            const own = table.index.get(vbColorOverrideKey(slot));
            if (own !== undefined && sameBytes(colors, entry(own))) {
                painting.add(slot);
                continue;
            }
            const owners = [...table.index]
                .filter(([, index]) => sameBytes(colors, entry(index)))
                .map(([key]) => Number(key.split('/')[0]));
            // Colors no table entry holds — mid-fade, say — are left with
            // the slot, which is the best answer there is.
            (owners.length > 0 ? owners : [slot]).forEach(id => painting.add(id));
        }
        return painting;
    }

    /** Put the list back to everything. */
    clearDrawn(): void {
        if (this._drawn !== undefined) {
            this._drawn = undefined;
            this.onDidChangeEmitter.fire();
        }
    }

    dispose(): void {
        this.cancelRebuild();
        this.onDidChangeEmitter.dispose();
    }
}
