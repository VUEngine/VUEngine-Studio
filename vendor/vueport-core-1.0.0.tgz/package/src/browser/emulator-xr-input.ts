/**
 * A headset's controllers, read once a frame — see `emulator-xr.ts`.
 *
 * A headset browser never lists its controllers to the Gamepad API, and stops
 * the page's animation frames while a session lasts, so the session reads
 * them itself, through this: as the Virtual Boy's buttons while playing, and
 * as named buttons and stick leans for the menu and the screen's adjustments.
 */

import { VbKey } from '../common/vb-constants';
import { XrInputSource } from './emulator-xr-webxr';

/** How far a stick has to lean before it counts as a D-pad direction. */
export const XR_STICK_THRESHOLD = 0.5;

/**
 * The Virtual Boy buttons held on a headset's controllers.
 *
 * Laid out as the console's own pad is: the left stick is the left D-pad and
 * the right stick the right one, the triggers are L and R, the right hand's
 * A and B are A and B, and the left hand's X and Y, where the console has
 * Select and Start under its left D-pad, are those. Buttons are by the
 * `xr-standard` mapping, which every current headset's controllers report.
 *
 * A grip held turns both sticks from playing to adjusting how the screen is
 * shown — see `adjustView` — so their directions are left out of the keys
 * while it is, and their leans and clicks are reported instead.
 */
export function readControllers(sources: ArrayLike<XrInputSource>): XrControllerReading {
    let keys = 0;
    let adjusting = false;
    let leftLean = 0;
    let rightLean = 0;
    let vertical = 0;
    const buttons = noXrButtons();
    for (let i = 0; i < sources.length; i++) {
        const source = sources[i];
        const pad = source.gamepad;
        if (!pad || pad.mapping !== 'xr-standard' || source.handedness === 'none') {
            continue;
        }
        const left = source.handedness === 'left';
        const pressed = (index: number) => pad.buttons[index]?.pressed ?? false;
        // The stick is axes 2 and 3; 0 and 1 are a touchpad no current
        // controller has. Up is negative, as on any pad.
        const x = pad.axes[2] ?? 0;
        const y = pad.axes[3] ?? 0;
        const lean = Math.abs(x) > Math.abs(y) ? x : -y;
        if (Math.abs(y) > Math.abs(vertical)) {
            vertical = y;
        }
        if (left) {
            leftLean = lean;
            buttons.leftClick = pressed(3);
            buttons.leftTrigger = pressed(0);
            buttons.x = pressed(4);
            buttons.y = pressed(5);
            // The menu button, where a browser passes it on at all: past the
            // thumb rest, 6, which the published layouts end with.
            buttons.menu = pad.buttons.slice(7).some(button => button?.pressed);
        } else {
            rightLean = lean;
            buttons.rightClick = pressed(3);
            buttons.rightTrigger = pressed(0);
            buttons.a = pressed(4);
            buttons.b = pressed(5);
        }
        if (pressed(1)) {
            adjusting = true;
        }
        if (x < -XR_STICK_THRESHOLD) {
            keys |= left ? VbKey.LL : VbKey.RL;
        } else if (x > XR_STICK_THRESHOLD) {
            keys |= left ? VbKey.LR : VbKey.RR;
        }
        if (y < -XR_STICK_THRESHOLD) {
            keys |= left ? VbKey.LU : VbKey.RU;
        } else if (y > XR_STICK_THRESHOLD) {
            keys |= left ? VbKey.LD : VbKey.RD;
        }
        if (pressed(0)) {
            keys |= left ? VbKey.LT : VbKey.RT;
        }
        if (pressed(4)) {
            keys |= left ? VbKey.SEL : VbKey.A;
        }
        if (pressed(5)) {
            keys |= left ? VbKey.STA : VbKey.B;
        }
    }
    if (adjusting) {
        // The sticks are adjusting the view, not playing.
        keys &= ~(VbKey.LU | VbKey.LD | VbKey.LL | VbKey.LR | VbKey.RU | VbKey.RD | VbKey.RL | VbKey.RR);
    }
    return { keys, adjusting, leftLean, rightLean, vertical, buttons };
}

/** The controller buttons a menu is driven with, by name rather than by index. */
export interface XrButtons {
    leftClick: boolean;
    rightClick: boolean;
    leftTrigger: boolean;
    rightTrigger: boolean;
    a: boolean;
    b: boolean;
    x: boolean;
    y: boolean;
    /** The left controller's menu button, if the browser passes it on. */
    menu: boolean;
}

export function noXrButtons(): XrButtons {
    return {
        leftClick: false, rightClick: false, leftTrigger: false, rightTrigger: false,
        a: false, b: false, x: false, y: false, menu: false,
    };
}

/** What the controllers are doing, once a frame; see {@link readControllers}. */
export interface XrControllerReading {
    /** The Virtual Boy buttons held. */
    keys: number;
    /** Whether a grip is held, which turns the sticks to adjusting the view. */
    adjusting: boolean;
    /**
     * How far each stick leans towards more, from -1 to 1: right or up, by
     * whichever of the two it leans further in.
     */
    leftLean: number;
    rightLean: number;
    /** The furthest either stick leans up (negative) or down, for moving through a menu. */
    vertical: number;
    buttons: XrButtons;
}
