import { Disposable } from '../common/emulator-events';
import { Core, Sim } from './core/vb-core';

/**
 * One emulator's worker, and the machines running in it.
 *
 * Ordinarily that is one machine. A link session adds a second — the *mirror*,
 * which is the other player's machine run here as well, from the other
 * player's inputs. Both have to live in one WebAssembly instance because the
 * link port is emulated by walking from one simulation to its peer inside it,
 * so a machine in another window is not something this one can be wired to.
 *
 * Running the pair rather than streaming a picture of it is what lets each
 * window be an ordinary, whole emulator — its own toolbar, its own debugger,
 * its own audio — and it is what a netplay session would do over a wire
 * instead of a BroadcastChannel. See `link-session.ts`.
 */
export interface EmulatorSession extends Disposable {
    readonly core: Core;
    /** This window's own machine. */
    readonly sim: Sim;
    /** The other player's machine, once {@link attachMirror} has run. */
    readonly mirror: Sim | undefined;
    /**
     * Bring the mirror up and wire the two together over the link port.
     *
     * It needs the cartridge — the same one this window's own machine is
     * running. A mirror without one is not a copy of the other player's
     * machine at all: it boots into empty memory and marches through whatever
     * it finds there, which looks like a working session right up until
     * anybody compares the two.
     *
     * `seat` is which player this window's own machine belongs to, and the
     * mirror takes the other seat. The core is handed the pair in seat order
     * rather than in the order this window built it, because the order changes
     * what a linked pair emulates and the two windows build theirs the
     * opposite way round — see `setPeer` in `vb-protocol.ts`.
     *
     * Idempotent: asking twice returns the mirror that is already there.
     */
    attachMirror(rom: ArrayBuffer, seat?: 1 | 2): Promise<Sim>;
    /** Take the mirror down again. This window's machine carries on alone. */
    detachMirror(): Promise<void>;
    /**
     * Do something that owns the mirror, once whatever already owns it is done.
     *
     * Building the mirror and giving it back are both several round trips to
     * the worker, and they belong to *different* link sessions: unlinking
     * disposes one session and linking again builds another, so the window
     * that has just let go is answering a new hello while it is still letting
     * go. Nothing in either session could see the other — a session's own
     * ordering cannot help here, because the two are not the same object —
     * and when the release won the race it disposed of the machine the new
     * session had just built, which the next booking died of.
     *
     * The mirror belongs to the emulator session rather than to any one link
     * session, so this is where the queue for it lives.
     */
    withMirror<T>(work: () => Promise<T>): Promise<T>;
}

class EmulatorSessionImpl implements EmulatorSession {

    mirror: Sim | undefined;

    /** Whatever owns the mirror at the moment. See {@link withMirror}. */
    protected mirrorWork: Promise<unknown> = Promise.resolve();

    constructor(
        readonly core: Core,
        readonly sim: Sim,
        protected readonly service: EmulatorCoreService,
    ) { }

    async attachMirror(rom: ArrayBuffer, seat: 1 | 2 = 1): Promise<Sim> {
        if (this.mirror) {
            return this.mirror;
        }
        const mirror = await this.core.createSim();
        await mirror.setHardwareMode(this.sim.isVbcHardware);
        await mirror.setCartRom(rom);
        // Peering is symmetric in the core, so one call does both ends — and
        // it carries the seat, so both windows emulate the pair in one order.
        await this.sim.setPeer(mirror, seat);
        this.mirror = mirror;
        return mirror;
    }

    withMirror<T>(work: () => Promise<T>): Promise<T> {
        // The queue is what is chained, not the caller's result: one piece of
        // work failing must not leave everything after it unable to run.
        const next = this.mirrorWork.then(work, work);
        this.mirrorWork = next.catch(() => undefined);
        return next;
    }

    async detachMirror(): Promise<void> {
        const mirror = this.mirror;
        if (!mirror) {
            return;
        }
        this.mirror = undefined;
        await this.sim.setPeer(undefined);
        mirror.dispose();
    }

    dispose(): void {
        this.service.disposeSession(this);
    }
}

/**
 * Where the core's three pieces are served from.
 *
 * All host-specific: the worker and the worklet are emitted next to whatever
 * bundle the host builds, and the wasm is fetched over HTTP because
 * `WebAssembly.instantiateStreaming` wants a URL. The emulator is told rather
 * than working them out, so a host is free to serve them from anywhere.
 */
export interface VueportCoreUrls {
    workerUrl: string;
    audioWorkletUrl: string;
    /** The core's WebAssembly binary. */
    wasmUrl: string;
    /** The RetroAchievements engine's Emscripten module, if this build has one. */
    rcheevosModuleUrl?: string;
    /** Render WebGL on the page, for hosts such as Linux WebKitGTK. */
    mainThreadVideo?: boolean;
}

/**
 * Creates and tracks emulator sessions.
 *
 * One session per emulator, one worker per session. Emulation state is
 * core-wide — run and suspend apply to every machine in a worker at once —
 * which is wrong for unrelated emulators and exactly right for a linked pair,
 * which has to stay in step.
 */
export class EmulatorCoreService implements Disposable {

    protected readonly sessions = new Set<EmulatorSessionImpl>();

    constructor(protected readonly urls: VueportCoreUrls) { }

    async createSession(): Promise<EmulatorSession> {
        const core = await this.createCore();
        const session = new EmulatorSessionImpl(core, await core.createSim(), this);
        this.sessions.add(session);
        return session;
    }

    /** Shut a session down, releasing its worker. */
    disposeSession(session: EmulatorSession): void {
        const impl = session as EmulatorSessionImpl;
        if (!this.sessions.delete(impl)) {
            return;
        }
        impl.core.dispose();
    }

    protected async createCore(): Promise<Core> {
        return Core.create(this.urls);
    }

    dispose(): void {
        for (const session of [...this.sessions]) {
            this.disposeSession(session);
        }
        this.sessions.clear();
    }
}
