import { Disposable } from '../common/emulator-events';
import { Core, Sim } from './core/vb-core';

/**
 * One emulator's worker and the machines in it. A link session adds the mirror, the other player's machine run
 * here as well from their inputs: both must live in one WebAssembly instance, as the link port is emulated by
 * walking from one simulation to its peer. That keeps each window a whole emulator (toolbar, debugger, audio),
 * and is what netplay would do over a wire instead of a BroadcastChannel. See link-session.ts.
 */
export interface EmulatorSession extends Disposable {
    readonly core: Core;
    // this window's own machine
    readonly sim: Sim;
    // the other player's machine, once attachMirror has run
    readonly mirror: Sim | undefined;
    /**
     * Brings the mirror up and wires the two together over the link port. Needs the same cartridge this window runs;
     * without one the mirror boots into empty memory and only looks like a working session.
     * `seat` is this window's player, the mirror takes the other. The core gets the pair in seat order, as the order
     * changes what a linked pair emulates and the two windows build theirs the opposite way round (setPeer in
     * vb-protocol.ts). Idempotent.
     */
    attachMirror(rom: ArrayBuffer, seat?: 1 | 2): Promise<Sim>;
    // this window's machine carries on alone
    detachMirror(): Promise<void>;
    /**
     * Runs work that owns the mirror once whatever owns it now is done. Building and releasing the mirror are several
     * worker round trips belonging to different link sessions (unlink, then link again), and when the release won
     * the race it disposed of the machine the new session had just built. The mirror belongs to the emulator session,
     * so the queue lives here.
     */
    withMirror<T>(work: () => Promise<T>): Promise<T>;
}

class EmulatorSessionImpl implements EmulatorSession {

    mirror: Sim | undefined;

    // whatever owns the mirror at the moment, see withMirror
    protected mirrorWork: Promise<unknown> = Promise.resolve();

    constructor(
        readonly core: Core,
        readonly sim: Sim,
        protected readonly service: EmulatorCoreService,
    ) { }

    async attachMirror(rom: ArrayBuffer, seat: 1 | 2 = 1): Promise<Sim> {
        if (this.mirror) {
            return this.mirror;
        }
        const mirror = await this.core.createSim();
        await mirror.setHardwareMode(this.sim.isVbcHardware);
        await mirror.setCartRom(rom);
        // peering is symmetric in the core, so one call does both ends; it carries the seat, so both windows emulate
        // the pair in one order
        await this.sim.setPeer(mirror, seat);
        this.mirror = mirror;
        return mirror;
    }

    withMirror<T>(work: () => Promise<T>): Promise<T> {
        // the queue is chained, not the caller's result, so one failure does not block everything after it
        const next = this.mirrorWork.then(work, work);
        this.mirrorWork = next.catch(() => undefined);
        return next;
    }

    async detachMirror(): Promise<void> {
        const mirror = this.mirror;
        if (!mirror) {
            return;
        }
        this.mirror = undefined;
        await this.sim.setPeer(undefined);
        mirror.dispose();
    }

    dispose(): void {
        this.service.disposeSession(this);
    }
}

// where the core's three pieces are served from, all host-specific: the worker and worklet are emitted next to the
// host's bundle, the wasm is fetched over HTTP because WebAssembly.instantiateStreaming wants a URL
export interface VueportCoreUrls {
    workerUrl: string;
    audioWorkletUrl: string;
    wasmUrl: string;
    // the RetroAchievements engine's Emscripten module, if this build has one
    rcheevosModuleUrl?: string;
    // render WebGL on the page, for hosts such as Linux WebKitGTK
    mainThreadVideo?: boolean;
}

// One session per emulator, one worker per session. Run and suspend apply to every machine in a worker at once,
// which is right for a linked pair that has to stay in step and wrong for unrelated emulators.
export class EmulatorCoreService implements Disposable {

    protected readonly sessions = new Set<EmulatorSessionImpl>();

    constructor(protected readonly urls: VueportCoreUrls) { }

    async createSession(): Promise<EmulatorSession> {
        const core = await this.createCore();
        const session = new EmulatorSessionImpl(core, await core.createSim(), this);
        this.sessions.add(session);
        return session;
    }

    // releases its worker
    disposeSession(session: EmulatorSession): void {
        const impl = session as EmulatorSessionImpl;
        if (!this.sessions.delete(impl)) {
            return;
        }
        impl.core.dispose();
    }

    protected async createCore(): Promise<Core> {
        return Core.create(this.urls);
    }

    dispose(): void {
        for (const session of [...this.sessions]) {
            this.disposeSession(session);
        }
        this.sessions.clear();
    }
}
