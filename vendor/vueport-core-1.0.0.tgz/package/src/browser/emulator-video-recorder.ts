import { Emitter, Event } from '../common/emulator-events';
import { DisplayMode } from '../common/vb-constants';
import { Frame } from '../common/vb-protocol';
import { Core, Sim } from './core/vb-core';
import { EsSoundPlayer } from './emulator-essound-player';
import { VbRenderer } from '../worker/vb-renderer';

/**
 * Recording what is being played, picture and sound, as a video file.
 *
 * The two halves are gathered from opposite ends of the emulator and only meet
 * here.
 *
 * The picture cannot be read off the screen. Presentation belongs to the
 * worker — the panel's canvas has had its control transferred there — and a
 * canvas in that state refuses to be captured, so there is nothing on the page
 * to record. Instead the machine's frames are tapped at the source (see
 * `setVideoTap` in `vb-protocol.ts`) and composed a second time here, into a
 * canvas of this recorder's own. Which costs one upload and one blit per
 * frame, and buys the same freedom a screenshot has: a recording can be a
 * different rendering mode, palette and size from the one being played in,
 * and the live picture never flickers through the change.
 *
 * The sound is in two places because ESSound is played by the page while the
 * machine's own audio is produced by the core. Both are pulled into the core's
 * audio context — an audio graph cannot reach across contexts, so ESSound's
 * own graph hands over a `MediaStream` and that is what is mixed in — and the
 * single mixed track is what is recorded. A recorder given two audio tracks
 * would keep one of them and silently drop the other.
 *
 * What is recorded is what is heard: mute, volume, balance and the emulator's
 * speed all apply, because all of them are upstream of the taps.
 *
 * Which container and codecs are used is not simply asked for and granted.
 * `MediaRecorder.isTypeSupported` answers for the muxer rather than for the
 * encoders behind it, and says yes to combinations a browser will then fail
 * to encode — Chrome accepts `avc1,mp4a.40.2` and raises `EncodingError` on
 * the first frame, leaving a recording that runs happily and produces an
 * empty file. So the type is a list rather than an answer: the first one that
 * works is the one kept, and an encoder that fails before it has written
 * anything is swapped for the next candidate while the recording carries on.
 * See {@link VideoRecorder.mimeTypes}.
 *
 * That failure had nothing to do with a missing encoder, which is worth
 * writing down because it looked exactly like one. AAC is defined only for a
 * fixed set of sample rates, and the machine's 41700 Hz is not among them, so
 * the encoder refuses the mix it is handed and the whole container goes down
 * with it — the recording falls back to AV1 and Opus, a file rather fewer
 * players open. The audio is therefore resampled on its way into the
 * recording and not before; see {@link VideoRecorder.openAudio}.
 *
 * The file is held in memory until the recording is stopped — the encoder
 * hands over chunks as it goes and they are kept in a list, because a browser
 * has nowhere to stream them to that the person could then be handed. So a
 * recording costs roughly its own bit rate in memory per second, which is what
 * the quality setting is really choosing between for a long session.
 */

/**
 * WebM candidates, best first.
 *
 * VP9 over VP8 for the picture this records: flat areas of four brightnesses
 * are what it is best at. Opus is the only audio WebM carries.
 */
const WEBM_TYPES = [
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
];

/**
 * MP4 candidates, best first.
 *
 * H.264 with AAC first because it is the combination everything plays, from a
 * phone's photo roll to a video editor. AV1 with Opus second, for a browser
 * that cannot produce the first — a file fewer players open, but a file. Bare
 * `video/mp4` last, for a browser that offers the container without naming
 * what is in it.
 */
const MP4_TYPES = [
    'video/mp4;codecs=avc1,mp4a.40.2',
    'video/mp4;codecs=av01,opus',
    'video/mp4',
];

/** How often the encoder hands over what it has, in milliseconds. */
const CHUNK_INTERVAL = 1000;

/** Bit rates the quality names stand for, for a picture this size. */
export const VIDEO_BIT_RATES: Record<VideoQuality, number> = {
    low: 1_500_000,
    medium: 4_000_000,
    high: 12_000_000,
};

export const AUDIO_BIT_RATE = 128_000;

/**
 * Sample rates an AAC encoder will take.
 *
 * AAC carries its rate as an index into a table rather than as a number, so
 * this is not a quality threshold a browser may choose to be generous about:
 * a rate that is not in the table cannot be written down, and the encoder can
 * only refuse. The machine's own 41700 Hz is not in it, and neither — for
 * Chrome's encoder, whatever the table says — is 32000.
 */
export const AAC_SAMPLE_RATES = [44100, 48000];

/**
 * What a recording's audio is resampled to when it has to be.
 *
 * 48 kHz because it is what the hardware is almost always running at anyway,
 * and what Opus works in internally whatever it is given — so this is rarely
 * an extra conversion, more often the one that was going to happen regardless,
 * done somewhere we can see it.
 */
export const RECORDING_SAMPLE_RATE = 48_000;

/**
 * The rate a recording's audio has to be resampled to, or undefined for a
 * context already running at one an encoder will take.
 */
export function bridgeSampleRateFor(rate: number): number | undefined {
    return AAC_SAMPLE_RATES.includes(rate) ? undefined : RECORDING_SAMPLE_RATE;
}

/**
 * What a recorder's error event says went wrong, where it says anything.
 *
 * The DOM library types the event as a plain `Event`, which is all a browser
 * that carries no detail gives; the ones that do carry a `DOMException` whose
 * name is the only part worth repeating — `EncodingError` for a container the
 * encoders behind it cannot actually produce.
 */
function failureName(event: unknown): string | undefined {
    return (event as { error?: { name?: string } } | undefined)?.error?.name;
}

export type VideoQuality = 'low' | 'medium' | 'high';

/**
 * Which container to prefer. A preference and not a promise: what a browser
 * can encode is the browser's business, so the other container is still used
 * rather than refusing to record.
 */
export type VideoFormat = 'auto' | 'webm' | 'mp4';

/** A stored setting read back as one of the three, defaulting to automatic. */
export function videoFormatOf(value: string | undefined): VideoFormat {
    return value === 'webm' || value === 'mp4' || value === 'auto' ? value : 'auto';
}

/** A stored setting read back as one of the three, defaulting in the middle. */
export function videoQualityOf(value: string | undefined): VideoQuality {
    return value === 'low' || value === 'medium' || value === 'high' ? value : 'medium';
}

export interface VideoRecorderOptions {
    core: Core;
    sim: Sim;
    /**
     * ESSound's playback, mixed in when the running ROM has any.
     *
     * Left out for a ROM with no tracks beside it: opening the tap builds the
     * player's audio context, and there is no reason to build one for silence.
     */
    esSound?: EsSoundPlayer;
    /** How the frames are composed — need not be the mode being played in. */
    mode: DisplayMode;
    /** Whole-number multiple of the mode's own size to record at. */
    scale?: number;
    /** One of {@link VideoQuality}; anything else is read as the middle one. */
    quality?: string;
    /** One of {@link VideoFormat}; anything else is read as automatic. */
    format?: string;
}

/** A finished recording, ready to be handed to whoever asked for it. */
export interface VideoRecording {
    blob: Blob;
    /** `webm` or `mp4`, whichever the browser could encode. */
    extension: string;
    /** How many of the machine's frames went in. */
    frames: number;
    /** How long it runs, in seconds, pauses excluded. */
    seconds: number;
    /** The container and codecs it was actually encoded with. */
    mimeType: string;
    /** Why the encoder gave up, for a recording that ended by itself. */
    failure?: string;
}

export class VideoRecorder {

    /**
     * Every container and codec set this browser says it can encode, in the
     * order they should be tried for the requested format.
     *
     * The preferred container comes first and the other one after it, because
     * a file in the container somebody did not ask for is a better answer than
     * no recording at all — Safari has no WebM encoder and Firefox no MP4 one,
     * and neither of those should mean a button that does nothing.
     *
     * Bear in mind that this list is what a browser says it can mux, which is
     * not what it can encode; see the note on sample rates at the top of this
     * file for how far apart those two answers can be.
     */
    static mimeTypes(format: string = 'auto'): string[] {
        if (typeof MediaRecorder === 'undefined') {
            return [];
        }
        // MP4 unless WebM was asked for, the automatic choice included. WebM
        // is the better encoding of this particular picture — flat areas of
        // four brightnesses are what VP9 is best at — but a recording is made
        // to be shown to someone, and H.264 in MP4 is the file that opens
        // wherever it is taken. A browser that cannot write it still gets
        // WebM, from the second half of this list.
        const order = videoFormatOf(format) === 'webm'
            ? [...WEBM_TYPES, ...MP4_TYPES]
            : [...MP4_TYPES, ...WEBM_TYPES];
        return order.filter(type => MediaRecorder.isTypeSupported(type));
    }

    /** The first of those, or undefined for a browser that will encode none. */
    static mimeType(format?: string): string | undefined {
        return VideoRecorder.mimeTypes(format)[0];
    }

    /**
     * Whether this browser can record at all.
     *
     * Three things have to be there, and a WebKitGTK build of the desktop
     * wrapper is the case where they are not: the encoder, a canvas that can
     * be captured, and a canvas track that takes its frames when it is told
     * to rather than on a clock of its own.
     */
    static isSupported(): boolean {
        return VideoRecorder.mimeTypes().length > 0
            && typeof HTMLCanvasElement !== 'undefined'
            && typeof HTMLCanvasElement.prototype.captureStream === 'function';
    }

    /**
     * Start recording. Resolves once the encoder is running.
     *
     * The mode is settled here and held for the life of the recording: the
     * stereo layouts present at different geometries, and a stream whose
     * frames change size halfway through is not a file most players will open.
     */
    static async start(options: VideoRecorderOptions): Promise<VideoRecorder> {
        const candidates = VideoRecorder.mimeTypes(options.format);
        if (candidates.length === 0) {
            throw new Error('This browser cannot record video.');
        }
        const recorder = new VideoRecorder(options, candidates);
        await recorder.begin();
        return recorder;
    }

    protected readonly core: Core;
    protected readonly sim: Sim;
    protected readonly esSound: EsSoundPlayer | undefined;
    protected readonly mode: DisplayMode;
    protected readonly scale: number;
    protected readonly quality: VideoQuality;

    /**
     * The containers still worth trying, current one first.
     *
     * Shrinks rather than being indexed into: a candidate that has failed is
     * gone, so nothing can go back round to it.
     */
    protected candidates: string[];

    /** Where the frames are composed, and where they are captured from. */
    protected canvas: HTMLCanvasElement | undefined;
    protected renderer: VbRenderer | undefined;
    protected output: HTMLCanvasElement | undefined;
    protected outputContext: CanvasRenderingContext2D | undefined;
    protected track: CanvasCaptureMediaStreamTrack | undefined;

    protected mix: MediaStreamAudioDestinationNode | undefined;
    protected esSoundSource: MediaStreamAudioSourceNode | undefined;
    /** The context the mix is resampled in, where it has to be. */
    protected bridge: AudioContext | undefined;
    protected bridgeSource: MediaStreamAudioSourceNode | undefined;

    protected recorder: MediaRecorder | undefined;
    protected chunks: Blob[] = [];
    /** The stream both encoders are fed from; it outlives any one of them. */
    protected stream: MediaStream | undefined;
    /** Why the encoder gave up, once none of the candidates has worked. */
    protected failure: string | undefined;

    protected readonly onDidFailEmitter = new Emitter<string>();
    /**
     * The encoder gave up and the recording has ended itself.
     *
     * Nothing else says so: a `MediaRecorder` that fails stops on the spot,
     * and a host that was not listening would go on showing a record light
     * over a machine nobody is recording. Whatever was encoded before the
     * failure is still there to be saved — see {@link VideoRecorder.stop}.
     */
    readonly onDidFail: Event<string> = this.onDidFailEmitter.event;

    protected frames = 0;
    /** Wall-clock milliseconds spent recording, pauses excluded. */
    protected elapsed = 0;
    protected since = 0;
    protected paused = false;
    protected stopped = false;

    protected constructor(options: VideoRecorderOptions, candidates: string[]) {
        this.core = options.core;
        this.sim = options.sim;
        this.esSound = options.esSound;
        this.mode = options.mode;
        this.scale = Math.max(1, Math.floor(options.scale ?? 1));
        this.quality = videoQualityOf(options.quality);
        this.candidates = candidates;
    }

    /** What this recording is being encoded as, which a failure can change. */
    get mimeType(): string {
        return this.candidates[0];
    }

    /** How long it has been running, in seconds, for a badge to count up. */
    get seconds(): number {
        const running = this.paused || this.stopped ? 0 : Date.now() - this.since;
        return (this.elapsed + running) / 1000;
    }

    get frameCount(): number {
        return this.frames;
    }

    get isRecording(): boolean {
        return !this.stopped;
    }

    /** What the file will be called at the end, without its stem. */
    get extension(): string {
        return this.mimeType.startsWith('video/mp4') ? 'mp4' : 'webm';
    }

    /**
     * Build everything the recording needs, and start it.
     *
     * Every failure on the way in releases what was built first. Without that
     * a recording that could not be started would leave the machine mirroring
     * its frames to a handler that no longer exists — invisible, and paid for
     * on every frame until the ROM is closed.
     */
    protected async begin(): Promise<void> {
        try {
            await this.build();
        } catch (error) {
            await this.sim.setVideoTap().catch(() => undefined);
            this.release();
            throw error;
        }
    }

    protected async build(): Promise<void> {
        const canvas = document.createElement('canvas');
        this.canvas = canvas;
        this.renderer = new VbRenderer(canvas, this.mode);

        // Captured from a plain 2D canvas rather than from the WebGL one, so
        // that the enlargement is a nearest-neighbor blit — the shader maps
        // every output pixel onto a source pixel, so rendering into a bigger
        // drawing buffer would not be a bigger picture but a differently-cut
        // one. The same reasoning as `VbRenderer#capture`.
        const output = document.createElement('canvas');
        output.width = this.mode.width * this.scale;
        output.height = this.mode.height * this.scale;
        this.output = output;
        const context = output.getContext('2d', { alpha: false });
        if (!context) {
            throw new Error('Could not acquire a 2D context to record into.');
        }
        context.imageSmoothingEnabled = false;
        // Black rather than transparent, so that a recording stopped before
        // the machine ever presented is still a picture.
        context.fillStyle = '#000000';
        context.fillRect(0, 0, output.width, output.height);
        this.outputContext = context;

        // Zero, so the stream takes a frame when it is given one and not on a
        // clock of its own: one video frame per emulated frame, whatever the
        // machine's speed, and no duplicates while it is paused.
        const video = output.captureStream(0);
        this.track = video.getVideoTracks()[0] as CanvasCaptureMediaStreamTrack;

        const audio = await this.openAudio();
        this.stream = new MediaStream([...video.getVideoTracks(), ...audio]);

        await this.sim.setVideoTap(frame => this.present(frame));

        // Started last: everything the stream carries is in place, so the file
        // begins with a frame of the game rather than with the wait for one.
        this.startEncoder();
        // One frame straight away, so that a stream taking its frames on
        // request has something in it before the machine presents — which for
        // a recording started on a paused machine is not for a while.
        this.track.requestFrame();
        this.since = Date.now();
    }

    /**
     * Put an encoder on the stream and start it, using the current candidate.
     *
     * Separate from everything else the recording holds, because this is the
     * one part that may have to be built twice: a `MediaRecorder` that fails
     * stops for good, so trying the next candidate means a new one — on the
     * same canvas, the same tap and the same audio mix, all of which carry on
     * undisturbed through the swap.
     */
    protected startEncoder(): void {
        const recorder = new MediaRecorder(this.stream!, {
            mimeType: this.mimeType,
            videoBitsPerSecond: VIDEO_BIT_RATES[this.quality],
            audioBitsPerSecond: AUDIO_BIT_RATE,
        });
        // Both handlers answer only for the encoder that is still the
        // recording's own. An encoder that has been given up on goes on to
        // flush what it had, and that arrives after the swap — see
        // {@link VideoRecorder.encoderFailed}.
        recorder.ondataavailable = event => {
            if (this.recorder === recorder && event.data.size > 0) {
                this.chunks.push(event.data);
            }
        };
        recorder.onerror = event => {
            if (this.recorder === recorder) {
                this.encoderFailed(failureName(event));
            }
        };
        this.recorder = recorder;
        recorder.start(CHUNK_INTERVAL);
    }

    /**
     * The encoder raised an error. Try the next candidate, or give up.
     *
     * Trying the next one is only right while nothing has been encoded yet:
     * that is the failure this exists for — a browser that accepts a container
     * it has no encoder for and says so on the first frame — and it costs a
     * fraction of a second of the recording. Once bytes have been written they
     * are a file in one particular container, and starting a second encoder
     * would be starting a second file, so a later failure ends the recording
     * instead and keeps what there is.
     */
    protected encoderFailed(name: string | undefined): void {
        if (this.stopped || this.failure !== undefined) {
            return;
        }
        const written = this.chunks.reduce((size, chunk) => size + chunk.size, 0);
        let why = name ?? 'no reason given';
        while (written === 0 && this.candidates.length > 1) {
            const failed = this.mimeType;
            // The partial chunks belong to a container that is being
            // abandoned; keeping them would put its header in front of the
            // next encoder's file.
            //
            // The encoder they came from is silenced for the same reason, and
            // this is the part that is easy to miss: a `MediaRecorder` that
            // has failed still delivers what it had, and it delivers it after
            // this — Chrome hands over a whole finished MP4 of the third of a
            // second before the failure, `ftyp` and `moov` and `mfra` and all.
            // Arriving after the list has been cleared, that file would be
            // glued in front of the next encoder's, and every player would
            // read the recording through the wrong header: the abandoned
            // container's codecs, and its duration of nothing.
            const abandoned = this.recorder;
            if (abandoned) {
                abandoned.ondataavailable = null;
                abandoned.onerror = null;
            }
            this.chunks = [];
            this.candidates = this.candidates.slice(1);
            console.warn(`[emulator] ${failed} could not be encoded (${why}),`
                + ` recording as ${this.mimeType} instead`);
            try {
                this.startEncoder();
                return;
            } catch (error) {
                // Constructing the next one failed outright, which is a
                // different answer from the encoder failing later — either
                // way there may be another candidate behind it.
                why = error instanceof Error ? error.message : String(error);
            }
        }
        this.failure = name ?? 'the encoder failed';
        this.onDidFailEmitter.fire(this.failure);
    }

    /**
     * Both sources, mixed into the one track a recording can carry.
     *
     * In the core's own audio context, which is where the machine's sound
     * already is: taking it out through a `MediaStream` as well would put a
     * resampling bridge in front of the one thing that must not glitch.
     * ESSound is on the other side of such a bridge because it has no choice —
     * it plays media elements in a context of its own.
     */
    protected async openAudio(): Promise<MediaStreamTrack[]> {
        const context = this.core.audio;
        const mix = context.createMediaStreamDestination();
        this.mix = mix;
        this.core.connectAudio(mix);

        if (this.esSound?.hasTracks) {
            const source = context.createMediaStreamSource(this.esSound.openTap());
            source.connect(mix);
            this.esSoundSource = source;
        }
        return (await this.resampled(mix.stream)).getAudioTracks();
    }

    /**
     * The mix at a rate an encoder will take.
     *
     * The machine runs its audio at 41700 Hz and the recording is the one
     * place that cannot follow it there, because AAC has no such rate: handed
     * the mix as it is, Chrome fails the whole `avc1,mp4a.40.2` container on
     * the first frame and the recording falls back to AV1 and Opus. So the
     * mix is carried through a second context running at a rate AAC knows,
     * and a `MediaStream` is what carries it, since that is the only way
     * audio crosses between contexts.
     *
     * The resampling the header warns about is real but lands where it can be
     * afforded: behind the tap, so playback never goes through it, and in a
     * conversion the hardware was going to perform anyway a moment later.
     *
     * A context that cannot be built is not a reason to refuse to record. The
     * unbridged mix is returned instead, and the recording ends up in the
     * container that will have it — which is what would have happened before
     * any of this existed.
     */
    protected async resampled(stream: MediaStream): Promise<MediaStream> {
        const rate = bridgeSampleRateFor(this.core.audio.sampleRate);
        if (rate === undefined) {
            return stream;
        }
        try {
            const bridge = new AudioContext({ sampleRate: rate });
            this.bridge = bridge;
            // A context built while the page is not allowed to make sound
            // starts suspended, and a suspended one carries nothing: the
            // recording would run to the end and hold a picture with silence
            // beside it. Recording starts from a button, so the permission is
            // there to be taken.
            if (bridge.state === 'suspended') {
                await bridge.resume();
            }
            const source = bridge.createMediaStreamSource(stream);
            const destination = bridge.createMediaStreamDestination();
            source.connect(destination);
            this.bridgeSource = source;
            return destination.stream;
        } catch (error) {
            console.warn('[emulator] recording at the machine\'s own sample rate:'
                + ` the mix could not be resampled (${error instanceof Error ? error.message : error})`);
            this.closeBridge();
            return stream;
        }
    }

    /** Let go of the second context, which the browser will not collect. */
    protected closeBridge(): void {
        this.bridgeSource?.disconnect();
        this.bridgeSource = undefined;
        this.bridge?.close().catch(() => {
            // A context that has already gone needs no closing.
        });
        this.bridge = undefined;
    }

    /**
     * One frame of the machine, composed and handed to the encoder.
     *
     * Synchronous throughout: the buffer goes straight back to the worker when
     * this returns, so the upload to the texture has to have happened by then.
     */
    protected present(frame: Frame): void {
        if (this.stopped || !this.renderer || !this.canvas || !this.outputContext || !this.output) {
            return;
        }
        this.renderer.present(new Uint8Array(frame.pixels), frame.colorMode);
        this.outputContext.drawImage(this.canvas, 0, 0, this.output.width, this.output.height);
        this.track?.requestFrame();
        this.frames++;
    }

    /**
     * Hold the recording while the machine is not running.
     *
     * A paused emulator presents nothing and its audio context is suspended,
     * so a recorder left running would write a silent still for as long as the
     * pause lasted. Held instead, the file carries on where the game does.
     */
    setPaused(paused: boolean): void {
        if (this.stopped || this.paused === paused || !this.recorder) {
            return;
        }
        this.paused = paused;
        if (paused) {
            this.elapsed += Date.now() - this.since;
            if (this.recorder.state === 'recording') {
                this.recorder.pause();
            }
        } else {
            this.since = Date.now();
            if (this.recorder.state === 'paused') {
                this.recorder.resume();
            }
        }
    }

    /**
     * Stop, and hand back what was recorded.
     *
     * The tap is closed first so that no frame arrives after the encoder has
     * been told there are no more, and the encoder's last chunk is waited for
     * — a file assembled before `onstop` is a file missing its end.
     */
    async stop(): Promise<VideoRecording> {
        if (this.stopped) {
            throw new Error('This recording has already been stopped.');
        }
        this.stopped = true;
        if (!this.paused) {
            this.elapsed += Date.now() - this.since;
        }

        await this.sim.setVideoTap().catch(() => {
            // A machine that has already gone takes its tap with it.
        });

        const recorder = this.recorder;
        if (recorder && recorder.state !== 'inactive') {
            await new Promise<void>(resolve => {
                recorder.onstop = () => resolve();
                // An encoder that gives up still owes us what it has: waiting
                // for a `stop` that will never come would hang the caller, and
                // the chunks already handed over are a playable file.
                recorder.onerror = () => resolve();
                recorder.stop();
            });
        }
        this.release();

        return {
            blob: new Blob(this.chunks, { type: this.mimeType }),
            extension: this.extension,
            frames: this.frames,
            seconds: this.elapsed / 1000,
            mimeType: this.mimeType,
            failure: this.failure,
        };
    }

    /** Give up on a recording without assembling it — a ROM being closed. */
    async cancel(): Promise<void> {
        if (this.stopped) {
            return;
        }
        this.stopped = true;
        await this.sim.setVideoTap().catch(() => undefined);
        if (this.recorder && this.recorder.state !== 'inactive') {
            this.recorder.stop();
        }
        this.chunks.length = 0;
        this.release();
    }

    /** Everything this holds that the browser will not collect by itself. */
    protected release(): void {
        if (this.mix) {
            this.core.disconnectAudio(this.mix);
            this.esSoundSource?.disconnect();
            this.esSound?.closeTap();
            this.mix.disconnect();
        }
        this.mix = undefined;
        this.esSoundSource = undefined;
        this.closeBridge();
        this.track?.stop();
        this.track = undefined;
        this.renderer?.dispose();
        this.renderer = undefined;
        this.canvas = undefined;
        this.output = undefined;
        this.outputContext = undefined;
        this.recorder = undefined;
        this.stream = undefined;
        this.onDidFailEmitter.dispose();
    }
}
