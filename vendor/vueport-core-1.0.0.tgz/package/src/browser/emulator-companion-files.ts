/**
 * Where a ROM's save, save states and cheats go, by the companionFiles setting:
 *
 *   beside the ROM   `<rom dir>/Red Alarm (USA).p1.sram`
 *   in the store     `roms/Red Alarm (USA)/save.sram`
 *
 * Beside a ROM the files share a folder with everything else, so each carries the ROM's name, the convention
 * other emulators follow too. In the store each ROM gets a folder and the files are named for what they are.
 */
import {
    DEFAULT_SAVE_SLOT,
    EmulatorCompanionLocation,
    emulatorSaveSlot,
} from '../common/emulator-sram';
import { VueportStorage } from '../common/emulator-host';

export interface CompanionRom {
    name: string;
    // where the ROM itself is, when the host knows (never in a browser); beside-the-ROM needs it. For a ROM
    // from an archive this is the archive on the disk, so its name is not name; see besideStem
    location?: string;
}

// relative to the store's root; exported for the library, which weighs it and offers to clear it
export const COMPANION_STORE_ROOT = 'roms';

// what belongs to no particular ROM, beside them
const SHARED_ROOT = 'shared';

// the archives that hold one cartridge; the same list as the web package's VB_ARCHIVE_EXTENSIONS, which core
// cannot import
const CARTRIDGE_ARCHIVE_EXTENSIONS = ['.vb.zip', '.vbz'];

export class EmulatorCompanionFiles {

    constructor(
        protected readonly storage: VueportStorage,
        // read on every call, so a change in the setting takes effect at once
        protected readonly location: () => EmulatorCompanionLocation,
    ) { }

    // not the same as the setting: a ROM the host cannot place has no "beside", and every path below falls back
    // to the store; this lets a host tell the player
    besideRom(rom: CompanionRom): boolean {
        return this.location() === EmulatorCompanionLocation.ROM && rom.location !== undefined;
    }

    directory(rom: CompanionRom): string {
        return this.besideRom(rom)
            // location is defined whenever besideRom is true
            ? this.storage.parent(rom.location as string)
            : this.storeDirectory(rom);
    }

    // the ROM's own folder in the store, whatever the setting says
    protected storeDirectory(rom: CompanionRom): string {
        return this.storage.join(COMPANION_STORE_ROOT, this.storage.stem(rom.name));
    }

    // whether the file on the disk is an archive the ROM was unpacked from, the one case where the two names differ
    protected unpacked(rom: CompanionRom): boolean {
        return rom.location !== undefined && this.storage.name(rom.location) !== rom.name;
    }

    // the file on the disk, so Red Alarm.vbz gets Red Alarm.p1.sram whatever the ROM inside is called (.vb.zip is
    // one extension, or it would be Red Alarm.vb.p1.sram). A plain .zip names files for the ROM inside, as it may
    // be a whole collection, and every game sharing one save would be far worse
    protected besideStem(rom: CompanionRom): string {
        if (!this.unpacked(rom)) {
            return this.storage.stem(rom.name);
        }
        const file = this.storage.name(rom.location as string);
        const archive = CARTRIDGE_ARCHIVE_EXTENSIONS
            .find(extension => file.toLowerCase().endsWith(extension));
        return archive !== undefined && file.length > archive.length
            ? file.slice(0, -archive.length)
            : this.storage.stem(rom.name);
    }

    // macros marked global, always in the store and taking no ROM: they outlive the game they were recorded in,
    // and beside its file deleting the ROM would take them
    globalMacros(): string {
        return this.storage.join(SHARED_ROOT, 'macros.vueport-macros.json');
    }

    // the ROM as a path the cheat store hangs .cht off: beside the ROM the ROM (or, from an archive, where it
    // would be unpacked under the archive's name), in the store where it would be kept. Need not exist
    romPath(rom: CompanionRom): string {
        if (!this.besideRom(rom)) {
            return this.storage.join(this.directory(rom), rom.name);
        }
        // an extension even where the ROM inside had none, so taking the stem back off cannot cut into a name like
        // `Mario Clash (v1.1)`
        const extension = rom.name.slice(this.storage.stem(rom.name).length) || '.vb';
        return this.storage.join(this.directory(rom), `${this.besideStem(rom)}${extension}`);
    }

    /**
     * A player's save file on the slot they play. Numbered even with one machine running, as the two of a link
     * session each have a cartridge. The store keeps save.sram for player one, as it always has. Slot A is left
     * unspelt in both layouts: it holds every save from before slots existed, and is the one another emulator
     * would read. See EMULATOR_SAVE_SLOTS
     */
    saveRam(rom: CompanionRom, player = 1, slot: string = DEFAULT_SAVE_SLOT): string {
        const named = emulatorSaveSlot(slot);
        const suffix = named === DEFAULT_SAVE_SLOT ? '' : `.${named}`;
        return this.besideRom(rom)
            ? this.storage.join(
                this.directory(rom), `${this.besideStem(rom)}.p${player}${suffix}.sram`)
            : this.storage.join(
                this.directory(rom),
                player > 1 ? `save-${player}${suffix}.sram` : `save${suffix}.sram`);
    }

    // a linked pair is one state in one file (see wrapSaveState), and a state is identified by when it was taken.
    // Beside the ROM the id goes between the ROM's name and the extension, so one game's files sort together
    saveState(rom: CompanionRom, id: string): string {
        return this.besideRom(rom)
            ? this.storage.join(this.directory(rom), `${this.besideStem(rom)}.${id}.state`)
            : this.storage.join(this.directory(rom), `state-${id}.state`);
    }

    // the inverse of saveState: the naming is the index, so the browser can list a folder rather than keep one.
    // Beside a ROM the ROM's own name tells this game's files apart from others'
    saveStateId(rom: CompanionRom, fileName: string): string | undefined {
        if (!fileName.endsWith('.state')) {
            return undefined;
        }
        const body = fileName.slice(0, -'.state'.length);
        const prefix = this.besideRom(rom) ? `${this.besideStem(rom)}.` : 'state-';
        return body.length > prefix.length && body.startsWith(prefix)
            ? body.slice(prefix.length)
            : undefined;
    }

    /**
     * Where ESSound's tracks are looked for: the ROM's own folder when there is one, as real hardware reads them
     * from there. Deliberately not directory: the companionFiles setting only decides where the emulator's own
     * files go (as directory(rom), tracks beside a ROM were unfindable for anyone saving to the store). An archive
     * is the exception: its tracks are unpacked into the store and looked for there, rather than writing into and
     * clearing a folder of the player's own files.
     */
    sounds(rom: CompanionRom): string {
        return rom.location !== undefined && !this.unpacked(rom)
            ? this.storage.parent(rom.location)
            : this.storeDirectory(rom);
    }
}
