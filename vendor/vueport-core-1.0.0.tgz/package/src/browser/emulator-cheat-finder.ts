import { Emitter, Event } from '../common/emulator-events';
import {
    ScanDataType,
    ScanOperator,
    readScanValue,
    scanFirst,
    scanNext,
    scanValueBytes,
} from '../common/emulator-cheat-scan';
import { VB_CART_RAM_BASE, VB_WRAM_BASE } from '../common/vb-constants';
import { Sim } from './core/vb-core';

/**
 * Where a search looks.
 *
 * Only the two writable regions, because only they hold anything worth finding:
 * a value the player can make move lives in work memory, and one that survives
 * the power going off lives in the cartridge's save. Cartridge ROM never
 * changes, so there would be nothing to narrow against, and the hardware
 * registers are not variables.
 */
export enum CheatScanRegion {
    /** The Virtual Boy's 64 KB of work memory — where nearly everything is. */
    WRAM = 'wram',
    /** The cartridge's save data, for what survives a reset. */
    CART_RAM = 'cartRam',
}

export const CHEAT_SCAN_REGIONS: CheatScanRegion[] = [CheatScanRegion.WRAM, CheatScanRegion.CART_RAM];

/** WRAM is the whole of region 5 with 64 KB mirrored across it; this is one copy. */
const WRAM_LENGTH = 0x10000;

/** One surviving address, as the panel shows it. */
export interface CheatScanResult {
    /** A real CPU address, so a cheat can be written straight from it. */
    address: number;
    /** What it holds now. */
    value: number;
    /** What it held when the last pass was made, for the column beside it. */
    previous: number;
}

/**
 * The state of one search: what has been looked at, and what is left.
 *
 * Held beside the cheat store rather than inside the Cheats panel, and for the
 * same reason the store is held outside it — a search survives the panel being
 * closed and reopened, and switching to the editor and back. It does not
 * survive the ROM, which is the point at which every address it found stops
 * meaning anything.
 *
 * Nothing here polls. The panel asks for a pass when the player presses a
 * button, and asks for fresh values on a slow timer while it is open; both
 * cost one 64 KB read, which is what `readMemory` is sized for.
 */
export class CheatFinder {

    protected sim: Sim | undefined;
    /**
     * Where a poke goes, when something other than this owns that.
     *
     * Set while a link session is running: a write into either of the two
     * machines has to be made in both windows on the same frame, or they stop
     * being copies of each other. Returns false if it could not be arranged,
     * and the write goes straight in as it does when playing alone.
     */
    protected writer: ((address: number, bytes: number[]) => boolean) | undefined;

    protected region = CheatScanRegion.WRAM;
    protected type = ScanDataType.U16;

    /**
     * The snapshot the surviving candidates were last judged against.
     *
     * Undefined before the first pass. This is what "it went down" is measured
     * from — not the value on screen a moment ago, but the one that was there
     * when the player last pressed Scan.
     */
    protected baseline: Uint8Array | undefined;
    /** The most recent read, which is what the value column shows. */
    protected current: Uint8Array | undefined;
    /**
     * How much of the cartridge's save window this search covers.
     *
     * Fixed at the first pass and held until the search is thrown away; see
     * {@link read} for why it cannot move underneath a search.
     */
    protected cartRamBytes?: number;

    /** The surviving offsets into the region, or undefined before a first pass. */
    protected candidates: Uint32Array | undefined;
    /**
     * Every candidate set this search has been through, newest last.
     *
     * A pass that narrows to nothing is the ordinary way to get a search wrong
     * — the wrong data type, or a number read off the screen a frame late — and
     * starting over from an empty list is a punishment for a typo. Undo puts
     * the previous set back.
     */
    protected history: Uint32Array[] = [];
    /** True while a pass or a refresh is in flight, so the panel can say so. */
    protected working = false;

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires whenever the search changes, whatever changed it. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    /**
     * The simulation being searched, or undefined once it is gone.
     *
     * Set the same way the cheat store's is, from the widget as a ROM starts
     * and stops. A search is thrown away with the machine it was made against:
     * the addresses would still parse, but nothing they were narrowed against
     * exists any more.
     */
    setSim(sim: Sim | undefined): void {
        this.sim = sim;
        this.reset();
    }

    /** Hand a link session this search's pokes. See {@link writer}. */
    setWriter(writer: ((address: number, bytes: number[]) => boolean) | undefined): void {
        this.writer = writer;
    }

    get hasSim(): boolean {
        return this.sim !== undefined;
    }

    get busy(): boolean {
        return this.working;
    }

    get scanRegion(): CheatScanRegion {
        return this.region;
    }

    get dataType(): ScanDataType {
        return this.type;
    }

    /** True once a first pass has been made and there is something to narrow. */
    get started(): boolean {
        return this.candidates !== undefined;
    }

    /** How many addresses are still in the running. */
    get count(): number {
        return this.candidates?.length ?? 0;
    }

    get canUndo(): boolean {
        return this.history.length > 0;
    }

    /**
     * Change where the search looks, or how it reads memory.
     *
     * Both throw the search away rather than reinterpreting it: an offset that
     * survived as a halfword is not a candidate for the same search read as
     * bytes, and an offset into WRAM means nothing in the cartridge's save.
     */
    setRegion(region: CheatScanRegion): void {
        if (region === this.region) {
            return;
        }
        this.region = region;
        this.reset();
    }

    setDataType(type: ScanDataType): void {
        if (type === this.type) {
            return;
        }
        this.type = type;
        this.reset();
    }

    /** Forget the search, keeping the region and type the player chose. */
    reset(): void {
        this.baseline = undefined;
        this.current = undefined;
        this.cartRamBytes = undefined;
        this.candidates = undefined;
        this.history = [];
        this.changed();
    }

    /** Take back the last pass. */
    undo(): void {
        const previous = this.history.pop();
        if (previous) {
            this.candidates = previous;
            this.changed();
        }
    }

    /**
     * The first pass: read memory and keep what answers the question.
     *
     * With one of the relative operators and no value this keeps everything,
     * which is how a search for a number nobody can read starts — see
     * `emulator-cheat-scan.ts`.
     */
    async first(op: ScanOperator, value?: number): Promise<void> {
        await this.pass(async snapshot => {
            this.history = [];
            this.candidates = scanFirst(snapshot, this.type, op, value);
        });
    }

    /** A later pass: narrow what is left against what it held before. */
    async next(op: ScanOperator, value?: number): Promise<void> {
        const candidates = this.candidates;
        const baseline = this.baseline;
        if (!candidates || !baseline) {
            return this.first(op, value);
        }
        await this.pass(async snapshot => {
            this.history.push(candidates);
            this.candidates = scanNext(candidates, baseline, snapshot, this.type, op, value);
        });
    }

    /**
     * Read memory again without judging anything.
     *
     * What the panel calls on its timer, so the value column follows the game
     * while the player decides what to ask next. The baseline is deliberately
     * left alone: it is what the last pass was made against, and moving it here
     * would make "unchanged" mean "unchanged since a moment ago", which is not
     * a question anybody asked.
     */
    async refreshValues(): Promise<void> {
        const snapshot = await this.read();
        if (snapshot) {
            this.current = snapshot;
            this.changed();
        }
    }

    /**
     * Write a value straight into memory, once.
     *
     * The step that turns a list of addresses into an answer: poke a candidate
     * and look at the screen. Nothing is remembered — the game will overwrite
     * it on the next frame it feels like, which is exactly what a cheat exists
     * to prevent and what makes this a test rather than a fix.
     */
    async poke(address: number, value: number): Promise<void> {
        const sim = this.sim;
        if (!sim) {
            return;
        }
        const width = scanValueBytes(this.type);
        const bytes: number[] = [];
        for (let i = 0; i < width; i++) {
            bytes.push((value >>> (i * 8)) & 0xff);
        }
        if (!this.writer?.(address >>> 0, bytes)) {
            await sim.writeMemory(address >>> 0, new Uint8Array(bytes).buffer);
        }
        // Under a link session the write is booked a few frames out, so this
        // read is of the value as it still is. The panel is polling anyway and
        // picks the change up a moment later; refreshing here is what makes a
        // solo poke visible at once, which is the case that needs it.
        await this.refreshValues();
    }

    /**
     * The survivors, at most `limit` of them.
     *
     * Capped because a first pass over 64 KB can leave every address in the
     * running and a table of sixty-five thousand rows is neither drawable nor
     * readable. The count is reported separately, which is the number that
     * actually tells the player whether to keep narrowing.
     */
    results(limit: number): CheatScanResult[] {
        const candidates = this.candidates;
        const current = this.current;
        if (!candidates || !current) {
            return [];
        }
        const base = this.regionBase();
        const baseline = this.baseline ?? current;
        const shown = Math.min(limit, candidates.length);
        const results: CheatScanResult[] = [];
        for (let i = 0; i < shown; i++) {
            const offset = candidates[i];
            results.push({
                address: (base + offset) >>> 0,
                value: readScanValue(current, offset, this.type),
                previous: readScanValue(baseline, offset, this.type),
            });
        }
        return results;
    }

    /** How many hex digits a cheat written from this search should carry. */
    get cheatDigits(): number {
        return scanValueBytes(this.type) * 2;
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }

    // ------------------------------------------------------------- internals

    protected regionBase(): number {
        return this.region === CheatScanRegion.WRAM ? VB_WRAM_BASE : VB_CART_RAM_BASE;
    }

    /**
     * One pass: read, judge, and move the baseline to what was just read.
     *
     * The baseline moves here and nowhere else, so every relative question is
     * asked about the interval between two presses of Scan.
     */
    protected async pass(judge: (snapshot: Uint8Array) => Promise<void>): Promise<void> {
        if (this.working) {
            return;
        }
        this.working = true;
        this.changed();
        try {
            const snapshot = await this.read();
            if (!snapshot) {
                return;
            }
            await judge(snapshot);
            this.baseline = snapshot;
            this.current = snapshot;
        } finally {
            this.working = false;
            this.changed();
        }
    }

    /**
     * A copy of the region as it is right now.
     *
     * Undefined rather than a throw when there is no machine: the panel is
     * shown beside a screen that can be closed under it, and a search asking
     * about a disposed core is a mistake to shrug off rather than to report.
     */
    protected async read(): Promise<Uint8Array | undefined> {
        const sim = this.sim;
        if (!sim) {
            return undefined;
        }
        try {
            if (this.region === CheatScanRegion.CART_RAM) {
                // The save window is the whole 16 MiB of Game Pak RAM, nearly
                // none of which any game touches. Reading it whole would copy
                // 16 MiB across the worker boundary for every pass and hold
                // two of them here at once, so the search looks only as far up
                // the window as the game has written.
                //
                // Settled once and kept for the length of a search: a pass
                // compares offset against offset, so a region that changed
                // size between two of them would not be the same region. A
                // game that reaches higher up mid-search is caught by starting
                // the search again, which is what changing region does too.
                if (this.cartRamBytes === undefined) {
                    this.cartRamBytes = (await sim.cartRamInfo()).used;
                }
                return new Uint8Array(await sim.getCartRam(this.cartRamBytes));
            }
            return new Uint8Array(await sim.readMemory(VB_WRAM_BASE, WRAM_LENGTH));
        } catch {
            // The core went away between the question and the answer.
            return undefined;
        }
    }

    protected changed(): void {
        this.onDidChangeEmitter.fire();
    }
}
