/**
 * What the status readouts say.
 *
 * Only the formatting — where the readings are shown is each host's own: the
 * standalone build has a strip along the bottom of its window, the studio puts
 * them in the workbench's status bar. What they *say* should not differ
 * between the two, which is why the wording lives here rather than beside
 * either one.
 */
import { nls } from '../common/emulator-nls';
import { VueportRumblePack } from '../common/emulator-rumble';
import { Speed } from '../common/vb-protocol';
import { EsSoundPlayer } from './emulator-essound-player';
import { connectedGamepads } from './emulator-gamepad';
import { VbHardwareMode } from './emulator-types';

/** What a host has to be able to answer for the readouts below. */
export interface EmulatorStatusSource {
    /** Whether there is a cartridge in the machine. */
    readonly hasRom: boolean;
    readonly paused: boolean;
    /** The measured rate, as the worker last reported it. */
    readonly emulationSpeed: Speed | undefined;
    readonly esSound: EsSoundPlayer;
    readonly rumblePack: VueportRumblePack;
    /** Whether VB Color is switched on at all. */
    readonly vbcSupportEnabled: boolean;
    /** Whether the running machine actually is one. */
    readonly vbcHardwareActive: boolean;
    /** What the setting says, which may be `auto`. */
    readonly selectedHardwareMode: string;
}

/** Shown wherever a reading has nothing to report. */
export const STATUS_NONE = '—';

/**
 * What the speed reads as.
 *
 * The measured rate rather than the requested one: a fast forward ratio the
 * machine cannot sustain is clamped, so the two disagree exactly when knowing
 * the difference matters.
 */
export function formatEmulationSpeed(source: EmulatorStatusSource): string {
    if (!source.hasRom) {
        return STATUS_NONE;
    }
    if (source.paused) {
        return '⏸';
    }
    return source.emulationSpeed
        ? `${Math.round(source.emulationSpeed.ratio * 100)}%`
        : STATUS_NONE;
}

/** Both the physical model and whether Auto chose it. */
export function formatHardwareMode(source: EmulatorStatusSource): string {
    if (!source.vbcSupportEnabled) {
        return nls.localize('vueport/vbColor/hardware/virtualBoy', 'Virtual Boy');
    }
    const model = source.vbcHardwareActive
        ? nls.localize('vueport/vbColor/hardware/vbColor', 'VB Color')
        : nls.localize('vueport/vbColor/hardware/virtualBoy', 'Virtual Boy');
    return source.selectedHardwareMode === VbHardwareMode.AUTO
        ? nls.localize('vueport/vbColor/hardware/autoStatus', 'Auto ({0})', model)
        : model;
}

/**
 * What the ESSound entry reads as.
 *
 * The expansion plays audio files kept beside the cartridge. A browser cannot
 * reach the folder a ROM was opened from, so the only way they arrive is
 * zipped with it — which is what "no tracks" usually means there.
 */
export function formatEsSound(source: EmulatorStatusSource): string {
    if (!source.hasRom || !source.esSound.isScanned) {
        return STATUS_NONE;
    }
    const count = source.esSound.list.length;
    if (count === 0) {
        return STATUS_NONE;
    }
    // Two keys rather than one with a count: a language that inflects
    // differently needs to write the whole phrase, not a suffix.
    const tracks = count === 1
        ? nls.localize('vueport/status/oneTrack', '1 track')
        : nls.localize('vueport/debug/panels/esSound/tracks', '{0} tracks', count);
    const playing = source.esSound.playing.length;
    return playing > 0
        ? nls.localize('vueport/debug/panels/esSound/tracksPlaying', '{0}, {1} playing', tracks, playing)
        : tracks;
}

/**
 * The pack's own name where it gives one, or that there is simply one there.
 *
 * A pack the link cable has taken the port from says so instead of its name:
 * the name would read as "working", and the whole point of the reading is that
 * it is not. See `applyRumbleForwarding`.
 */
export function formatRumblePack(source: EmulatorStatusSource): string {
    if (!source.rumblePack.connected) {
        return STATUS_NONE;
    }
    if (source.rumblePack.linkPortInUse) {
        return nls.localize('vueport/status/rumbleLinkPortTaken', 'off (linked)');
    }
    return source.rumblePack.deviceName
        ?? nls.localize('vueport/status/connected', 'connected');
}

/** The first controller the browser has named, or that there is none. */
export function formatController(): string {
    return connectedGamepads()[0] ?? STATUS_NONE;
}

/** A program counter, as the debugger spells one. */
export function formatProgramCounter(pc: number | undefined): string {
    return pc === undefined
        ? STATUS_NONE
        : `0x${(pc >>> 0).toString(16).toUpperCase().padStart(8, '0')}`;
}

/** How many classes the symbol table describes. */
export function formatSymbolCount(classes: number | undefined): string {
    return classes === undefined
        ? STATUS_NONE
        : nls.localize('vueport/status/symbolClasses', '{0} classes', classes.toLocaleString());
}
