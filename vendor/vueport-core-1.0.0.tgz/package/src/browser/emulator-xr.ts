/**
 * Playing in a headset: an immersive WebXR session that shows each eye its own
 * picture, which is what the Virtual Boy was built around.
 *
 * The game keeps running exactly as it does on the page. The worker still
 * draws the page's canvas; this takes a second copy of every frame through the
 * same video tap a recording uses (see `setVideoTap`), because WebXR exists on
 * the page's thread only and the worker's canvas cannot be shared with it.
 *
 * Each frame is composed once, side by side, by the ordinary renderer and its
 * shader — palette, VB Color and frame blending all come along — into a small
 * texture of the page's own. From there it reaches the headset one of two ways:
 *
 * - A quad layer, where the browser offers them. The headset's compositor
 *   puts the picture on a screen in space itself, which keeps it sharper and
 *   steadier than anything drawn into the eye buffers could be, and lets each
 *   eye be given its half of one texture. Enlarged by a whole multiple first,
 *   so the compositor's own filtering does not blur the pixels.
 * - Otherwise a projection layer, into which the screen is drawn per eye, with
 *   a filter that keeps pixel edges sharp without shimmering.
 *
 * Both eyes see the screen at the same place. The depth is the game's own:
 * the parallax between the two pictures puts things in front of or behind it,
 * as the console did, and the 3D Depth setting scales it as it always does.
 *
 * The headset's controllers are read here too, since a headset browser stops
 * the page's animation frames while a session lasts and never lists its
 * controllers to the Gamepad API. Their two sticks are the Virtual Boy's two
 * D-pads; see `readControllers`.
 *
 * In parts: the WebXR declarations in `emulator-xr-webxr.ts`, the controllers
 * in `emulator-xr-input.ts`, the drawing in `emulator-xr-render.ts`, and what
 * is drawn on menus and around the screen in `emulator-xr-panel.ts`.
 */

import {
    buildDisplayMode,
    DisplayMode,
    VbRenderingMode,
    VB_FRAME_RATE,
    VB_SCREEN_HEIGHT,
    VB_SCREEN_WIDTH,
} from '../common/vb-constants';
import { Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import {
    noXrButtons,
    readControllers,
    XrButtons,
    XrControllerReading,
    XR_STICK_THRESHOLD,
} from './emulator-xr-input';
import {
    drawXrBadges,
    drawXrPanel,
    drawXrPointer,
    drawXrStatus,
    drawXrToast,
    firstXrItem,
    moveXrCursor,
    XrHud,
    XrPanel,
    XrPanelRow,
    XR_BADGES_PIXELS,
    XR_PANEL_PIXELS,
    XR_POINTER_PIXELS,
    XR_STATUS_PIXELS,
    XR_TOAST_PIXELS,
} from './emulator-xr-panel';
import {
    buildProgram,
    COPY_FRAGMENT_SHADER,
    COPY_VERTEX_SHADER,
    multiply,
    OVERLAY_COPY_FRAGMENT_SHADER,
    OVERLAY_FRAGMENT_SHADER,
    OVERLAY_UNIT,
    quadEyeRegions,
    quadSizeFactor,
    SCREEN_FRAGMENT_SHADER,
    SCREEN_UNIT,
    SCREEN_VERTEX_SHADER,
    XrFrameRenderer,
    XrOverlay,
} from './emulator-xr-render';
import {
    XrFrame,
    xrGlobals,
    XrInputSource,
    XrProjectionLayer,
    XrQuadLayer,
    XrSession,
    XrSpace,
    xrSystem,
    XrWebGlBinding,
    XrWebGlLayer,
} from './emulator-xr-webxr';

// ------------------------------------------------------------- Placement

/** How far in front of the player the screen stands, in meters. */
const XR_SCREEN_DISTANCE = 2;
/** How the screen is shown in a headset; adjustable from inside it. */
export interface XrScreen {
    /** How wide the screen is, in meters, at the distance it stands at. */
    width: number;
    /**
     * The stereo depth to play at in the headset, in percent, as
     * `stereoDepth` is — but of half the real console's: see
     * {@link XR_DEPTH_SCALE}. Its own setting, because how deep a picture
     * looks depends on how big it is, and in a headset it is big.
     */
    depth: number;
}

/**
 * What the headset's depth is worth in the machine's own terms. A screen in a
 * headset is so much bigger than the console's that its full depth was too
 * strong to sit through, on a Quest 3; so 100 % there is half the console's,
 * and the setting still reads 100 % when it is where it starts out.
 */
export const XR_DEPTH_SCALE = 0.5;

/** The stereo depth a headset's setting comes to, for the machine. */
export function xrStereoDepth(screen: XrScreen): number {
    return Math.round(screen.depth * XR_DEPTH_SCALE);
}

/**
 * About 44 degrees across at the distance above, roughly how much of the view
 * the console's own screen fills; and the headset's full depth.
 */
export const XR_DEFAULT_SCREEN: XrScreen = { width: 1.6, depth: 100 };
/** The narrowest and widest the screen can be made, in meters. */
export const XR_MIN_WIDTH = 0.6;
export const XR_MAX_WIDTH = 4;
/** The deepest the headset's depth goes, in percent; see {@link XrScreen.depth}. */
export const XR_MAX_DEPTH = 200;

/** A view brought into the ranges a headset can show. */
export function clampXrScreen(view: Partial<XrScreen>): XrScreen {
    const width = Number.isFinite(view.width) ? view.width! : XR_DEFAULT_SCREEN.width;
    const depth = Number.isFinite(view.depth) ? view.depth! : XR_DEFAULT_SCREEN.depth;
    return {
        width: Math.min(XR_MAX_WIDTH, Math.max(XR_MIN_WIDTH, width)),
        depth: Math.round(Math.min(XR_MAX_DEPTH, Math.max(0, depth))),
    };
}

/** How tall a screen of this width is. */
function screenHeight(width: number): number {
    return width * VB_SCREEN_HEIGHT / VB_SCREEN_WIDTH;
}

/** How fast the screen grows or shrinks with a stick all the way over: by this factor a second. */
const XR_WIDTH_RATE = 1.6;
/** How fast the depth changes with a stick all the way over, in percent a second. */
const XR_DEPTH_RATE = 60;
/** How far a stick has to lean before it adjusts anything. */
const XR_ADJUST_DEAD_ZONE = 0.3;
/** How often an adjustment in progress is passed on, in milliseconds. */
const XR_ADJUST_REPORT_MS = 100;
/**
 * How many texels a Virtual Boy pixel is given in a quad layer. The compositor
 * filters the texture as it maps it onto the display; at about three display
 * pixels per Virtual Boy pixel on a current headset, three texels each keeps
 * that filtering to the pixels' edges instead of smearing them.
 */
const XR_LAYER_SCALE = 3;

/** How long a start waits on a step that should be immediate, in milliseconds. */
const XR_STEP_TIMEOUT_MS = 2000;

/** How long both grips are held to leave the headset, in milliseconds. */
const XR_EXIT_HOLD_MS = 1000;

/**
 * The display rate to ask the headset for.
 *
 * A whole multiple of the machine's own 50 Hz shows every frame for the same
 * number of refreshes, so motion in the game is even; the highest such rate
 * wins. Without one, the highest rate at all, because the more often the
 * display refreshes, the less a frame can be shown too early or too late.
 */
export function pickXrFrameRate(rates: readonly number[]): number | undefined {
    if (rates.length === 0) {
        return undefined;
    }
    const multiples = rates.filter(rate => {
        const times = Math.round(rate / VB_FRAME_RATE);
        return times >= 2 && Math.abs(rate - times * VB_FRAME_RATE) < 0.5;
    });
    return Math.max(...(multiples.length > 0 ? multiples : rates));
}

/** How wide a menu is in the room, and how far away: in front of the screen. */
const XR_PANEL_WIDTH = 0.9;
const XR_PANEL_DISTANCE = 1.7;
/** How wide a line of news is, and how far beneath the screen it sits. */
const XR_TOAST_WIDTH = 0.9;
const XR_TOAST_GAP = 0.06;
/** How far the badges and the status strip stand off the screen's edges, in meters. */
const XR_HUD_GAP = 0.03;
/** How often what is around the screen is read again, in milliseconds. */
const XR_HUD_MS = 250;
/** How long a line of news stays up, in milliseconds. */
const XR_TOAST_MS = 3000;
/** How wide the pointer's dot is, in meters, and how far in front of what it points at. */
const XR_POINTER_WIDTH = 0.022;
const XR_POINTER_LIFT = 0.005;
/** How long a stick is held before the cursor repeats, then how often it does. */
const XR_REPEAT_DELAY_MS = 400;
const XR_REPEAT_MS = 150;

/** How the session went, for telling a headset that showed nothing why. */
export interface XrDiagnostics {
    /**
     * How far starting it got: the last step begun. A session that showed
     * nothing at all is most often one whose start never finished.
     */
    stage: XrStage;
    /** How the picture reached the headset. */
    path: 'quad' | 'projection' | 'none';
    /** The display rate asked for, if one was. */
    frameRate?: number;
    /** Headset frames drawn. */
    xrFrames: number;
    /** Frames the machine presented while the session lasted. */
    gameFrames: number;
    /** The first thing that went wrong, if anything did. */
    error?: string;
    /** The first WebGL error seen, as its code. */
    glError?: number;
    /** Where it was seen: the step it surfaced after. */
    glErrorAt?: string;
    /** What the browser said each eye's part of the quad layer was, on the first frame. */
    quadLayout?: string;
    /** Whether the context was lost along the way. */
    contextLost?: boolean;
    /** Headset frames that came without a pose to draw from. */
    posesMissing: number;
    /** The first thing that went wrong reading the controllers, apart from drawing. */
    inputError?: string;
}

/**
 * What kind of session to ask for: `vr`, for a headset that can only show a
 * room of its own; `ar`, for one that can also show the room it is in. An
 * `ar` session shows that room only as its backdrop says — see
 * {@link EmulatorXrSession.setBackdrop} — and covers it in black otherwise,
 * so that it can go between them without being asked for again: a browser
 * grants a session only to a gesture, and switching from inside one has none.
 */
export type XrMode = 'vr' | 'ar';

/**
 * What is around the screen: black, a room of its own; the player's room,
 * passthrough; or the player's room through the screen too — its black made
 * see-through, so that only what the game lights up floats in the room, a
 * hologram. Anything but black wants an `ar` session.
 */
export type XrBackdrop = 'black' | 'passthrough' | 'hologram';

/** The WebXR session mode each of those is. */
function sessionMode(mode: XrMode): string {
    return mode === 'ar' ? 'immersive-ar' : 'immersive-vr';
}

/** The steps of starting a session, in order; see {@link XrDiagnostics.stage}. */
export type XrStage = 'session' | 'context' | 'space' | 'layer' | 'loop' | 'machine' | 'running';

/** What a session needs from the emulator it shows. */
export interface EmulatorXrHost {
    /** The machine to show, if one is running yet; see {@link EmulatorXrSession.setSim}. */
    readonly sim: Sim | undefined;
    /** The controls to drive it with. */
    readonly input: EmulatorInputController;
    /** The display settings; the headset takes their palette and blending. */
    displayMode(): DisplayMode;
    /** The session is over, whoever ended it, and this is how it went. */
    onXrEnded(diagnostics: XrDiagnostics): void;
    /**
     * Ask for the machine's audio again. The machine is clocked by its audio,
     * so a headset that stops the page's sound on the way in would freeze it;
     * called on the way in and on every trigger pressed in the headset, which
     * the browser counts as a gesture as it would a click.
     */
    resumeAudio?(): void;
    /**
     * False to draw into the eye buffers even where the browser offers a quad
     * layer — for telling a layer problem from any other.
     */
    quadLayers?: boolean;
    /** What kind of session to ask for; `vr` without one. */
    mode?: XrMode;
    /** What an `ar` session starts out with around the screen; black without one. */
    backdrop?: XrBackdrop;
    /** How to show the screen, as last left; {@link XR_DEFAULT_SCREEN} without one. */
    view?: XrScreen;
    /**
     * The screen's size or depth has been adjusted from inside the headset.
     * The depth is the host's to apply — it is the machine's, not the
     * picture's — and both are the host's to keep for next time.
     */
    onXrViewChanged?(view: XrScreen): void;
    /**
     * The menu a stick click opens, built fresh each time it opens. Absent,
     * or answering nothing, leaves the click alone.
     */
    quickMenu?(): XrPanel | undefined;
    /**
     * What the page shows around its picture — badges, status bar — to show
     * around the screen. Asked a few times a second; drawn again only when
     * the answer changes.
     */
    hud?(): XrHud | undefined;
}

/** The context attributes the renderer asks for, plus the headset's own. */
const XR_CONTEXT_ATTRIBUTES = {
    alpha: false,
    antialias: false,
    depth: false,
    preserveDrawingBuffer: true,
    stencil: false,
    xrCompatible: true,
};

/** Sessions started so far, for telling their copies of the frames apart; see `tapOwner`. */
let sessionCount = 0;

/**
 * One immersive session. Start one with {@link EmulatorXrSession.start} from a
 * click or a key press — a browser grants a headset to nothing else, and only
 * for a few seconds after it, so a game can be started into a session that is
 * already showing: the screen is a dim red until there is a machine to show.
 */
export class EmulatorXrSession {

    /** Whether this browser has a headset to offer — for passthrough, one that can show the room. */
    static async isSupported(mode: XrMode = 'vr'): Promise<boolean> {
        try {
            return await xrSystem()?.isSessionSupported(sessionMode(mode)) ?? false;
        } catch {
            // A page whose permissions policy withholds `xr-spatial-tracking`
            // is told so by a rejection rather than a false.
            return false;
        }
    }

    static async start(host: EmulatorXrHost): Promise<EmulatorXrSession> {
        const xr = xrSystem();
        if (!xr) {
            throw new Error('There is no headset to play in.');
        }
        const stats: XrDiagnostics = { stage: 'session', path: 'none', xrFrames: 0, gameFrames: 0, posesMissing: 0 };
        const reach = (stage: XrStage): void => {
            stats.stage = stage;
        };
        reach('session');
        // First, while the click that asked for it still counts as one.
        // Layers only when a quad layer is wanted: a session that has them
        // may refuse a base layer outright, as the Quest Browser does.
        const session = await xr.requestSession(sessionMode(host.mode ?? 'vr'), {
            optionalFeatures: host.quadLayers === false ? [] : ['layers'],
        });
        let renderer: XrFrameRenderer | undefined;
        let xrSession: EmulatorXrSession | undefined;
        try {
            reach('context');
            // Compatible from the start rather than made so afterwards: making
            // a context compatible may rebuild it, and with it lose every
            // texture and program the renderer had already made in it.
            const canvas = document.createElement('canvas');
            canvas.getContext('webgl2', XR_CONTEXT_ATTRIBUTES);
            renderer = new XrFrameRenderer(canvas, xrDisplayMode(host.displayMode()));
            const gl = renderer.context;
            // Already compatible, so this has nothing to do — and a start
            // must not hang on it if it never says so.
            await Promise.race([
                (gl as WebGL2RenderingContext & { makeXRCompatible(): Promise<void> }).makeXRCompatible(),
                new Promise(resolve => setTimeout(resolve, XR_STEP_TIMEOUT_MS)),
            ]);
            reach('space');
            const space = await session.requestReferenceSpace('local');
            xrSession = new EmulatorXrSession(host, session, renderer, canvas, space, stats, reach);
            await xrSession.begin();
            return xrSession;
        } catch (error) {
            if (xrSession) {
                // Releases everything, the renderer included.
                await xrSession.end();
            } else {
                renderer?.dispose();
                await session.end().catch(() => undefined);
            }
            throw error;
        }
    }

    protected readonly gl: WebGL2RenderingContext;
    /** The side-by-side picture, composed once per frame that arrives. */
    protected readonly image: WebGLTexture;
    protected readonly imageFramebuffer: WebGLFramebuffer;
    /** Where a layer's texture is attached to be drawn into. */
    protected readonly layerFramebuffer: WebGLFramebuffer;

    /** The quad layer, its binding, and the program that fills it. */
    protected quad: {
        binding: XrWebGlBinding;
        layer: XrQuadLayer;
        program: WebGLProgram;
        viewport: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        /** Copies a menu or a line of news into its own quad layer. */
        overlayProgram: WebGLProgram;
        overlayViewport: WebGLUniformLocation | null;
        /** Dark see-through, for the hologram backdrop. */
        hologram: WebGLUniformLocation | null;
        /**
         * Black over the whole view, under everything, for an `ar` session
         * whose backdrop is black — where the browser has projection layers.
         */
        cover: XrProjectionLayer | undefined;
    } | undefined;
    /** Otherwise, the projection layer and the program that draws the screen into it. */
    protected projection: {
        layer: XrWebGlLayer;
        program: WebGLProgram;
        size: WebGLUniformLocation | null;
        viewProjection: WebGLUniformLocation | null;
        eye: WebGLUniformLocation | null;
        hologram: WebGLUniformLocation | null;
        /** Draws a menu or a line of news over the screen. */
        overlayProgram: WebGLProgram;
        overlayViewProjection: WebGLUniformLocation | null;
        overlayCenter: WebGLUniformLocation | null;
        overlaySize: WebGLUniformLocation | null;
    } | undefined;

    /** The machine shown, if there is one; see {@link setSim}. */
    protected sim: Sim | undefined;
    /** What is around the screen; see {@link setBackdrop}. */
    protected backdropShown: XrBackdrop;
    /**
     * What this session's copy of the frames is asked for under. Its own, not
     * one every session shares, so that a session letting go of its copy can
     * never take another's with it, whichever order one ends and the next
     * starts in.
     */
    protected readonly tapOwner = `xr-${++sessionCount}`;
    /** How the screen is shown, as adjusted from inside the headset. */
    protected view: XrScreen;
    /** When the view was last passed on, and the frame time before this one. */
    protected viewReportedAt = 0;
    protected lastFrameTime: number | undefined;
    /** Whether an adjustment is under way, so its end can be passed on. */
    protected adjusting = false;
    /** The menu or question in front of the screen, and where its cursor is. */
    protected panel: { panel: XrPanel; cursor: number } | undefined;
    protected readonly panelOverlay: XrOverlay;
    /** The line of news beneath the screen, and until when it stays. */
    protected readonly toastOverlay: XrOverlay;
    protected toastUntil = 0;
    /** The badges over the screen and the status strip beneath it. */
    protected readonly badgesOverlay: XrOverlay;
    protected readonly statusOverlay: XrOverlay;
    /** When they were last read, and what they said, so unchanged ones are not drawn again. */
    protected hudReadAt = -Infinity;
    protected hudShown: string | undefined;
    /** Where each item of the panel up was drawn, for what a controller points at. */
    protected panelRows: XrPanelRow[] = [];
    /** The dot where a controller's ray meets the panel. */
    protected readonly pointerOverlay: XrOverlay;
    /** The hand that points, which is the one that last pulled its trigger. */
    protected pointingHand: 'left' | 'right' = 'right';
    /** What the ray is on: an item, which a trigger then takes; the panel around them; or nothing. */
    protected pointingAt: 'item' | 'panel' | 'nothing' = 'nothing';
    /** The buttons held on the frame before, for telling a press from a hold. */
    protected previousButtons: XrButtons = noXrButtons();
    /** The direction a stick is moving the cursor in, and when it moves it next. */
    protected repeat: { step: number; at: number } | undefined;
    /**
     * Whether the game is kept from the controllers until they are let go:
     * the press that closed a menu must not reach the game as well.
     */
    protected heldBack = false;
    /** Whether a frame has arrived since the picture was last composed. */
    protected dirty = false;
    protected frameHandle: number | undefined;
    /** Which hands are holding their grip, by the session's own events. */
    protected readonly squeezing = new Set<string>();
    /** Ends the session once both grips have been held long enough. */
    protected exitTimer: ReturnType<typeof setTimeout> | undefined;
    protected ended = false;
    /** Whether {@link begin} got all the way, and the host is owed an `onXrEnded`. */
    protected started = false;

    protected constructor(
        protected readonly host: EmulatorXrHost,
        protected readonly session: XrSession,
        protected readonly renderer: XrFrameRenderer,
        canvas: HTMLCanvasElement,
        protected readonly space: XrSpace,
        protected readonly stats: XrDiagnostics,
        protected readonly reach: (stage: XrStage) => void,
    ) {
        const gl = renderer.context;
        this.gl = gl;
        this.view = clampXrScreen(host.view ?? XR_DEFAULT_SCREEN);
        this.backdropShown = this.mode === 'ar' ? host.backdrop ?? 'black' : 'black';
        canvas.addEventListener('webglcontextlost', () => {
            this.stats.contextLost = true;
        });

        gl.activeTexture(gl.TEXTURE0 + SCREEN_UNIT);
        const image = gl.createTexture();
        const imageFramebuffer = gl.createFramebuffer();
        const layerFramebuffer = gl.createFramebuffer();
        if (!image || !imageFramebuffer || !layerFramebuffer) {
            throw new Error('Could not allocate the headset picture.');
        }
        gl.bindTexture(gl.TEXTURE_2D, image);
        gl.texStorage2D(gl.TEXTURE_2D, 1, gl.RGBA8, VB_SCREEN_WIDTH * 2, VB_SCREEN_HEIGHT);
        // Linear for the sharp-bilinear filter; the quad layer's copy reads
        // texels directly and is not affected.
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.bindFramebuffer(gl.FRAMEBUFFER, imageFramebuffer);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, image, 0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.activeTexture(gl.TEXTURE0);

        this.image = image;
        this.imageFramebuffer = imageFramebuffer;
        this.layerFramebuffer = layerFramebuffer;
        this.panelOverlay = new XrOverlay(gl, XR_PANEL_PIXELS, XR_PANEL_WIDTH);
        this.panelOverlay.place(0, 0, -XR_PANEL_DISTANCE);
        this.toastOverlay = new XrOverlay(gl, XR_TOAST_PIXELS, XR_TOAST_WIDTH);
        this.badgesOverlay = new XrOverlay(gl, XR_BADGES_PIXELS, this.view.width, true);
        this.statusOverlay = new XrOverlay(gl, XR_STATUS_PIXELS, this.view.width);
        this.pointerOverlay = new XrOverlay(gl, XR_POINTER_PIXELS, XR_POINTER_WIDTH, true);
        drawXrPointer(this.pointerOverlay.canvas);
        this.pointerOverlay.upload();
        this.placeAround();
        this.clearImage();
    }

    /**
     * A red screen, until a frame is composed, rather than the texture's
     * transparent black: a screen that is there but has nothing on it reads
     * differently from one that is not there at all.
     */
    protected clearImage(): void {
        const gl = this.gl;
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.imageFramebuffer);
        gl.clearColor(0.45, 0, 0, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    protected async begin(): Promise<void> {
        const session = this.session;
        // First, so that a session the headset ends while this is still
        // setting up is cleaned up like any other.
        session.addEventListener('end', this.onEnd);
        session.addEventListener('select', this.onGesture);
        session.addEventListener('squeeze', this.onGesture);
        session.addEventListener('visibilitychange', this.onGesture);
        session.addEventListener('squeezestart', this.onSqueezeStart);
        session.addEventListener('squeezeend', this.onSqueezeEnd);
        this.checkGl('setting up');
        this.reach('layer');
        if (this.host.quadLayers === false || !this.createQuadLayer()) {
            this.createProjectionLayer();
        }
        this.applyScreenSize();
        this.checkGl('creating the layer');
        this.host.resumeAudio?.();

        this.reach('loop');
        this.host.input.setExternalFrames(true);
        this.frameHandle = session.requestAnimationFrame(this.onFrame);

        const rate = pickXrFrameRate([...session.supportedFrameRates ?? []]);
        if (rate !== undefined && session.updateTargetFrameRate) {
            this.stats.frameRate = rate;
            // Not waited for. The change takes effect within the frame loop,
            // and the promise settles only once it has — so waiting for it
            // before the loop runs waits for good, which on a Quest left the
            // headset black. A rate the headset refuses leaves it at its own.
            session.updateTargetFrameRate(rate).catch(() => undefined);
        }

        this.reach('machine');
        await this.setSim(this.host.sim);
        if (this.ended) {
            throw new Error('The headset session ended while it was starting.');
        }
        this.reach('running');
        this.started = true;
    }

    /**
     * Show this machine, or none — a game being opened, closed, or built again
     * underneath the session, which outlives all three.
     */
    async setSim(sim: Sim | undefined): Promise<void> {
        if (sim === this.sim) {
            return;
        }
        const previous = this.sim;
        this.sim = sim;
        if (previous) {
            // A machine that has already gone took its tap with it.
            await previous.setVideoTap(undefined, this.tapOwner).catch(() => undefined);
        }
        if (this.ended) {
            return;
        }
        if (!sim) {
            this.dirty = false;
            this.clearImage();
            return;
        }
        // The picture on show now, so the headset has it at once rather than
        // from the next frame — which a paused machine never presents.
        const current = await sim.readFrame().catch(() => undefined);
        if (this.sim !== sim || this.ended) {
            return;
        }
        if (current) {
            [...current.previous].reverse().forEach((before, index) =>
                this.renderer.present(new Uint8Array(before.pixels), before.colorMode, index === 0 ? 'jump' : 'next'));
            this.renderer.present(
                new Uint8Array(current.pixels), current.colorMode, current.previous.length > 0 ? 'next' : 'jump');
            this.dirty = true;
            // A game that stays paused presents nothing more, and is shown all the same.
            this.stats.gameFrames++;
            this.checkGl('taking the picture on show');
        }
        await sim.setVideoTap(frame => {
            if (this.sim === sim && !this.ended) {
                this.renderer.present(new Uint8Array(frame.pixels), frame.colorMode, frame.kind);
                this.dirty = true;
                this.stats.gameFrames++;
                if (this.stats.gameFrames <= 3) {
                    this.checkGl('taking a game frame');
                }
            }
        }, this.tapOwner);
        // Replaced or ended while the tap was being opened.
        if (this.sim !== sim || this.ended) {
            await sim.setVideoTap(undefined, this.tapOwner).catch(() => undefined);
        }
    }

    /** Put the screen in a quad layer, if this browser has them. */
    protected createQuadLayer(): boolean {
        const Binding = xrGlobals.XRWebGLBinding;
        const Transform = xrGlobals.XRRigidTransform;
        if (!Binding || !Transform || !this.session.enabledFeatures?.includes('layers')) {
            return false;
        }
        try {
            const binding = new Binding(this.session, this.gl);
            const layer = binding.createQuadLayer({
                space: this.space,
                viewPixelWidth: VB_SCREEN_WIDTH * XR_LAYER_SCALE,
                viewPixelHeight: VB_SCREEN_HEIGHT * XR_LAYER_SCALE,
                layout: 'stereo-left-right',
                textureType: 'texture',
                isStatic: false,
                width: this.view.width * quadSizeFactor(),
                height: screenHeight(this.view.width) * quadSizeFactor(),
                transform: new Transform({ x: 0, y: 0, z: -XR_SCREEN_DISTANCE }),
            });
            const gl = this.gl;
            const program = buildProgram(gl, COPY_VERTEX_SHADER, COPY_FRAGMENT_SHADER);
            gl.useProgram(program);
            gl.uniform1i(gl.getUniformLocation(program, 'uImage'), SCREEN_UNIT);
            const overlayProgram = buildProgram(gl, COPY_VERTEX_SHADER, OVERLAY_COPY_FRAGMENT_SHADER);
            gl.useProgram(overlayProgram);
            gl.uniform1i(gl.getUniformLocation(overlayProgram, 'uImage'), OVERLAY_UNIT);
            // Low resolution is no loss: it is only ever one colour.
            const cover = this.mode === 'ar'
                ? binding.createProjectionLayer?.({ textureType: 'texture', scaleFactor: 0.25 })
                : undefined;
            layer.blendTextureSourceAlpha = this.backdropShown === 'hologram';
            this.quad = {
                binding,
                layer,
                program,
                viewport: gl.getUniformLocation(program, 'uViewport'),
                eye: gl.getUniformLocation(program, 'uEye'),
                hologram: gl.getUniformLocation(program, 'uHologram'),
                overlayProgram,
                overlayViewport: gl.getUniformLocation(overlayProgram, 'uViewport'),
                cover,
            };
            // The screen, and from the first frame the backdrop under it.
            this.updateLayers();
            this.stats.path = 'quad';
            return true;
        } catch (error) {
            this.stats.error ??= `quad layer: ${error instanceof Error ? error.message : String(error)}`;
            return false;
        }
    }

    /** Draw the screen into the eye buffers instead. */
    protected createProjectionLayer(): void {
        const Layer = xrGlobals.XRWebGLLayer;
        if (!Layer) {
            throw new Error('This browser cannot draw into a headset.');
        }
        if (this.session.enabledFeatures?.includes('layers')) {
            // Only reached when the quad layer itself failed, whose reason
            // is the one worth reporting.
            throw new Error(this.stats.error ?? 'The quad layer could not be created.');
        }
        const gl = this.gl;
        const layer = new Layer(this.session, gl);
        this.session.updateRenderState({ baseLayer: layer });

        const program = buildProgram(gl, SCREEN_VERTEX_SHADER, SCREEN_FRAGMENT_SHADER);
        gl.useProgram(program);
        gl.uniform1i(gl.getUniformLocation(program, 'uImage'), SCREEN_UNIT);
        gl.uniform3f(gl.getUniformLocation(program, 'uCenter'), 0, 0, -XR_SCREEN_DISTANCE);
        const overlayProgram = buildProgram(gl, SCREEN_VERTEX_SHADER, OVERLAY_FRAGMENT_SHADER);
        gl.useProgram(overlayProgram);
        gl.uniform1i(gl.getUniformLocation(overlayProgram, 'uImage'), OVERLAY_UNIT);
        this.projection = {
            layer,
            program,
            size: gl.getUniformLocation(program, 'uSize'),
            viewProjection: gl.getUniformLocation(program, 'uViewProjection'),
            eye: gl.getUniformLocation(program, 'uEye'),
            hologram: gl.getUniformLocation(program, 'uHologram'),
            overlayProgram,
            overlayViewProjection: gl.getUniformLocation(overlayProgram, 'uViewProjection'),
            overlayCenter: gl.getUniformLocation(overlayProgram, 'uCenter'),
            overlaySize: gl.getUniformLocation(overlayProgram, 'uSize'),
        };
        this.stats.path = 'projection';
    }

    /** What kind of session this is. */
    get mode(): XrMode {
        return this.host.mode ?? 'vr';
    }

    /** What is around the screen. */
    get backdrop(): XrBackdrop {
        return this.backdropShown;
    }

    /**
     * Show the player's room around the screen — and through it, for a
     * hologram — or cover it in black: at once, in the session as it is.
     * Only an `ar` session has a room to show.
     */
    setBackdrop(backdrop: XrBackdrop): void {
        if (this.mode !== 'ar' || backdrop === this.backdropShown) {
            return;
        }
        this.backdropShown = backdrop;
        if (this.quad) {
            this.quad.layer.blendTextureSourceAlpha = backdrop === 'hologram';
        }
        this.updateLayers();
    }

    /** Whether the session is under way: started, and not ended since. */
    get running(): boolean {
        return this.started && !this.ended;
    }

    /** How the session has gone so far. */
    get diagnostics(): XrDiagnostics {
        return { ...this.stats };
    }

    /** Follow a change to the display settings. */
    setDisplayMode(mode: DisplayMode): void {
        if (!this.ended) {
            this.renderer.setDisplayMode(xrDisplayMode(mode));
            this.dirty = true;
        }
    }

    /** Leave the headset. The host hears of it through `onXrEnded`. */
    async end(): Promise<void> {
        if (!this.ended) {
            await this.session.end().catch(() => this.onEnd());
        }
    }

    protected readonly onFrame = (time: number, frame: XrFrame): void => {
        if (this.ended) {
            return;
        }
        this.frameHandle = this.session.requestAnimationFrame(this.onFrame);
        this.stats.xrFrames++;
        // Each caught on its own, so that one going wrong is reported rather
        // than leaving a session that draws nothing and says nothing — and so
        // that the controllers failing can never cost the picture.
        // The first frames, then now and then: asking stalls the pipeline.
        const checking = this.stats.glError === undefined
            && (this.stats.xrFrames <= 5 || this.stats.xrFrames % 300 === 0);
        if (checking) {
            // Whatever happened since the last frame: a game frame arriving,
            // the session being set up.
            this.checkGl('between frames');
        }
        try {
            // Before the buttons are read, so that a trigger takes what is
            // under the pointer on the frame it is pulled.
            this.point(frame);
            this.pollInput(time);
        } catch (error) {
            this.stats.inputError ??= error instanceof Error ? error.message : String(error);
        }
        try {
            if (this.dirty) {
                this.dirty = false;
                this.renderer.renderTo(this.imageFramebuffer);
                if (checking) {
                    this.checkGl('composing');
                }
            }
            this.refreshHud(time);
            if (this.toastOverlay.visible && performance.now() >= this.toastUntil) {
                this.toastOverlay.visible = false;
                this.updateLayers();
            }
            if (this.quad) {
                this.drawQuad(frame);
            } else {
                this.drawProjection(frame);
            }
            if (checking) {
                this.checkGl(this.quad ? 'quad layer' : 'eye buffers');
            }
        } catch (error) {
            this.stats.error ??= error instanceof Error ? error.message : String(error);
        }
    };

    /** Note the first WebGL error, and where it surfaced. */
    protected checkGl(where: string): void {
        const code = this.gl.getError();
        if (code !== this.gl.NO_ERROR && this.stats.glError === undefined) {
            this.stats.glError = code;
            this.stats.glErrorAt = where;
        }
    }

    protected pollInput(time: number): void {
        const input = this.host.input;
        const elapsed = this.lastFrameTime === undefined ? 0 : Math.min(time - this.lastFrameTime, 100) / 1000;
        this.lastFrameTime = time;
        // The system menu is up, or the headset is off: nothing held.
        if (this.session.visibilityState !== 'visible') {
            input.setXrKeys(0);
            input.pollFrame();
            return;
        }
        const reading = readControllers(this.session.inputSources);
        const buttons = reading.buttons;
        const before = this.previousButtons;
        this.previousButtons = buttons;
        const pressed = (name: keyof XrButtons) => buttons[name] && !before[name];
        let keys = reading.keys;
        if (this.panel) {
            keys = 0;
            this.drivePanel(reading, pressed, time);
        } else if (reading.adjusting) {
            this.adjustView(reading, elapsed, time);
        } else {
            if (this.adjusting) {
                this.adjusting = false;
                this.depthInProgress = undefined;
                this.host.onXrViewChanged?.({ ...this.view });
            }
            // A stick clicked on its own opens the menu, as does the menu
            // button; with a grip held, a click puts the screen back instead
            // — see `adjustView`.
            if ((pressed('leftClick') || pressed('rightClick') || pressed('menu')) && this.openQuickMenu()) {
                keys = 0;
            }
        }
        if (this.panel) {
            this.heldBack = true;
        } else if (this.heldBack) {
            // Until everything that was down when the menu went is up again.
            if (keys === 0 && !Object.values(buttons).some(Boolean)) {
                this.heldBack = false;
            }
            keys = 0;
        }
        input.setXrKeys(keys);
        // Pads paired with the headset itself are still the Gamepad API's.
        input.pollFrame();
    }

    /**
     * Follow the pointing hand's ray onto the panel, if one is up: the dot
     * goes where it meets it, and the cursor onto the item it is on.
     */
    protected point(frame: XrFrame): void {
        const shown = this.panel;
        const hit = shown ? this.pointerHit(frame) : undefined;
        if (!shown || !hit) {
            this.pointingAt = 'nothing';
            this.showPointer(false);
            return;
        }
        this.pointerOverlay.place(hit.point.x, hit.point.y, hit.point.z + XR_POINTER_LIFT);
        this.showPointer(true);
        const row = this.panelRows.find(candidate => hit.y >= candidate.top && hit.y < candidate.bottom);
        const item = row && shown.panel.items()[row.index];
        if (!row || !item || item.disabled) {
            this.pointingAt = 'panel';
            return;
        }
        this.pointingAt = 'item';
        if (row.index !== shown.cursor) {
            shown.cursor = row.index;
            this.drawPanel();
        }
    }

    /** Where the pointing hand's ray meets the panel — or, where it misses, the other hand's. */
    protected pointerHit(frame: XrFrame): ReturnType<XrOverlay['hit']> {
        const sources = this.session.inputSources;
        const hands = [this.pointingHand, this.pointingHand === 'left' ? 'right' : 'left'];
        for (const hand of hands) {
            for (let i = 0; i < sources.length; i++) {
                const source = sources[i];
                if (source.handedness !== hand || !source.targetRaySpace) {
                    continue;
                }
                const pose = frame.getPose?.(source.targetRaySpace, this.space);
                if (!pose) {
                    continue;
                }
                const m = pose.transform.matrix;
                // From the ray's origin, along its -Z axis.
                const hit = this.panelOverlay.hit(
                    { x: m[12], y: m[13], z: m[14] },
                    { x: -m[8], y: -m[9], z: -m[10] });
                if (hit) {
                    return hit;
                }
            }
        }
        return undefined;
    }

    protected showPointer(visible: boolean): void {
        if (this.pointerOverlay.visible !== visible) {
            this.pointerOverlay.visible = visible;
            this.updateLayers();
        }
    }

    /** Open the host's menu, if it has one to offer. */
    protected openQuickMenu(): boolean {
        const menu = this.host.quickMenu?.();
        if (menu) {
            this.showPanel(menu);
        }
        return menu !== undefined;
    }

    /**
     * The sticks move the cursor, repeating while held; A or a trigger takes
     * the line under it, B or a stick click closes the panel.
     */
    protected drivePanel(
        reading: XrControllerReading,
        pressed: (name: keyof XrButtons) => boolean,
        time: number,
    ): void {
        const shown = this.panel!;
        const items = shown.panel.items();
        const step = reading.vertical < -XR_STICK_THRESHOLD ? -1 : reading.vertical > XR_STICK_THRESHOLD ? 1 : 0;
        if (step === 0) {
            this.repeat = undefined;
        } else if (!this.repeat || this.repeat.step !== step || time >= this.repeat.at) {
            const first = !this.repeat || this.repeat.step !== step;
            this.repeat = { step, at: time + (first ? XR_REPEAT_DELAY_MS : XR_REPEAT_MS) };
            const cursor = moveXrCursor(items, shown.cursor, step);
            if (cursor !== shown.cursor) {
                shown.cursor = cursor;
                this.drawPanel();
            }
        }
        // A trigger points with its own hand from now on.
        if (pressed('leftTrigger')) {
            this.pointingHand = 'left';
        } else if (pressed('rightTrigger')) {
            this.pointingHand = 'right';
        }
        // A trigger takes what it points at. Pointed at the panel between its
        // items it takes nothing, rather than what the cursor was left on;
        // pointed nowhere near it, it does what A does.
        const triggered = (pressed('leftTrigger') || pressed('rightTrigger')) && this.pointingAt !== 'panel';
        if (pressed('a') || triggered) {
            const item = items[shown.cursor];
            if (item && !item.disabled) {
                const outcome = item.run();
                // Unless it was a switch, or it put up a panel of its own.
                if (this.panel === shown) {
                    if (outcome === 'keep') {
                        this.drawPanel();
                    } else {
                        this.closePanel();
                    }
                }
            }
        } else if (pressed('b') || pressed('leftClick') || pressed('rightClick') || pressed('menu')) {
            this.closePanel();
        }
    }

    /**
     * Show a menu or a question in front of the screen, in place of any that
     * is up. The controllers drive it, and not the game, until it closes.
     */
    showPanel(panel: XrPanel): void {
        if (this.ended) {
            panel.onClose?.();
            return;
        }
        const previous = this.panel;
        this.panel = { panel, cursor: firstXrItem(panel.items()) };
        this.repeat = undefined;
        previous?.panel.onClose?.();
        this.drawPanel();
        this.panelOverlay.visible = true;
        // What goes around the screen comes with it, on the next frame.
        this.hudReadAt = -Infinity;
        this.updateLayers();
    }

    /**
     * Take a size and depth set from outside the headset — the settings pane,
     * with a tethered headset showing the page at the same time. Not passed
     * back through `onXrViewChanged`: whoever set it has it already.
     */
    setView(view: XrScreen): void {
        if (this.ended) {
            return;
        }
        this.view = clampXrScreen(view);
        this.depthInProgress = undefined;
        this.applyScreenSize();
    }

    /** Put the screen's size and depth back to how they start out. */
    resetScreen(): void {
        this.view = { ...XR_DEFAULT_SCREEN };
        this.depthInProgress = undefined;
        this.applyScreenSize();
        this.host.onXrViewChanged?.({ ...this.view });
    }

    /** Take the menu or question away, if one is up. */
    closePanel(): void {
        const shown = this.panel;
        if (!shown) {
            return;
        }
        this.panel = undefined;
        this.panelOverlay.visible = false;
        this.pointerOverlay.visible = false;
        this.pointingAt = 'nothing';
        this.hudReadAt = -Infinity;
        this.updateLayers();
        shown.panel.onClose?.();
    }

    /**
     * Ask something in the headset, with the two answers as a menu. Backing
     * out of it, or the session ending, is the second answer.
     */
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean> {
        return new Promise<boolean>(resolve => {
            let answer = false;
            this.showPanel({
                title,
                message,
                items: () => [
                    { label: yes, run: () => { answer = true; } },
                    { label: no, run: () => { answer = false; } },
                ],
                onClose: () => resolve(answer),
            });
        });
    }

    /** A line of news beneath the screen, for a few seconds. */
    toast(text: string, error = false): void {
        if (this.ended) {
            return;
        }
        drawXrToast(this.toastOverlay.canvas, text, error);
        this.toastOverlay.upload();
        this.toastUntil = performance.now() + XR_TOAST_MS;
        if (!this.toastOverlay.visible) {
            this.toastOverlay.visible = true;
            this.placeAround();
            this.updateLayers();
        }
    }

    /**
     * Put what goes around the screen where it goes, for the screen's size:
     * the badges over it, the status strip under it, and the news under that.
     * As wide as the screen, as the page's are as wide as its window.
     */
    protected placeAround(): void {
        const width = this.view.width;
        const half = screenHeight(width) / 2;
        const z = -XR_SCREEN_DISTANCE + 0.02;
        this.badgesOverlay.resize(width);
        this.statusOverlay.resize(width);
        this.badgesOverlay.place(0, half + XR_HUD_GAP + this.badgesOverlay.height / 2, z);
        this.statusOverlay.place(0, -(half + XR_HUD_GAP + this.statusOverlay.height / 2), z);
        const underStatus = this.statusOverlay.visible ? this.statusOverlay.height + XR_HUD_GAP : 0;
        this.toastOverlay.place(0, -(half + XR_TOAST_GAP + underStatus + this.toastOverlay.height / 2), z + 0.01);
    }

    /** Read what goes around the screen again, now and then, and draw what changed. */
    protected refreshHud(time: number): void {
        if (time - this.hudReadAt < XR_HUD_MS) {
            return;
        }
        this.hudReadAt = time;
        // Only while a menu is up: around the screen while playing, it pulls
        // the eye away from the game.
        const hud = this.panel ? this.host.hud?.() : undefined;
        const shown = hud ? JSON.stringify(hud) : undefined;
        if (shown === this.hudShown) {
            return;
        }
        this.hudShown = shown;
        const badges = !!hud && hud.states.length + hud.activities.length > 0;
        const status = !!hud && hud.status.length > 0;
        if (hud && badges) {
            drawXrBadges(this.badgesOverlay.canvas, hud);
            this.badgesOverlay.upload();
        }
        if (hud && status) {
            drawXrStatus(this.statusOverlay.canvas, hud);
            this.statusOverlay.upload();
        }
        if (badges !== this.badgesOverlay.visible || status !== this.statusOverlay.visible) {
            this.badgesOverlay.visible = badges;
            this.statusOverlay.visible = status;
            this.placeAround();
            this.updateLayers();
        }
    }

    /** Everything shown in front of or around the screen, in the order it stacks. */
    protected get overlays(): XrOverlay[] {
        return [this.badgesOverlay, this.statusOverlay, this.toastOverlay, this.panelOverlay, this.pointerOverlay];
    }

    protected drawPanel(): void {
        const shown = this.panel;
        if (shown) {
            this.panelRows = drawXrPanel(this.panelOverlay.canvas, shown.panel, shown.cursor);
            this.panelOverlay.upload();
        }
    }

    /** Give a session with quad layers the overlays that are showing, over the screen. */
    protected updateLayers(): void {
        const quad = this.quad;
        if (!quad || this.ended) {
            return;
        }
        const layers: (XrQuadLayer | XrProjectionLayer)[] = [quad.layer];
        if (quad.cover && this.mode === 'ar' && this.backdropShown === 'black') {
            layers.unshift(quad.cover);
        }
        for (const overlay of this.overlays) {
            if (overlay.visible) {
                layers.push(overlay.ensureLayer(quad.binding, this.space));
            }
        }
        this.session.updateRenderState({ layers });
    }

    /**
     * A grip held, and the sticks pushed: the left one makes the screen bigger
     * or smaller, the right one the picture deeper or flatter. Right or up is
     * more of either, left or down less; clicking a stick puts its own back
     * to how it started out.
     */
    protected adjustView(
        reading: XrControllerReading,
        elapsed: number,
        time: number,
    ): void {
        const lean = (value: number) => Math.abs(value) < XR_ADJUST_DEAD_ZONE ? 0 : value;
        const before = this.view;
        // On the press, not for as long as it is held.
        const resetWidth = reading.buttons.leftClick && !this.clicked.left;
        const resetDepth = reading.buttons.rightClick && !this.clicked.right;
        this.clicked = { left: reading.buttons.leftClick, right: reading.buttons.rightClick };
        // Kept unrounded while it moves, or a slow push would never get it
        // past the rounding.
        const depth = resetDepth
            ? XR_DEFAULT_SCREEN.depth
            : Math.min(200, Math.max(0,
                (this.depthInProgress ?? before.depth) + lean(reading.rightLean) * XR_DEPTH_RATE * elapsed));
        this.depthInProgress = depth;
        this.view = clampXrScreen({
            width: resetWidth
                ? XR_DEFAULT_SCREEN.width
                : before.width * Math.pow(XR_WIDTH_RATE, lean(reading.leftLean) * elapsed),
            depth,
        });
        if (this.view.width !== before.width) {
            this.applyScreenSize();
        }
        this.adjusting = true;
        if (this.view.depth !== before.depth
            && (resetDepth || time - this.viewReportedAt >= XR_ADJUST_REPORT_MS)) {
            this.viewReportedAt = time;
            this.host.onXrViewChanged?.({ ...this.view });
        }
    }

    /** Whether each stick was pressed in on the frame before, for telling a click from a hold. */
    protected clicked = { left: false, right: false };

    /** The unrounded depth while it is being adjusted. */
    protected depthInProgress: number | undefined;

    /** Size the screen as the view says. */
    protected applyScreenSize(): void {
        const width = this.view.width;
        this.placeAround();
        if (this.quad) {
            this.quad.layer.width = width * quadSizeFactor();
            this.quad.layer.height = screenHeight(width) * quadSizeFactor();
        } else if (this.projection) {
            this.gl.useProgram(this.projection.program);
            this.gl.uniform2f(this.projection.size, width, screenHeight(width));
        }
    }

    /**
     * Both grips held for a second leave the headset.
     *
     * Kept by the session's own events rather than read off the controllers
     * with the buttons, so that the way out works whatever else does not: a
     * headset showing nothing must still let somebody out without reaching
     * for the system menu.
     */
    protected readonly onSqueezeStart = (event: Event): void => {
        const hand = (event as Event & { inputSource?: XrInputSource }).inputSource?.handedness;
        if (hand !== 'left' && hand !== 'right') {
            return;
        }
        this.squeezing.add(hand);
        if (this.squeezing.size === 2 && this.exitTimer === undefined) {
            this.exitTimer = setTimeout(() => {
                this.exitTimer = undefined;
                this.end().catch(() => undefined);
            }, XR_EXIT_HOLD_MS);
        }
    };

    protected readonly onSqueezeEnd = (event: Event): void => {
        const hand = (event as Event & { inputSource?: XrInputSource }).inputSource?.handedness;
        if (hand) {
            this.squeezing.delete(hand);
        }
        if (this.exitTimer !== undefined) {
            clearTimeout(this.exitTimer);
            this.exitTimer = undefined;
        }
    };

    /** Draw each eye's half into the quad layer, enlarged. */
    protected drawQuad(frame: XrFrame): void {
        const gl = this.gl;
        const quad = this.quad!;
        if (quad.cover && this.mode === 'ar' && this.backdropShown === 'black') {
            this.drawCover(frame, quad.binding, quad.cover);
        }
        const regions = quadEyeRegions(
            quad.binding.getSubImage(quad.layer, frame, 'left'),
            quad.binding.getSubImage(quad.layer, frame, 'right'),
        );
        if (this.stats.xrFrames === 1) {
            this.stats.quadLayout = regions.description;
        }
        gl.useProgram(quad.program);
        gl.activeTexture(gl.TEXTURE0 + SCREEN_UNIT);
        gl.bindTexture(gl.TEXTURE_2D, this.image);
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.layerFramebuffer);
        for (const [index, region] of regions.eyes.entries()) {
            if (!region) {
                continue;
            }
            const { x, y, width, height } = region.viewport;
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, region.texture, 0);
            if (this.stats.xrFrames === 1) {
                const status = gl.checkFramebufferStatus(gl.FRAMEBUFFER);
                if (status !== gl.FRAMEBUFFER_COMPLETE) {
                    this.stats.error ??= `quad layer framebuffer incomplete: 0x${status.toString(16)}`;
                }
            }
            gl.viewport(x, y, width, height);
            gl.uniform4f(quad.viewport, x, y, width, height);
            gl.uniform1i(quad.eye, index);
            gl.uniform1i(quad.hologram, this.backdropShown === 'hologram' ? 1 : 0);
            gl.drawArrays(gl.TRIANGLES, 0, 3);
        }
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, null, 0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        gl.activeTexture(gl.TEXTURE0);

        const overlays = this.overlays.filter(overlay => overlay.visible && overlay.layer);
        if (overlays.length > 0) {
            gl.useProgram(quad.overlayProgram);
            for (const overlay of overlays) {
                overlay.drawLayer(quad.binding, frame, this.layerFramebuffer, quad.overlayViewport);
            }
        }
    }

    /** Black, all over each eye's view: the room of its own an `ar` session gives the screen. */
    protected drawCover(frame: XrFrame, binding: XrWebGlBinding, cover: XrProjectionLayer): void {
        const pose = frame.getViewerPose(this.space);
        if (!pose || !binding.getViewSubImage) {
            return;
        }
        const gl = this.gl;
        gl.bindFramebuffer(gl.FRAMEBUFFER, this.layerFramebuffer);
        gl.clearColor(0, 0, 0, 1);
        for (const view of pose.views) {
            const image = binding.getViewSubImage(cover, view);
            gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, image.colorTexture, 0);
            gl.clear(gl.COLOR_BUFFER_BIT);
        }
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, null, 0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    /** Draw the screen into each eye's view, in a dark room. */
    protected drawProjection(frame: XrFrame): void {
        const projection = this.projection!;
        const gl = this.gl;
        gl.bindFramebuffer(gl.FRAMEBUFFER, projection.layer.framebuffer);
        // With passthrough, the room shows wherever nothing is drawn; a quad
        // layer gets that for nothing, the eye buffers by being clear.
        gl.clearColor(0, 0, 0, this.backdropShown === 'black' ? 1 : 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
        // After the clear, so that a frame without a pose still shows the room.
        const pose = frame.getViewerPose(this.space);
        if (!pose) {
            this.stats.posesMissing++;
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);
            return;
        }
        gl.useProgram(projection.program);
        gl.activeTexture(gl.TEXTURE0 + SCREEN_UNIT);
        gl.bindTexture(gl.TEXTURE_2D, this.image);
        for (const view of pose.views) {
            const viewport = projection.layer.getViewport(view);
            if (!viewport) {
                continue;
            }
            gl.viewport(viewport.x, viewport.y, viewport.width, viewport.height);
            gl.uniformMatrix4fv(projection.viewProjection, false,
                multiply(view.projectionMatrix, view.transform.inverse.matrix));
            gl.uniform1f(projection.eye, view.eye === 'right' ? 1 : 0);
            gl.uniform1i(projection.hologram, this.backdropShown === 'hologram' ? 1 : 0);
            gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        }
        // Over the screen, in the order the quad layers would be: news, then
        // a menu over everything.
        const overlays = this.overlays.filter(overlay => overlay.visible);
        if (overlays.length > 0) {
            gl.useProgram(projection.overlayProgram);
            for (const view of pose.views) {
                const viewport = projection.layer.getViewport(view);
                if (!viewport) {
                    continue;
                }
                gl.viewport(viewport.x, viewport.y, viewport.width, viewport.height);
                gl.uniformMatrix4fv(projection.overlayViewProjection, false,
                    multiply(view.projectionMatrix, view.transform.inverse.matrix));
                for (const overlay of overlays) {
                    overlay.drawProjection(projection.overlayCenter, projection.overlaySize);
                }
            }
            gl.activeTexture(gl.TEXTURE0 + SCREEN_UNIT);
        }
        gl.activeTexture(gl.TEXTURE0);
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }

    /** Something done in the headset, which the audio may have been waiting for. */
    protected readonly onGesture = (): void => {
        if (this.session.visibilityState === 'visible') {
            this.host.resumeAudio?.();
        }
    };

    protected readonly onEnd = (): void => {
        if (this.ended) {
            return;
        }
        this.ended = true;
        this.session.removeEventListener('end', this.onEnd);
        this.session.removeEventListener('select', this.onGesture);
        this.session.removeEventListener('squeeze', this.onGesture);
        this.session.removeEventListener('visibilitychange', this.onGesture);
        this.session.removeEventListener('squeezestart', this.onSqueezeStart);
        this.session.removeEventListener('squeezeend', this.onSqueezeEnd);
        if (this.exitTimer !== undefined) {
            clearTimeout(this.exitTimer);
            this.exitTimer = undefined;
        }
        if (this.frameHandle !== undefined) {
            this.session.cancelAnimationFrame(this.frameHandle);
            this.frameHandle = undefined;
        }
        this.host.input.setExternalFrames(false);
        this.sim?.setVideoTap(undefined, this.tapOwner).catch(() => undefined);
        // A question still up is answered no; a menu, closed.
        const shown = this.panel;
        this.panel = undefined;
        shown?.panel.onClose?.();
        const gl = this.gl;
        for (const overlay of this.overlays) {
            overlay.dispose();
        }
        gl.deleteFramebuffer(this.imageFramebuffer);
        gl.deleteFramebuffer(this.layerFramebuffer);
        gl.deleteTexture(this.image);
        if (this.quad) {
            gl.deleteProgram(this.quad.program);
            gl.deleteProgram(this.quad.overlayProgram);
        }
        if (this.projection) {
            gl.deleteProgram(this.projection.program);
            gl.deleteProgram(this.projection.overlayProgram);
        }
        this.renderer.dispose();
        if (this.started) {
            this.host.onXrEnded(this.diagnostics);
        }
    };
}

/** The display settings as the headset shows them: both eyes, side by side. */
function xrDisplayMode(mode: DisplayMode): DisplayMode {
    return buildDisplayMode(
        VbRenderingMode.SIDE_BY_SIDE, mode.palette, mode.anaglyph, false, mode.frameBlending);
}
