/**
 * A game's rumble, played on the controller in somebody's hands.
 *
 * The Rumble Pack is one device on one link port, and most people playing have
 * neither. What they often do have is a game pad with two motors in it, and
 * the Gamepad API will drive them — so the effects a game broadcasts can be
 * felt without the hardware they were written for.
 *
 * A stand-in, and it says so. The pack drives a DRV2625 through a library of
 * 123 waveforms; a pad has one heavy motor, one light one, and a duration in
 * milliseconds. What bridges them is `RUMBLE_EFFECT_SHAPES`: how hard each
 * effect pulls, from its name, and how long it runs, measured off the real
 * hardware. So a click taps for the tenth of a second it actually lasts, an
 * alert buzzes for its three quarters, and a ramp is played as a ramp — in a
 * few steps, because `playEffect` holds one magnitude for its whole duration.
 *
 * What it cannot do is worth knowing. The shortest effects are around 70 ms,
 * which is not much more than a pad's motor takes to spin up, so those arrive
 * as a bump whatever is asked for; and the two motors are a crossfade rather
 * than a waveform. It is the difference between a game that rumbles and one
 * that does not, which is most of the point.
 *
 * Fed by the pack's own change event rather than by the byte path, so it works
 * the same whichever pack a host built — a real one over a serial port, or the
 * decoding-only one a page falls back to.
 */

import { Disposable } from '../common/emulator-events';
import {
    isRumblePlaying,
    rumbleEffectAmplitudeAt,
    RumbleEffectShape,
    rumbleEffectMs,
    rumbleEffectShape,
    RumbleState,
    VueportRumblePack,
} from '../common/emulator-rumble';

/**
 * How long a pad buzzes for a Play whose effect nobody named.
 *
 * Only for that: an effect the panel knows the number of is played for the
 * length its shape gives. This is the fallback for a game that sent a Play
 * before ever choosing an effect, where the honest answer is a short pulse
 * rather than the ceiling's worth of buzzing.
 */
export const GAMEPAD_PULSE_MS = 200;

/**
 * How many steps a ramp is played in.
 *
 * `playEffect` holds one pair of magnitudes for its whole duration, so a ramp
 * has to be several of them in a row. Four is enough to feel like a rise or a
 * fall rather than a block, and few enough that the shortest ramp measured —
 * 216 ms — still gives each step longer than a pad takes to respond.
 */
export const GAMEPAD_RAMP_STEPS = 4;

/**
 * What the Gamepad API calls a motor, as much of it as is used here.
 *
 * Declared rather than taken from the DOM library: `vibrationActuator` is not
 * in every version of it, and a build that has it would still not agree with
 * one that does not.
 */
interface VibrationActuator {
    playEffect(type: string, params: {
        duration: number,
        startDelay?: number,
        strongMagnitude?: number,
        weakMagnitude?: number,
    }): Promise<string>;
    reset?(): Promise<string>;
}

/** The pads this machine should buzz, as the caller decides which those are. */
export type RumblePads = () => Gamepad[];

export class GamepadRumble implements Disposable {

    /** The Play this has already acted on, by its number. */
    protected playing: number | undefined;
    protected subscription: Disposable | undefined;
    /** The steps of a ramp still to come. Dropped when anything ends it. */
    protected steps: ReturnType<typeof setTimeout>[] = [];

    constructor(
        protected readonly pack: VueportRumblePack,
        protected readonly pads: RumblePads,
        /** Whether the person wants this at all. Read on every effect. */
        protected readonly enabled: () => boolean,
    ) { }

    /** Start following the pack. Returns this, so it can be built and started. */
    start(): this {
        this.subscription ??= this.pack.onDidChangeConnected(() => this.follow());
        return this;
    }

    dispose(): void {
        this.subscription?.dispose();
        this.subscription = undefined;
        this.silence();
    }

    /**
     * Whether a pad should be buzzing for this machine right now.
     *
     * Off while a real pack is attached and being fed: the pack is the device
     * the game was written for, and somebody who has gone to the trouble of
     * plugging one in does not also want it in their hands. This is a
     * stand-in, and it stands down.
     */
    protected wanted(): boolean {
        return this.enabled() && !(this.pack.connected && this.pack.forwarding);
    }

    /** Called on every byte the pack sees; acts only on the ones that matter. */
    protected follow(): void {
        const state = this.pack.emulatedRumbleState;
        // By the Play's number rather than its timestamp: a game is free to
        // send two in the same millisecond, and both are effects.
        const play = state.plays;
        if (play !== undefined && play !== this.playing && isRumblePlaying(state)) {
            // Noted even when nothing is played for it, so that switching this
            // on mid-effect does not buzz for a Play that already happened.
            this.playing = play;
            if (this.wanted()) {
                this.pulse(state);
            }
            return;
        }
        // A Stop, which is a game cutting an effect short. An effect that ran
        // its own length needs nothing: the pulse was over before the ceiling.
        if (state.playing === false && this.playing !== undefined) {
            this.playing = undefined;
            this.silence();
        }
    }

    /**
     * Play one effect, in as many steps as its shape needs.
     *
     * For exactly as long as the panel counts it as playing, which is the
     * effect's own measured length: a pad still buzzing for something the rest
     * of the emulator has stopped showing would be saying two things at once.
     */
    protected pulse(state: RumbleState): void {
        this.clearSteps();
        const shape = rumbleEffectShape(state.effect);
        // The effect's measured length; the ceiling for the one that runs
        // until it is stopped; and a short pulse for a Play whose effect the
        // game never chose, where there is nothing to go on at all.
        const total = shape === undefined ? GAMEPAD_PULSE_MS : rumbleEffectMs(shape);
        const count = shape?.rampTo === undefined ? 1 : GAMEPAD_RAMP_STEPS;
        const each = Math.round(total / count);

        for (let step = 0; step < count; step++) {
            const play = () => this.play(each, this.strength(shape, state.frequency, step, count));
            if (step === 0) {
                play();
            } else {
                this.steps.push(setTimeout(play, each * step));
            }
        }
    }

    /** One step's worth of both motors. */
    protected strength(
        shape: RumbleEffectShape | undefined,
        frequency: number | undefined,
        step: number,
        count: number,
    ): { strong: number, weak: number } {
        const { strong, weak } = magnitudes(frequency);
        // Where along the effect this step sits: its middle, so that a rise
        // neither starts at nothing nor ends at full and is symmetrical with
        // the fall.
        const scale = rumbleEffectAmplitudeAt(shape, count === 1 ? 1 : (step + 0.5) / count);
        return { strong: round(strong * scale), weak: round(weak * scale) };
    }

    protected play(duration: number, { strong, weak }: { strong: number, weak: number }): void {
        for (const actuator of this.actuators()) {
            actuator
                .playEffect('dual-rumble', {
                    duration,
                    strongMagnitude: strong,
                    weakMagnitude: weak,
                })
                // A pad unplugged mid-effect, or one that turns out not to
                // take the effect after all. Neither is worth a word.
                .catch(() => undefined);
        }
    }

    protected silence(): void {
        this.clearSteps();
        for (const actuator of this.actuators()) {
            actuator.reset?.().catch(() => undefined);
        }
    }

    protected clearSteps(): void {
        for (const step of this.steps) {
            clearTimeout(step);
        }
        this.steps.length = 0;
    }

    /** The motors of the pads that drive this machine, where they have any. */
    protected actuators(): VibrationActuator[] {
        const found: VibrationActuator[] = [];
        for (const pad of this.pads()) {
            const actuator = (pad as unknown as { vibrationActuator?: VibrationActuator })
                .vibrationActuator;
            if (typeof actuator?.playEffect === 'function') {
                found.push(actuator);
            }
        }
        return found;
    }
}

/**
 * The pack's one frequency, split over a pad's two motors.
 *
 * The pack shakes at 50 to 400 Hz; a dual-rumble pad has a heavy motor that
 * gives a low rumble and a light one that gives a high buzz. So the frequency
 * a game asked for is a crossfade between them rather than an intensity: a low
 * frequency leans on the heavy motor, a high one on the light. Not what the
 * hardware does — it is one motor, driven harder or softer — but it is what a
 * pad has, and it keeps a 400 Hz buzz feeling different from a 50 Hz shudder.
 *
 * An unknown frequency sits in the middle, which is where a game that never
 * said belongs.
 */
export function magnitudes(frequency: number | undefined): { strong: number, weak: number } {
    const tilt = frequency === undefined
        ? 0.5
        : Math.min(1, Math.max(0, (frequency - 50) / 350));
    return { strong: round(1 - 0.6 * tilt), weak: round(0.4 + 0.6 * tilt) };
}

/** Three decimals is past anything a motor can tell apart, and it reads. */
function round(value: number): number {
    return Number(Math.min(1, Math.max(0, value)).toFixed(3));
}
