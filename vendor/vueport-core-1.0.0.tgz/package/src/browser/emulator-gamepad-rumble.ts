/**
 * A game's rumble played on a game pad's two motors via the Gamepad API, as a stand-in for the Rumble Pack.
 * The pack drives a DRV2625 through 123 waveforms; a pad has a heavy and a light motor and a duration in ms.
 * RUMBLE_EFFECT_SHAPES bridges them: strength from the effect's name, length measured off the real hardware, and
 * ramps played in steps, as playEffect holds one magnitude for its whole duration. The shortest effects (~70 ms)
 * barely exceed motor spin-up, so they arrive as a bump.
 * Fed by the pack's change event rather than the byte path, so it works with a real serial pack or the
 * decoding-only fallback alike.
 */

import { Disposable } from '../common/emulator-events';
import {
    isRumblePlaying,
    rumbleEffectAmplitudeAt,
    RumbleEffectShape,
    rumbleEffectMs,
    rumbleEffectShape,
    RumbleState,
    VueportRumblePack,
} from '../common/emulator-rumble';

// for a Play sent before the game ever chose an effect; known effects play for the length their shape gives
export const GAMEPAD_PULSE_MS = 200;

// playEffect holds one pair of magnitudes for its whole duration, so a ramp is several in a row. Four feel like a
// rise rather than a block, and the shortest ramp measured (216 ms) still gives each step longer than a pad's
// response
export const GAMEPAD_RAMP_STEPS = 4;

// declared rather than taken from the DOM library, as vibrationActuator is not in every version of it
interface VibrationActuator {
    playEffect(type: string, params: {
        duration: number,
        startDelay?: number,
        strongMagnitude?: number,
        weakMagnitude?: number,
    }): Promise<string>;
    reset?(): Promise<string>;
}

// the older Gamepad Extensions draft interface (one pulse of one strength), which Firefox has where
// vibrationActuator is missing, and only behind dom.gamepad.haptic_feedback.enabled
interface HapticActuator {
    pulse(value: number, duration: number): Promise<boolean>;
}

// whichever of the two a pad has, as one thing to play on
interface PadMotors {
    play(duration: number, strong: number, weak: number): void;
    reset(): void;
}

// undefined is common: Chrome gives a vibrationActuator only to controllers it knows how to drive (Xbox,
// DualShock, DualSense, Switch Pro, a few others), so a pad it reads raw gets none even with motors
function padMotors(pad: Gamepad): PadMotors | undefined {
    const actuator = (pad as unknown as { vibrationActuator?: VibrationActuator | null }).vibrationActuator;
    if (typeof actuator?.playEffect === 'function') {
        return {
            play: (duration, strong, weak) => {
                actuator
                    .playEffect('dual-rumble', { duration, strongMagnitude: strong, weakMagnitude: weak })
                    // a pad unplugged mid-effect, or one that does not take the effect after all
                    .catch(() => undefined);
            },
            reset: () => { actuator.reset?.().catch(() => undefined); },
        };
    }
    const haptic = (pad as unknown as { hapticActuators?: readonly HapticActuator[] }).hapticActuators?.[0];
    if (typeof haptic?.pulse === 'function') {
        return {
            // one motor: the stronger of the two
            play: (duration, strong, weak) => { haptic.pulse(Math.max(strong, weak), duration).catch(() => undefined); },
            reset: () => { haptic.pulse(0, 0).catch(() => undefined); },
        };
    }
    return undefined;
}

// the period a weaker effect is chopped into, in ms: on for a share of it, off for the rest. The Vibration API knows
// no strength, only on and off, and a motor pulsed this fast reads as a softer buzz rather than as taps
const DEVICE_PWM_MS = 20;
// shorter than this a motor never spins up, so a weak step is never chopped finer
const DEVICE_MIN_ON_MS = 5;

/**
 * The phone's or tablet's own motor, for a game played on its screen with no pad to hold: navigator.vibrate, which
 * Chrome on Android has and Safari on iOS does not. One motor and no strength, so the stronger of the two pad
 * magnitudes decides how much of each short period it runs (see DEVICE_PWM_MS); full strength is one long buzz.
 */
export function deviceMotor(): PadMotors | undefined {
    if (typeof navigator === 'undefined' || typeof navigator.vibrate !== 'function') {
        return undefined;
    }
    const vibrate = (pattern: number | number[]): void => {
        try {
            navigator.vibrate(pattern);
        } catch {
            // refused before the page was touched once; the next effect tries again
        }
    };
    return {
        play: (duration, strong, weak) => {
            const level = Math.max(strong, weak);
            if (level <= 0 || duration <= 0) {
                return;
            }
            if (level >= 0.9) {
                vibrate(duration);
                return;
            }
            const on = Math.max(DEVICE_MIN_ON_MS, Math.round(DEVICE_PWM_MS * level));
            const off = Math.max(0, DEVICE_PWM_MS - on);
            const pattern: number[] = [];
            for (let elapsed = 0; elapsed < duration; elapsed += on + off) {
                pattern.push(Math.min(on, duration - elapsed), off);
            }
            vibrate(pattern);
        },
        reset: () => vibrate(0),
    };
}

export function deviceCanRumble(): boolean {
    return deviceMotor() !== undefined;
}

export function gamepadCanRumble(pad: Gamepad): boolean {
    return padMotors(pad) !== undefined;
}

// the caller decides which pads those are
export type RumblePads = () => Gamepad[];

export class GamepadRumble implements Disposable {

    // the number of the Play this has already acted on
    protected playing: number | undefined;
    protected subscription: Disposable | undefined;
    // the timers of a ramp's remaining steps; dropped when anything ends it
    protected steps: ReturnType<typeof setTimeout>[] = [];

    constructor(
        protected readonly pack: VueportRumblePack,
        protected readonly pads: RumblePads,
        // 0–1, 0 is off. Read on every effect, so moving the slider is felt on the next one
        protected readonly intensity: () => number,
        // whether the device's own motor stands in while no pad with motors drives this machine; read per effect,
        // like the intensity. Left out, never
        protected readonly onDevice?: () => boolean,
    ) { }

    // returns this, so it can be built and started in one go
    start(): this {
        this.subscription ??= this.pack.onDidChangeConnected(() => this.follow());
        return this;
    }

    dispose(): void {
        this.subscription?.dispose();
        this.subscription = undefined;
        this.silence();
    }

    // off while a real pack is attached and fed: somebody who plugged one in does not also want it in their hands
    protected wanted(): boolean {
        return this.intensity() > 0 && !(this.pack.connected && this.pack.forwarding);
    }

    // called on every byte the pack sees; acts only on the ones that matter
    protected follow(): void {
        const state = this.pack.emulatedRumbleState;
        // by the Play's number rather than its timestamp, as a game may send two in the same millisecond
        const play = state.plays;
        if (play !== undefined && play !== this.playing && isRumblePlaying(state)) {
            // noted even when nothing is played, so switching this on mid-effect does not buzz for a past Play
            this.playing = play;
            if (this.wanted()) {
                this.pulse(state);
            }
            return;
        }
        // a Stop cuts an effect short. One that ran its own length needs nothing: the pulse was already over
        if (state.playing === false && this.playing !== undefined) {
            this.playing = undefined;
            this.silence();
        }
    }

    // for exactly as long as the panel counts it as playing (the effect's measured length), so the pad never buzzes
    // for something the rest of the emulator stopped showing
    protected pulse(state: RumbleState): void {
        this.clearSteps();
        const shape = rumbleEffectShape(state.effect);
        // the measured length, the ceiling for one that runs until stopped, a short pulse when no effect was chosen
        const total = shape === undefined ? GAMEPAD_PULSE_MS : rumbleEffectMs(shape);
        const count = shape?.rampTo === undefined ? 1 : GAMEPAD_RAMP_STEPS;
        const each = Math.round(total / count);

        for (let step = 0; step < count; step++) {
            const play = () => this.play(each, this.strength(shape, state.frequency, step, count));
            if (step === 0) {
                play();
            } else {
                this.steps.push(setTimeout(play, each * step));
            }
        }
    }

    // one step's worth of both motors
    protected strength(
        shape: RumbleEffectShape | undefined,
        frequency: number | undefined,
        step: number,
        count: number,
    ): { strong: number, weak: number } {
        const { strong, weak } = magnitudes(frequency);
        // sampled at the step's middle, so a rise neither starts at nothing nor ends at full and mirrors the fall;
        // times the person's intensity setting
        const scale = rumbleEffectAmplitudeAt(shape, count === 1 ? 1 : (step + 0.5) / count)
            * Math.min(1, Math.max(0, this.intensity()));
        return { strong: round(strong * scale), weak: round(weak * scale) };
    }

    protected play(duration: number, { strong, weak }: { strong: number, weak: number }): void {
        for (const motors of this.motors()) {
            motors.play(duration, strong, weak);
        }
    }

    protected silence(): void {
        this.clearSteps();
        for (const motors of this.motors()) {
            motors.reset();
        }
    }

    protected clearSteps(): void {
        for (const step of this.steps) {
            clearTimeout(step);
        }
        this.steps.length = 0;
    }

    // the motors of the pads that drive this machine, where they have any; the device's own when none has and the
    // host allows it, as somebody holding a pad does not also want the phone on the table buzzing
    protected motors(): PadMotors[] {
        const pads = this.pads().map(padMotors).filter((motors): motors is PadMotors => motors !== undefined);
        if (pads.length === 0 && this.onDevice?.()) {
            const device = deviceMotor();
            return device ? [device] : [];
        }
        return pads;
    }
}

/**
 * The pack's one frequency (50 to 400 Hz) as a crossfade over a pad's heavy and light motor: low leans on the heavy
 * one, high on the light. Not what the hardware does (one motor, driven harder or softer), but it keeps a 400 Hz
 * buzz feeling different from a 50 Hz shudder. An unknown frequency sits in the middle.
 */
export function magnitudes(frequency: number | undefined): { strong: number, weak: number } {
    const tilt = frequency === undefined
        ? 0.5
        : Math.min(1, Math.max(0, (frequency - 50) / 350));
    return { strong: round(1 - 0.6 * tilt), weak: round(0.4 + 0.6 * tilt) };
}

// three decimals is past anything a motor can tell apart, and it reads
function round(value: number): number {
    return Number(Math.min(1, Math.max(0, value)).toFixed(3));
}
