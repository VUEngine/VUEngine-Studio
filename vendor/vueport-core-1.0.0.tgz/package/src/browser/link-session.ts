import { Disposable, DisposableCollection, Emitter, Event } from '../common/emulator-events';
import {
    LINK_PROTOCOL_VERSION,
    LinkChannel,
    LinkMessage,
    LinkSeat,
} from '../common/link-channel';
import { ScheduledEdit } from '../common/vb-protocol';
import { SAVE_RAM_WINDOW } from '../common/emulator-save-state';
import { Sim } from './core/vb-core';
import { EmulatorSession } from './emulator-core-service';

/** How a link session is getting on, for the chrome to show. */
export enum LinkState {
    /** Announcing ourselves, with nobody answering yet. */
    Waiting = 'waiting',
    /** Both windows are present and playing. */
    Connected = 'connected',
    /** Connected, but stopped because the other window's input has not arrived. */
    Stalled = 'stalled',
    /**
     * The session is over and will not resume: the other window closed, or the
     * two could never have played together.
     *
     * Not where an ordinary unlink leads. A player who unlinks is still there,
     * so this window goes back to {@link Waiting} with its end of the cable
     * plugged in, and the next hello picks the session straight back up.
     */
    Closed = 'closed',
}

/**
 * Why a session ended or refused to start, in words a person can act on.
 *
 * `left` is the one that is not a failure: the other player unlinked, and both
 * windows are still sitting there with the game open. It is the reason this
 * window goes back to {@link LinkState.Waiting} rather than to
 * {@link LinkState.Closed} — see {@link LinkSession.peerGone}. `closed` is the
 * same message from a window that is going away, which there is no waiting for.
 */
export interface LinkRefusal {
    reason: 'protocol' | 'rom' | 'core' | 'seat' | 'left' | 'closed' | 'desync' | 'edit';
    message: string;
}

export interface LinkSessionOptions {
    session: EmulatorSession;
    channel: LinkChannel;
    seat: LinkSeat;
    /** The cartridge both windows must be running, as its CRC32 string. */
    rom: string;
    /**
     * The cartridge itself, for the mirror.
     *
     * Read when the mirror is built rather than held here, because the bytes
     * are up to sixteen megabytes and the session has no other use for them.
     */
    romData(): ArrayBuffer | undefined;
    /** The core's state struct size, as a build check. */
    core: number;
    /**
     * Frames between pressing a button and the machines acting on it.
     *
     * Only the window that answers a hello decides this; the joining window
     * takes whatever it is told, so both sides always agree.
     */
    delay?: number;
    /**
     * The changes this window's own machine is already under, for the other
     * window's mirror of it to match.
     *
     * A session starts both machines from power-on, but not from *nothing*: a
     * player who switched a cheat on before inviting anybody has a machine
     * that is not the one a fresh mirror would be, and the two would come
     * apart on the first frame the cheat touched. So whatever standing edits
     * this window is running under travel once, at the start of every run.
     *
     * In practice this is the enabled cheats. Called rather than held because
     * they can change between a session being built and it beginning.
     */
    standingEdits?(): ScheduledEdit[];
}

/**
 * Two windows playing one linked game.
 *
 * Each window runs *both* machines in its own worker — its own and a mirror of
 * the other player's — and the only thing that crosses between them is a
 * controller mask per frame per seat. The machines stay identical because the
 * core is deterministic given the same cartridge and the same inputs on the
 * same frames; `packages/core/tests/determinism-probe.mjs` is where that was
 * established, and `setLockstep` in `vb-protocol.ts` is what stops a machine
 * running past input that has not arrived.
 *
 * The consequence worth understanding: a window can only be as far ahead as
 * the input it has been given, so a window whose partner has stopped will stop
 * too, a few frames later. That is not a fault — it is the same thing two
 * Virtual Boys on one cable do when you unplug one.
 */
/**
 * The authority's save, as a whole save window for one machine to be given.
 *
 * What travels between two windows is only the part of the window the game has
 * written; what a machine is given has to be the whole of it, or its save
 * would answer on a narrower window than the other player's and the two would
 * disagree the first time either one read past it.
 *
 * Zero-filled rather than `freshSaveRam`, and that is the point: the two
 * machines have to hold identical bytes or they part company on the first
 * read, and noise is by definition not identical. Nothing is lost by it — what
 * arrives always covers at least the baseline, which is the only part that
 * comes up holding anything.
 */
function expandCartRam(cartRam: ArrayBuffer, window = SAVE_RAM_WINDOW): ArrayBuffer {
    const ram = new Uint8Array(window);
    ram.set(new Uint8Array(cartRam, 0, Math.min(cartRam.byteLength, ram.length)));
    return ram.buffer;
}

export class LinkSession implements Disposable {

    /**
     * How far ahead of the machines input is booked, when nobody says
     * otherwise.
     *
     * Three frames is 60 ms, which is far more than a BroadcastChannel needs
     * and enough that neither window has to stall over an ordinary hiccup.
     * Netplay over a wire will want to negotiate this rather than assume it.
     */
    static readonly DEFAULT_DELAY_FRAMES = 3;
    /** How often a window with nobody to talk to says hello again. */
    static readonly HELLO_INTERVAL_MS = 500;
    /**
     * How long a window will stand still waiting for the other one.
     *
     * A window that is closed says goodbye on its way out, but one that
     * crashed, was killed, or lost its connection says nothing at all — and
     * without this its partner would sit at a frozen picture for ever, under
     * lockstep, waiting for input that is never coming. Long enough to sit
     * through a slow tab being woken up, short enough that a person does not
     * conclude the emulator has hung.
     */
    static readonly PEER_TIMEOUT_MS = 10000;
    /** How much early remote input is held while this window sets up. */
    static readonly MAX_PENDING_REMOTE = 600;
    /**
     * How often the two windows check that they still agree.
     *
     * Every second or so. Two machines running the same cartridge from the
     * same inputs *should* stay identical for ever — that is what
     * `tests/determinism-probe.mjs` measures — but "should" is not something
     * to leave unchecked in a session someone is playing: a desync that goes
     * unnoticed is two people playing different games and blaming each other.
     */
    static readonly DIGEST_PERIOD_FRAMES = 60;
    /**
     * How many of our mirror's digests are kept while their counterpart is in
     * flight. A couple of seconds' worth; anything older is of no use.
     */
    static readonly MAX_KEPT_DIGESTS = 8;
    /** How many booked writes are held while this window sets up. */
    static readonly MAX_PENDING_EDITS = 64;

    protected readonly toDispose = new DisposableCollection();
    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires whenever {@link state} changes, for the chrome to redraw. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    protected readonly channel: LinkChannel;
    protected readonly emulatorSession: EmulatorSession;
    readonly seat: LinkSeat;
    protected readonly rom: string;
    protected readonly romData: () => ArrayBuffer | undefined;
    protected readonly coreBuild: number;

    protected mirror: Sim | undefined;
    protected delay: number;

    state = LinkState.Waiting;
    refusal: LinkRefusal | undefined;

    /**
     * The mask the player is holding right now.
     *
     * Booked against frames as they come up rather than when it changes: under
     * lockstep every frame needs an entry, so a session is a producer that
     * keeps the schedule filled, not a reporter of changes.
     */
    protected heldKeys = 0;
    /** The next frame this window has not yet booked its own input for. */
    protected nextFrame = 0;
    /** The last frame the machines reported reaching. */
    protected machineFrame = 0;
    protected helloTimer: ReturnType<typeof setInterval> | undefined;
    protected stallTimer: ReturnType<typeof setTimeout> | undefined;
    protected disposed = false;
    /**
     * Set the moment this window commits to starting, before any of the
     * setting up has happened.
     *
     * The joining window says hello until it hears back, so a second hello can
     * easily arrive while the answer to the first is still being acted on.
     * Without this flag that second hello starts the whole session over —
     * resetting machines that had just been reset, and leaving the two windows
     * booking input against different frames.
     */
    protected beginning = false;
    /**
     * Remote input that arrived before there was a machine to put it in.
     *
     * The other window starts booking the moment it begins, which may be
     * before this one has its mirror up. Dropping those frames looks harmless
     * and is fatal: under lockstep nothing re-sends them, so the mirror waits
     * for frame zero for ever and both windows stop.
     */
    protected readonly pendingRemote: { epoch: number, frame: number, keys: number }[] = [];
    /**
     * Booked writes that arrived before there was a machine to put them in.
     *
     * Held for the same reason the input above is, and it matters more here:
     * the standing cheats travel once, at frame 0 of every run, and a window
     * that dropped them because its mirror was a moment late would play the
     * whole session against a machine the other window is not running.
     */
    protected readonly pendingEdits:
        { epoch: number, seat: LinkSeat, frame: number, edits: ScheduledEdit[] }[] = [];
    /** See {@link LinkSessionOptions.standingEdits}. */
    protected readonly standingEdits: () => ScheduledEdit[];
    /**
     * What our copy of the other player's machine looked like, by frame.
     *
     * Held until their own digest for that frame arrives, which is what it is
     * compared against.
     */
    protected readonly mirrorDigests = new Map<number, number>();
    /**
     * Which run of the session this is. See `epoch` in `link-channel.ts`.
     *
     * Zero for the first, one more for every save state loaded into it.
     */
    protected epoch = 0;

    constructor(options: LinkSessionOptions) {
        this.emulatorSession = options.session;
        this.channel = options.channel;
        this.seat = options.seat;
        this.rom = options.rom;
        this.romData = options.romData;
        this.coreBuild = options.core;
        this.delay = options.delay ?? LinkSession.DEFAULT_DELAY_FRAMES;
        this.standingEdits = options.standingEdits ?? (() => []);

        this.toDispose.push(this.channel.onMessage(
            message => this.receive(message).catch(error => this.receiveFailed(error))));
        this.toDispose.push(this.emulatorSession.core.onDigest(taken => {
            this.onLocalDigest(taken.sim, taken.frame, taken.digest);
        }));
        this.toDispose.push(this.emulatorSession.core.onProgress(({ frame }) => {
            this.machineFrame = frame;
            this.fillSchedule();
        }));
        this.toDispose.push(this.emulatorSession.core.onAwaitingInput(({ waiting }) => {
            this.setState(waiting ? LinkState.Stalled : LinkState.Connected);
        }));
    }

    /** The other player's machine, once there is one. For the debugger to offer. */
    get mirrorSim(): Sim | undefined {
        return this.mirror;
    }

    get connected(): boolean {
        return this.state === LinkState.Connected || this.state === LinkState.Stalled;
    }

    /**
     * Start waiting for the other window.
     *
     * Only player 2's window says hello, and player 1's only answers. Letting
     * both do both would leave which of them is the authority to a race, and
     * the authority is what decides where the session starts from — see
     * `begin` in `link-channel.ts`.
     *
     * The hello is repeated rather than sent once: the two windows come up in
     * whatever order the browser feels like, and a hello that arrived before
     * anyone was listening is indistinguishable from one that was never sent.
     */
    start(): void {
        if (this.seat !== 2) {
            return;
        }
        this.sayHello();
        this.helloTimer = setInterval(
            () => {
                if (this.state === LinkState.Waiting) {
                    this.sayHello();
                }
            },
            LinkSession.HELLO_INTERVAL_MS,
        );
    }

    /** True for the window that decides where the session starts from. */
    protected get authority(): boolean {
        return this.seat === 1;
    }

    /**
     * Take the mask the player is holding.
     *
     * Not applied here: it is booked against the frames still to come, so that
     * the same press lands on the same frame in both windows however long the
     * message took to cross.
     */
    setKeys(keys: number): void {
        this.heldKeys = keys;
        this.fillSchedule();
    }

    protected sayHello(): void {
        this.channel.send({
            kind: 'hello',
            seat: this.seat,
            protocol: LINK_PROTOCOL_VERSION,
            rom: this.rom,
            core: this.coreBuild,
        });
    }

    /**
     * A message that could not be acted on.
     *
     * Acting on one means telling machines things — `begin` alone makes a
     * dozen awaited calls — and a machine can go away while that is happening:
     * the other window closes, this window's session ends, the ROM is closed.
     * The call then rejects, and because messages arrive in a listener there
     * is nobody holding the promise, so the rejection went to the page as an
     * uncaught error. It is not one: a session whose machines have gone is
     * over, which is the only thing to say about it.
     *
     * Ended rather than ignored where the session still believes it is
     * running, because something that cannot be told to the machines has been
     * missed, and carrying on from there is exactly the silent disagreement
     * the digests exist to catch.
     */
    protected receiveFailed(error: unknown): void {
        if (this.disposed || this.state === LinkState.Closed) {
            return;
        }
        console.warn('[vueport] the link session could not act on a message:', error);
        this.close({
            reason: 'closed',
            message: 'The link session ended: one of the machines is no longer there.',
        });
    }

    protected async receive(message: LinkMessage): Promise<void> {
        if (this.disposed) {
            return;
        }
        switch (message.kind) {
            case 'hello':
                await this.onHello(message.seat, message);
                break;
            case 'welcome':
                await this.onWelcome(message);
                break;
            case 'begin':
                await this.begin(message.cartRam, message.cartRamWindow);
                break;
            case 'resume':
                await this.applyResume(message.epoch, message.p1, message.p2);
                break;
            case 'input':
                this.onRemoteInput(message.epoch, message.frame, message.keys);
                break;
            case 'edit':
                this.onRemoteEdits(message.epoch, message.seat, message.frame, message.edits);
                break;
            case 'digest':
                // Frame numbers start again at zero after a save state is
                // loaded, so a digest still in flight from the previous run
                // names a frame that now means a different moment — and
                // comparing the two would report a desync that never happened.
                if (message.epoch === this.epoch) {
                    this.onRemoteDigest(message.frame, message.digest);
                }
                break;
            case 'bye':
                // A window that is going away is gone; one that merely
                // unlinked can be linked to again in a moment. Older builds
                // cannot reach here — the protocol version that added this is
                // checked before a session begins — so an absent `leaving` is
                // a message this build did not send.
                this.peerGone(message.leaving === 'window'
                    ? { reason: 'closed', message: 'The other player closed their window.' }
                    : { reason: 'left', message: 'The other player unlinked.' });
                break;
        }
    }

    protected async onHello(
        seat: LinkSeat,
        message: { protocol: number, rom: string, core: number },
    ): Promise<void> {
        const refusal = this.checkCompatible(seat, message);
        if (refusal) {
            this.close(refusal);
            return;
        }
        if (this.beginning) {
            // Already answered. See `beginning`.
            return;
        }
        this.beginning = true;
        // Answering is what fixes the delay for both sides, so it is sent
        // before the mirror exists — the joining window needs the number more
        // urgently than it needs us to be ready.
        this.channel.send({
            kind: 'welcome',
            seat: this.seat,
            protocol: LINK_PROTOCOL_VERSION,
            rom: this.rom,
            core: this.coreBuild,
            delay: this.delay,
        });
        // The authority decides where both windows start, and starts there
        // itself at the same time.
        // Only as far up the save window as the game has written. The window
        // itself is the whole 16 MiB of Game Pak RAM, and sending that down a
        // data channel to start a two-player game would be absurd — the two
        // machines agree on the rest without being told, because everything
        // above the baseline is zero on both sides. See `expandCartRam`.
        const info = await this.emulatorSession.sim.cartRamInfo();
        const cartRam = await this.emulatorSession.sim.getCartRam(info.used);
        this.channel.send({
            kind: 'begin', seat: this.seat, epoch: 0,
            cartRam: cartRam.slice(0), cartRamWindow: info.size,
        });
        await this.begin(cartRam, info.size);
    }

    protected async onWelcome(
        message: { seat: LinkSeat, protocol: number, rom: string, core: number, delay: number },
    ): Promise<void> {
        const refusal = this.checkCompatible(message.seat, message);
        if (refusal) {
            this.close(refusal);
            return;
        }
        this.delay = message.delay;
        // Nothing more to do here: the `begin` that follows is what starts us.
    }

    /** Everything that has to match before two windows can play together. */
    protected checkCompatible(
        seat: LinkSeat,
        message: { protocol: number, rom: string, core: number },
    ): LinkRefusal | undefined {
        if (seat === this.seat) {
            return {
                reason: 'seat',
                message: 'Both windows opened as the same player.',
            };
        }
        if (message.protocol !== LINK_PROTOCOL_VERSION) {
            return {
                reason: 'protocol',
                message: 'The other window is running a different version of VUEPort.',
            };
        }
        if (message.core !== this.coreBuild) {
            return {
                reason: 'core',
                message: 'The other window is running a different emulator core.',
            };
        }
        if (message.rom !== this.rom) {
            return {
                reason: 'rom',
                message: 'The other window has a different game open.',
            };
        }
        return undefined;
    }

    /**
     * Put all of this window's machines back to power-on and start the session
     * at frame zero.
     *
     * Both windows do this from the same save RAM at what is, for them, the
     * same moment — which is the only way two independently running emulators
     * can be said to be in step at all. It restarts the game, and that is not
     * a side effect to apologize for: it is what putting a cable between two
     * Virtual Boys amounts to.
     *
     * From here neither machine runs a frame it has not been given input for,
     * which is what keeps the two windows identical from then on.
     */
    protected async begin(cartRam: ArrayBuffer, cartRamWindow?: number): Promise<void> {
        if (this.connected || this.disposed || (this.beginning && !this.authority)) {
            return;
        }
        this.beginning = true;
        // Whatever ended the last run is no longer what is happening. The run
        // itself was put away when it ended — see `peerGone`, which is the
        // only way a session gets here twice.
        this.refusal = undefined;
        const cartridge = this.romData();
        if (!cartridge) {
            this.close({ reason: 'rom', message: 'The game is no longer open in this window.' });
            return;
        }
        const own = this.emulatorSession.sim;
        // Behind the machines of the run before this one, which may still be
        // on their way back — and the run before this one is a *different*
        // session object, so the queue for that cannot live here. See
        // `withMirror` in `emulator-core-service.ts`.
        const mirror = await this.emulatorSession.withMirror(async () => {
            // With the seat, so that both windows hand the pair to the core in
            // the same order: what a linked pair emulates depends on it, and
            // this window's own machine is the other window's mirror. See
            // `setPeer` in `vb-protocol.ts`.
            const built = await this.emulatorSession.attachMirror(cartridge, this.seat);
            if (this.disposed) {
                // The session went away while the mirror was being built. It
                // is handed back by whoever disposed of the session — which
                // queues behind this — and the caller below stops here.
                return built;
            }
            this.mirror = built;

            // Lockstep goes on *first*, and this is not a detail: with
            // nothing booked, the drive loop stops on the spot and cannot run
            // another frame. Setting up in any other order lets the machine
            // advance a few frames between being reset and being held — after
            // which both windows book from frame zero into machines that are
            // already past it, every booking is refused as too late, and the
            // two sit staring at each other for ever. Which is exactly what
            // happened.
            await own.setLockstep(true);
            await built.setLockstep(true);
            await own.setDigestPeriod(LinkSession.DIGEST_PERIOD_FRAMES);
            await built.setDigestPeriod(LinkSession.DIGEST_PERIOD_FRAMES);

            // Both machines start from the authority's save, or they would
            // part company the first time either one read it.
            await own.setCartRam(expandCartRam(cartRam, cartRamWindow));
            await built.setCartRam(expandCartRam(cartRam, cartRamWindow));
            // The mirror is the other player's machine: it is heard in their
            // window, not in this one.
            await built.setVolume(0);

            // Resetting is also what puts the frame count back to zero, which
            // is the number both windows book their input against.
            await own.reset();
            await built.reset();
            return built;
        });
        if (this.disposed) {
            return;
        }
        this.nextFrame = 0;
        this.machineFrame = 0;

        this.setState(LinkState.Connected);
        // Before either of the two below, because both of those book against
        // frames — and what a machine is running under has to be settled
        // before the first frame it runs.
        this.sendStandingEdits();
        this.drainPendingRemote(mirror);
        this.fillSchedule();
    }

    /**
     * Book this window's input for every frame up to the horizon, and tell the
     * other window about each one.
     *
     * The horizon moves with the machines rather than with the wall clock, so
     * this cannot drift: fall behind and the machines wait for us, run ahead
     * and there is simply nothing left to book.
     */
    protected fillSchedule(): void {
        if (!this.connected) {
            return;
        }
        const horizon = this.machineFrame + this.delay;
        if (this.nextFrame > horizon) {
            return;
        }
        // A window that has been away comes back to a horizon far ahead of it.
        // Booking every frame in between would be pointless work for input
        // nobody gave, so the gap is skipped and the machines take the stall.
        if (this.nextFrame < this.machineFrame) {
            this.nextFrame = this.machineFrame;
        }
        const sim = this.emulatorSession.sim;
        for (let frame = this.nextFrame; frame <= horizon; frame++) {
            const keys = this.heldKeys;
            sim.queueKeys(frame, keys).catch(() => undefined);
            this.channel.send({ kind: 'input', seat: this.seat, epoch: this.epoch, frame, keys });
        }
        this.nextFrame = horizon + 1;
    }

    /**
     * Change one of the two machines, in both windows, on the same frame.
     *
     * The write side of the session, and the reason it exists: switching a
     * cheat on, or poking a value the Cheat Finder turned up, is a change
     * nothing in the emulated program knows about — so unlike a button press
     * it has no route from one window to the other. Made in one window only,
     * the two machines are running different games from that moment, which
     * the digest check ends the session over a second later without being
     * able to say why.
     *
     * `seat` names the machine being changed rather than the window asking,
     * so a debugger can aim at either: our own seat is our own machine here
     * and the mirror there, and the other seat the other way round.
     *
     * ## The frame
     *
     * Far enough ahead that both windows can still book it. Neither window
     * can be more than {@link delay} frames from the other — each only runs
     * on input booked at most that far ahead, and under lockstep it runs on
     * nothing else — so `nextFrame`, which is already a full delay past our
     * own machine, is past theirs too. A second delay on top is the message's
     * travel time, and 60 ms of it is a great deal more than a
     * BroadcastChannel takes.
     *
     * Not a promise of anything: the booking goes in as the frame is chosen
     * and the message leaves at once, because the other window has to hear
     * about it before its own machine reaches that frame.
     */
    scheduleEdits(seat: LinkSeat, edits: ScheduledEdit[]): boolean {
        if (!this.connected || edits.length === 0) {
            return false;
        }
        const frame = Math.max(this.nextFrame, this.machineFrame + this.delay + 1) + this.delay;
        // Sent before it is booked here, so that the window with further to
        // travel gets the head start rather than the one with none.
        this.channel.send({ kind: 'edit', seat, epoch: this.epoch, frame, edits });
        this.bookEdits(seat, frame, edits);
        return true;
    }

    /**
     * Put booked writes into whichever of this window's machines they name.
     *
     * A booking the core refuses is a frame that has already been emulated —
     * which means this window has applied a change the other one applied
     * somewhere else, or not at all. That is a desync that has already
     * happened; saying so beats letting the digest report it a second later
     * as an unexplained one.
     */
    protected bookEdits(seat: LinkSeat, frame: number, edits: ScheduledEdit[]): void {
        const sim = seat === this.seat ? this.emulatorSession.sim : this.mirror;
        if (!sim) {
            return;
        }
        sim.queueEdits(frame, edits).catch(() => this.close({
            reason: 'edit',
            message: 'A change to one of the machines arrived too late to be made on the'
                + ' same frame in both windows, so the link session ended.',
        }));
    }

    /**
     * The other window changed one of the machines.
     *
     * Held rather than dropped when there is nowhere to put it yet — see
     * {@link pendingEdits}, and `onRemoteInput` for the same reasoning about
     * input.
     */
    protected onRemoteEdits(
        epoch: number,
        seat: LinkSeat,
        frame: number,
        edits: ScheduledEdit[],
    ): void {
        if (epoch < this.epoch) {
            return;
        }
        if (epoch === this.epoch && this.connected && this.mirror) {
            this.bookEdits(seat, frame, edits);
            return;
        }
        if (this.pendingEdits.length < LinkSession.MAX_PENDING_EDITS) {
            this.pendingEdits.push({ epoch, seat, frame, edits });
        }
    }

    /**
     * Tell the other window what this window's machine is already running
     * under, so its mirror of us starts the run the same way.
     *
     * At frame zero, and sent before the first input is booked: the channel
     * delivers in order, so a cheat sent first is in force before the frame
     * it would otherwise have missed.
     */
    protected sendStandingEdits(): void {
        const edits = this.standingEdits();
        if (edits.length === 0) {
            return;
        }
        // Our own machine already has them — the store put them there when
        // they were switched on, and a reset does not take them off — so this
        // is for their mirror only, and is not booked here.
        this.channel.send({ kind: 'edit', seat: this.seat, epoch: this.epoch, frame: 0, edits });
    }

    /**
     * One of this window's machines reached a frame its digest was due at.
     *
     * Ours goes to the other window, to be checked against their copy of this
     * machine. Our copy of *their* machine is kept until their own digest for
     * that frame arrives.
     */
    protected onLocalDigest(sim: number, frame: number, digest: number): void {
        if (!this.connected) {
            return;
        }
        if (sim === this.emulatorSession.sim.id) {
            this.channel.send({ kind: 'digest', seat: this.seat, epoch: this.epoch, frame, digest });
            return;
        }
        if (sim !== this.mirror?.id) {
            return;
        }
        this.mirrorDigests.set(frame, digest);
        // Oldest first, so dropping from the front drops the stalest.
        while (this.mirrorDigests.size > LinkSession.MAX_KEPT_DIGESTS) {
            const oldest = this.mirrorDigests.keys().next();
            if (oldest.done) {
                break;
            }
            this.mirrorDigests.delete(oldest.value);
        }
    }

    /**
     * The other window's account of its own machine at one frame.
     *
     * Compared against our copy of it. A frame we have nothing for is not a
     * disagreement — the two windows do not reach a frame at the same instant,
     * so one side's digest routinely arrives before or after ours was taken;
     * only two digests of the same frame that differ mean anything.
     */
    protected onRemoteDigest(frame: number, digest: number): void {
        const ours = this.mirrorDigests.get(frame);
        if (ours === undefined) {
            return;
        }
        this.mirrorDigests.delete(frame);
        if (ours === digest) {
            return;
        }
        this.close({
            reason: 'desync',
            message: 'The two machines stopped matching, so the link session ended.',
        });
    }

    /**
     * A snapshot of both machines, for saving.
     *
     * Named by player rather than by whose window they came from, because that
     * is the only naming both windows agree on. Either window can take one:
     * they are running the same pair, so the two snapshots are the same.
     */
    async snapshot(): Promise<{ p1: ArrayBuffer, p2: ArrayBuffer } | undefined> {
        const mirror = this.mirror;
        if (!this.connected || !mirror) {
            return undefined;
        }
        const own = await this.emulatorSession.sim.saveState();
        const theirs = await mirror.saveState();
        return this.seat === 1 ? { p1: own, p2: theirs } : { p1: theirs, p2: own };
    }

    /**
     * Put both windows back to a saved moment.
     *
     * Sent before it is applied here, so the other window starts its own
     * restart at about the same time rather than a round trip later.
     */
    async resume(p1: ArrayBuffer, p2: ArrayBuffer): Promise<void> {
        if (!this.connected) {
            return;
        }
        const epoch = this.epoch + 1;
        this.channel.send({
            kind: 'resume', seat: this.seat, epoch, p1: p1.slice(0), p2: p2.slice(0),
        });
        await this.applyResume(epoch, p1, p2);
    }

    protected async applyResume(epoch: number, p1: ArrayBuffer, p2: ArrayBuffer): Promise<void> {
        const mirror = this.mirror;
        if (!this.connected || !mirror || epoch <= this.epoch) {
            return;
        }
        const own = this.emulatorSession.sim;
        const mine = this.seat === 1 ? p1 : p2;
        const theirs = this.seat === 1 ? p2 : p1;

        // From here anything still in flight from the previous run is ignored,
        // so a stale mask cannot be taken for one of the frames about to be
        // played again.
        this.epoch = epoch;
        this.mirrorDigests.clear();

        // Resetting is what puts the frame count back to zero and drops the
        // bookings; the state goes on top of that, into a machine that cannot
        // run a frame in between because it has nothing booked.
        await own.reset();
        await mirror.reset();
        await own.loadState(mine.slice(0));
        await mirror.loadState(theirs.slice(0));

        this.nextFrame = 0;
        this.machineFrame = 0;
        // Said again rather than assumed to have survived. A cheat switched on
        // moments before the state was loaded may have been booked against a
        // frame one window reached and the other did not, which leaves the two
        // running under different sets — and the reset that just happened
        // dropped the bookings that would have settled it.
        this.sendStandingEdits();
        // The other window restarts at about the same moment, so its first
        // frames of the new run are very likely already here.
        this.drainPendingRemote(mirror);
        this.fillSchedule();
    }

    protected onRemoteInput(epoch: number, frame: number, keys: number): void {
        // From a run that is over. Its frame numbers mean nothing now.
        if (epoch < this.epoch) {
            return;
        }
        // Deliberately not "is there a mirror": there is one from early in
        // `begin`, and everything booked into it before the reset at the end
        // of `begin` is thrown away with the reset. Only once the session says
        // it has begun — and is on the same run — is the mirror a machine
        // worth booking against.
        if (epoch === this.epoch && this.connected && this.mirror) {
            this.mirror.queueKeys(frame, keys).catch(() => undefined);
            return;
        }
        // Either we have not begun yet, or the other window has already
        // restarted and we are about to. Both are the same problem: under
        // lockstep nothing re-sends a frame, so anything dropped here is a
        // frame the mirror waits for for ever. See `pendingRemote`.
        if (this.pendingRemote.length < LinkSession.MAX_PENDING_REMOTE) {
            this.pendingRemote.push({ epoch, frame, keys });
        }
    }

    /**
     * Book whatever the other window sent while this one was setting up.
     *
     * Only for the run we are now on: anything older named frames that have
     * been played already, and anything newer is for a restart still to come.
     */
    protected drainPendingRemote(mirror: Sim): void {
        const held = this.pendingRemote.splice(0);
        for (const input of held) {
            if (input.epoch === this.epoch) {
                mirror.queueKeys(input.frame, input.keys).catch(() => undefined);
            } else if (input.epoch > this.epoch) {
                this.pendingRemote.push(input);
            }
        }
        // Before the input rather than after would be tidier to read, and
        // wrong: these are booked against frames like everything else, so the
        // order they are handed to the core in does not matter — the order
        // they are applied in is the order of the frames they name.
        const edits = this.pendingEdits.splice(0);
        for (const edit of edits) {
            if (edit.epoch === this.epoch) {
                this.bookEdits(edit.seat, edit.frame, edit.edits);
            } else if (edit.epoch > this.epoch) {
                this.pendingEdits.push(edit);
            }
        }
    }

    protected setState(state: LinkState): void {
        // A closed session stays closed; a late message must not revive it.
        if (this.state === state || this.state === LinkState.Closed) {
            return;
        }
        this.state = state;
        this.armStallTimeout(state === LinkState.Stalled);
        this.onDidChangeEmitter.fire();
    }

    /**
     * Start or stop counting how long we have been standing still.
     *
     * Standing still is ordinary — it is what happens whenever the other
     * window is a few frames behind — so this only gives up after long enough
     * that the other window is not coming back. See {@link PEER_TIMEOUT_MS}.
     */
    protected armStallTimeout(armed: boolean): void {
        if (this.stallTimer !== undefined) {
            clearTimeout(this.stallTimer);
            this.stallTimer = undefined;
        }
        if (!armed) {
            return;
        }
        // Closed rather than left waiting: silence is not an unlink, and a
        // window that went quiet without saying goodbye has given no reason to
        // expect it back. Inviting somebody afresh is the offer that makes
        // sense there.
        this.stallTimer = setTimeout(
            () => this.close({
                reason: 'closed',
                message: 'The other player stopped responding.',
            }),
            LinkSession.PEER_TIMEOUT_MS,
        );
    }

    /**
     * The other player is not there any more.
     *
     * Which of two things that means depends on whether their window is still
     * open, and the difference is the whole of what this decides. An unlink is
     * not a failure — both windows still have the game, and the natural next
     * thing either player does is link again — so this window lets the
     * machines go, forgets the run, and goes back to waiting with the channel
     * still open. Seat 2 starts saying hello again by itself, because its
     * hello timer only ever asked whether the state was `Waiting`; seat 1 goes
     * on listening for one. So re-linking is one press, in one window.
     *
     * A window that closed is gone, and a session waiting for it would be a
     * session waiting for nobody: that ends properly, and the chrome offers to
     * invite somebody new.
     */
    protected peerGone(refusal: LinkRefusal): void {
        if (this.state === LinkState.Closed || this.disposed) {
            return;
        }
        if (refusal.reason === 'closed') {
            this.close(refusal);
            return;
        }
        this.refusal = refusal;
        this.state = LinkState.Waiting;
        this.armStallTimeout(false);
        // So the next hello is answered rather than taken for a repeat of the
        // one that started the session that has just ended.
        this.beginning = false;
        /*
         * The run itself, put away here rather than when the next one starts.
         *
         * The epoch counts save states loaded into the run that has just
         * ended, and frame numbers begin again at zero in the next one — so a
         * window that carried its epoch across would refuse every input the
         * other one sent, and the two would sit staring at each other. The
         * queues go for the same reason: what is in them is input and writes
         * booked against frames of a run that is over.
         *
         * Not in `begin`, which is also the first begin: what is waiting there
         * is input from the *coming* run that arrived before this window had a
         * machine to put it in, and throwing that away strands the mirror at
         * frame zero for ever. See `pendingRemote`.
         */
        this.epoch = 0;
        this.pendingRemote.length = 0;
        this.pendingEdits.length = 0;
        this.releaseMachines().catch(() => undefined);
        this.onDidChangeEmitter.fire();
    }

    /** End the session for good, leaving this window's own machine running alone. */
    protected close(refusal: LinkRefusal): void {
        if (this.state === LinkState.Closed) {
            return;
        }
        this.refusal = refusal;
        this.state = LinkState.Closed;
        this.armStallTimeout(false);
        this.releaseMachines().catch(() => undefined);
        this.onDidChangeEmitter.fire();
    }

    /**
     * Put the machines back to running on their own.
     *
     * Lockstep comes off first and the mirror goes second: a machine left
     * under lockstep with nothing booking for it never runs another frame.
     */
    protected releaseMachines(): Promise<void> {
        this.mirrorDigests.clear();
        // The whole hand-back owns the mirror, so the next run — which may
        // well be a session that does not exist yet — waits for all of it and
        // not just for the last step. See `withMirror`.
        return this.emulatorSession.withMirror(async () => {
            await this.emulatorSession.sim.setDigestPeriod(0).catch(() => undefined);
            await this.emulatorSession.sim.setLockstep(false).catch(() => undefined);
            await this.emulatorSession.detachMirror().catch(() => undefined);
            this.mirror = undefined;
        });
    }

    /**
     * Leave the session.
     *
     * `leaving` is what the other window is told, and it decides what happens
     * there: `session` leaves it waiting, with the game still open in both
     * windows and one press between them and playing again; `window` ends it,
     * because this window is going away. See {@link LinkGoodbye}.
     */
    dispose(leaving: 'session' | 'window' = 'window'): void {
        if (this.disposed) {
            return;
        }
        this.disposed = true;
        if (this.helloTimer !== undefined) {
            clearInterval(this.helloTimer);
            this.helloTimer = undefined;
        }
        this.armStallTimeout(false);
        // Said before the channel goes, so the other window stops waiting for
        // input that is never coming rather than stalling until it is closed.
        this.channel.send({ kind: 'bye', seat: this.seat, leaving });
        this.releaseMachines().catch(() => undefined);
        this.toDispose.dispose();
        this.channel.dispose();
        this.onDidChangeEmitter.dispose();
    }
}
