import { Emitter, Event } from '../common/emulator-events';
import { crc32, formatRomId } from '../common/emulator-cheat-database';
import { VueportStorage } from '../common/emulator-host';
import {
    builtInPatchesFor,
    PATCH_DATABASE,
    BuiltInRomPatch,
    RomPatchDatabaseEntry,
} from '../common/emulator-patch-database';
import {
    applyRomPatches,
    detectRomPatchFormat,
    RomPatch,
    RomPatchFormat,
    RomPatchType,
    ROM_PATCH_TYPES,
} from '../common/emulator-rom-patches';
import {
    readVesBrowserState,
    browserStateStorage,
    browserStateKey,
    writeVesBrowserState,
} from './emulator-browser-state';

/*
 * Patch bytes are kept in a JSON file, so they travel as base64.
 *
 * `atob`/`btoa` are what a page already has; the `buffer` package answers the
 * same two calls and costs twenty-five kilobytes of bundle to do it. The
 * encoder walks the array in chunks rather than spreading it into
 * `String.fromCharCode`, because a patch is routinely large enough that one
 * call with a million arguments overflows the stack.
 */

/** How many bytes are turned into characters per call. */
const BASE64_CHUNK = 0x8000;

function toBase64(bytes: Uint8Array): string {
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += BASE64_CHUNK) {
        binary += String.fromCharCode(...bytes.subarray(offset, offset + BASE64_CHUNK));
    }
    return btoa(binary);
}

function fromBase64(text: string): Uint8Array {
    const binary = atob(text);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

interface StoredPatch {
    id: string;
    name: string;
    fileName: string;
    format: RomPatchFormat;
    /** Base64 in current files; number arrays remain accepted for early builds. */
    data: string | number[];
    /** Accepted while migrating files written before state moved to the browser. */
    enabled?: boolean;
    description?: string;
    author?: string;
    type?: RomPatchType;
    screenshot?: string;
}

interface StoredPatchState {
    enabled?: string[];
    patches?: StoredPatch[];
}

interface StoredBrowserPatchState {
    enabled?: string[];
}

/** Fields the player may edit on an imported patch. */
export type RomPatchMetadata = Pick<RomPatch,
    'name' | 'description' | 'author' | 'type' | 'screenshot'>;

const patchType = (value: unknown): RomPatchType =>
    ROM_PATCH_TYPES.includes(value as RomPatchType)
        ? value as RomPatchType
        : 'hack';

/** Why listeners are redrawing; ROM-affecting changes require a restart. */
export interface PatchStoreChange {
    affectsRom: boolean;
}

/**
 * Registered built-in and imported patches for the current original ROM.
 * Imported definitions live in the companion JSON; current switches live in
 * browser storage and never make built-ins appear in that file.
 */
/** Whether two patches carry the same bytes, so a rebuild that changed nothing costs nothing. */
function sameBytes(a: Uint8Array | undefined, b: Uint8Array): boolean {
    if (!a || a.length !== b.length) {
        return false;
    }
    for (let at = 0; at < a.length; at += 1) {
        if (a[at] !== b[at]) {
            return false;
        }
    }
    return true;
}

export class PatchStore {
    protected builtIn: RomPatch[] = [];
    /**
     * Patches VUEPort generated itself this session — currently the VB Color
     * colorizations, built from a shipped patch document, the player's palette
     * edits and the running ROM.
     *
     * A list of their own, and deliberately not part of `custom`: `custom` is
     * what gets written to the patch file beside the ROM, and a generated patch
     * has no business being persisted. It is rebuilt from its document
     * whenever it is needed, so persisting it could only ever produce a stale
     * copy.
     */
    protected generated: RomPatch[] = [];
    protected custom: RomPatch[] = [];
    protected sourceRom: Uint8Array | undefined;
    protected statePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected loaded = false;
    protected persisting: Promise<void> = Promise.resolve();

    protected readonly onDidChangeEmitter = new Emitter<PatchStoreChange>();
    readonly onDidChange: Event<PatchStoreChange> = this.onDidChangeEmitter.event;

    constructor(
        protected readonly storage: VueportStorage,
        protected readonly database: readonly RomPatchDatabaseEntry[] = PATCH_DATABASE,
        protected readonly stateStorage?: browserStateStorage,
    ) { }

    get list(): ReadonlyArray<RomPatch> {
        return [...this.builtIn, ...this.generated, ...this.custom];
    }

    /**
     * The unmodified ROM the patches apply to, for whoever has to build one.
     *
     * The VB Color build needs it: a BPS is a delta, so generating one means
     * having the source it is a delta against.
     */
    get rom(): Uint8Array | undefined {
        return this.sourceRom;
    }

    /**
     * Add or replace a patch VUEPort generated, by id.
     *
     * Replacing rather than appending, because the color editor rebuilds its
     * patch behind every edit and the list must not grow a copy each time.
     *
     * Returns whether the running ROM is affected, which is true when the patch
     * is enabled and either was not before or its bytes changed. `restart` is
     * how the caller says whether that is worth restarting the game for, and
     * while somebody is editing colors it is not: the edit is already on
     * screen and already in the running ROM's palette table, and the new bytes
     * only have to be in place for the next restart. Passing false still
     * replaces the patch and still tells listeners to redraw — it withholds
     * only the ROM-affecting flag the restart hangs off.
     */
    setGeneratedPatch(patch: RomPatch, restart = true): boolean {
        if (!patch.id) {
            throw new Error('A generated patch needs an id.');
        }
        const at = this.generated.findIndex(candidate => candidate.id === patch.id);
        const previous = at >= 0 ? this.generated[at] : undefined;
        const next: RomPatch = { ...patch, builtIn: true, generated: true };
        if (at >= 0) {
            this.generated[at] = next;
        } else {
            this.generated.push(next);
        }
        const affectsRom = next.enabled
            && (previous?.enabled !== true || !sameBytes(previous.data, next.data));
        this.changed(false, true, affectsRom && restart);
        return affectsRom;
    }

    /** Take a generated patch away again. */
    removeGeneratedPatch(id: string): void {
        const at = this.generated.findIndex(candidate => candidate.id === id);
        if (at < 0) {
            return;
        }
        const affectsRom = this.generated[at].enabled;
        this.generated.splice(at, 1);
        this.changed(false, true, affectsRom);
    }

    get active(): number {
        return this.list.filter(patch => patch.enabled).length;
    }

    /**
     * The patch at a list index, and where it lives.
     *
     * `custom` is its index in the player's own patches, or -1 for one of the
     * two lists VUEPort owns — the shipped ones and the generated ones — which
     * are addressed through `at`'s own return value instead.
     */
    protected at(index: number): { patch: RomPatch, custom: number, generated: number } | undefined {
        if (index < 0) {
            return undefined;
        }
        if (index < this.builtIn.length) {
            return { patch: this.builtIn[index], custom: -1, generated: -1 };
        }
        const afterBuiltIn = index - this.builtIn.length;
        if (afterBuiltIn < this.generated.length) {
            return { patch: this.generated[afterBuiltIn], custom: -1, generated: afterBuiltIn };
        }
        const custom = afterBuiltIn - this.generated.length;
        return this.custom[custom] ? { patch: this.custom[custom], custom, generated: -1 } : undefined;
    }

    async load(romPath: string, romId: string | undefined, sourceRom: Uint8Array): Promise<void> {
        const directory = this.storage.parent(romPath);
        const stem = this.storage.stem(romPath);
        this.statePath = this.storage.join(directory, `${stem}.vueport-patches.json`);
        this.browserStateKey = browserStateKey('patches', romPath);
        this.sourceRom = sourceRom.slice();
        this.builtIn = [];
        // Generated patches belong to the ROM they were compiled against, so a
        // new one starts with none. Whoever generates them puts them back.
        this.generated = [];
        this.custom = [];
        let state: StoredPatchState = {};
        try {
            if (await this.storage.exists(this.statePath)) {
                const parsed = JSON.parse(await this.storage.readText(this.statePath));
                if (parsed && typeof parsed === 'object') {
                    state = parsed;
                }
            }
            this.builtIn = builtInPatchesFor(romId, this.database)
                .map((patch: BuiltInRomPatch) => ({
                    ...patch,
                    data: new Uint8Array(patch.data),
                    enabled: false,
                    builtIn: true,
                }));
            this.custom = (Array.isArray(state.patches) ? state.patches : [])
                .filter(patch => patch && (typeof patch.data === 'string' || Array.isArray(patch.data)))
                .map(patch => {
                    const data = typeof patch.data === 'string'
                        ? fromBase64(patch.data)
                        : new Uint8Array(patch.data);
                    return {
                        id: String(patch.id),
                        name: String(patch.name),
                        fileName: String(patch.fileName),
                        format: detectRomPatchFormat(data),
                        data,
                        enabled: Boolean(patch.enabled),
                        description: typeof patch.description === 'string' ? patch.description : undefined,
                        author: typeof patch.author === 'string' ? patch.author : undefined,
                        type: patchType(patch.type),
                        screenshot: typeof patch.screenshot === 'string' ? patch.screenshot : undefined,
                    };
                });
            const stored = readVesBrowserState<StoredBrowserPatchState>(
                this.stateStorage, this.browserStateKey);
            const legacyEnabled = [
                ...(Array.isArray(state.enabled) ? state.enabled : []),
                ...this.custom.flatMap(patch => patch.enabled ? [patch.id!] : []),
            ];
            const enabled = new Set(Array.isArray(stored?.enabled)
                ? stored.enabled.filter(id => typeof id === 'string')
                : legacyEnabled);
            this.builtIn = this.builtIn.map(patch => ({
                ...patch,
                enabled: enabled.has(patch.id!),
            }));
            this.custom = this.custom.map(patch => ({
                ...patch,
                enabled: enabled.has(patch.id!),
            }));
            // Do not carry an invalid enabled combination into the emulator.
            this.apply(sourceRom);
            this.loaded = true;
            if (this.saveBrowserState()) {
                const hasLegacyState = Object.prototype.hasOwnProperty.call(state, 'enabled')
                    || (state.patches ?? []).some(patch => patch.enabled !== undefined);
                if (hasLegacyState) {
                    await this.saveDefinitions();
                }
            }
        } catch (error) {
            console.warn(`[emulator] could not read patches from ${this.statePath}:`, error);
            this.builtIn = this.builtIn.map(patch => ({ ...patch, enabled: false }));
            this.custom = this.custom.map(patch => ({ ...patch, enabled: false }));
            this.loaded = true;
        }
        this.changed(false, false, false);
    }

    unload(): void {
        this.builtIn = [];
        this.generated = [];
        this.custom = [];
        this.sourceRom = undefined;
        this.statePath = undefined;
        this.browserStateKey = undefined;
        this.loaded = false;
        this.changed(false, false, false);
    }

    /** Import one recognized patch, disabled until the player opts in. */
    importPatch(fileName: string, data: Uint8Array): number {
        if (!this.loaded || !this.sourceRom) {
            throw new Error('No ROM is loaded.');
        }
        const format = detectRomPatchFormat(data);
        // Validate source compatibility without changing the running ROM. An
        // imported patch never enables itself.
        this.validateResult(applyRomPatches(this.sourceRom, [{
            name: fileName,
            fileName,
            format,
            data,
            enabled: true,
            type: 'hack',
        }]));
        const id = `custom-${format}-${formatRomId(crc32(data))}`;
        const existing = this.custom.findIndex(candidate => candidate.id === id);
        const patch: RomPatch = {
            id,
            name: fileName.replace(/\.(ips|ups|bps|bdf|bspatch)$/i, '') || fileName,
            fileName,
            format,
            data: data.slice(),
            enabled: false,
            type: 'hack',
        };
        if (existing >= 0) {
            this.custom[existing] = patch;
            this.changed(true, true, false);
            return this.builtIn.length + this.generated.length + existing;
        }
        this.custom.push(patch);
        this.changed(true, true, false);
        return this.list.length - 1;
    }

    /** Change descriptive fields on one of the player's imported patches. */
    updateMetadata(index: number, metadata: Partial<RomPatchMetadata>): void {
        const found = this.at(index);
        if (!found || found.custom < 0) {
            return;
        }
        const clean: Partial<RomPatchMetadata> = {
            ...metadata,
            type: metadata.type === undefined ? undefined : patchType(metadata.type),
        };
        // Undefined means "not part of this edit", except for a screenshot:
        // the detail view deliberately uses it to remove an existing image.
        if (metadata.type === undefined) {
            delete clean.type;
        }
        this.custom[found.custom] = { ...found.patch, ...clean };
        this.changed(true, true, false);
    }

    /** Enable or disable one patch, validating the entire resulting chain. */
    setEnabled(index: number, enabled: boolean): void {
        const found = this.at(index);
        if (!found || found.patch.enabled === enabled || !this.sourceRom) {
            return;
        }
        const changed = { ...found.patch, enabled };
        const candidate = [...this.list];
        candidate[index] = changed;
        this.validateResult(applyRomPatches(this.sourceRom, candidate));
        // Back into whichever of the three lists it came from. `index` is an
        // index into the concatenation, so it only addresses `builtIn` directly
        // for a patch that is actually in it.
        if (found.generated >= 0) {
            this.generated[found.generated] = changed;
        } else if (found.custom >= 0) {
            this.custom[found.custom] = changed;
        } else {
            this.builtIn[index] = changed;
        }
        this.changed(false, true, true);
    }

    remove(index: number): void {
        const found = this.at(index);
        if (!found || found.custom < 0) {
            return;
        }
        const affectsRom = found.patch.enabled;
        this.custom.splice(found.custom, 1);
        this.changed(true, true, affectsRom);
    }

    disableAll(): void {
        if (this.active === 0) {
            return;
        }
        this.builtIn = this.builtIn.map(patch => ({ ...patch, enabled: false }));
        this.generated = this.generated.map(patch => ({ ...patch, enabled: false }));
        this.custom = this.custom.map(patch => ({ ...patch, enabled: false }));
        this.changed(false, true, true);
    }

    apply(source: Uint8Array): Uint8Array {
        return this.validateResult(applyRomPatches(source, this.list));
    }

    /** The Virtual Boy core accepts cartridge images in power-of-two sizes. */
    protected validateResult(result: Uint8Array): Uint8Array {
        if (result.length === 0 || !Number.isInteger(Math.log2(result.length))) {
            throw new Error('The patch result is not a power-of-two-sized Virtual Boy ROM.');
        }
        return result;
    }

    /** Wait until all state changes made so far have reached storage. */
    whenSaved(): Promise<void> {
        return this.persisting;
    }

    protected changed(persistDefinitions: boolean, persistState: boolean, affectsRom: boolean): void {
        if (persistState) {
            this.saveBrowserState();
        }
        if (persistDefinitions) {
            this.persisting = this.persisting.then(() => this.saveDefinitions());
        }
        this.onDidChangeEmitter.fire({ affectsRom });
    }

    protected saveBrowserState(): boolean {
        const enabled = this.list.filter(patch => patch.enabled).map(patch => patch.id!);
        return writeVesBrowserState(
            this.stateStorage, this.browserStateKey, { enabled }, this.list.length === 0);
    }

    protected async saveDefinitions(): Promise<void> {
        const path = this.statePath;
        if (!path || !this.loaded) {
            return;
        }
        const patches: StoredPatch[] = this.custom.map(patch => ({
            id: patch.id!,
            name: patch.name,
            fileName: patch.fileName,
            format: patch.format,
            data: toBase64(patch.data),
            description: patch.description,
            author: patch.author,
            type: patch.type,
            screenshot: patch.screenshot,
        }));
        try {
            if (patches.length === 0) {
                if (await this.storage.exists(path)) {
                    await this.storage.delete(path);
                }
            } else {
                await this.storage.writeText(path, JSON.stringify({ patches }, undefined, 2) + '\n');
            }
        } catch (error) {
            console.warn(`[emulator] could not store patches in ${path}:`, error);
        }
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}
