/**
 * The small, synchronous browser store used for per-ROM UI state.
 *
 * Kept structural rather than typed as DOM `Storage`, so tests and hosts can
 * provide the few operations without pretending to be a complete browser.
 */
export interface browserStateStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}

/** One namespaced localStorage key for one kind of state and one ROM. */
export function browserStateKey(kind: string, romPath: string): string {
    return `vueport.${kind}-state.${encodeURIComponent(romPath)}`;
}

/** A compact deterministic identity for a user definition kept elsewhere. */
export function browserStateId(value: string): string {
    let first = 0x811c9dc5;
    let second = 0x6d2b79f5;
    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        first = Math.imul(first ^ code, 0x01000193);
        second = Math.imul(second ^ code, 0x5bd1e995);
    }
    return `${(first >>> 0).toString(16).padStart(8, '0')}`
        + `${(second >>> 0).toString(16).padStart(8, '0')}-${value.length}`;
}

/** Read JSON without allowing a damaged browser preference to stop a ROM. */
export function readVesBrowserState<T>(
    storage: browserStateStorage | undefined,
    key: string,
): T | undefined {
    if (!storage) {
        return undefined;
    }
    try {
        const text = storage.getItem(key);
        return text === null ? undefined : JSON.parse(text) as T;
    } catch {
        return undefined;
    }
}

/**
 * Write JSON, removing an empty state instead of accumulating one key for
 * every ROM that has merely been opened.
 */
export function writeVesBrowserState(
    storage: browserStateStorage | undefined,
    key: string | undefined,
    value: object,
    empty: boolean,
): boolean {
    if (!storage || !key) {
        return false;
    }
    try {
        if (empty) {
            storage.removeItem(key);
        } else {
            storage.setItem(key, JSON.stringify(value));
        }
        return true;
    } catch {
        // Losing a remembered switch is not worth interrupting emulation.
        return false;
    }
}
