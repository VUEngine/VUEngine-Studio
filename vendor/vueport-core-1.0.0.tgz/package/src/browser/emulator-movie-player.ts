import { Emitter, Event } from '../common/emulator-events';
import { Movie } from '../common/emulator-movie';
import { VbKey } from '../common/vb-constants';
import { Sim } from './core/vb-core';

/**
 * Plays a recorded input movie back into a running machine.
 *
 * A movie is only worth anything if it is reproduced exactly: one frame of
 * slip and the run is somebody else's game. So playback does not hand buttons
 * to the input controller and hope the frames line up — it books each frame's
 * mask against that frame number with `queueKeys`, and puts the machine under
 * lockstep so it refuses to run past what has been booked. The machine then
 * waits for the movie rather than the movie chasing the machine, which is the
 * only arrangement that cannot drift.
 *
 * That machinery exists for link sessions, where two windows have to agree
 * frame by frame. A movie is the same problem with one of the windows replaced
 * by a file.
 *
 * The player deliberately does not reset the machine itself. A movie starts
 * from power-on, and what "power-on" means — which save is in the cartridge,
 * which hardware model, whether a color patch is applied — belongs to
 * whoever owns the emulator.
 */
export class MoviePlayer {

    /**
     * How far ahead of the machine to keep the schedule filled.
     *
     * Comfortably inside the worker's own limit on how far a booking may
     * reach, and far enough that a slow frame on this side never leaves the
     * machine with nothing booked and stalls it.
     */
    protected static readonly HORIZON = 240;

    protected movie: Movie | undefined;
    protected sim: Sim | undefined;
    /** The next movie frame that has not been booked yet. */
    protected nextFrame = 0;
    /** Where the machine had got to at the last report. */
    protected machineFrame = 0;

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires when playback starts, stops, or advances a reported frame. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    get playing(): boolean {
        return this.movie !== undefined;
    }

    /** The movie being played, for chrome that wants to name it. */
    get current(): Movie | undefined {
        return this.movie;
    }

    /** How far through the movie the machine has got, in frames. */
    get frame(): number {
        return this.machineFrame;
    }

    get length(): number {
        return this.movie?.frames.length ?? 0;
    }

    /**
     * Start playing `movie` into `sim`, from the frame the machine is at.
     *
     * The caller resets first for a run that is meant to be reproduced; a
     * movie started against a machine that has been running is played from
     * wherever it happens to be, which is occasionally what somebody wants and
     * never what a published run needs.
     */
    async start(sim: Sim, movie: Movie): Promise<void> {
        await this.stop();
        if (movie.frames.length === 0) {
            return;
        }
        this.movie = movie;
        this.sim = sim;
        this.nextFrame = 0;
        this.machineFrame = 0;
        await sim.setLockstep(true);
        this.fill();
        this.onDidChangeEmitter.fire();
    }

    /**
     * The machine has reached `frame`; book more, and notice the end.
     *
     * Driven by the core's progress reports, which only a machine under
     * lockstep sends — so this is quiet for an emulator that is not playing a
     * movie, and costs nothing.
     */
    advance(frame: number): void {
        if (!this.movie) {
            return;
        }
        this.machineFrame = frame;
        if (frame >= this.movie.frames.length) {
            this.stop().catch(() => undefined);
            return;
        }
        this.fill();
        this.onDidChangeEmitter.fire();
    }

    /** Stop playing and let the machine run freely again. */
    async stop(): Promise<void> {
        const sim = this.sim;
        this.movie = undefined;
        this.sim = undefined;
        this.nextFrame = 0;
        if (sim) {
            await sim.setLockstep(false).catch(() => undefined);
        }
        this.onDidChangeEmitter.fire();
    }

    /** Book every frame from where booking left off up to the horizon. */
    protected fill(): void {
        const movie = this.movie;
        const sim = this.sim;
        if (!movie || !sim) {
            return;
        }
        const horizon = Math.min(
            this.machineFrame + MoviePlayer.HORIZON, movie.frames.length - 1);
        for (let frame = Math.max(this.nextFrame, this.machineFrame); frame <= horizon; frame++) {
            // The signature bit is the machine being told a controller is
            // plugged in, not a button, so no movie format records it — and
            // booking a mask without it would unplug the pad for that frame.
            sim.queueKeys(frame, movie.frames[frame] | VbKey.SGN).catch(() => undefined);
        }
        this.nextFrame = Math.max(this.nextFrame, horizon + 1);
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}
