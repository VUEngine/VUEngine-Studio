/**
 * What a headset shows besides the game: a menu or a question in front of the
 * screen, and a line of news beneath it.
 *
 * The page's own interface is gone while a session lasts — a headset shows
 * nothing of the document — so the little that is needed in there is drawn
 * here, with a 2D canvas, and handed to the session as a texture. Driven by
 * the controllers alone: the sticks move through a list, A takes the line
 * under the cursor, B goes back. See `EmulatorXrSession.showPanel`.
 */

/** One line of a panel: something to do. */
export interface XrPanelItem {
    label: string;
    /** Shown beside the label, dimmer: a state, a shortcut. */
    detail?: string;
    disabled?: boolean;
    /**
     * What choosing it does. The panel closes afterwards, unless this says
     * `'keep'` — a switch, whose new state the panel then shows.
     */
    run(): void | 'keep';
}

/** A menu or a question, in front of the screen. */
export interface XrPanel {
    title: string;
    /** Lines of text above the items: what a question is asking. */
    message?: string[];
    /** Read again whenever the panel is drawn, so a switch shows its new state. */
    items(): XrPanelItem[];
    /**
     * Lines at the foot of the panel, dimmer than the rest: what else the
     * controllers do, for somebody who cannot look at the page to find out.
     */
    footer?: string[];
    /** A heading over the footer, saying when what it lists applies. */
    footerTitle?: string;
    /** The panel has gone, however: chosen, backed out of, or replaced. */
    onClose?(): void;
}

/** The panel's canvas, in pixels; its width in the room is `XR_PANEL_WIDTH`. */
export const XR_PANEL_PIXELS = { width: 1024, height: 960 };
/** The news line's canvas, in pixels. */
export const XR_TOAST_PIXELS = { width: 1024, height: 112 };

const COLORS = {
    background: '#141414',
    border: '#3a3a3a',
    title: '#ff3b30',
    text: '#f2f2f2',
    dim: '#8c8c8c',
    disabled: '#5a5a5a',
    cursor: '#c4001a',
    cursorText: '#ffffff',
    error: '#ff6b5e',
};

const FONT = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
const PADDING = 48;
const TITLE_SIZE = 52;
const MESSAGE_SIZE = 32;
const MESSAGE_LINE = 42;
const ITEM_SIZE = 38;
const ITEM_HEIGHT = 72;
const FOOTER_SIZE = 27;
const FOOTER_LINE = 38;

/** Break text into lines no wider than `width`, at spaces. */
function wrap(context: CanvasRenderingContext2D, text: string, width: number): string[] {
    const lines: string[] = [];
    let line = '';
    for (const word of text.split(/\s+/)) {
        const next = line ? `${line} ${word}` : word;
        if (line && context.measureText(next).width > width) {
            lines.push(line);
            line = word;
        } else {
            line = next;
        }
    }
    if (line) {
        lines.push(line);
    }
    return lines;
}

/** Shorten text to fit `width`, with an ellipsis where it was cut. */
function fit(context: CanvasRenderingContext2D, text: string, width: number): string {
    if (context.measureText(text).width <= width) {
        return text;
    }
    let cut = text;
    while (cut.length > 1 && context.measureText(`${cut}…`).width > width) {
        cut = cut.slice(0, -1);
    }
    return `${cut}…`;
}

/**
 * Draw a panel, with the cursor on the item at `cursor`. Opaque all over: a
 * headset's compositor blends a layer by its alpha, and a panel that let the
 * game show through it would be harder to read for no gain.
 */
export function drawXrPanel(canvas: HTMLCanvasElement, panel: XrPanel, cursor: number): XrPanelRow[] {
    const context = canvas.getContext('2d');
    if (!context) {
        return [];
    }
    const { width, height } = XR_PANEL_PIXELS;
    if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
    }
    context.fillStyle = COLORS.border;
    context.fillRect(0, 0, width, height);
    context.fillStyle = COLORS.background;
    context.fillRect(4, 4, width - 8, height - 8);
    context.textBaseline = 'middle';

    const inner = width - PADDING * 2;
    let y = PADDING + TITLE_SIZE / 2;
    context.font = `700 ${TITLE_SIZE}px ${FONT}`;
    context.fillStyle = COLORS.title;
    context.fillText(fit(context, panel.title, inner), PADDING, y);
    y += TITLE_SIZE / 2 + 28;

    if (panel.message?.length) {
        context.font = `400 ${MESSAGE_SIZE}px ${FONT}`;
        context.fillStyle = COLORS.text;
        for (const paragraph of panel.message) {
            for (const line of wrap(context, paragraph, inner)) {
                context.fillText(line, PADDING, y + MESSAGE_LINE / 2);
                y += MESSAGE_LINE;
            }
            y += MESSAGE_LINE / 3;
        }
        y += 12;
    }

    // The footer first, from the bottom up, so the list knows where to stop.
    let bottom = height - PADDING;
    if (panel.footer?.length) {
        context.font = `400 ${FOOTER_SIZE}px ${FONT}`;
        context.fillStyle = COLORS.dim;
        const lines = panel.footer.map(line => fit(context, line, inner));
        bottom -= lines.length * FOOTER_LINE;
        lines.forEach((line, index) => context.fillText(line, PADDING, bottom + index * FOOTER_LINE + FOOTER_LINE / 2));
        if (panel.footerTitle) {
            bottom -= FOOTER_LINE;
            context.font = `600 ${FOOTER_SIZE}px ${FONT}`;
            context.fillStyle = COLORS.text;
            context.fillText(fit(context, panel.footerTitle, inner), PADDING, bottom + FOOTER_LINE / 2);
        }
        context.fillStyle = COLORS.border;
        context.fillRect(PADDING, bottom - 18, inner, 2);
        bottom -= 30;
    }

    const items = panel.items();
    // Scrolled so the cursor stays in view, for a list longer than the panel.
    const room = Math.max(1, Math.floor((bottom - y) / ITEM_HEIGHT));
    const first = Math.max(0, Math.min(cursor - room + 1, items.length - room));
    const rows: XrPanelRow[] = [];
    for (let index = first; index < Math.min(items.length, first + room); index++) {
        const item = items[index];
        const top = y + (index - first) * ITEM_HEIGHT;
        rows.push({ index, top, bottom: top + ITEM_HEIGHT });
        const selected = index === cursor;
        if (selected) {
            context.fillStyle = COLORS.cursor;
            context.fillRect(PADDING - 20, top + 4, inner + 40, ITEM_HEIGHT - 8);
        }
        context.font = `${selected ? 700 : 500} ${ITEM_SIZE}px ${FONT}`;
        const color = item.disabled ? COLORS.disabled : selected ? COLORS.cursorText : COLORS.text;
        let detailWidth = 0;
        if (item.detail) {
            context.font = `400 ${ITEM_SIZE * 0.8}px ${FONT}`;
            detailWidth = context.measureText(item.detail).width + 24;
            context.fillStyle = selected ? COLORS.cursorText : COLORS.dim;
            context.textAlign = 'right';
            context.fillText(item.detail, PADDING + inner, top + ITEM_HEIGHT / 2);
            context.textAlign = 'left';
            context.font = `${selected ? 700 : 500} ${ITEM_SIZE}px ${FONT}`;
        }
        context.fillStyle = color;
        context.fillText(fit(context, item.label, inner - detailWidth), PADDING, top + ITEM_HEIGHT / 2);
    }
    return rows;
}

/** Where an item was drawn on a panel, for finding what a controller points at. */
export interface XrPanelRow {
    /** Its place among the panel's items. */
    index: number;
    /** Its top and bottom edge, in the canvas' pixels from the top. */
    top: number;
    bottom: number;
}

/** The pointer's dot, in pixels; see {@link drawXrPointer}. */
export const XR_POINTER_PIXELS = { width: 64, height: 64 };

/** The dot where a controller's ray meets a panel: light, ringed in dark, so it shows on either. */
export function drawXrPointer(canvas: HTMLCanvasElement): void {
    const context = canvas.getContext('2d');
    if (!context) {
        return;
    }
    const { width, height } = XR_POINTER_PIXELS;
    canvas.width = width;
    canvas.height = height;
    context.beginPath();
    context.arc(width / 2, height / 2, width / 2 - 6, 0, Math.PI * 2);
    context.fillStyle = COLORS.text;
    context.fill();
    context.lineWidth = 6;
    context.strokeStyle = COLORS.background;
    context.stroke();
}

/** Draw a line of news: a save written, an achievement earned, an error. */
export function drawXrToast(canvas: HTMLCanvasElement, text: string, error: boolean): void {
    const context = canvas.getContext('2d');
    if (!context) {
        return;
    }
    const { width, height } = XR_TOAST_PIXELS;
    if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
    }
    context.fillStyle = error ? COLORS.cursor : COLORS.border;
    context.fillRect(0, 0, width, height);
    context.fillStyle = COLORS.background;
    context.fillRect(4, 4, width - 8, height - 8);
    context.font = `500 ${MESSAGE_SIZE + 4}px ${FONT}`;
    context.fillStyle = error ? COLORS.error : COLORS.text;
    context.textBaseline = 'middle';
    context.textAlign = 'center';
    context.fillText(fit(context, text, width - PADDING * 2), width / 2, height / 2);
    context.textAlign = 'left';
}

/**
 * Where the cursor goes from `cursor` by `step`, past disabled items, staying
 * put at either end rather than wrapping: with a stick, overshooting the last
 * line by holding it too long should not land on the first.
 */
export function moveXrCursor(items: readonly XrPanelItem[], cursor: number, step: number): number {
    let next = cursor;
    for (let at = cursor + step; at >= 0 && at < items.length; at += step) {
        if (!items[at].disabled) {
            next = at;
            break;
        }
    }
    return next;
}

/** The first item that can be chosen, for where the cursor starts. */
export function firstXrItem(items: readonly XrPanelItem[]): number {
    const index = items.findIndex(item => !item.disabled);
    return index < 0 ? 0 : index;
}

// ------------------------------------------------------------------ Around the screen

/**
 * One pill over the screen: a state the machine is in, or something running
 * on it. Words rather than the page's icons, which a 2D canvas cannot draw.
 */
export interface XrBadge {
    text: string;
    /** Something being recorded or taken, drawn in red as the page draws it. */
    live?: boolean;
}

/** One reading in the strip beneath the screen, as the page's status bar has it. */
export interface XrStatusItem {
    label: string;
    value: string;
    tone?: 'ok' | 'off';
}

/**
 * What the page shows around the picture, for the headset to show around the
 * screen: the badges over it, the status bar under it.
 */
export interface XrHud {
    /** What the machine is doing — paused, muted, fast-forwarding — at the left. */
    states: XrBadge[];
    /** What is running on it — cheats, patches, a recording — at the right. */
    activities: XrBadge[];
    status: XrStatusItem[];
}

/** The badge row's canvas, in pixels; its width in the room is the screen's. */
export const XR_BADGES_PIXELS = { width: 1536, height: 72 };
/** The status strip's canvas, in pixels; likewise. */
export const XR_STATUS_PIXELS = { width: 1536, height: 60 };

const BADGE_SIZE = 32;
const BADGE_HEIGHT = 56;
const BADGE_GAP = 12;
const BADGE_PADDING = 22;
const STATUS_SIZE = 30;
const STATUS_GAP = 44;

function roundRect(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number): void {
    const radius = height / 2;
    context.beginPath();
    context.moveTo(x + radius, y);
    context.lineTo(x + width - radius, y);
    context.arc(x + width - radius, y + radius, radius, -Math.PI / 2, Math.PI / 2);
    context.lineTo(x + radius, y + height);
    context.arc(x + radius, y + radius, radius, Math.PI / 2, Math.PI * 1.5);
    context.closePath();
}

/**
 * Draw the badges over the screen: states from the left, activities from the
 * right. Transparent between them, unlike everything else drawn here — the
 * pills stand over the room the way they stand over the page's picture.
 */
export function drawXrBadges(canvas: HTMLCanvasElement, hud: XrHud): void {
    const context = canvas.getContext('2d');
    if (!context) {
        return;
    }
    const { width, height } = XR_BADGES_PIXELS;
    if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
    } else {
        context.clearRect(0, 0, width, height);
    }
    context.font = `600 ${BADGE_SIZE}px ${FONT}`;
    context.textBaseline = 'middle';
    const top = (height - BADGE_HEIGHT) / 2;
    const pill = (badge: XrBadge, x: number, pillWidth: number) => {
        roundRect(context, x, top, pillWidth, BADGE_HEIGHT);
        context.fillStyle = badge.live ? COLORS.cursor : COLORS.background;
        context.fill();
        context.lineWidth = 2;
        context.strokeStyle = badge.live ? COLORS.cursor : COLORS.border;
        context.stroke();
        context.fillStyle = COLORS.text;
        context.fillText(badge.text, x + BADGE_PADDING, height / 2);
    };
    let left = 2;
    for (const badge of hud.states) {
        const pillWidth = context.measureText(badge.text).width + BADGE_PADDING * 2;
        pill(badge, left, pillWidth);
        left += pillWidth + BADGE_GAP;
    }
    let right = width - 2;
    for (const badge of hud.activities) {
        const pillWidth = context.measureText(badge.text).width + BADGE_PADDING * 2;
        right -= pillWidth;
        pill(badge, right, pillWidth);
        right -= BADGE_GAP;
    }
}

/** Draw the status strip beneath the screen: each reading's name, dimmer, then its value. */
export function drawXrStatus(canvas: HTMLCanvasElement, hud: XrHud): void {
    const context = canvas.getContext('2d');
    if (!context) {
        return;
    }
    const { width, height } = XR_STATUS_PIXELS;
    if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
    }
    context.fillStyle = COLORS.background;
    context.fillRect(0, 0, width, height);
    context.textBaseline = 'middle';
    let x = 24;
    for (const item of hud.status) {
        context.font = `400 ${STATUS_SIZE}px ${FONT}`;
        context.fillStyle = COLORS.dim;
        context.fillText(item.label, x, height / 2);
        x += context.measureText(item.label).width + 12;
        context.font = `600 ${STATUS_SIZE}px ${FONT}`;
        context.fillStyle = item.tone === 'ok' ? '#4cd964' : item.tone === 'off' ? COLORS.disabled : COLORS.text;
        context.fillText(item.value, x, height / 2);
        x += context.measureText(item.value).width + STATUS_GAP;
        if (x > width) {
            break;
        }
    }
}
