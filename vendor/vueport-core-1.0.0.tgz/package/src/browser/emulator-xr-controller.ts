/**
 * Playing in a headset, as a host offers it: whether there is one, the button
 * that starts a session, the menu and the readings around the screen in it,
 * and what is kept between sessions.
 *
 * `EmulatorXrSession` is the session itself and knows nothing of the host; this
 * is what both hosts — the standalone build and the studio — would otherwise
 * each write around it, in the same words.
 */

import { nls } from '../common/emulator-nls';
import { formatVesMovieLength } from '../common/emulator-movie';
import { DisplayMode } from '../common/vb-constants';
import { Core, Sim } from './core/vb-core';
import { EmulatorInputController } from './emulator-input';
import { MacroActivity } from './emulator-macro-store';
import {
    EmulatorStatusSource,
    formatEmulationSpeed,
    formatEsSound,
    formatHardwareMode,
    formatRumblePack,
    STATUS_NONE,
} from './emulator-status';
import { EmulatorAction } from './emulator-types';
import {
    clampXrScreen,
    EmulatorXrSession,
    XrAvailability,
    XrBackdrop,
    XrDiagnostics,
    XrScreen,
    xrStereoDepth,
} from './emulator-xr';
import { XrBadge, XrHud, XrPanel, XrStatusItem } from './emulator-xr-panel';
import {
    loadXrBackdrop,
    loadXrScreen,
    nextXrBackdrop,
    saveXrBackdrop,
    saveXrScreen,
    xrBackdropLabel,
} from './emulator-xr-storage';

/** What the headset can show in place of the host's own notices and questions. */
export interface XrHeadsetUi {
    toast(text: string, error: boolean): void;
    ask(title: string, message: string[], yes: string, no: string): Promise<boolean>;
}

/** What the readings around the screen are read from — the host's own badges and status bar. */
export interface XrHudSource extends EmulatorStatusSource {
    readonly state: {
        readonly loaded: boolean;
        readonly paused: boolean;
        readonly frameAdvance: boolean;
        readonly fastForward: boolean;
        readonly slowmotion: boolean;
        readonly muted: boolean;
        readonly lowPower: boolean;
    };
    readonly settings: { get(key: 'fastForwardRatio' | 'slowMotionRatio'): unknown };
    readonly rewinding: boolean;
    readonly activeCheats: number;
    readonly activePatches: number;
    readonly macroActivity: MacroActivity;
    readonly profiling: boolean;
    readonly moviePlaying: boolean;
    readonly movieFrame: number;
    readonly movieLength: number;
    readonly recordingVideo: boolean;
    recordedSeconds(): number;
    readonly saveGameSlot: string;
}

/** What the controller needs from the host it is part of. */
export interface XrControllerHost {
    sim(): Sim | undefined;
    core(): Core | undefined;
    input(): EmulatorInputController;
    displayMode(): DisplayMode;
    /** The badges and readings to show around the screen. */
    hudSource(): XrHudSource;
    /** What the menu is headed with: the game's name. */
    romTitle(): string;
    runAction(action: EmulatorAction): void;
    /** Whether Load Latest State has anything to load, and may. */
    canLoadState(): boolean;
    /**
     * The machine's 3D depth has changed — on the way in or out, or adjusted
     * in the headset. The host's to apply, through {@link EmulatorXrController.stereoDepth}.
     */
    applyStereoDepth(): Promise<void>;
    /** Draw again: the button, the settings pane. */
    update(): void;
    notifyError(message: string): void;
    /** The headset is showing, or no longer: where notices and questions should go. */
    setHeadset?(headset: XrHeadsetUi | undefined): void;
    /** False to draw into the eye buffers even where a quad layer is on offer; see `EmulatorXrHost.quadLayers`. */
    quadLayers?: boolean;
    /** Report each session's diagnostics to the console when it ends. */
    debug?: boolean;
}

export class EmulatorXrController {

    protected session: EmulatorXrSession | undefined;
    protected starting = false;
    /** Whether the headset's menu paused the game, which it then does not report as news. */
    protected menuPaused = false;
    protected disposed = false;
    protected readonly deviceChange: { dispose(): void };

    /** What the browser said it can do with a headset, once it has. */
    availability: XrAvailability | undefined;
    /** And whether that headset can show the room it is in — passthrough. */
    passthroughSupported = false;
    /** How the screen is shown in a headset, as it was last adjusted there. */
    screen: XrScreen = loadXrScreen();
    /**
     * What is wanted around the screen: a room of its own, the player's, or
     * the player's through the screen as well.
     */
    backdrop: XrBackdrop = loadXrBackdrop();

    constructor(protected readonly host: XrControllerHost) {
        // The button is drawn only where there is a headset to start a
        // session in. Asked again whenever one comes or goes: a PC's arrives
        // when Link or Virtual Desktop connects, often after this.
        this.check();
        this.deviceChange = EmulatorXrSession.onDeviceChange(() => this.check());
    }

    dispose(): void {
        this.disposed = true;
        this.deviceChange.dispose();
        this.session?.end().catch(() => undefined);
    }

    /** Whether there is a headset to play in. */
    get supported(): boolean {
        return this.availability === 'headset';
    }

    /** Whether the game is being played in one. */
    get active(): boolean {
        return this.session !== undefined;
    }

    /** The 3D depth the machine should be drawn at: the headset's own while in one. */
    stereoDepth(page: number): number {
        return this.session ? xrStereoDepth(this.screen) : page;
    }

    protected check(): void {
        EmulatorXrSession.availability().then(availability => {
            this.availability = availability;
            if (!this.disposed) {
                this.host.update();
            }
        }).catch(() => undefined);
        EmulatorXrSession.isSupported('ar').then(supported => {
            this.passthroughSupported = supported;
        }).catch(() => undefined);
    }

    /**
     * Put the running game in a headset, or take it out again.
     *
     * Called straight from a click: a browser grants a headset only to a
     * gesture, and `EmulatorXrSession.start` asks for it before anything else.
     */
    async toggle(): Promise<void> {
        if (this.session) {
            await this.session.end();
        } else {
            await this.enter();
        }
    }

    async end(): Promise<void> {
        await this.session?.end();
    }

    /**
     * Start a session, with or without a game in it yet. Without one is how a
     * game is started straight into the headset: the session shows the
     * machine as soon as {@link setSim} hands it one.
     */
    async enter(): Promise<void> {
        if (this.session || this.starting || !this.supported) {
            return;
        }
        this.starting = true;
        try {
            const session = await EmulatorXrSession.start({
                // Wherever the headset can show the room, so that passthrough
                // can go on and off in the session rather than by asking for
                // another one, which only a gesture on the page can.
                mode: this.passthroughSupported ? 'ar' : 'vr',
                backdrop: this.backdrop,
                sim: this.host.sim(),
                input: this.host.input(),
                displayMode: () => this.host.displayMode(),
                resumeAudio: () => this.host.core()?.resumeAudio(),
                quadLayers: this.host.quadLayers,
                view: this.screen,
                quickMenu: () => this.quickMenu(),
                hud: () => this.hud(),
                onXrViewChanged: screen => {
                    this.screen = screen;
                    saveXrScreen(screen);
                    this.host.applyStereoDepth().catch(() => undefined);
                },
                onXrEnded: diagnostics => this.ended(diagnostics),
            });
            // A headset taken off in the moment it took to start has ended
            // the session already.
            this.session = session.running ? session : undefined;
            if (this.session) {
                const headset = this.session;
                this.host.setHeadset?.({
                    toast: (text, error) => headset.toast(text, error),
                    ask: (title, message, yes, no) => headset.ask(title, message, yes, no),
                });
            }
            await this.host.applyStereoDepth();
            // The game may have started while the session was being set up.
            await this.session?.setSim(this.host.sim());
            if (this.session) {
                this.watchAudioClock();
            }
        } catch (error) {
            this.host.notifyError(nls.localize(
                'vueport/xr/failed', 'Could not start the headset: {0}',
                error instanceof Error ? error.message : String(error)));
        } finally {
            this.starting = false;
            this.host.update();
        }
    }

    protected ended(diagnostics: XrDiagnostics): void {
        this.session = undefined;
        this.host.setHeadset?.(undefined);
        this.watchAudioClock();
        // Back to the depth the page is played at.
        this.host.applyStereoDepth().catch(() => undefined);
        // How it went, for whoever is looking into a headset that
        // misbehaves: frames drawn, the layer path, errors.
        if (this.host.debug) {
            console.info('[vueport] headset session', diagnostics);
        }
        this.host.update();
    }

    /**
     * The machine to show, or none while one is being built again — a patch,
     * a hardware change, a new build. The headset stays through that.
     */
    async setSim(sim: Sim | undefined): Promise<void> {
        await this.session?.setSim(sim);
    }

    setDisplayMode(mode: DisplayMode): void {
        this.session?.setDisplayMode(mode);
    }

    /**
     * The headset's screen size and depth, set from the settings pane. A
     * session under way — a tethered headset, with the page still in view —
     * takes them at once.
     */
    setScreen(screen: XrScreen): void {
        this.screen = clampXrScreen(screen);
        saveXrScreen(this.screen);
        this.session?.setView(this.screen);
        this.host.applyStereoDepth().catch(() => undefined);
        this.host.update();
    }

    /** What is around the headset's screen, set from the settings pane. */
    setBackdrop(backdrop: XrBackdrop): void {
        this.backdrop = backdrop;
        saveXrBackdrop(backdrop);
        this.session?.setBackdrop(backdrop);
        this.host.update();
    }

    /**
     * Get the machine going again if the audio that clocks it stopped with
     * the move into the headset or out of it — see `Core.restartStalledAudio`.
     *
     * Checked twice, because the headset takes the audio device over a moment
     * after the session has started rather than as it starts. Without this a
     * game started on the page and taken into the headset afterwards — after
     * a patch rebuilt it, say — showed its first, black frame until it was
     * paused and resumed by hand.
     */
    protected watchAudioClock(): void {
        const core = this.host.core();
        const check = (): void => {
            if (this.host.core() === core && !this.disposed) {
                core?.restartStalledAudio().catch(() => undefined);
            }
        };
        check();
        setTimeout(check, EmulatorXrController.AUDIO_CLOCK_RECHECK_MS);
    }

    /** How long after a headset comes or goes to look at the audio clock again. */
    protected static readonly AUDIO_CLOCK_RECHECK_MS = 2500;

    /**
     * The menu a stick click opens in the headset: what is worth doing
     * without taking it off. The game waits while it is up, and carries on
     * when it goes — unless it was already paused, which it then stays.
     */
    protected quickMenu(): XrPanel | undefined {
        const session = this.session;
        const state = this.host.hudSource().state;
        if (!session || !state.loaded) {
            return undefined;
        }
        const pausedHere = !state.paused;
        if (pausedHere) {
            this.host.runAction(EmulatorAction.PauseToggle);
        }
        this.menuPaused = pausedHere;
        // Kept here rather than read back: the switch lands a moment after
        // it is pressed, and the menu is redrawn at once.
        let muted = state.muted;
        return {
            title: this.host.romTitle(),
            items: () => [
                {
                    label: nls.localize('vueport/xr/menu/continue', 'Continue'),
                    run: () => undefined,
                },
                {
                    label: nls.localize('vueport/xr/menu/saveState', 'Save State'),
                    run: () => this.host.runAction(EmulatorAction.SaveState),
                },
                {
                    label: nls.localize('vueport/xr/menu/loadState', 'Load Latest State'),
                    disabled: !this.host.canLoadState(),
                    run: () => this.host.runAction(EmulatorAction.LoadState),
                },
                {
                    label: nls.localize('vueport/xr/menu/reset', 'Reset Game'),
                    run: () => this.host.runAction(EmulatorAction.Reset),
                },
                {
                    label: nls.localize('vueport/xr/menu/sound', 'Sound'),
                    detail: muted
                        ? nls.localize('vueport/xr/menu/off', 'Off')
                        : nls.localize('vueport/xr/menu/on', 'On'),
                    run: () => {
                        muted = !muted;
                        this.host.runAction(EmulatorAction.AudioMute);
                        return 'keep';
                    },
                },
                ...session.mode === 'ar' ? [{
                    label: nls.localize('vueport/xr/menu/backdrop/title', 'Backdrop'),
                    detail: xrBackdropLabel(session.backdrop),
                    run: () => {
                        this.backdrop = nextXrBackdrop(session.backdrop);
                        session.setBackdrop(this.backdrop);
                        saveXrBackdrop(this.backdrop);
                        return 'keep' as const;
                    },
                }] : [],
                {
                    label: nls.localize('vueport/xr/menu/resetScreen', 'Reset Screen Size and Depth'),
                    run: () => { session.resetScreen(); return 'keep'; },
                },
                {
                    label: nls.localize('vueport/xr/menu/leave', 'Leave VR'),
                    run: () => { session.end().catch(() => undefined); },
                },
            ],
            footerTitle: nls.localize('vueport/xr/menu/hintTitle', 'While playing:'),
            footer: [
                nls.localize('vueport/xr/menu/hintSize', 'Grip + left stick: screen size · click: reset'),
                nls.localize('vueport/xr/menu/hintDepth', 'Grip + right stick: 3D depth · click: reset'),
                nls.localize('vueport/xr/menu/hintLeave', 'Both grips for a second: leave VR'),
            ],
            onClose: () => {
                this.menuPaused = false;
                // Not if the game has gone, or somebody has paused it since.
                const now = this.host.hudSource().state;
                if (pausedHere && now.loaded && now.paused && this.session) {
                    this.host.runAction(EmulatorAction.PauseToggle);
                }
            },
        };
    }

    /**
     * What goes around the screen in the headset: the badges the host puts
     * over its picture, and its status bar's readings — the same ones, in the
     * same words, as far as words can stand in for icons.
     */
    protected hud(): XrHud | undefined {
        const source = this.host.hudSource();
        const state = source.state;
        if (!state.loaded) {
            return undefined;
        }
        const states: XrBadge[] = [];
        if (source.rewinding) {
            states.push({ text: nls.localize('vueport/state/rewinding', 'Rewinding') });
        }
        // Not the pause the menu itself is holding: that one goes with it.
        if (state.paused && !this.menuPaused) {
            states.push({ text: nls.localize('vueport/state/paused', 'Paused') });
        }
        if (state.frameAdvance) {
            states.push({ text: nls.localize('vueport/state/frameAdvance', 'Frame advance') });
        }
        if (state.fastForward) {
            states.push({
                text: `${nls.localize('vueport/state/fastForward', 'Fast-forward')} ×${source.settings.get('fastForwardRatio')}`,
            });
        }
        if (state.slowmotion) {
            states.push({
                text: `${nls.localize('vueport/state/slowMotion', 'Slow motion')} ×${source.settings.get('slowMotionRatio')}`,
            });
        }
        if (state.muted) {
            states.push({ text: nls.localize('vueport/state/muted', 'Muted') });
        }
        if (state.lowPower) {
            states.push({ text: nls.localize('vueport/state/lowPower', 'Low power') });
        }

        const activities: XrBadge[] = [];
        if (source.activeCheats > 0) {
            activities.push({ text: nls.localize('vueport/xr/hud/cheats', 'Cheats {0}', source.activeCheats) });
        }
        if (source.activePatches > 0) {
            activities.push({ text: nls.localize('vueport/xr/hud/patches', 'Patches {0}', source.activePatches) });
        }
        if (source.macroActivity === MacroActivity.RECORDING) {
            activities.push({ text: nls.localize('vueport/macros/rec', 'REC'), live: true });
        } else if (source.macroActivity !== MacroActivity.IDLE) {
            activities.push({ text: nls.localize('vueport/macros/playing', 'Macro') });
        }
        if (source.profiling) {
            activities.push({ text: nls.localize('vueport/debug/panels/profiler/profile/prof', 'PROF'), live: true });
        }
        if (source.moviePlaying) {
            activities.push({
                text: `${formatVesMovieLength(source.movieFrame)} / ${formatVesMovieLength(source.movieLength)}`,
            });
        }
        if (source.recordingVideo) {
            activities.push({
                text: `${nls.localize('vueport/xr/hud/video', 'Video')} ${formatDuration(source.recordedSeconds())}`,
                live: true,
            });
        }

        const status: XrStatusItem[] = [
            { label: nls.localize('vueport/status/speed', 'Speed'), value: formatEmulationSpeed(source) },
            {
                label: nls.localize('vueport/status/hardware', 'Hardware'),
                value: formatHardwareMode(source),
                tone: source.vbcHardwareActive ? 'ok' as const : undefined,
            },
            { label: nls.localize('vueport/status/saveSlot', 'Save Slot'), value: source.saveGameSlot },
            // The headset's own depth, which is the one in force there.
            { label: nls.localize('vueport/preferences/stereoDepth/title', '3D Depth'), value: `${this.screen.depth} %` },
            { label: nls.localize('vueport/status/rumblePack', 'Rumble Pack'), value: formatRumblePack(source) },
            { label: nls.localize('vueport/status/esSound', 'ESSound'), value: formatEsSound(source) },
        ].filter(item => item.value !== STATUS_NONE);
        return { states, activities, status };
    }
}

/** `1:07` — how long a recording has run. */
function formatDuration(seconds: number): string {
    const whole = Math.round(seconds);
    return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
}
