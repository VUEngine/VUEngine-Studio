import { ArrowRight, Eye, Lock, MagnifyingGlass, PencilSimple, Plus, Star, StarHalf, Trash, X } from '@phosphor-icons/react';
import * as React from 'react';
import {
    CHEAT_DEFAULT_DIGITS,
    CHEAT_DIGITS,
    parseVesCheatCode,
    parseVesCheatFile,
    Cheat,
    CheatCode,
    vesCheatMaxValue
} from '../../common/emulator-cheats';
import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';
import { CheatFinder } from '../emulator-cheat-finder';
import { CheatStore } from '../emulator-cheat-store';
import EmulatorCheatFinder from './EmulatorCheatFinder';
import EmptyContainer from './kit/EmptyContainer';
import {
    PanelDetailBadge,
    PanelDetailFooter,
    PanelDetailHero,
    PanelDetailSection,
    PanelDetailToolbar,
} from './kit/PanelDetail';
import RadioSelect from './kit/RadioSelect';
import Switch from './kit/Switch';
import styled from 'styled-components';

const StyledCloseButton = styled.button`
    position: relative;
    z-index: 10;
`;

/** What a new cheat, and a new code, start out as. */
const NEW_CHEAT_ADDRESS = 0x05000000;

/**
 * The cheats kept beside the ROM: named sets of writes the core repeats every
 * frame, which is what holds a value against a game that keeps changing it.
 *
 * The list on top is every cheat in the file, with the selected one's name,
 * switch and codes editable below it. Everything here edits the store, which
 * owns the list, writes the file and pushes the enabled writes into the core —
 * so a cheat stays on with this closed, and this is only a view of it. That is
 * also why nothing is polled: the store says when to redraw.
 *
 * A component rather than a panel, because it is shown in two places and only
 * one of them is a panel. In Debug mode it is docked like every other
 * inspector; while playing it sits beside the screen with no dock involved at
 * all, since somebody reaching for a cheat mid-game should not have to think
 * about panels, tabs or layouts.
 */
export default function EmulatorCheats(props: {
    cheats: CheatStore,
    /** The memory search behind the Find button — see `EmulatorCheatFinder`. */
    finder: CheatFinder,
    notifications: VueportNotifications,
    /**
     * Put these away, when there is somewhere to put them away to.
     *
     * Given for the strip beside the screen, which has no chrome of its own to
     * close it by. The docked panel leaves this out: it has a tab, and a
     * second way to close it sitting inside would be one too many.
     */
    onClose?: () => void,
    /**
     * Whose machine the debugger is currently pointed at, while a link
     * session is running.
     *
     * Only for the note below. The switches here always belong to this
     * window's own player, whichever machine the inspectors are showing — see
     * `peerNote` — and the note is what keeps that from being a surprise.
     */
    inspecting?: 'own' | 'peer',
}): React.JSX.Element {
    const { cheats, finder, notifications, onClose, inspecting } = props;

    /**
     * Said when the inspectors are on the other player's machine.
     *
     * The Find button beside these switches searches whichever machine the
     * debugger is pointed at, and these switches do not: a cheat belongs to
     * the player who switched it on, and reaches the other window as a change
     * to *their* mirror of this machine rather than to the machine they are
     * playing. Two halves of one panel behaving differently is exactly the
     * sort of thing that has to be said out loud rather than discovered.
     */
    const peerNote = inspecting === 'peer' && <div className='vp-panel-note'>
        {nls.localize(
            'vueport/cheats/ownMachineOnly',
            'These switches apply to your own machine. The search below follows the'
            + " debugger, which is on the other player's.",
        )}
    </div>;

    /** The X at the end of the toolbar row, when there is one to draw. */
    const closeButton = onClose && <StyledCloseButton
        type='button'
        className='vp-panel-close'
        aria-label={nls.localize('vueport/cheats/closeCheats', 'Close Cheats')}
        onClick={onClose}
    >
        <X size={20} />
    </StyledCloseButton>;
    /**
     * Which cheat is being edited, if one is.
     *
     * The editor takes the whole panel rather than sitting under the list:
     * everything about a cheat is typed in — its name, its addresses, its
     * values — and a form squeezed under a list is a form with no room in it.
     * The list is what you come back to.
     */
    const [editing, setEditing] = React.useState<number | undefined>(undefined);
    /**
     * Whether the memory search has the panel.
     *
     * A third full-panel view alongside the editor, for the same reason: a
     * search is a form with a table under it and has no room under the list.
     * What it is *for* is adding to that list, so it belongs here rather than
     * in a panel of its own — and being here is what makes it reachable while
     * playing, not only in Debug mode.
     */
    const [finding, setFinding] = React.useState(false);
    /** Narrows the list by name; the panel keeps every other bit of state. */
    const [filter, setFilter] = React.useState('');
    const importInput = React.useRef<HTMLInputElement>(null);
    /** Ties the editor's titles to its fields, unique per copy of the panel. */
    const fieldId = React.useId();
    const [, setVersion] = React.useState(0);
    const redraw = React.useCallback(() => setVersion(version => version + 1), []);

    // The store owns the list and says when it changed — a cheat can be turned
    // on from the other copy of this, or the file reloaded with a new ROM.
    React.useEffect(() => {
        const subscription = cheats.onDidChange(redraw);
        return () => subscription.dispose();
    }, [cheats, redraw]);

    const list = cheats.list;
    // Index rather than identity, because that is how the store is addressed —
    // and why removing one closes the editor rather than moving it along.
    const selected = editing ?? 0;
    const cheat = list[selected];

    // A cheat is made of things that have to be typed in, so a new one opens
    // where they can be: nobody adds a cheat in order to look at "New cheat".
    const addCheat = (): void =>
        setEditing(cheats.add(nls.localize('vueport/cheats/newCheat', 'New cheat')));

    /**
     * Read a `.cht` file the player picked and add its cheats to the list.
     *
     * They arrive off, whatever the file said — an import should not switch
     * writes on by itself — and the picker is reset so choosing the same file
     * twice fires again.
     */
    const importFrom = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (importInput.current) {
            importInput.current.value = '';
        }
        if (!file) {
            return;
        }
        let added: number;
        try {
            added = cheats.importCheats(parseVesCheatFile(await file.text()));
        } catch {
            notifications.error(nls.localize('vueport/cheats/importFailed',
                '{0} could not be read as a cheat file.', file.name));
            return;
        }
        if (added === 0) {
            notifications.warn(nls.localize('vueport/cheats/importedNone',
                'No cheats were found in {0}.', file.name));
            return;
        }
        notifications.info(added === 1
            ? nls.localize('vueport/cheats/importedOne', 'Imported 1 cheat from {0}.', file.name)
            : nls.localize('vueport/cheats/importedMany',
                'Imported {0} cheats from {1}.', String(added), file.name));
    };

    /** Add, Find and Import, the row the list and the empty state both end with. */
    const actions = <div className='vp-panel-actions'>
        <button className='vp-button secondary' onClick={addCheat}>
            <Plus size={16} />
            {nls.localize('vueport/cheats/addCheat', 'Add Cheat')}
        </button>
        {/* The way in for somebody who has no address to type: search for one.
            Beside Add rather than inside the editor, because it is how a cheat
            is arrived at, not something done to a cheat that exists. */}
        <button className='vp-button secondary' onClick={() => setFinding(true)}>
            <MagnifyingGlass size={16} />
            {nls.localize('vueport/cheats/find', 'Find…')}
        </button>
        <button className='vp-button secondary' onClick={() => importInput.current?.click()}>
            {nls.localize('vueport/cheats/import', 'Import…')}
        </button>
        <input
            ref={importInput}
            type='file'
            accept='.cht,text/plain'
            hidden
            onChange={event => importFrom(event.target.files)}
        />
    </div>;

    /**
     * "Cheats", a count of what is on, and the way out when there is one.
     *
     * The title is for the strip beside the screen, which has no tab naming it;
     * the docked panel has one, so there it is just the count.
     */
    const header = <div className='vp-panel-heading'>
        {onClose &&
            <span className='vp-panel-heading-title'>
                <Star size={22} />
                {nls.localize('vueport/cheats/title', 'Cheats')}
            </span>}
        {closeButton}
    </div>;

    /**
     * Delete a cheat, once the user has confirmed it.
     *
     * Worth asking about: the row's only handle is a small button beside a
     * checkbox people click often, and a cheat is typed in by hand — a
     * misclick would throw away work with nothing to undo it, and removing the
     * last one takes the file with it.
     */
    const removeCheat = async (index: number): Promise<void> => {
        const doomed = cheats.list[index];
        // A shipped cheat is not the player's to delete. The button is not
        // offered for one either; this is the guard behind that.
        if (!doomed || doomed.builtIn) {
            return;
        }
        // Hoisted out of the message's arguments rather than nested in them:
        // the extractor stops descending once it has matched a localize call,
        // so a nested one is never seen and its key never reaches nls.json.
        const unnamed = nls.localize('vueport/cheats/thisCheat', 'this cheat');
        const confirmed = await notifications.confirm({
            title: nls.localize('vueport/cheats/deleteCheatQuestion', 'Delete Cheat?'),
            message: nls.localize(
                'vueport/cheats/areYouSureYouWantToDelete',
                'Are you sure you want to delete {0}?',
                doomed.description || unnamed,
            ),
        });
        if (confirmed) {
            cheats.remove(index);
            // Back to the list: the thing being edited is gone, and every
            // index after it now means a different cheat.
            setEditing(undefined);
        }
    };

    /** Replace one of a cheat's codes, or drop it when `code` is undefined. */
    const setCode = (owner: Cheat, index: number, code: CheatCode | undefined): void => {
        const codes = [...owner.codes];
        if (code) {
            codes[index] = code;
        } else {
            codes.splice(index, 1);
        }
        cheats.update(selected, { codes });
    };

    const addCode = (owner: Cheat): void => {
        cheats.update(selected, {
            codes: [
                ...owner.codes,
                { address: NEW_CHEAT_ADDRESS, value: 0, digits: CHEAT_DEFAULT_DIGITS },
            ],
        });
    };

    /**
     * One code or several — space, comma and the file format's own `+` all
     * count as a break between them, so a line copied from a published cheat
     * list, or a whole block of them, pastes in one go.
     */
    const parsePastedCodes = (text: string): CheatCode[] =>
        text.split(/[\s,+]+/)
            .map(parseVesCheatCode)
            .filter((parsed): parsed is CheatCode => parsed !== undefined);

    /**
     * What's in the paste box, so Add Code can pick it up without the player
     * having to press Enter first.
     */
    const pasteRef = React.useRef<HTMLInputElement>(null);

    /**
     * Add Code: whatever is waiting in the paste box, when there is
     * something, otherwise the usual blank row — one press does the thing the
     * player was already reaching for.
     */
    const addCodeOrPasted = (owner: Cheat): void => {
        const box = pasteRef.current;
        const pastedCodes = box ? parsePastedCodes(box.value) : [];
        if (pastedCodes.length > 0) {
            cheats.update(selected, { codes: [...owner.codes, ...pastedCodes] });
            box!.value = '';
            return;
        }
        addCode(owner);
    };

    const hexPlaceholder = (code: CheatCode): string =>
        (code.value >>> 0).toString(16).toUpperCase().padStart(code.digits, '0');

    /**
     * The hex field re-pads to its width on every commit — a leading zero can
     * appear or disappear as the value changes — which would otherwise jump
     * the cursor to the end on every keystroke. So while a hex field has
     * focus it shows exactly what was typed, unformatted, and only pads and
     * commits on blur (or Enter, which just blurs into the same handler).
     */
    const [hexDraft, setHexDraft] = React.useState<{ index: number, text: string } | undefined>(undefined);

    const commitHexDraft = (owner: Cheat, index: number, code: CheatCode): void => {
        if (hexDraft?.index !== index) {
            return;
        }
        const value = parseInt(hexDraft.text, 16);
        if (!Number.isNaN(value)) {
            setCode(owner, index, { ...code, value: Math.min(vesCheatMaxValue(code.digits), value >>> 0) });
        }
        setHexDraft(undefined);
    };

    const addressPlaceholder = (code: CheatCode): string =>
        (code.address >>> 0).toString(16).toUpperCase();

    /**
     * The same trouble as the hex field above, and the same fix: `>>> 0` drops
     * leading zeroes as the address changes, which would otherwise jump the
     * cursor to the end on every keystroke. Raw while focused, parsed and
     * committed on blur (or Enter, which just blurs into the same handler).
     */
    const [addressDraft, setAddressDraft] = React.useState<{ index: number, text: string } | undefined>(undefined);

    const commitAddressDraft = (owner: Cheat, index: number, code: CheatCode): void => {
        if (addressDraft?.index !== index) {
            return;
        }
        const address = parseInt(addressDraft.text, 16);
        if (!Number.isNaN(address)) {
            setCode(owner, index, { ...code, address: address >>> 0 });
        }
        setAddressDraft(undefined);
    };

    /**
     * One entry per write: where it goes and what it writes on one line, how
     * wide the write is under it. Hex and decimal sit side by side rather than
     * taking turns behind a switch — both are just the same `code.value`, so
     * editing either one writes straight through and the other catches up on
     * the next render. The width is a row of its own because three choices
     * read faster as three buttons than as a dropdown, and there is no room
     * for them beside four fields in the strip beside the screen.
     */
    const renderCodes = (owner: Cheat): React.ReactNode =>
        <div className='vp-detail-card vp-cheats-codes'>
            {owner.codes.length > 0 &&
                <div className='vp-cheats-code vp-cheats-code-header' aria-hidden='true'>
                    <span>{nls.localize('vueport/cheats/address', 'Address')}</span>
                    <span />
                    <span>{nls.localize('vueport/cheats/hex', 'Hex')}</span>
                    <span>{nls.localize('vueport/cheats/decimal', 'Decimal')}</span>
                    <span />
                </div>}
            {owner.codes.map((code, index) => (
                <div className='vp-cheats-code-entry' key={index}>
                    <div className='vp-cheats-code'>
                        {/* The 0x is drawn over the field rather than typed
                            into it, so the field holds only the digits that
                            parse. */}
                        <span className='vp-cheats-address'>
                            <span className='prefix' aria-hidden='true'>0x</span>
                            <input
                                className='vp-input address'
                                value={addressDraft?.index === index ? addressDraft.text : addressPlaceholder(code)}
                                spellCheck={false}
                                aria-label={nls.localize('vueport/cheats/addressHint', 'Address to write to, in hexadecimal')}
                                readOnly={owner.builtIn}
                                onFocus={() => setAddressDraft({ index, text: addressPlaceholder(code) })}
                                onChange={e => setAddressDraft({ index, text: e.target.value })}
                                onBlur={() => commitAddressDraft(owner, index, code)}
                                onKeyDown={e => {
                                    if (e.key === 'Enter') {
                                        e.currentTarget.blur();
                                    }
                                }}
                            />
                        </span>
                        <ArrowRight size={14} className='vp-cheats-arrow' aria-hidden='true' />
                        <input
                            className='vp-input hex'
                            value={hexDraft?.index === index ? hexDraft.text : hexPlaceholder(code)}
                            spellCheck={false}
                            aria-label={nls.localize('vueport/cheats/valueHint', 'Value to write, in hexadecimal')}
                            readOnly={owner.builtIn}
                            onFocus={() => setHexDraft({ index, text: hexPlaceholder(code) })}
                            onChange={e => setHexDraft({ index, text: e.target.value })}
                            onBlur={() => commitHexDraft(owner, index, code)}
                            onKeyDown={e => {
                                if (e.key === 'Enter') {
                                    e.currentTarget.blur();
                                }
                            }}
                        />
                        <input
                            className='vp-input decimal'
                            value={(code.value >>> 0).toString(10)}
                            spellCheck={false}
                            aria-label={nls.localize('vueport/cheats/valueDecimalHint', 'Value to write, in decimal')}
                            readOnly={owner.builtIn}
                            onChange={e => {
                                const value = parseInt(e.target.value, 10);
                                if (!Number.isNaN(value) && value >= 0) {
                                    setCode(owner, index, {
                                        ...code,
                                        value: Math.min(vesCheatMaxValue(code.digits), value >>> 0),
                                    });
                                }
                            }}
                        />
                        {owner.builtIn
                            ? <span />
                            : <button
                                type='button'
                                className='vp-cheats-remove'
                                aria-label={nls.localize('vueport/cheats/removeCode', 'Remove code')}
                                title={nls.localize('vueport/cheats/removeCode', 'Remove code')}
                                onClick={() => setCode(owner, index, undefined)}
                            >
                                <Trash size={14} />
                            </button>}
                    </div>
                    <div className='vp-cheats-width' title={nls.localize('vueport/cheats/widthHint', 'How wide the write is')}>
                        <span>{nls.localize('vueport/cheats/width', 'Width')}</span>
                        <RadioSelect
                            options={CHEAT_DIGITS.map(digits => ({ value: digits, label: `${digits * 4}` }))}
                            defaultValue={code.digits}
                            disabled={owner.builtIn}
                            onChange={([option]) => {
                                const digits = Number(option.value);
                                setCode(owner, index, {
                                    ...code,
                                    digits,
                                    value: Math.min(vesCheatMaxValue(digits), code.value),
                                });
                            }}
                        />
                        <span>bit</span>
                    </div>
                </div>
            ))}
            {!owner.builtIn && <div className='vp-cheats-code-add'>
                <input
                    ref={pasteRef}
                    className='vp-input paste'
                    placeholder={nls.localize('vueport/cheats/paste',
                        'Paste one or more codes, e.g. 50091A4:0001, 50091A6:0002')}
                    aria-label={nls.localize('vueport/cheats/paste',
                        'Paste one or more codes, e.g. 50091A4:0001, 50091A6:0002')}
                    spellCheck={false}
                    onKeyDown={e => {
                        if (e.key !== 'Enter') {
                            return;
                        }
                        const pastedCodes = parsePastedCodes(e.currentTarget.value);
                        if (pastedCodes.length > 0) {
                            cheats.update(selected, { codes: [...owner.codes, ...pastedCodes] });
                            e.currentTarget.value = '';
                        }
                    }}
                />
                <button className='vp-button secondary' onClick={() => addCodeOrPasted(owner)}>
                    <Plus size={16} />
                    {nls.localize('vueport/cheats/addCode', 'Add Code')}
                </button>
            </div>}
        </div>;

    const renderDetail = (owner: Cheat): React.ReactNode =>
        <div className='vp-detail-page'>
            <PanelDetailHero
                icon={<Star size={22} weight='fill' />}
                name={owner.description}
                // What a shipped cheat is called, and what it writes, are the
                // database's to say — so the view shows them but takes no edits.
                onRename={owner.builtIn ? undefined : description => cheats.update(selected, { description })}
                meta={owner.codes.length === 1
                    ? nls.localize('vueport/cheats/codeCountOne', '1 code')
                    : nls.localize('vueport/cheats/codeCountMany', '{0} codes', owner.codes.length)}
                badges={owner.builtIn && <PanelDetailBadge icon={<Lock size={12} />}>
                    {nls.localize('vueport/cheats/builtIn', 'Ships with the emulator')}
                </PanelDetailBadge>}
                control={<Switch
                    label={nls.localize('vueport/cheats/enabled', 'Enabled')}
                    value={owner.enabled}
                    onChange={enabled => cheats.update(selected, { enabled })}
                />}
            />
            {/* A shipped cheat with nothing to say gets no empty, unusable
                box; the player's own always gets one — it is theirs to fill
                whenever they want to. */}
            {(owner.notes || !owner.builtIn) &&
                <PanelDetailSection
                    title={nls.localize('vueport/cheats/description', 'Description')}
                    htmlFor={owner.builtIn ? undefined : `${fieldId}-notes`}
                >
                    {owner.builtIn
                        ? <p className='vp-detail-text'>{owner.notes}</p>
                        : <textarea
                            id={`${fieldId}-notes`}
                            className='vp-input vp-detail-textarea'
                            rows={4}
                            value={owner.notes ?? ''}
                            placeholder={nls.localize(
                                'vueport/cheats/notesPlaceholder',
                                'What this cheat does, or when it does not work')}
                            onChange={e => cheats.update(selected, { notes: e.target.value || undefined })}
                        />}
                </PanelDetailSection>}
            <PanelDetailSection title={nls.localize('vueport/cheats/codes', 'Codes')}>
                {renderCodes(owner)}
            </PanelDetailSection>
            {!owner.builtIn && <PanelDetailFooter>
                <button className='vp-button secondary danger' onClick={() => removeCheat(selected)}>
                    <Trash size={14} />
                    {nls.localize('vueport/cheats/removeCheat', 'Remove Cheat')}
                </button>
            </PanelDetailFooter>}
        </div>;

    // Searching takes the whole panel, ahead of everything else: it is offered
    // from the empty state as well, and having no cheats yet is the commonest
    // reason to be looking for one.
    if (finding) {
        return <EmulatorCheatFinder
            finder={finder}
            cheats={cheats}
            notifications={notifications}
            onBack={() => setFinding(false)}
            onCreated={index => {
                setFinding(false);
                setEditing(index);
            }}
        />;
    }

    if (list.length === 0) {
        return <>
            {header}
            {peerNote}
            <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/cheats/noCheat', 'No cheats have been configured')}
                    description={nls.localize('vueport/cheats/noCheatDescription', 'Add cheats to pin certain memory addresses to a given value.')}
                    icon={<StarHalf size={32} />}
                />
            </div>
            {actions}
        </>;
    }

    // Editing one takes the whole panel; the list is what it goes back to.
    if (cheat !== undefined && editing !== undefined) {
        return <>
            <PanelDetailToolbar
                list={nls.localize('vueport/cheats/title', 'Cheats')}
                index={editing}
                count={list.length}
                onBack={() => setEditing(undefined)}
                onStep={setEditing}
            />
            <div className='vp-panel-detail vp-scroll'>
                {renderDetail(cheat)}
            </div>
        </>;
    }

    const needle = filter.trim().toLowerCase();
    const visible = list
        .map((entry, index) => ({ entry, index }))
        .filter(({ entry }) => !needle || entry.description.toLowerCase().includes(needle));

    return <>
        {header}
        {peerNote}
        <div className='vp-panel-filter'>
            <MagnifyingGlass size={15} />
            <input
                type='text'
                spellCheck={false}
                value={filter}
                placeholder={nls.localize('vueport/cheats/filter', 'Filter')}
                aria-label={nls.localize('vueport/cheats/filter', 'Filter')}
                onChange={event => setFilter(event.target.value)}
            />
            {filter &&
                <button
                    type='button'
                    className='vp-panel-filter-clear'
                    aria-label={nls.localize('vueport/general/clear', 'Clear')}
                    onClick={() => setFilter('')}
                >
                    <X size={14} />
                </button>}
        </div>
        <div className='vp-split-table vp-scroll'>
            {visible.length === 0
                ? <p className='vp-panel-empty'>
                    {nls.localize('vueport/cheats/noMatch', 'No cheats match “{0}”.', filter.trim())}
                </p>
                : <ul className='vp-panel-list'>
                    {visible.map(({ entry, index }) => (
                        <li
                            key={index}
                            className={'vp-panel-row' + (entry.enabled ? ' enabled' : '')}
                            // The whole row switches the cheat: a switch is a
                            // small target, and switching is the one thing a
                            // row is for. The buttons inside stop the click
                            // reaching here — the pencil because it means
                            // something else, the switch because it would
                            // otherwise toggle twice and land back where it was.
                            onClick={() => cheats.update(index, { enabled: !entry.enabled })}
                        >
                            <button
                                type='button'
                                role='switch'
                                aria-checked={entry.enabled}
                                aria-label={entry.description
                                    || nls.localize('vueport/cheats/thisCheat', 'this cheat')}
                                className='vp-switch'
                                onClick={e => {
                                    e.stopPropagation();
                                    cheats.update(index, { enabled: !entry.enabled });
                                }}
                            >
                                <span className='vp-switch-knob' />
                            </button>
                            {/* Notes under the name, as a patch's description
                                is under its name. */}
                            <span className='vp-panel-row-summary'>
                                <span className='vp-panel-row-name'>{entry.description}</span>
                                {entry.notes &&
                                    <span className='vp-panel-row-notes'>{entry.notes}</span>}
                            </span>
                            {/* A shipped cheat opens the same way, but nothing
                                inside takes edits — its name and its writes are
                                the database's to say — so it is an eye, not a
                                pencil. */}
                            <button
                                type='button'
                                className='vp-panel-row-action'
                                aria-label={(entry.builtIn
                                    ? nls.localize('vueport/cheats/viewCheat', 'View {0}',
                                        entry.description
                                        || nls.localize('vueport/cheats/thisCheat', 'this cheat'))
                                    : nls.localize('vueport/cheats/editCheat', 'Edit {0}',
                                        entry.description
                                        || nls.localize('vueport/cheats/thisCheat', 'this cheat')))}
                                onClick={e => {
                                    e.stopPropagation();
                                    setEditing(index);
                                }}
                            >
                                {entry.builtIn ? <Eye size={18} /> : <PencilSimple size={18} />}
                            </button>
                            {/* A shipped cheat is the database's, not the
                                player's, so there is nothing here to throw away. */}
                            {!entry.builtIn &&
                                <button
                                    type='button'
                                    className='vp-panel-row-action danger'
                                    aria-label={nls.localize('vueport/cheats/removeNamedCheat', 'Remove {0}',
                                        entry.description
                                        || nls.localize('vueport/cheats/thisCheat', 'this cheat'))}
                                    onClick={e => {
                                        e.stopPropagation();
                                        removeCheat(index);
                                    }}
                                >
                                    <X size={16} />
                                </button>
                            }
                        </li>
                    ))}
                </ul>}
        </div>
        {actions}
    </>;
}
