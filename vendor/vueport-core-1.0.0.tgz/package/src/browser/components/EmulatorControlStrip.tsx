import {
  ArrowCounterClockwise,
  BatteryFull,
  BatteryLow,
  Camera,
  ClockClockwise,
  FastForward,
  FileArrowUp,
  FloppyDisk,
  ListDashes,
  Pause,
  PushPin,
  Rewind,
  SkipForward,
  SpeakerSimpleHigh,
  SpeakerSimpleSlash,
  VideoCamera
} from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { EmulatorCommands } from '../emulator-commands';
import { EmulatorAction } from '../emulator-types';
import { EmulatorToolbarControl, EmulatorToolbarHost } from './EmulatorToolbar';
import { DEFAULT_KIT_SERVICES } from './kit/KitContext';

/**
 * The transport, as a strip that floats over the picture.
 *
 * The same controls as `EmulatorToolbar` and the same host interface — this is
 * a second presentation, not a second emulator. Which one a host gets is the
 * `chrome` prop on `Emulator`: the studio and anything embedding the emulator
 * in a workbench want the toolbar, because there the emulator is one panel
 * among many and a row of controls above it reads as that panel's own. The
 * standalone application wants this, because there the picture is the product
 * and a permanent toolbar frames a 384x224 image with an IDE.
 *
 * What is deliberately NOT here, compared to the toolbar: the scale, rendering
 * mode and palette selectors, the Play/Debug switch, and linking a second
 * player. Those are settings rather than transport — they are changed once and
 * then left, and they live in the settings window and the title bar
 * respectively. Keeping them out is what lets this be a strip rather than a
 * floating toolbar.
 *
 * The strip carries no state of its own beyond nothing: what is switched on is
 * said by the badges over the picture (`EmulatorStateBadges`), because this
 * strip is not always on screen and a lit button nobody can see is not a
 * status display.
 */

export interface EmulatorControlStripProps {
  host: EmulatorToolbarHost;
  /** Held open regardless of the pointer, and drawn as pressed. */
  pinned?: boolean;
  /**
   * Left out for a strip the host has placed somewhere of its own — the
   * studio's title bar — where there is no hiding to pin against. The pin
   * button is then not drawn at all, rather than drawn doing nothing.
   */
  onTogglePinned?(): void;
  /**
   * Sits in a row the host owns rather than floating over the picture.
   *
   * It is the same controls either way; what changes is that it is not a
   * layer — no rounded slab, no shadow, and it gives its height to the row
   * around it instead of claiming its own.
   */
  inline?: boolean;
}

/** A control a host added, in the strip's clothes rather than the toolbar's. */
function hostControls(
  controls: EmulatorToolbarControl[] | undefined,
  tooltip: (content: string) => object,
): React.ReactNode {
  return controls?.length
    ? controls.map(control =>
      <button
        key={control.id}
        data-control={control.id}
        className={'vp-strip-button vp-toolbar-host-control'
          + (control.active ? ' vp-strip-button-on' : '')}
        {...tooltip(control.label)}
        onClick={() => control.run()}
        disabled={control.disabled}
      >
        {control.icon}
      </button>
    )
    : undefined;
}

export function EmulatorControlStrip(props: EmulatorControlStripProps): React.JSX.Element {
  const { host, pinned, onTogglePinned, inline } = props;
  const hover = host.hover ?? DEFAULT_KIT_SERVICES.hover;
  const rewindEnabled = host.isRewindEnabled();
  const busy = host.state.showControls;

  /**
   * What a button says about itself. The toolbar's arrangement exactly — see
   * the note there on why `title` is not set.
   */
  const tooltip = (content: string) => ({
    'aria-label': content,
    onMouseEnter: (event: React.MouseEvent<HTMLElement>) =>
      hover.show(event.currentTarget, content),
    onMouseLeave: () => hover.hide(),
  });

  /** Every button in here is the same button with a different glyph. */
  const button = (
    key: string,
    label: string,
    icon: React.ReactNode,
    onClick: () => void,
    options?: { on?: boolean, off?: boolean, disabled?: boolean, extra?: object },
  ): React.JSX.Element =>
    <button
      key={key}
      // Named rather than positional, and not a label: what a control is
      // called is translated, and its place in the row is a design decision
      // that moves.
      data-control={key}
      className={'vp-strip-button'
        + (options?.on ? ' vp-strip-button-on' : '')
        + (options?.off ? ' vp-strip-button-off' : '')}
      {...tooltip(label)}
      onClick={onClick}
      disabled={options?.disabled}
      {...options?.extra}
    >
      {icon}
    </button>;

  /** The keys a control answers to, appended to its name. */
  const withKey = (label: string, commandId: string): string =>
    `${label}${host.bindings.label(commandId, true)}`;

  const groups: React.ReactNode[] = [];
  const leading = hostControls(host.leadingControls, tooltip);
  if (leading) {
    groups.push(<div className='vp-strip-group' key='host-leading'>{leading}</div>);
  }

  groups.push(<div className='vp-strip-group' key='transport'>
    {button('reset',
      withKey(EmulatorCommands.INPUT_RESET.label ?? '', EmulatorCommands.INPUT_RESET.id),
      <ArrowCounterClockwise size={18} />,
      () => host.runAction(EmulatorAction.Reset),
      { disabled: busy })}
    {button('pause',
      withKey(host.state.paused
        ? nls.localize('vueport/state/resume', 'Resume')
        : nls.localize('vueport/state/pause', 'Pause'),
        EmulatorCommands.INPUT_PAUSE_TOGGLE.id),
      <Pause size={18} />,
      () => host.runAction(EmulatorAction.PauseToggle),
      { on: host.state.paused, disabled: busy })}
  </div>);

  groups.push(<div className='vp-strip-group' key='speed'>
    {button('rewind',
      withKey(EmulatorCommands.INPUT_REWIND.label ?? '', EmulatorCommands.INPUT_REWIND.id)
      + (rewindEnabled ? '' : ` — ${nls.localize('vueport/state/rewind/isOff', 'off, click to enable')}`),
      <Rewind size={18} />,
      () => undefined,
      {
        on: host.rewinding,
        off: !rewindEnabled,
        disabled: busy || host.state.paused,
        // Held down rather than clicked, exactly as in the toolbar: the
        // pointer presses rewind for as long as it is down, and a click with
        // no pointer behind it is the keyboard activating the button.
        extra: {
          onPointerDown: host.onRewindButtonDown,
          onPointerUp: host.onRewindButtonUp,
          onPointerCancel: host.onRewindButtonUp,
          onLostPointerCapture: () => host.stopRewinding(),
          onClick: (event: React.MouseEvent<HTMLButtonElement>) => {
            if (!rewindEnabled) {
              host.promptEnableRewind();
            } else if (event.detail === 0) {
              host.runAction(EmulatorAction.Rewind);
            }
          },
        },
      })}
    {button('slowmotion',
      withKey(EmulatorCommands.INPUT_TOGGLE_SLOWMOTION.label ?? '',
        EmulatorCommands.INPUT_TOGGLE_SLOWMOTION.id),
      <ClockClockwise size={18} />,
      () => host.runAction(EmulatorAction.ToggleSlowmotion),
      // Slow motion and frame advance both hand out an unfair timing edge, so
      // hardcore mode takes them away — drawn out but still live, the same as
      // rewind and load state: the click runs `runAction`, which puts up the
      // "Hardcore Mode is on" notice. Fast forward it leaves alone.
      {
        on: host.state.slowmotion, off: host.isHardcore(),
        disabled: busy || host.state.paused
      })}
    {button('frame-advance',
      withKey(EmulatorCommands.INPUT_FRAME_ADVANCE.label ?? '',
        EmulatorCommands.INPUT_FRAME_ADVANCE.id),
      <SkipForward size={18} />,
      () => host.runAction(EmulatorAction.FrameAdvance),
      {
        on: host.state.frameAdvance,
        off: host.isHardcore(),
        disabled: busy || (host.state.paused && !host.state.frameAdvance),
      })}
    {button('fast-forward',
      withKey(EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD.label ?? '',
        EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD.id),
      <FastForward size={18} />,
      () => host.runAction(EmulatorAction.ToggleFastForward),
      { on: host.state.fastForward, disabled: busy || host.state.paused })}
  </div>);

  groups.push(<div className='vp-strip-group' key='states'>
    {button('save-state',
      withKey(EmulatorCommands.INPUT_SAVE_STATE.label ?? '', EmulatorCommands.INPUT_SAVE_STATE.id),
      <FloppyDisk size={18} />,
      () => host.runAction(EmulatorAction.SaveState),
      { disabled: busy || host.state.paused })}
    {button('load-state',
      withKey(EmulatorCommands.INPUT_LOAD_STATE.label ?? '', EmulatorCommands.INPUT_LOAD_STATE.id),
      <FileArrowUp size={18} />,
      () => host.runAction(EmulatorAction.LoadState),
      // Hardcore mode forbids resuming from a snapshot. Drawn out but still
      // live, the same as rewind is when it is switched off: the click runs
      // `runAction`, which puts up the "Hardcore Mode is on" notice.
      {
        off: host.isHardcore(),
        disabled: busy || host.state.paused || !host.state.saveStateExists
      })}
    {/* Where the slot number used to be, and for the same reason it is not
        there any more: saving makes a new state every time, so the thing worth
        reaching from the transport is the list of them. Only for a host that
        has one — see `EmulatorToolbarState.showSaveStates`. */}
    {host.toggleSaveStates && button('save-states',
      withKey(EmulatorCommands.TOGGLE_SAVE_STATES.label ?? '',
        EmulatorCommands.TOGGLE_SAVE_STATES.id),
      <ListDashes size={18} />,
      () => host.toggleSaveStates?.(),
      { on: host.state.showSaveStates, disabled: busy })}
  </div>);

  groups.push(<div className='vp-strip-group' key='session'>
    {button('mute',
      withKey(host.state.muted
        ? nls.localize('vueport/state/unmute', 'Unmute')
        : nls.localize('vueport/state/mute', 'Mute'),
        EmulatorCommands.INPUT_AUDIO_MUTE.id),
      host.state.muted ? <SpeakerSimpleSlash size={18} /> : <SpeakerSimpleHigh size={18} />,
      () => host.runAction(EmulatorAction.AudioMute),
      { on: host.state.muted, disabled: busy })}
    {button('low-power',
      withKey(EmulatorCommands.INPUT_TOGGLE_LOW_POWER.label ?? '',
        EmulatorCommands.INPUT_TOGGLE_LOW_POWER.id),
      host.state.lowPower ? <BatteryLow size={18} /> : <BatteryFull size={18} />,
      () => host.runAction(EmulatorAction.ToggleLowPower),
      { on: host.state.lowPower, disabled: busy })}
  </div>);

  groups.push(<div className='vp-strip-group' key='capture'>
    {button('screenshot',
      withKey(EmulatorCommands.INPUT_SCREENSHOT.label ?? '', EmulatorCommands.INPUT_SCREENSHOT.id),
      <Camera size={18} />,
      () => host.runAction(EmulatorAction.Screenshot),
      { disabled: busy })}
    {/* Only where the host can actually record. `recordingVideo` is the
        capability as well as the state: a host that never answers it has no
        recorder behind this button, and a button that does nothing is worse
        than one that is not there. Lit while it runs, unlike the shutter
        beside it — the one control in this group that is a state rather than
        an event — and the badge over the picture says the same thing for when
        the strip has hidden itself. */}
    {host.recordingVideo !== undefined && button('video',
      withKey(host.recordingVideo
        ? nls.localize('vueport/video/stop', 'Stop Recording')
        : EmulatorCommands.INPUT_VIDEO_RECORD.label ?? '',
        EmulatorCommands.INPUT_VIDEO_RECORD.id),
      <VideoCamera size={18} weight={host.recordingVideo ? 'fill' : 'regular'} />,
      () => host.runAction(EmulatorAction.VideoRecord),
      { on: host.recordingVideo, disabled: busy })}
  </div>);

  const trailing = hostControls(host.trailingControls, tooltip);
  if (trailing) {
    groups.push(<div className='vp-strip-group' key='host-trailing'>{trailing}</div>);
  }

  /*
   * The only control in here about the strip rather than about the emulator,
   * which is why it is last and behind its own divider. Pinned, the strip
   * stops hiding itself — the answer to auto-hiding being exactly right while
   * playing and exactly wrong while setting something up.
   */
  if (onTogglePinned) {
    groups.push(<div className='vp-strip-group' key='pin'>
      {button('pin',
        pinned
          ? nls.localize('vueport/strip/unpin', 'Let the controls hide again')
          : nls.localize('vueport/strip/pin', 'Keep the controls on screen'),
        <PushPin size={18} weight={pinned ? 'fill' : 'regular'} />,
        onTogglePinned,
        { on: pinned })}
    </div>);
  }

  return <div
    className={'vp-strip vp-scroll' + (inline ? ' vp-strip-inline' : '')}
    role='toolbar'
  >{groups}</div>;
}
