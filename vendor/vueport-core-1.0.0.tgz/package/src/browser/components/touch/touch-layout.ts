import { TouchControlPlacement, TouchControlsLayout } from '../../../common/emulator-settings';
import { VbKey } from '../../../common/vb-constants';

/**
 * The on-screen controller's parts and where each goes. Laid out after the real pad: L and R on top, a d-pad under
 * each, Select and Start under the left one where B and A sit under the right, mirrored (Select outside and higher,
 * as A is). All eight are round or a cross, as on the hardware.
 *
 * A place is a centre measured from a corner of the controller's area, in CSS pixels at 100 %: from the left or right
 * edge across, from the top or bottom edge down. So the arrangement keeps to the edges the thumbs are at, however
 * wide or tall the phone is, and only the space between grows.
 */
export type TouchControlId = 'l' | 'r' | 'ldpad' | 'rdpad' | 'select' | 'start' | 'b' | 'a';

export const TOUCH_CONTROL_IDS: readonly TouchControlId[] = ['l', 'r', 'ldpad', 'rdpad', 'select', 'start', 'b', 'a'];

// upright, the controller has the screen's width below the picture; on its side, the strips beside it
export type TouchOrientation = 'portrait' | 'landscape';

export interface TouchControlSpot {
    // which edge `x` is measured from
    from: 'left' | 'right';
    x: number;
    // which edge `y` is measured from, or the middle of the height (a negative `y` above it)
    fromY: 'top' | 'bottom' | 'middle';
    y: number;
    // a button's diameter, a d-pad's width
    size: number;
}

export interface TouchLayoutSpec {
    // the area the spots were drawn for; the controller is scaled down where a phone has less, see layoutScale
    width: number;
    height: number;
    // how far in from each side the controller reaches, so a picture beside it can be kept clear of it
    side: number;
    spots: Record<TouchControlId, TouchControlSpot>;
}

export const TOUCH_LAYOUTS: Record<TouchOrientation, TouchLayoutSpec> = {
    // under the picture, kept to the bottom edge, where a thumb rests holding the phone
    portrait: {
        width: 390,
        height: 460,
        side: 390,
        spots: {
            l: { from: 'left', x: 60, fromY: 'bottom', y: 416, size: 64 },
            r: { from: 'right', x: 60, fromY: 'bottom', y: 416, size: 64 },
            ldpad: { from: 'left', x: 98, fromY: 'bottom', y: 278, size: 148 },
            rdpad: { from: 'right', x: 98, fromY: 'bottom', y: 278, size: 148 },
            select: { from: 'left', x: 60, fromY: 'bottom', y: 154, size: 64 },
            start: { from: 'left', x: 136, fromY: 'bottom', y: 126, size: 64 },
            a: { from: 'right', x: 60, fromY: 'bottom', y: 154, size: 64 },
            b: { from: 'right', x: 136, fromY: 'bottom', y: 126, size: 64 },
        },
    },
    // beside the picture, the whole height, centred on it, so a taller phone has the room shared above and below. A
    // quarter larger than the first layout, which left the strips beside the picture half empty, and with B and Start
    // only a little below A and Select, as the larger buttons would otherwise run off the bottom
    landscape: {
        width: 844,
        height: 390,
        side: 184,
        spots: {
            l: { from: 'left', x: 60, fromY: 'middle', y: -140, size: 70 },
            r: { from: 'right', x: 60, fromY: 'middle', y: -140, size: 70 },
            ldpad: { from: 'left', x: 96, fromY: 'middle', y: -13, size: 168 },
            rdpad: { from: 'right', x: 96, fromY: 'middle', y: -13, size: 168 },
            select: { from: 'left', x: 54, fromY: 'middle', y: 119, size: 72 },
            start: { from: 'left', x: 140, fromY: 'middle', y: 139, size: 72 },
            a: { from: 'right', x: 54, fromY: 'middle', y: 119, size: 72 },
            b: { from: 'right', x: 140, fromY: 'middle', y: 139, size: 72 },
        },
    },
};

// what a round control holds; the d-pads hold a direction each, see DPAD_KEYS
export const BUTTON_KEYS: Record<Exclude<TouchControlId, 'ldpad' | 'rdpad'>, VbKey> = {
    l: VbKey.LT,
    r: VbKey.RT,
    select: VbKey.SEL,
    start: VbKey.STA,
    b: VbKey.B,
    a: VbKey.A,
};

export const DPAD_KEYS: Record<'ldpad' | 'rdpad', { up: VbKey, right: VbKey, down: VbKey, left: VbKey }> = {
    ldpad: { up: VbKey.LU, right: VbKey.LR, down: VbKey.LD, left: VbKey.LL },
    rdpad: { up: VbKey.RU, right: VbKey.RR, down: VbKey.RD, left: VbKey.RL },
};

export function isDpad(id: TouchControlId): id is 'ldpad' | 'rdpad' {
    return id === 'ldpad' || id === 'rdpad';
}

/**
 * How much smaller than drawn the controller has to be for this area, never larger: a phone shorter than the layout
 * (an iPhone SE upright) shrinks it rather than letting L and R run into the picture. Not below two thirds, where the
 * buttons would get too small to hit; the area scrolls nothing, so what is left over is simply clipped.
 */
export function layoutScale(spec: TouchLayoutSpec, width: number, height: number): number {
    const fit = Math.min(width / spec.width, height / spec.height, 1);
    return Math.max(fit, 2 / 3);
}

export interface PlacedControl {
    id: TouchControlId;
    // centre, in the area's own pixels
    cx: number;
    cy: number;
    size: number;
}

// every control's centre and size in an area this large, with the player's own moves and sizes folded in
export function placeControls(
    orientation: TouchOrientation,
    width: number,
    height: number,
    size: number,
    custom: TouchControlsLayout | undefined,
): PlacedControl[] {
    const spec = TOUCH_LAYOUTS[orientation];
    const scale = layoutScale(spec, width, height) * size;
    const moved = custom?.[orientation] ?? {};
    return TOUCH_CONTROL_IDS.map(id => {
        const spot = spec.spots[id];
        const own: TouchControlPlacement = moved[id] ?? { dx: 0, dy: 0, scale: 1 };
        const cx = (spot.from === 'left' ? spot.x * scale : width - spot.x * scale) + own.dx;
        const cy = (spot.fromY === 'top' ? spot.y * scale
            : spot.fromY === 'middle' ? height / 2 + spot.y * scale
                : height - spot.y * scale) + own.dy;
        return { id, cx, cy, size: spot.size * scale * own.scale };
    });
}

// how far in the picture has to stay from each side, for a controller this large beside it
export function sideClearance(orientation: TouchOrientation, width: number, height: number, size: number): number {
    const spec = TOUCH_LAYOUTS[orientation];
    return spec.side * layoutScale(spec, width, height) * size;
}

// the step a control's own size goes up or down by in the editor, and its bounds
export const PLACEMENT_SCALE_STEP = 0.05;
export const PLACEMENT_SCALE_RANGE = { min: 0.6, max: 1.6 };
