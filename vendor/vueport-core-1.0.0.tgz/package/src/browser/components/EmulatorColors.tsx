/**
 * The VB Color palette editor, beside the running game.
 *
 * Scene filter, object list, four swatches per palette. Changing one writes the
 * color into the running game at once, so the result is on screen without the
 * game restarting; the patch that carries the same colors is rebuilt behind
 * it. Why those are two paths, and why there is nothing here to enter or leave,
 * is in `emulator-vb-color-store.ts`.
 *
 * A component rather than a panel because it is shown in two places and only one
 * of them is a panel — the same arrangement `EmulatorCheats` uses. While playing
 * it is a strip beside the screen; in Debug mode it is docked, where it can sit
 * open alongside the VCU panel's Color RAM grid.
 *
 * The game *is* the preview, which is the whole reason this is not in the
 * settings dialog: colors are chosen by looking at them. It is also why the
 * whole feature is governed from here — the switch that applies the
 * colorization is at the bottom of this panel rather than in a list of games
 * under the settings, where it would have been a switch for something you
 * could not see. Making one for a game that has none starts here too, and for
 * the same reason: see `emulator-vb-color-create.ts` for what that makes and
 * what it warns about first.
 */

import {
    ArrowCounterClockwise,
    ArrowLeft,
    ClipboardText,
    Copy,
    DownloadSimple,
    Export,
    Eye,
    FloppyDisk,
    Info,
    Lightning,
    MagnifyingGlass,
    PaintBucket,
    Plus,
    Prohibit,
    Trash,
    X,
} from '@phosphor-icons/react';
import * as React from 'react';
import { VesColorPatchStatus } from '../../common/emulator-color-patches';
import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';
import {
    VB_COLOR_MAX_PALETTE_NAME,
    VbColorObject,
    VbColorPaletteView,
} from '../../common/emulator-vb-color';
import { VB_COLOR_CREATED_VERSION } from '../../common/emulator-vb-color-create';
import { ColorStore } from '../emulator-vb-color-store';
import { field } from '../panels/emulator-vip-detail';
import ColorField from './kit/ColorField';
import EmptyContainer from './kit/EmptyContainer';
import Select from './kit/Select';

/** How far along a colorization is, in words. */
function statusLabel(status: VesColorPatchStatus): string {
    switch (status) {
        case 'complete':
            return nls.localize('vueport/vbColor/status/complete', 'Complete');
        case 'partial':
            return nls.localize('vueport/vbColor/status/partial', 'Partial');
        case 'wip':
            return nls.localize('vueport/vbColor/status/wip', 'In progress');
    }
}

export interface EmulatorColorsProps {
    colors: ColorStore;
    /** For the switch at the foot of the panel, which warns before it restarts. */
    notifications: VueportNotifications;
    /** Present only for the strip beside the screen, which has no chrome. */
    onClose?: () => void;
}

export default function EmulatorColors(props: EmulatorColorsProps): React.JSX.Element {
    const { colors, notifications, onClose } = props;

    const [scene, setScene] = React.useState<string | undefined>(undefined);
    const [filter, setFilter] = React.useState('');
    const [selected, setSelected] = React.useState<string | undefined>(undefined);
    /** Whether the colorization's own details have the panel. */
    const [showingInfo, setShowingInfo] = React.useState(false);
    /**
     * The palette name being typed, while it is being typed.
     *
     * Held here rather than written on every keystroke so that a half-typed
     * name is not a rename: what is stored is what somebody finished with, on
     * Enter or on leaving the field.
     */
    const [renaming, setRenaming] = React.useState<{ id: number, value: string } | undefined>(undefined);
    const [, bump] = React.useReducer((n: number) => n + 1, 0);

    React.useEffect(() => {
        const subscription = colors.onDidChange(bump);
        return () => subscription.dispose();
    }, [colors]);

    /**
     * Switch the colorization on or off, saying what that costs first.
     *
     * Only on the way on. Applying a patch is applying a patch — the machine is
     * rebuilt from the original ROM either way — but coming *off* is the way
     * back from something somebody has just been warned about, and asking twice
     * to undo one confirmation is how a dialog stops being read.
     */
    const setApplied = async (applied: boolean): Promise<void> => {
        if (applied && !await notifications.confirm({
            title: nls.localize('vueport/vbColor/applyQuestion', 'Apply Color Patch?'),
            message: nls.localize(
                'vueport/vbColor/applyConfirm',
                'The emulation needs to be reset for the ROM to pick up the color patch. \
Anything since your last save will be lost.',
            ),
            okLabel: nls.localize('vueport/vbColor/applyAndRestart', 'Apply and Restart'),
        })) {
            return;
        }
        colors.setApplied(applied);
    };

    /**
     * Throw every color edit away, once.
     *
     * Asked about first, unlike a single palette's Reset beside its swatches:
     * that one undoes what is in front of you, this one undoes work you may
     * have done half an hour ago in a scene you cannot currently see. Nothing
     * in the panel can put it back.
     */
    const resetAll = async (): Promise<void> => {
        if (!await notifications.confirm({
            title: nls.localize('vueport/vbColor/resetQuestion', 'Reset All Changes?'),
            message: nls.localize(
                'vueport/vbColor/resetConfirm',
                'Every palette goes back to the colors and names this colorization ships with.'
                + ' {0} palette(s) have been changed and {1} renamed.',
                String(colors.editedCount),
                String(colors.renamedCount),
            ),
            okLabel: nls.localize('vueport/vbColor/reset', 'Reset'),
        })) {
            return;
        }
        colors.resetAll();
    };

    /**
     * Make a colorization for this game, having said what it will and will not be.
     *
     * The warning is the point of the dialog, not the restart: what comes back
     * is a generic bootstrap, and somebody who expected the four shipped
     * colorizations' work would find eight useful palettes and 248 that do
     * nothing and conclude it was broken. Said before it is made rather than
     * after, because afterwards it reads as an excuse.
     */
    const create = async (): Promise<void> => {
        if (!await notifications.confirm({
            title: nls.localize('vueport/vbColor/create/question', 'Create a Color Patch?'),
            message: [
                nls.localize(
                    'vueport/vbColor/create/confirmGeneric',
                    'This makes a generic color patch, not one written for this game. It switches VB Color '
                    + 'on before the game starts and gives you 256 editable palettes — but the game goes on '
                    + 'choosing between the eight it always could, so only those eight change what is on '
                    + 'screen. Reaching the rest needs a patch made for this game by hand.'),
                nls.localize(
                    'vueport/vbColor/create/confirmCost',
                    'The cartridge is compiled to twice its size, and the emulation is reset to run it. '
                    + 'Anything since your last save will be lost.'),
            ],
            okLabel: nls.localize('vueport/vbColor/create/createAndRestart', 'Create and Restart'),
        })) {
            return;
        }
        await colors.create();
        if (colors.error) {
            notifications.error(colors.error);
        }
    };

    /**
     * Write the colors somebody has chosen into their own color patch.
     *
     * Said out loud afterwards, because nothing on screen changes: the game
     * was already showing these colors, and what moved is where they are
     * kept. See `saveCreated`.
     */
    const save = async (): Promise<void> => {
        try {
            if (await colors.saveCreated()) {
                notifications.info(nls.localize(
                    'vueport/vbColor/create/saved', 'Your colors are saved in this color patch.'));
            }
        } catch (error) {
            notifications.error(nls.localize(
                'vueport/vbColor/create/saveFailed', 'The color patch could not be saved: {0}',
                error instanceof Error ? error.message : String(error)));
        }
    };

    /** Throw a created colorization away — the file, the edits and all. */
    const deleteCreated = async (): Promise<void> => {
        if (!await notifications.confirm({
            title: nls.localize('vueport/vbColor/create/deleteQuestion', 'Delete This Color Patch?'),
            message: nls.localize(
                'vueport/vbColor/create/deleteConfirm',
                'The color patch made for this game is deleted, along with every color you changed in it. '
                + 'The game is reset and runs unpatched again.'),
            okLabel: nls.localize('vueport/vbColor/create/delete', 'Delete'),
        })) {
            return;
        }
        setShowingInfo(false);
        await colors.deleteCreated();
    };

    /** Save the colorization with its edits, and say where it went. */
    const exportPatch = async (): Promise<void> => {
        const fileName = await colors.exportPatch();
        if (fileName) {
            notifications.info(nls.localize(
                'vueport/vbColor/exported', 'Colorization saved as {0}.', fileName));
        }
    };

    /**
     * The foot of the panel: what can be done to the colorization as a whole,
     * as against to the palettes inside it.
     *
     * Two buttons for a colorization VUEPort ships, and which two depends on
     * the state rather than one control changing meaning under a label that
     * stays put. Off, the pair is about getting a colorization running — turn
     * this one on, or bring another in. On, it is about the one that is running
     * — turn it off, or take a copy of it out. The button that changes the
     * machine leads; the file operation follows it, quieter, because it
     * changes nothing.
     *
     * One made here has more that can be done to it, and that is the whole
     * difference: it is the person's own file, so it can be written into and it
     * can be thrown away. Save and Delete are therefore here and only here —
     * beside the rest of what is done to the colorization as a whole — and the
     * row wraps rather than squeezing five buttons onto one line.
     *
     * Neither pair, while a colorization is still loading or has failed to
     * build: there is nothing to enable and nothing to export, and offering to
     * make a new one for a game that already has one — which is what the
     * failure is — would answer a question nobody asked.
     */
    const actions = colors.status === 'loading' || colors.status === 'failed'
        ? undefined
        : colors.status === 'ready'
            ? <div className='vp-panel-actions'>
                <button
                    type='button'
                    className='vp-button secondary'
                    disabled={colors.building}
                    onClick={() => { setApplied(!colors.applied); }}
                >
                    {colors.applied
                        ? <Prohibit size={14} />
                        : <PaintBucket size={14} />
                    }
                    {colors.applied
                        ? nls.localize('vueport/vbColor/disablePatch', 'Disable')
                        : nls.localize('vueport/vbColor/enablePatch', 'Enable Color Patch')
                    }
                </button>
                {colors.applied
                    ? <>
                        {/* Only for one made here, and dead until there is
                        something to write: VUEPort's own bundled documents are
                        not its to edit, which is what Export is for. */}
                        {colors.created &&
                            <button
                                type='button'
                                className='vp-button secondary'
                                disabled={colors.editedCount === 0 && colors.renamedCount === 0}
                                title={nls.localize(
                                    'vueport/vbColor/create/saveTooltip',
                                    'Write the colors and names you changed into this color patch')}
                                onClick={() => { save(); }}
                            >
                                <FloppyDisk size={14} />
                                {nls.localize('vueport/vbColor/create/save', 'Save')}
                            </button>}
                        <button
                            type='button'
                            className='vp-button secondary'
                            title={nls.localize(
                                'vueport/vbColor/exportTooltip',
                                'Save this colorization, with your edits, as a JSON file')}
                            onClick={() => { exportPatch(); }}
                        >
                            <Export size={14} />
                            {nls.localize('vueport/vbColor/export', 'Export')}
                        </button>
                        {/* Dead until there is something to undo, which is also
                        what makes it readable as a record: a live Reset means
                        this colorization is no longer the one that shipped. */}
                        <button
                            type='button'
                            className='vp-button secondary'
                            disabled={colors.editedCount === 0 && colors.renamedCount === 0}
                            title={nls.localize(
                                'vueport/vbColor/resetTooltip', 'Reset all changes')}
                            onClick={() => { resetAll(); }}
                        >
                            <ArrowCounterClockwise size={14} />
                            {nls.localize('vueport/vbColor/reset', 'Reset')}
                        </button>
                    </>
                    /*
                     * Inert for now, like Create was. What a colorization may be
                     * imported *from* is not simply the other end of Export, so
                     * this has a decision behind it that the button being here
                     * does not settle.
                     *
                     * Not offered for one made here: the offer is "bring another
                     * one in", and beside a colorization somebody made and
                     * switched off it would be answering a question nobody asked.
                     * Enable and Delete are the two things to do with that.
                     */
                    : !colors.created && <button
                        type='button'
                        className='vp-button secondary'
                        onClick={() => undefined}
                    >
                        <DownloadSimple size={14} />
                        {nls.localize('vueport/vbColor/import', 'Import')}
                    </button>}
                {/* Whether it is switched on or off: a colorization somebody made
                and does not want is one they should be able to be rid of
                without turning it on first. */}
                {colors.created &&
                    <button
                        type='button'
                        className='vp-button secondary'
                        title={nls.localize(
                            'vueport/vbColor/create/deleteTooltip',
                            'Delete this color patch and every color you changed in it')}
                        onClick={() => { deleteCreated(); }}
                    >
                        <Trash size={14} />
                        {nls.localize('vueport/vbColor/create/delete', 'Delete')}
                    </button>}
            </div>
            /*
             * Nothing for this game: the one thing to offer is making one.
             *
             * Dead where the ROM cannot take one — an odd size, too large to
             * double — with the reason on the button rather than behind it, so
             * nobody presses it to find out. See `createRefusal`.
             */
            : <div className='vp-panel-actions'>
                <button
                    type='button'
                    className='vp-button secondary'
                    disabled={!colors.canCreate}
                    title={colors.createRefusal}
                    onClick={() => { create(); }}
                >
                    <Plus size={14} />
                    {colors.creating
                        ? nls.localize('vueport/vbColor/create/creating', 'Creating…')
                        : nls.localize('vueport/vbColor/create/create', 'Create')}
                </button>
            </div>;

    const header = <div className='vp-panel-heading'>
        {onClose && <span className='vp-panel-heading-title'>
            <PaintBucket size={22} />
            {nls.localize('vueport/vbColor/title', 'Colors')}
        </span>}
        {onClose && <button
            type='button'
            className='vp-panel-close'
            aria-label={nls.localize('vueport/vbColor/close', 'Close Colors')}
            onClick={onClose}
        >
            <X size={20} />
        </button>}
    </div>;

    // Every state ends in the same foot — the switch, or the Create button
    // where there is nothing to switch. The panel is always reachable now, so
    // what it says when it has nothing is as much a part of it as the list.
    const empty = (title: string, description: string): React.JSX.Element => <>
        {header}
        <div className='vp-panel-empty-fill'>
            <EmptyContainer title={title} description={description} icon={<PaintBucket size={32} />} />
        </div>
        {actions}
    </>;

    if (colors.status === 'none') {
        return empty(
            nls.localize('vueport/vbColor/noneTitle', 'No colorization for this game'),
            nls.localize(
                'vueport/vbColor/noneDescription',
                'There is no colorization patch for this game.',
            ));
    }

    if (colors.status === 'loading') {
        return colors.creating
            ? empty(
                nls.localize('vueport/vbColor/create/creatingTitle', 'Making a color patch…'),
                nls.localize(
                    'vueport/vbColor/create/creatingDescription',
                    'Compiling the bootstrap into the cartridge and building the patch.'))
            : empty(
                nls.localize('vueport/vbColor/loadingTitle', 'Loading the colorization…'),
                nls.localize('vueport/vbColor/loadingDescription', 'Reading its palettes and building the patch.'));
    }

    if (colors.status === 'failed' || !colors.loaded) {
        return empty(
            nls.localize('vueport/vbColor/failedTitle', 'The colorization could not be built'),
            colors.error ?? '');
    }

    // Editing needs the colorization actually running: the palettes it copies
    // are what the swatches are painting over. Said once, and the way out is
    // the switch at the foot, which every state here carries.
    if (!colors.applied) {
        return empty(
            nls.localize('vueport/vbColor/notAppliedTitle', 'Color Patch Not Applied'),
            nls.localize(
                'vueport/vbColor/notAppliedDescription',
                'There is a color patch available for this game, but it is currently disabled. \
Enable it below. Will restart the game.',
            ));
    }

    const palettes = colors.palettes;
    const paletteById = (id: number): VbColorPaletteView | undefined =>
        palettes.find(palette => palette.id === id);
    /** What a palette is called, for a document that left one unnamed. */
    const name = (palette: VbColorPaletteView): string =>
        palette.name || nls.localize('vueport/vbColor/palette', 'Palette {0}', String(palette.id));
    // Undefined until the button below has been pressed, which is the whole
    // difference between this and a filter that watches: no sample, no claim.
    const drawn = colors.drawn;

    const objectIsDrawn = (object: VbColorObject): boolean =>
        drawn !== undefined && colors.palettesOf(object).some(id => drawn.has(id));
    const objectIsEdited = (object: VbColorObject): boolean =>
        colors.palettesOf(object).some(id => colors.isEdited(id));
    const needle = filter.trim().toLowerCase();
    const objectMatches = (object: VbColorObject): boolean =>
        needle === ''
        || object.name.toLowerCase().includes(needle)
        || colors.palettesOf(object).some(id =>
            String(id) === needle || (paletteById(id)?.name.toLowerCase().includes(needle) ?? false));

    const listed = colors.objects(scene)
        .filter(object => drawn === undefined || objectIsDrawn(object))
        .filter(objectMatches)
        // Edited first: what somebody is working on is what they come back to.
        .sort((a, b) => Number(objectIsEdited(b)) - Number(objectIsEdited(a)));

    const chosen = selected === undefined
        ? undefined
        : colors.objects().find(object => object.id === selected);

    const back = (onBack: () => void): React.JSX.Element =>
        <div className='vp-panel-toolbar'>
            <button
                type='button'
                className='vp-panel-back'
                aria-label={nls.localize('vueport/debug/panels/general/backToList', 'Back To List')}
                onClick={onBack}
            >
                <ArrowLeft size={20} />
                {nls.localize('vueport/debug/panels/general/backToList', 'Back To List')}
            </button>
        </div>;

    /* A patch compiled before the palette ABI: shown, and not editable. */
    const locked = !colors.editable &&
        <p className='vp-input-hint'>
            {nls.localize(
                'vueport/vbColor/notEditable',
                'This color patch was compiled before its palettes could be edited, so they are'
                + ' shown as it ships them.')}
        </p>;

    // ----------------------------------------------------------------- info

    /*
     * What this colorization is, as against what it paints.
     *
     * The catalog entry's own fields, laid out the way the Cheats and Patches
     * panels lay out theirs.
     */
    const entry = colors.entry;
    if (showingInfo && entry) {
        return <>
            {back(() => setShowingInfo(false))}
            <div className='vp-panel-detail vp-scroll'>
                <div className='vp-detail'>
                    <div className='vp-detail-groups'>
                        <fieldset className='vp-inspector-group'>
                            <legend>{nls.localize('vueport/vbColor/colorPatch', 'Color Patch')}</legend>
                            <div className='vp-detail-fields'>
                                {field(nls.localize('vueport/general/name', 'Name'), entry.game)}
                                {field(
                                    nls.localize('vueport/vbColor/status/status', 'Status'),
                                    statusLabel(entry.status),
                                )}
                                {field(
                                    nls.localize('vueport/patches/author', 'Author'),
                                    entry.author ?? nls.localize('vueport/patches/unknownAuthor', 'Unknown'),
                                )}
                                {field(
                                    nls.localize('vueport/vbColor/version', 'Version'),
                                    entry.version ?? '—',
                                )}
                                {/* The ROMs it matches: the field that says
                                    which dump this was made against, and so
                                    what it will and will not line up with. */}
                                {field(
                                    nls.localize('vueport/vbColor/matchingRoms', 'Matching ROMs'),
                                    entry.crc32.join(', '),
                                )}
                                {field(
                                    nls.localize('vueport/vbColor/palettes', 'Palettes'),
                                    String(palettes.length),
                                )}
                                {field(
                                    nls.localize('vueport/vbColor/editable', 'Palette Editing'),
                                    colors.editable
                                        ? nls.localize('vueport/vbColor/editableYes', 'Available')
                                        : nls.localize('vueport/vbColor/editableNo',
                                            'Not available for this build of the patch'),
                                )}
                                {field(
                                    nls.localize('vueport/vbColor/edited', 'Edited'),
                                    nls.localize('vueport/vbColor/editedCount',
                                        '{0} palette(s) changed, {1} renamed',
                                        String(colors.editedCount), String(colors.renamedCount)),
                                )}
                                {field(
                                    nls.localize('vueport/achievements/hardcore/title', 'Hardcore Mode'),
                                    nls.localize('vueport/achievements/hardcore/titleOff', 'Switched off'),
                                )}
                                {colors.created && field(
                                    nls.localize('vueport/vbColor/create/madeHere', 'Made With'),
                                    VB_COLOR_CREATED_VERSION,
                                )}
                            </div>
                            {entry.notes &&
                                <p className='vp-vbcolor-notes'>{entry.notes}</p>}
                            {colors.description &&
                                <p className='vp-vbcolor-notes'>{colors.description}</p>}
                        </fieldset>
                    </div>
                </div>
            </div>
            {actions}
        </>;
    }

    // --------------------------------------------------------------- detail

    const swatches = (
        paletteId: number,
        variant: string | undefined,
        values: string[],
    ): React.JSX.Element =>
        <div className='vp-colors-swatches'>
            {values.map((color, index) =>
                <ColorField
                    key={index}
                    value={color}
                    large
                    disabled={!colors.editable}
                    title={nls.localize(
                        'vueport/vbColor/swatchTitle', 'Palette {0}, color {1}',
                        String(paletteId), String(index))}
                    // While the picker is dragged: shown, not stored. See
                    // `previewColor`.
                    onPreview={hex => colors.previewColor(paletteId, variant, index, hex)}
                    onChange={hex => colors.setColor(paletteId, variant, index, hex)}
                />)}
        </div>;

    /**
     * What can be done to one color set: take a copy, put one in, find it, undo it.
     *
     * Per *set* and not per palette, which is the difference that matters for a
     * game like Galactic Pinball: a palette there carries a set per table, and
     * one Reset under all of them could only ever mean all of them. Copy and
     * Paste are the pair that makes 256 palettes bearable — pick colors once,
     * and put them wherever else they belong.
     *
     * Locate is here rather than once per palette for the same reason. It
     * paints the table entry, and a variant has its own entry, so flashing the
     * set in front of you is what somebody pressing it next to that set means.
     */
    const setActions = (paletteId: number, variant?: string): React.JSX.Element => {
        const copied = colors.copied;
        return <div className='vp-colors-palette-actions'>
            <button
                type='button'
                className='vp-button secondary'
                title={nls.localize('vueport/vbColor/copyTooltip', 'Copy these four colors')}
                onClick={() => colors.copySet(paletteId, variant)}
            >
                <Copy size={14} />
                {nls.localize('vueport/general/copy', 'Copy')}
            </button>
            <button
                type='button'
                className='vp-button secondary'
                disabled={!colors.editable || copied === undefined}
                title={copied
                    ? nls.localize(
                        'vueport/vbColor/pasteTooltip', 'Paste the copied colors: {0}', copied.join(', '))
                    : nls.localize('vueport/vbColor/pasteNothing', 'No colors have been copied yet')}
                onClick={() => colors.pasteInto(paletteId, variant)}
            >
                <ClipboardText size={14} />
                {nls.localize('vueport/general/paste', 'Paste')}
            </button>
            <button
                type='button'
                className='vp-button secondary'
                onClick={() => colors.flash(paletteId, variant)}
            >
                <Lightning size={14} />
                {nls.localize('vueport/vbColor/locate', 'Locate')}
            </button>
            {colors.editable &&
                <button
                    type='button'
                    className='vp-button secondary'
                    disabled={!colors.isSetEdited(paletteId, variant)}
                    onClick={() => colors.resetSet(paletteId, variant)}
                >
                    <ArrowCounterClockwise size={14} />
                    {nls.localize('vueport/vbColor/resetPalette', 'Reset')}
                </button>}
            {/* The badge belongs to the palette, not to one of its sets:
                what a sample found painting is a Color RAM slot. */}
            {variant === undefined && drawn?.has(paletteId) &&
                <span className='vp-colors-recent'>
                    <Eye size={13} />
                    {nls.localize('vueport/vbColor/recentlyDrawn', 'on screen')}
                </span>}
        </div>;
    };

    if (chosen) {
        return <>
            {back(() => setSelected(undefined))}
            <div className='vp-panel-detail vp-scroll'>
                <h3 className='vp-colors-object-name'>{chosen.name}</h3>
                {locked}
                {colors.palettesOf(chosen).map(paletteId => {
                    const palette = paletteById(paletteId);
                    if (!palette) {
                        return undefined;
                    }
                    // What the field shows: the half-typed name while it is
                    // being typed, and what the palette is called otherwise.
                    const shown = renaming?.id === paletteId ? renaming.value : name(palette);
                    return <fieldset key={paletteId} className='vp-inspector-group'>
                        {/*
                          * The legend is the name, and the name is editable.
                          *
                          * A generic color patch calls its palettes "BG Palette
                          * 37", which is true and no help at all; the first
                          * thing somebody does with one is work out what a
                          * palette is and write it down. A field rather than a
                          * pencil that opens a dialog, because renaming is the
                          * cheapest thing in the panel and should cost one
                          * click. Emptying it gives the patch's own name back.
                          *
                          * Nothing is stored per keystroke — see `renaming`.
                          * Enter commits, Escape puts the current name back
                          * and commits that, which stores nothing new.
                          */}
                        <legend>
                            {/* The wrapper carries the same text as the field,
                                which is what gives the field its width — see
                                the stylesheet. */}
                            <span className='vp-colors-palette-name' data-value={shown}>
                                <input
                                    type='text'
                                    spellCheck={false}
                                    /* A text field is twenty characters wide
                                       by default, and that width is what its
                                       grid cell would be sized to — so the
                                       copy beside it could never make the box
                                       any narrower. One character, and the
                                       copy decides. */
                                    size={1}
                                    maxLength={VB_COLOR_MAX_PALETTE_NAME}
                                    value={shown}
                                    title={nls.localize(
                                        'vueport/vbColor/renameTooltip',
                                        'Rename this palette. Leave it empty for the name the patch gives it.')}
                                    aria-label={nls.localize(
                                        'vueport/vbColor/rename', 'Rename palette {0}', String(paletteId))}
                                    onFocus={() => setRenaming({ id: paletteId, value: name(palette) })}
                                    onChange={event => setRenaming({ id: paletteId, value: event.target.value })}
                                    onBlur={event => {
                                        setRenaming(undefined);
                                        colors.setPaletteName(paletteId, event.target.value);
                                    }}
                                    onKeyDown={event => {
                                        if (event.key === 'Enter') {
                                            event.currentTarget.blur();
                                        } else if (event.key === 'Escape') {
                                            setRenaming({ id: paletteId, value: name(palette) });
                                            // The blur that follows commits the
                                            // name it already had, which is a
                                            // no-op — see `setPaletteName`.
                                            event.currentTarget.value = name(palette);
                                            event.currentTarget.blur();
                                        }
                                    }}
                                />
                            </span>
                        </legend>
                        {swatches(paletteId, undefined, palette.colors)}
                        {setActions(paletteId)}
                        {/* Color sets the patch chooses between itself — per
                            table, per theme. Which one is on screen is the
                            patch's business, so all of them are here, each
                            with its own copy, paste, locate and reset. */}
                        {palette.variants.map(variant =>
                            <div key={variant.name} className='vp-colors-variant'>
                                <span className='vp-colors-variant-name'>{variant.name}</span>
                                {swatches(paletteId, variant.name, variant.colors)}
                                {setActions(paletteId, variant.name)}
                            </div>)}
                    </fieldset>;
                })}
            </div>
            {actions}
        </>;
    }

    // ----------------------------------------------------------------- list

    const scenes = colors.scenes;

    return <>
        {header}
        <div className='vp-colors-top'>
            <Select
                value={scene ?? ''}
                disabled={scenes.length === 0}
                title={scenes.length === 0
                    ? nls.localize('vueport/vbColor/noScenes', 'This color patch defines no scenes')
                    : undefined}
                onChange={next => {
                    setScene(next || undefined);
                    colors.clearDrawn();
                }}
                options={[
                    { value: '', label: nls.localize('vueport/vbColor/allScenes', 'All scenes') },
                    ...scenes.map(item => ({ value: item.id, label: item.name })),
                ]}
            />
            {/* A button and not a filter that watches, because the list is
                being read while the game runs: pressing it takes a quarter of a
                second of what the game paints and narrows the
                list to those, and then leaves it alone. Pressing again takes a
                new sample — the list moves when asked and at no other time.

                Dead while the game is paused, because what it samples is the
                game painting: stopped, the only answer it could give is an
                empty screen, which is worse than no answer. Editing colors
                does work paused — the picture is composited again for each
                write — so this is the one control here that needs the game
                running. */}
            <button
                type='button'
                className='vp-button secondary'
                disabled={colors.sampling || colors.paused}
                title={colors.paused
                    ? nls.localize(
                        'vueport/vbColor/showCurrentPaused',
                        'Works only while the game is running. A paused game draws nothing to find.')
                    : nls.localize(
                        'vueport/vbColor/showCurrentTooltip',
                        'Show only palettes that are currently on screen')}
                onClick={() => colors.sampleDrawn()}
            >
                <Eye size={14} />
                {nls.localize('vueport/vbColor/showCurrent', 'Current')}
            </button>
            {drawn !== undefined &&
                <button
                    type='button'
                    className='vp-button secondary'
                    title={nls.localize('vueport/vbColor/showAllTooltip', 'Show every palette again')}
                    onClick={() => colors.clearDrawn()}
                >
                    <ArrowCounterClockwise size={14} />
                </button>}
            <button
                type='button'
                className='vp-button secondary'
                aria-label={nls.localize('vueport/vbColor/aboutPatch', 'About this color patch')}
                title={nls.localize('vueport/vbColor/aboutPatch', 'About this color patch')}
                onClick={() => setShowingInfo(true)}
            >
                <Info size={18} />
            </button>
        </div>
        <div className='vp-panel-filter'>
            <MagnifyingGlass size={15} />
            <input
                type='text'
                spellCheck={false}
                value={filter}
                placeholder={nls.localize('vueport/vbColor/filter', 'Filter')}
                aria-label={nls.localize('vueport/vbColor/filter', 'Filter')}
                onChange={event => setFilter(event.target.value)}
            />
            {filter &&
                <button
                    type='button'
                    className='vp-panel-filter-clear'
                    aria-label={nls.localize('vueport/general/clear', 'Clear')}
                    onClick={() => setFilter('')}
                >
                    <X size={14} />
                </button>}
        </div>
        {locked}

        <div className='vp-split-table vp-scroll'>
            {listed.length === 0
                ? <p className='vp-panel-empty'>
                    {drawn !== undefined
                        ? nls.localize('vueport/vbColor/noneDrawn',
                            'Nothing in this scene was being drawn when you asked. Try another'
                            + ' scene, or ask again from somewhere else in the game.')
                        : needle !== ''
                            ? nls.localize('vueport/vbColor/noMatch', 'Nothing matches “{0}”.', filter.trim())
                            : nls.localize('vueport/vbColor/noObjects', 'Nothing in this scene.')}
                </p>
                : <ul className='vp-panel-list'>
                    {listed.map(object => <li
                        key={object.id}
                        className={'vp-panel-row' + (objectIsEdited(object) ? ' enabled' : '')}
                        onClick={() => setSelected(object.id)}
                    >
                        <span className='vp-patches-summary'>
                            <span className='vp-panel-row-name'>{object.name}</span>
                            <span className='vp-patches-meta'>
                                {nls.localize('vueport/vbColor/paletteCount', '{0} palette(s)',
                                    String(colors.palettesOf(object).length))}
                                {objectIsEdited(object)
                                    && ` · ${nls.localize('vueport/vbColor/edited', 'edited')}`}
                                {objectIsDrawn(object)
                                    && ` · ${nls.localize('vueport/vbColor/recentlyDrawn', 'on screen')}`}
                            </span>
                        </span>
                        <span className='vp-colors-preview'>
                            {colors.palettesOf(object).slice(0, 1).flatMap(id =>
                                (paletteById(id)?.colors ?? []).map((color, index) =>
                                    <span
                                        key={`${id}-${index}`}
                                        className='vp-colors-chip'
                                        style={{ background: color }}
                                    />))}
                        </span>
                    </li>)}
                </ul>}
        </div>
        {actions}
    </>;
}
