import { MessageLoop } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import * as React from 'react';
import { createPortal } from 'react-dom';
import { EmulatorCommands } from '../emulator-commands';
import { MacroActivity } from '../emulator-macro-store';
import { EmulatorAction } from '../emulator-types';
import { RetroAchievementsService } from '../emulator-retroachievements';
import { VueportDock } from '../panels/emulator-dock';
import EmulatorCheatBadge from './EmulatorCheatBadge';
import EmulatorLeaderboardTracker from './EmulatorLeaderboardTracker';
import EmulatorMacroBadge from './EmulatorMacroBadge';
import EmulatorProfileBadge from './EmulatorProfileBadge';
import { EmulatorControlStrip } from './EmulatorControlStrip';
import { EmulatorStateBadges } from './EmulatorStateBadges';
import EmulatorMovieBadge from './EmulatorMovieBadge';
import EmulatorVideoBadge from './EmulatorVideoBadge';
import { EmulatorToolbarHost } from './EmulatorToolbar';

/**
 * What the emulator's chrome needs from the emulator itself.
 *
 * Everything the toolbar reads, plus the dock to show and the overlays to lay
 * over it.
 */
export interface EmulatorHost extends EmulatorToolbarHost {
    /** The panels: the screen, and whichever inspectors are open. */
    readonly dock: VueportDock;
    /** The controller reference and the palette and settings windows. */
    renderOverlay(): React.ReactNode;
    /**
     * The cheats, shown beside the screen — in Play mode and in Debug mode.
     *
     * Deliberately not a panel. They were one in Debug mode once, which made
     * the same list two things: a strip while playing and a dockable tab while
     * debugging, opened by one button that meant whichever the mode said. The
     * dock is for inspecting the machine; the cheats, the macros, the patches,
     * the colors and the achievements belong to the game, so all five are
     * rendered beside it instead and `state.showCheats` and its four siblings
     * are what say whether.
     */
    renderCheats(): React.ReactNode;
    /**
     * The running ROM's save states, beside the screen on the cheats' terms —
     * see `renderCheats`. `state.showSaveStates` is what says whether.
     *
     * Optional, unlike its siblings: the browser is the standalone build's,
     * and a host that has not adopted it leaves this out rather than having to
     * answer for a panel it does not have. See `EmulatorToolbarState`.
     */
    renderSaveStates?(): React.ReactNode;
    /**
     * The VB Color palette editor beside the screen, on the same terms as the
     * cheats — see `renderCheats`. `state.showColors` is what says whether.
     */
    renderColors(): React.ReactNode;
    /** How many cheats are switched on. */
    readonly activeCheats: number;
    /** Put them on screen beside the picture. */
    showCheats(): void;
    /**
     * The macros, shown beside the screen.
     *
     * The cheats' arrangement exactly, and for the same reasons — see
     * `renderCheats`. `state.showMacros` is what says whether.
     */
    renderMacros(): React.ReactNode;
    /** Whether a macro is being recorded, one is playing, or neither. */
    readonly macroActivity: MacroActivity;
    /** Whether a recorded input movie is driving the controller. */
    readonly moviePlaying: boolean;
    /** How far through it the machine is, and how long it runs, in frames. */
    readonly movieFrame: number;
    readonly movieLength: number;
    /** Stop it and hand the controller back; see `EmulatorMovieBadge`. */
    stopMoviePlayback(): void;
    /** Put them on screen beside the picture. */
    showMacros(): void;
    /**
     * Stop recording and throw away what was recorded.
     *
     * What the REC badge over the picture does. Thrown away rather than kept,
     * because keeping it means naming it and opening the editor on it, and a
     * badge pressed mid-game is somebody saying "stop that", not somebody
     * asking to be taken out of the game and shown a form.
     */
    cancelMacroRecording(): void;
    /** The registered ROM patches, shown beside the screen. */
    renderPatches(): React.ReactNode;
    /** Put the ROM patches on screen beside the picture. */
    showPatches(): void;
    /** Show the color editor beside the picture. */
    showColors(): void;
    /**
     * The RetroAchievements list, shown beside the screen.
     *
     * The cheats' and macros' arrangement exactly, and for the same reasons —
     * see `renderCheats`. `state.showAchievements` is what says whether, and
     * only one of the five strips is ever open at once.
     */
    renderAchievements(): React.ReactNode;
    /** Put it on screen beside the picture. */
    showAchievements(): void;
    /**
     * The account and the running set, for the leaderboard readout over the
     * picture.
     *
     * The service itself rather than the values, unlike the other two badges:
     * a running attempt's value changes many times a second, and only that
     * one small overlay should be redrawing at that rate. It subscribes for
     * itself — see `EmulatorLeaderboardTracker`.
     */
    readonly retroAchievements: RetroAchievementsService;
}

/**
 * Which set of chrome the emulator wears.
 *
 * `immersive` is a strip that floats over the picture and hides itself when
 * the pointer stops. Right for a host where the emulator IS the application:
 * a 384x224 image framed by a permanent toolbar is a picture in an IDE, and
 * what the controls cost in attention they do not earn back while somebody is
 * playing. What is switched on is said by the badges over the picture instead,
 * which do not hide.
 *
 * `hosted` is `immersive` with the strip taken out: the badges still sit over
 * the picture and the overlays still open, but the transport is somewhere the
 * host put it. Right for a host that has a row of its own to put it in — the
 * studio's title bar — where hiding it would be hiding a row that is already
 * there, and showing it over the picture as well would be two of them.
 *
 * `screen` is the picture and nothing else — no toolbar, no strip, no badges,
 * no overlay. For a linked player 2, whose transport, cheats and settings are
 * all player 1's; all it owns is a screen and its own controller.
 */
export type EmulatorChrome = 'immersive' | 'hosted' | 'screen';

/** How long the pointer must be still before the strip goes away. */
const STRIP_IDLE_DELAY = 6000;

export interface EmulatorProps {
    emulator: EmulatorHost;
    /**
     * Whether the emulator's own node is in the document yet.
     *
     * Lumino refuses to attach a widget to a host that is not itself attached,
     * and React effects run as soon as the tree commits — which can be before
     * the surrounding widget has been put anywhere. So the dock waits for this
     * to turn true rather than for the effect to fire.
     */
    attached: boolean;
    /**
     * Shown where the panels would be, and only then.
     *
     * For a host that has no ROM yet and something better to put there than an
     * empty dock — the standalone build's start page.
     */
    placeholder?: React.ReactNode;
    /** Defaults to `immersive`, which is the emulator with all of its own chrome. */
    chrome?: EmulatorChrome;
}

/**
 * The emulator, as one React component.
 *
 * The toolbar and the overlays are React. The dock is not: it is a Lumino
 * `DockPanel`, because panels that can be dragged, split, tabbed and resized
 * are what it is for, and Lumino does that without a framework. It is attached
 * into a container this component owns but never renders into — the same
 * arrangement the screen panel uses one level down for its canvas, and for the
 * same reason: some things have to keep their identity across renders.
 */
export function Emulator(props: EmulatorProps): React.JSX.Element {
    const { emulator, attached, placeholder, chrome = 'immersive' } = props;
    const dockHost = React.useRef<HTMLDivElement>(null);

    // Whether the floating strip is being held open regardless of the
    // pointer. Whether it is up on its own is not React state at all — see
    // the effect below, which toggles a class on the panel's own node
    // directly, the same way it is portalled into that node directly.
    const [pinned, setPinned] = React.useState(false);

    React.useEffect(() => {
        const host = dockHost.current;
        if (!host || !attached) {
            return undefined;
        }
        if (!emulator.dock.isAttached) {
            Widget.attach(emulator.dock, host);
        }
        // Lumino sizes a widget from resize messages, which normally arrive
        // from the layout that owns it. Nothing owns this one, so the
        // container's own size changes are what drive it.
        const observer = new ResizeObserver(() =>
            MessageLoop.sendMessage(emulator.dock, Widget.ResizeMessage.UnknownSize)
        );
        observer.observe(host);
        return () => {
            observer.disconnect();
            try {
                if (emulator.dock.isAttached) {
                    Widget.detach(emulator.dock);
                }
            } catch {
                // A linked player 2's dock is attached and detached as the pair
                // forms and breaks; Lumino occasionally sees the widget go on
                // its own first. Nothing to do but not throw out of a cleanup.
            }
        };
    }, [emulator.dock, attached]);

    const showingPlaceholder = placeholder !== undefined;
    // Drives the floating strip and the pointer-tracking that hides it. Not
    // `hosted`, which wears everything else `immersive` does but keeps its
    // transport in a row of the host's own.
    const immersive = chrome === 'immersive' && !showingPlaceholder;
    // A bare screen: no chrome of its own, no overlay, no badges — see the
    // `EmulatorChrome` note. Player 2 in a linked pair.
    const bare = chrome === 'screen';

    /*
     * The strip comes back whenever the pointer moves over the screen panel
     * — the same node it now lives inside of, see `strip` on
     * `ScreenPanel` — and goes again once it has been still for a
     * while.
     *
     * Scoped to the screen panel rather than the whole emulator body: in
     * Debug mode that panel is one tile among several, and a pointer resting
     * on an unrelated one — Memory Pools, the log — has no bearing on
     * whether the screen's own transport should be up.
     *
     * Pinned, none of this runs at all — no listener, no timer, nothing to
     * wake up. The strip is simply up.
     */
    React.useEffect(() => {
        const area = emulator.dock.screen.node;
        const stripNode = emulator.dock.screen.strip;
        if (!immersive || pinned) {
            stripNode.classList.remove('vp-strip-layer-idle');
            return undefined;
        }
        let timer: ReturnType<typeof setTimeout> | undefined;
        // Set only while the pointer rests inside the strip itself. A pointer
        // that has stopped there fires no more `pointermove` to push the
        // timer back, so the timer's own callback has to know not to act.
        let overStrip = false;

        const clear = (): void => {
            if (timer) {
                clearTimeout(timer);
                timer = undefined;
            }
        };
        const scheduleHide = (): void => {
            clear();
            timer = setTimeout(() => {
                if (!overStrip) {
                    stripNode.classList.add('vp-strip-layer-idle');
                }
            }, STRIP_IDLE_DELAY);
        };
        const wake = (): void => {
            stripNode.classList.remove('vp-strip-layer-idle');
            scheduleHide();
        };
        wake();
        area.addEventListener('pointermove', wake);

        // A pointer that leaves the whole panel takes the strip with it
        // rather than waiting out the delay: it is on its way somewhere else.
        const leaveArea = (): void => {
            overStrip = false;
            clear();
            stripNode.classList.add('vp-strip-layer-idle');
        };
        area.addEventListener('pointerleave', leaveArea);

        // Resting on the strip pauses the countdown outright; leaving it
        // again — while the pointer is still somewhere over the picture —
        // starts a fresh one rather than cutting it immediately, the same
        // grace a pointer moving across the picture gets.
        const enterStrip = (): void => {
            overStrip = true;
            clear();
        };
        const leaveStrip = (): void => {
            overStrip = false;
            scheduleHide();
        };
        stripNode.addEventListener('pointerenter', enterStrip);
        stripNode.addEventListener('pointerleave', leaveStrip);

        return () => {
            clear();
            area.removeEventListener('pointermove', wake);
            area.removeEventListener('pointerleave', leaveArea);
            stripNode.removeEventListener('pointerenter', enterStrip);
            stripNode.removeEventListener('pointerleave', leaveStrip);
        };
    }, [immersive, pinned, emulator.dock.screen]);

    /*
     * The strips, in both modes alike.
     *
     * Debug mode used to dock each of these as a panel instead, which meant
     * one list reachable two ways, a title-bar button that meant something
     * different depending on the mode, and a cheat list that moved when
     * somebody pressed the bug. They sit beside the screen now whatever the
     * mode — the dock is for inspecting the machine, and these five belong to
     * the game.
     *
     * Only one of the five is open at a time: the host enforces that when it
     * sets these flags.
     */
    const saveStatesBeside =
        (emulator.state.showSaveStates ?? false) && emulator.renderSaveStates && !showingPlaceholder;
    const cheatsBeside = emulator.state.showCheats && !showingPlaceholder;
    const macrosBeside = emulator.state.showMacros && !showingPlaceholder;
    const colorsBeside = emulator.state.showColors && !showingPlaceholder;
    const patchesBeside = emulator.state.showPatches && !showingPlaceholder;
    const achievementsBeside = emulator.state.showAchievements && !showingPlaceholder;

    /*
     * What is going on that the picture itself does not show: a cheat holding
     * a value, a macro recording or playing, a profile being taken.
     *
     * Both are properties of what is running rather than of the layout, which
     * is why they sit over the picture and follow it wherever the dock puts
     * it. The screen panel is imperative DOM, so they go in through the slot
     * it offers rather than being rendered by it.
     */
    const badges = !showingPlaceholder && !bare
        ? createPortal(
            <>
                {emulator.activeCheats > 0 &&
                    <EmulatorCheatBadge
                        count={emulator.activeCheats}
                        onShow={() => emulator.showCheats()}
                    />
                }
                {/* Shown whether or not the macros are beside the screen,
                    unlike the cheats' badge. A cheat that is on is a standing
                    setting, and having its list open says so; a recording is
                    an event, and one that has been running for ten minutes is
                    worth saying loudly wherever the panel happens to be. */}
                <EmulatorMacroBadge
                    activity={emulator.macroActivity}
                    onShow={() => emulator.showMacros()}
                    onCancelRecording={() => emulator.cancelMacroRecording()}
                />
                {/* Whatever mode the emulator is in. The toolbar's own stop
                    button is a Debug mode control, and profiling does not end
                    when somebody switches to Play — which is precisely when
                    nothing else is left saying it is running. */}
                <EmulatorProfileBadge
                    profiling={emulator.profiling}
                    onStop={() => emulator.runCommand(EmulatorCommands.PROFILE_STOP.id)}
                />
                {/* A recorded run driving the controller. Beside the macro
                    badge because it is the same kind of news — something other
                    than the player is pressing the buttons — and a good deal
                    more surprising when nobody remembers starting it. */}
                <EmulatorMovieBadge
                    playing={emulator.moviePlaying}
                    frame={emulator.movieFrame}
                    length={emulator.movieLength}
                    onStop={() => emulator.stopMoviePlayback()}
                />
                {/* A video recording, for the profile badge's reasons: the
                    button that stops it lives in a strip that hides itself,
                    and the file does not exist until it is stopped. */}
                <EmulatorVideoBadge
                    recording={emulator.recordingVideo ?? false}
                    seconds={() => emulator.recordedSeconds?.() ?? 0}
                    onStop={() => emulator.runAction(EmulatorAction.VideoRecord)}
                />
                {/* A leaderboard attempt in progress: the timer or score the
                    player is racing, which is no use to them in a panel. */}
                <EmulatorLeaderboardTracker achievements={emulator.retroAchievements} />
            </>,
            emulator.dock.screen.badges,
        )
        : undefined;

    /*
     * And, in the opposite corner, what the machine is doing — but only where
     * the chrome hides itself. With a toolbar up its lit buttons say the same
     * thing, and saying it twice a hand's width apart is noise.
     */
    const stateBadges = immersive
        ? createPortal(<EmulatorStateBadges host={emulator} />, emulator.dock.screen.stateBadges)
        : undefined;

    /*
     * The floating transport itself, portalled into the screen panel's own
     * node rather than rendered where this component sits — the same reason
     * the badges above are. In Play mode that node fills the whole dock and
     * the difference is invisible; in Debug mode the screen is one tile among
     * several, and this is what keeps the strip inside it rather than
     * floating over whatever panel happens to be in front. Tabbed out of
     * view, the node it portals into is hidden along with the rest of the
     * panel, and the strip goes with it — nothing to reach for when there is
     * no picture to reach for it over.
     *
     * No wrapping div and no idle class here: the node this portals into
     * already carries `.vp-strip-layer`, created once by the panel
     * itself, and the pointer-tracking effect above toggles its idle class
     * directly rather than through a render.
     */
    const strip = immersive
        ? createPortal(
            <EmulatorControlStrip
                host={emulator}
                pinned={pinned}
                onTogglePinned={() => setPinned(was => !was)}
            />,
            emulator.dock.screen.strip,
        )
        : undefined;

    return <>
        {showingPlaceholder && <div className='vp-placeholder vp-scroll'>{placeholder}</div>}
        {/* A row, so the cheats can sit beside the screen rather than in the
            dock with it. The dock keeps the space the cheats do not take.

            Hidden rather than unmounted while the placeholder is up: the dock
            is a Lumino widget attached to the node inside this one, and taking
            that node away would leave it attached to something no longer in
            the document. Hidden here rather than on the dock's own container,
            because this row is what claims the height — leave it laid out and
            it takes a share the start page should have had. */}
        <div
            className='vp-body'
            style={showingPlaceholder ? { display: 'none' } : undefined}
        >
            <div className='vp-dock-host' ref={dockHost} />
            {saveStatesBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderSaveStates?.()}
                </aside>
            }
            {cheatsBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderCheats()}
                </aside>
            }
            {macrosBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderMacros()}
                </aside>
            }
            {patchesBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderPatches()}
                </aside>
            }
            {colorsBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderColors()}
                </aside>
            }
            {achievementsBeside &&
                <aside className='vp-panel-aside vp-split vp-scroll'>
                    {emulator.renderAchievements()}
                </aside>
            }
        </div>
        {!bare &&
            <div className='vp-overlay-layer'>
                {emulator.renderOverlay()}
            </div>
        }
        {badges}
        {stateBadges}
        {strip}
    </>;
}
