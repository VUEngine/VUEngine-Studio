import { VideoCamera } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';

/** `0:07`, `12:40` — the clock every recorder has ever shown. */
function formatDuration(seconds: number): string {
    const whole = Math.floor(Math.max(0, seconds));
    return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
}

/**
 * That a video is being recorded, over the corner of the picture.
 *
 * The profile badge's sibling, and there for the same reasons: a recording
 * costs something for as long as it runs, the button that stops it may be in a
 * hidden strip, and the file only exists once it is stopped. Red and blinking,
 * because that is what a record light is.
 *
 * It counts on a clock of its own rather than being redrawn by the emulator.
 * A running recording would otherwise make the whole chrome re-render once a
 * second for the sake of one number — and that number is the only thing here
 * that changes.
 */
export default function EmulatorVideoBadge(props: {
    recording: boolean,
    /**
     * How long it has been running, asked for rather than passed in: the badge
     * decides when to look, so nothing above it has to keep a timer.
     */
    seconds(): number,
    onStop: () => void,
}): React.JSX.Element | null {
    const { recording, seconds, onStop } = props;
    const [shown, setShown] = React.useState(0);

    React.useEffect(() => {
        if (!recording) {
            return undefined;
        }
        setShown(seconds());
        // Twice a second, so the count never sits a whole second behind what
        // it should say — a clock that ticks on its own schedule drifts
        // visibly against one that ticks on the recording's.
        const timer = setInterval(() => setShown(seconds()), 500);
        return () => clearInterval(timer);
    }, [recording, seconds]);

    if (!recording) {
        return null;
    }
    return <button
        type='button'
        className='vp-screen-badge vp-video-badge live'
        aria-label={nls.localize('vueport/video/badge',
            'A video recording is running. Stop it and save the file.')}
        onClick={onStop}
    >
        <VideoCamera size={16} weight='fill' />
        {formatDuration(shown)}
    </button>;
}
