import * as React from 'react';
import { nls } from '../../../common/emulator-nls';
import { EmulatorGamePadButton } from '../../emulator-commands';
import { pushEscapeLayer } from '../kit/escape-layers';

/**
 * The shell both input pages wear.
 *
 * The keyboard pages and the Game Pads page ask entirely different questions —
 * one binds key codes to commands, the other binds a physical controller's
 * buttons and axes to a per-device profile — but they answer them in the same
 * shape: the controller drawn with its bindings written on it, a strip under it
 * that waits for a press, a row of presets, and the same bindings again as two
 * lists to read straight down. That shape is here, so it is one answer rather
 * than two that drift apart.
 *
 * Nothing in this file knows what a binding is. Each page keeps its own state
 * and hands these the text.
 */

/** A walk through every button, one press at a time. */
export interface CaptureRun {
    step: number;
    total: number;
    queue: EmulatorGamePadButton[];
}

/**
 * The keys pressed while a capture is running.
 *
 * On an escape layer, so a window opened over this one gets the key first, and
 * in the capture phase, because the emulator's own key handler is listening on
 * the page and must not see the key being bound. Installed only when a capture
 * starts or ends — not once per step of a run — so the layer does not flicker
 * as the run advances.
 *
 * What a key means is the page's: the keyboard pages bind it, the Game Pads
 * page watches only for Escape and takes its bindings off the controller.
 */
export function useCaptureKeys(waiting: boolean, onKey: (event: KeyboardEvent) => void): void {
    // Read through a ref rather than closed over, so a run's later steps are
    // not still answering the first one's question.
    const handle = React.useRef(onKey);
    handle.current = onKey;
    React.useEffect(() => {
        if (!waiting) {
            return undefined;
        }
        const layer = pushEscapeLayer();
        const onKeyDown = (event: KeyboardEvent): void => {
            if (layer.isTop()) {
                handle.current(event);
            }
        };
        window.addEventListener('keydown', onKeyDown, true);
        return () => {
            window.removeEventListener('keydown', onKeyDown, true);
            layer.dispose();
        };
    }, [waiting]);
}

/**
 * The strip under the picture, while a press is being waited for.
 *
 * In the same card as the picture rather than in a modal, so the control being
 * asked for stays in view, lit, while it waits.
 */
export function CaptureStrip(props: {
    /** What is being bound — a button's name, or a command's. */
    title: React.ReactNode,
    /** Set while walking every button, which is what puts "3 of 14" beside the title. */
    run?: CaptureRun,
    /** How to answer: press a key, press a control on your controller. */
    prompt: React.ReactNode,
    /** What is bound right now, or what a run promises about saving. */
    detail: React.ReactNode,
    /** Cancel, and whatever else this page offers for the binding at hand. */
    actions: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-input-capture'>
        <div className='vp-input-capture-head'>
            <span className='vp-input-capture-title'>{props.title}</span>
            {props.run &&
                <span className='vp-input-step-count'>
                    {nls.localize('vueport/input/setAllStep', '{0} of {1}',
                        String(props.run.step), String(props.run.total))}
                </span>}
        </div>
        <p className='vp-input-capture-prompt'>{props.prompt}</p>
        {props.detail}
        <div className='vp-input-capture-actions'>{props.actions}</div>
    </div>;
}

/** The button that gets out of a capture without changing anything. */
export function CancelCapture(props: { onClick: () => void }): React.JSX.Element {
    return <button type='button' className='vp-button secondary' onClick={props.onClick}>
        {nls.localize('vueport/state/cancel', 'Cancel')}
    </button>;
}

/**
 * One binding in a list — the whole row is the button that rebinds it.
 *
 * Lit when the pointer is over it or over the control it names on the picture,
 * so the two halves of the page point at each other.
 */
export function BindingRow(props: {
    name: React.ReactNode,
    /** The key or control it answers to, or the "press…" prompt while waiting. */
    value: React.ReactNode,
    lit?: boolean,
    waiting?: boolean,
    onClick: () => void,
    onHoverIn?: () => void,
    onHoverOut?: () => void,
}): React.JSX.Element {
    return <button
        type='button'
        className={'vp-input-row'
            + (props.lit ? ' is-lit' : '')
            + (props.waiting ? ' is-waiting' : '')}
        onClick={props.onClick}
        onMouseEnter={props.onHoverIn}
        onMouseLeave={props.onHoverOut}
    >
        <span className='vp-input-row-name'>{props.name}</span>
        <span className={'vp-input-key' + (props.waiting ? ' is-waiting' : '')}>
            {props.value}
        </span>
    </button>;
}

/** A titled list of bindings, beside or under the picture. */
export function BindingList(props: {
    title: string,
    children: React.ReactNode,
}): React.JSX.Element {
    return <fieldset className='vp-input-list'>
        <legend className='vp-panel-list-header'>{props.title}</legend>
        {props.children}
    </fieldset>;
}

/** A whole layout in one press, plus whatever else the row carries at its end. */
export function PresetRow(props: {
    /** The pills, in the order they are offered. */
    children: React.ReactNode,
    /** Pushed to the far end of the row — "Set all buttons…", and the like. */
    trailing?: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-preset-row'>
        <span className='vp-preset-label'>
            {nls.localize('vueport/input/presets', 'Presets')}
        </span>
        {props.children}
        <span className='vp-input-spacer' />
        {props.trailing}
    </div>;
}

export function PresetPill(props: {
    label: string,
    /** Marked as the one the bindings currently match. */
    current?: boolean,
    onClick: () => void,
}): React.JSX.Element {
    return <button
        type='button'
        className={'vp-preset-pill' + (props.current ? ' is-current' : '')}
        onClick={props.onClick}
    >
        {props.label}
    </button>;
}

/** The button that walks every control in one run. */
export function SetAllButton(props: { label: string, onClick: () => void }): React.JSX.Element {
    return <button type='button' className='vp-button secondary' onClick={props.onClick}>
        {props.label}
    </button>;
}

/** The two controller halves, side by side above the capture strip. */
export function PadDiagrams(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-diagrams'>{props.children}</div>;
}

/**
 * One page of the input settings: the tab strip and whatever that page carries
 * beside it, then the page itself.
 *
 * The strip is handed in rather than drawn here, because which page is showing
 * is the pane's business — see `InputSettings` — while what else belongs in the
 * row is the page's: whether player two has keys of its own, which controller
 * is being configured, which player it drives.
 */
export function InputPage(props: {
    top: React.ReactNode,
    children: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-input-settings'>
        <div className='vp-input-top'>{props.top}</div>
        {props.children}
    </div>;
}

/** Pushes whatever follows it to the far end of a row. */
export function InputSpacer(): React.JSX.Element {
    return <span className='vp-input-spacer' />;
}

/**
 * The controller a page has found, named as the Game Pads page names it.
 *
 * Every page of the pane carries it in the same place — beside the tab strip,
 * before the spacer — so that moving between them does not move the pad's name
 * from one end of the row to the other.
 */
export function PadBadge(props: { label?: string, title?: string }): React.JSX.Element {
    return <span className='vp-input-pad' title={props.title}>
        <span className='vp-input-pad-dot' />
        {props.label}
    </span>;
}

/** The picture, the capture strip and the presets, in one titled card. */
export function BindingCard(props: { children: React.ReactNode }): React.JSX.Element {
    return <fieldset className='vp-input-pad-card'>
        <legend className='vp-panel-list-header'>
            {nls.localize('vueport/input/assignments', 'Assignments')}
        </legend>
        {props.children}
    </fieldset>;
}

/** The card and the lists, which wrap under it when the window is narrow. */
export function BindingBody(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-body'>{props.children}</div>;
}

export function BindingLists(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-lists'>{props.children}</div>;
}
