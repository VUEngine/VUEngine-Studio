import * as React from 'react';
import { nls } from '../../../common/emulator-nls';
import { VUEPORT_DEFAULTS, VueportSettings } from '../../../common/emulator-settings';
import { TURBO_RATE_RANGE, clampTurboRate } from '../../../common/emulator-turbo';
import { VB_FRAME_RATE } from '../../../common/vb-constants';
import { EmulatorGamePadButton } from '../../emulator-commands';
import { pushEscapeLayer } from '../kit/escape-layers';

// the shell both input pages share: the controller drawn with its bindings, a strip under it waiting for a press,
// a row of presets, and the bindings again as two lists. Nothing here knows what a binding is; each page keeps its
// own state and hands these the text

// a walk through every button, one press at a time
export interface CaptureRun {
    step: number;
    total: number;
    queue: EmulatorGamePadButton[];
}

/**
 * On an escape layer, so a window opened over this one gets the key first, and in the capture phase, so the
 * emulator's own key handler on the page does not see the key being bound. Installed only when a capture starts or
 * ends, not per step of a run, so the layer does not flicker. The keyboard pages bind the key, the Game Pads page
 * only watches for Escape
 */
export function useCaptureKeys(waiting: boolean, onKey: (event: KeyboardEvent) => void): void {
    // read through a ref, so a run's later steps are not still answering the first one's question
    const handle = React.useRef(onKey);
    handle.current = onKey;
    React.useEffect(() => {
        if (!waiting) {
            return undefined;
        }
        const layer = pushEscapeLayer();
        const onKeyDown = (event: KeyboardEvent): void => {
            if (layer.isTop()) {
                handle.current(event);
            }
        };
        window.addEventListener('keydown', onKeyDown, true);
        return () => {
            window.removeEventListener('keydown', onKeyDown, true);
            layer.dispose();
        };
    }, [waiting]);
}

// in the same card as the picture rather than a modal, so the control being asked for stays in view, lit
export function CaptureStrip(props: {
    // a button's name, or a command's
    title: React.ReactNode,
    // set while walking every button, which puts "3 of 14" beside the title
    run?: CaptureRun,
    // press a key, press a control on your controller
    prompt: React.ReactNode,
    // what is bound right now, or what a run promises about saving
    detail: React.ReactNode,
    // cancel, and whatever else this page offers for the binding at hand
    actions: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-input-capture'>
        <div className='vp-input-capture-head'>
            <span className='vp-input-capture-title'>{props.title}</span>
            {props.run &&
                <span className='vp-input-step-count'>
                    {nls.localize('vueport/input/setAllStep', '{0} of {1}',
                        String(props.run.step), String(props.run.total))}
                </span>}
        </div>
        <p className='vp-input-capture-prompt'>{props.prompt}</p>
        {props.detail}
        <div className='vp-input-capture-actions'>{props.actions}</div>
    </div>;
}

export function CancelCapture(props: { onClick: () => void }): React.JSX.Element {
    return <button type='button' className='vp-button secondary' onClick={props.onClick}>
        {nls.localize('vueport/state/cancel', 'Cancel')}
    </button>;
}

// the whole row is the button that rebinds it. Lit when the pointer is over it or over the control it names on the
// picture, so the two halves of the page point at each other
export function BindingRow(props: {
    name: React.ReactNode,
    // the key or control it answers to, or the "press..." prompt while waiting
    value: React.ReactNode,
    lit?: boolean,
    waiting?: boolean,
    // bound differently from the preset the mapping started from
    changed?: boolean,
    changedTitle?: string,
    onClick: () => void,
    onHoverIn?: () => void,
    onHoverOut?: () => void,
}): React.JSX.Element {
    return <button
        type='button'
        className={'vp-input-row'
            + (props.lit ? ' is-lit' : '')
            + (props.waiting ? ' is-waiting' : '')
            + (props.changed ? ' is-changed' : '')}
        title={props.changedTitle}
        onClick={props.onClick}
        onMouseEnter={props.onHoverIn}
        onMouseLeave={props.onHoverOut}
    >
        <span className='vp-input-row-name'>{props.name}</span>
        <span className={'vp-input-key' + (props.waiting ? ' is-waiting' : '')}>
            {props.value}
        </span>
    </button>;
}

export function BindingList(props: {
    title: string,
    children: React.ReactNode,
}): React.JSX.Element {
    return <fieldset className='vp-input-list'>
        <legend className='vp-panel-list-header'>{props.title}</legend>
        {props.children}
    </fieldset>;
}

// a whole layout in one press, plus whatever else the row carries at its end
export function PresetRow(props: {
    children: React.ReactNode,
    // pushed to the far end of the row: "Set all buttons...", and the like
    trailing?: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-preset-row'>
        <span className='vp-preset-label'>
            {nls.localize('vueport/input/presets/title', 'Presets')}
        </span>
        {props.children}
        <span className='vp-input-spacer' />
        {props.trailing}
    </div>;
}

export function PresetPill(props: {
    label: string,
    // the one the bindings currently match
    current?: boolean,
    onClick: () => void,
}): React.JSX.Element {
    return <button
        type='button'
        className={'vp-preset-pill' + (props.current ? ' is-current' : '')}
        onClick={props.onClick}
    >
        {props.label}
    </button>;
}

export function SetAllButton(props: { label: string, onClick: () => void }): React.JSX.Element {
    return <button type='button' className='vp-button secondary' onClick={props.onClick}>
        {props.label}
    </button>;
}

// the two controller halves, side by side above the capture strip
export function PadDiagrams(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-diagrams'>{props.children}</div>;
}

// the tab strip is handed in, as which page shows is the pane's business (see InputSettings), while what else
// belongs in the row is the page's: player two's keys, which controller, which player it drives
export function InputPage(props: {
    top: React.ReactNode,
    children: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-input-settings'>
        <div className='vp-input-top'>{props.top}</div>
        {props.children}
    </div>;
}

// pushes whatever follows it to the far end of a row
export function InputSpacer(): React.JSX.Element {
    return <span className='vp-input-spacer' />;
}

// in the same place on every page, beside the tab strip and before the spacer, so the pad's name does not jump
export function PadBadge(props: { label?: string, title?: string }): React.JSX.Element {
    return <span className='vp-input-pad' title={props.title}>
        <span className='vp-input-pad-dot' />
        {props.label}
    </span>;
}

// the picture, the capture strip and the presets, in one titled card
export function BindingCard(props: { children: React.ReactNode }): React.JSX.Element {
    return <fieldset className='vp-input-pad-card'>
        <legend className='vp-panel-list-header'>
            {nls.localize('vueport/input/assignments', 'Assignments')}
        </legend>
        {props.children}
    </fieldset>;
}

// the lists wrap under the card when the window is narrow
export function BindingBody(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-body'>{props.children}</div>;
}

export function BindingLists(props: { children: React.ReactNode }): React.JSX.Element {
    return <div className='vp-input-lists'>{props.children}</div>;
}

// one setting for every turbo button, keyboard and pad alike. Runs slow to fast, the reverse of the setting's frames
// per half period, and shows presses a second. Marked like the Game Pads page's sliders when off the default
export function TurboRateSlider(props: {
    settings: VueportSettings,
    onChange?: () => void,
}): React.JSX.Element {
    const { settings, onChange } = props;
    const [, bump] = React.useReducer((n: number) => n + 1, 0);
    const rate = clampTurboRate(settings.get('turboRate'));
    const standard = clampTurboRate(settings.defaults?.turboRate ?? VUEPORT_DEFAULTS.turboRate);
    const flip = (value: number): number => TURBO_RATE_RANGE.min + TURBO_RATE_RANGE.max - value;
    const perSecond = VB_FRAME_RATE / (2 * rate);
    return <label
        className={'vp-gamepad-deadzone' + (rate !== standard ? ' is-changed' : '')}
        title={nls.localize(
            'vueport/input/turbo/rateHint',
            'How often a turbo button presses itself while you hold it. The same for every turbo button.',
        )}
    >
        {nls.localize('vueport/input/turbo/rate', 'Turbo speed')}
        <input
            type='range'
            min={TURBO_RATE_RANGE.min}
            max={TURBO_RATE_RANGE.max}
            step={1}
            value={flip(rate)}
            onChange={event => {
                settings.set('turboRate', flip(Number(event.target.value))).catch(() => undefined);
                bump();
                onChange?.();
            }}
        />
        <span className='vp-gamepad-changed' />
        <span className='vp-gamepad-deadzone-value'>
            {nls.localize('vueport/input/turbo/perSecond', '{0}/s',
                perSecond.toFixed(perSecond < 10 ? 1 : 0))}
        </span>
    </label>;
}

// the button's name, marked as the turbo one
export function TurboTitle(props: { name: React.ReactNode }): React.JSX.Element {
    return <>{props.name} ({nls.localize('vueport/input/turbo/title', 'Turbo')})</>;
}
