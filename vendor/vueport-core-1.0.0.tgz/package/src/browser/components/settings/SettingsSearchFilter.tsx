import * as React from 'react';

/**
 * The settings search, for a pane that is written by hand.
 *
 * The schema-backed panes filter themselves: they know which settings they
 * hold and what each is called (see `SettingsFields`). A hand-written pane has
 * no such list — its rows are whatever it renders — so this reads them off the
 * page instead, the same way somebody looking at the pane would.
 *
 * A row is one of the setting layouts the panes share (`ROW`); a group is a
 * fieldset, which shows in full when its legend matches and otherwise only for
 * the rows in it that do, and goes when none of them does. Anything else — a
 * note, a status line, the library's tiles — stays when its own text matches.
 * When nothing in the pane matches, the query was meant for the pane's label or
 * keywords rather than a row, and everything is shown, as the schema panes do.
 *
 * Read again on every change below it, since a pane redraws by itself: a
 * switch that brings more rows with it, a scan that finishes, a chunk that
 * arrives.
 */
export function SettingsSearchFilter(props: {
    search: string,
    children: React.ReactNode,
}): React.JSX.Element {
    const root = React.useRef<HTMLDivElement>(null);
    const { search } = props;

    React.useLayoutEffect(() => {
        const element = root.current;
        if (!element) {
            return;
        }
        const terms = search.toLowerCase().split(/\s+/).filter(Boolean);
        const apply = (): void => {
            element.querySelectorAll(`[${HIDDEN}]`).forEach(each => each.removeAttribute(HIDDEN));
            if (terms.length === 0) {
                return;
            }
            const hidden: Element[] = [];
            if (filter(element, terms, hidden)) {
                hidden.forEach(each => each.setAttribute(HIDDEN, ''));
            }
        };
        apply();
        // Attributes are not watched, so marking rows does not call this again.
        const observer = new MutationObserver(apply);
        observer.observe(element, { childList: true, subtree: true, characterData: true });
        return () => observer.disconnect();
    }, [search]);

    return <div ref={root} style={{ display: 'contents' }}>{props.children}</div>;
}

/** What the pane's stylesheet hides. */
const HIDDEN = 'data-settings-search-hidden';

/** The layouts one setting is drawn in, title, description and control together. */
const ROW = '.vp-bool-setting, .vp-range-setting, .vp-select-setting, .vp-appearance-row';

/**
 * Whether every word of the query is on the element. The words in its fields
 * count too, which say what they are for only in a placeholder or a label read
 * out loud — the Achievements sign-in's user name and password.
 */
function matches(element: Element, terms: string[]): boolean {
    const named = Array.from(element.querySelectorAll('[placeholder], [aria-label]'), each =>
        `${each.getAttribute('placeholder') ?? ''} ${each.getAttribute('aria-label') ?? ''}`);
    const text = [element.textContent ?? '', ...named].join(' ').toLowerCase();
    return terms.every(term => text.includes(term));
}

/**
 * Collects what the query hides below `container` into `hidden`, and answers
 * whether anything there stays on screen.
 */
function filter(container: Element, terms: string[], hidden: Element[]): boolean {
    let any = false;
    for (const child of Array.from(container.children)) {
        let shows: boolean;
        if (child.tagName === 'LEGEND') {
            continue;
        } else if (child.tagName === 'FIELDSET') {
            const legend = child.querySelector(':scope > legend');
            shows = (legend !== null && matches(legend, terms)) || filter(child, terms, hidden);
        } else if (child.matches(ROW)) {
            shows = matches(child, terms);
        } else if (child.querySelector(`${ROW}, fieldset`)) {
            // A wrapper around rows rather than a row: decided by what it holds.
            shows = filter(child, terms, hidden);
        } else {
            shows = matches(child, terms);
        }
        if (shows) {
            any = true;
        } else {
            hidden.push(child);
        }
    }
    return any;
}
