import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { VueportConfig } from '../../../common/emulator-settings';
import { EmulatorDecoration } from '../../emulator-types';
import EmulatorPalettes from '../EmulatorPalettes';
import {
    ChoiceSetting,
    DecorationColorSetting,
    RenderingModeSetting,
    SettingsFields,
    SettingsPaneProps,
    SettingsRow,
    SliderSetting,
    useSetting,
} from './SettingFields';

/** What the Display pane is handed beyond the settings themselves. */
interface DisplayProps extends SettingsPaneProps {
    /**
     * Whether VB Color hardware is driving the picture. Passed through to the
     * decoration color, which is the one control here that answers differently
     * for it — see {@link DecorationColorSetting}.
     */
    vbcHardwareActive?: boolean;
}

/**
 * How the picture is drawn, above the palette pickers.
 *
 * The intensity only means something for the two decorations that cast a halo,
 * so it only joins the row when one of those is chosen. The color goes further
 * still: only Ambient reads it at all — Immersion takes its color from the
 * picture itself — so it joins only then, after the intensity.
 */
function DisplayFields(props: DisplayProps): React.JSX.Element {
    const decoration = useSetting(props.settings, 'decoration');
    const ambient = decoration === EmulatorDecoration.AMBIENT;
    const halo = ambient || decoration === EmulatorDecoration.IMMERSION;
    const decorationIds: (keyof VueportConfig)[] = ['decoration'];
    if (halo) {
        decorationIds.push('decorationIntensity');
    }
    if (ambient) {
        decorationIds.push('decorationColor');
    }
    return <SettingsFields {...props} ids={['renderingMode', 'scale', ...decorationIds]}>
        <RenderingModeSetting id='renderingMode' />
        <ChoiceSetting id='scale' />
        <SettingsRow ids={decorationIds}>
            <ChoiceSetting id='decoration' />
            {halo && <SliderSetting id='decorationIntensity' />}
            {ambient && <DecorationColorSetting vbcHardware={props.vbcHardwareActive} />}
        </SettingsRow>
    </SettingsFields>;
}

/**
 * The Display pane: the rendering mode, the scale and the screen decoration,
 * then the colors the picture is shown in, with the running picture in the
 * column beside them so a change lands where it can be seen.
 */
export default function DisplaySettings(props: DisplayProps & {
    notifications: VueportNotifications,
    /** The running picture. Passed in, because where it comes from is the host's. */
    preview?: React.ReactNode,
}): React.JSX.Element {
    return <EmulatorPalettes
        settings={props.settings}
        notifications={props.notifications}
        preview={props.preview}
    >
        <DisplayFields {...props} />
    </EmulatorPalettes>;
}
