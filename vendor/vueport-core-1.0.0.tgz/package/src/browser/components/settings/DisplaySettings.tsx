import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { VueportConfig } from '../../../common/emulator-settings';
import { EmulatorDecoration } from '../../emulator-types';
import { VbRenderingMode } from '../../../common/vb-constants';
import EmulatorPalettes from '../EmulatorPalettes';
import {
    ChoiceSetting,
    DecorationColorSetting,
    RenderingModeSetting,
    SettingsFields,
    SettingsPaneProps,
    SettingsRow,
    SliderSetting,
    SwitchSetting,
    useSetting,
} from './SettingFields';

/** What the Display pane is handed beyond the settings themselves. */
interface DisplayProps extends SettingsPaneProps {
    /**
     * Whether VB Color hardware is driving the picture. Passed through to the
     * decoration color, which is the one control here that answers differently
     * for it — see {@link DecorationColorSetting}.
     */
    vbcHardwareActive?: boolean;
    /** The palette pickers, placed below the scale. */
    pickers?: React.ReactNode;
}

/**
 * How the picture is drawn, with the palette pickers below the scale.
 *
 * Swapping the eyes and the depth mean something to every mode that shows
 * both eyes, and nothing to the two that show one.
 *
 * The intensity only means something for the two decorations that cast a halo,
 * so it only joins the row when one of those is chosen. The color goes further
 * still: only Ambient reads it at all — Immersion takes its color from the
 * picture itself — so it joins only then, after the intensity.
 *
 * The spin-up delay only means something while the spin-up is shown, so it
 * joins that row only then.
 */
function DisplayFields(props: DisplayProps): React.JSX.Element {
    const renderingMode = useSetting(props.settings, 'renderingMode');
    const stereo = renderingMode !== VbRenderingMode.LEFT && renderingMode !== VbRenderingMode.RIGHT;
    const modeIds: (keyof VueportConfig)[] = ['renderingMode'];
    if (stereo) {
        modeIds.push('swapEyes', 'stereoDepth');
    }
    const decoration = useSetting(props.settings, 'decoration');
    const ambient = decoration === EmulatorDecoration.AMBIENT;
    const halo = ambient || decoration === EmulatorDecoration.IMMERSION;
    const decorationIds: (keyof VueportConfig)[] = ['decoration'];
    if (halo) {
        decorationIds.push('decorationIntensity');
    }
    if (ambient) {
        decorationIds.push('decorationColor');
    }
    const spinUp = useSetting(props.settings, 'mirrorSpinUp');
    const spinUpIds: (keyof VueportConfig)[] = ['mirrorSpinUp'];
    if (spinUp) {
        spinUpIds.push('mirrorSpinUpDelay');
    }
    return <SettingsFields {...props} ids={[...modeIds, 'scale', ...decorationIds, 'frameBlending', 'columnTable', ...spinUpIds]}>
        <RenderingModeSetting id='renderingMode' />
        {stereo && <SwitchSetting id='swapEyes' />}
        {stereo && <SliderSetting id='stereoDepth' />}
        <ChoiceSetting id='scale' />
        {props.pickers}
        <SettingsRow ids={decorationIds}>
            <ChoiceSetting id='decoration' />
            {halo && <SliderSetting id='decorationIntensity' />}
            {ambient && <DecorationColorSetting vbcHardware={props.vbcHardwareActive} />}
        </SettingsRow>
        <ChoiceSetting id='frameBlending' />
        <SwitchSetting id='columnTable' />
        <SettingsRow ids={spinUpIds} even>
            <SwitchSetting id='mirrorSpinUp' />
            {spinUp && <SwitchSetting id='mirrorSpinUpDelay' />}
        </SettingsRow>
    </SettingsFields>;
}

/**
 * The Display pane: the rendering mode and the scale, the colors the picture
 * is shown in, then the screen decoration and frame blending, with the running
 * picture in the column beside them so a change lands where it can be seen.
 */
export default function DisplaySettings(props: DisplayProps & {
    notifications: VueportNotifications,
    /** The running picture. Passed in, because where it comes from is the host's. */
    preview?: React.ReactNode,
}): React.JSX.Element {
    return <EmulatorPalettes
        settings={props.settings}
        notifications={props.notifications}
        preview={props.preview}
    >
        {pickers => <DisplayFields {...props} pickers={pickers} />}
    </EmulatorPalettes>;
}
