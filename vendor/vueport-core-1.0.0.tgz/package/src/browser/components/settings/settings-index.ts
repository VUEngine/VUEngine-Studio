import { VueportConfig } from '../../../common/emulator-settings';

/**
 * What each settings pane can show.
 *
 * Kept to exactly what the pane shows and filters, so a query that lights a tab
 * always leaves it with something — no "matched the tab, but the pane is empty".
 *
 * Here rather than beside the panes themselves because the settings window's
 * tab rail reads these to build its search index, and the rail must not drag
 * every pane's code — the palette editor and the color picker behind it among
 * it — into the chunk it is loaded in.
 */

/** The decoration and what only some decorations have: a halo, and its color. */
export const DECORATION_SETTINGS: readonly (keyof VueportConfig)[] = [
    'decoration', 'decorationIntensity', 'decorationColor',
];

export const DISPLAY_SETTINGS: readonly (keyof VueportConfig)[] = [
    'renderingMode', 'scale', ...DECORATION_SETTINGS,
];

/** In the order the pane shows them: how large the file is, then how it is composed. */
export const SCREENSHOT_SETTINGS: readonly (keyof VueportConfig)[] = [
    'screenshotScale', 'screenshotUseDisplaySettings', 'screenshotRenderingMode',
];

/**
 * What a recording is given whether or not it follows the picture on screen —
 * how many bits it is worth, what it is wrapped in, and how large it is drawn.
 */
export const RECORDING_SETTINGS: readonly (keyof VueportConfig)[] = [
    'videoQuality', 'videoFormat', 'videoScale',
];

/** In the order the pane shows them: what the file is, then how it is composed. */
export const VIDEO_SETTINGS: readonly (keyof VueportConfig)[] = [
    ...RECORDING_SETTINGS, 'videoUseDisplaySettings', 'videoRenderingMode',
];

export const REWIND_SETTINGS: readonly (keyof VueportConfig)[] = [
    'rewindEnabled', 'rewindGranularity', 'rewindBufferSize',
];

export const SPEED_SETTINGS: readonly (keyof VueportConfig)[] = [
    'fastForwardRatio', 'slowMotionRatio',
];

export const EMULATION_SETTINGS: readonly (keyof VueportConfig)[] = [
    ...REWIND_SETTINGS, ...SPEED_SETTINGS,
];

/**
 * The states the emulator takes by itself, which is all the save states have
 * to be configured about: the rotating automatic ones, and the one a closed
 * game is put away with. A state somebody takes by hand needs no setting.
 */
export const SAVE_STATE_SETTINGS: readonly (keyof VueportConfig)[] = [
    'autoSaveStatesEnabled', 'autoSaveStateInterval', 'autoSaveStateCount',
    'suspendResumeEnabled', 'suspendResumeStart',
];

/** A game's own saved progress: which slot it plays on, and what a fresh save holds. */
export const SAVE_DATA_SETTINGS: readonly (keyof VueportConfig)[] = [
    'saveGameSlot', 'sramInit', 'sramWindow',
];

/**
 * Where a ROM's companion files are kept. A pane of its own rather than a
 * section of Save Data: it decides where the save states and the cheats go
 * too, so it is not about save games in particular but about one folder.
 */
export const FILE_SETTINGS: readonly (keyof VueportConfig)[] = [
    'companionFiles',
];

export const VB_COLOR_SETTINGS: readonly (keyof VueportConfig)[] = [
    'vbcSupportEnabled', 'hardwareMode', 'vbcAutoApplyColorPatches',
];

export const SOUND_SETTINGS: readonly (keyof VueportConfig)[] = [
    'errorSoundEnabled', 'achievementSoundEnabled',
];
