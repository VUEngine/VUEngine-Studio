import { VueportConfig } from '../../../common/emulator-settings';

// what each settings pane shows and filters, so a query that lights a tab always leaves it with something.
// Kept apart from the panes so the tab rail can build its search index without dragging every pane's code
// (palette editor, color picker) into its chunk

// the decoration, and what only some decorations have: a halo and its color
export const DECORATION_SETTINGS: readonly (keyof VueportConfig)[] = [
    'decoration', 'decorationIntensity', 'decorationColor',
];

export const DISPLAY_SETTINGS: readonly (keyof VueportConfig)[] = [
    'renderingMode', 'swapEyes', 'stereoDepth', 'scale', 'frameBlending', ...DECORATION_SETTINGS, 'columnTable', 'mirrorSpinUp', 'mirrorSpinUpDelay',
];

// in the pane's order: file size, then composition
export const SCREENSHOT_SETTINGS: readonly (keyof VueportConfig)[] = [
    'screenshotScale', 'screenshotUseDisplaySettings', 'screenshotRenderingMode', 'screenshotFrameBlending',
];

// what a recording gets whether or not it follows the picture on screen
export const RECORDING_SETTINGS: readonly (keyof VueportConfig)[] = [
    'videoQuality', 'videoFormat', 'videoScale',
];

// in the pane's order: the file, then composition
export const VIDEO_SETTINGS: readonly (keyof VueportConfig)[] = [
    ...RECORDING_SETTINGS, 'videoUseDisplaySettings', 'videoRenderingMode', 'videoFrameBlending',
];

export const REWIND_SETTINGS: readonly (keyof VueportConfig)[] = [
    'rewindEnabled', 'rewindGranularity', 'rewindBufferSize',
];

export const SPEED_SETTINGS: readonly (keyof VueportConfig)[] = [
    'fastForwardRatio', 'slowMotionRatio',
];

export const EMULATION_SETTINGS: readonly (keyof VueportConfig)[] = [
    ...REWIND_SETTINGS, ...SPEED_SETTINGS,
];

// the states the emulator takes by itself (rotating automatic ones, and the one a closed game is put away with);
// a manual state needs no setting
export const SAVE_STATE_SETTINGS: readonly (keyof VueportConfig)[] = [
    'autoSaveStatesEnabled', 'autoSaveStateInterval', 'autoSaveStateCount',
    'suspendResumeEnabled', 'suspendResumeStart',
];

export const SAVE_DATA_SETTINGS: readonly (keyof VueportConfig)[] = [
    'saveGameSlot', 'sramInit', 'sramWindow',
];

// a pane of its own rather than a section of Save Data, as it decides where save states and cheats go too
export const FILE_SETTINGS: readonly (keyof VueportConfig)[] = [
    'companionFiles',
];

export const VB_COLOR_SETTINGS: readonly (keyof VueportConfig)[] = [
    'vbcSupportEnabled', 'hardwareMode', 'vbcAutoApplyColorPatches',
];

export const SOUND_SETTINGS: readonly (keyof VueportConfig)[] = [
    'errorSoundEnabled', 'achievementSoundEnabled',
];

// the on-screen controller, the Input pane's Touch page; the layout is changed in its editor, but Reset All covers it
export const TOUCH_SETTINGS: readonly (keyof VueportConfig)[] = [
    'touchControls', 'touchControlsOpacity', 'touchControlsSize',
    'touchControlsDiagonals', 'touchControlsSlide', 'touchControlsVibration', 'touchControlsHighlight',
    'touchControlsRumble',
];
