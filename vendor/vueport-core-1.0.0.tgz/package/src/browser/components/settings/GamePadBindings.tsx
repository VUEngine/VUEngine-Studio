/**
 * What a physical controller's buttons do — the Game Pads page of the input
 * settings.
 *
 * A page of its own rather than a section of each player's, because a pad
 * mapping belongs to the *device*: a controller keeps its layout whichever
 * player happens to be holding it, and duplicating it per player would mean
 * setting the same pad up twice. Which player a pad drives is a separate
 * question, and is asked here as one small control rather than by filing the
 * whole mapping under a player.
 *
 * The picture is the same one the keyboard pages draw — see `input-diagram.tsx`
 * — captioned with the pad's own buttons instead of keys. It lights up live
 * while a control is physically held, which is the only honest way to check a
 * mapping: you press the button and watch the right thing light up, without
 * starting a game.
 *
 * The mapping itself, and why it is per device rather than one fixed table, is
 * in `emulator-gamepad-profiles.ts`.
 */

import { GameController, Warning } from '@phosphor-icons/react';
import * as React from 'react';
import {
    DEFAULT_GAMEPAD_DEAD_ZONE,
    GAMEPAD_DEAD_ZONE_RANGE,
    GamepadDatabase,
    GamepadFamily,
    GamepadPreset,
    GamepadProfile,
    GamepadSource,
    assignGamepadAction,
    assignGamepadButton,
    clearGamepadAction,
    clearGamepadButton,
    forgetGamepadProfile,
    gamepadSourceId,
    offeredGamepadPresets,
    parseGamepadSource,
    profileFromPreset,
    resolveGamepadProfile,
    storeGamepadProfile,
} from '../../../common/emulator-gamepad-profiles';
import { nls } from '../../../common/emulator-nls';
import { VueportSettings } from '../../../common/emulator-settings';
import {
    EmulatorCommands,
    EmulatorGamePadButton,
    EMULATOR_ACTION_COMMANDS,
} from '../../emulator-commands';
import {
    connectedGamepadList,
    onGamepadsChanged,
    readPressedSources,
} from '../../emulator-gamepad';
import { EmulatorAction } from '../../emulator-types';
import EmptyContainer from '../kit/EmptyContainer';
import Select from '../kit/Select';
import Switch from '../kit/Switch';
import {
    BindingBody,
    BindingCard,
    BindingList,
    BindingLists,
    BindingRow,
    CancelCapture,
    CaptureRun,
    CaptureStrip,
    InputPage,
    InputSpacer,
    PadBadge,
    PadDiagrams,
    PresetPill,
    PresetRow,
    SetAllButton,
    useCaptureKeys,
} from './input-fields';
import { PAD_BUTTONS, PadDiagram, padButtonName } from './input-diagram';

/**
 * The emulator actions worth putting on a pad, in the order the column reads.
 *
 * A subset of what the keyboard offers, and deliberately so: a pad has a dozen
 * buttons and they are all spoken for by the game, so what is left is for the
 * two or three things somebody actually wants without reaching for the
 * keyboard. The debugging ones — frame advance among them — stay on the
 * keyboard, where there are keys to spare.
 */
const PAD_ACTIONS: EmulatorAction[] = [
    EmulatorAction.PauseToggle,
    EmulatorAction.Rewind,
    EmulatorAction.ToggleFastForward,
    EmulatorAction.ToggleSlowmotion,
    EmulatorAction.SaveState,
    EmulatorAction.LoadState,
    EmulatorAction.Reset,
    EmulatorAction.AudioMute,
    EmulatorAction.Fullscreen,
    EmulatorAction.Screenshot,
];

/**
 * What a family calls its face buttons, by standard-layout index.
 *
 * The reason this matters rather than being decoration: the Virtual Boy's A is
 * its *rightmost* face button, which the standard layout calls button 1 — and
 * button 1 is printed "B" on an Xbox pad, "○" on a PlayStation one and "A" on
 * a Nintendo one. A page that showed "Button 1" would be accurate and useless;
 * one that showed the wrong letter would be worse. So the glyph comes from the
 * detected family, and a pad whose family is not known shows the index.
 */
const FACE_GLYPHS: Record<GamepadFamily, Record<number, string> | undefined> = {
    xbox: { 0: 'A', 1: 'B', 2: 'X', 3: 'Y', 4: 'LB', 5: 'RB', 6: 'LT', 7: 'RT', 8: 'View', 9: 'Menu', 10: 'LS', 11: 'RS' },
    playstation: { 0: '✕', 1: '○', 2: '□', 3: '△', 4: 'L1', 5: 'R1', 6: 'L2', 7: 'R2', 8: 'Share', 9: 'Options', 10: 'L3', 11: 'R3' },
    nintendo: { 0: 'B', 1: 'A', 2: 'Y', 3: 'X', 4: 'L', 5: 'R', 6: 'ZL', 7: 'ZR', 8: '−', 9: '+', 10: 'LS', 11: 'RS' },
    generic: undefined,
};

/**
 * Where Select's and Start's captions sit on this page.
 *
 * Their shipped anchors sit nineteen units apart under two buttons that are
 * themselves close together, which carries the single character a key name
 * needs. A pad calls them "Share" and "Options", or "View" and "Menu", and side
 * by side those overlap. Pulled apart onto opposite diagonals instead, each
 * clear of the d-pad captions beside them.
 */
const PAD_CAPTION_OVERRIDES = {
    select: { x: 60, y: 44, anchor: 'end' },
    start: { x: 109, y: 73, anchor: 'start' },
} as const;

/** The d-pad, which every family agrees about. */
const DPAD_GLYPHS: Record<number, string> = { 12: '↑', 13: '↓', 14: '←', 15: '→' };

/** What the two stick axes are called on the standard layout. */
const AXIS_NAMES: Record<number, string> = {
    0: 'LS', 1: 'LS', 2: 'RS', 3: 'RS',
};

/**
 * What to write beside a control for the source driving it.
 *
 * A pad the browser has normalized gets a real name, since the index means the
 * same thing on every such pad. One it has not gets the raw index, which is
 * honest: nothing here knows what that button is printed with.
 */
function sourceLabel(
    source: GamepadSource,
    family: GamepadFamily,
    standard: boolean,
    compact = false,
): string {
    if (source.kind === 'axis') {
        if (standard && AXIS_NAMES[source.index]) {
            const vertical = source.index % 2 === 1;
            const arrow = vertical
                ? (source.direction < 0 ? '↑' : '↓')
                : (source.direction < 0 ? '←' : '→');
            return `${AXIS_NAMES[source.index]}${arrow}`;
        }
        return compact
            ? `${source.index}${source.direction < 0 ? '−' : '+'}`
            : `Axis ${source.index}${source.direction < 0 ? '−' : '+'}`;
    }
    if (standard) {
        if (DPAD_GLYPHS[source.index]) {
            // "D↑" on the picture, "D-Pad ↑" in the list: the captions sit in
            // gaps between the drawn controls that fit about four characters,
            // and the arrow is unambiguous once the prefix says which control
            // it belongs to.
            return compact
                ? `D${DPAD_GLYPHS[source.index]}`
                : `D-Pad ${DPAD_GLYPHS[source.index]}`;
        }
        const glyph = FACE_GLYPHS[family]?.[source.index];
        if (glyph) {
            return glyph;
        }
    }
    return `${source.index}`;
}

/** Every source on a control, joined — a control can have more than one. */
function sourcesLabel(
    sources: GamepadSource[] | undefined,
    family: GamepadFamily,
    standard: boolean,
): string {
    if (!sources || sources.length === 0) {
        return '—';
    }
    return sources.map(source => sourceLabel(source, family, standard)).join(' / ');
}

/**
 * The same, for a caption written on the picture: the first source only, and
 * abbreviated.
 *
 * The captions sit in the gaps between the drawn controls, which were sized for
 * a key name — "E", at most "F10". A pad's controls are named far longer, and
 * every one of them listed would have the left cross's four captions overlapping
 * each other and the Select and Start ones beside them. The picture is the quick
 * answer to "what do I press for this"; the list underneath is where every
 * source bound to a control is spelled out.
 */
function captionLabel(
    sources: GamepadSource[] | undefined,
    family: GamepadFamily,
    standard: boolean,
): string {
    return sources?.[0] ? sourceLabel(sources[0], family, standard, true) : '—';
}

/** How a preset's name reads. Localized where we have a translation for it. */
function presetLabel(preset: GamepadPreset): string {
    switch (preset.id) {
        case 'standard-xbox':
            return nls.localize('vueport/input/gamePads/presets/xbox', 'Xbox');
        case 'standard-playstation':
            return nls.localize('vueport/input/gamePads/presets/playstation', 'PlayStation');
        case 'standard-nintendo':
            return nls.localize('vueport/input/gamePads/presets/nintendo', 'Nintendo');
        case 'standard-generic':
            return nls.localize('vueport/input/gamePads/presets/standard', 'Standard');
        case 'standard-nofaceswap':
            return nls.localize('vueport/input/gamePads/presets/swapped', 'Standard (A/B swapped)');
        default:
            return preset.name;
    }
}

/** One control being waited for: a Virtual Boy button, or an emulator action. */
interface PadTarget {
    button?: EmulatorGamePadButton;
    action?: EmulatorAction;
}

/** What a capture in progress is asking for. */
interface PadCapture extends PadTarget {
    title: React.ReactNode;
    run?: CaptureRun;
}

function sameTarget(a: PadTarget, b: PadTarget): boolean {
    return a.button === b.button && a.action === b.action;
}

export interface GamePadBindingsProps {
    settings: VueportSettings;
    /** The pane's tab strip, which leads this page's own top row. */
    tabs: React.ReactNode;
    /**
     * Where the harvested device-name database comes from, when the host ships
     * one — see `scripts/fetch-controller-db.mjs`. Asked once, the first time
     * this page is opened, so the file never weighs on a session that does not
     * look at its controllers. Everything works without it: a pad falls back to
     * the name its own id carries.
     */
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator re-reads it. */
    onChange?: () => void;
}

export default function GamePadBindings(props: GamePadBindingsProps): React.JSX.Element {
    const { settings, tabs, loadDatabase, onChange } = props;

    /** The device-name database, once it has arrived. */
    const [database, setDatabase] = React.useState<GamepadDatabase | undefined>(undefined);
    React.useEffect(() => {
        let canceled = false;
        // Failing to load it is not worth reporting: the page works without it,
        // only with less friendly names, and a toast about a names file would
        // be noise about something nobody asked for.
        loadDatabase?.().then(
            loaded => { if (!canceled) { setDatabase(loaded); } },
            () => undefined,
        );
        return () => { canceled = true; };
    }, [loadDatabase]);

    /**
     * Which connected pad is being configured, by the Gamepad API's own slot.
     *
     * By slot rather than by device key, because two pads of the same model
     * share a key — there is nothing in a browser's id to tell them apart —
     * and picking one of a pair has to be possible even though they will then
     * share a mapping.
     */
    const [selected, setSelected] = React.useState<number | undefined>(undefined);
    const [capture, setCapture] = React.useState<PadCapture | undefined>(undefined);
    const [hovered, setHovered] = React.useState<EmulatorGamePadButton | undefined>(undefined);
    /** Which sources are physically held right now, as source ids. */
    const [pressed, setPressed] = React.useState<Set<string>>(() => new Set());
    const [, bump] = React.useReducer((n: number) => n + 1, 0);

    /** The pads the page can see. Re-read when one is plugged in or out. */
    const [pads, setPads] = React.useState<Gamepad[]>(() => connectedGamepadList());
    React.useEffect(() => onGamepadsChanged(() => setPads(connectedGamepadList())), []);

    const stored = settings.get('gamepadProfiles');
    const players = settings.get('gamepadPlayers');
    const vibration = settings.get('gamepadRumbleEnabled');
    const vibrationLabel = nls.localize('vueport/input/gamePads/vibration', 'Vibration');

    // The pad being configured: the one chosen, or the first connected. Held
    // as a slot rather than an object, since `getGamepads` hands back a fresh
    // snapshot on every call and nothing survives between them.
    const pad = pads.find(candidate => candidate.index === selected) ?? pads[0];

    // Re-resolved whenever the stored profiles change, which they do by
    // identity: `save` writes a new array through the settings, so the next
    // render reads a different one and this recomputes.
    const resolved = React.useMemo(
        () => pad ? resolveGamepadProfile(pad, stored, database) : undefined,
        [pad, stored, database],
    );
    const profile = resolved?.profile;
    const standard = pad?.mapping === 'standard';

    /**
     * Poll the pad while this page is open.
     *
     * Its own loop rather than the emulator's, because this runs whether or not
     * a game is loaded — the settings are reachable from the welcome screen —
     * and because what it wants is different: every source held, not the folded
     * Virtual Boy mask. Stopped as soon as the page goes away.
     */
    const captureRef = React.useRef(capture);
    captureRef.current = capture;
    const profileRef = React.useRef(profile);
    profileRef.current = profile;
    /**
     * Where the loop reaches what to do with a press.
     *
     * Through a ref rather than closed over, because the loop is installed once
     * per pad while `bindSource` closes over the stored profiles — which every
     * save replaces. A run through all fourteen buttons would otherwise write
     * each one against the list as it was before the first, and land on the
     * settings as a single button changed.
     */
    const bindRef = React.useRef<(source: GamepadSource) => void>(() => undefined);

    React.useEffect(() => {
        if (!pad) {
            return undefined;
        }
        const slot = pad.index;
        let handle = 0;
        let previous = new Set<string>();
        const frame = (): void => {
            handle = requestAnimationFrame(frame);
            const live = connectedGamepadList().find(candidate => candidate.index === slot);
            if (!live) {
                return;
            }
            const held = readPressedSources(
                live, profileRef.current?.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE);
            // A press is an edge: the settings react to a button going down,
            // not to it being held, or one held while the page opened would
            // bind itself immediately.
            const waiting = captureRef.current;
            if (waiting) {
                for (const id of held) {
                    if (!previous.has(id)) {
                        const source = parseGamepadSource(id);
                        if (source) {
                            bindRef.current(source);
                            break;
                        }
                    }
                }
            }
            previous = held;
            // Only re-render when the set actually changed: this runs sixty
            // times a second and most frames nothing is held at all.
            setPressed(current => sameSet(current, held) ? current : held);
        };
        handle = requestAnimationFrame(frame);
        return () => cancelAnimationFrame(handle);
        // Only the slot: everything else the loop needs is read fresh through
        // the refs above, and re-installing it on every render would throw
        // away the previous-frame state the edge detection depends on.
    }, [pad?.index]);

    /** Write a profile back, replacing whatever was stored for this device. */
    const save = (next: GamepadProfile): void => {
        settings.set('gamepadProfiles', storeGamepadProfile(stored, next)).catch(() => undefined);
        bump();
        onChange?.();
    };

    /**
     * Put the source that was just pressed on whatever is being asked for.
     *
     * What is being asked for, and the profile it lands in, come through the
     * refs above: a run's later steps would otherwise still be answering the
     * first one's question.
     */
    const bindSource = (source: GamepadSource): void => {
        const waiting = captureRef.current;
        const current = profileRef.current;
        if (!waiting || !current) {
            return;
        }
        if (waiting.action !== undefined) {
            save(assignGamepadAction(current, waiting.action, source));
            setCapture(undefined);
            return;
        }
        if (waiting.button === undefined) {
            return;
        }
        const next = assignGamepadButton(current, waiting.button, source);
        if (!waiting.run) {
            save(next);
            setCapture(undefined);
            return;
        }
        // A run saves as it goes rather than at the end, unlike the keyboard's:
        // there, an abort has to leave the old keys alone because every step
        // overwrites one. Here each step is a button somebody just physically
        // pressed and watched land, and throwing fourteen of those away because
        // the fifteenth was awkward is the worse trade.
        save(next);
        const { step, total, queue } = waiting.run;
        const [nextButton, ...rest] = queue;
        if (!nextButton) {
            setCapture(undefined);
            return;
        }
        setCapture({
            button: nextButton,
            title: padButtonName(nextButton, buttonLabel(nextButton)),
            run: { step: step + 1, total, queue: rest },
        });
    };
    bindRef.current = bindSource;

    // Escape gets out of a capture, the same as it does on the keyboard pages.
    // Nothing else here comes from the keyboard: the bindings arrive off the
    // controller, through the loop above.
    useCaptureKeys(capture !== undefined, event => {
        if (event.key !== 'Escape') {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        setCapture(undefined);
    });

    const buttonLabel = (button: EmulatorGamePadButton): string =>
        EMULATOR_GAMEPAD_LABELS[button]();

    /** Whether a control is drawn lit: hovered, being asked for, or held. */
    const isHeld = (button: EmulatorGamePadButton): boolean =>
        (profile?.buttons[button] ?? []).some(source => pressed.has(gamepadSourceId(source)));

    const isWaitingFor = (target: PadTarget): boolean =>
        capture !== undefined && sameTarget(capture, target);

    const caption = (button: EmulatorGamePadButton): string => {
        if (isWaitingFor({ button })) {
            return nls.localize('vueport/input/gamePads/pressButton', 'press a button…');
        }
        return captionLabel(profile?.buttons[button], profile?.family ?? 'generic', standard);
    };

    /** Walk every Virtual Boy button, asking for a pad control for each. */
    const setEveryButton = (): void => {
        const [first, ...queue] = PAD_BUTTONS;
        setCapture({
            button: first,
            title: padButtonName(first, buttonLabel(first)),
            run: { step: 1, total: PAD_BUTTONS.length, queue },
        });
    };

    const applyPreset = (preset: GamepadPreset): void => {
        if (!resolved) {
            return;
        }
        setCapture(undefined);
        save(profileFromPreset(preset, resolved.identity, database));
    };

    /** Forget everything recorded for this pad, back to what is detected. */
    const forget = (): void => {
        if (!profile) {
            return;
        }
        setCapture(undefined);
        settings.set('gamepadProfiles', forgetGamepadProfile(stored, profile.device))
            .catch(() => undefined);
        bump();
        onChange?.();
    };

    const setPlayer = (value: number | undefined): void => {
        if (!profile) {
            return;
        }
        const next = { ...players };
        if (value === undefined) {
            delete next[profile.device];
        } else {
            next[profile.device] = value;
        }
        settings.set('gamepadPlayers', next).catch(() => undefined);
        bump();
        onChange?.();
    };

    const setDeadZone = (value: number): void => {
        if (profile) {
            save({ ...profile, deadZone: value });
        }
    };

    // ------------------------------------------------------------- rendering

    // The Gamepad API withholds a pad until a button on it is pressed — the
    // list of devices attached to a machine is a fingerprint — so "none
    // connected" really means "none used yet", and saying so is the difference
    // between a page that looks broken and one that tells you what to do.
    if (!pad || !profile || !resolved) {
        return <InputPage top={tabs}>
            <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/input/gamePads/none', 'No controller detected')}
                    description={nls.localize(
                        'vueport/input/gamePads/noneDescription',
                        'Connect a controller and press any button on it. Browsers keep a controller hidden from a page until it is used.',
                    )}
                    icon={<GameController size={32} />}
                />
            </div>
        </InputPage>;
    }

    const assignedPlayer = players[profile.device];
    const presets = offeredGamepadPresets(pad);
    /** What the control being asked for is bound to right now. */
    const boundTo = capture === undefined
        ? '—'
        : capture.action !== undefined
            ? sourcesLabel(profile.actions?.[capture.action], profile.family, standard)
            : sourcesLabel(profile.buttons[capture.button!], profile.family, standard);

    /** One row of a list — the whole row is the button, as on the key pages. */
    const row = (
        name: React.ReactNode,
        target: PadTarget,
        sources: GamepadSource[] | undefined,
        lit: boolean,
    ): React.JSX.Element => {
        const waiting = isWaitingFor(target);
        return <BindingRow
            key={target.button ?? target.action}
            name={name}
            value={waiting
                ? nls.localize('vueport/input/gamePads/pressButton', 'press a button…')
                : sourcesLabel(sources, profile.family, standard)}
            lit={lit}
            waiting={waiting}
            onClick={() => setCapture({ ...target, title: name })}
            onHoverIn={() => target.button && setHovered(target.button)}
            onHoverOut={() => target.button && setHovered(undefined)}
        />;
    };

    return <InputPage top={<>
        {tabs}
        {pads.length > 1
            ? <Select
                value={String(pad.index)}
                onChange={next => {
                    setSelected(Number(next));
                    setCapture(undefined);
                }}
                options={pads.map(candidate => ({
                    value: String(candidate.index),
                    label: resolveGamepadProfile(candidate, stored, database).profile.label,
                }))}
            />
            : <PadBadge label={profile.label} title={pad.id} />}
        <InputSpacer />
    </>}>
        <p className={'vp-input-hint' + (resolved.origin === 'unmapped' ? ' is-warning' : '')}>
            {resolved.origin === 'unmapped'
                ? <>
                    <Warning size={15} />
                    {nls.localize(
                        'vueport/input/gamePads/unrecognized',
                        'Your browser does not recognize this controller, so its buttons \
arrive in no known order and no preset can be guessed for it. \
Use "Set all buttons" to manually create a mapping.',
                    )}
                </>
                : resolved.origin === 'stored'
                    ? nls.localize(
                        'vueport/input/gamePads/storedAs',
                        'Using your own mapping for {0}.', profile.label ?? '')
                    : nls.localize(
                        'vueport/input/gamePads/detectedAs',
                        'Detected as {0} · {1}',
                        profile.label ?? '',
                        resolved.preset ? presetLabel(resolved.preset) : '')}
        </p>

        <BindingBody>
            <BindingCard>
                <PadDiagrams>
                    {(['front', 'back'] as const).map(face =>
                        <PadDiagram
                            key={face}
                            face={face}
                            caption={caption}
                            // Held wins over hovered: while a button is down,
                            // what lights up is the answer to "did that land
                            // where I meant it to".
                            isLit={button => isHeld(button) || hovered === button
                                || isWaitingFor({ button })}
                            isWaiting={button => isWaitingFor({ button })}
                            onSelect={button => setCapture({
                                button,
                                title: padButtonName(button, buttonLabel(button)),
                            })}
                            onHover={setHovered}
                            captionAt={PAD_CAPTION_OVERRIDES}
                        />)}
                </PadDiagrams>
                {capture &&
                    <CaptureStrip
                        title={capture.title}
                        run={capture.run}
                        prompt={nls.localize(
                            'vueport/input/gamePads/pressPrompt',
                            'Press the control on your controller, or Escape to stop.',
                        )}
                        detail={capture.run
                            ? <p className='vp-input-capture-note'>
                                {nls.localize(
                                    'vueport/input/gamePads/runNote',
                                    'Each button is saved as you press it, so stopping keeps what you have set so far.',
                                )}
                            </p>
                            : <p className='vp-input-capture-current'>
                                {boundTo !== '—'
                                    ? <>{nls.localize('vueport/input/gamePads/currentlyOn', 'Currently on:')} <b>{boundTo}</b></>
                                    : nls.localize('vueport/input/gamePads/currentlyUnmapped', 'Not mapped to anything.')}
                            </p>}
                        actions={<>
                            <CancelCapture onClick={() => setCapture(undefined)} />
                            {!capture.run && boundTo !== '—' &&
                                <button
                                    type='button'
                                    className='vp-button secondary'
                                    onClick={() => {
                                        save(capture.action !== undefined
                                            ? clearGamepadAction(profile, capture.action)
                                            : clearGamepadButton(profile, capture.button!));
                                        setCapture(undefined);
                                    }}
                                >
                                    {nls.localize('vueport/input/gamePads/clear', 'Clear')}
                                </button>}
                        </>}
                    />}

                <PresetRow trailing={
                    <SetAllButton
                        label={nls.localize('vueport/input/gamePads/setAll', 'Set all buttons…')}
                        onClick={setEveryButton}
                    />
                }>
                    {presets.map(preset =>
                        <PresetPill
                            key={preset.id}
                            label={presetLabel(preset)}
                            current={profile.preset === preset.id}
                            onClick={() => applyPreset(preset)}
                        />)}
                </PresetRow>

                <div className='vp-preset-row'>
                    <label className='vp-gamepad-deadzone'>
                        {nls.localize('vueport/input/gamePads/deadZone', 'Stick dead zone')}
                        <input
                            type='range'
                            min={GAMEPAD_DEAD_ZONE_RANGE.min * 100}
                            max={GAMEPAD_DEAD_ZONE_RANGE.max * 100}
                            step={5}
                            value={Math.round(profile.deadZone * 100)}
                            onChange={event => setDeadZone(Number(event.target.value) / 100)}
                        />
                        <span className='vp-gamepad-deadzone-value'>
                            {Math.round(profile.deadZone * 100)}%
                        </span>
                    </label>
                    {/* The one control here that is not the selected pad's:
                        vibration is on or off for every controller at once,
                        because it answers a question about the game rather
                        than about a device. */}
                    <span
                        className='vp-input-same'
                        title={nls.localize(
                            'vueport/input/gamePads/vibrationHint',
                            'Play a game\'s rumble effects on your controller when no Rumble Pack \
is connected. The Rumble Pack\'s effects are approximated: each becomes a short pulse.',
                        )}
                    >
                        <Switch
                            label={vibrationLabel}
                            value={vibration}
                            onChange={next => {
                                settings.set('gamepadRumbleEnabled', next).catch(() => undefined);
                                bump();
                            }}
                        />
                        {vibrationLabel}
                    </span>
                    <span className='vp-input-spacer' />
                    {resolved.origin === 'stored' &&
                        <button type='button' className='vp-button secondary' onClick={forget}>
                            {resolved.preset
                                ? nls.localize('vueport/input/gamePads/resetToPreset',
                                    'Reset to {0}', presetLabel(resolved.preset))
                                : nls.localize('vueport/input/gamePads/forget', 'Forget this controller')}
                        </button>}

                    <label className='vp-input-same'>
                        {nls.localize('vueport/input/gamePads/drives', 'Drives')}
                        <Select
                            value={assignedPlayer === undefined ? 'auto' : String(assignedPlayer)}
                            onChange={next => setPlayer(next === 'auto' ? undefined : Number(next))}
                            options={[
                                {
                                    value: 'auto',
                                    label: nls.localize('vueport/input/gamePads/driveAuto', 'Either player'),
                                },
                                { value: '1', label: nls.localize('vueport/input/gamePads/player1', 'Player 1') },
                                { value: '2', label: nls.localize('vueport/input/gamePads/player2', 'Player 2') },
                            ]}
                        />
                    </label>
                </div>
            </BindingCard>

            <BindingLists>
                <BindingList title={nls.localize('vueport/input/gamePad', 'Game pad')}>
                    {PAD_BUTTONS.map(button => row(
                        padButtonName(button, buttonLabel(button)),
                        { button },
                        profile.buttons[button],
                        isHeld(button) || hovered === button,
                    ))}
                </BindingList>
                <BindingList title={nls.localize('vueport/input/emulator', 'Emulator')}>
                    {PAD_ACTIONS.map(action => row(
                        actionLabel(action),
                        { action },
                        profile.actions?.[action],
                        (profile.actions?.[action] ?? [])
                            .some(source => pressed.has(gamepadSourceId(source))),
                    ))}
                </BindingList>
            </BindingLists>
        </BindingBody>
    </InputPage>;
}

/** Whether two sets hold the same members. */
function sameSet(a: Set<string>, b: Set<string>): boolean {
    if (a.size !== b.size) {
        return false;
    }
    for (const value of a) {
        if (!b.has(value)) {
            return false;
        }
    }
    return true;
}

function actionLabel(action: EmulatorAction): string {
    return EMULATOR_ACTION_COMMANDS[action].label ?? action;
}

/**
 * What each Virtual Boy button is called here.
 *
 * Read off the commands the keyboard pages already label, so the two pages name
 * the same button the same way; through accessors, because the commands read
 * their own labels lazily and the host installs its translations after this
 * module is imported.
 */
const EMULATOR_GAMEPAD_LABELS: Record<EmulatorGamePadButton, () => string> = {
    lUp: () => EmulatorCommands.INPUT_L_UP.label ?? '',
    lDown: () => EmulatorCommands.INPUT_L_DOWN.label ?? '',
    lLeft: () => EmulatorCommands.INPUT_L_LEFT.label ?? '',
    lRight: () => EmulatorCommands.INPUT_L_RIGHT.label ?? '',
    rUp: () => EmulatorCommands.INPUT_R_UP.label ?? '',
    rDown: () => EmulatorCommands.INPUT_R_DOWN.label ?? '',
    rLeft: () => EmulatorCommands.INPUT_R_LEFT.label ?? '',
    rRight: () => EmulatorCommands.INPUT_R_RIGHT.label ?? '',
    select: () => EmulatorCommands.INPUT_SELECT.label ?? '',
    start: () => EmulatorCommands.INPUT_START.label ?? '',
    b: () => EmulatorCommands.INPUT_B.label ?? '',
    a: () => EmulatorCommands.INPUT_A.label ?? '',
    lTrigger: () => EmulatorCommands.INPUT_L_TRIGGER.label ?? '',
    rTrigger: () => EmulatorCommands.INPUT_R_TRIGGER.label ?? '',
};
