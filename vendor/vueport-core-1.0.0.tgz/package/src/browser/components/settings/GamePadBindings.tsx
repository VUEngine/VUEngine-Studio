/**
 * What a physical controller's buttons do — the Game Pads page of the input
 * settings.
 *
 * A page of its own rather than a section of each player's, because a pad
 * mapping belongs to the *device*: a controller keeps its layout whichever
 * player happens to be holding it, and duplicating it per player would mean
 * setting the same pad up twice. Which player a pad drives is a separate
 * question, and is asked here as one small control rather than by filing the
 * whole mapping under a player.
 *
 * The picture is the same one the keyboard pages draw — see `input-diagram.tsx`
 * — captioned with the pad's own buttons instead of keys. It lights up live
 * while a control is physically held, which is the only honest way to check a
 * mapping: you press the button and watch the right thing light up, without
 * starting a game.
 *
 * The mapping itself, and why it is per device rather than one fixed table, is
 * in `emulator-gamepad-profiles.ts`.
 */

import { GameController, Warning, X } from '@phosphor-icons/react';
import * as React from 'react';
import {
    DEFAULT_GAMEPAD_DEAD_ZONE,
    GAMEPAD_DEAD_ZONE_RANGE,
    GamepadDatabase,
    GamepadFamily,
    GamepadHatDirection,
    GamepadPadAction,
    GamepadProfile,
    GamepadProfileFile,
    GamepadSource,
    GamepadUiAction,
    assignGamepadAction,
    assignGamepadButton,
    assignGamepadTurbo,
    clearGamepadAction,
    clearGamepadButton,
    clearGamepadTurbo,
    forgetGamepadProfile,
    gamepadMacroAction,
    gamepadMacroSlot,
    gamepadPreset,
    gamepadProfileFile,
    gamepadProfileMatchesPreset,
    gamepadSourceId,
    parseGamepadSource,
    removeGamepadSource,
    ResolvedGamepadProfile,
    resolveGamepadProfile,
    storeGamepadProfile,
} from '../../../common/emulator-gamepad-profiles';
import { VueportNotifications } from '../../../common/emulator-host';
import { nls } from '../../../common/emulator-nls';
import { VUEPORT_DEFAULTS, VueportSettings } from '../../../common/emulator-settings';
import {
    EmulatorCommands,
    EmulatorGamePadButton,
    EMULATOR_ACTION_COMMANDS,
    EMULATOR_MACRO_SLOT_COMMANDS,
    EMULATOR_MACRO_SLOTS,
    EMULATOR_TURBO_BUTTONS,
} from '../../emulator-commands';
import { gamepadCanRumble } from '../../emulator-gamepad-rumble';
import {
    connectedGamepadList,
    onGamepadsChanged,
    readPressedSources,
} from '../../emulator-gamepad';
import { EmulatorAction } from '../../emulator-types';
import EmptyContainer from '../kit/EmptyContainer';
import RadioSelect from '../kit/RadioSelect';
import Select from '../kit/Select';
import {
    BindingBody,
    BindingCard,
    BindingList,
    BindingLists,
    BindingRow,
    CancelCapture,
    CaptureRun,
    CaptureStrip,
    InputPage,
    InputSpacer,
    PadBadge,
    PadDiagrams,
    SetAllButton,
    TurboRateSlider,
    TurboTitle,
    useCaptureKeys,
} from './input-fields';
import { PAD_BUTTONS, PadDiagram, padButtonName } from './input-diagram';

/**
 * The emulator actions worth putting on a pad, in the order the column reads.
 *
 * A subset of what the keyboard offers, and deliberately so: a pad has a dozen
 * buttons and they are all spoken for by the game, so what is left is for the
 * two or three things somebody actually wants without reaching for the
 * keyboard. The debugging ones — frame advance among them — stay on the
 * keyboard, where there are keys to spare.
 */
const PAD_ACTIONS: EmulatorAction[] = [
    EmulatorAction.PauseToggle,
    EmulatorAction.Rewind,
    EmulatorAction.ToggleFastForward,
    EmulatorAction.ToggleSlowmotion,
    EmulatorAction.SaveState,
    EmulatorAction.LoadState,
    EmulatorAction.Reset,
    EmulatorAction.AudioMute,
    EmulatorAction.Fullscreen,
    EmulatorAction.Screenshot,
];

/**
 * What a family calls its face buttons, by standard-layout index.
 *
 * The reason this matters rather than being decoration: the Virtual Boy's A is
 * its *rightmost* face button, which the standard layout calls button 1 — and
 * button 1 is printed "B" on an Xbox pad, "○" on a PlayStation one and "A" on
 * a Nintendo one. A page that showed "Button 1" would be accurate and useless;
 * one that showed the wrong letter would be worse. So the glyph comes from the
 * detected family, and a pad whose family is not known shows the index.
 */
const FACE_GLYPHS: Record<GamepadFamily, Record<number, string> | undefined> = {
    xbox: { 0: 'A', 1: 'B', 2: 'X', 3: 'Y', 4: 'LB', 5: 'RB', 6: 'LT', 7: 'RT', 8: 'View', 9: 'Menu', 10: 'LS', 11: 'RS', 16: 'Xbox' },
    playstation: { 0: '✕', 1: '○', 2: '□', 3: '△', 4: 'L1', 5: 'R1', 6: 'L2', 7: 'R2', 8: 'Share', 9: 'Options', 10: 'L3', 11: 'R3', 16: 'PS' },
    nintendo: { 0: 'B', 1: 'A', 2: 'Y', 3: 'X', 4: 'L', 5: 'R', 6: 'ZL', 7: 'ZR', 8: '−', 9: '+', 10: 'LS', 11: 'RS', 16: 'Home' },
    generic: undefined,
};

/** The d-pad, which every family agrees about. */
const DPAD_GLYPHS: Record<number, string> = { 12: '↑', 13: '↓', 14: '←', 15: '→' };

/** What the two stick axes are called on the standard layout. */
const AXIS_NAMES: Record<number, string> = {
    0: 'LS', 1: 'LS', 2: 'RS', 3: 'RS',
};

/** A hat switch's directions, drawn the same as the standard d-pad's. */
const HAT_GLYPHS: Record<GamepadHatDirection, string> = { up: '↑', down: '↓', left: '←', right: '→' };

/**
 * What to write beside a control for the source driving it.
 *
 * A pad the browser has normalized gets a real name, since the index means the
 * same thing on every such pad. One it has not gets the raw index, which is
 * honest: nothing here knows what that button is printed with.
 */
function sourceLabel(
    source: GamepadSource,
    family: GamepadFamily,
    standard: boolean,
    compact = false,
    labels?: Record<string, string>,
): string {
    // What the device's own profile calls it, before any family's guess.
    const own = labels?.[gamepadSourceId(source)];
    if (own) {
        return own;
    }
    if (source.kind === 'hat') {
        // A hat is a d-pad whatever the browser made of it, so it reads as one.
        return compact ? `D${HAT_GLYPHS[source.direction]}` : `D-Pad ${HAT_GLYPHS[source.direction]}`;
    }
    if (source.kind === 'axis') {
        if (standard && AXIS_NAMES[source.index]) {
            const vertical = source.index % 2 === 1;
            const arrow = vertical
                ? (source.direction < 0 ? '↑' : '↓')
                : (source.direction < 0 ? '←' : '→');
            return `${AXIS_NAMES[source.index]}${arrow}`;
        }
        return compact
            ? `${source.index}${source.direction < 0 ? '−' : '+'}`
            : `Axis ${source.index}${source.direction < 0 ? '−' : '+'}`;
    }
    if (standard) {
        if (DPAD_GLYPHS[source.index]) {
            // "D↑" on the picture, "D-Pad ↑" in the list: the captions sit in
            // gaps between the drawn controls that fit about four characters,
            // and the arrow is unambiguous once the prefix says which control
            // it belongs to.
            return compact
                ? `D${DPAD_GLYPHS[source.index]}`
                : `D-Pad ${DPAD_GLYPHS[source.index]}`;
        }
        const glyph = FACE_GLYPHS[family]?.[source.index];
        if (glyph) {
            return glyph;
        }
        // Every family has the one in the middle, whatever it is printed with.
        if (source.index === 16) {
            return 'Home';
        }
    }
    return `${source.index}`;
}

/** Every source on a control, joined — a control can have more than one. */
function sourcesLabel(
    sources: GamepadSource[] | undefined,
    family: GamepadFamily,
    standard: boolean,
    labels?: Record<string, string>,
): string {
    if (!sources || sources.length === 0) {
        return '—';
    }
    return sources.map(source => sourceLabel(source, family, standard, false, labels)).join(' / ');
}

/**
 * The same, for a caption written on the picture: the first source only, and
 * abbreviated.
 *
 * The captions sit in the gaps between the drawn controls, which were sized for
 * a key name — "E", at most "F10". A pad's controls are named far longer, and
 * every one of them listed would have the left cross's four captions overlapping
 * each other and the Select and Start ones beside them. The picture is the quick
 * answer to "what do I press for this"; the list underneath is where every
 * source bound to a control is spelled out.
 */
function captionLabel(
    sources: GamepadSource[] | undefined,
    family: GamepadFamily,
    standard: boolean,
    labels?: Record<string, string>,
): string {
    return sources?.[0] ? sourceLabel(sources[0], family, standard, true, labels) : '—';
}

/**
 * One control being waited for: a Virtual Boy button, the same button on
 * turbo, or an action — the emulator's, the host's, or a macro slot.
 */
interface PadTarget {
    button?: EmulatorGamePadButton;
    turbo?: EmulatorGamePadButton;
    action?: GamepadPadAction;
}

/** What a capture in progress is asking for. */
interface PadCapture extends PadTarget {
    title: React.ReactNode;
    run?: CaptureRun;
    /** Put the press beside what is already bound instead of in its place. */
    add?: boolean;
}

function sameTarget(a: PadTarget, b: PadTarget): boolean {
    return a.button === b.button && a.turbo === b.turbo && a.action === b.action;
}

export interface GamePadBindingsProps {
    settings: VueportSettings;
    /** Asks before a reset throws away the person's own mapping. */
    notifications: VueportNotifications;
    /** The pane's tab strip, which leads this page's own top row. */
    tabs: React.ReactNode;
    /**
     * Where the harvested device-name database comes from, when the host ships
     * one — see `scripts/fetch-controller-db.mjs`. Asked once, the first time
     * this page is opened, so the file never weighs on a session that does not
     * look at its controllers. Everything works without it: a pad falls back to
     * the name its own id carries.
     */
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator re-reads it. */
    onChange?: () => void;
    /**
     * Hands a file to the person — the host's download or save dialog. Without
     * it there is no Export button.
     */
    exportFile?: (name: string, data: Uint8Array) => Promise<void>;
    /**
     * Sends a profile to be considered for shipping with VUEPort, with the
     * note the person wrote beside it. Resolves to whether it was new; throws
     * with a message to show when it did not get there. Without it there is
     * no Share button.
     */
    shareProfile?: (file: GamepadProfileFile, note: string) => Promise<'received' | 'duplicate'>;
    /**
     * The host's own actions a pad control can be bound to — the command
     * palette, where the host has one. Listed first among the actions; absent,
     * none are offered, though a preset's binding for one is still kept.
     */
    uiActions?: readonly GamepadUiAction[];
}

export default function GamePadBindings(props: GamePadBindingsProps): React.JSX.Element {
    const { settings, notifications, tabs, loadDatabase, onChange, exportFile, shareProfile, uiActions } = props;

    /** The device-name database, once it has arrived. */
    const [database, setDatabase] = React.useState<GamepadDatabase | undefined>(undefined);
    React.useEffect(() => {
        let canceled = false;
        // Failing to load it is not worth reporting: the page works without it,
        // only with less friendly names, and a toast about a names file would
        // be noise about something nobody asked for.
        loadDatabase?.().then(
            loaded => { if (!canceled) { setDatabase(loaded); } },
            () => undefined,
        );
        return () => { canceled = true; };
    }, [loadDatabase]);

    /**
     * Which connected pad is being configured, by the Gamepad API's own slot.
     *
     * By slot rather than by device key, because two pads of the same model
     * share a key — there is nothing in a browser's id to tell them apart —
     * and picking one of a pair has to be possible even though they will then
     * share a mapping.
     */
    const [selected, setSelected] = React.useState<number | undefined>(undefined);
    const [capture, setCapture] = React.useState<PadCapture | undefined>(undefined);
    const [hovered, setHovered] = React.useState<EmulatorGamePadButton | undefined>(undefined);
    /** The Share panel, while it is open: the note, and how sending went. */
    const [sharing, setSharing] = React.useState<{
        note: string,
        state: 'editing' | 'sending' | 'received' | 'duplicate' | 'failed',
        error?: string,
    } | undefined>(undefined);
    /** Which sources are physically held right now, as source ids. */
    const [pressed, setPressed] = React.useState<Set<string>>(() => new Set());
    const [, bump] = React.useReducer((n: number) => n + 1, 0);

    /** The pads the page can see. Re-read when one is plugged in or out. */
    const [pads, setPads] = React.useState<Gamepad[]>(() => connectedGamepadList());
    React.useEffect(() => onGamepadsChanged(() => setPads(connectedGamepadList())), []);

    const stored = settings.get('gamepadProfiles');
    const players = settings.get('gamepadPlayers');
    /** Percent; 0 is off. */
    const vibration = settings.get('gamepadRumbleIntensity');
    /** What it goes back to: the host's default where it has its own, ours otherwise. */
    const standardVibration = settings.defaults?.gamepadRumbleIntensity ?? VUEPORT_DEFAULTS.gamepadRumbleIntensity;
    const vibrationLabel = nls.localize('vueport/input/gamePads/vibration', 'Vibration');

    // The pad being configured: the one chosen, or the first connected. Held
    // as a slot rather than an object, since `getGamepads` hands back a fresh
    // snapshot on every call and nothing survives between them.
    const pad = pads.find(candidate => candidate.index === selected) ?? pads[0];

    // Re-resolved whenever the stored profiles change, which they do by
    // identity: `save` writes a new array through the settings, so the next
    // render reads a different one and this recomputes.
    const resolved = React.useMemo(
        () => pad ? resolveGamepadProfile(pad, stored, database) : undefined,
        [pad, stored, database],
    );
    const profile = resolved?.profile;
    const standard = pad?.mapping === 'standard';
    /**
     * The device's own names for its controls, when its profile came from a
     * bundled one that has them — kept through edits, since a profile keeps
     * the preset it was built from.
     */
    const labels = gamepadPreset(profile?.preset)?.labels;
    /** What the dead zone goes back to: the pad's preset's own, or the default. */
    const standardDeadZone = resolved?.preset?.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE;

    /**
     * Poll the pad while this page is open.
     *
     * Its own loop rather than the emulator's, because this runs whether or not
     * a game is loaded — the settings are reachable from the welcome screen —
     * and because what it wants is different: every source held, not the folded
     * Virtual Boy mask. Stopped as soon as the page goes away.
     */
    const captureRef = React.useRef(capture);
    captureRef.current = capture;
    const profileRef = React.useRef(profile);
    profileRef.current = profile;
    const resolvedRef = React.useRef(resolved);
    resolvedRef.current = resolved;
    /**
     * Where the loop reaches what to do with a press.
     *
     * Through a ref rather than closed over, because the loop is installed once
     * per pad while `bindSource` closes over the stored profiles — which every
     * save replaces. A run through all fourteen buttons would otherwise write
     * each one against the list as it was before the first, and land on the
     * settings as a single button changed.
     */
    const bindRef = React.useRef<(source: GamepadSource) => void>(() => undefined);

    React.useEffect(() => {
        if (!pad) {
            return undefined;
        }
        const slot = pad.index;
        let handle = 0;
        let previous = new Set<string>();
        // Which axes are hat switches. Seeded from what is already bound, so a
        // mapped d-pad lights up even if it is held as the page opens, and
        // grown by every reading from then on.
        const hats = new Set<number>(Object.values(profileRef.current?.buttons ?? {})
            .flat()
            .filter(source => source?.kind === 'hat')
            .map(source => source!.index));
        const frame = (): void => {
            handle = requestAnimationFrame(frame);
            const live = connectedGamepadList().find(candidate => candidate.index === slot);
            if (!live) {
                return;
            }
            const held = readPressedSources(
                live, profileRef.current?.deadZone ?? DEFAULT_GAMEPAD_DEAD_ZONE, hats);
            // A press is an edge: the settings react to a button going down,
            // not to it being held, or one held while the page opened would
            // bind itself immediately.
            const waiting = captureRef.current;
            if (waiting) {
                for (const id of held) {
                    if (!previous.has(id)) {
                        const source = parseGamepadSource(id);
                        if (source) {
                            bindRef.current(source);
                            break;
                        }
                    }
                }
            }
            previous = held;
            // Only re-render when the set actually changed: this runs sixty
            // times a second and most frames nothing is held at all.
            setPressed(current => sameSet(current, held) ? current : held);
        };
        handle = requestAnimationFrame(frame);
        return () => cancelAnimationFrame(handle);
        // Only the slot: everything else the loop needs is read fresh through
        // the refs above, and re-installing it on every render would throw
        // away the previous-frame state the edge detection depends on.
    }, [pad?.index]);

    /** Write a profile back, replacing whatever was stored for this device. */
    const save = (next: GamepadProfile): void => {
        // Edited back to exactly the preset: nothing of the person's own is left to keep.
        const preset = resolvedRef.current?.preset;
        const updated = preset && gamepadProfileMatchesPreset(next, preset)
            ? forgetGamepadProfile(stored, next.device)
            : storeGamepadProfile(stored, next);
        settings.set('gamepadProfiles', updated).catch(() => undefined);
        bump();
        onChange?.();
    };

    /**
     * Put the source that was just pressed on whatever is being asked for.
     *
     * What is being asked for, and the profile it lands in, come through the
     * refs above: a run's later steps would otherwise still be answering the
     * first one's question.
     */
    const bindSource = (source: GamepadSource): void => {
        const waiting = captureRef.current;
        const current = profileRef.current;
        if (!waiting || !current) {
            return;
        }
        if (waiting.action !== undefined) {
            save(assignGamepadAction(current, waiting.action, source, waiting.add));
            setCapture(undefined);
            return;
        }
        if (waiting.turbo !== undefined) {
            save(assignGamepadTurbo(current, waiting.turbo, source, waiting.add));
            setCapture(undefined);
            return;
        }
        if (waiting.button === undefined) {
            return;
        }
        const next = assignGamepadButton(current, waiting.button, source, waiting.add);
        if (!waiting.run) {
            save(next);
            setCapture(undefined);
            return;
        }
        // A run saves as it goes rather than at the end, unlike the keyboard's:
        // there, an abort has to leave the old keys alone because every step
        // overwrites one. Here each step is a button somebody just physically
        // pressed and watched land, and throwing fourteen of those away because
        // the fifteenth was awkward is the worse trade.
        save(next);
        const { step, total, queue } = waiting.run;
        const [nextButton, ...rest] = queue;
        if (!nextButton) {
            setCapture(undefined);
            return;
        }
        setCapture({
            button: nextButton,
            title: padButtonName(nextButton, buttonLabel(nextButton)),
            run: { step: step + 1, total, queue: rest },
        });
    };
    bindRef.current = bindSource;

    // Escape gets out of a capture, the same as it does on the keyboard pages.
    // Nothing else here comes from the keyboard: the bindings arrive off the
    // controller, through the loop above.
    useCaptureKeys(capture !== undefined, event => {
        if (event.key !== 'Escape') {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        setCapture(undefined);
    });

    const buttonLabel = (button: EmulatorGamePadButton): string =>
        EMULATOR_GAMEPAD_LABELS[button]();

    /** Whether a control is drawn lit: hovered, being asked for, or held. */
    const isHeld = (button: EmulatorGamePadButton): boolean =>
        (profile?.buttons[button] ?? []).some(source => pressed.has(gamepadSourceId(source)));

    /** The same for a turbo button, and for an action. */
    const isHeldOnTurbo = (button: EmulatorGamePadButton): boolean =>
        (profile?.turbo?.[button] ?? []).some(source => pressed.has(gamepadSourceId(source)));
    const isActionHeld = (action: GamepadPadAction): boolean =>
        (profile?.actions?.[action] ?? []).some(source => pressed.has(gamepadSourceId(source)));

    const isWaitingFor = (target: PadTarget): boolean =>
        capture !== undefined && sameTarget(capture, target);

    const caption = (button: EmulatorGamePadButton): string => {
        if (isWaitingFor({ button })) {
            return nls.localize('vueport/input/gamePads/pressButton', 'press a button…');
        }
        return captionLabel(profile?.buttons[button], profile?.family ?? 'generic', standard, labels);
    };

    /** Walk every Virtual Boy button, asking for a pad control for each. */
    const setEveryButton = (): void => {
        const [first, ...queue] = PAD_BUTTONS;
        setCapture({
            button: first,
            title: padButtonName(first, buttonLabel(first)),
            run: { step: 1, total: PAD_BUTTONS.length, queue },
        });
    };

    /** Forget everything recorded for this pad, back to what is detected. */
    const forget = async (): Promise<void> => {
        if (!profile) {
            return;
        }
        const toPreset = resolved?.preset !== undefined;
        const confirmed = await notifications.confirm({
            title: toPreset
                ? nls.localize('vueport/input/gamePads/resetPresetQuestion', 'Reset to Preset?')
                : nls.localize('vueport/input/gamePads/forgetQuestion', 'Forget Controller?'),
            message: nls.localize(
                'vueport/input/gamePads/resetPresetMessage',
                'All changes you made to the mapping of {0} will be lost.',
                profile.label ?? '',
            ),
            okLabel: toPreset
                ? nls.localize('vueport/input/gamePads/resetPreset', 'Reset to preset')
                : nls.localize('vueport/input/gamePads/forget', 'Forget this controller'),
        });
        if (!confirmed) {
            return;
        }
        setCapture(undefined);
        settings.set('gamepadProfiles', forgetGamepadProfile(stored, profile.device))
            .catch(() => undefined);
        bump();
        onChange?.();
    };

    const setPlayer = (value: number | undefined): void => {
        if (!profile) {
            return;
        }
        const next = { ...players };
        if (value === undefined) {
            delete next[profile.device];
        } else {
            next[profile.device] = value;
        }
        settings.set('gamepadPlayers', next).catch(() => undefined);
        bump();
        onChange?.();
    };

    /**
     * Write this pad's mapping out as a profile file — the shape VUEPort
     * bundles in `src/data/gamepad-profiles/`, so a recorded mapping can ship.
     */
    const exportProfile = (): void => {
        if (!profile || !pad || !exportFile) {
            return;
        }
        const file = gamepadProfileFile(profile, pad);
        const data = new TextEncoder().encode(JSON.stringify(file, undefined, 4) + '\n');
        exportFile(`${file.id}.json`, data).catch(() => undefined);
    };

    const sendProfile = (): void => {
        if (!profile || !pad || !shareProfile || !sharing) {
            return;
        }
        const note = sharing.note;
        setSharing({ note, state: 'sending' });
        shareProfile(gamepadProfileFile(profile, pad), note).then(
            outcome => setSharing({ note, state: outcome }),
            (error: unknown) => setSharing({
                note,
                state: 'failed',
                error: error instanceof Error ? error.message : String(error),
            }),
        );
    };

    const setDeadZone = (value: number): void => {
        if (profile) {
            save({ ...profile, deadZone: value });
        }
    };

    // ------------------------------------------------------------- rendering

    // The Gamepad API withholds a pad until a button on it is pressed — the
    // list of devices attached to a machine is a fingerprint — so "none
    // connected" really means "none used yet", and saying so is the difference
    // between a page that looks broken and one that tells you what to do.
    if (!pad || !profile || !resolved) {
        return <InputPage top={tabs}>
            <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/input/gamePads/none', 'No controller detected')}
                    description={nls.localize(
                        'vueport/input/gamePads/noneDescription',
                        'Connect a controller and press any button on it. Browsers keep a controller hidden from a page until it is used.',
                    )}
                    icon={<GameController size={32} />}
                />
            </div>
        </InputPage>;
    }

    const assignedPlayer = players[profile.device];
    const canRumble = gamepadCanRumble(pad);
    /** What the control being asked for is bound to right now. */
    const boundTo: GamepadSource[] = capture === undefined
        ? []
        : (capture.action !== undefined
            ? profile.actions?.[capture.action]
            : capture.turbo !== undefined
                ? profile.turbo?.[capture.turbo]
                : profile.buttons[capture.button!]) ?? [];

    /** The preset a stored mapping is compared against; none when nothing was changed. */
    const baseline = resolved.origin === 'stored' ? resolved.preset : undefined;
    const sourceIds = (sources: GamepadSource[] | undefined): Set<string> =>
        new Set((sources ?? []).map(gamepadSourceId));

    /** One row of a list — the whole row is the button, as on the key pages. */
    const row = (
        name: React.ReactNode,
        target: PadTarget,
        sources: GamepadSource[] | undefined,
        lit: boolean,
    ): React.JSX.Element => {
        const waiting = isWaitingFor(target);
        const original = target.action !== undefined
            ? baseline?.actions?.[target.action]
            : target.turbo !== undefined
                ? baseline?.turbo?.[target.turbo]
                : baseline?.buttons[target.button!];
        const changed = baseline !== undefined && !sameSet(sourceIds(sources), sourceIds(original));
        return <BindingRow
            key={target.button ?? (target.turbo !== undefined ? `turbo-${target.turbo}` : target.action)}
            name={name}
            value={waiting
                ? nls.localize('vueport/input/gamePads/pressButton', 'press a button…')
                : sourcesLabel(sources, profile.family, standard, labels)}
            lit={lit}
            waiting={waiting}
            changed={changed}
            changedTitle={changed
                ? nls.localize('vueport/input/gamePads/changedFromPreset', 'Changed from the preset: {0}',
                    sourcesLabel(original, profile.family, standard, labels))
                : undefined}
            onClick={() => setCapture({
                ...target,
                title: target.turbo !== undefined ? <TurboTitle name={name} /> : name,
            })}
            onHoverIn={() => (target.button ?? target.turbo) && setHovered(target.button ?? target.turbo)}
            onHoverOut={() => (target.button ?? target.turbo) && setHovered(undefined)}
        />;
    };

    return <InputPage top={<>
        {tabs}
        {pads.length > 1
            ? <Select
                value={String(pad.index)}
                onChange={next => {
                    setSelected(Number(next));
                    setCapture(undefined);
                }}
                options={pads.map(candidate => ({
                    value: String(candidate.index),
                    label: padName(resolveGamepadProfile(candidate, stored, database)),
                }))}
            />
            : <PadBadge label={padName(resolved)} title={pad.id} />}
        <InputSpacer />
    </>}>
        <BindingBody>
            <BindingCard>
                <PadDiagrams>
                    {(['front', 'back'] as const).map(face =>
                        <PadDiagram
                            key={face}
                            face={face}
                            caption={caption}
                            // Held wins over hovered: while a button is down,
                            // what lights up is the answer to "did that land
                            // where I meant it to".
                            isLit={button => isHeld(button) || hovered === button
                                || isWaitingFor({ button })}
                            isWaiting={button => isWaitingFor({ button })}
                            onSelect={button => setCapture({
                                button,
                                title: padButtonName(button, buttonLabel(button)),
                            })}
                            onHover={setHovered}
                        />)}
                </PadDiagrams>
                {capture &&
                    <CaptureStrip
                        title={capture.title}
                        run={capture.run}
                        prompt={capture.add
                            ? nls.localize(
                                'vueport/input/gamePads/pressAddPrompt',
                                'Press another control to add it, or Escape to stop.',
                            )
                            : nls.localize(
                                'vueport/input/gamePads/pressPrompt',
                                'Press the control on your controller, or Escape to stop.',
                            )}
                        detail={capture.run
                            ? <p className='vp-input-capture-note'>
                                {nls.localize(
                                    'vueport/input/gamePads/runNote',
                                    'Each button is saved as you press it, so stopping keeps what you have set so far.',
                                )}
                            </p>
                            : <p className='vp-input-capture-current'>
                                {boundTo.length > 0
                                    ? <>
                                        {nls.localize('vueport/input/gamePads/currentlyOn', 'Currently on:')}
                                        {/* Each one removable on its own: with
                                            several on a control, "Clear" is
                                            too blunt to drop just one. */}
                                        {boundTo.map(source =>
                                            <button
                                                key={gamepadSourceId(source)}
                                                type='button'
                                                className='vp-input-source-chip'
                                                title={nls.localize('vueport/input/gamePads/removeSource', 'Remove')}
                                                onClick={() => save(removeGamepadSource(profile, source))}
                                            >
                                                {sourceLabel(source, profile.family, standard, false, labels)}
                                                <X size={11} />
                                            </button>)}
                                    </>
                                    : nls.localize('vueport/input/gamePads/currentlyUnmapped', 'Not mapped to anything.')}
                            </p>}
                        actions={<>
                            <CancelCapture onClick={() => setCapture(undefined)} />
                            {!capture.run && !capture.add && boundTo.length > 0 &&
                                <button
                                    type='button'
                                    className='vp-button secondary'
                                    onClick={() => setCapture({ ...capture, add: true })}
                                >
                                    {nls.localize('vueport/input/gamePads/addAnother', 'Add another')}
                                </button>}
                            {!capture.run && boundTo.length > 0 &&
                                <button
                                    type='button'
                                    className='vp-button secondary'
                                    onClick={() => {
                                        save(capture.action !== undefined
                                            ? clearGamepadAction(profile, capture.action)
                                            : capture.turbo !== undefined
                                                ? clearGamepadTurbo(profile, capture.turbo)
                                                : clearGamepadButton(profile, capture.button!));
                                        setCapture(undefined);
                                    }}
                                >
                                    {nls.localize('vueport/input/gamePads/clear', 'Clear')}
                                </button>}
                        </>}
                    />}

                <div className='vp-preset-row'>
                    <label className={'vp-gamepad-deadzone'
                        + (profile.deadZone !== standardDeadZone ? ' is-changed' : '')}>
                        {nls.localize('vueport/input/gamePads/deadZone', 'Stick dead zone')}
                        <input
                            type='range'
                            min={GAMEPAD_DEAD_ZONE_RANGE.min * 100}
                            max={GAMEPAD_DEAD_ZONE_RANGE.max * 100}
                            step={5}
                            value={Math.round(profile.deadZone * 100)}
                            onChange={event => setDeadZone(Number(event.target.value) / 100)}
                        />
                        <span className='vp-gamepad-changed' />
                        <span className='vp-gamepad-deadzone-value'>
                            {Math.round(profile.deadZone * 100)}%
                        </span>
                    </label>
                    {/* The one control here that is not the selected pad's:
                        vibration is set for every controller at once, because
                        it answers a question about the game rather than about
                        a device. A strength rather than a switch: a pad's
                        motors pull far harder than the Rumble Pack's, and how
                        much of that somebody wants is theirs to say; 0 is off. */}
                    <label
                        className={'vp-gamepad-deadzone'
                            + (canRumble ? '' : ' is-disabled')
                            + (vibration !== standardVibration ? ' is-changed' : '')}
                        title={nls.localize(
                            'vueport/input/gamePads/vibrationHint',
                            'How strongly to play a game\'s rumble effects on your controller when no Rumble Pack \
is connected; 0 is off. The Rumble Pack\'s effects are approximated: each becomes a short pulse.',
                        )}
                    >
                        {vibrationLabel}
                        <input
                            type='range'
                            min={0}
                            max={100}
                            step={5}
                            value={vibration}
                            disabled={!canRumble}
                            onChange={event => {
                                settings.set('gamepadRumbleIntensity', Number(event.target.value)).catch(() => undefined);
                                bump();
                            }}
                        />
                        <span className='vp-gamepad-changed' />
                        <span className='vp-gamepad-deadzone-value'>
                            {vibration > 0 ? `${vibration}%` : nls.localize('vueport/input/gamePads/vibrationOff', 'Off')}
                        </span>
                        {/* Says why the slider is greyed out. */}
                        {!canRumble &&
                            <span className='vp-gamepad-no-rumble' title={nls.localize(
                                'vueport/input/gamePads/noRumbleHint',
                                'The browser gives a page vibration only for controllers it knows how to drive. \
This one may have motors, but they cannot be reached from here.',
                            )}>
                                <Warning size={13} />
                                {nls.localize('vueport/input/gamePads/noRumble', 'not available for this controller')}
                            </span>}
                    </label>
                    <TurboRateSlider settings={settings} onChange={onChange} />
                </div>

                <div className='vp-preset-row'>
                    <span className='vp-gamepad-deadzone'>
                        {nls.localize('vueport/input/gamePads/drives', 'Drives')}
                    </span>
                    <RadioSelect
                        options={[
                            { value: 'auto', label: nls.localize('vueport/input/gamePads/driveAuto', 'Either player') },
                            { value: 1, label: nls.localize('vueport/input/gamePads/player1', 'Player 1') },
                            { value: 2, label: nls.localize('vueport/input/gamePads/player2', 'Player 2') },
                        ]}
                        defaultValue={assignedPlayer ?? 'auto'}
                        onChange={options => {
                            const value = options[0]?.value;
                            setPlayer(typeof value === 'number' ? value : undefined);
                        }}
                    />
                </div>

                <div className='vp-preset-row'>
                    {exportFile &&
                        <button
                            type='button'
                            className='vp-button secondary'
                            title={nls.localize(
                                'vueport/input/gamePads/exportHint',
                                'Save this controller\'s mapping as a profile file, the format VUEPort ships its controller profiles in.',
                            )}
                            onClick={exportProfile}
                        >
                            {nls.localize('vueport/input/gamePads/export', 'Export…')}
                        </button>}
                    {/* Only a raw pad's own recording is worth shipping. A pad
                        the browser normalizes already gets the standard
                        presets, and a mapping of one of those is somebody's
                        preference, which a bundled profile would then press
                        on everyone with that pad. */}
                    {shareProfile && resolved.origin === 'stored' && !standard &&
                        <button
                            type='button'
                            className='vp-button secondary'
                            onClick={() => setSharing(current => current ?? { note: '', state: 'editing' })}
                        >
                            {nls.localize('vueport/input/gamePads/share', 'Share…')}
                        </button>}
                    <span className='vp-input-spacer' />
                    {resolved.origin === 'stored' &&
                        <button type='button' className='vp-button secondary' onClick={() => { forget().catch(() => undefined); }}>
                            {resolved.preset
                                ? nls.localize('vueport/input/gamePads/resetPreset', 'Reset to preset')
                                : nls.localize('vueport/input/gamePads/forget', 'Forget this controller')}
                        </button>}
                    <SetAllButton
                        label={nls.localize('vueport/input/gamePads/setAll', 'Set all buttons…')}
                        onClick={setEveryButton}
                    />
                </div>

                {sharing && shareProfile && !standard &&
                    <div className='vp-input-capture'>
                        <div className='vp-input-capture-head'>
                            <span className='vp-input-capture-title'>
                                {nls.localize('vueport/input/gamePads/shareTitle', 'Share this mapping')}
                            </span>
                        </div>
                        <p className='vp-input-capture-prompt'>
                            {nls.localize(
                                'vueport/input/gamePads/shareExplain',
                                'Your browser does not know this controller, so everyone who has one has to map it by hand. \
Send your mapping to the VUEPort team and it can ship with VUEPort, set up for them out of the box.',
                            )}
                        </p>
                        <p className='vp-input-capture-note'>
                            {nls.localize(
                                'vueport/input/gamePads/shareWhat',
                                'What is sent: the controller\'s name and ids, how this browser and system report it, \
and what every button and action is set to — the same file Export… saves. Nothing else, and nothing that identifies you.',
                            )}
                        </p>
                        {sharing.state === 'editing' || sharing.state === 'sending' || sharing.state === 'failed'
                            ? <textarea
                                className='vp-input vp-gamepad-share-note'
                                rows={2}
                                maxLength={500}
                                placeholder={nls.localize(
                                    'vueport/input/gamePads/sharePlaceholder',
                                    'Optional: anything worth knowing — how it is connected (USB, Bluetooth), which mode it is in.',
                                )}
                                value={sharing.note}
                                disabled={sharing.state === 'sending'}
                                onChange={event => setSharing({ note: event.target.value, state: 'editing' })}
                            />
                            : <p className='vp-input-capture-current'>
                                {sharing.state === 'received'
                                    ? nls.localize('vueport/input/gamePads/shareReceived', 'Sent — thank you.')
                                    : nls.localize('vueport/input/gamePads/shareDuplicate',
                                        'This exact mapping has been sent already — thank you.')}
                            </p>}
                        {sharing.state === 'failed' &&
                            <p className='vp-input-capture-note is-warning'>
                                <Warning size={13} /> {nls.localize(
                                    'vueport/input/gamePads/shareFailed', 'Could not send it: {0}', sharing.error ?? '')}
                            </p>}
                        <div className='vp-input-capture-actions'>
                            {sharing.state === 'received' || sharing.state === 'duplicate'
                                ? <button type='button' className='vp-button secondary' onClick={() => setSharing(undefined)}>
                                    {nls.localize('vueport/input/gamePads/shareClose', 'Close')}
                                </button>
                                : <>
                                    <button
                                        type='button'
                                        className='vp-button'
                                        disabled={sharing.state === 'sending'}
                                        onClick={sendProfile}
                                    >
                                        {sharing.state === 'sending'
                                            ? nls.localize('vueport/input/gamePads/shareSending', 'Sending…')
                                            : nls.localize('vueport/input/gamePads/shareSend', 'Send')}
                                    </button>
                                    <CancelCapture onClick={() => setSharing(undefined)} />
                                </>}
                        </div>
                    </div>}
            </BindingCard>

            <BindingLists>
                <BindingList title={nls.localize('vueport/input/gamePad', 'Game pad')}>
                    {PAD_BUTTONS.map(button => row(
                        padButtonName(button, buttonLabel(button)),
                        { button },
                        profile.buttons[button],
                        isHeld(button) || hovered === button,
                    ))}
                </BindingList>
                <BindingList title={nls.localize('vueport/input/turbo/title', 'Turbo')}>
                    {EMULATOR_TURBO_BUTTONS.map(button => row(
                        padButtonName(button, buttonLabel(button)),
                        { turbo: button },
                        profile.turbo?.[button],
                        isHeldOnTurbo(button) || hovered === button,
                    ))}
                </BindingList>
                <BindingList title={nls.localize('vueport/input/emulator', 'Emulator')}>
                    {[...(uiActions ?? []), ...PAD_ACTIONS].map(action => row(
                        actionLabel(action),
                        { action },
                        profile.actions?.[action],
                        isActionHeld(action),
                    ))}
                </BindingList>
                <BindingList title={nls.localize('vueport/input/macros', 'Macros')}>
                    {EMULATOR_MACRO_SLOTS.map(gamepadMacroAction).map(action => row(
                        actionLabel(action),
                        { action },
                        profile.actions?.[action],
                        isActionHeld(action),
                    ))}
                </BindingList>
            </BindingLists>
        </BindingBody>
    </InputPage>;
}

function padName(resolved: ResolvedGamepadProfile): string | undefined {
    return resolved.origin === 'unmapped'
        ? nls.localize('vueport/input/gamePads/unknown', 'Unknown controller')
        : resolved.profile.label;
}

/** Whether two sets hold the same members. */
function sameSet(a: Set<string>, b: Set<string>): boolean {
    if (a.size !== b.size) {
        return false;
    }
    for (const value of a) {
        if (!b.has(value)) {
            return false;
        }
    }
    return true;
}

function actionLabel(action: GamepadPadAction): string {
    if (action === 'commandPalette') {
        return nls.localize('vueport/input/gamePads/commandPalette', 'Command Palette');
    }
    const slot = gamepadMacroSlot(action);
    if (slot !== undefined) {
        return EMULATOR_MACRO_SLOT_COMMANDS[slot - 1].label ?? action;
    }
    return EMULATOR_ACTION_COMMANDS[action as EmulatorAction].label ?? action;
}

/**
 * What each Virtual Boy button is called here.
 *
 * Read off the commands the keyboard pages already label, so the two pages name
 * the same button the same way; through accessors, because the commands read
 * their own labels lazily and the host installs its translations after this
 * module is imported.
 */
const EMULATOR_GAMEPAD_LABELS: Record<EmulatorGamePadButton, () => string> = {
    lUp: () => EmulatorCommands.INPUT_L_UP.label ?? '',
    lDown: () => EmulatorCommands.INPUT_L_DOWN.label ?? '',
    lLeft: () => EmulatorCommands.INPUT_L_LEFT.label ?? '',
    lRight: () => EmulatorCommands.INPUT_L_RIGHT.label ?? '',
    rUp: () => EmulatorCommands.INPUT_R_UP.label ?? '',
    rDown: () => EmulatorCommands.INPUT_R_DOWN.label ?? '',
    rLeft: () => EmulatorCommands.INPUT_R_LEFT.label ?? '',
    rRight: () => EmulatorCommands.INPUT_R_RIGHT.label ?? '',
    select: () => EmulatorCommands.INPUT_SELECT.label ?? '',
    start: () => EmulatorCommands.INPUT_START.label ?? '',
    b: () => EmulatorCommands.INPUT_B.label ?? '',
    a: () => EmulatorCommands.INPUT_A.label ?? '',
    lTrigger: () => EmulatorCommands.INPUT_L_TRIGGER.label ?? '',
    rTrigger: () => EmulatorCommands.INPUT_R_TRIGGER.label ?? '',
};
