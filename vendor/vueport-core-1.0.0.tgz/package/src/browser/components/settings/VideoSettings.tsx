import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { VbRenderingMode } from '../../../common/vb-constants';
import EmulatorPalettes from '../EmulatorPalettes';
import {
    ChoiceSetting,
    RenderingModeSetting,
    SettingsFields,
    SettingsPaneProps,
    SliderSetting,
    SwitchSetting,
    useSetting,
} from './SettingFields';
import { RECORDING_SETTINGS, VIDEO_SETTINGS } from './settings-index';

/**
 * How a recording is composed, above the palette pickers.
 *
 * What the file is — its quality, its container and how large it is drawn —
 * comes first, because that applies to every recording. How the picture inside
 * it is composed follows: the switch that hands the question to the Display
 * pane, and, when it is off, the mode and the palettes this pane picks for
 * itself. The mode is not offered at all while the switch is on, rather than
 * shown doing nothing.
 */
function VideoFields(props: SettingsPaneProps): React.JSX.Element {
    const asShown = useSetting(props.settings, 'videoUseDisplaySettings');
    return <SettingsFields
        {...props}
        ids={asShown ? [...RECORDING_SETTINGS, 'videoUseDisplaySettings'] : VIDEO_SETTINGS}
    >
        <div className='vp-appearance'>
            <ChoiceSetting id='videoQuality' />
            <ChoiceSetting id='videoFormat' />
            <SliderSetting id='videoScale' />
        </div>
        <SwitchSetting id='videoUseDisplaySettings' />
        {/* The cards the Display pane uses, rather than a dropdown saying the
            same thing in words: the same question deserves the same picture. */}
        {!asShown && <RenderingModeSetting id='videoRenderingMode' />}
    </SettingsFields>;
}

/**
 * The Video pane: the Screenshots pane with the file's own settings above it —
 * a recording is a file in a container at a quality, which a still is not.
 */
export default function VideoSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications,
}): React.JSX.Element {
    const asShown = useSetting(props.settings, 'videoUseDisplaySettings');
    const mode = useSetting(props.settings, 'videoRenderingMode');
    return <EmulatorPalettes
        settings={props.settings}
        notifications={props.notifications}
        target='video'
        sections={asShown ? 'none' : mode === VbRenderingMode.ANAGLYPH ? 'both' : 'color'}
    >
        <VideoFields {...props} />
    </EmulatorPalettes>;
}
