import React from 'react';
import { VueportNotifications } from '../../../common/emulator-host';
import { VbRenderingMode } from '../../../common/vb-constants';
import EmulatorPalettes from '../EmulatorPalettes';
import {
    RenderingModeSetting,
    SettingsFields,
    SettingsPaneProps,
    SliderSetting,
    SwitchSetting,
    useSetting,
} from './SettingFields';
import { SCREENSHOT_SETTINGS } from './settings-index';

/**
 * How a screenshot is composed, above the palette pickers — the Video pane's
 * arrangement, pointed at the screenshot settings.
 *
 * How large the file is comes first, because that applies to every shot. Then
 * the switch that hands the rest of the question to the Display pane, and,
 * when it is off, the mode and the palettes this pane picks for itself. The
 * mode is not offered at all while the switch is on, rather than shown doing
 * nothing.
 */
function ScreenshotFields(props: SettingsPaneProps): React.JSX.Element {
    const asShown = useSetting(props.settings, 'screenshotUseDisplaySettings');
    return <SettingsFields
        {...props}
        ids={asShown
            ? ['screenshotScale', 'screenshotUseDisplaySettings']
            : SCREENSHOT_SETTINGS}
    >
        <div className='vp-appearance'>
            <SliderSetting id='screenshotScale' />
        </div>
        <SwitchSetting id='screenshotUseDisplaySettings' />
        {!asShown && <RenderingModeSetting id='screenshotRenderingMode' />}
    </SettingsFields>;
}

/**
 * The Screenshots pane: the Display pane pointed at the screenshot settings,
 * and with only the palette the chosen mode actually uses — the mode is settled
 * here rather than being changed underneath it.
 */
export default function ScreenshotSettings(props: SettingsPaneProps & {
    notifications: VueportNotifications,
}): React.JSX.Element {
    const asShown = useSetting(props.settings, 'screenshotUseDisplaySettings');
    const mode = useSetting(props.settings, 'screenshotRenderingMode');
    return <EmulatorPalettes
        settings={props.settings}
        notifications={props.notifications}
        target='screenshot'
        sections={asShown ? 'none' : mode === VbRenderingMode.ANAGLYPH ? 'both' : 'color'}
    >
        <ScreenshotFields {...props} />
    </EmulatorPalettes>;
}
