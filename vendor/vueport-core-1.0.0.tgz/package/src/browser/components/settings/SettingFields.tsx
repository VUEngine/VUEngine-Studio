import React from 'react';
import styled from 'styled-components';
import { nls } from '../../../common/emulator-nls';
import { VUEPORT_DEFAULTS, VueportConfig, VueportSettings } from '../../../common/emulator-settings';
import { paletteDecorationColor, resolvePalette } from '../../emulator-types';
import { VueportSettingSchema, vueportSettingsSchema } from '../../emulator-settings-schema';
import EmulatorRenderingModeField from '../EmulatorRenderingModeField';
import ColorField from '../kit/ColorField';
import { VueportHover } from '../kit/KitContext';
import RadioSelect from '../kit/RadioSelect';
import Range from '../kit/Range';
import ResetButton from '../kit/ResetButton';
import Switch from '../kit/Switch';
import Select from '../kit/Select';
import VContainer from '../kit/VContainer';

/**
 * The parts a settings pane is built from.
 *
 * A pane writes its controls out — `<SwitchSetting id='rewindEnabled' />` —
 * rather than handing over a list of ids for something else to interpret, so
 * which control a setting gets, where it sits and what it sits beside are all
 * read and changed in the pane itself. What still comes from
 * {@link vueportSettingsSchema} is what a setting *is*: its title, its
 * description, its range and its choices, which the application's own
 * preferences page reads from the same declaration.
 */

/** The settings whose value has the given type — what each control can be pointed at. */
type SettingsOf<T> = {
    [K in keyof VueportConfig]: VueportConfig[K] extends T ? K : never
}[keyof VueportConfig];

export type BooleanSetting = SettingsOf<boolean>;
export type StringSetting = SettingsOf<string>;
export type NumberSetting = SettingsOf<number>;

/** What every pane is handed. */
export interface SettingsPaneProps {
    settings: VueportSettings;
    /**
     * Passed in rather than taken from the kit's context: the settings window
     * is not inside one, and the controls it uses want an explicit hover.
     */
    hover: VueportHover;
    /**
     * Which settings this host has settled for itself, and why.
     *
     * Returns the reason a setting cannot be changed here, or undefined when
     * it can. Shown rather than hidden: a setting that simply vanishes in one
     * application looks like a feature that is missing, where one shown fixed
     * with a reason beside it says what the application does and why it has no
     * choice.
     */
    readOnly?: (id: keyof VueportConfig) => string | undefined;
    /**
     * The settings dialog's running search. When at least one setting in this
     * pane matches every word of it, only the matches are shown; when none do,
     * the query was meant for another pane and everything is shown as normal.
     */
    search?: string;
}

interface SettingsScope extends SettingsPaneProps {
    /** Whether the search leaves this setting on screen. */
    shows: (id: keyof VueportConfig) => boolean;
}

const ScopeContext = React.createContext<SettingsScope | undefined>(undefined);

function useScope(): SettingsScope {
    const scope = React.useContext(ScopeContext);
    if (!scope) {
        throw new Error('A settings control has to sit inside <SettingsFields>.');
    }
    return scope;
}

/** Read a setting, and redraw whenever it changes elsewhere. */
export function useSetting<K extends keyof VueportConfig>(
    settings: VueportSettings,
    id: K,
): VueportConfig[K] {
    const [, redraw] = React.useReducer((version: number) => version + 1, 0);
    React.useEffect(() => {
        const listener = settings.onDidChange(changed => {
            if (changed === id) {
                redraw();
            }
        });
        return () => listener.dispose();
    }, [settings, id]);
    return settings.get(id);
}

function schemaOf(id: keyof VueportConfig): VueportSettingSchema | undefined {
    return vueportSettingsSchema()[id];
}

/**
 * What a reset puts a setting back to.
 *
 * The host's answer where it has one, since that is what its people see when
 * they first open it. Resetting to the emulator's own answer would offer to
 * undo the way the application ships.
 */
function standardValue<K extends keyof VueportConfig>(
    settings: VueportSettings,
    id: K,
): VueportConfig[K] {
    return settings.defaults?.[id] ?? VUEPORT_DEFAULTS[id];
}

/** Everything a query could match a setting on, lower-cased. */
function haystack(schema: VueportSettingSchema): string {
    return [
        schema.title,
        schema.description,
        ...(schema.enumItemLabels ?? []),
        ...(schema.enumItemNames ?? []),
        ...(schema.enumItemDescriptions ?? []),
    ].filter(Boolean).join(' ').toLowerCase();
}

/**
 * The settings a query leaves on screen, or undefined when it touches none of
 * them — in which case it was meant for another pane and this one shows in full.
 */
function matchingSettings(
    ids: readonly (keyof VueportConfig)[],
    search: string | undefined,
): Set<keyof VueportConfig> | undefined {
    const terms = (search ?? '').toLowerCase().split(/\s+/).filter(Boolean);
    if (terms.length === 0) {
        return undefined;
    }
    const matching = ids.filter(id => {
        const schema = schemaOf(id);
        return schema !== undefined && terms.every(term => haystack(schema).includes(term));
    });
    return matching.length > 0 ? new Set(matching) : undefined;
}

/**
 * A pane's settings, stacked.
 *
 * `ids` is what the pane is showing right now, which is what the search
 * filters against — a setting the pane has folded away is not one a query can
 * land on.
 */
export function SettingsFields(props: SettingsPaneProps & {
    ids: readonly (keyof VueportConfig)[],
    /** The space between the pane's blocks. Sectioned panes sit closer together. */
    gap?: number | string,
    children: React.ReactNode,
}): React.JSX.Element {
    const { ids, gap, children, ...pane } = props;
    const matching = matchingSettings(ids, pane.search);
    const scope: SettingsScope = { ...pane, shows: id => !matching || matching.has(id) };
    return <ScopeContext.Provider value={scope}>
        <VContainer gap={gap ?? 'var(--vp-space-x4)'}>{children}</VContainer>
    </ScopeContext.Provider>;
}

/** A fieldset with a legend, for a pane whose settings fall into categories. */
export function SettingsSection(props: {
    title: string,
    /** The settings it holds: a search that hides every one of them hides this too. */
    ids: readonly (keyof VueportConfig)[],
    children: React.ReactNode,
}): React.JSX.Element | null {
    const { shows } = useScope();
    if (!props.ids.some(shows)) {
        return null;
    }
    return <fieldset>
        <legend>{props.title}</legend>
        <VContainer gap={10}>{props.children}</VContainer>
    </fieldset>;
}

/**
 * Settings side by side rather than stacked — the decoration row on the
 * Display pane. Each keeps its title-description-control stack and shares the
 * available width; wrapping keeps the descriptions readable in a narrow window.
 */
const Row = styled.div`
    align-items: flex-start;
    display: flex;
    flex-wrap: wrap;
    gap: var(--vp-space-x4);

    > * {
        flex: 1 1 220px;
        min-width: 0;
    }
`;

export function SettingsRow(props: {
    /** The settings it holds: a search that hides every one of them hides this too. */
    ids: readonly (keyof VueportConfig)[],
    children: React.ReactNode,
}): React.JSX.Element | null {
    const { shows } = useScope();
    if (!props.ids.some(shows)) {
        return null;
    }
    return <Row>{props.children}</Row>;
}

/** A setting's title with its reset button right beside it. */
const TitleRow = styled.div`
    align-items: center;
    display: flex;
    gap: var(--vp-space);
`;

/** Why a setting is shown but cannot be changed here. */
const FixedNote = styled.div`
    font-size: 0.9em;
    opacity: 0.7;
    white-space: normal;
`;

/**
 * What a setting does, always visible between its title and its control — the
 * same reading order as the standalone Welcome pane's "Remembered ROMs".
 */
export const SettingDescription = styled.span`
    color: var(--vp-text-dim);
    white-space: normal;
`;

const Field = styled.div`
    display: flex;
    flex-direction: column;
    gap: var(--vp-space);
`;

/**
 * The title, description and reset button around one control.
 *
 * Nothing is hidden behind hover: every setting follows the same
 * title-description-control reading order.
 */
export function Setting(props: {
    id: keyof VueportConfig,
    children: React.ReactNode,
}): React.JSX.Element | null {
    const { settings, readOnly, shows } = useScope();
    // The control inside this already follows the setting; this is what keeps
    // the reset button beside it in step.
    useSetting(settings, props.id);
    const schema = schemaOf(props.id);
    if (!schema || !shows(props.id)) {
        return null;
    }
    const fixed = readOnly?.(props.id);
    const standard = standardValue(settings, props.id);
    return <Field>
        <TitleRow>
            <span className='vp-setting-title'>{schema.title}</span>
            <ResetButton
                disabled={settings.get(props.id) === standard || fixed !== undefined}
                onReset={() => { settings.set(props.id, standard); }}
            />
        </TitleRow>
        {schema.description && <SettingDescription>{schema.description}</SettingDescription>}
        {props.children}
        {fixed && <FixedNote>{fixed}</FixedNote>}
    </Field>;
}

const SelectionName = styled.span`
    color: var(--vp-text-dim);
`;

/**
 * What the chosen option does, under the control.
 *
 * A setting's own description says what the setting is for, and is written
 * before anything is picked; this answers the question that follows it — what
 * *this* answer gets you — so that the difference between seven rendering
 * modes or eight scales can be read rather than tried. Only for the settings
 * whose schema carries `enumItemDescriptions`: the rest have choices that say
 * enough in their own names.
 */
function SelectionNote(props: {
    schema: VueportSettingSchema,
    value: string,
}): React.JSX.Element | null {
    const index = props.schema.enum?.indexOf(props.value) ?? -1;
    const description = index < 0 ? undefined : props.schema.enumItemDescriptions?.[index];
    if (!description) {
        return null;
    }
    const name = props.schema.enumItemNames?.[index]
        ?? props.schema.enumItemLabels?.[index]
        ?? props.value;
    return <SettingDescription>
        <SelectionName>{name}</SelectionName>
        {': '}{description}
    </SettingDescription>;
}

/** The choices an enum setting offers, in the order the schema lists them. */
function optionsOf(schema: VueportSettingSchema): { value: string, label: string }[] {
    return (schema.enum ?? []).map((option, index) => ({
        value: String(option),
        label: schema.enumItemLabels?.[index] ?? String(option),
    }));
}

/** Everything a control needs about the setting it is pointed at. */
function useControl<K extends keyof VueportConfig>(id: K): {
    schema: VueportSettingSchema,
    value: VueportConfig[K],
    disabled: boolean,
    set: (value: VueportConfig[K]) => void,
    /** Nothing to undo — the setting already holds what a reset would give it. */
    isStandard: boolean,
    reset: () => void,
} {
    const { settings, readOnly } = useScope();
    const value = useSetting(settings, id);
    const disabled = readOnly?.(id) !== undefined;
    return {
        schema: schemaOf(id) ?? { type: 'string', title: id },
        value,
        disabled,
        set: (next): void => {
            settings.set(id, next);
        },
        isStandard: value === standardValue(settings, id),
        reset: (): void => {
            settings.set(id, standardValue(settings, id));
        },
    };
}

/** A boolean, as the switch every pane shows one with. */
export function SwitchSetting(props: { id: BooleanSetting }): React.JSX.Element {
    const { schema, value, disabled, set } = useControl(props.id);
    return <Setting id={props.id}>
        <Switch
            label={schema.title}
            value={value === true}
            disabled={disabled}
            onChange={set}
        />
    </Setting>;
}

/**
 * A handful of choices, as a segmented control. Past four or five it stops
 * being readable and {@link DropdownSetting} is the answer instead.
 */
export function ChoiceSetting(props: { id: StringSetting }): React.JSX.Element {
    const { schema, value, disabled, set } = useControl(props.id);
    const { hover } = useScope();
    return <Setting id={props.id}>
        <RadioSelect
            options={optionsOf(schema)}
            defaultValue={String(value)}
            disabled={disabled}
            onChange={chosen => set(String(chosen[0].value))}
            hover={hover}
        />
        <SelectionNote schema={schema} value={String(value)} />
    </Setting>;
}

/** More choices than a segmented control stays readable at. */
export function DropdownSetting(props: { id: StringSetting }): React.JSX.Element {
    const { schema, value, disabled, set } = useControl(props.id);
    return <Setting id={props.id}>
        <Select
            options={optionsOf(schema)}
            value={String(value)}
            disabled={disabled}
            onChange={set}
        />
        <SelectionNote schema={schema} value={String(value)} />
    </Setting>;
}

/**
 * The rendering mode as a set of pictures rather than phrases: a card per mode
 * with a schematic of what it does to the picture.
 */
export function RenderingModeSetting(props: { id: StringSetting }): React.JSX.Element {
    const { schema, value, disabled, set } = useControl(props.id);
    return <Setting id={props.id}>
        <EmulatorRenderingModeField
            options={optionsOf(schema)}
            value={String(value)}
            disabled={disabled}
            onChange={set}
        />
        <SelectionNote schema={schema} value={String(value)} />
    </Setting>;
}

export function SliderSetting(props: { id: NumberSetting }): React.JSX.Element {
    const { schema, value, disabled, set } = useControl(props.id);
    return <Setting id={props.id}>
        <Range
            value={Number(value)}
            min={schema.minimum ?? 0}
            max={schema.maximum ?? 100}
            step={schema.multipleOf}
            disabled={disabled}
            setValue={set}
            width='100%'
        />
    </Setting>;
}

/**
 * A switch that belongs to the setting above it rather than standing on its
 * own: named beside itself instead of under a title of its own, with its reset
 * on the same line, since the title row is already spoken for.
 */
const SubSwitch = styled.div`
    align-items: center;
    display: flex;
    gap: var(--vp-space);
`;

/**
 * Where the Ambient halo takes its color from: a color well, and under it the
 * switch that hands the choice to the current palette instead.
 *
 * Two settings under one title, because they are one decision. While the
 * palette is the answer the well stays put and goes dim, showing the color
 * that is being used rather than the one that was last chosen — what the halo
 * is doing is the thing worth seeing, and a well that vanished would leave the
 * switch to say it in words alone.
 */
export function DecorationColorSetting(props: {
    /**
     * VB Color hardware is driving the picture. Optional, and false where a
     * host has no such thing: it only changes which color the well shows while
     * the switch is on, since colors then come from CRAM rather than the
     * chosen palette.
     */
    vbcHardware?: boolean,
}): React.JSX.Element {
    const { settings } = useScope();
    const color = useControl('decorationColor');
    const colorValue = String(color.value);
    const fromPalette = useControl('decorationColorFromPalette');
    // What the halo would take from the palette, read the same way the running
    // picture reads it — so the two follow the mode and the palette together.
    const renderingMode = useSetting(settings, 'renderingMode');
    const palette = useSetting(settings, 'palette');
    const customPalettes = useSetting(settings, 'customPalettes');
    const shown = fromPalette.value === true
        ? paletteDecorationColor(
            renderingMode, resolvePalette(palette, customPalettes), props.vbcHardware)
        : (/^#[0-9a-fA-F]{6}$/.test(colorValue) ? colorValue : '#000000');
    const label = nls.localize(
        'vueport/preferences/decorationColorFromPaletteLabel',
        'Derive from palette',
    );
    return <Setting id='decorationColor'>
        <VContainer>
            <ColorField
                value={shown}
                disabled={color.disabled || fromPalette.value === true}
                title={color.schema.title}
                onChange={color.set}
            />
            <SubSwitch>
                <Switch
                    label={label}
                    value={fromPalette.value === true}
                    disabled={fromPalette.disabled}
                    onChange={fromPalette.set}
                />
                {label}
                <ResetButton
                    disabled={fromPalette.isStandard || fromPalette.disabled}
                    onReset={fromPalette.reset}
                />
            </SubSwitch>
        </VContainer>
    </Setting>;
}
