import React from 'react';
import { nls } from '../../../common/emulator-nls';
import {
    ChoiceSetting,
    SettingsFields,
    SettingsPaneProps,
    SettingsSection,
    SliderSetting,
    SwitchSetting,
    useSetting
} from './SettingFields';

export default function SaveStateSettings(props: SettingsPaneProps): React.JSX.Element {
    // The interval and the count say nothing until the states are being taken,
    // and what a launch does with a suspended game says nothing until there is
    // one to launch into — the way the rewind pane's do, see `EmulationSettings`.
    const automatic = useSetting(props.settings, 'autoSaveStatesEnabled');
    const suspending = useSetting(props.settings, 'suspendResumeEnabled');
    // What each section is showing right now, which is what the dialog's
    // search filters against and what decides whether a section is there at
    // all: a query matching none of a section's settings takes the whole
    // fieldset with it rather than leaving an empty box behind.
    const automaticIds = automatic
        ? (['autoSaveStatesEnabled', 'autoSaveStateInterval', 'autoSaveStateCount'] as const)
        : (['autoSaveStatesEnabled'] as const);
    const suspendIds = suspending
        ? (['suspendResumeEnabled', 'suspendResumeStart'] as const)
        : (['suspendResumeEnabled'] as const);
    return (
        <div className='vp-appearance'>
            <SettingsFields {...props} ids={[...automaticIds, ...suspendIds]} gap={10}>
                <SettingsSection
                    title={nls.localize(
                        'vueport/preferences/sections/autoSaveStates', 'Automatic Save States')}
                    ids={automaticIds}
                >
                    <SwitchSetting id='autoSaveStatesEnabled' />
                    {automatic && <>
                        <SliderSetting id='autoSaveStateInterval' />
                        <SliderSetting id='autoSaveStateCount' />
                    </>}
                </SettingsSection>
                <SettingsSection
                    title={nls.localize(
                        'vueport/preferences/sections/suspendResume', 'Suspend and Resume')}
                    ids={suspendIds}
                >
                    <SwitchSetting id='suspendResumeEnabled' />
                    {suspending && <ChoiceSetting id='suspendResumeStart' />}
                </SettingsSection>
            </SettingsFields>
        </div>
    );
}
