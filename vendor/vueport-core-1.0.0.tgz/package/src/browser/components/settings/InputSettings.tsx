import * as React from 'react';
import { GamepadDatabase } from '../../../common/emulator-gamepad-profiles';
import { nls } from '../../../common/emulator-nls';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
import RadioSelect from '../kit/RadioSelect';
import GamePadBindings from './GamePadBindings';
import KeyboardBindings from './KeyboardBindings';

/**
 * The Input pane: which control does what.
 *
 * Three pages behind one tab strip. Two of them are keyboards — player one's
 * and player two's — and the third is whatever physical controller is plugged
 * in. They are separate components because they answer separate questions: a
 * keymap binds key codes to the emulator's commands and belongs to a player,
 * while a pad mapping binds a controller's buttons and axes to a profile and
 * belongs to the *device*. What they share is the shape of the answer, which
 * is in `input-fields.tsx`.
 *
 * All this owns is the strip and which page is showing. Each page draws its own
 * top row around the strip, because what belongs beside it is the page's:
 * whether player two has keys of its own, which controller is being configured,
 * which player it drives.
 */

/** The pages of the tab strip at the top. */
export type InputSettingsPage = 'player1' | 'player2' | 'gamePads';

/** Each page as the tab strip's value — the two players, then the pads. */
const PAGE_VALUES: Record<InputSettingsPage, number> = { player1: 1, player2: 2, gamePads: 3 };

export interface InputSettingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    /** Passed straight to the Game Pads page; see its own props. */
    loadGamepadDatabase?: () => Promise<GamepadDatabase | undefined>;
    /** Called after a mapping changes, so the running emulator can re-read it. */
    onChange?: () => void;
    /**
     * The page to open on, for a link straight to one — the status bar's
     * controller entry. Read once, when the pane mounts; player one otherwise.
     */
    initialPage?: InputSettingsPage;
}

export default function InputSettings(props: InputSettingsProps): React.JSX.Element {
    const { settings, bindings, loadGamepadDatabase, onChange, initialPage } = props;
    const [page, setPage] = React.useState(() => PAGE_VALUES[initialPage ?? 'player1']);

    const tabs = <RadioSelect
        options={[
            { value: 1, label: nls.localize('vueport/input/player1', 'Player 1') },
            { value: 2, label: nls.localize('vueport/input/player2', 'Player 2') },
            { value: 3, label: nls.localize('vueport/input/gamePads/title', 'Game Pads') },
        ]}
        defaultValue={page}
        onChange={options => setPage(options[0].value as number)}
    />;

    // A physical controller is configured per device rather than per player —
    // it keeps its mapping whoever is holding it — so that page owns its own
    // selection and state, and only the tab strip is shared with the others.
    if (page === 3) {
        return <GamePadBindings
            tabs={tabs}
            settings={settings}
            loadDatabase={loadGamepadDatabase}
            onChange={onChange}
        />;
    }

    return <KeyboardBindings
        // Remounted per player, which is what drops a capture in progress when
        // the page changes — as leaving it always has.
        key={page}
        tabs={tabs}
        player={page === 2 ? 2 : 1}
        settings={settings}
        bindings={bindings}
        onChange={onChange}
    />;
}
