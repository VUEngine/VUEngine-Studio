import * as React from 'react';
import { Command } from '../../../common/emulator-command';
import { resolveGamepadProfile } from '../../../common/emulator-gamepad-profiles';
import { nls } from '../../../common/emulator-nls';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
import {
    EmulatorCommands,
    EmulatorGamePadButton,
    emulatorGamePadCommand,
} from '../../emulator-commands';
import { connectedGamepadList, onGamepadsChanged } from '../../emulator-gamepad';
import Switch from '../kit/Switch';
import { CONTROLLER_POWER_SWITCH } from './controller-art';
import {
    BindingBody,
    BindingCard,
    BindingList,
    BindingLists,
    BindingRow,
    CancelCapture,
    CaptureRun,
    CaptureStrip,
    InputPage,
    InputSpacer,
    PadBadge,
    PadDiagrams,
    PresetPill,
    PresetRow,
    SetAllButton,
    useCaptureKeys,
} from './input-fields';
import { PAD_BUTTONS, PadDiagram, padButtonName } from './input-diagram';

/**
 * Which key does what — the controller drawn with its bindings written on it,
 * and the same keys as a list to read straight down.
 *
 * Every control on the picture is a target, and so is every row of the list:
 * click one and the next key pressed is bound to it, read straight off the page
 * rather than through a modal. "Set all buttons" walks the whole pad in one run
 * through the same strip, saving only at the end. A preset lays out a whole
 * layout in one press.
 *
 * Player two has a keymap of its own; the emulator's own keys — pause, save
 * state, fullscreen — belong to the first player's page because they are the
 * application's, not the game's.
 */

/** The emulator actions, in the order their column reads. */
const EMULATOR_COMMANDS: Command[] = [
    EmulatorCommands.INPUT_PAUSE_TOGGLE,
    EmulatorCommands.INPUT_REWIND,
    EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD,
    EmulatorCommands.INPUT_TOGGLE_SLOWMOTION,
    EmulatorCommands.INPUT_FRAME_ADVANCE,
    EmulatorCommands.INPUT_SAVE_STATE,
    EmulatorCommands.INPUT_LOAD_STATE,
    EmulatorCommands.INPUT_RESET,
    EmulatorCommands.INPUT_AUDIO_MUTE,
    EmulatorCommands.INPUT_TOGGLE_LOW_POWER,
    EmulatorCommands.INPUT_FULLSCREEN,
    EmulatorCommands.INPUT_SCREENSHOT,
    EmulatorCommands.INPUT_VIDEO_RECORD,
    EmulatorCommands.INPUT_TOGGLE_CONTROLS_OVERLAY,
];

/**
 * A whole pad laid out in one press, offered from the Presets button.
 *
 * `default` needs no table of its own — it is what {@link VueportInputBindings.resetToDefault}
 * already answers for every button — but the other two are a genuine
 * alternative layout, specified here in full so every button lands on a key
 * whether or not it changes from the shipped defaults.
 */
interface Preset {
    id: string;
    label(): string;
    /** Absent for `default`, which resets every button instead of naming keys. */
    keys?: Record<EmulatorGamePadButton, string>;
}

const PRESETS: Preset[] = [
    {
        id: 'default',
        label: () => nls.localize('vueport/input/presets/default', 'Default'),
    },
    {
        id: 'wasd',
        label: () => nls.localize('vueport/input/presets/wasd', 'WASD'),
        // The left D-pad on WASD, the right one on the arrows; everything
        // else — the face buttons and the triggers — stays what it ships
        // with, so switching here and back loses nothing but the D-pads.
        keys: {
            lUp: 'KeyW', lLeft: 'KeyA', lDown: 'KeyS', lRight: 'KeyD',
            rUp: 'ArrowUp', rLeft: 'ArrowLeft', rDown: 'ArrowDown', rRight: 'ArrowRight',
            select: 'KeyV', start: 'KeyB', b: 'KeyN', a: 'KeyM',
            lTrigger: 'KeyG', rTrigger: 'KeyH',
        },
    },
    {
        id: 'arrows',
        label: () => nls.localize('vueport/input/presets/arrows', 'Arrows'),
        // Lemur's own layout: the arrow keys for the left D-pad, IJKL for the
        // right one, ASDF for select/start/B/A, and E/R for the triggers.
        keys: {
            lUp: 'ArrowUp', lLeft: 'ArrowLeft', lDown: 'ArrowDown', lRight: 'ArrowRight',
            rUp: 'KeyI', rLeft: 'KeyJ', rDown: 'KeyK', rRight: 'KeyL',
            select: 'KeyA', start: 'KeyS', b: 'KeyD', a: 'KeyF',
            lTrigger: 'KeyE', rTrigger: 'KeyR',
        },
    },
];

/** How the caption for a key reads: the mapping, "none", or "press a key…". */
function keyCaption(bindings: VueportInputBindings, id: string, waiting: boolean): string {
    if (waiting) {
        return nls.localize('vueport/input/pressKey', 'press a key…');
    }
    return bindings.label(id, false) || '—';
}

/**
 * One key press being waited for — a single rebind, or one step of a run
 * through every button.
 */
interface Capture {
    command: Command;
    button?: EmulatorGamePadButton;
    title: React.ReactNode;
    run?: CaptureRun;
}

export interface KeyboardBindingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    /** Whose keymap this page edits. */
    player: 1 | 2;
    /** The pane's tab strip, which leads this page's own top row. */
    tabs: React.ReactNode;
    /** Called after a mapping changes, so the running emulator can re-read it. */
    onChange?: () => void;
}

export default function KeyboardBindings(props: KeyboardBindingsProps): React.JSX.Element {
    const { settings, bindings, player, tabs, onChange } = props;
    /** The key press being waited for, or undefined between them. */
    const [capture, setCapture] = React.useState<Capture | undefined>(undefined);
    /**
     * What the pointer is over, on the picture or in the list — a pad button,
     * or the power switch, which is bound to Reset rather than to a button.
     */
    const [hovered, setHovered] = React.useState<EmulatorGamePadButton | 'power' | undefined>(undefined);
    const [, bump] = React.useReducer((n: number) => n + 1, 0);
    /** The first connected game pad, if any. */
    const [pad, setPad] = React.useState<Gamepad | undefined>(() => connectedGamepadList()[0]);

    // Whether a pad was noticed at all, which is worth saying here because the
    // Gamepad API withholds a controller until a button on it is pressed, and
    // somebody looking for their controller on this page needs to know it was
    // seen. What its buttons do is the Game Pads page's business.
    React.useEffect(() => onGamepadsChanged(() => setPad(connectedGamepadList()[0])), []);

    // Named the way the Game Pads page names it — the person's own label for
    // the device when they have configured one, the browser's id cleaned up
    // otherwise — so that one controller does not go by two names in one pane.
    const padLabel = pad
        ? resolveGamepadProfile(pad, settings.get('gamepadProfiles')).profile.label
        : undefined;

    const sameControls = settings.get('player2SameControls');
    /** Player two answering to player one's keys has nothing of its own to set. */
    const configurable = player === 1 || !sameControls;

    const setSameControls = (value: boolean): void => {
        settings.set('player2SameControls', value).catch(() => undefined);
        setCapture(undefined);
        bump();
        onChange?.();
    };

    const commandForButton = (button: EmulatorGamePadButton): Command =>
        emulatorGamePadCommand(button, player);

    const captureRef = React.useRef(capture);
    captureRef.current = capture;
    /** What a "set all buttons" run has collected so far, saved only at the end. */
    const runCollected = React.useRef<Record<string, string>>({});

    /** Ask for a key for one command — a plain rebind, not a run. */
    const rebind = (command: Command, button: EmulatorGamePadButton | undefined, title?: React.ReactNode): void => {
        setCapture({ command, button, title: title ?? command.label });
    };

    /**
     * Stop waiting for a key and keep whatever was already bound — what the
     * Cancel button does, and what Escape does. A run in progress drops the
     * keys it had collected, since it only ever saves them all at once.
     */
    const cancelCapture = (): void => {
        setCapture(undefined);
        runCollected.current = {};
    };

    /**
     * Walk every button on the pad, asking for a key for each, through the
     * same strip a single rebind uses — the quickest way to lay out a
     * keyboard or a fresh controller. The button being asked for is lit on
     * the picture; Escape at any point stops the run and keeps what was
     * there, exactly as leaving a single rebind does.
     */
    const setEveryButton = (): void => {
        runCollected.current = {};
        const [first, ...queue] = PAD_BUTTONS;
        const command = commandForButton(first);
        setCapture({
            command,
            button: first,
            title: padButtonName(first, command.label),
            run: { step: 1, total: PAD_BUTTONS.length, queue },
        });
    };

    /**
     * Change the mappings, and redraw once the change is actually in force.
     *
     * A host's keymap can be a file — the studio writes a Theia keymap through
     * Monaco and reads it back into the registry — so a write is not done when
     * it returns, and the redraw that every one of these is followed by used to
     * happen first and show the mappings as they were. Waiting is also what
     * keeps a run of writes in order: such a host rewrites the whole keymap per
     * command, and two of them in flight would each miss the other's change.
     */
    const applyChange = (change: () => unknown): void => {
        Promise.resolve(change()).then(() => {
            bump();
            onChange?.();
        }, () => {
            // The host reports its own failures; the mappings on screen still
            // have to catch up with whatever did land.
            bump();
            onChange?.();
        });
    };

    const applyPreset = (preset: Preset): void => {
        setCapture(undefined);
        applyChange(async () => {
            if (!preset.keys) {
                for (const button of PAD_BUTTONS) {
                    await Promise.resolve(bindings.resetToDefault(commandForButton(button).id));
                }
                return;
            }
            const codes: Record<string, string> = {};
            for (const button of PAD_BUTTONS) {
                codes[commandForButton(button).id] = preset.keys[button];
            }
            await Promise.resolve(bindings.replaceAll(codes));
        });
    };

    useCaptureKeys(capture !== undefined, event => {
        event.preventDefault();
        event.stopPropagation();
        if (event.key === 'Escape') {
            cancelCapture();
            return;
        }
        // A bare modifier is someone still reaching for the real key.
        if (['Shift', 'Control', 'Alt', 'Meta'].includes(event.key)) {
            return;
        }
        const current = captureRef.current;
        if (!current) {
            return;
        }
        const code = event.code;
        if (!current.run) {
            setCapture(undefined);
            applyChange(() => bindings.bind(current.command.id, code));
            return;
        }
        const { step, total, queue } = current.run;
        const collected = { ...runCollected.current, [current.command.id]: code };
        runCollected.current = collected;
        const [next, ...rest] = queue;
        if (!next) {
            runCollected.current = {};
            setCapture(undefined);
            applyChange(() => bindings.replaceAll(collected));
            return;
        }
        const nextCommand = commandForButton(next);
        setCapture({
            command: nextCommand,
            button: next,
            title: padButtonName(next, nextCommand.label),
            run: { step: step + 1, total, queue: rest },
        });
    });

    /** Whether a control is lit — hovered, or waiting for a key. */
    const isLit = (button: EmulatorGamePadButton, commandId: string): boolean =>
        hovered === button || (capture?.command.id === commandId);

    const isWaiting = (commandId: string): boolean => capture?.command.id === commandId;

    /** One row of the list — the whole thing is the button. */
    const row = (command: Command, button?: EmulatorGamePadButton): React.JSX.Element => {
        // Reset has no pad button but it does have a target on the picture: the
        // power switch. Its row lights that the way a button's row lights its own.
        const onPicture: EmulatorGamePadButton | 'power' | undefined =
            button ?? (command.id === EmulatorCommands.INPUT_RESET.id ? 'power' : undefined);
        const waiting = isWaiting(command.id);
        const name = button !== undefined ? padButtonName(button, command.label) : command.label;
        return <BindingRow
            key={command.id}
            name={name}
            value={keyCaption(bindings, command.id, waiting)}
            lit={onPicture !== undefined && (hovered === onPicture || waiting)}
            waiting={waiting}
            onClick={() => rebind(command, button, button !== undefined ? name : undefined)}
            onHoverIn={() => onPicture && setHovered(onPicture)}
            onHoverOut={() => onPicture && setHovered(undefined)}
        />;
    };

    /**
     * The controller's power switch, on the front only. The Virtual Boy has no
     * reset button — its power switch is the reset — so the switch is a binding
     * target for the Reset command, wired the same way the pad buttons are.
     * Player two's page owns none of the emulator's own keys, so there it is
     * just part of the picture.
     */
    const powerSwitch = (): React.JSX.Element => {
        if (player !== 1) {
            return <g className='vp-input-art'>{CONTROLLER_POWER_SWITCH}</g>;
        }
        const command = EmulatorCommands.INPUT_RESET;
        const waiting = isWaiting(command.id);
        const lit = hovered === 'power' || capture?.command.id === command.id;
        return <g
            className={'vp-input-control vp-input-power'
                + (lit ? ' is-lit' : '')
                + (waiting ? ' is-waiting' : '')}
            onClick={() => rebind(command, undefined)}
            onMouseEnter={() => setHovered('power')}
            onMouseLeave={() => setHovered(undefined)}
        >
            <g className='vp-input-control-shape'>{CONTROLLER_POWER_SWITCH}</g>
            <text className='vp-input-control-key' x={125} y={52} textAnchor='middle'>
                {keyCaption(bindings, command.id, waiting)}
            </text>
            <circle className='vp-input-control-hit' cx={125} cy={36} r={13} />
        </g>;
    };

    /** One controller half, captioned with the keys its buttons answer to. */
    const diagram = (face: 'front' | 'back'): React.JSX.Element =>
        <PadDiagram
            face={face}
            caption={button =>
                keyCaption(bindings, commandForButton(button).id, isWaiting(commandForButton(button).id))}
            isLit={button => isLit(button, commandForButton(button).id)}
            isWaiting={button => isWaiting(commandForButton(button).id)}
            onSelect={button => {
                const command = commandForButton(button);
                rebind(command, button, padButtonName(button, command.label));
            }}
            onHover={setHovered}
            powerSwitch={powerSwitch()}
        />;

    const mapped = capture ? bindings.label(capture.command.id, false) : '';
    const sameLabel = nls.localize('vueport/input/sameAsPlayer1', 'Same as Player 1');

    return <InputPage top={<>
        {tabs}
        {padLabel && <PadBadge label={padLabel} title={pad?.id} />}
        <InputSpacer />
    </>}>
        {player === 2 &&
            <span className='vp-input-same'>
                <Switch label={sameLabel} value={sameControls} onChange={setSameControls} />
                {sameLabel}
            </span>
        }
        {configurable &&
            <BindingBody>
                <BindingCard>
                    <PadDiagrams>
                        {diagram('front')}
                        {diagram('back')}
                    </PadDiagrams>
                    {capture &&
                        <CaptureStrip
                            title={capture.title}
                            run={capture.run}
                            prompt={nls.localize(
                                'vueport/input/pressKey', 'Press the key to bind, or Escape to cancel.')}
                            detail={capture.run
                                ? <p className='vp-input-capture-note'>
                                    {nls.localize(
                                        'vueport/input/captureAllNote',
                                        'Nothing is saved until every button is set.'
                                    )}
                                </p>
                                : <p className='vp-input-capture-current'>
                                    {mapped
                                        ? <>{nls.localize('vueport/input/currentlyMappedTo', 'Currently mapped to:')} <b>{mapped}</b></>
                                        : nls.localize('vueport/input/currentlyUnmapped', 'Currently not mapped to any key.')}
                                </p>}
                            actions={capture.run
                                ? <CancelCapture onClick={cancelCapture} />
                                : <>
                                    <CancelCapture onClick={cancelCapture} />
                                    <button
                                        type='button'
                                        className='vp-button secondary'
                                        onClick={() => applyChange(
                                            () => bindings.resetToDefault(capture.command.id)
                                        )}
                                    >
                                        {nls.localize('vueport/input/resetToDefault', 'Reset to Default')}
                                    </button>
                                    <button
                                        type='button'
                                        className='vp-button secondary'
                                        disabled={!mapped}
                                        onClick={() => applyChange(
                                            () => bindings.clear(capture.command.id)
                                        )}
                                    >
                                        {nls.localize('vueport/input/clearAllMappings', 'Clear All Mappings')}
                                    </button>
                                </>}
                        />}
                    <PresetRow trailing={
                        <SetAllButton
                            label={nls.localize('vueport/input/setAll', 'Set all buttons…')}
                            onClick={setEveryButton}
                        />
                    }>
                        {PRESETS.map(preset =>
                            <PresetPill
                                key={preset.id}
                                label={preset.label()}
                                onClick={() => applyPreset(preset)}
                            />)}
                    </PresetRow>
                </BindingCard>

                <BindingLists>
                    <BindingList title={nls.localize('vueport/input/gamePad', 'Game pad')}>
                        {PAD_BUTTONS.map(button => row(commandForButton(button), button))}
                    </BindingList>
                    {player === 1 &&
                        <BindingList title={nls.localize('vueport/input/emulator', 'Emulator')}>
                            {EMULATOR_COMMANDS.map(command => row(command))}
                        </BindingList>}
                </BindingLists>
            </BindingBody>}
    </InputPage>;
}
