import * as React from 'react';
import { X } from '@phosphor-icons/react';
import { Command } from '../../../common/emulator-command';
import { GamepadDatabase, resolveGamepadProfile } from '../../../common/emulator-gamepad-profiles';
import { nls } from '../../../common/emulator-nls';
import { VueportInputBindings, VueportSettings } from '../../../common/emulator-settings';
import {
    EMULATOR_MACRO_SLOT_COMMANDS,
    EMULATOR_TURBO_BUTTONS,
    EmulatorCommands,
    EmulatorGamePadButton,
    emulatorGamePadCommand,
    emulatorTurboCommand,
} from '../../emulator-commands';
import { connectedGamepadList, onGamepadsChanged } from '../../emulator-gamepad';
import Switch from '../kit/Switch';
import { CONTROLLER_POWER_SWITCH } from './controller-art';
import {
    BindingBody,
    BindingCard,
    BindingList,
    BindingLists,
    BindingRow,
    CancelCapture,
    CaptureRun,
    CaptureStrip,
    InputPage,
    InputSpacer,
    PadBadge,
    PadDiagrams,
    PresetPill,
    PresetRow,
    SetAllButton,
    TurboRateSlider,
    TurboTitle,
    useCaptureKeys,
} from './input-fields';
import { PAD_BUTTONS, PadDiagram, padButtonName } from './input-diagram';

// the controller drawn with its key bindings, plus the same keys as a list. Every control and row is a
// capture target, "Set all buttons" saves only at the end. The emulator's own keys live on player one's
// page, as they belong to the application, not the game

// in the order their column reads
const EMULATOR_COMMANDS: Command[] = [
    EmulatorCommands.INPUT_PAUSE_TOGGLE,
    EmulatorCommands.INPUT_REWIND,
    EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD,
    EmulatorCommands.INPUT_TOGGLE_SLOWMOTION,
    EmulatorCommands.INPUT_FRAME_ADVANCE,
    EmulatorCommands.INPUT_SAVE_STATE,
    EmulatorCommands.INPUT_LOAD_STATE,
    EmulatorCommands.INPUT_RESET,
    EmulatorCommands.INPUT_AUDIO_MUTE,
    EmulatorCommands.INPUT_TOGGLE_LOW_POWER,
    EmulatorCommands.INPUT_FULLSCREEN,
    EmulatorCommands.INPUT_SCREENSHOT,
    EmulatorCommands.INPUT_VIDEO_RECORD,
    EmulatorCommands.INPUT_TOGGLE_CONTROLS_OVERLAY,
];

// `default` resets via VueportInputBindings.resetToDefault, the others are full layouts so every button and
// action lands on a key. They include the emulator keys because both take the arrows the shipped time
// controls sit on; only player one's page lays those out
interface Preset {
    id: string;
    label(): string;
    // absent for `default`, which resets every button instead
    keys?: Record<EmulatorGamePadButton, string>;
    // emulator keys by command id
    actions?: Record<string, string>;
}

// emulator keys for a layout that takes the arrows: time controls move to the number row after save and
// load (back, slow, step, fast), low battery moves from W to T
const PRESET_ACTION_KEYS: Record<string, string> = {
    [EmulatorCommands.INPUT_PAUSE_TOGGLE.id]: 'Space',
    [EmulatorCommands.INPUT_RESET.id]: 'F10',
    [EmulatorCommands.INPUT_AUDIO_MUTE.id]: 'KeyQ',
    [EmulatorCommands.INPUT_TOGGLE_LOW_POWER.id]: 'KeyT',
    [EmulatorCommands.INPUT_SAVE_STATE.id]: 'Digit1',
    [EmulatorCommands.INPUT_LOAD_STATE.id]: 'Digit2',
    [EmulatorCommands.INPUT_REWIND.id]: 'Digit3',
    [EmulatorCommands.INPUT_TOGGLE_SLOWMOTION.id]: 'Digit4',
    [EmulatorCommands.INPUT_FRAME_ADVANCE.id]: 'Digit5',
    [EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD.id]: 'Digit6',
    [EmulatorCommands.INPUT_FULLSCREEN.id]: 'KeyO',
    [EmulatorCommands.INPUT_TOGGLE_CONTROLS_OVERLAY.id]: 'KeyP',
    [EmulatorCommands.INPUT_SCREENSHOT.id]: 'F9',
    [EmulatorCommands.INPUT_VIDEO_RECORD.id]: 'F8',
};

const PRESETS: Preset[] = [
    {
        id: 'default',
        label: () => nls.localize('vueport/input/presets/default', 'Default'),
    },
    {
        id: 'wasd',
        label: () => nls.localize('vueport/input/presets/wasd', 'WASD'),
        // left D-pad on WASD, right one on the arrows, face buttons and triggers as shipped
        keys: {
            lUp: 'KeyW', lLeft: 'KeyA', lDown: 'KeyS', lRight: 'KeyD',
            rUp: 'ArrowUp', rLeft: 'ArrowLeft', rDown: 'ArrowDown', rRight: 'ArrowRight',
            select: 'KeyV', start: 'KeyB', b: 'KeyN', a: 'KeyM',
            lTrigger: 'KeyG', rTrigger: 'KeyH',
        },
        actions: PRESET_ACTION_KEYS,
    },
    {
        id: 'arrows',
        label: () => nls.localize('vueport/input/presets/arrows', 'Arrows'),
        // Lemur's layout: arrows for the left D-pad, IJKL for the right, ASDF for select/start/B/A, E/R for triggers
        keys: {
            lUp: 'ArrowUp', lLeft: 'ArrowLeft', lDown: 'ArrowDown', lRight: 'ArrowRight',
            rUp: 'KeyI', rLeft: 'KeyJ', rDown: 'KeyK', rRight: 'KeyL',
            select: 'KeyA', start: 'KeyS', b: 'KeyD', a: 'KeyF',
            lTrigger: 'KeyE', rTrigger: 'KeyR',
        },
        actions: PRESET_ACTION_KEYS,
    },
];

// the mapping, "none" or "press a key…"
function keyCaption(bindings: VueportInputBindings, id: string, waiting: boolean): string {
    if (waiting) {
        return nls.localize('vueport/input/pressKeyShort', 'press a key…');
    }
    return bindings.label(id, false) || '—';
}

// one awaited key press, a single rebind or one step of a run through every button
interface Capture {
    command: Command;
    button?: EmulatorGamePadButton;
    title: React.ReactNode;
    run?: CaptureRun;
    // add the key beside the bound ones instead of replacing them
    add?: boolean;
}

export interface KeyboardBindingsProps {
    settings: VueportSettings;
    bindings: VueportInputBindings;
    player: 1 | 2;
    // leads this page's top row
    tabs: React.ReactNode;
    // the Game Pads page's device-name database, so the pad badge names it the same way
    loadDatabase?: () => Promise<GamepadDatabase | undefined>;
    // so the running emulator can re-read the mappings
    onChange?: () => void;
}

export default function KeyboardBindings(props: KeyboardBindingsProps): React.JSX.Element {
    const { settings, bindings, player, tabs, loadDatabase, onChange } = props;
    const [capture, setCapture] = React.useState<Capture | undefined>(undefined);
    // a pad button, or the power switch, which is bound to Reset
    const [hovered, setHovered] = React.useState<EmulatorGamePadButton | 'power' | undefined>(undefined);
    const [, bump] = React.useReducer((n: number) => n + 1, 0);
    const [pad, setPad] = React.useState<Gamepad | undefined>(() => connectedGamepadList()[0]);

    // the Gamepad API withholds a controller until a button is pressed, so this page shows that it was seen
    React.useEffect(() => onGamepadsChanged(() => setPad(connectedGamepadList()[0])), []);

    const [database, setDatabase] = React.useState<GamepadDatabase | undefined>(undefined);
    const hasPad = pad !== undefined;
    React.useEffect(() => {
        if (!hasPad) {
            return;
        }
        let canceled = false;
        loadDatabase?.().then(
            loaded => { if (!canceled) { setDatabase(loaded); } },
            () => undefined,
        );
        return () => { canceled = true; };
    }, [loadDatabase, hasPad]);

    // named like on the Game Pads page, so one controller does not go by two names in one pane
    const padLabel = pad
        ? resolveGamepadProfile(pad, settings.get('gamepadProfiles'), database).profile.label
        : undefined;

    const sameControls = settings.get('player2SameControls');
    // player two using player one's keys has nothing of its own to set
    const configurable = player === 1 || !sameControls;

    const setSameControls = (value: boolean): void => {
        settings.set('player2SameControls', value).catch(() => undefined);
        setCapture(undefined);
        bump();
        onChange?.();
    };

    const commandForButton = (button: EmulatorGamePadButton): Command =>
        emulatorGamePadCommand(button, player);

    const captureRef = React.useRef(capture);
    captureRef.current = capture;
    // saved only at the end of the run
    const runCollected = React.useRef<Record<string, string>>({});

    const rebind = (command: Command, button: EmulatorGamePadButton | undefined, title?: React.ReactNode): void => {
        setCapture({ command, button, title: title ?? command.label });
    };

    // Cancel and Escape keep what was bound; a run drops the keys it collected
    const cancelCapture = (): void => {
        setCapture(undefined);
        runCollected.current = {};
    };

    // walks every button through the same strip a single rebind uses, lighting the one being asked for.
    // Escape stops the run and keeps what was there
    const setEveryButton = (): void => {
        runCollected.current = {};
        const [first, ...queue] = PAD_BUTTONS;
        const command = commandForButton(first);
        setCapture({
            command,
            button: first,
            title: padButtonName(first, command.label),
            run: { step: 1, total: PAD_BUTTONS.length, queue },
        });
    };

    // commands a key bound to this one may not also drive. Player one's pad shares a window with the emulator
    // keys, player two's clashes only with itself: its shipped arrows overlap the time controls, and in its
    // window the pad wins anyway (see EmulatorInputController.processKeyEvent)
    const rivals = (commandId: string): string[] => {
        // turbo buttons are the pad's too; macro slots are player one's, like the emulator keys
        const own = [
            ...PAD_BUTTONS.map(button => commandForButton(button).id),
            ...EMULATOR_TURBO_BUTTONS.map(button => emulatorTurboCommand(button, player).id),
        ];
        const scope = player === 1
            ? [
                ...own,
                ...EMULATOR_COMMANDS.map(command => command.id),
                ...EMULATOR_MACRO_SLOT_COMMANDS.map(command => command.id),
            ]
            : own;
        return scope.filter(id => id !== commandId);
    };

    const release = async (commandId: string, code: string): Promise<void> => {
        if (bindings.unbind) {
            await Promise.resolve(bindings.unbind(commandId, code));
            return;
        }
        const rest = bindings.keyCodes(commandId).filter(other => other !== code);
        await Promise.resolve(bindings.clear(commandId));
        for (const other of rest) {
            await Promise.resolve(bindings.bind(commandId, other));
        }
    };

    // a key does one thing, so a newly bound key leaves its other commands. Walked from the last command back,
    // so a key pressed twice in one run stays with the button it was pressed for last
    const claimKeys = async (commandIds: string[]): Promise<void> => {
        for (const commandId of [...commandIds].reverse()) {
            for (const code of bindings.keyCodes(commandId)) {
                for (const rival of rivals(commandId)) {
                    if (bindings.keyCodes(rival).includes(code)) {
                        await release(rival, code);
                    }
                }
            }
        }
    };

    // redraws once the change is in force. A host keymap can be a file (the studio writes a Theia keymap through
    // Monaco), so a write is not done when it returns; waiting also keeps writes in order, since such a host
    // rewrites the whole keymap per command
    const applyChange = (change: () => unknown, claimed: string[] = []): void => {
        Promise.resolve(change()).then(() => claimKeys(claimed)).then(() => {
            bump();
            onChange?.();
        }, () => {
            // the host reports its own failures, the screen still has to catch up with what landed
            bump();
            onChange?.();
        });
    };

    const applyPreset = (preset: Preset): void => {
        setCapture(undefined);
        // the emulator's keys only where they are shown, see `Preset`
        const actions = player === 1 ? EMULATOR_COMMANDS.map(command => command.id) : [];
        const commandIds = [...PAD_BUTTONS.map(button => commandForButton(button).id), ...actions];
        applyChange(async () => {
            if (!preset.keys) {
                for (const commandId of commandIds) {
                    await Promise.resolve(bindings.resetToDefault(commandId));
                }
                return;
            }
            const codes: Record<string, string> = {};
            for (const button of PAD_BUTTONS) {
                codes[commandForButton(button).id] = preset.keys[button];
            }
            for (const commandId of actions) {
                const code = preset.actions?.[commandId];
                if (code) {
                    codes[commandId] = code;
                }
            }
            await Promise.resolve(bindings.replaceAll(codes));
        }, commandIds);
    };

    useCaptureKeys(capture !== undefined, event => {
        event.preventDefault();
        event.stopPropagation();
        if (event.key === 'Escape') {
            cancelCapture();
            return;
        }
        // a bare modifier is someone still reaching for the real key
        if (['Shift', 'Control', 'Alt', 'Meta'].includes(event.key)) {
            return;
        }
        const current = captureRef.current;
        if (!current) {
            return;
        }
        const code = event.code;
        if (!current.run) {
            setCapture(undefined);
            // replaces by default, as on the Game Pads page; adding is the deliberate Add Another
            applyChange(() => current.add
                ? bindings.bind(current.command.id, code)
                : bindings.replaceAll({ [current.command.id]: code }),
            [current.command.id]);
            return;
        }
        const { step, total, queue } = current.run;
        const collected = { ...runCollected.current, [current.command.id]: code };
        runCollected.current = collected;
        const [next, ...rest] = queue;
        if (!next) {
            runCollected.current = {};
            setCapture(undefined);
            applyChange(() => bindings.replaceAll(collected), Object.keys(collected));
            return;
        }
        const nextCommand = commandForButton(next);
        setCapture({
            command: nextCommand,
            button: next,
            title: padButtonName(next, nextCommand.label),
            run: { step: step + 1, total, queue: rest },
        });
    });

    // hovered, or waiting for a key
    const isLit = (button: EmulatorGamePadButton, commandId: string): boolean =>
        hovered === button || (capture?.command.id === commandId);

    const isWaiting = (commandId: string): boolean => capture?.command.id === commandId;

    const row = (command: Command, button?: EmulatorGamePadButton, turbo = false): React.JSX.Element => {
        // Reset has no pad button, so its row lights the power switch. A turbo row lights its plain button
        const onPicture: EmulatorGamePadButton | 'power' | undefined =
            button ?? (command.id === EmulatorCommands.INPUT_RESET.id ? 'power' : undefined);
        const waiting = isWaiting(command.id);
        // named like the plain button, the list says turbo
        const name = button !== undefined
            ? padButtonName(button, (turbo ? commandForButton(button) : command).label)
            : command.label;
        return <BindingRow
            key={command.id}
            name={name}
            value={keyCaption(bindings, command.id, waiting)}
            lit={onPicture !== undefined && (hovered === onPicture || waiting)}
            waiting={waiting}
            onClick={() => rebind(command, button, button !== undefined
                ? (turbo ? <TurboTitle name={name} /> : name)
                : undefined)}
            onHoverIn={() => onPicture && setHovered(onPicture)}
            onHoverOut={() => onPicture && setHovered(undefined)}
        />;
    };

    // the VB has no reset button, its power switch is the reset, so it is the Reset command's target. On player
    // two's page it is just part of the picture
    const powerSwitch = (): React.JSX.Element => {
        if (player !== 1) {
            return <g className='vp-input-art'>{CONTROLLER_POWER_SWITCH}</g>;
        }
        const command = EmulatorCommands.INPUT_RESET;
        const waiting = isWaiting(command.id);
        const lit = hovered === 'power' || capture?.command.id === command.id;
        return <g
            className={'vp-input-control vp-input-power'
                + (lit ? ' is-lit' : '')
                + (waiting ? ' is-waiting' : '')}
            onClick={() => rebind(command, undefined)}
            onMouseEnter={() => setHovered('power')}
            onMouseLeave={() => setHovered(undefined)}
        >
            <g className='vp-input-control-shape'>{CONTROLLER_POWER_SWITCH}</g>
            <text className='vp-input-control-key' x={125} y={52} textAnchor='middle'>
                {keyCaption(bindings, command.id, waiting)}
            </text>
            <circle className='vp-input-control-hit' cx={125} cy={36} r={13} />
        </g>;
    };

    const diagram = (face: 'front' | 'back'): React.JSX.Element =>
        <PadDiagram
            face={face}
            caption={button =>
                keyCaption(bindings, commandForButton(button).id, isWaiting(commandForButton(button).id))}
            isLit={button => isLit(button, commandForButton(button).id)}
            isWaiting={button => isWaiting(commandForButton(button).id)}
            onSelect={button => {
                const command = commandForButton(button);
                rebind(command, button, padButtonName(button, command.label));
            }}
            onHover={setHovered}
            powerSwitch={powerSwitch()}
        />;

    const mapped = capture ? bindings.label(capture.command.id, false) : '';
    const sameLabel = nls.localize('vueport/input/sameAsPlayer1', 'Same as Player 1');

    return <InputPage top={<>
        {tabs}
        {padLabel && <PadBadge label={padLabel} title={pad?.id} />}
        <InputSpacer />
    </>}>
        {player === 2 &&
            <span className='vp-input-same'>
                <Switch label={sameLabel} value={sameControls} onChange={setSameControls} />
                {sameLabel}
            </span>
        }
        {configurable &&
            <BindingBody>
                <BindingCard>
                    <PadDiagrams>
                        {diagram('front')}
                        {diagram('back')}
                    </PadDiagrams>
                    {capture &&
                        <CaptureStrip
                            title={capture.title}
                            run={capture.run}
                            prompt={capture.add
                                ? nls.localize('vueport/input/pressAnotherKey',
                                    'Press another key to add it, or Escape to cancel.')
                                : nls.localize('vueport/input/pressKey', 'Press the key to bind, or Escape to cancel.')}
                            detail={capture.run
                                ? <p className='vp-input-capture-note'>
                                    {nls.localize(
                                        'vueport/input/captureAllNote',
                                        'Nothing is saved until every button is set.'
                                    )}
                                </p>
                                : <p className='vp-input-capture-current'>
                                    {!mapped
                                        ? nls.localize('vueport/input/currentlyUnmapped', 'Currently not mapped to any key.')
                                        : bindings.unbind && bindings.keyLabel
                                            ? <>
                                                {nls.localize('vueport/input/currentlyMappedTo', 'Currently mapped to:')}
                                                {/* one removable chip per key, as Clear All is too blunt to drop one */}
                                                {bindings.keyCodes(capture.command.id).map(code =>
                                                    <button
                                                        key={code}
                                                        type='button'
                                                        className='vp-input-source-chip'
                                                        title={nls.localize('vueport/input/gamePads/removeSource', 'Remove')}
                                                        onClick={() => applyChange(
                                                            () => bindings.unbind?.(capture.command.id, code))}
                                                    >
                                                        {bindings.keyLabel?.(code) ?? code}
                                                        <X size={11} />
                                                    </button>)}
                                            </>
                                            : <>{nls.localize('vueport/input/currentlyMappedTo', 'Currently mapped to:')} <b>{mapped}</b></>}
                                </p>}
                            actions={capture.run
                                ? <CancelCapture onClick={cancelCapture} />
                                : <>
                                    <CancelCapture onClick={cancelCapture} />
                                    {!capture.add && mapped &&
                                        <button
                                            type='button'
                                            className='vp-button secondary'
                                            onClick={() => setCapture({ ...capture, add: true })}
                                        >
                                            {nls.localize('vueport/input/gamePads/addAnother', 'Add another')}
                                        </button>}
                                    <button
                                        type='button'
                                        className='vp-button secondary'
                                        onClick={() => applyChange(
                                            () => bindings.resetToDefault(capture.command.id),
                                            [capture.command.id]
                                        )}
                                    >
                                        {nls.localize('vueport/input/resetToDefault', 'Reset to Default')}
                                    </button>
                                    <button
                                        type='button'
                                        className='vp-button secondary'
                                        disabled={!mapped}
                                        onClick={() => applyChange(
                                            () => bindings.clear(capture.command.id)
                                        )}
                                    >
                                        {nls.localize('vueport/input/clearAllMappings', 'Clear All Mappings')}
                                    </button>
                                </>}
                        />}
                    <div className='vp-preset-row'>
                        <TurboRateSlider settings={settings} onChange={onChange} />
                    </div>
                    <PresetRow trailing={
                        <SetAllButton
                            label={nls.localize('vueport/input/setAll', 'Set all buttons…')}
                            onClick={setEveryButton}
                        />
                    }>
                        {PRESETS.map(preset =>
                            <PresetPill
                                key={preset.id}
                                label={preset.label()}
                                onClick={() => applyPreset(preset)}
                            />)}
                    </PresetRow>
                </BindingCard>

                <BindingLists>
                    <BindingList title={nls.localize('vueport/input/gamePad', 'Game pad')}>
                        {PAD_BUTTONS.map(button => row(commandForButton(button), button))}
                    </BindingList>
                    <BindingList title={nls.localize('vueport/input/turbo/title', 'Turbo')}>
                        {EMULATOR_TURBO_BUTTONS.map(button => row(emulatorTurboCommand(button, player), button, true))}
                    </BindingList>
                    {player === 1 &&
                        <BindingList title={nls.localize('vueport/input/emulator', 'Emulator')}>
                            {EMULATOR_COMMANDS.map(command => row(command))}
                        </BindingList>}
                    {player === 1 &&
                        <BindingList title={nls.localize('vueport/input/macros', 'Macros')}>
                            {EMULATOR_MACRO_SLOT_COMMANDS.map(command => row(command))}
                        </BindingList>}
                </BindingLists>
            </BindingBody>}
    </InputPage>;
}
