import {
    ArrowsIn,
    ArrowsOut,
    Bandaids,
    Bug,
    ClockCountdown,
    Lightning,
    Plugs,
    PlugsConnected,
    Queue,
    SlidersHorizontal,
    Star,
    Trophy
} from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { EmulatorCommands } from '../emulator-commands';
import { EmulatorAction, EmulatorMode } from '../emulator-types';
import { EmulatorToolbarHost } from './EmulatorToolbar';
import { DOM_HOVER } from './kit/dom-hover';
import { VbColorIcon } from './kit/VbColorIcon';

/**
 * The strip along the top of the emulator.
 *
 * It exists because the emulator's own chrome got out of the way. With
 * `chrome: 'immersive'` the toolbar is a strip that floats over the picture
 * and hides itself, and a control that *opens* something — the cheats, the
 * settings, Debug mode — has no business hiding: you go looking for those, and
 * something you go looking for has to be somewhere.
 *
 * So the split is: the strip below is the transport, the things you do TO the
 * running machine. This is everything that opens something.
 *
 * Both hosts wear it. What differs between them is what sits on the left,
 * which is why that is a slot ({@link TitleBarProps.title}) rather than
 * anything this component knows about: the standalone build puts the ROM's
 * name and the way out of it there; the studio, which has a workbench naming
 * the file already, puts the emulator's transport toolbar there instead.
 *
 * On the desktop this IS the window's title bar, which is what
 * {@link TitleBarProps.windowControls} is for. In the studio it is a strip
 * inside a widget, and there are no window controls to draw.
 */

/** One button, in the same clothes as its neighbors. */
function TitleBarButton(props: {
    /** A stable hook: what a control is called is translated, its name is not. */
    control: string,
    label: string,
    active?: boolean,
    disabled?: boolean,
    dimmed?: boolean,
    onClick: () => void,
    children: React.ReactNode,
}): React.JSX.Element {
    const { control, label, active, disabled, dimmed, onClick, children } = props;
    return <button
        type='button'
        data-control={control}
        className={'vp-titlebar-button'
            + (active ? ' active' : '')
            + (dimmed ? ' dimmed' : '')}
        disabled={disabled}
        aria-label={label}
        onMouseEnter={event => DOM_HOVER.show(event.currentTarget, label)}
        onMouseLeave={() => DOM_HOVER.hide()}
        onClick={() => { DOM_HOVER.hide(); onClick(); }}
    >
        {children}
    </button>;
}

/**
 * Which of the five strips a control opens.
 *
 * Named for what they are rather than for a mode: they open beside the screen
 * in Play and in Debug alike. They were Play mode's alone once, with docked
 * panels standing in for them while debugging — two ways to reach one list,
 * and a button whose meaning changed with the mode.
 */
export type PlayStrip =
    'save-states' | 'cheats' | 'macros' | 'patches' | 'achievements';

/**
 * What the title bar needs beyond what the toolbar already asks for.
 *
 * Everything optional is a thing a host may simply not have: a build with no
 * VB Color hardware switch draws no pill, one with no Debug mode draws no bug.
 */
export interface TitleBarHost extends EmulatorToolbarHost {
    /** Whether there is a cartridge in the machine — the panel controls need one. */
    readonly hasRom: boolean;
    /** Whether the settings window is open, so its button can say so. */
    readonly settingsOpen: boolean;
    toggleDebugMode(): void;
    /** Whether the color unit is switched on at all. */
    readonly vbcSupportEnabled: boolean;
    /** What the VB Color pill says, or nothing for a machine that is not one. */
    readonly vbcHeaderPillLabel?: string;
    /** The pill's click: choose which console this is. */
    pickHardwareMode?(): Promise<void>;
    /** Turn hardcore mode off, for the pill that says it is on. */
    offerToLeaveHardcore?(): Promise<void>;
    /**
     * Whether a second player can be invited before a game is open — the
     * other window then waits for this one to start one. Left out, the link
     * button needs a cartridge like the panel controls do.
     */
    readonly linksWithoutRom?: boolean;
}

/**
 * How much of the window this strip is responsible for.
 *
 * `none` — a browser, or a strip inside a larger application. No window, no
 * controls, no drag.
 *
 * `overlay` — macOS keeps its traffic lights and lends the space behind them.
 * Nothing to draw; the strip only has to keep its own controls clear of the
 * three, which is what the inset is for. Fake lights would lose the symbols
 * that appear on hover, option-click to zoom and double-click to fill.
 *
 * `custom` — the frame is off, so minimize, maximize and close are drawn here.
 */
export type TitleBarWindowControls = 'none' | 'overlay' | 'custom';

export interface TitleBarProps {
    emulator: TitleBarHost;
    /**
     * What sits on the left, where a window would put its document's name.
     *
     * The one place the two hosts differ, and the reason this is a slot: the
     * standalone build names the ROM here and offers the way out of it; the
     * studio's tab already names the file, so it puts the emulator's transport
     * toolbar here instead.
     */
    title?: React.ReactNode;
    /** The application's mark, left of the title. Nothing is drawn without one. */
    logo?: React.ReactNode;
    /** See {@link TitleBarWindowControls}. Defaults to `none`. */
    windowControls?: TitleBarWindowControls;
    onMinimizeWindow?: () => void;
    onMaximizeWindow?: () => void;
    onCloseWindow?: () => void;
    /**
     * Whether the view is fullscreen, so the button can invite the way out
     * rather than the way in.
     *
     * Left out, the page's own fullscreen element is watched, which is right
     * for anything running in a browser. A host whose fullscreen is the
     * window's — the desktop shell, where macOS's own green button changes it
     * from outside this strip — passes what it knows instead.
     */
    fullscreen?: boolean;
}

function linkLabel(status: ReturnType<TitleBarHost['linkStatus']>): string {
    switch (status) {
        case 'linked':
            return nls.localize('vueport/commands/link/unlink', 'Unlink Players');
        case 'waiting':
            return nls.localize('vueport/commands/link/cancel', 'Cancel Link');
        case 'relinkable':
            return nls.localize('vueport/commands/link/relink', 'Relink Players');
        default:
            return nls.localize('vueport/commands/link/secondPlayer', 'Link Second Player');
    }
}

function linkCommand(status: ReturnType<TitleBarHost['linkStatus']>): string {
    switch (status) {
        case 'linked':
        case 'waiting':
            return EmulatorCommands.UNLINK_PLAYERS.id;
        case 'relinkable':
            return EmulatorCommands.RELINK_PLAYERS.id;
        default:
            return EmulatorCommands.LINK_SECOND_PLAYER.id;
    }
}

export default function TitleBar(props: TitleBarProps): React.JSX.Element {
    const { emulator, title, logo, windowControls = 'none' } = props;
    const debugging = emulator.state.mode === EmulatorMode.DEBUG;
    // Cheats, macros, patches and Debug mode are all off limits while
    // hardcore is on.
    const hardcore = emulator.isHardcore();

    // The page's own fullscreen, for a host that does not tell us its own.
    // Leaving it with Escape never touches the emulator, so nothing else here
    // would hear about it otherwise.
    const [pageFullscreen, setPageFullscreen] = React.useState(
        () => typeof document !== 'undefined' && document.fullscreenElement !== null
    );
    React.useEffect(() => {
        if (props.fullscreen !== undefined) {
            return undefined;
        }
        const sync = (): void => setPageFullscreen(document.fullscreenElement !== null);
        document.addEventListener('fullscreenchange', sync);
        return () => document.removeEventListener('fullscreenchange', sync);
    }, [props.fullscreen]);
    const fullscreen = props.fullscreen ?? pageFullscreen;

    /**
     * A strip control: shows its list beside the screen, or puts it away.
     *
     * The same button in both modes. It used to be drawn dimmed in Debug mode
     * and offer the way out of it instead, because the strips belonged to Play
     * mode and the same five lists were docked panels while debugging — so
     * five of the eight controls up here meant something different depending
     * on a mode set elsewhere. They open the strip now, whatever the mode.
     *
     * Dimmed rather than disabled where a strip is off limits, and live
     * either way: a dimmed control that took no click would leave somebody
     * pressing a button that does nothing and no explanation of why. The
     * click puts up the reason — the "Hardcore Mode is on" notice.
     */
    const panelButton = (
        which: PlayStrip,
        label: string,
        showing: boolean,
        icon: React.ReactNode,
        toggle: () => void,
        dimmed = false,
    ): React.JSX.Element =>
        <TitleBarButton
            control={which}
            label={label}
            active={showing}
            dimmed={dimmed}
            onClick={toggle}
        >
            {icon}
        </TitleBarButton>;

    return <header
        className={'vp-titlebar vp-titlebar-' + windowControls}
        // Tauri's own drag region rather than `-webkit-app-region`, which
        // WebView2 does not honor: this is the attribute the shell looks for.
        data-tauri-drag-region={windowControls === 'none' ? undefined : true}
    >
        {logo}

        {logo && <span className='vp-titlebar-divider' />}
        {title}

        {emulator.vbcHeaderPillLabel &&
            <button
                type='button'
                className='vp-titlebar-pill'
                onMouseEnter={event => DOM_HOVER.show(event.currentTarget,
                    nls.localize(
                        'vueport/titleBar/vbcHint',
                        'VB Color hardware is active — click to change hardware mode'
                    ))}
                onMouseLeave={() => DOM_HOVER.hide()}
                onClick={() => {
                    DOM_HOVER.hide();
                    emulator.pickHardwareMode?.().catch(() => undefined);
                }}
            >
                <VbColorIcon size={14} />
                {emulator.vbcHeaderPillLabel}
            </button>}

        {hardcore &&
            <button
                type='button'
                className='vp-titlebar-pill'
                onMouseEnter={event => DOM_HOVER.show(event.currentTarget,
                    nls.localize('vueport/achievements/hardcore/titleHint', 'Hardcore Mode is on — click to turn off'))}
                onMouseLeave={() => DOM_HOVER.hide()}
                onClick={() => {
                    DOM_HOVER.hide();
                    emulator.offerToLeaveHardcore?.().catch(() => undefined);
                }}
            >
                <Lightning size={18} weight='fill' />
                {nls.localize('vueport/achievements/hardcore/title', 'Hardcore Mode')}
            </button>}

        {(emulator.isLinked() || emulator.linkStatus() === 'waiting') &&
            /* The modifier carries no styling of its own — it is what says
               which pill this is, the way the update pill's does. Shown while
               waiting as well: a link invited from the library has a second
               window open and waiting on this one well before there is a game
               to link over. `waiting` rather than `linked` until the session
               is up, so the modifier still says what it did. */
            <span className={'vp-titlebar-pill ' + (emulator.isLinked() ? 'linked' : 'waiting')}>
                <PlugsConnected size={18} />
                {nls.localize('vueport/titleBar/linked', 'Linked · P{0}', String(emulator.player))}
            </span>}

        <div className='vp-titlebar-spacer' />

        <div className='vp-titlebar-controls'>
            {(emulator.hasRom || emulator.linksWithoutRom) && <>
                {/* Linking a second player — a session control, not transport,
                    so it sits up here rather than in the strip over the
                    picture. Set apart from the panel buttons by its divider. */}
                <TitleBarButton
                    control='link'
                    label={linkLabel(emulator.linkStatus())}
                    /* Lit for waiting as well as for linked: something is
                       running that pressing the button would stop. */
                    active={emulator.linkStatus() === 'linked' || emulator.linkStatus() === 'waiting'}
                    onClick={() => emulator.runCommand(linkCommand(emulator.linkStatus()))}
                >
                    {emulator.linkStatus() === 'linked' ? <PlugsConnected size={20} /> : <Plugs size={20} />}
                </TitleBarButton>
                <span className='vp-titlebar-controls-divider' />
            </>}
            {emulator.hasRom && <>
                {/* Profiling is not up here: it belongs to the CPU Profiler
                    panel, and a recording that outlives Debug mode is stopped
                    from the badge over the picture. */}
                {/* Left of the cheats, because it is the one of these that
                    is about the session rather than about the game: the moments
                    of this sitting, to go back to. */}
                {emulator.toggleSaveStates && panelButton('save-states',
                    nls.localize('vueport/commands/toggle/saveStates', 'Save States'),
                    emulator.state.showSaveStates ?? false, <ClockCountdown size={20} />,
                    () => emulator.toggleSaveStates?.())}
                {panelButton('cheats',
                    nls.localize('vueport/commands/toggle/cheats', 'Cheats'),
                    emulator.state.showCheats, <Star size={20} />,
                    () => emulator.toggleCheats(), hardcore)}
                {panelButton('macros',
                    nls.localize('vueport/commands/toggle/macros', 'Macros'),
                    emulator.state.showMacros, <Queue size={20} />,
                    () => emulator.toggleMacros(), hardcore)}
                {panelButton('patches',
                    nls.localize('vueport/commands/toggle/patches', 'Patches'),
                    emulator.state.showPatches, <Bandaids size={20} />,
                    () => emulator.togglePatches(), hardcore)}
                {panelButton('achievements',
                    nls.localize('vueport/commands/toggle/achievements', 'Achievements'),
                    emulator.state.showAchievements, <Trophy size={20} />,
                    () => emulator.toggleAchievements())}
                <span className='vp-titlebar-controls-divider' />
                <TitleBarButton
                    control='mode'
                    label={debugging
                        ? nls.localize('vueport/debug/leave', 'Leave Debug mode')
                        : nls.localize('vueport/debug/enter', 'Debug mode')}
                    active={debugging}
                    dimmed={hardcore}
                    onClick={() => emulator.toggleDebugMode()}
                >
                    <Bug size={20} />
                </TitleBarButton>
            </>}

            <TitleBarButton
                control='settings'
                label={nls.localize('vueport/settings/title', 'Settings')}
                active={emulator.settingsOpen}
                onClick={() => emulator.togglePreferencesWindow()}
            >
                <SlidersHorizontal size={20} />
            </TitleBarButton>
            <TitleBarButton
                control='fullscreen'
                label={fullscreen
                    ? nls.localize('vueport/commands/exitFullscreen', 'Exit Fullscreen')
                    : nls.localize('vueport/commands/fullscreen', 'Fullscreen')}
                active={fullscreen}
                onClick={() => emulator.runAction(EmulatorAction.Fullscreen)}
            >
                {fullscreen ? <ArrowsIn size={20} /> : <ArrowsOut size={20} />}
            </TitleBarButton>
        </div>

        {windowControls === 'custom' &&
            <div className='vp-window-controls'>
                <button
                    type='button'
                    className='vp-window-control'
                    aria-label={nls.localize('vueport/window/minimize', 'Minimize')}
                    onClick={() => props.onMinimizeWindow?.()}
                >
                    <svg viewBox='0 0 12 12' aria-hidden='true'><path d='M1 6h10' /></svg>
                </button>
                <button
                    type='button'
                    className='vp-window-control'
                    aria-label={nls.localize('vueport/window/maximize', 'Maximize')}
                    onClick={() => props.onMaximizeWindow?.()}
                >
                    <svg viewBox='0 0 12 12' aria-hidden='true'>
                        <rect x='1.5' y='1.5' width='9' height='9' />
                    </svg>
                </button>
                <button
                    type='button'
                    className='vp-window-control close'
                    aria-label={nls.localize('vueport/window/close', 'Close')}
                    onClick={() => props.onCloseWindow?.()}
                >
                    <svg viewBox='0 0 12 12' aria-hidden='true'>
                        <path d='M1.5 1.5l9 9M10.5 1.5l-9 9' />
                    </svg>
                </button>
            </div>}
    </header>;
}
