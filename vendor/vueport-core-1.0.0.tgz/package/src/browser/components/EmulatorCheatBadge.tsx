import { Star } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';

// count of active cheats over the picture, shown only while the cheats panel is put away, so cheats
// a player set up and forgot are not out of sight. A button that shows them
export default function EmulatorCheatBadge(props: {
    count: number,
    onShow: () => void,
}): React.JSX.Element {
    const { count, onShow } = props;
    return <button
        type='button'
        className='vp-screen-badge vp-cheat-badge'
        aria-label={nls.localize('vueport/cheats/activeBadge',
            '{0} cheats are on. Show them.', count)}
        onClick={onShow}
    >
        <Star size={16} weight='fill' />
        {count}
    </button>;
}
