import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { ScreenPanel } from '../panels/emulator-screen-panel';
import RadioSelect from './kit/RadioSelect';

export interface EmulatorScreenPreviewProps {
    /** The panel the picture normally lives in. */
    screen: ScreenPanel;
    /**
     * A still to show when there is no game — a screenshot the host points to,
     * recolored through the current palette. See
     * {@link ScreenPanel.setPlaceholder}.
     *
     * Optional: a host with no still to offer gets the live picture alone and
     * no picker at all, rather than a picker with one usable answer. The
     * studio is one — its emulator opens on a ROM it just built, so the case
     * the still covers barely arises there.
     */
    placeholder?: string;
    /** Whether a ROM is loaded, i.e. whether there is a live picture to show. */
    loaded: boolean;
}

/**
 * The Display pane's preview — a mini screen panel.
 *
 * Not a copy of the canvas: presentation was handed to the worker and only one
 * element can hold it, so this borrows the picture itself while it is mounted
 * and gives it back on the way out. Unlike the palette window it once served,
 * this borrows it *with* the decoration and the scale, so both can be seen at
 * work. With no game it shows the still instead, run through the palette so a
 * choice still previews.
 */
export default function EmulatorScreenPreview(
    props: EmulatorScreenPreviewProps,
): React.JSX.Element {
    const { screen, placeholder, loaded } = props;
    const host = React.useRef<HTMLDivElement>(null);
    const [source, setSource] = React.useState<'placeholder' | 'live'>(
        loaded || !placeholder ? 'live' : 'placeholder',
    );

    React.useEffect(() => {
        if (placeholder) {
            screen.setPlaceholder(placeholder).catch(() => undefined);
        }
    }, [screen, placeholder]);

    React.useEffect(() => {
        const node = host.current;
        if (!node) {
            return undefined;
        }
        screen.lendPicture(node, { fit: false, decorate: true });
        return () => {
            screen.showPlaceholder(false);
            screen.returnPicture();
        };
    }, [screen]);

    const showPlaceholder = !!placeholder && (source === 'placeholder' || !loaded);
    React.useEffect(() => {
        screen.showPlaceholder(showPlaceholder);
    }, [screen, showPlaceholder]);

    // The box needs an intrinsic shape for the borrowed frame — sized as a
    // share of its container — to have something to fit into. The still is now
    // laid out to the same geometry as a live picture, so the mode's shape is
    // right for both. `web-emulator` re-renders this on every setting change,
    // so a mode switch is picked up here.
    const { width, height } = screen.pictureSize;

    return <>
        {/* Only where there are two things to choose between. Without a still
            there is one source, and a picker offering it alone would be asking
            a question with one answer. */}
        {placeholder &&
            <RadioSelect
                fitSpace
                options={[
                    {
                        value: 'placeholder',
                        label: nls.localize('vueport/palettes/preview/placeholder', 'Placeholder'),
                    },
                    {
                        value: 'live',
                        label: nls.localize('vueport/palettes/preview/live', 'Live image'),
                        disabled: !loaded,
                    },
                ]}
                defaultValue={showPlaceholder ? 'placeholder' : 'live'}
                onChange={chosen => setSource(chosen[0].value as 'placeholder' | 'live')}
            />}
        <div
            className='vp-screen-preview'
            ref={host}
            style={{ aspectRatio: `${width} / ${height}` }}
        />
    </>;
}
