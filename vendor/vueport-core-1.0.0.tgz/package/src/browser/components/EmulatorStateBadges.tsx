import {
  BatteryLow,
  ClockClockwise,
  FastForward,
  Pause,
  Rewind,
  SkipForward,
  SpeakerSimpleSlash,
} from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { EmulatorAction } from '../emulator-types';
import { EmulatorToolbarHost } from './EmulatorToolbar';

/**
 * What the machine is doing, over the corner of the picture.
 *
 * The counterpart to the chrome hiding itself. While a toolbar is on screen
 * the lit buttons say all of this — paused, muted, fast-forwarding — and a
 * second copy in the corner would be noise. Take the toolbar away and the
 * lit buttons go with it, and somebody is playing a muted game with nothing
 * on screen saying so, wondering why there is no sound.
 *
 * So these are not badges for the sake of decoration; they are where the
 * state moved to. Which is also why they are worded rather than iconic: an
 * icon in a corner is a puzzle when there is no toolbar to compare it with.
 *
 * And each one switches off what it is announcing. These only appear where
 * the chrome has hidden itself, which is exactly where the button that would
 * otherwise do it has gone: the keyboard shortcut is real but is no help to
 * somebody who has just discovered the sound is off and does not know what
 * turned it off. Reading the badge and pressing it are the same gesture.
 */

/** One thing that is on, what it is called, and how to stop it. */
interface BadgeState {
  id: string;
  label: string;
  icon: React.ReactNode;
  /** What pressing does, as the accessible name says it. */
  action: string;
  stop(): void;
  /** A ratio worth saying, for the two that have one. */
  detail?: string;
}

export function EmulatorStateBadges(props: { host: EmulatorToolbarHost }): React.JSX.Element | null {
  const { host } = props;
  const badges: BadgeState[] = [];
  const resume = nls.localize('vueport/state/resume', 'Resume');

  // Rewinding first, and frame advance beside it: both are momentary, both
  // are what somebody is doing right now rather than a mode they left on.
  if (host.rewinding) {
    badges.push({
      id: 'rewinding',
      label: nls.localize('vueport/state/rewinding', 'Rewinding'),
      icon: <Rewind size={16} weight='fill' />,
      action: nls.localize('vueport/state/stopRewinding', 'Stop rewinding'),
      stop: () => host.stopRewinding(),
    });
  }
  if (host.state.paused) {
    badges.push({
      id: 'paused',
      label: nls.localize('vueport/state/paused', 'Paused'),
      icon: <Pause size={16} weight='fill' />,
      action: resume,
      stop: () => host.runAction(EmulatorAction.PauseToggle),
    });
  }
  if (host.state.frameAdvance) {
    badges.push({
      id: 'frame-advance',
      label: nls.localize('vueport/state/frameAdvance', 'Frame advance'),
      icon: <SkipForward size={16} weight='fill' />,
      // Frame advance is a paused machine being stepped, so leaving it is
      // resuming — the same action the Paused badge beside it performs.
      action: resume,
      stop: () => host.runAction(EmulatorAction.PauseToggle),
    });
  }
  if (host.state.fastForward) {
    badges.push({
      id: 'fast-forward',
      label: nls.localize('vueport/state/fastForward', 'Fast-forward'),
      icon: <FastForward size={16} weight='fill' />,
      action: nls.localize('vueport/state/stopFastForward', 'Back to normal speed'),
      stop: () => host.runAction(EmulatorAction.ToggleFastForward),
      detail: `×${host.settings.get('fastForwardRatio')}`,
    });
  }
  if (host.state.slowmotion) {
    badges.push({
      id: 'slow-motion',
      label: nls.localize('vueport/state/slowMotion', 'Slow motion'),
      icon: <ClockClockwise size={16} />,
      action: nls.localize('vueport/state/stopSlowMotion', 'Back to normal speed'),
      stop: () => host.runAction(EmulatorAction.ToggleSlowmotion),
      detail: `×${host.settings.get('slowMotionRatio')}`,
    });
  }
  if (host.state.muted) {
    badges.push({
      id: 'muted',
      label: nls.localize('vueport/state/muted', 'Muted'),
      icon: <SpeakerSimpleSlash size={16} weight='fill' />,
      action: nls.localize('vueport/state/unmute', 'Unmute'),
      stop: () => host.runAction(EmulatorAction.AudioMute),
    });
  }
  if (host.state.lowPower) {
    badges.push({
      id: 'low-power',
      label: nls.localize('vueport/state/lowPower', 'Low power'),
      icon: <BatteryLow size={16} />,
      action: nls.localize('vueport/state/stopLowPower', 'Leave low power'),
      stop: () => host.runAction(EmulatorAction.ToggleLowPower),
    });
  }

  if (badges.length === 0) {
    return null;
  }

  /*
   * `role="status"` rather than nothing: this is the only place these are
   * announced once the chrome is hidden, and somebody who cannot see the
   * corner of the picture still needs to be told the sound is off.
   */
  return <div className='vp-state-badge-list' role='status'>
    {badges.map(badge =>
      <button
        type='button'
        // The same pill as the badges in the corner opposite; see the
        // stylesheet for why they stopped being two different shapes.
        className='vp-screen-badge vp-state-badge'
        key={badge.id}
        data-state={badge.id}
        // What it says and what pressing it does, in that order — the label
        // is the news, the action is what to do about it.
        aria-label={`${badge.label}. ${badge.action}.`}
        onClick={badge.stop}
      >
        {badge.icon}
        <span>{badge.label}</span>
        {badge.detail && <span className='vp-state-badge-detail'>{badge.detail}</span>}
      </button>
    )}
  </div>;
}
