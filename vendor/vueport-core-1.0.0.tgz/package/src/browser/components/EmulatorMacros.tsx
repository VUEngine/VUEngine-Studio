import {
    GlobeHemisphereWest,
    Hash,
    MagnifyingGlass,
    PencilSimple,
    Play,
    Queue,
    Record,
    Repeat,
    Stop,
    Trash,
    X,
} from '@phosphor-icons/react';
import * as React from 'react';
import styled from 'styled-components';
import { VueportNotifications } from '../../common/emulator-host';
import {
    formatMacroDuration,
    MACRO_SLOT_COUNT,
    parseMacroFile,
    Macro,
    macroKeysUsed,
    macroPressCount,
    macroPresses,
} from '../../common/emulator-macros';
import { nls } from '../../common/emulator-nls';
import { EmulatorGamePadButton } from '../emulator-commands';
import { emulatorHeldButtons } from '../emulator-input';
import { MacroStore, MacroActivity } from '../emulator-macro-store';
import EmptyContainer from './kit/EmptyContainer';
import { PanelDetailFooter, PanelDetailHero, PanelDetailSection, PanelDetailToolbar } from './kit/PanelDetail';
import Select from './kit/Select';
import Switch from './kit/Switch';

const StyledCloseButton = styled.button`
    position: relative;
    z-index: 10;
`;

/** How often the stopwatch moves while something is being recorded or played. */
const TICK_MS = 100;

/**
 * The controller's buttons, as short as they can be written.
 *
 * Not translated, and deliberately: these are the markings on the hardware,
 * the same way a cheat's addresses are the machine's. An arrow is an arrow in
 * every language, and a row of steps has room for `L↑ A` where it has none for
 * "Left D-Pad ⇧, A". The full names are still what the hover says — those come
 * from the input commands, which are translated.
 */
const BUTTON_SYMBOLS: Record<EmulatorGamePadButton, string> = {
    lUp: 'L↑',
    lRight: 'L→',
    lDown: 'L↓',
    lLeft: 'L←',
    rUp: 'R↑',
    rRight: 'R→',
    rDown: 'R↓',
    rLeft: 'R←',
    lTrigger: 'LT',
    rTrigger: 'RT',
    select: 'Sel',
    start: 'Sta',
    b: 'B',
    a: 'A',
};

/**
 * The steps a macro's timeline is marked off in, in milliseconds — the first
 * that leaves no more than four marks along it.
 */
const TIMELINE_TICKS = [100, 200, 500, 1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000];

/**
 * Every button a macro holds, with the stretches it is held for as
 * `[from, to]` moments — a button still down at the last step is held to the
 * end. In the order the controller reference reads them, like everywhere else
 * a mask is spelled out here.
 */
function macroLanes(macro: Macro): Array<{ button: EmulatorGamePadButton, bars: Array<[number, number]> }> {
    const lanes = emulatorHeldButtons(macroKeysUsed(macro))
        .map(button => ({ button, bars: [] as Array<[number, number]>, since: undefined as number | undefined }));
    for (const step of macro.steps) {
        const held = emulatorHeldButtons(step.keys);
        for (const lane of lanes) {
            const down = held.includes(lane.button);
            if (down && lane.since === undefined) {
                lane.since = step.at;
            } else if (!down && lane.since !== undefined) {
                lane.bars.push([lane.since, step.at]);
                lane.since = undefined;
            }
        }
    }
    return lanes.map(({ button, bars, since }) => ({
        button,
        bars: since === undefined ? bars : [...bars, [since, macro.duration]],
    }));
}

/**
 * The macros kept beside the ROM: recorded button sequences, named, and played
 * back on demand.
 *
 * The list on top is every macro in the file; opening one shows what it is
 * made of and lets it be renamed. Everything here drives the store, which owns
 * the list, writes the file and holds the buttons down during playback — so a
 * macro plays on with this closed, and this is only a view of it.
 *
 * A component rather than a panel, for the reason the cheats are one: it is
 * shown in two places and only one of them is a panel. In Debug mode it is
 * docked like every other inspector; while playing it sits beside the screen
 * with no dock involved, because recording a sequence is something you do
 * *while* playing and should not cost you the game you are in.
 */
export default function EmulatorMacros(props: {
    macros: MacroStore,
    notifications: VueportNotifications,
    /**
     * Put these away, when there is somewhere to put them away to.
     *
     * Given for the strip beside the screen, which has no chrome of its own to
     * close it by. The docked panel leaves this out: it has a tab.
     */
    onClose?: () => void,
}): React.JSX.Element {
    const { macros, notifications, onClose } = props;

    const [editing, setEditing] = React.useState<number | undefined>(undefined);
    /** Narrows the list by name; the panel keeps every other bit of state. */
    const [filter, setFilter] = React.useState('');
    const importInput = React.useRef<HTMLInputElement>(null);
    const [, setVersion] = React.useState(0);
    const redraw = React.useCallback(() => setVersion(version => version + 1), []);

    // The store owns the list and says when it changed — a macro can be
    // started from the other copy of this, or the file reloaded with a new ROM.
    React.useEffect(() => {
        const subscription = macros.onDidChange(redraw);
        return () => subscription.dispose();
    }, [macros, redraw]);

    const activity = macros.activity;

    /*
     * The stopwatch, which nothing else is going to redraw.
     *
     * The store says when recording starts and stops, not how long it has been
     * going: that changes continuously, and a store firing sixty times a
     * second so a panel can move one number would make every other listener
     * pay for it. So the number is pulled here, on a timer that exists only
     * while there is something to count.
     */
    React.useEffect(() => {
        if (activity === MacroActivity.IDLE) {
            return undefined;
        }
        const timer = window.setInterval(redraw, TICK_MS);
        return () => window.clearInterval(timer);
    }, [activity, redraw]);

    const list = macros.list;
    const recording = activity === MacroActivity.RECORDING;

    /** The X at the end of the toolbar row, when there is one to draw. */
    const closeButton = onClose && <StyledCloseButton
        type='button'
        className='vp-panel-close'
        aria-label={nls.localize('vueport/macros/closeMacros', 'Close Macros')}
        onClick={onClose}
    >
        <X size={20} />
    </StyledCloseButton>;

    /**
     * "Macros" and the way out, when there is one.
     *
     * The title is for the strip beside the screen, which has no tab naming it;
     * the docked panel has one, so there the heading is only the close — which
     * it also does without, so then it takes no room.
     */
    const header = <div className='vp-panel-heading'>
        {onClose &&
            <span className='vp-panel-heading-title'>
                <Queue size={22} />
                {nls.localize('vueport/macros/title', 'Macros')}
            </span>}
        {closeButton}
    </div>;

    /**
     * What a recording is called before anybody names it.
     *
     * Numbered from the length of the list rather than from the highest number
     * in it: this is a placeholder to be typed over, not an identity, and the
     * editor opens on it precisely so that it gets typed over.
     */
    const defaultName = (): string =>
        nls.localize('vueport/macros/newMacro', 'Macro {0}', list.length + 1);

    /**
     * Stop recording and keep what was recorded, opening it to be named.
     *
     * Nothing is kept when no button was pressed — the store drops that, and
     * says so by returning nothing. Somebody who pressed Record twice by
     * accident should not have to delete the evidence.
     */
    const stopRecording = (): void => {
        const index = macros.stopRecording(defaultName());
        if (index === undefined) {
            notifications.info(nls.localize(
                'vueport/macros/nothingRecorded',
                'Nothing was recorded: no buttons were pressed.'));
            return;
        }
        setEditing(index);
    };

    const toggleRecording = (): void => {
        if (recording) {
            stopRecording();
        } else {
            // Back to the list, so that what is about to be recorded is not
            // hidden behind the editor for something else.
            setEditing(undefined);
            macros.startRecording();
        }
    };

    /**
     * Delete a macro, once the user has confirmed it.
     *
     * Worth asking about, and more so than for a cheat: a cheat is a few
     * numbers that can be typed in again, and a macro is a performance that
     * cannot — there is no getting the same one back except by playing it
     * again.
     */
    const removeMacro = async (index: number): Promise<void> => {
        const doomed = list[index];
        if (!doomed) {
            return;
        }
        // Hoisted out of the message's arguments for the reason the cheats
        // hoist theirs: the extractor stops descending once it has matched a
        // localize call, so a nested one never reaches nls.json.
        const unnamed = nls.localize('vueport/macros/thisMacro', 'this macro');
        const confirmed = await notifications.confirm({
            title: nls.localize('vueport/macros/deleteMacroQuestion', 'Delete Macro?'),
            message: nls.localize(
                'vueport/macros/areYouSureYouWantToDelete',
                'Are you sure you want to delete {0}?',
                doomed.name || unnamed,
            ),
        });
        if (confirmed) {
            macros.remove(index);
            // Back to the list: the thing being edited is gone, and every
            // index after it now means a different macro.
            setEditing(undefined);
        }
    };

    /** The symbols of a mask, in the order the controller reference reads them. */
    const symbols = (keys: number): string[] =>
        emulatorHeldButtons(keys).map(button => BUTTON_SYMBOLS[button]);

    /** The buttons of a mask, as caps — or the word for holding none of them. */
    const renderButtons = (keys: number): React.ReactNode => {
        const held = symbols(keys);
        if (held.length === 0) {
            return <span className='vp-macros-release'>
                {nls.localize('vueport/macros/release', 'release')}
            </span>;
        }
        return held.map(symbol => (
            <span className='vp-macros-button' key={symbol}>{symbol}</span>
        ));
    };

    /**
     * What the macro presses, in order, for the line under its name.
     *
     * The presses only — a line listing every step would be half releases, and
     * nobody reads a sequence as "A, nothing, up, up and A, up, nothing". Two
     * buttons that went down together stay together, with a dot between one
     * press and the next, so a chord does not read as two presses.
     */
    const renderSequence = (macro: Macro): React.ReactNode =>
        macroPresses(macro).map((press, index) =>
            <React.Fragment key={index}>
                {index > 0 && <span className='vp-macros-separator'>·</span>}
                {symbols(press).map(symbol => (
                    <span className='vp-macros-button' key={symbol}>{symbol}</span>
                ))}
            </React.Fragment>
        );

    /** The same sequence as plain text, for the hover on a line that is cut off. */
    const sequenceText = (macro: Macro): string =>
        macroPresses(macro).map(press => symbols(press).join(' ')).join(' · ');

    /**
     * The macro drawn as what the hands did: a lane per button it ever
     * holds, with a bar for every stretch that button is down, against one
     * clock. The steps list below says the same thing exactly; this is what
     * says it at a glance — that the A is a tap and the right is held through
     * it, which a column of moments makes you work out.
     *
     * Read-only, like the steps: recording it again is the edit.
     */
    const renderTimeline = (macro: Macro, index: number): React.ReactNode => {
        const duration = Math.max(1, macro.duration);
        const at = (moment: number): string => `${Math.min(100, (moment / duration) * 100)}%`;
        const lanes = macroLanes(macro);
        const step = TIMELINE_TICKS.find(candidate => duration / candidate <= 4)
            ?? TIMELINE_TICKS[TIMELINE_TICKS.length - 1];
        const ticks: number[] = [];
        for (let moment = 0; moment <= duration; moment += step) {
            ticks.push(moment);
        }
        // Where playback has got to, folded back into the macro for one that
        // repeats — the clock keeps running across the loops.
        const playhead = macros.playingIndex === index
            ? (macro.loop ? macros.elapsed % duration : Math.min(macros.elapsed, duration))
            : undefined;
        return <div className='vp-detail-card vp-macros-timeline'>
            {lanes.map(({ button, bars }, lane) => (
                <div className='vp-macros-lane' key={button}>
                    <span className='vp-macros-button'>{BUTTON_SYMBOLS[button]}</span>
                    <span className='vp-macros-track'>
                        {bars.map(([from, to], bar) => <span
                            key={bar}
                            className='vp-macros-bar'
                            style={{
                                background: `var(--vp-series-${(lane % 5) + 1})`,
                                left: at(from),
                                width: `calc(${at(to)} - ${at(from)})`,
                            }}
                        />)}
                        {playhead !== undefined &&
                            <span className='vp-macros-playhead' style={{ left: at(playhead) }} />}
                    </span>
                </div>
            ))}
            <div className='vp-macros-lane vp-macros-ticks' aria-hidden='true'>
                <span />
                <span className='vp-macros-track'>
                    {ticks.map(moment => <span key={moment} style={{ left: at(moment) }}>
                        {step < 1000 ? (moment / 1000).toFixed(1) : `${moment / 1000}`}
                    </span>)}
                </span>
            </div>
        </div>;
    };

    /**
     * Every moment of the macro: when it happens, and what is held from then.
     *
     * Read-only, unlike a cheat's codes. A cheat is a handful of numbers
     * somebody looked up and may well want to correct; a macro is a recording
     * of what a pair of hands did, and a table of milliseconds is not where
     * anybody would want to fix one. Recording it again is the edit.
     */
    const renderSteps = (macro: Macro): React.ReactNode =>
        <ol className='vp-detail-card vp-macros-steps vp-scroll'>
            {macro.steps.map((step, index) => (
                <li className='vp-macros-step' key={index}>
                    <span className='time'>{formatMacroDuration(step.at)}</span>
                    <span className='keys'>{renderButtons(step.keys)}</span>
                </li>
            ))}
        </ol>;

    /**
     * Move a macro between this game's file and the shared one, and keep it
     * open: it lands at the end of the part of the list it moved to, so the
     * index this view was opened on now names a different macro. Worked out
     * rather than looked up — the store hands out the shared ones as fresh
     * copies, so the macro itself is not in the list to be found.
     */
    const setGlobal = (index: number, global: boolean): void => {
        macros.setGlobal(index, global);
        setEditing(global
            ? macros.list.length - 1
            : macros.list.filter(entry => !entry.global).length - 1);
    };

    const renderDetail = (macro: Macro, index: number): React.ReactNode => {
        const playing = macros.playingIndex === index;
        const name = macro.name || nls.localize('vueport/macros/thisMacro', 'this macro');
        const presses = macroPressCount(macro);
        return <div className='vp-detail-page'>
            <PanelDetailHero
                icon={<Queue size={22} />}
                name={macro.name}
                onRename={next => macros.update(index, { name: next })}
                meta={<>
                    {formatMacroDuration(macro.duration)}
                    {' · '}
                    {presses === 1
                        ? nls.localize('vueport/macros/pressCountOne', '1 press')
                        : nls.localize('vueport/macros/pressCountMany', '{0} presses', presses)}
                    {macro.loop && <Repeat size={13} />}
                    {macro.slot !== undefined && <SlotBadge slot={macro.slot} />}
                    {macro.global && <GlobeHemisphereWest
                        size={13}
                        aria-label={nls.localize('vueport/macros/globalMacro', 'Available in every game')}
                    />}
                </>}
                control={<button
                    type='button'
                    className={'vp-detail-play' + (playing ? ' playing' : '')}
                    aria-pressed={playing}
                    aria-label={playing
                        ? nls.localize('vueport/macros/stopNamedMacro', 'Stop {0}', name)
                        : nls.localize('vueport/macros/playNamedMacro', 'Play {0}', name)}
                    onClick={() => macros.play(index)}
                >
                    {playing ? <Stop size={18} weight='fill' /> : <Play size={18} weight='fill' />}
                </button>}
            />
            <PanelDetailSection
                title={nls.localize('vueport/macros/timeline', 'Timeline')}
                aside={playing ? formatMacroDuration(macros.elapsed) : formatMacroDuration(macro.duration)}
            >
                {renderTimeline(macro, index)}
            </PanelDetailSection>
            <PanelDetailSection title={nls.localize('vueport/macros/playback', 'Playback')}>
                <div className='vp-detail-card'>
                    <div className='vp-detail-option'>
                        <Repeat size={18} aria-hidden='true' />
                        <span className='vp-detail-option-text'>
                            {nls.localize('vueport/macros/loop', 'Repeat')}
                            <span className='hint'>
                                {nls.localize('vueport/macros/loopHint',
                                    'Start again from the top when it ends, until it is stopped')}
                            </span>
                        </span>
                        <Switch
                            label={nls.localize('vueport/macros/loop', 'Repeat')}
                            value={macro.loop === true}
                            onChange={loop => macros.update(index, { loop })}
                        />
                    </div>
                    <div className='vp-detail-option'>
                        <Hash size={18} aria-hidden='true' />
                        <span className='vp-detail-option-text'>
                            {nls.localize('vueport/macros/slot', 'Slot')}
                            <span className='hint'>
                                {nls.localize('vueport/macros/slotHint',
                                    'Play it with the key or controller button set for this slot in the input settings')}
                            </span>
                        </span>
                        <Select
                            size='small'
                            label={nls.localize('vueport/macros/slot', 'Slot')}
                            value={String(macro.slot ?? 0)}
                            onChange={value => macros.setSlot(index, Number(value) || undefined)}
                            options={[
                                { value: '0', label: nls.localize('vueport/macros/slotNone', 'None') },
                                ...Array.from({ length: MACRO_SLOT_COUNT }, (unused, i) => {
                                    const slot = i + 1;
                                    // Who has it now, in the same file: choosing
                                    // it takes it from them, so it is worth seeing.
                                    const holder = macros.list.find((other, at) =>
                                        at !== index && other.slot === slot && !other.global === !macro.global);
                                    return {
                                        value: String(slot),
                                        label: holder
                                            ? nls.localize('vueport/macros/slotTaken', '{0} ({1})', slot, holder.name)
                                            : String(slot),
                                    };
                                }),
                            ]}
                        />
                    </div>
                    {/* Absent rather than disabled where the host keeps no
                        shared file: a switch that can never be thrown says a
                        feature is missing, which is not the case — this
                        application simply has nowhere to put it. */}
                    {macros.supportsGlobal && <div className='vp-detail-option'>
                        <GlobeHemisphereWest size={18} aria-hidden='true' />
                        <span className='vp-detail-option-text'>
                            {nls.localize('vueport/macros/global', 'All Games')}
                            <span className='hint'>
                                {nls.localize('vueport/macros/globalHint',
                                    'Offer this macro in every game, not only this one. It moves out \
of this game\'s macros file and into the shared one.')}
                            </span>
                        </span>
                        <Switch
                            label={nls.localize('vueport/macros/global', 'All Games')}
                            value={macro.global === true}
                            onChange={global => setGlobal(index, global)}
                        />
                    </div>}
                </div>
            </PanelDetailSection>
            <PanelDetailSection
                title={nls.localize('vueport/macros/steps', 'Steps')}
                aside={macro.steps.length}
            >
                {renderSteps(macro)}
            </PanelDetailSection>
            <PanelDetailFooter
                hint={nls.localize('vueport/macros/recordAgain', 'Record again to change the steps.')}
            >
                <button className='vp-button secondary danger' onClick={() => removeMacro(index)}>
                    <Trash size={14} />
                    {nls.localize('vueport/macros/removeMacro', 'Remove Macro')}
                </button>
            </PanelDetailFooter>
        </div>;
    };

    /**
     * Read a macros file the player picked and add what is in it to the list.
     *
     * The emulator's own `<rom>.vueport-macros.json` — the file the store keeps
     * beside a ROM's saves, so this is how a macro moves from one install, or
     * one ROM, to another. The picker is reset so choosing the same file twice
     * fires again.
     */
    const importFrom = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (importInput.current) {
            importInput.current.value = '';
        }
        if (!file) {
            return;
        }
        let added: number;
        try {
            added = macros.importMacros(parseMacroFile(await file.text()));
        } catch {
            notifications.error(nls.localize('vueport/macros/importFailed',
                '{0} could not be read as a macros file.', file.name));
            return;
        }
        if (added === 0) {
            notifications.warn(nls.localize('vueport/macros/importedNone',
                'No macros were found in {0}.', file.name));
            return;
        }
        notifications.info(added === 1
            ? nls.localize('vueport/macros/importedOne', 'Imported 1 macro from {0}.', file.name)
            : nls.localize('vueport/macros/importedMany',
                'Imported {0} macros from {1}.', String(added), file.name));
    };

    /** Record / Stop, at the foot of the panel — the one thing this list adds to. */
    const recordActions = <div className='vp-panel-actions'>
        <button
            className={recording ? 'vp-button' : 'vp-button secondary'}
            onClick={toggleRecording}
        >
            {recording
                ? <>
                    <Stop size={16} weight='fill' />
                    {nls.localize('vueport/macros/stopRecording', 'Stop')}
                    <span className='vp-macros-clock'>
                        {formatMacroDuration(macros.elapsed)}
                    </span>
                </>
                : <>
                    <Record size={16} weight='fill' />
                    {nls.localize('vueport/macros/record', 'Record')}
                </>
            }
        </button>
        {!recording &&
            <button className='vp-button secondary' onClick={() => importInput.current?.click()}>
                {nls.localize('vueport/macros/import', 'Import…')}
            </button>}
        <input
            ref={importInput}
            type='file'
            accept='.json,application/json'
            hidden
            onChange={event => importFrom(event.target.files)}
        />
    </div>;

    if (list.length === 0 && !recording) {
        return <>
            {header}
            <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/macros/noMacro', 'No macros have been recorded')}
                    description={nls.localize('vueport/macros/noMacroDescription',
                        'Record a sequence of button presses, give it a name, and play it back whenever you like.')}
                    icon={<Record size={32} />}
                />
            </div>
            {recordActions}
        </>;
    }

    const editingMacro = editing === undefined ? undefined : list[editing];

    // Editing one takes the whole panel; the list is what it goes back to.
    if (editingMacro !== undefined && editing !== undefined) {
        return <>
            <PanelDetailToolbar
                list={nls.localize('vueport/macros/title', 'Macros')}
                index={editing}
                count={list.length}
                onBack={() => setEditing(undefined)}
                onStep={setEditing}
            />
            <div className='vp-panel-detail vp-scroll'>
                {renderDetail(editingMacro, editing)}
            </div>
        </>;
    }

    // The index goes along for the ride: the store is addressed by position in
    // the whole list, and a filtered row that played the wrong macro would be
    // a bug nobody would think to look for.
    const needle = filter.trim().toLowerCase();
    const visible = list
        .map((macro, index) => ({ macro, index }))
        .filter(({ macro }) => !needle || macro.name.toLowerCase().includes(needle));

    return <>
        {header}
        <div className='vp-panel-filter'>
            <MagnifyingGlass size={15} />
            <input
                type='text'
                spellCheck={false}
                value={filter}
                placeholder={nls.localize('vueport/macros/filter', 'Filter')}
                aria-label={nls.localize('vueport/macros/filter', 'Filter')}
                onChange={event => setFilter(event.target.value)}
            />
            {filter &&
                <button
                    type='button'
                    className='vp-panel-filter-clear'
                    aria-label={nls.localize('vueport/general/clear', 'Clear')}
                    onClick={() => setFilter('')}
                >
                    <X size={14} />
                </button>}
        </div>
        <div className='vp-split-table vp-scroll'>
            {visible.length === 0 && !recording
                ? <p className='vp-panel-empty'>
                    {nls.localize('vueport/macros/noMatch', 'No macros match “{0}”.', filter.trim())}
                </p>
                : <ul className='vp-panel-list'>
                    {recording &&
                        /* The recording, as a row of its own where the macro it
                           will become is going to be. Nothing else on screen says
                           that the buttons being pressed are going anywhere, and
                           the panel is often the only part of the emulator in
                           view. */
                        <li className='vp-panel-row vp-macros-row recording'>
                            <Record size={16} weight='fill' className='vp-macros-rec' />
                            <span className='vp-panel-row-name'>
                                {nls.localize('vueport/macros/recording', 'Recording…')}
                            </span>
                            <span className='vp-macros-meta'>
                                {formatMacroDuration(macros.elapsed)}
                            </span>
                        </li>
                    }
                    {visible.map(({ macro, index }) => {
                        const playing = macros.playingIndex === index;
                        const name = macro.name
                            || nls.localize('vueport/macros/thisMacro', 'this macro');
                        return <li
                            key={index}
                            className={'vp-panel-row vp-macros-row' + (playing ? ' playing' : '')}
                            // The whole card plays the macro, the way a cheat's
                            // card switches the cheat: it is the one thing a card
                            // is for. The buttons inside stop the click reaching
                            // here — the pencil because it means something else,
                            // the play button because it would otherwise fire
                            // twice and land back where it started.
                            onClick={() => macros.play(index)}
                        >
                            {/* At the head of the row, where a cheat's switch sits:
                                the row's own action, reachable without reading. */}
                            <button
                                type='button'
                                aria-pressed={playing}
                                aria-label={playing
                                    ? nls.localize('vueport/macros/stopNamedMacro', 'Stop {0}', name)
                                    : nls.localize('vueport/macros/playNamedMacro', 'Play {0}', name)}
                                className='vp-macros-play'
                                onClick={e => {
                                    e.stopPropagation();
                                    macros.play(index);
                                }}
                            >
                                {playing
                                    ? <Stop size={14} weight='fill' />
                                    : <Play size={14} weight='fill' />
                                }
                            </button>
                            {/* The card's two lines, in a column of their own:
                                the row itself is what puts the controls at the far
                                end, and it can only do that for one child. */}
                            <span className='vp-macros-summary'>
                                <span className='vp-panel-row-name'>
                                    {macro.name}
                                    <span className='vp-macros-meta'>
                                        {playing
                                            ? formatMacroDuration(macros.elapsed)
                                            : formatMacroDuration(macro.duration)}
                                        {macro.loop && <Repeat size={14} />}
                                        {macro.slot !== undefined && <SlotBadge slot={macro.slot} />}
                                        {/* Which of these rows are not this
                                            game's. Beside the repeat mark
                                            rather than in front of the name:
                                            the name is what the eye is
                                            scanning for, and where a macro is
                                            kept is a fact about it rather than
                                            part of what it is called. */}
                                        {macro.global && <GlobeHemisphereWest
                                            className='vp-macros-global'
                                            size={14}
                                            aria-label={nls.localize(
                                                'vueport/macros/globalMacro', 'Available in every game')}
                                        />}
                                    </span>
                                </span>
                                <span
                                    className='vp-macros-sequence'
                                    // The line is cut off rather than wrapped, so
                                    // the whole of it has to be reachable somehow.
                                    title={sequenceText(macro)}
                                >
                                    {renderSequence(macro)}
                                </span>
                            </span>
                            <button
                                type='button'
                                className='vp-panel-row-action'
                                aria-label={nls.localize('vueport/macros/editMacro', 'Edit {0}', name)}
                                onClick={e => {
                                    e.stopPropagation();
                                    setEditing(index);
                                }}
                            >
                                <PencilSimple size={18} />
                            </button>
                            <button
                                type='button'
                                className='vp-panel-row-action danger'
                                aria-label={nls.localize('vueport/macros/removeNamedMacro', 'Remove {0}', name)}
                                onClick={e => {
                                    e.stopPropagation();
                                    removeMacro(index);
                                }}
                            >
                                <X size={16} />
                            </button>
                        </li>;
                    })}
                </ul>}
        </div>
        {recordActions}
    </>;
}

/** Which slot plays a macro, as a small numbered mark beside its other marks. */
function SlotBadge(props: { slot: number }): React.JSX.Element {
    return <span
        className='vp-macros-slot'
        title={nls.localize('vueport/macros/slotBadge', 'Slot {0}', props.slot)}
    >
        {props.slot}
    </span>;
}
