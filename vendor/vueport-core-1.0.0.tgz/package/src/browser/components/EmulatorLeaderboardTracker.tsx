import { ChartBar } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { RetroAchievementsService } from '../emulator-retroachievements';

/**
 * The running leaderboard attempts' values, over the corner of the picture.
 *
 * A leaderboard attempt is the one thing RetroAchievements tracks that the
 * player has to be able to see while it happens — a timer they are racing, a
 * score they are pushing — so unlike the achievements, which can wait for the
 * panel, this belongs over the game.
 *
 * Not a button: there is nothing to open. The panel lists the same
 * leaderboards, and an attempt in progress is not the moment to send anybody
 * looking at a list.
 *
 * It subscribes to the service itself rather than being handed the values,
 * because they change many times a second while an attempt runs and nothing
 * larger than this should redraw at that rate — which is exactly why
 * `onDidChangeTrackers` is separate from `onDidChange`.
 */
export default function EmulatorLeaderboardTracker(props: {
    achievements: RetroAchievementsService,
}): React.JSX.Element | null {
    const { achievements } = props;
    const [, setVersion] = React.useState(0);

    React.useEffect(() => {
        const subscription = achievements.onDidChangeTrackers(() => setVersion(version => version + 1));
        return () => subscription.dispose();
    }, [achievements]);

    const trackers = achievements.leaderboardTrackers;
    if (trackers.length === 0) {
        return null;
    }

    // Several at once is normal — one leaderboard can be timing the level
    // while another counts what was collected in it — and each gets its own
    // pill rather than being run together into one unreadable string.
    return <>
        {trackers.map(tracker =>
            <span
                key={tracker.id}
                className='vp-screen-badge vp-leaderboard-tracker'
                aria-label={nls.localize(
                    'vueport/achievements/trackerLabel', 'Leaderboard attempt: {0}', tracker.display)}
            >
                <ChartBar size={14} weight='fill' />
                {tracker.display}
            </span>)}
    </>;
}
