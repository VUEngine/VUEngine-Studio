import { MagnifyingGlass, SlidersHorizontal, X } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import { VueportConfig } from '../../common/emulator-settings';
import { vueportSettingsSchema } from '../emulator-settings-schema';
import { Window } from './kit/Window';

/**
 * One tab of the settings window, as its host describes it.
 *
 * The window knows nothing about what settings exist or how a pane is built;
 * it is handed this list and renders a rail from it. That is what lets the two
 * hosts carry different tabs over the same window — the standalone build has
 * panes for the things an application owns (its APIs, its start page, its
 * theme, its About) that mean nothing inside an IDE.
 */
export interface SettingsTabSpec<T extends string = string> {
    id: T;
    /** Localized, and what the rail is sorted by. */
    label: string;
    icon: React.ReactNode;
    /**
     * The schema-backed settings this pane shows, so their titles and
     * descriptions feed the search index. Kept to exactly what the pane shows
     * and filters, so a query that lights this tab always leaves it with
     * something.
     */
    settings?: readonly (keyof VueportConfig)[];
    /**
     * Extra words this pane answers to. For a hand-written pane, which does not
     * filter its own rows, this is all there is to route a query to it by
     * besides its label.
     */
    keywords?: string;
    /** Sits alone at the foot of the rail, the way an application's About does. */
    foot?: boolean;
}

/** The full haystack for one pane, lower-cased. Rebuilt per call — the schema is localized. */
function haystackFor(tab: SettingsTabSpec): string {
    const schema = vueportSettingsSchema();
    const parts = [tab.label, tab.keywords ?? ''];
    for (const id of tab.settings ?? []) {
        const entry = schema[id];
        if (entry) {
            parts.push(entry.title, entry.description ?? '', (entry.enumItemLabels ?? []).join(' '));
        }
    }
    return parts.join(' ').toLowerCase();
}

/**
 * The tabs a query touches. Every tab when the query is empty.
 *
 * Every pane has its own component and its own way of laying settings out, so
 * there is no one list to filter. This is the shared half: a keyword index that
 * says which panes a query touches, so the rail can fade the ones it does not
 * and jump to one it does. The panes filter their own settings as well, and get
 * the same query passed straight through.
 */
function tabsMatching<T extends string>(tabs: SettingsTabSpec<T>[], query: string): Set<T> {
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (terms.length === 0) {
        return new Set(tabs.map(tab => tab.id));
    }
    return new Set(tabs
        .filter(tab => terms.every(term => haystackFor(tab).includes(term)))
        .map(tab => tab.id));
}

function SettingsTab<T extends string>(props: {
    tab: SettingsTabSpec<T>,
    active: boolean,
    /** A search is running and this pane has nothing that matches. */
    dimmed: boolean,
    onClick: () => void,
}): React.JSX.Element {
    return <button
        type='button'
        role='tab'
        aria-selected={props.active}
        className={'vp-settings-tab'
            + (props.active ? ' active' : '')
            + (props.dimmed ? ' is-dimmed' : '')}
        onClick={props.onClick}
    >
        {props.tab.icon}
        <span>{props.tab.label}</span>
    </button>;
}

function SettingsSearch(props: {
    value: string,
    onChange: (value: string) => void,
}): React.JSX.Element {
    const label = nls.localize('vueport/settings/search', 'Search settings');
    return <div className='vp-settings-search'>
        <MagnifyingGlass size={15} />
        <input
            type='text'
            spellCheck={false}
            value={props.value}
            placeholder={label}
            aria-label={label}
            onChange={event => props.onChange(event.target.value)}
        />
        {props.value &&
            <button
                type='button'
                className='vp-settings-search-clear'
                aria-label={nls.localize('vueport/general/clear', 'Clear')}
                onClick={() => props.onChange('')}
            >
                <X size={14} />
            </button>}
    </div>;
}

/**
 * The settings window: a titled window with a tab rail down its left and one
 * pane at a time beside it.
 *
 * Deliberately holds none of the panes' own logic — `renderPane` builds each one
 * and this only decides which is on screen. The pane that is not showing is not
 * rendered, the same as when each of these was its own window: the input mapper
 * captures keys while it is mounted, and one sitting live behind another tab has
 * no business doing that.
 */
export function SettingsWindow<T extends string>(props: {
    /** Every tab this host carries. The rail's order is computed, not this one. */
    tabs: SettingsTabSpec<T>[],
    tab: T,
    onTab: (tab: T) => void,
    onClose: () => void,
    /** One pane, built for the given tab and handed the running search query. */
    renderPane: (tab: T, search: string) => React.ReactNode,
    /**
     * Wraps the pane, for a host whose panes arrive as separately loaded chunks:
     * the window, its search and its rail stay mounted while one is on its way,
     * and an error belongs in the pane rather than in place of the whole window.
     * A host that builds its panes outright leaves this out.
     */
    paneBoundary?: (tab: T, pane: React.ReactNode) => React.ReactNode,
}): React.JSX.Element {
    const { tabs, tab, onTab, onClose, renderPane, paneBoundary } = props;
    const [search, setSearch] = React.useState('');
    const query = search.trim();
    const matching = tabsMatching(tabs, query);

    /*
     * The rail, alphabetically by the label each tab shows. By label rather than
     * by identifier because the label is the only part a reader can scan:
     * sorting the identifiers would file Achievements under `retroachievements`,
     * and a fixed order would be alphabetical in English alone.
     */
    const inOrder = tabs.filter(entry => !entry.foot)
        .sort((a, b) => a.label.localeCompare(b.label));
    const atFoot = tabs.filter(entry => entry.foot);

    /*
     * A search that leaves the open pane with nothing takes the person to the
     * first pane that does have a match, so a query is never a dead end.
     *
     * `onTab` is read through a ref rather than depended on. A caller hands a
     * fresh arrow every render and that arrow usually asks the host to redraw —
     * so depending on it would run this effect on every render, and one that
     * moves the tab would then cause the render that runs it again.
     */
    const changeTab = React.useRef(onTab);
    changeTab.current = onTab;
    const firstMatch = [...inOrder, ...atFoot].find(entry => matching.has(entry.id))?.id;
    const missed = query !== '' && !matching.has(tab);
    React.useEffect(() => {
        if (missed && firstMatch !== undefined) {
            changeTab.current(firstMatch);
        }
    }, [missed, firstMatch]);

    const railTab = (entry: SettingsTabSpec<T>): React.JSX.Element =>
        <SettingsTab
            key={entry.id}
            tab={entry}
            active={entry.id === tab}
            dimmed={query !== '' && entry.id !== tab && !matching.has(entry.id)}
            onClick={() => onTab(entry.id)}
        />;

    const pane = renderPane(tab, query);

    return <Window
        title={nls.localize('vueport/settings/title', 'Settings')}
        icon={<SlidersHorizontal size={22} />}
        onClose={onClose}
        large
        headerActions={<SettingsSearch value={search} onChange={setSearch} />}
        sidebar={
            <div className='vp-settings-tabs' role='tablist' aria-orientation='vertical'>
                {inOrder.map(railTab)}
                {atFoot.length > 0 &&
                    <div className='vp-settings-tabs-foot'>{atFoot.map(railTab)}</div>}
            </div>
        }
    >
        {paneBoundary ? paneBoundary(tab, pane) : pane}
    </Window>;
}
