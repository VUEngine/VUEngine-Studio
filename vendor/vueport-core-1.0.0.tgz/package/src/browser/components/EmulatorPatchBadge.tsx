import { Bandaids } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';

/**
 * How many ROM patches are on, over the corner of the picture.
 *
 * The cheats' badge, for the cheats' reason: a patch changes what the game
 * is, and one switched on weeks ago — a debug menu, a save hack, a level
 * select — is easy to forget until the game behaves like nothing anybody
 * remembers. The colorizations are not counted: they are listed among the
 * patches, but a game in color says so by itself.
 *
 * A button, because the obvious thing to want after noticing it is to see
 * which ones.
 */
export default function EmulatorPatchBadge(props: {
    count: number,
    onShow: () => void,
}): React.JSX.Element {
    const { count, onShow } = props;
    return <button
        type='button'
        className='vp-screen-badge vp-patch-badge'
        aria-label={nls.localize('vueport/patches/activeBadge',
            '{0} patches are on. Show them.', count)}
        onClick={onShow}
    >
        <Bandaids size={16} weight='fill' />
        {count}
    </button>;
}
