import { MagnifyingGlass, X } from '@phosphor-icons/react';
import React from 'react';
import { nls } from '../../../common/emulator-nls';

interface PanelFilterProps {
    value: string;
    onChange(value: string): void;
    // replaces the plain "Filter" in the box and on the label, e.g. "Filter classes"
    placeholder?: string;
    // readout between the text and the clear button, e.g. how much of a long list is left
    status?: React.ReactNode;
    // marks the box when the text matches nothing
    missed?: boolean;
}

// the filter box between a panel's heading and its rows. Shares the markup of `.vp-panel-filter`
// (clear button only with text, screen reader label), which every list used to write by hand
export default function PanelFilter({
    value, onChange, placeholder, status, missed,
}: PanelFilterProps): React.JSX.Element {
    const label = placeholder ?? nls.localize('vueport/general/filter', 'Filter');
    return <div className={`vp-panel-filter${missed ? ' missed' : ''}`}>
        <MagnifyingGlass size={15} />
        <input
            type='text'
            spellCheck={false}
            value={value}
            placeholder={label}
            aria-label={label}
            onChange={event => onChange(event.target.value)}
        />
        {status}
        {value &&
            <button
                type='button'
                className='vp-panel-filter-clear'
                aria-label={nls.localize('vueport/general/clear', 'Clear')}
                onClick={() => onChange('')}
            >
                <X size={14} />
            </button>}
    </div>;
}
