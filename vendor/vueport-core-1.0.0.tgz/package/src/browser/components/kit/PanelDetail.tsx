import { ArrowLeft, CaretLeft, CaretRight } from '@phosphor-icons/react';
import React from 'react';
import { nls } from '../../../common/emulator-nls';

/*
 * The pieces a list panel's detail view is built from.
 *
 * The cheats, the macros and the patches each open one entry of their list
 * onto the whole panel, and each used to dress it as an inspector — a framed
 * group with a legend, a grid of label-and-field pairs and a checkbox. That is
 * the shape of a register dump, not of one thing somebody picked out of a list
 * to look at. These give the three of them one shape instead: the way back
 * and along at the top, the thing itself as a heading with its switch, its
 * parts in titled sections, and what can be done to it as a whole at the foot.
 */

/**
 * Back to the list, and on to the entry before or after this one.
 *
 * The back button carries the list's name rather than "Back To List": it is
 * the only thing that says which panel this is in the strip beside the screen,
 * where there is no tab to say it. Stepping along is for going through a list
 * of shipped cheats or patches one after another without the round trip.
 */
export function PanelDetailToolbar(props: {
    /** What the list is called — "Cheats". */
    list: string,
    index: number,
    count: number,
    onBack: () => void,
    onStep: (index: number) => void,
}): React.JSX.Element {
    const { list, index, count, onBack, onStep } = props;
    return <div className='vp-panel-toolbar vp-detail-toolbar'>
        <button
            type='button'
            className='vp-panel-back'
            title={nls.localize('vueport/general/backToList', 'Back To List')}
            onClick={onBack}
        >
            <ArrowLeft size={18} />
            {list}
        </button>
        {count > 1 && <div className='vp-detail-pager'>
            <button
                type='button'
                aria-label={nls.localize('vueport/general/previous', 'Previous')}
                disabled={index <= 0}
                onClick={() => onStep(index - 1)}
            >
                <CaretLeft size={16} />
            </button>
            <span>{nls.localize('vueport/general/position', '{0} of {1}', index + 1, count)}</span>
            <button
                type='button'
                aria-label={nls.localize('vueport/general/next', 'Next')}
                disabled={index >= count - 1}
                onClick={() => onStep(index + 1)}
            >
                <CaretRight size={16} />
            </button>
        </div>}
    </div>;
}

/**
 * The entry as a heading: what kind of thing it is, its name, a line of what
 * is known about it, and the one control that is its reason to exist — the
 * switch of a cheat or a patch, the play button of a macro.
 *
 * The name is typed into where it is read, rather than into a "Name" field
 * further down: renaming is the commonest edit, and a heading that is also the
 * field is one place to look rather than two. A name that is not the player's
 * to change is plain text.
 */
export function PanelDetailHero(props: {
    icon: React.ReactNode,
    name: string,
    /** How a name that cannot be renamed is shown, where that is more than its text. */
    title?: React.ReactNode,
    onRename?: (name: string) => void,
    meta?: React.ReactNode,
    badges?: React.ReactNode,
    control?: React.ReactNode,
}): React.JSX.Element {
    const { icon, name, title, onRename, meta, badges, control } = props;
    return <div className='vp-detail-hero'>
        <div className='vp-detail-hero-main'>
            <span className='vp-detail-hero-icon' aria-hidden='true'>{icon}</span>
            <div className='vp-detail-hero-text'>
                {onRename
                    ? <input
                        className='vp-detail-hero-name'
                        value={name}
                        spellCheck={false}
                        aria-label={nls.localize('vueport/general/name', 'Name')}
                        onChange={event => onRename(event.target.value)}
                    />
                    : <span className='vp-detail-hero-name'>{title ?? name}</span>}
                {meta && <span className='vp-detail-hero-meta'>{meta}</span>}
            </div>
            {control}
        </div>
        {badges && <div className='vp-detail-badges'>{badges}</div>}
    </div>;
}

/** One pill under the heading. */
export function PanelDetailBadge(props: {
    icon?: React.ReactNode,
    children: React.ReactNode,
}): React.JSX.Element {
    return <span className='vp-detail-badge'>
        {props.icon}
        {props.children}
    </span>;
}

/**
 * One part of the entry, under a small title.
 *
 * The title is the label of the field below when the section is just one
 * field — `htmlFor` — so the field is named without a second label beside it.
 */
export function PanelDetailSection(props: {
    title: string,
    htmlFor?: string,
    /** At the far end of the title row — a count, or a unit. */
    aside?: React.ReactNode,
    children: React.ReactNode,
}): React.JSX.Element {
    const { title, htmlFor, aside, children } = props;
    return <section className='vp-detail-section'>
        <div className='vp-detail-section-head'>
            {htmlFor
                ? <label className='vp-detail-section-title' htmlFor={htmlFor}>{title}</label>
                : <h3 className='vp-detail-section-title'>{title}</h3>}
            {aside && <span className='vp-detail-section-aside'>{aside}</span>}
        </div>
        {children}
    </section>;
}

/**
 * Facts about the entry that are read rather than edited — its file, its
 * format, its version — as a two-column sheet. Rows without a value are left
 * out, so a caller can list everything it might know.
 */
export function PanelDetailFacts(props: {
    rows: Array<[label: string, value: React.ReactNode | undefined, code?: boolean]>,
}): React.JSX.Element {
    return <dl className='vp-detail-facts'>
        {props.rows
            .filter(([, value]) => value !== undefined && value !== '')
            .map(([label, value, code]) => <React.Fragment key={label}>
                <dt>{label}</dt>
                <dd className={code ? 'code' : undefined}>{value}</dd>
            </React.Fragment>)}
    </dl>;
}

/**
 * The foot of the view: a line about the entry as a whole, and what can be
 * done to it — taking it away, mostly. Pushed to the bottom of the panel, away
 * from the switch at the top, so that the one thing here that cannot be undone
 * is never next to the one that is pressed all the time.
 */
export function PanelDetailFooter(props: {
    hint?: React.ReactNode,
    children?: React.ReactNode,
}): React.JSX.Element {
    return <div className='vp-detail-footer'>
        <span className='vp-detail-footer-hint'>{props.hint}</span>
        {props.children}
    </div>;
}
