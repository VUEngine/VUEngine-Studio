import React from 'react';
import { createPortal } from 'react-dom';
import type { ColorResult } from 'react-color';
import styled from 'styled-components';
import { pushEscapeLayer } from './escape-layers';

/**
 * `react-color` is loaded when a picker is first opened, not when the page is.
 *
 * It is the largest dependency the interface has — the library plus its color
 * maths is about ninety kilobytes — and it is reachable only from a color
 * well, which is settings-and-palettes furniture that most sessions never
 * touch. Behind a dynamic import it becomes a chunk of its own, and the cost
 * lands on the click that needs it rather than on every start.
 */
const ChromePicker = React.lazy(async () => ({
    default: (await import('react-color')).ChromePicker,
}));

/**
 * A color well that opens `react-color`'s Chrome picker rather than the
 * browser's native `<input type="color">`.
 *
 * The picker is a floating panel: rendered into `document.body` and placed
 * against the well with fixed coordinates, so it is never clipped by the
 * scrolling dialog it is used in. A transparent cover behind it closes it on
 * an outside click; Escape closes it too.
 */
/*
 * `$large` rather than `large`: styled-components hands anything else straight
 * to the DOM, and `<button large="true">` is not an attribute — React drops it
 * with a warning on the console. The `$` marks it as the component's own.
 */
const Well = styled.button<{ $large?: boolean }>`
    background: var(--vp-bg);
    border: var(--vp-border-width) solid var(--vp-control);
    border-radius: var(--vp-radius-large);
    box-sizing: border-box;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    height: ${p => p.$large ? '112px' : '30px'};
    padding: ${p => p.$large ? 'var(--vp-space)' : '2px'};
    gap: var(--vp-space);
    width: ${p => p.$large ? '128px' : '56px'};

    &:disabled {
        cursor: default;
        opacity: 0.5;
    }

    &:not(:disabled):hover,
    &:not(:disabled):focus-visible {
        border-color: var(--vp-accent);
        outline: none;
    }
`;

/* The color, inset so the well's own border still reads as the frame. */
const Fill = styled.span`
    border-radius: var(--vp-radius);
    display: block;
    height: 100%;
    width: 100%;
`;

const Cover = styled.div`
    inset: 0;
    position: fixed;
    z-index: 10000;
`;

/*
 * `react-color` paints the Chrome picker with a fixed light palette through
 * inline styles. Restating the surfaces, text and borders with the kit's
 * tokens — over `!important`, since inline styles are what is being beaten —
 * makes it follow the theme like everything else. Only the color areas
 * themselves (the saturation square, the hue strip) are left alone: those are
 * the color, not chrome.
 */
const Popover = styled.div`
    position: fixed;
    z-index: 10001;

    .chrome-picker {
        background: var(--vp-panel) !important;
        border: 1px solid var(--vp-line) !important;
        border-radius: var(--vp-radius-large) !important;
        box-shadow: 0 4px 16px var(--vp-shadow) !important;
        font-family: var(--vp-font-ui) !important;
    }

    /* The HEX / R / G / B entry fields. */
    .chrome-picker input {
        background: var(--vp-bg) !important;
        box-shadow: inset 0 0 0 1px var(--vp-control) !important;
        color: var(--vp-text) !important;
    }

    /* Their captions, and the mode toggle's chevron. */
    .chrome-picker span {
        color: var(--vp-text-dim) !important;
    }

    .chrome-picker svg {
        fill: var(--vp-text-dim) !important;
    }

    .chrome-picker svg:hover {
        background: var(--vp-hover) !important;
    }
`;

const PICKER_WIDTH = 225;
const PICKER_HEIGHT = 270;
const GAP = 4;

/**
 * How still the picker has to be before a color is passed on, and how long a
 * drag may run without one.
 *
 * `react-color` reports every pointer move, and what a well is wired to is not
 * free: the color editor writes each one into the running game across the
 * worker. Sixty of those a second arrive faster than they can be done, and the
 * picker ends up dragging a queue behind it. So a color is passed on once the
 * pointer settles — and, while it refuses to, at least every `PREVIEW_MAX_MS`,
 * so a long sweep is still live rather than a jump at the end.
 */
const PREVIEW_MS = 90;
const PREVIEW_MAX_MS = 220;

/**
 * The same for the settled color, which is stored rather than shown.
 *
 * Longer, and with no ceiling: one write per gesture is the point of it, and
 * until the gesture ends the preview is what is on screen anyway. Released at
 * once when the picker closes, so nothing is left waiting on a timer whose
 * reason has gone away.
 */
const COMMIT_MS = 250;

/** A color waiting to be passed on, with the means to hurry or drop it. */
interface Settled {
    (hex: string): void;
    /** Pass a waiting color on now. */
    flush(): void;
    /** Drop one. */
    cancel(): void;
}

/**
 * Call `fn` with the last color once `wait` has gone by without a newer one
 * and — where a `most` is given — no less often than that while they keep
 * coming.
 *
 * `Utils.debounce` is the same idea without the ceiling, which is the half a
 * picker needs: a drag that never pauses would otherwise show nothing at all
 * until it ended. The *current* `fn` is called rather than the one this was
 * made with, so a handler closing over fresh props is not held to the render
 * that created it.
 */
function useSettled(
    fn: ((hex: string) => void) | undefined,
    wait: number,
    most?: number,
): Settled {
    const call = React.useRef(fn);
    call.current = fn;

    return React.useMemo<Settled>(() => {
        let timer: ReturnType<typeof setTimeout> | undefined;
        let since = 0;
        let waiting: string | undefined;

        const send = (): void => {
            if (timer !== undefined) {
                clearTimeout(timer);
                timer = undefined;
            }
            const hex = waiting;
            waiting = undefined;
            since = 0;
            if (hex !== undefined) {
                call.current?.(hex);
            }
        };

        const push = ((hex: string) => {
            const now = Date.now();
            waiting = hex;
            if (since === 0) {
                since = now;
            }
            if (most !== undefined && now - since >= most) {
                send();
                return;
            }
            if (timer !== undefined) {
                clearTimeout(timer);
            }
            timer = setTimeout(send, most === undefined
                ? wait
                : Math.min(wait, since + most - now));
        }) as Settled;

        push.flush = send;
        push.cancel = () => {
            if (timer !== undefined) {
                clearTimeout(timer);
                timer = undefined;
            }
            waiting = undefined;
            since = 0;
        };
        return push;
    }, [wait, most]);
}

interface ColorFieldProps {
    /** The current color as `#rrggbb`. */
    value: string;
    /**
     * The settled color: once the picker has come to rest, or at once when it
     * closes. Not one per pointer move — see `COMMIT_MS`.
     */
    onChange: (hex: string) => void;
    /**
     * The color while the picker is dragged. Optional — for a live preview.
     * Several a second rather than every move (see `PREVIEW_MS`), but still
     * not a place to persist.
     */
    onPreview?: (hex: string) => void;
    disabled?: boolean;
    large?: boolean;
    /** Names the well for a screen reader, and titles it on hover. */
    title?: string;
}

export default function ColorField(props: ColorFieldProps): React.JSX.Element {
    const { value, onChange, onPreview, disabled, large, title } = props;
    const [open, setOpen] = React.useState(false);
    const [at, setAt] = React.useState<{ top: number, left: number }>();
    /**
     * The color being chosen, while it is being chosen.
     *
     * `react-color` looks like it holds its own, and does not: `ColorWrap`
     * derives its whole state from the `color` prop on *every* render. So the
     * picker only ever shows what it is given back, and a color held back
     * while the outward calls settle would be a handle snapping out from under
     * the pointer. The draft is that answer, given at once and for free —
     * nothing outside this component re-renders for it.
     *
     * It lasts as long as the picker is open. While it is, nothing else can
     * change the color anyway: the cover behind it takes the first click.
     */
    const [draft, setDraft] = React.useState<string>();
    const wellRef = React.useRef<HTMLButtonElement>(null);

    const safe = /^#[0-9a-fA-F]{6}$/.test(value) ? value : '#000000';
    const shown = draft ?? safe;

    const preview = useSettled(onPreview, PREVIEW_MS, PREVIEW_MAX_MS);
    const commit = useSettled(onChange, COMMIT_MS);

    const place = React.useCallback(() => {
        const rect = wellRef.current?.getBoundingClientRect();
        if (!rect) {
            return;
        }
        const left = Math.max(GAP, Math.min(
            rect.left, window.innerWidth - PICKER_WIDTH - GAP));
        const below = rect.bottom + GAP;
        const top = below + PICKER_HEIGHT > window.innerHeight - GAP
            ? Math.max(GAP, rect.top - GAP - PICKER_HEIGHT)
            : below;
        setAt({ top, left });
    }, []);

    React.useLayoutEffect(() => {
        if (open) {
            place();
        }
    }, [open, place]);

    React.useEffect(() => {
        if (!open) {
            return undefined;
        }
        // A layer of its own so one Escape closes the picker and leaves the
        // window it sits in open — see `escape-layers`.
        const layer = pushEscapeLayer();
        const onKey = (event: KeyboardEvent) => {
            if (event.key === 'Escape' && layer.isTop()) {
                event.stopPropagation();
                setOpen(false);
            }
        };
        window.addEventListener('keydown', onKey, true);
        window.addEventListener('resize', place);
        // A scroll anywhere between the well and the viewport moves the well.
        window.addEventListener('scroll', place, true);
        return () => {
            layer.dispose();
            window.removeEventListener('keydown', onKey, true);
            window.removeEventListener('resize', place);
            window.removeEventListener('scroll', place, true);
        };
    }, [open, place]);

    /*
     * Closed: the color in hand is the one that was left behind, so it is
     * passed on at once rather than waiting out a timer that was only ever
     * there to spare a drag. The preview goes the other way — the settled
     * color supersedes it — and the draft with it, so from here the well
     * shows what was actually stored, snapped to what the hardware can show.
     */
    React.useEffect(() => {
        if (!open) {
            preview.cancel();
            commit.flush();
            setDraft(undefined);
        }
    }, [open, preview, commit]);

    /* And the same for a well that goes away with a color still in hand. */
    React.useEffect(() => () => {
        preview.cancel();
        commit.flush();
    }, [preview, commit]);

    return <>
        <Well
            ref={wellRef}
            type='button'
            disabled={disabled}
            $large={large}
            aria-label={title}
            aria-haspopup='dialog'
            aria-expanded={open}
            title={title}
            onClick={() => !disabled && setOpen(current => !current)}
        >
            <Fill style={{ background: shown }} />
            {large && <>{shown.toUpperCase()}</>}
        </Well>
        {open && at && createPortal(
            <>
                <Cover onClick={() => setOpen(false)} />
                <Popover style={at} onKeyDown={e => e.stopPropagation()}>
                    {/*
                      * No fallback: the chunk is a same-origin file that is
                      * already in the browser's cache after the first open, so
                      * a spinner would be a flash of furniture in the common
                      * case. The cover behind it is up either way, so the
                      * well reads as open while the picker arrives.
                      */}
                    <React.Suspense fallback={null}>
                        <ChromePicker
                            color={shown}
                            disableAlpha
                            /*
                             * One handler, not `onChange` and
                             * `onChangeComplete`: the second is the first
                             * behind a hundred-millisecond debounce of
                             * `react-color`'s own, which during a drag means
                             * ten stores a second — each one a settings write
                             * and a re-render of every swatch in the panel
                             * that holds this well. The settling here is the
                             * same idea, told what it is for.
                             */
                            onChange={(result: ColorResult) => {
                                setDraft(result.hex);
                                preview(result.hex);
                                commit(result.hex);
                            }}
                        />
                    </React.Suspense>
                </Popover>
            </>,
            document.body,
        )}
    </>;
}
