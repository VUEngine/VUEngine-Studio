import { CaretDown } from '@phosphor-icons/react';
import React, { ReactElement, ReactNode } from 'react';
import Dropdown, { DropdownEntry, Option } from 'react-dropdown';

/**
 * A dropdown, in the shape the rest of these controls are in.
 *
 * The native `<select>` it replaces was the one control the browser drew
 * itself: its own font, its own arrow, its own list, and on every platform a
 * different one. Everything around it — the fields, the buttons, the segmented
 * switches — is the application's, so the odd one out read as a seam. This
 * wraps `react-dropdown`, which brings the behaviour (a real listbox, the
 * arrow keys, Home/End, Escape, type-ahead-free but focus-correct) and leaves
 * the drawing to `.vp-dropdown-*` in the stylesheet.
 *
 * Two ways to carry an icon:
 *
 *   - {@link SelectProps.icon} sits in the control and never moves — what the
 *     dropdown is FOR rather than what is chosen in it. Worth having only
 *     while the icon says nothing the control's own choice says: the library's
 *     sort dropdown gave its sort icon up to a button beside it the moment the
 *     direction became something to click.
 *   - {@link SelectOption.icon} belongs to one choice, and so appears both in
 *     the menu row and in the control once that row is the chosen one.
 */
export interface SelectOption {
    value: string;
    label: ReactNode;
    /** Shown before the label, in the menu and in the control alike. */
    icon?: ReactElement;
    disabled?: boolean;
}

/** Choices under a heading — what `<optgroup>` was. */
export interface SelectGroup {
    group: ReactNode;
    options: SelectOption[];
}

export type SelectEntry = SelectOption | SelectGroup;

export interface SelectProps {
    options: SelectEntry[];
    value: string;
    onChange: (value: string) => void;
    /** The control's own icon, before whatever is chosen. */
    icon?: ReactElement;
    /** Said while nothing is chosen. */
    placeholder?: ReactNode;
    disabled?: boolean;
    /** What the choice is about, for a screen reader. */
    label?: string;
    /** The hover title, for a control whose name is not beside it. */
    title?: string;
    size?: 'small' | 'large';
    /**
     * How wide the menu is drawn.
     *
     * `control` — the default — makes it exactly as wide as the control, which
     * is what a dropdown that fills its row wants: the menu is the field, open.
     * `content` sizes it to the longest row instead, for a control narrower
     * than what is in it — a pill sized to the word `Type` has a menu saying
     * `Technical demos`, and a menu clipped to the pill would be four
     * ellipses.
     */
    menuWidth?: 'control' | 'content';
    className?: string;
    style?: React.CSSProperties;
}

/** How little room below is still worth opening downwards into. */
const MIN_MENU_HEIGHT = 120;
const MENU_GAP = 2;

export default function Select(props: SelectProps): React.JSX.Element {
    const { options, value, onChange, icon, disabled } = props;
    const root = React.useRef<HTMLDivElement>(null);
    const [open, setOpen] = React.useState(false);

    /*
     * The menu is placed in the window's own coordinates while it is open.
     *
     * `react-dropdown` puts it under the control in the flow, which a panel
     * that scrolls — the inspectors, a settings pane, the dialog — would clip
     * at its own edge. Fixed coordinates escape that the way the color well's
     * picker does, and the menu stays a child of the control all the same, so
     * the outside-click and the keyboard go on working. It flips above the
     * control when there is more room there, which is what a dropdown at the
     * foot of a panel needs.
     */
    React.useLayoutEffect(() => {
        const control = root.current?.querySelector<HTMLElement>('.vp-dropdown-control');
        const menu = root.current?.querySelector<HTMLElement>('.vp-dropdown-menu');
        if (!open || !control || !menu) {
            return undefined;
        }
        const place = (): void => {
            const box = control.getBoundingClientRect();
            const below = window.innerHeight - box.bottom - MENU_GAP * 2;
            const above = box.top - MENU_GAP * 2;
            const flip = below < Math.min(menu.scrollHeight, MIN_MENU_HEIGHT) && above > below;
            menu.style.position = 'fixed';
            menu.style.left = `${box.left}px`;
            menu.style.right = 'auto';
            if (props.menuWidth === 'content') {
                // As wide as its longest row, never narrower than the control
                // it hangs off, and never past the right edge of the window.
                menu.style.width = 'max-content';
                menu.style.minWidth = `${box.width}px`;
                menu.style.maxWidth = `${Math.max(box.width, window.innerWidth - box.left - MENU_GAP * 2)}px`;
            } else {
                menu.style.width = `${box.width}px`;
                // The stylesheet's `min-width: 100%` is the control's width
                // while the menu sits in the flow; once it is fixed, that 100%
                // is the window's, which would stretch it from edge to edge.
                menu.style.minWidth = '0';
            }
            menu.style.maxHeight = `${Math.max(MIN_MENU_HEIGHT, flip ? above : below)}px`;
            menu.style.top = flip ? 'auto' : `${box.bottom + MENU_GAP}px`;
            menu.style.bottom = flip ? `${window.innerHeight - box.top + MENU_GAP}px` : 'auto';
        };
        place();
        // Capture, so a scroll in any panel between here and the window moves
        // the menu with the control rather than leaving it behind.
        window.addEventListener('scroll', place, true);
        window.addEventListener('resize', place);
        return () => {
            window.removeEventListener('scroll', place, true);
            window.removeEventListener('resize', place);
        };
    }, [open, options, props.menuWidth]);

    // An option's own icon travels with its label, which is what puts it in
    // the control as well as in the menu — `react-dropdown` draws the chosen
    // option's label in both places.
    const toOption = (option: SelectOption): Option => ({
        value: option.value,
        label: option.icon
            ? <span className='vp-dropdown-item'>{option.icon}{option.label}</span>
            : option.label,
        disabled: option.disabled,
        // The value on the row itself. A menu row is a `<li>` with a label in
        // it and nothing else to go on, so this is what lets anything outside
        // — a test, above all — say which row it means.
        data: { value: option.value },
    });
    const entries: DropdownEntry[] = options.map(entry => ('group' in entry
        ? { type: 'group' as const, name: entry.group, items: entry.options.map(toOption) }
        : toOption(entry)));

    const classes = ['vp-dropdown'];
    if (props.size) {
        classes.push(props.size);
    }
    if (icon) {
        classes.push('with-icon');
    }
    if (props.className) {
        classes.push(props.className);
    }

    return <div ref={root} className={classes.join(' ')} style={props.style} title={props.title}>
        {icon && <span className='vp-dropdown-icon' aria-hidden='true'>{icon}</span>}
        <Dropdown
            baseClassName='vp-dropdown'
            options={entries}
            value={value}
            disabled={disabled}
            placeholder={props.placeholder}
            aria-label={props.label}
            onChange={option => onChange(String(option.value))}
            onOpenChange={setOpen}
            // One caret, pointing the same way open or shut: it says where the
            // menu comes from, and a flipping arrow says it twice — the menu
            // itself is the more obvious half of that message.
            arrowClosed={<CaretDown size={14} />}
            arrowOpen={<CaretDown size={14} />}
        />
    </div>;
}
