import { Bandaids, Plus } from '@phosphor-icons/react';
import React, { ReactElement } from 'react';
import styled from 'styled-components';
import { nls } from '../../../common/emulator-nls';

/*
 * The row of calls to action. One is the common case and sits alone; a screen
 * that genuinely offers a choice — the library with nothing in it yet, which
 * can be pointed at a folder, handed a single ROM, or sent to the catalog —
 * puts them side by side rather than making two of the three disappear.
 */
const StyledActions = styled.div`
    display: flex;
    flex-wrap: wrap;
    gap: var(--vp-space);
    justify-content: center;
    margin-top: 20px;
`;

const StyledContainer = styled.div`
    align-items: center;
    color: var(--vp-text-dim);
    display: flex;
    flex-direction: column;
    flex-grow: 1;
    gap: var(--vp-space);
    inset: 0;
    justify-content: center;
    padding: var(--vp-space-x2);
    position: absolute;
    text-align: center;

    /* The icon is the quietest thing here; the title carries the weight. */
    > svg:first-child { color: var(--vp-field-border); }
`;

/** One of the buttons at the foot of an empty state. */
export interface EmptyContainerAction {
    label: string;
    /** The button's own icon; a plus when nothing is given. */
    icon?: ReactElement;
    /** A font glyph instead, for a host that ships an icon font. */
    iconCls?: string;
    /** Draw it as the one being asked for rather than as an alternative. */
    primary?: boolean;
    /** Offered but not available — a folder picker this browser has not got. */
    disabled?: boolean;
    onClick: () => void;
}

interface EmptyContainerProps {
    title: string;
    description?: string;
    icon?: ReactElement;
    buttonIconCls?: string;
    /**
     * The button's own icon, for a container whose call to action is not
     * "add" — recording a macro, say.
     *
     * Takes precedence over `buttonIconCls`, which names a font glyph: an
     * element works in a host that ships no icon font, which the standalone
     * build does not.
     */
    buttonIcon?: ReactElement;
    buttonLabel?: string;
    onClick?: () => void
    /**
     * Several calls to action rather than one.
     *
     * Takes precedence over `buttonLabel` and friends, which stay for the many
     * screens that offer exactly one thing.
     */
    actions?: EmptyContainerAction[];
}

export default function EmptyContainer(props: EmptyContainerProps): React.JSX.Element {
    const { title, description, icon, buttonIconCls, buttonIcon, buttonLabel, onClick } = props;

    // The single-button props are one action spelled the long way, so they
    // become one and the rest of this only knows about a list.
    const actions: EmptyContainerAction[] = props.actions
        ?? (onClick
            ? [{
                label: buttonLabel ?? nls.localize('vueport/general/add', 'Add'),
                icon: buttonIcon,
                iconCls: buttonIconCls,
                onClick,
            }]
            : []);

    return <StyledContainer>
        {icon ? icon : <Bandaids size={32} />}
        <div
            style={{
                color: 'var(--vp-text)',
                fontSize: '130%',
                fontWeight: 600,
            }}
        >
            {title}
        </div>
        {description &&
            <div
                style={{
                    maxWidth: 460,
                    textAlign: 'center',
                }}
            >
                {description}
            </div>
        }
        {actions.length > 0 &&
            <StyledActions>
                {actions.map((action, index) =>
                    <button
                        key={`empty-container-action-${index}`}
                        className={`vp-button large${action.primary ? '' : ' secondary'}`}
                        disabled={action.disabled}
                        onClick={action.onClick}
                    >
                        {action.icon
                            ?? (action.iconCls
                                ? <i className={action.iconCls} />
                                : <Plus size={16} />)
                        }
                        {action.label}
                    </button>
                )}
            </StyledActions>
        }
    </StyledContainer>;
}
