import type { VueportHover } from './KitContext';

/**
 * The hover used by hosts that do not bring one of their own.
 *
 * VES answers `VueportHover` with the studio's own hover service, which places
 * and paints the popup itself. Nothing else in this repository does, so every
 * `show` outside the studio used to reach a no-op and no explanation ever
 * appeared. This is deliberately small — one element reused for every hover,
 * positioned against the control it explains and painted from the same theme
 * variables as the rest of the kit.
 */

/** Gap kept between the popup and both its target and the viewport edge. */
const MARGIN = 8;

/**
 * How long the pointer must rest on a control before it is explained.
 *
 * Without a wait every control crossed on the way somewhere else flashes its
 * text, which reads as noise rather than help.
 */
const SHOW_DELAY = 500;

/** Reused across hovers: only one is ever on screen. */
let element: HTMLElement | undefined;

/** The wait in progress, if the pointer is resting on something. */
let pending: ReturnType<typeof setTimeout> | undefined;

/** Whether there is a DOM to attach to; a test or an SSR pass has none. */
function hasDocument(): boolean {
    return typeof document !== 'undefined' && !!document.body;
}

function tooltipElement(): HTMLElement {
    if (element?.isConnected) {
        return element;
    }

    element = document.createElement('div');
    element.className = 'vp-hover';
    element.setAttribute('role', 'tooltip');

    // Inline rather than in a stylesheet: this module is imported by the web
    // build and by the studio, and neither loads a sheet on this one's behalf.
    // The tokens carry their own defaults (see `vueport-tokens.css`), so the
    // literals these used to fall back on are no longer needed here.
    Object.assign(element.style, {
        position: 'fixed',
        top: '0',
        left: '0',
        zIndex: '10000',
        maxWidth: '320px',
        padding: '4px 8px',
        borderRadius: 'var(--vp-radius)',
        border: '1px solid var(--vp-line)',
        background: 'var(--vp-bg)',
        color: 'var(--vp-text)',
        fontFamily: 'var(--vp-font-ui)',
        fontSize: 'var(--vp-font-size)',
        lineHeight: 'var(--vp-line-height)',
        // A hover explains whatever the pointer is on. Letting it take the
        // pointer itself would fire the target's mouseleave and hide it again
        // the moment it appeared under the cursor.
        pointerEvents: 'none',
        visibility: 'hidden',
    });

    document.body.appendChild(element);
    return element;
}

/**
 * Puts the popup below its target, or above when the space below is too
 * short — which is what a control near the bottom of a dialog runs into.
 * Horizontally it is centered on the target, then pulled back inside the
 * viewport so a control at either edge still shows its full text.
 */
function place(popup: HTMLElement, target: HTMLElement): void {
    const anchor = target.getBoundingClientRect();
    const box = popup.getBoundingClientRect();

    const below = anchor.bottom + MARGIN;
    const above = anchor.top - MARGIN - box.height;
    const top = below + box.height > window.innerHeight && above >= 0 ? above : below;

    const centered = anchor.left + anchor.width / 2 - box.width / 2;
    const left = Math.max(MARGIN, Math.min(centered, window.innerWidth - box.width - MARGIN));

    popup.style.top = `${Math.round(top)}px`;
    popup.style.left = `${Math.round(left)}px`;
}

function present(target: HTMLElement, content: string | HTMLElement): void {
    // The wait means the pointer may already have moved on, and a toolbar
    // button can be re-rendered out of the tree while the timer runs. A
    // detached target measures as a zero box at the origin, which would put
    // the popup in the top-left corner explaining a control that is gone.
    if (!target.isConnected) {
        return;
    }

    const popup = tooltipElement();
    if (typeof content === 'string') {
        popup.textContent = content;
    } else {
        popup.replaceChildren(content);
    }

    // Measured at the origin while still hidden, so the size `place` reads
    // is the one the content actually wants and the first painted frame is
    // already in the right spot.
    popup.style.visibility = 'hidden';
    popup.style.top = '0';
    popup.style.left = '0';
    place(popup, target);
    popup.style.visibility = 'visible';
}

export const DOM_HOVER: VueportHover = {
    show(target: HTMLElement, content: string | HTMLElement): void {
        if (!hasDocument() || !content) {
            return;
        }

        // Restarted rather than kept: moving along a row of toolbar buttons
        // should ask the same question of each in turn, not show the first
        // one's text because its timer happened to be the one still running.
        clearTimeout(pending);
        pending = setTimeout(() => present(target, content), SHOW_DELAY);
    },

    hide(): void {
        clearTimeout(pending);
        pending = undefined;
        if (element) {
            element.style.visibility = 'hidden';
        }
    },
};
