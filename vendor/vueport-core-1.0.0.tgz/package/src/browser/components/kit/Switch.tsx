import * as React from 'react';

// a switch rather than a checkbox, as these settings take effect the moment they are thrown. The label is
// for screen readers only, as the visible text already sits beside or above it
export default function Switch(props: {
    label: string,
    value: boolean,
    disabled?: boolean,
    onChange: (value: boolean) => void,
}): React.JSX.Element {
    return <button
        type='button'
        role='switch'
        aria-checked={props.value}
        aria-label={props.label}
        disabled={props.disabled}
        className='vp-switch'
        onClick={() => props.onChange(!props.value)}
    >
        <span className='vp-switch-knob' />
    </button>;
}
