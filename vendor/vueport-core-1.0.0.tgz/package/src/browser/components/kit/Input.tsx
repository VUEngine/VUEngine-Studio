import { Warning, X } from '@phosphor-icons/react';
import React, { FocusEventHandler, MouseEventHandler, RefObject, useCallback, useEffect, useState } from 'react';
import styled from 'styled-components';
import { nls } from '../../../common/emulator-nls';
import InfoLabel from './InfoLabel';
import { useKit } from './KitContext';
import { clamp, debounce } from './Utils';
import VContainer from './VContainer';

interface InputProps {
    value: string | number
    setValue?: (data: string | number) => void
    type?: 'string' | 'number'
    label?: string
    tooltip?: string
    size?: 'small' | 'large'
    title?: string
    placeholder?: string
    min?: number
    max?: number
    defaultValue?: string | number
    step?: number
    disabled?: boolean
    readOnly?: boolean
    clearable?: boolean
    style?: object
    tabIndex?: number
    autoFocus?: boolean
    width?: number
    grow?: number
    id?: string
    className?: string
    onClick?: MouseEventHandler<HTMLInputElement>
    onBlur?: FocusEventHandler<HTMLInputElement>
    inputRef?: RefObject<HTMLInputElement>
}

const ClearableContainer = styled.div`
    display: inline-block;
    position: relative;

    i {
        cursor: pointer;
        display: none !important;
        position: absolute;
        right: 8px;
        top: 5px;

        &.invalid {
            color: var(--vp-accent); 
            display: block !important;
            right: 20px;
        }

        &:hover {
            color: var(--vp-accent);
        }
    }

    &:hover {
        i {
            display: inline-block !important;
        }
    }
`;

export default function Input(props: InputProps): React.JSX.Element {
    const {
        type,
        size,
        value, setValue, defaultValue,
        label, tooltip, title, placeholder,
        min, max, step,
        disabled, readOnly, clearable,
        id, className, style, width, grow,
        tabIndex, autoFocus,
        onClick, onBlur,
        inputRef,
    } = props;
    const { setCommandsEnabled } = useKit();
    const [internalValue, setInternalValue] = useState<string | number>(value ?? defaultValue);
    const [invalid, setInvalid] = useState<boolean>(false);

    const isNumeric = (v: number | string): boolean => {
        if (typeof v === 'number') {
            return true;
        }
        return !isNaN(v as unknown as number) && !isNaN(parseFloat(v));
    };

    const updateInternalValue = (iv: string | number) => {
        if (type === 'number' && isNumeric(iv as unknown as number)) {
            iv = clamp(
                Number.isInteger(step) ? parseInt(iv as string) : parseFloat(iv as string),
                Number.MIN_SAFE_INTEGER, // do not enforce min value here
                max ?? Number.MAX_SAFE_INTEGER,
                defaultValue as number ?? min ?? 0
            );
            setInternalValue(iv);
        } else {
            setInternalValue(iv);
        }

        validateAndUpdateValue(iv);
    };

    const handleOnFocus = () => {
        setCommandsEnabled(false);
    };

    const handleOnBlur = () => {
        setCommandsEnabled(true);
    };

    const validateAndUpdateValue = useCallback(debounce(
        (iv: string | number) => {
            if ((type === 'number' && isNumeric(iv) && (min === undefined || Number(iv) >= min))) {
                if (setValue) {
                    setValue(iv);
                }
                setInvalid(false);
            } else if (type !== 'number') {
                if (setValue) {
                    setValue((iv as string).trim());
                }
                setInvalid(false);
            } else {
                setInvalid(true);
            }
        },
        type === 'number' ? 250 : 500
    ), [setValue]);

    // resync if value is changed from the outside, e.g. through undo
    useEffect(() => {
        setInternalValue(value);
    }, [
        value
    ]);

    return (
        <VContainer grow={grow}>
            {label !== undefined &&
                <InfoLabel
                    label={label}
                    tooltip={tooltip}
                />
            }
            <div>
                <ClearableContainer
                    style={{
                        width: width ?? '100%',
                    }}
                >
                    <input
                        id={id}
                        ref={inputRef}
                        className={`vp-input${size ? ` ${size}` : ''}${className ? ` ${className}` : ''}`}
                        type={type}
                        min={min}
                        max={max}
                        step={step}
                        value={internalValue}
                        onChange={e => updateInternalValue(e.target.value)}
                        onFocus={handleOnFocus}
                        onBlur={e => {
                            handleOnBlur();
                            if (onBlur) {
                                onBlur(e);
                            }
                        }}
                        onClick={onClick}
                        disabled={disabled}
                        readOnly={readOnly}
                        style={{
                            boxSizing: 'border-box',
                            width: width ?? '100%',
                            ...(style ?? {})
                        }}
                        tabIndex={tabIndex}
                        autoFocus={autoFocus}
                        title={title}
                        placeholder={placeholder}
                    />
                    {clearable && !!internalValue && !disabled && !readOnly &&
                        <div
                            onClick={() => updateInternalValue(type === 'number'
                                ? (defaultValue as number ?? 0)
                                : (defaultValue as string ?? '')
                            )}
                            title={nls.localize('vueport/general/clear', 'Clear')}
                        >
                            <X size={16} />
                        </div>
                    }
                    {invalid &&
                        <div
                            className="invalid"
                            title={nls.localize('vueport/general/invalid', 'Invalid')}
                        >
                            <Warning size={20} />
                        </div>
                    }
                </ClearableContainer>
            </div>
        </VContainer>
    );
}
