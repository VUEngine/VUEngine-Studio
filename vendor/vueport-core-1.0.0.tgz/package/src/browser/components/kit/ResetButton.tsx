import { ArrowUUpLeft } from '@phosphor-icons/react';
import React from 'react';
import styled from 'styled-components';
import { nls } from '../../../common/emulator-nls';

/**
 * The button that puts a setting back the way it came.
 *
 * Styled down to an icon rather than using `vp-button`, because it belongs to
 * the setting beside it rather than standing on its own — the same weight a
 * clear or reveal affordance inside a field has. Sits next to the setting's
 * title, and disables itself (dimmed, no tooltip) when there is nothing to
 * undo.
 */
const Styled = styled.button`
    background: transparent;
    border: none;
    color: var(--vp-text);
    cursor: pointer;
    display: flex;
    margin: 0;
    min-width: unset;
    padding: 2px;

    &:disabled {
        cursor: default;
        opacity: 0.3;
    }

    &:not(:disabled):hover {
        color: var(--vp-accent);
    }
`;

export default function ResetButton(props: {
    onReset: () => void,
    /** Nothing to undo — the setting already holds its default. */
    disabled?: boolean,
    size?: number,
}): React.JSX.Element {
    return <Styled
        type='button'
        disabled={props.disabled}
        title={props.disabled
            ? undefined
            : nls.localize('vueport/general/resetToDefault', 'Reset to Default')}
        onClick={props.onReset}
    >
        <ArrowUUpLeft size={props.size ?? 16} />
    </Styled>;
}
