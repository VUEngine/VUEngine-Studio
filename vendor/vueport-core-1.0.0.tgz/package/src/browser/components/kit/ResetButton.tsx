import { ArrowUUpLeft } from '@phosphor-icons/react';
import React from 'react';
import styled from 'styled-components';
import { nls } from '../../../common/emulator-nls';

/**
 * The button that puts a setting back the way it came.
 *
 * Styled down to an icon rather than using `vp-button`, because it belongs to
 * the setting beside it rather than standing on its own — the same weight a
 * clear or reveal affordance inside a field has. Sits next to the setting's
 * title, and is only seen when there is something to undo: a column of
 * dimmed arrows beside every untouched setting said nothing, where one arrow
 * beside the one that was changed says which it is.
 *
 * Hidden rather than left out, so it keeps its place: an icon taller than the
 * title it sits by, arriving on the first change, would push everything below
 * it down by a few pixels at exactly the moment somebody is looking there.
 *
 * Dimmed itself until pointed at, and then the text colour — a quiet mark
 * beside the title rather than a call to action.
 */
const Styled = styled.button`
    background: transparent;
    border: none;
    color: var(--vp-text-dim);
    cursor: pointer;
    display: flex;
    margin: 0;
    min-width: unset;
    padding: 2px;

    &:hover,
    &:focus-visible {
        color: var(--vp-text);
    }

    &:disabled {
        visibility: hidden;
    }
`;

export default function ResetButton(props: {
    onReset: () => void,
    /** Nothing to undo — the setting already holds its default. Hides the button, keeping its place. */
    disabled?: boolean,
    size?: number,
}): React.JSX.Element {
    return <Styled
        type='button'
        disabled={props.disabled}
        aria-hidden={props.disabled}
        title={props.disabled
            ? undefined
            : nls.localize('vueport/general/resetToDefault', 'Reset to Default')}
        onClick={props.onReset}
    >
        <ArrowUUpLeft size={props.size ?? 16} />
    </Styled>;
}
