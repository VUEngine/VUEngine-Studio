/**
 * Which layer Escape belongs to.
 *
 * Layers stack: a key capture opened over the input window sits above it, and
 * one Escape should close the capture and leave the window. Both listen for
 * keys on `window` in the capture phase — they have to, so that the emulator's
 * own key handler never sees the keystroke — and `stopPropagation` does not
 * reach a listener registered on that same target, so without this each layer
 * sees every Escape and one press closes both.
 *
 * A stack rather than a flag because the nesting is open-ended, and the most
 * recently opened layer is always the one on top.
 */

export interface EscapeLayer {
    /** True while nothing has been opened over this layer. */
    isTop(): boolean;
    /** Give up the layer. Safe to call more than once. */
    dispose(): void;
}

const layers: object[] = [];

/**
 * Claim the topmost layer, until disposed.
 *
 * Removed by identity rather than by popping: React unmounts effects in an
 * order of its own, and a layer that closed while another was above it must
 * take itself out of the middle without disturbing the rest.
 */
export function pushEscapeLayer(): EscapeLayer {
    const token = {};
    layers.push(token);
    return {
        isTop: () => layers[layers.length - 1] === token,
        dispose: () => {
            const at = layers.lastIndexOf(token);
            if (at !== -1) {
                layers.splice(at, 1);
            }
        },
    };
}
