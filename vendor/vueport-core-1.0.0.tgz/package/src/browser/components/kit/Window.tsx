import * as React from 'react';
import { nls } from '../../../common/emulator-nls';
import { pushEscapeLayer } from './escape-layers';
import { X } from '@phosphor-icons/react';

/**
 * A window over the emulator: the settings, colors and input windows.
 *
 * Both hosts' now. It began as the standalone build's, because a browser has
 * no dialog system to borrow and pulling one in for three windows would have
 * been a poor trade. The studio has `PopUpDialog` and used it, which is how
 * the two ended up with the same windows wearing different clothes — so the
 * studio uses this one too, and they are one window again.
 *
 * The whole of what those windows need: a titled panel that closes.
 */
export function Window(props: {
    title: string,
    /** Shown beside the title — a caller's own icon, matching what the window is for. */
    icon: React.ReactNode,
    onClose: () => void,
    children: React.ReactNode,
    /**
     * Take the whole 90% the backdrop allows, rather than stopping at the
     * width and height that suit a form. For the controller window, which
     * draws a game pad with its assignments laid out around it.
     */
    large?: boolean,
    /**
     * Size to the content rather than taking the standard window's fixed
     * 60×45rem. For a window with a set amount to say — the game-info window,
     * not a settings screen someone browses.
     */
    compact?: boolean,
    /**
     * A column down the left of the body, outside the scroll region. For a
     * window whose body is one of several panes — the settings dialog puts its
     * tab rail here so it stays put while a pane scrolls.
     */
    sidebar?: React.ReactNode,
    /**
     * Controls in the header, between the title and the close button — the
     * settings dialog's search field sits here.
     */
    headerActions?: React.ReactNode,
}): React.JSX.Element {
    const { title, icon, onClose, children, large, compact, sidebar, headerActions } = props;

    // Read through a ref so the effect below can run once. Callers pass a
    // fresh arrow on every render, and re-running the effect would put this
    // window's layer back on top of anything opened over it.
    const close = React.useRef(onClose);
    close.current = onClose;

    React.useEffect(() => {
        const layer = pushEscapeLayer();
        const onKeyDown = (e: KeyboardEvent) => {
            // Not this window's Escape if something was opened over it — a key
            // capture, say, which has its own use for the key.
            if (e.key === 'Escape' && layer.isTop()) {
                e.stopPropagation();
                close.current();
            }
        };
        // Capture phase: the emulator's key handler is listening on the page
        // and would otherwise read Escape as a game input.
        window.addEventListener('keydown', onKeyDown, true);
        return () => {
            window.removeEventListener('keydown', onKeyDown, true);
            layer.dispose();
        };
    }, []);

    return <div className='vp-window-backdrop' onMouseDown={onClose}>
        <div
            className={'vp-window'
                + (large ? ' vp-window-large' : '')
                + (compact ? ' vp-window-compact' : '')}
            role='dialog'
            aria-modal='true'
            aria-label={title}
            onMouseDown={e => e.stopPropagation()}
        >
            <header>
                <div className='vp-window-title'>
                    {icon}
                    <h2>{title}</h2>
                </div>
                {headerActions}
                <button
                    className='vp-window-close'
                    onClick={onClose}
                    title={nls.localize('vueport/state/close', 'Close')}
                    aria-label={nls.localize('vueport/state/close', 'Close')}
                >
                    <X size={18} />
                </button>
            </header>
            <div className='vp-window-main'>
                {sidebar &&
                    <div className='vp-window-sidebar vp-scroll'>{sidebar}</div>}
                <div className='vp-window-body vp-scroll'>
                    {children}
                </div>
            </div>
        </div>
    </div>;
}
