import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';

/** The sentence every patch switch ends with, for any dialog that restarts the game. */
export const RESTART_CONFIRM = (): string => nls.localize(
    'vueport/patches/restartConfirm',
    'The emulation needs to be reset for the ROM to pick up the change. \
Anything since your last save will be lost.',
);

/**
 * Ask before switching a ROM patch on or off.
 *
 * Both ways, and for every kind of patch alike, because both cost the same: a
 * patch is applied by rebuilding the machine from the original ROM, so the
 * game restarts and anything since the last save is gone. `notes` go before
 * the shared sentence — what else the switch does, such as a color patch
 * switching another one off.
 */
export function confirmPatchRestart(
    notifications: VueportNotifications,
    enable: boolean,
    notes: string[] = [],
): Promise<boolean> {
    return notifications.confirm({
        title: enable
            ? nls.localize('vueport/patches/applyQuestion', 'Apply Patch?')
            : nls.localize('vueport/patches/disableQuestion', 'Disable Patch?'),
        message: [
            ...notes,
            RESTART_CONFIRM(),
        ],
        okLabel: enable
            ? nls.localize('vueport/vbColor/applyAndRestart', 'Apply and Restart')
            : nls.localize('vueport/patches/disableAndRestart', 'Disable and Restart'),
    });
}
