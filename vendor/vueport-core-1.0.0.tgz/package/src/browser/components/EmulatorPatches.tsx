import {
    ArrowLeft,
    Bandaids,
    Eye,
    FileArrowUp,
    MagnifyingGlass,
    PencilSimple,
    Trash,
    X,
} from '@phosphor-icons/react';
import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';
import { RomPatch, RomPatchType, ROM_PATCH_TYPES } from '../../common/emulator-rom-patches';
import { PatchStore, RomPatchMetadata } from '../emulator-patch-store';
import { VesColorPatchStatus } from '../../common/emulator-color-patches';
import { RESTART_CONFIRM, confirmPatchRestart } from './patch-restart';
import { control, field } from '../panels/emulator-vip-detail';
import EmptyContainer from './kit/EmptyContainer';
import Select from './kit/Select';

function typeLabel(type: RomPatchType): string {
    switch (type) {
        case 'hack': return nls.localize('vueport/patches/types/hack', 'Hack');
        case 'enhancement': return nls.localize('vueport/patches/types/enhancement', 'Enhancement');
        case 'debug': return nls.localize('vueport/patches/types/debug', 'Debug');
        case 'trainer': return nls.localize('vueport/patches/types/trainer', 'Trainer');
        case 'translation': return nls.localize('vueport/patches/types/translation', 'Translation');
    }
}

function colorPatchLabel(): string {
    return nls.localize('vueport/vbColor/colorPatch', 'Color Patch');
}

/** How far along a colorization is, in words. */
function colorPatchStatusLabel(status: VesColorPatchStatus): string {
    switch (status) {
        case 'complete':
            return nls.localize('vueport/vbColor/status/complete', 'Complete');
        case 'partial':
            return nls.localize('vueport/vbColor/status/partial', 'Partial');
        case 'wip':
            return nls.localize('vueport/vbColor/status/wip', 'In progress');
    }
}

export default function EmulatorPatches(props: {
    patches: PatchStore,
    notifications: VueportNotifications,
    /**
     * Make sure the VB Color hardware is on before a colorization is switched
     * on, offering to turn it on — which restarts the game — if not.
     * Resolves to whether it is on now.
     */
    ensureVbcSupport?: () => Promise<boolean>,
    onClose?: () => void,
}): React.JSX.Element {
    const { patches, notifications, ensureVbcSupport, onClose } = props;
    const importInput = React.useRef<HTMLInputElement>(null);
    const [editing, setEditing] = React.useState<number | undefined>(undefined);
    const [filter, setFilter] = React.useState('');
    const [, setVersion] = React.useState(0);

    React.useEffect(() => {
        const subscription = patches.onDidChange(() => setVersion(version => version + 1));
        return () => subscription.dispose();
    }, [patches]);

    const reportError = (patch: RomPatch, error: unknown): void =>
        notifications.error(nls.localize(
            'vueport/patches/applyFailed',
            '{0} could not be applied: {1}',
            patch.name,
            error instanceof Error ? error.message : String(error),
        ));

    /**
     * Switch a patch on or off, having said what that costs — see
     * `confirmPatchRestart`.
     *
     * A colorization asks two things more on the way on: for VB Color support,
     * since without it a colorization has nothing to draw with, and whether the
     * game's other colorization may go, since only one can be on.
     */
    const toggle = async (index: number): Promise<void> => {
        const patch = patches.list[index];
        if (!patch) {
            return;
        }
        const enable = !patch.enabled;
        if (patch.color && enable && ensureVbcSupport && !await ensureVbcSupport()) {
            return;
        }
        const replaced = patch.color && enable
            ? patches.list.find(other => other.color && other.enabled && other.id !== patch.id)
            : undefined;
        if (!await confirmPatchRestart(notifications, enable, replaced
            ? [nls.localize(
                'vueport/vbColor/applyReplaces',
                'Only one color patch can be applied at a time, so {0} is switched off.',
                replaced.name)]
            : [])) {
            return;
        }
        // Found again: the list may have moved on while the questions were
        // open, and turning VB Color on restarts the game.
        const now = patches.list.findIndex(candidate => candidate === patch
            || (patch.id !== undefined && candidate.id === patch.id));
        if (now < 0 || patches.list[now].enabled !== patch.enabled) {
            return;
        }
        try {
            patches.setEnabled(now, enable);
        } catch (error) {
            reportError(patch, error);
        }
    };

    const importFrom = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (importInput.current) {
            importInput.current.value = '';
        }
        if (!file) {
            return;
        }
        try {
            const index = patches.importPatch(file.name, new Uint8Array(await file.arrayBuffer()));
            setEditing(index);
            notifications.info(nls.localize(
                'vueport/patches/imported',
                'Imported {0}. The patch is disabled until you enable it.',
                file.name,
            ));
        } catch (error) {
            notifications.error(nls.localize(
                'vueport/patches/importFailed',
                '{0} could not be imported: {1}',
                file.name,
                error instanceof Error ? error.message : String(error),
            ));
        }
    };

    const remove = async (index: number): Promise<void> => {
        const patch = patches.list[index];
        if (!patch || patch.builtIn) {
            return;
        }
        const confirmed = await notifications.confirm({
            title: nls.localize('vueport/patches/removeQuestion', 'Remove Patch?'),
            message: [
                nls.localize(
                    'vueport/patches/removeConfirm',
                    'Are you sure you want to remove {0}?',
                    patch.name,
                ),
                // Taking an applied patch away is switching it off as well.
                ...(patch.enabled ? [RESTART_CONFIRM()] : []),
            ],
        });
        if (confirmed) {
            patches.remove(index);
            setEditing(undefined);
        }
    };

    const actions = <div className='vp-panel-actions'>
        <button className='vp-button secondary' onClick={() => importInput.current?.click()}>
            <FileArrowUp size={16} />
            {nls.localize('vueport/patches/import', 'Import Patch…')}
        </button>
        <input
            ref={importInput}
            type='file'
            accept='.ips,.ups,.bps,.bdf,.bspatch,application/octet-stream'
            hidden
            onChange={event => { importFrom(event.target.files); }}
        />
    </div>;

    const header = <div className='vp-panel-heading'>
        {onClose && <span className='vp-panel-heading-title'>
            <Bandaids size={22} />
            {nls.localize('vueport/patches/title', 'Patches')}
        </span>}
        {onClose && <button
            type='button'
            className='vp-panel-close'
            aria-label={nls.localize('vueport/patches/close', 'Close Patches')}
            onClick={onClose}
        >
            <X size={20} />
        </button>}
    </div>;

    const list = patches.list;
    const rows = list.map((patch, index) => ({ patch, index }));
    const selected = editing === undefined ? undefined : list[editing];

    if (selected && editing !== undefined) {
        const editable = !selected.builtIn;
        const set = (metadata: Partial<RomPatchMetadata>): void =>
            patches.updateMetadata(editing, metadata);
        return <>
            <div className='vp-panel-toolbar'>
                <button
                    type='button'
                    className='vp-panel-back'
                    aria-label={nls.localize('vueport/general/backToList', 'Back To List')}
                    onClick={() => setEditing(undefined)}
                >
                    <ArrowLeft size={20} />
                    {nls.localize('vueport/general/backToList', 'Back To List')}
                </button>
            </div>
            <div className='vp-panel-detail vp-scroll'>
                <div className='vp-detail vp-patches-detail'>
                    <div className='vp-detail-groups'>
                        <fieldset className='vp-inspector-group'>
                            <legend>{nls.localize('vueport/patches/patch', 'Patch')}</legend>
                            <div className='vp-detail-fields'>
                                {control(
                                    nls.localize('vueport/general/name', 'Name'),
                                    <input
                                        className='vp-input'
                                        value={selected.name}
                                        readOnly={!editable}
                                        onChange={event => set({ name: event.target.value })}
                                    />,
                                    undefined,
                                    true,
                                )}
                                {selected.color
                                    ? field(nls.localize('vueport/patches/type', 'Type'), colorPatchLabel())
                                    : control(
                                        nls.localize('vueport/patches/type', 'Type'),
                                        <Select
                                            value={selected.type}
                                            disabled={!editable}
                                            onChange={next => set({ type: next as RomPatchType })}
                                            options={ROM_PATCH_TYPES.map(type => ({
                                                value: type,
                                                label: typeLabel(type),
                                            }))}
                                        />,
                                    )}
                                {control(
                                    nls.localize('vueport/patches/author', 'Author'),
                                    <input
                                        className='vp-input'
                                        value={selected.author ?? ''}
                                        placeholder={nls.localize('vueport/patches/unknownAuthor', 'Unknown')}
                                        readOnly={!editable}
                                        onChange={event => set({ author: event.target.value || undefined })}
                                    />,
                                    undefined,
                                    true,
                                )}
                                {selected.version !== undefined && field(
                                    nls.localize('vueport/vbColor/version', 'Version'), selected.version)}
                                {selected.colorStatus !== undefined && field(
                                    nls.localize('vueport/vbColor/status/status', 'Status'),
                                    colorPatchStatusLabel(selected.colorStatus))}
                                {field(nls.localize('vueport/patches/file', 'File'), selected.fileName)}
                                {field(
                                    nls.localize('vueport/patches/format', 'Format'),
                                    selected.format === 'bsdiff' ? 'BSDiff' : selected.format.toUpperCase(),
                                )}
                                {control(
                                    nls.localize('vueport/patches/description', 'Description'),
                                    <textarea
                                        className='vp-input vp-patches-description'
                                        rows={4}
                                        value={selected.description ?? ''}
                                        placeholder={nls.localize(
                                            'vueport/patches/descriptionPlaceholder',
                                            'What this patch changes',
                                        )}
                                        readOnly={!editable}
                                        onChange={event => set({ description: event.target.value || undefined })}
                                    />,
                                    undefined,
                                    true,
                                )}
                            </div>
                            <div className='vp-detail-flags'>
                                <label>
                                    <input
                                        type='checkbox'
                                        checked={selected.enabled}
                                        onChange={() => { toggle(editing); }}
                                    />
                                    {nls.localize('vueport/patches/enabled', 'Enabled')}
                                </label>
                                {!selected.builtIn &&
                                    <button className='vp-button secondary' onClick={() => remove(editing)}>
                                        <Trash size={12} />
                                        {nls.localize('vueport/patches/remove', 'Remove Patch')}
                                    </button>}
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </>;
    }

    const needle = filter.trim().toLowerCase();
    const visible = rows
        .filter(({ patch }) => !needle || [patch.name, patch.author, patch.description]
            .some(text => text?.toLowerCase().includes(needle)));

    return <>
        {header}
        {rows.length === 0
            ? <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/patches/none', 'No patches are registered for this ROM')}
                    description={nls.localize(
                        'vueport/patches/noneDescription',
                        'Import an IPS, UPS, BPS or BSDiff patch to add one.',
                    )}
                    icon={<Bandaids size={32} />}
                />
            </div>
            : <>
                <div className='vp-panel-filter'>
                    <MagnifyingGlass size={15} />
                    <input
                        type='text'
                        spellCheck={false}
                        value={filter}
                        placeholder={nls.localize('vueport/patches/filter', 'Filter')}
                        aria-label={nls.localize('vueport/patches/filter', 'Filter')}
                        onChange={event => setFilter(event.target.value)}
                    />
                    {filter &&
                        <button
                            type='button'
                            className='vp-panel-filter-clear'
                            aria-label={nls.localize('vueport/general/clear', 'Clear')}
                            onClick={() => setFilter('')}
                        >
                            <X size={14} />
                        </button>}
                </div>
                <div className='vp-split-table vp-scroll'>
                    {visible.length === 0
                        ? <p className='vp-panel-empty'>
                            {nls.localize('vueport/patches/noMatch', 'No patches match “{0}”.', filter.trim())}
                        </p>
                        : <ul className='vp-panel-list'>
                            {visible.map(({ patch, index }) => <li
                                key={patch.id ?? `${patch.fileName}-${index}`}
                                className={'vp-panel-row vp-patches-row'
                                    + (patch.color ? ' vp-patches-color' : '')
                                    + (patch.enabled ? ' enabled' : '')}
                                onClick={() => { toggle(index); }}
                            >
                                <button
                                    type='button'
                                    role='switch'
                                    aria-checked={patch.enabled}
                                    aria-label={patch.name}
                                    className='vp-switch'
                                    onClick={event => {
                                        event.stopPropagation();
                                        toggle(index);
                                    }}
                                >
                                    <span className='vp-switch-knob' />
                                </button>
                                <span className='vp-patches-summary'>
                                    <span className='vp-panel-row-name'>{patch.name}</span>
                                    {/* A colorization reads as one at a glance: the
                                        VB Color stripe, and the kind first in the
                                        line under its name. */}
                                    {patch.color &&
                                        <span className='vp-patches-color-stripe' aria-hidden='true' />}
                                    <span className='vp-patches-meta'>
                                        {patch.color ? colorPatchLabel() : typeLabel(patch.type)}
                                        {patch.colorStatus && ` · ${colorPatchStatusLabel(patch.colorStatus)}`}
                                        {patch.author && ` · ${patch.author}`}
                                        {patch.version && ` · ${patch.version}`}
                                        {!patch.builtIn && ` · ${patch.fileName}`}
                                    </span>
                                    {patch.description &&
                                        <span className='vp-panel-row-notes'>{patch.description}</span>}
                                </span>
                                <button
                                    type='button'
                                    className='vp-panel-row-action'
                                    aria-label={patch.builtIn
                                        ? nls.localize('vueport/patches/viewNamed', 'View {0}', patch.name)
                                        : nls.localize('vueport/patches/editNamed', 'Edit {0}', patch.name)}
                                    onClick={event => {
                                        event.stopPropagation();
                                        setEditing(index);
                                    }}
                                >
                                    {patch.builtIn ? <Eye size={18} /> : <PencilSimple size={18} />}
                                </button>
                                {!patch.builtIn && <button
                                    type='button'
                                    className='vp-panel-row-action danger'
                                    aria-label={nls.localize('vueport/patches/removeNamed', 'Remove {0}', patch.name)}
                                    onClick={event => {
                                        event.stopPropagation();
                                        remove(index);
                                    }}
                                >
                                    <Trash size={16} />
                                </button>}
                            </li>)}
                        </ul>}
                </div>
            </>}
        {actions}
    </>;
}
