import {
    ArrowLeft,
    Bandaids,
    Eye,
    FileArrowUp,
    Image as ImageIcon,
    MagnifyingGlass,
    PencilSimple,
    Trash,
    X,
} from '@phosphor-icons/react';
import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';
import { RomPatch, RomPatchType, ROM_PATCH_TYPES } from '../../common/emulator-rom-patches';
import { PatchStore, RomPatchMetadata } from '../emulator-patch-store';
import { control, field } from '../panels/emulator-vip-detail';
import EmptyContainer from './kit/EmptyContainer';
import Select from './kit/Select';

function typeLabel(type: RomPatchType): string {
    switch (type) {
        case 'hack': return nls.localize('vueport/patches/types/hack', 'Hack');
        case 'debug': return nls.localize('vueport/patches/types/debug', 'Debug');
        case 'trainer': return nls.localize('vueport/patches/types/trainer', 'Trainer');
        case 'translation': return nls.localize('vueport/patches/types/translation', 'Translation');
    }
}

export default function EmulatorPatches(props: {
    patches: PatchStore,
    notifications: VueportNotifications,
    onClose?: () => void,
}): React.JSX.Element {
    const { patches, notifications, onClose } = props;
    const importInput = React.useRef<HTMLInputElement>(null);
    const screenshotInput = React.useRef<HTMLInputElement>(null);
    const [editing, setEditing] = React.useState<number | undefined>(undefined);
    const [filter, setFilter] = React.useState('');
    const [, setVersion] = React.useState(0);

    React.useEffect(() => {
        const subscription = patches.onDidChange(() => setVersion(version => version + 1));
        return () => subscription.dispose();
    }, [patches]);

    const reportError = (patch: RomPatch, error: unknown): void =>
        notifications.error(nls.localize(
            'vueport/patches/applyFailed',
            '{0} could not be applied: {1}',
            patch.name,
            error instanceof Error ? error.message : String(error),
        ));

    const toggle = (index: number): void => {
        const patch = patches.list[index];
        if (!patch) {
            return;
        }
        try {
            patches.setEnabled(index, !patch.enabled);
        } catch (error) {
            reportError(patch, error);
        }
    };

    const importFrom = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (importInput.current) {
            importInput.current.value = '';
        }
        if (!file) {
            return;
        }
        try {
            const index = patches.importPatch(file.name, new Uint8Array(await file.arrayBuffer()));
            setEditing(index);
            notifications.info(nls.localize(
                'vueport/patches/imported',
                'Imported {0}. The patch is disabled until you enable it.',
                file.name,
            ));
        } catch (error) {
            notifications.error(nls.localize(
                'vueport/patches/importFailed',
                '{0} could not be imported: {1}',
                file.name,
                error instanceof Error ? error.message : String(error),
            ));
        }
    };

    const remove = async (index: number): Promise<void> => {
        const patch = patches.list[index];
        if (!patch || patch.builtIn) {
            return;
        }
        const confirmed = await notifications.confirm({
            title: nls.localize('vueport/patches/removeQuestion', 'Remove Patch?'),
            message: nls.localize(
                'vueport/patches/removeConfirm',
                'Are you sure you want to remove {0}?',
                patch.name,
            ),
        });
        if (confirmed) {
            patches.remove(index);
            setEditing(undefined);
        }
    };

    const importScreenshot = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (screenshotInput.current) {
            screenshotInput.current.value = '';
        }
        if (!file || editing === undefined) {
            return;
        }
        if (!file.type.startsWith('image/')) {
            notifications.error(nls.localize(
                'vueport/patches/screenshotInvalid',
                '{0} is not an image.',
                file.name,
            ));
            return;
        }
        const screenshot = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => typeof reader.result === 'string'
                ? resolve(reader.result)
                : reject(new Error('Could not read image.'));
            reader.onerror = () => reject(reader.error ?? new Error('Could not read image.'));
            reader.readAsDataURL(file);
        }).catch(error => {
            notifications.error(nls.localize(
                'vueport/patches/screenshotFailed',
                'The screenshot could not be imported: {0}',
                error instanceof Error ? error.message : String(error),
            ));
            return undefined;
        });
        if (screenshot !== undefined) {
            patches.updateMetadata(editing, { screenshot });
        }
    };

    const actions = <div className='vp-panel-actions'>
        <button className='vp-button secondary' onClick={() => importInput.current?.click()}>
            <FileArrowUp size={16} />
            {nls.localize('vueport/patches/import', 'Import Patch…')}
        </button>
        <input
            ref={importInput}
            type='file'
            accept='.ips,.ups,.bps,.bdf,.bspatch,application/octet-stream'
            hidden
            onChange={event => { importFrom(event.target.files); }}
        />
    </div>;

    const header = <div className='vp-panel-heading'>
        {onClose && <span className='vp-panel-heading-title'>
            <Bandaids size={22} />
            {nls.localize('vueport/patches/title', 'Patches')}
        </span>}
        {onClose && <button
            type='button'
            className='vp-panel-close'
            aria-label={nls.localize('vueport/patches/close', 'Close Patches')}
            onClick={onClose}
        >
            <X size={20} />
        </button>}
    </div>;

    const list = patches.list;
    const rows = list
        .map((patch, index) => ({ patch, index }))
        .filter(({ patch }) => !patch.generated);
    const selected = editing === undefined ? undefined : list[editing];

    if (selected && editing !== undefined) {
        const editable = !selected.builtIn;
        const set = (metadata: Partial<RomPatchMetadata>): void =>
            patches.updateMetadata(editing, metadata);
        return <>
            <div className='vp-panel-toolbar'>
                <button
                    type='button'
                    className='vp-panel-back'
                    aria-label={nls.localize('vueport/debug/panels/general/backToList', 'Back To List')}
                    onClick={() => setEditing(undefined)}
                >
                    <ArrowLeft size={20} />
                    {nls.localize('vueport/debug/panels/general/backToList', 'Back To List')}
                </button>
            </div>
            <div className='vp-panel-detail vp-scroll'>
                <div className='vp-detail vp-patches-detail'>
                    <div className='vp-detail-groups'>
                        <fieldset className='vp-inspector-group'>
                            <legend>{nls.localize('vueport/patches/patch', 'Patch')}</legend>
                            <div className='vp-detail-fields'>
                                {control(
                                    nls.localize('vueport/general/name', 'Name'),
                                    <input
                                        className='vp-input'
                                        value={selected.name}
                                        readOnly={!editable}
                                        onChange={event => set({ name: event.target.value })}
                                    />,
                                    undefined,
                                    true,
                                )}
                                {control(
                                    nls.localize('vueport/patches/type', 'Type'),
                                    <Select
                                        value={selected.type}
                                        disabled={!editable}
                                        onChange={next => set({ type: next as RomPatchType })}
                                        options={ROM_PATCH_TYPES.map(type => ({
                                            value: type,
                                            label: typeLabel(type),
                                        }))}
                                    />,
                                )}
                                {control(
                                    nls.localize('vueport/patches/author', 'Author'),
                                    <input
                                        className='vp-input'
                                        value={selected.author ?? ''}
                                        placeholder={nls.localize('vueport/patches/unknownAuthor', 'Unknown')}
                                        readOnly={!editable}
                                        onChange={event => set({ author: event.target.value || undefined })}
                                    />,
                                    undefined,
                                    true,
                                )}
                                {field(nls.localize('vueport/patches/file', 'File'), selected.fileName)}
                                {field(
                                    nls.localize('vueport/patches/format', 'Format'),
                                    selected.format === 'bsdiff' ? 'BSDiff' : selected.format.toUpperCase(),
                                )}
                                {control(
                                    nls.localize('vueport/patches/description', 'Description'),
                                    <textarea
                                        className='vp-input vp-patches-description'
                                        rows={4}
                                        value={selected.description ?? ''}
                                        placeholder={nls.localize(
                                            'vueport/patches/descriptionPlaceholder',
                                            'What this patch changes',
                                        )}
                                        readOnly={!editable}
                                        onChange={event => set({ description: event.target.value || undefined })}
                                    />,
                                    undefined,
                                    true,
                                )}
                            </div>
                            <div className='vp-detail-flags'>
                                <label>
                                    <input
                                        type='checkbox'
                                        checked={selected.enabled}
                                        onChange={() => toggle(editing)}
                                    />
                                    {nls.localize('vueport/patches/enabled', 'Enabled')}
                                </label>
                                {selected.builtIn
                                    ? <span className='vp-cheats-built-in'>
                                        {nls.localize('vueport/patches/builtIn', 'Ships with VUEPort')}
                                    </span>
                                    : <button className='vp-button secondary' onClick={() => remove(editing)}>
                                        <Trash size={12} />
                                        {nls.localize('vueport/patches/remove', 'Remove Patch')}
                                    </button>}
                            </div>
                        </fieldset>
                        <fieldset className='vp-inspector-group vp-patches-screenshot-group'>
                            <legend>{nls.localize('vueport/patches/screenshot', 'Screenshot')}</legend>
                            <div className='vp-patches-screenshot'>
                                {selected.screenshot
                                    ? <img src={selected.screenshot} alt={selected.name} />
                                    : <span>
                                        <ImageIcon size={32} />
                                        {nls.localize('vueport/patches/noScreenshot', 'No screenshot')}
                                    </span>}
                            </div>
                            {editable && <div className='vp-patches-screenshot-actions'>
                                <button
                                    className='vp-button secondary'
                                    onClick={() => screenshotInput.current?.click()}
                                >
                                    <ImageIcon size={16} />
                                    {selected.screenshot
                                        ? nls.localize('vueport/patches/replaceScreenshot', 'Replace…')
                                        : nls.localize('vueport/patches/addScreenshot', 'Add Screenshot…')}
                                </button>
                                {selected.screenshot && <button
                                    className='vp-button secondary'
                                    onClick={() => set({ screenshot: undefined })}
                                >
                                    <Trash size={14} />
                                    {nls.localize('vueport/patches/removeScreenshot', 'Remove')}
                                </button>}
                                <input
                                    ref={screenshotInput}
                                    type='file'
                                    accept='image/*'
                                    hidden
                                    onChange={event => { importScreenshot(event.target.files); }}
                                />
                            </div>}
                        </fieldset>
                    </div>
                </div>
            </div>
        </>;
    }

    const needle = filter.trim().toLowerCase();
    const visible = rows
        .filter(({ patch }) => !needle || [patch.name, patch.author, patch.description]
            .some(text => text?.toLowerCase().includes(needle)));

    return <>
        {header}
        {rows.length === 0
            ? <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/patches/none', 'No patches are registered for this ROM')}
                    description={nls.localize(
                        'vueport/patches/noneDescription',
                        'Import an IPS, UPS, BPS or BSDiff patch to add one.',
                    )}
                    icon={<Bandaids size={32} />}
                />
            </div>
            : <>
                <div className='vp-panel-filter'>
                    <MagnifyingGlass size={15} />
                    <input
                        type='text'
                        spellCheck={false}
                        value={filter}
                        placeholder={nls.localize('vueport/patches/filter', 'Filter')}
                        aria-label={nls.localize('vueport/patches/filter', 'Filter')}
                        onChange={event => setFilter(event.target.value)}
                    />
                    {filter &&
                        <button
                            type='button'
                            className='vp-panel-filter-clear'
                            aria-label={nls.localize('vueport/general/clear', 'Clear')}
                            onClick={() => setFilter('')}
                        >
                            <X size={14} />
                        </button>}
                </div>
                <div className='vp-split-table vp-scroll'>
                    {visible.length === 0
                        ? <p className='vp-panel-empty'>
                            {nls.localize('vueport/patches/noMatch', 'No patches match “{0}”.', filter.trim())}
                        </p>
                        : <ul className='vp-panel-list'>
                            {visible.map(({ patch, index }) => <li
                                key={patch.id ?? `${patch.fileName}-${index}`}
                                className={'vp-panel-row vp-patches-row' + (patch.enabled ? ' enabled' : '')}
                                onClick={() => toggle(index)}
                            >
                                <button
                                    type='button'
                                    role='switch'
                                    aria-checked={patch.enabled}
                                    aria-label={patch.name}
                                    className='vp-switch'
                                    onClick={event => {
                                        event.stopPropagation();
                                        toggle(index);
                                    }}
                                >
                                    <span className='vp-switch-knob' />
                                </button>
                                <span className='vp-patches-summary'>
                                    <span className='vp-panel-row-name'>{patch.name}</span>
                                    <span className='vp-patches-meta'>
                                        {typeLabel(patch.type)}
                                        {patch.author && ` · ${patch.author}`}
                                        {' · '}
                                        {patch.format === 'bsdiff' ? 'BSDiff' : patch.format.toUpperCase()}
                                        {' · '}
                                        {patch.builtIn
                                            ? nls.localize('vueport/patches/builtIn', 'Ships with VUEPort')
                                            : patch.fileName}
                                    </span>
                                    {patch.description &&
                                        <span className='vp-panel-row-notes'>{patch.description}</span>}
                                </span>
                                <button
                                    type='button'
                                    className='vp-panel-row-action'
                                    aria-label={patch.builtIn
                                        ? nls.localize('vueport/patches/viewNamed', 'View {0}', patch.name)
                                        : nls.localize('vueport/patches/editNamed', 'Edit {0}', patch.name)}
                                    onClick={event => {
                                        event.stopPropagation();
                                        setEditing(index);
                                    }}
                                >
                                    {patch.builtIn ? <Eye size={18} /> : <PencilSimple size={18} />}
                                </button>
                                {!patch.builtIn && <button
                                    type='button'
                                    className='vp-panel-row-action danger'
                                    aria-label={nls.localize('vueport/patches/removeNamed', 'Remove {0}', patch.name)}
                                    onClick={event => {
                                        event.stopPropagation();
                                        remove(index);
                                    }}
                                >
                                    <Trash size={16} />
                                </button>}
                            </li>)}
                        </ul>}
                </div>
            </>}
        {actions}
    </>;
}
