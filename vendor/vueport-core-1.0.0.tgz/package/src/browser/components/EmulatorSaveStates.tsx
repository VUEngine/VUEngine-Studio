import {
    ClockClockwise,
    ClockCountdown,
    Export,
    FileArrowUp,
    FloppyDisk,
    Image as ImageIcon,
    MoonStars,
    PencilSimple,
    Play,
    Trash,
    X,
} from '@phosphor-icons/react';
import * as React from 'react';
import { VueportNotifications } from '../../common/emulator-host';
import { nls } from '../../common/emulator-nls';
import { SaveStateKind } from '../../common/emulator-save-state';
import { SaveStateEntry, SaveStateStore } from '../emulator-save-state-store';
import EmptyContainer from './kit/EmptyContainer';

/** What each kind of state is called, where a row says which it is. */
function kindLabel(kind: SaveStateKind): string {
    switch (kind) {
        case 'manual': return nls.localize('vueport/saveStates/kind/manual', 'Manual');
        case 'auto': return nls.localize('vueport/saveStates/kind/auto', 'Automatic');
        case 'suspend': return nls.localize('vueport/saveStates/kind/suspend', 'Suspended Game');
    }
}

function kindIcon(kind: SaveStateKind): React.ReactNode {
    switch (kind) {
        case 'manual': return <FloppyDisk size={13} />;
        case 'auto': return <ClockClockwise size={13} />;
        case 'suspend': return <MoonStars size={13} />;
    }
}

/**
 * When a state was taken, as somebody would say it.
 *
 * The time alone for one taken today, because that is the whole of what
 * distinguishes this morning's states from each other; the date as well for
 * anything older. A state written before the container carried a date — see
 * `SaveStateEntry.legacy` — has none to show.
 */
function formatMoment(created: number): string {
    if (!created) {
        return nls.localize('vueport/saveStates/noDate', 'Date unknown');
    }
    const when = new Date(created);
    const time = when.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    const today = new Date();
    const sameDay = when.getFullYear() === today.getFullYear()
        && when.getMonth() === today.getMonth()
        && when.getDate() === today.getDate();
    return sameDay
        ? nls.localize('vueport/saveStates/today', 'Today, {0}', time)
        : `${when.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}, ${time}`;
}

/**
 * How long ago, in the largest unit that still says something: `5 minutes
 * ago`, `2 hours ago`, `yesterday`.
 *
 * Through `Intl` rather than through the emulator's own strings, because every
 * language pluralizes and phrases this differently and the browser already
 * knows how. A browser without it — none this runs in — simply gets no line.
 *
 * Beside the clock time rather than instead of it: "3 minutes ago" is what
 * tells two states of the same session apart at a glance, and the time itself
 * is what still means something tomorrow.
 */
function formatElapsed(created: number): string | undefined {
    if (!created || typeof Intl.RelativeTimeFormat !== 'function') {
        return undefined;
    }
    // Never in the future: a state taken on a machine whose clock runs ahead —
    // or one imported from one — is still a state from the past, and "in two
    // hours" is not something a list of what happened should ever say.
    const seconds = Math.min(0, Math.round((created - Date.now()) / 1000));
    const relative = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
    const units: [Intl.RelativeTimeFormatUnit, number][] =
        [['second', 60], ['minute', 60], ['hour', 24], ['day', 7], ['week', 5], ['month', 12]];
    let value = seconds;
    for (const [unit, span] of units) {
        if (Math.abs(value) < span) {
            return relative.format(value, unit);
        }
        value = Math.round(value / span);
    }
    return relative.format(value, 'year');
}

/**
 * When a state was taken, for the line between its name and its badge.
 *
 * A state with no name is already called by its time on the line above, so
 * there this is only how long ago that was; a named one carries both.
 */
function dateLine(entry: SaveStateEntry): string {
    return [
        entry.label !== undefined ? formatMoment(entry.created) : undefined,
        formatElapsed(entry.created),
    ].filter(part => part !== undefined).join(' · ');
}

/**
 * The running ROM's save states, beside the screen.
 *
 * The replacement for the numbered slot in the transport: saving always makes
 * a new state, and this is where they are told apart — by the picture of the
 * moment and the time it was taken, which is how a person remembers a moment
 * rather than by a number they had to keep track of.
 *
 * The picture is the button that loads it. That is the one action worth a
 * click of its own here, and a thumbnail somebody is already looking at to
 * decide which moment they want is the obvious thing to press once they have
 * decided.
 */
export default function EmulatorSaveStates(props: {
    states: SaveStateStore,
    notifications: VueportNotifications,
    /** Whether there is a machine running to take a state of, or put one into. */
    canSave: boolean,
    /** Hardcore mode forbids loading; saving and keeping states is still fine. */
    hardcore?: boolean,
    /** The host takes the state: it has the notice to put up and the flags to set. */
    onSave(): void,
    onLoad(entry: SaveStateEntry): void,
    onClose?: () => void,
}): React.JSX.Element {
    const { states, notifications, canSave, hardcore, onSave, onLoad, onClose } = props;
    const importInput = React.useRef<HTMLInputElement>(null);
    /** The state whose name is being edited, and the text so far. */
    const [renaming, setRenaming] = React.useState<{ id: string, text: string } | undefined>(undefined);
    const [, setVersion] = React.useState(0);

    React.useEffect(() => {
        const subscription = states.onDidChange(() => setVersion(version => version + 1));
        return () => subscription.dispose();
    }, [states]);

    /*
     * Redrawn on a slow clock as well as on every change, so "just now" turns
     * into "3 minutes ago" while somebody is looking at it. Half a minute is
     * the coarsest tick that never leaves a visibly stale line, and this panel
     * is only mounted while it is open.
     */
    React.useEffect(() => {
        const clock = setInterval(() => setVersion(version => version + 1), 30000);
        return () => clearInterval(clock);
    }, []);

    const report = (error: unknown): void => notifications.error(
        error instanceof Error ? error.message : String(error));

    const remove = async (entry: SaveStateEntry): Promise<void> => {
        const name = entry.label ?? formatMoment(entry.created);
        const confirmed = await notifications.confirm({
            title: nls.localize('vueport/saveStates/deleteQuestion', 'Delete Save State?'),
            message: nls.localize(
                'vueport/saveStates/deleteConfirm',
                'Are you sure you want to delete {0}? This cannot be undone.',
                name,
            ),
            okLabel: nls.localize('vueport/general/delete', 'Delete'),
        });
        if (confirmed) {
            await states.remove(entry).catch(report);
        }
    };

    const commitRename = async (entry: SaveStateEntry, text: string): Promise<void> => {
        setRenaming(undefined);
        if ((entry.label ?? '') !== text.trim()) {
            await states.rename(entry, text).catch(report);
        }
    };

    const importFrom = async (files: FileList | null): Promise<void> => {
        const file = files?.[0];
        if (importInput.current) {
            importInput.current.value = '';
        }
        if (!file) {
            return;
        }
        try {
            await states.importState(file.name, new Uint8Array(await file.arrayBuffer()));
            notifications.info(nls.localize(
                'vueport/saveStates/imported', 'Imported {0}.', file.name));
        } catch (error) {
            notifications.error(nls.localize(
                'vueport/saveStates/importFailed',
                '{0} could not be imported: {1}',
                file.name,
                error instanceof Error ? error.message : String(error),
            ));
        }
    };

    const header = <div className='vp-panel-heading'>
        {onClose && <span className='vp-panel-heading-title'>
            <ClockCountdown size={22} />
            {nls.localize('vueport/saveStates/title', 'Save States')}
        </span>}
        {onClose && <button
            type='button'
            className='vp-panel-close'
            aria-label={nls.localize('vueport/saveStates/close', 'Close Save States')}
            onClick={onClose}
        >
            <X size={20} />
        </button>}
    </div>;

    const actions = <div className='vp-panel-actions'>
        <button className='vp-button' disabled={!canSave} onClick={() => onSave()}>
            <FloppyDisk size={16} />
            {nls.localize('vueport/saveStates/save', 'Save State')}
        </button>
        <button
            className='vp-button secondary'
            disabled={!states.attached}
            onClick={() => importInput.current?.click()}
        >
            <FileArrowUp size={16} />
            {nls.localize('vueport/saveStates/import', 'Import…')}
        </button>
        <input
            ref={importInput}
            type='file'
            accept='.state,application/octet-stream'
            hidden
            onChange={event => { importFrom(event.target.files); }}
        />
    </div>;

    const list = states.list;

    return <>
        {header}
        {list.length === 0
            ? <div className='vp-panel-empty-fill'>
                <EmptyContainer
                    title={nls.localize('vueport/saveStates/none', 'This game has no save states')}
                    description={nls.localize(
                        'vueport/saveStates/noneDescription',
                        'Save one to come back to this moment. Every save makes a new state, '
                        + 'with a picture of what was on screen.',
                    )}
                    icon={<ClockCountdown size={32} />}
                />
            </div>
            : <div className='vp-split-table vp-scroll'>
                <ul className='vp-panel-list'>
                    {list.map(entry => <li
                        key={entry.id}
                        className={'vp-panel-row vp-states-row'
                            + (entry.kind === 'suspend' ? ' suspended' : '')
                            + (canSave ? ' loadable' : '')}
                        onClick={() => {
                            if (canSave && renaming?.id !== entry.id) {
                                onLoad(entry);
                            }
                        }}
                    >
                        {/* The whole row loads the state; the picture stays a
                            button so the keyboard has something to land on,
                            and lets its click bubble up to the row rather than
                            loading twice. Dimmed rather than gone in hardcore
                            mode and with nothing running: the row still says
                            what it is, and the reason it cannot be loaded is
                            the notice the host puts up. */}
                        <button
                            type='button'
                            className='vp-states-thumb'
                            disabled={!canSave}
                            aria-label={nls.localize(
                                'vueport/saveStates/loadNamed',
                                'Load {0}',
                                entry.label ?? formatMoment(entry.created),
                            )}
                        >
                            {entry.thumbnail
                                ? <img src={entry.thumbnail} alt='' />
                                : <ImageIcon size={24} />}
                            <span className='vp-states-thumb-play'>
                                <Play size={20} weight='fill' />
                            </span>
                        </button>
                        <span className='vp-states-summary'>
                            {renaming?.id === entry.id
                                ? <input
                                    className='vp-input vp-states-rename'
                                    autoFocus
                                    value={renaming.text}
                                    placeholder={formatMoment(entry.created)}
                                    onClick={event => event.stopPropagation()}
                                    onChange={event => setRenaming({ id: entry.id, text: event.target.value })}
                                    onBlur={() => commitRename(entry, renaming.text)}
                                    onKeyDown={event => {
                                        if (event.key === 'Enter') {
                                            commitRename(entry, renaming.text);
                                        } else if (event.key === 'Escape') {
                                            event.stopPropagation();
                                            setRenaming(undefined);
                                        }
                                    }}
                                />
                                : <span className='vp-panel-row-name'>
                                    {entry.label ?? formatMoment(entry.created)}
                                </span>}
                            {/* When it was taken, on a line of its own between
                                the name and the badge. */}
                            <span className='vp-states-date'>{dateLine(entry)}</span>
                            <span className='vp-states-meta'>
                                <span className={`vp-states-badge ${entry.kind}`}>
                                    {kindIcon(entry.kind)}
                                    {kindLabel(entry.kind)}
                                </span>
                                {entry.machines > 1 &&
                                    ` · ${nls.localize('vueport/saveStates/linkedPair', 'Linked pair')}`}
                                {entry.legacy &&
                                    ` · ${nls.localize('vueport/saveStates/legacy', 'Older format')}`}
                            </span>
                        </span>
                        {!entry.legacy && <button
                            type='button'
                            className='vp-panel-row-action'
                            aria-label={nls.localize('vueport/saveStates/rename', 'Rename')}
                            onClick={event => {
                                event.stopPropagation();
                                setRenaming({ id: entry.id, text: entry.label ?? '' });
                            }}
                        >
                            <PencilSimple size={16} />
                        </button>}
                        <button
                            type='button'
                            className='vp-panel-row-action'
                            aria-label={nls.localize('vueport/saveStates/export', 'Export')}
                            onClick={event => {
                                event.stopPropagation();
                                states.exportState(entry).catch(report);
                            }}
                        >
                            <Export size={16} />
                        </button>
                        <button
                            type='button'
                            className='vp-panel-row-action danger'
                            aria-label={nls.localize('vueport/saveStates/delete', 'Delete')}
                            onClick={event => {
                                event.stopPropagation();
                                remove(entry);
                            }}
                        >
                            <Trash size={16} />
                        </button>
                    </li>)}
                </ul>
            </div>}
        {hardcore && <p className='vp-panel-note'>
            {nls.localize(
                'vueport/saveStates/hardcoreNote',
                'Hardcore mode is on, so a state can be saved but not loaded.',
            )}
        </p>}
        {actions}
    </>;
}
