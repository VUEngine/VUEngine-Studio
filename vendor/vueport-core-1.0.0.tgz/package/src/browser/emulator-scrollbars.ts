import PerfectScrollbar from 'perfect-scrollbar';
import { Disposable } from '../common/emulator-events';

/**
 * What marks a container as one that scrolls its own content.
 *
 * Written on the element itself — in its `className`, or by `addClass` for the
 * dock's Lumino panels — rather than kept as a list of selectors here. A new
 * scrolling surface is then one word next to the element that scrolls, in the
 * same place as the CSS that makes it scroll, and nothing has to remember to
 * add it to a register somewhere else.
 *
 * Deliberately not `ps`: that is perfect-scrollbar's own class, which it adds
 * to a container once it has taken it over, so marking a container with it
 * would leave no way to tell the two apart.
 */
export const VUEPORT_SCROLL_MARKER = 'vp-scroll';

const SCROLL_SELECTOR = `.${VUEPORT_SCROLL_MARKER}`;

/** The rails perfect-scrollbar puts inside a container it has taken over. */
function isRail(node: Node): boolean {
    return node instanceof Element
        && (node.classList.contains('ps__rail-x') || node.classList.contains('ps__rail-y'));
}

/**
 * Perfect Scrollbar on every scrolling container in the interface.
 *
 * The dock's tab bar has had one since it was written (see `TabBar`)
 * and this is the same library and the same behavior everywhere else: the
 * native scrollbar hidden, a rail drawn over the content rather than taking a
 * strip of it, fading in on hover and while scrolling. What it buys is a
 * scrollbar that looks the same on every platform and costs no layout width —
 * a panel's content no longer reflows by ten pixels the moment it grows tall
 * enough to scroll.
 *
 * Attached from here rather than by each panel because the containers are not
 * the panels: they are elements React creates and throws away as its output
 * changes, and there is no one lifecycle to hang twenty scrollbars on. So this
 * watches the tree instead — a container that appears gets a scrollbar, one
 * that goes takes its scrollbar with it, and anything that changes inside one
 * makes it measure again.
 *
 * Two things went wrong the last time this library was pointed at the panels,
 * and both are settled here rather than left to be rediscovered:
 *
 * - Two scrollbars at once. Perfect Scrollbar pins its container to
 *   `overflow: hidden` and draws over it, which does nothing if the container's
 *   own CSS says `overflow: auto !important` — as `.vp-panel` does, to beat
 *   Lumino. The stylesheet answers that with a `.ps` rule of its own; see the
 *   scrollbars section of `emulator-widget.css`.
 * - No horizontal scrolling. That was Theia's `ReactWidget` attaching it with
 *   `suppressScrollX`, which the wide tables (VSU, Memory) cannot live with.
 *   Nothing is suppressed here; both axes scroll wherever the content is bigger
 *   than the box in that direction.
 */
export class VueportScrollbars implements Disposable {

    protected readonly bars = new Map<Element, PerfectScrollbar>();
    /** What the size observer is already watching for each container: its own children, minus the rails. */
    protected readonly watched = new Map<Element, Set<Element>>();
    /** Watches each container's own box and its content's, for a size that changed without the DOM doing. */
    protected sizes: ResizeObserver | undefined;
    /** Watches the whole tree, for containers arriving and leaving and for content changing inside one. */
    protected tree: MutationObserver | undefined;
    /** Containers whose measurements are stale, updated together on the next frame. */
    protected readonly stale = new Set<Element>();
    protected frame: number | undefined;

    /**
     * Take over every container under `root`, now and as they come and go.
     *
     * Called once, with the document the application renders into: the dock's
     * panels, the strips beside the screen and the host's own windows are all
     * in the same document, and one observer over the lot is cheaper than one
     * per surface.
     */
    install(root: Element): void {
        if (this.tree) {
            return;
        }
        this.sizes = new ResizeObserver(entries => {
            for (const entry of entries) {
                const container = this.bars.has(entry.target)
                    ? entry.target
                    : entry.target.parentElement;
                if (container && this.bars.has(container)) {
                    this.stale.add(container);
                }
            }
            this.schedule();
        });
        this.tree = new MutationObserver(records => this.onMutations(records));
        this.tree.observe(root, { childList: true, subtree: true, characterData: true });
        this.scan(root);
    }

    /** Look through a freshly added subtree for containers to take over. */
    protected scan(root: Element): void {
        if (root.matches(SCROLL_SELECTOR)) {
            this.attach(root);
        }
        root.querySelectorAll(SCROLL_SELECTOR).forEach(element => this.attach(element));
    }

    protected attach(element: Element): void {
        if (this.bars.has(element) || !this.scrolls(element)) {
            return;
        }
        // `keyboard` is deliberately absent: it moves the container by key and
        // the emulator reads the arrow keys as the D-pad, so a panel with focus
        // would swallow them. Everything else a scrollbar is for is here.
        this.bars.set(element, new PerfectScrollbar(element, {
            handlers: ['click-rail', 'drag-thumb', 'wheel', 'touch'],
            // A panel that cannot scroll any further hands the wheel back to
            // whatever holds it, rather than stopping the gesture dead.
            wheelPropagation: true,
        }));
        this.observeContent(element);
    }

    /**
     * Whether this container's CSS actually scrolls it, here.
     *
     * The mark says a container scrolls; the stylesheet says where. A few of
     * these only scroll under a particular parent — `.vp-detail` is a
     * scrolling column inside a split panel and an ordinary block anywhere
     * else — and the element carrying the mark cannot know which it is. Read
     * before the library touches it, since taking a container over is what
     * pins it to `overflow: hidden`, and pinning a box that was never meant to
     * be one would clip content its parent was going to scroll for it.
     */
    protected scrolls(element: Element): boolean {
        const style = getComputedStyle(element);
        return style.overflowX !== 'visible' || style.overflowY !== 'visible';
    }

    protected detach(element: Element): void {
        const bar = this.bars.get(element);
        if (!bar) {
            return;
        }
        bar.destroy();
        this.bars.delete(element);
        this.stale.delete(element);
        this.sizes?.unobserve(element);
        // Exactly what was watched, rather than whatever the element happens
        // to hold now: a container is usually detached because it was emptied.
        this.watched.get(element)?.forEach(child => this.sizes?.unobserve(child));
        this.watched.delete(element);
    }

    /**
     * Watch what a container holds, not only the container.
     *
     * A panel that is a fixed share of the dock does not change size when its
     * content grows — the content does, and that is what the scrollbar has to
     * be told about. Content that changes by DOM is caught by the tree
     * observer; this catches the rest, an image finishing loading or a font
     * arriving and reflowing a table.
     *
     * Written as a difference against what is already watched, and never as a
     * blind re-observe: `ResizeObserver.observe` delivers an observation for
     * an element it is already watching, so observing the same children again
     * is not a no-op — it schedules another callback, which marks the
     * container stale, which measures it again. Called on every mutation, as
     * this once was, that is a forced layout on every keystroke and every
     * frame the emulator paints, which is enough to starve a WebView of the
     * main thread entirely.
     */
    protected observeContent(element: Element): void {
        let watched = this.watched.get(element);
        if (!watched) {
            watched = new Set();
            this.watched.set(element, watched);
            this.sizes?.observe(element);
        }
        const children = new Set(Array.from(element.children).filter(child => !isRail(child)));
        for (const child of children) {
            if (!watched.has(child)) {
                this.sizes?.observe(child);
                watched.add(child);
            }
        }
        for (const child of Array.from(watched)) {
            if (!children.has(child)) {
                this.sizes?.unobserve(child);
                watched.delete(child);
            }
        }
    }

    protected onMutations(records: MutationRecord[]): void {
        for (const record of records) {
            // The library's own rails, going in and out of a container this
            // very observer is watching. Answering them would measure the
            // container again, which moves the rails, which is a loop.
            if (Array.from(record.addedNodes).every(isRail)
                && Array.from(record.removedNodes).every(isRail)
                && (record.addedNodes.length > 0 || record.removedNodes.length > 0)) {
                continue;
            }
            record.removedNodes.forEach(node => {
                if (node instanceof Element) {
                    if (this.bars.has(node)) {
                        this.detach(node);
                    }
                    node.querySelectorAll(SCROLL_SELECTOR).forEach(inner => this.detach(inner));
                }
            });
            record.addedNodes.forEach(node => {
                if (node instanceof Element) {
                    this.scan(node);
                }
            });
            // Whatever else changed, the container it changed in is now
            // measuring something other than what it was measuring before.
            const target = record.target instanceof Element
                ? record.target
                : record.target.parentElement;
            const container = target?.closest(SCROLL_SELECTOR);
            if (container && this.bars.has(container)) {
                this.stale.add(container);
                // Only its own children are worth re-reading, and only when
                // they are what changed: text changing somewhere deep inside
                // cannot have added or removed one.
                if (record.type === 'childList' && record.target === container) {
                    this.observeContent(container);
                }
            }
        }
        this.schedule();
    }

    /**
     * Measure once a frame at most.
     *
     * A React render is a burst of mutations describing one new picture, and
     * `update` reads layout — doing it per record would lay the page out
     * dozens of times to answer a single change.
     */
    protected schedule(): void {
        if (this.frame !== undefined || this.stale.size === 0) {
            return;
        }
        this.frame = requestAnimationFrame(() => {
            this.frame = undefined;
            const pending = Array.from(this.stale);
            this.stale.clear();
            for (const element of pending) {
                // Still attached, and still in the document: a container can
                // be measured and removed within the same frame.
                if (element.isConnected) {
                    this.bars.get(element)?.update();
                }
            }
        });
    }

    dispose(): void {
        if (this.frame !== undefined) {
            cancelAnimationFrame(this.frame);
            this.frame = undefined;
        }
        this.tree?.disconnect();
        this.tree = undefined;
        this.sizes?.disconnect();
        this.sizes = undefined;
        for (const element of Array.from(this.bars.keys())) {
            this.detach(element);
        }
        this.stale.clear();
    }
}
