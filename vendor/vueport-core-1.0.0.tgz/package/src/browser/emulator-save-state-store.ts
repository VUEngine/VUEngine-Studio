import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import { nls } from '../common/emulator-nls';
import {
    describeSaveState,
    SaveStateKind,
    unwrapSaveState,
    VesEmulatorSaveStateIdentity,
    VesEmulatorSaveStateMeta,
    wrapSaveState,
} from '../common/emulator-save-state';
import { CompanionRom, EmulatorCompanionFiles } from './emulator-companion-files';

/**
 * One state in the running ROM's library, as the browser shows it.
 *
 * Everything here but `path` comes out of the file itself — see
 * `VesEmulatorSaveStateMeta`. The megabyte of machine it was read alongside is
 * dropped again immediately: the browser shows a picture and a date, and
 * holding twenty snapshots of a Virtual Boy in memory to draw twenty
 * thumbnails would be paying for the states twice.
 */
export interface SaveStateEntry {
    /** What {@link EmulatorCompanionFiles.saveState} names the file with. */
    id: string;
    path: string;
    kind: SaveStateKind;
    /** When it was taken, or 0 for a file that does not say. */
    created: number;
    label?: string;
    /** A PNG `data:` URL of the moment, when the file carries one. */
    thumbnail?: string;
    /** How many machines it holds: two for a state of a linked pair. */
    machines: number;
    size: number;
    /**
     * True for a state written before the container carried metadata — a
     * numbered slot from an older VUEPort, or a raw snapshot.
     *
     * Still loadable, and still worth listing: somebody's playthrough is in
     * there. It simply has no picture and no date to show.
     */
    legacy: boolean;
}

/**
 * What the store needs from whatever is running the game.
 *
 * Declared here rather than imported from the widget, so that the store
 * depends on nothing above it: both hosts satisfy this structurally, and a
 * test can satisfy it with a handful of lines. It is deliberately about
 * *machines* rather than about a session — a linked pair is two of them, and
 * a state of that pair is one file holding both.
 */
export interface SaveStateMachine {
    /** How many machines are running: 1 alone, 2 while linked. */
    readonly machineCount: number;
    /** Every machine's snapshot, in player order, or nothing if none is running. */
    snapshot(): Promise<ArrayBuffer[] | undefined>;
    /** Put them all back, in the same order. */
    restore(states: ArrayBuffer[]): Promise<void>;
    /** A PNG of what is on screen right now, for the thumbnail. */
    thumbnail(): Promise<Uint8Array | undefined>;
    /** What the state is stamped with, so it cannot be loaded into another game. */
    identity(): VesEmulatorSaveStateIdentity | undefined;
    /** What ESSound is playing, which the core knows nothing about. */
    esSoundSnapshot(): unknown;
    /** And putting it back as the state found it. */
    esSoundRestore(snapshot: unknown): void;
}

/** Newest first, with the suspended game — if there is one — kept at the top. */
function byRecency(a: SaveStateEntry, b: SaveStateEntry): number {
    if ((a.kind === 'suspend') !== (b.kind === 'suspend')) {
        return a.kind === 'suspend' ? -1 : 1;
    }
    if (a.created !== b.created) {
        return b.created - a.created;
    }
    // Two states of the same second, or two legacy files with no date at all:
    // the id is the only order left, and it is at least a stable one.
    return a.id < b.id ? 1 : -1;
}

/** `data:image/png;base64,…`, in chunks small enough not to blow the argument list. */
function pngDataUrl(bytes: Uint8Array): string {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return `data:image/png;base64,${btoa(binary)}`;
}

/** `20260917-134501-097`: sorts by time as a string, and reads as a date. */
function timestampId(when: Date): string {
    const pad = (value: number, width = 2): string => `${value}`.padStart(width, '0');
    return `${when.getFullYear()}${pad(when.getMonth() + 1)}${pad(when.getDate())}`
        + `-${pad(when.getHours())}${pad(when.getMinutes())}${pad(when.getSeconds())}`
        + `-${pad(when.getMilliseconds(), 3)}`;
}

/** The one state a ROM is put away with; always this id, so it is overwritten. */
export const SUSPEND_STATE_ID = 'suspend';

/**
 * The running ROM's save states: what there are, and making, loading, naming
 * and throwing away one.
 *
 * ## No slots
 *
 * There were twenty-six numbered slots here once, and the number in the
 * transport was a thing to keep track of: which one this run was in, which one
 * that boss fight was in, whether the one being written over was the one
 * somebody still wanted. Saving now always makes a new state and never
 * replaces one, and the browser beside the screen is where they are told
 * apart — by their picture and their time, which is what a person actually
 * remembers a moment by.
 *
 * ## The library is the folder
 *
 * There is no index file. A state's id is in its name and everything else
 * about it is in the file, so the list is a directory listing and a state
 * copied in by hand is simply there the next time the folder is read. That
 * costs a read of every state to build the list, which is why the descriptions
 * are cached by path and size and only a file that is new or has changed is
 * read again.
 *
 * ## Three kinds
 *
 * Manual states are the person's and are never removed by the emulator. Auto
 * states are taken on a timer and rotate: the oldest falls out when a new one
 * arrives, which makes them a very coarse rewind that survives a crash. The
 * suspend state is a single file, overwritten whenever a ROM is put away and
 * offered back on the next launch. See `SaveStateKind`.
 */
export class SaveStateStore {

    protected rom: CompanionRom | undefined;
    protected machine: SaveStateMachine | undefined;
    protected entries: SaveStateEntry[] = [];
    /** Descriptions kept between refreshes, by path and size — see the class comment. */
    protected described = new Map<string, SaveStateEntry>();
    /** Refreshes run one after another, so two of them cannot interleave their lists. */
    protected refreshing: Promise<void> = Promise.resolve();

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires whenever the list changes, for the browser to redraw on. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    constructor(
        protected readonly storage: VueportStorage,
        protected readonly companions: EmulatorCompanionFiles,
    ) { }

    /** Newest first; the suspended game, if there is one, at the top. */
    get list(): readonly SaveStateEntry[] {
        return this.entries;
    }

    /** True once a ROM's folder has been read, which is what the panel waits for. */
    get attached(): boolean {
        return this.rom !== undefined;
    }

    /**
     * Point the store at the ROM that is now running, and at the machines
     * running it.
     *
     * Both may be undefined, which is what closing a ROM does: the list empties
     * and nothing can be saved or loaded until another one opens.
     */
    async attach(rom: CompanionRom | undefined, machine: SaveStateMachine | undefined): Promise<void> {
        const changed = rom?.name !== this.rom?.name || rom?.location !== this.rom?.location;
        this.rom = rom;
        this.machine = machine;
        if (changed) {
            this.described.clear();
            this.entries = [];
            this.onDidChangeEmitter.fire();
        }
        if (rom) {
            await this.refresh();
        }
    }

    /** Read the folder again. Cheap after the first time — see the class comment. */
    refresh(): Promise<void> {
        return this.refreshing = this.refreshing.then(() => this.readFolder()).catch(() => undefined);
    }

    protected async readFolder(): Promise<void> {
        const rom = this.rom;
        if (!rom) {
            return;
        }
        const files = await this.storage.list(this.companions.directory(rom)).catch(() => []);
        const found: SaveStateEntry[] = [];
        const seen = new Map<string, SaveStateEntry>();
        for (const file of files) {
            const id = this.companions.saveStateId(rom, file.name);
            if (id === undefined) {
                continue;
            }
            const key = `${file.path}:${file.size}`;
            const cached = this.described.get(key);
            const entry = cached ?? await this.describe(id, file.path, file.size);
            if (entry) {
                seen.set(key, entry);
                found.push(entry);
            }
        }
        this.described = seen;
        this.entries = found.sort(byRecency);
        this.onDidChangeEmitter.fire();
    }

    /** One file, read for what it says about itself and then let go of. */
    protected async describe(id: string, path: string, size: number): Promise<SaveStateEntry | undefined> {
        const bytes = await this.storage.read(path).catch(() => undefined);
        if (!bytes || bytes.length === 0) {
            return undefined;
        }
        const described = describeSaveState(bytes);
        if (!described || !described.meta) {
            // A raw snapshot, or a container from before there was metadata.
            return {
                id, path, size, kind: 'manual', created: 0,
                machines: described?.machines ?? 1, legacy: true,
            };
        }
        return {
            id,
            path,
            size,
            kind: described.meta.kind,
            created: described.meta.created,
            label: described.meta.label,
            thumbnail: described.meta.thumbnail,
            machines: described.machines,
            legacy: false,
        };
    }

    /** The newest state somebody asked for, which is what Load State loads. */
    get latestManual(): SaveStateEntry | undefined {
        return this.entries.find(entry => entry.kind === 'manual');
    }

    /** The state the ROM was last put away with, if it was. */
    get suspended(): SaveStateEntry | undefined {
        return this.entries.find(entry => entry.kind === 'suspend');
    }

    get autoStates(): SaveStateEntry[] {
        return this.entries.filter(entry => entry.kind === 'auto');
    }

    /**
     * Take a state of what is running now.
     *
     * Always a new file for a manual or automatic state — nothing is ever
     * written over, which is the point of there being no slots. The suspend
     * state is the one exception: it has a fixed id, so every launch finds one
     * state to offer rather than a pile of them.
     */
    async create(kind: SaveStateKind, label?: string): Promise<SaveStateEntry | undefined> {
        const rom = this.rom;
        const machine = this.machine;
        if (!rom || !machine) {
            return undefined;
        }
        const identity = machine.identity();
        const states = await machine.snapshot();
        if (!identity || !states || states.length === 0) {
            return undefined;
        }
        // Best-effort: a machine that cannot be captured — paused before its
        // first frame, or drawing on a surface the host will not read back —
        // still makes a perfectly good state, just one without a picture.
        const picture = await machine.thumbnail().catch(() => undefined);
        const when = new Date();
        const meta: VesEmulatorSaveStateMeta = {
            kind,
            created: when.getTime(),
            label,
            thumbnail: picture && picture.length > 0 ? pngDataUrl(picture) : undefined,
            romName: rom.name,
        };
        const id = kind === 'suspend'
            ? SUSPEND_STATE_ID
            : await this.freeId(rom, kind === 'auto' ? `auto-${timestampId(when)}` : timestampId(when));
        const path = this.companions.saveState(rom, id);
        await this.storage.write(path, wrapSaveState(states, identity, machine.esSoundSnapshot(), meta));
        await this.refresh();
        return this.entries.find(entry => entry.id === id);
    }

    /**
     * `base`, or `base-2`, `base-3`… — whichever is not taken.
     *
     * The id is the moment the state was taken down to the millisecond, which
     * two states can share: an automatic state and one somebody asked for can
     * land in the same tick, and time can be put back. Saving must never
     * silently write over a state, so a taken name is not used.
     */
    protected async freeId(rom: CompanionRom, base: string): Promise<string> {
        let id = base;
        for (let attempt = 2; await this.storage.exists(this.companions.saveState(rom, id)); attempt++) {
            id = `${base}-${attempt}`;
        }
        return id;
    }

    /**
     * Put the machines back to a state.
     *
     * The identity check in `unwrapSaveState` is what keeps a state of another
     * game — or of a linked pair, in a window playing alone — from restoring
     * convincing nonsense. A file with no container at all is a raw snapshot
     * from an older VUEPort, and is loaded as one: there is nothing in it to
     * check, and refusing it would strand states people already have.
     */
    async restore(entry: SaveStateEntry): Promise<void> {
        const machine = this.machine;
        if (!machine) {
            throw new Error(nls.localize(
                'vueport/saveStates/noMachine', 'There is no game running to load a state into.'));
        }
        const identity = machine.identity();
        const bytes = await this.storage.read(entry.path);
        if (!describeSaveState(bytes)) {
            if (machine.machineCount !== 1) {
                throw new Error(nls.localize(
                    'vueport/saveStates/rawIntoPair',
                    'This save state was made by a single emulator and cannot be loaded into a linked pair.'));
            }
            await machine.restore([bytes.slice().buffer as ArrayBuffer]);
            return;
        }
        if (!identity) {
            throw new Error(nls.localize(
                'vueport/saveStates/noRom', 'There is no ROM running to load a state into.'));
        }
        const unwrapped = unwrapSaveState(bytes, machine.machineCount, identity);
        await machine.restore(unwrapped.states);
        if (unwrapped.esSound !== undefined) {
            try {
                machine.esSoundRestore(JSON.parse(unwrapped.esSound));
            } catch {
                // A state whose audio section cannot be read still restores the
                // game; the tracks simply carry on as they were.
            }
        }
    }

    async remove(entry: SaveStateEntry): Promise<void> {
        await this.storage.delete(entry.path);
        await this.refresh();
    }

    /**
     * Give a state a name, or take one away.
     *
     * The whole file is written again, because the name lives inside it — see
     * `VesEmulatorSaveStateMeta`. That is a megabyte for a word, and it is
     * still the right trade: the alternative is a name that an exported state
     * arrives without.
     *
     * Naming an automatic state, or the suspended game, makes it one of the
     * person's own. Both of those are states the emulator will overwrite or
     * drop on its own, and somebody who has just called one "Before the boss"
     * is saying they want it — watching it disappear a minute later because
     * of what took it is not an answer. The badge on the row changes with it,
     * so the promotion says so rather than happening invisibly.
     */
    async rename(entry: SaveStateEntry, label: string): Promise<void> {
        const rom = this.rom;
        if (!rom) {
            return;
        }
        if (entry.legacy) {
            throw new Error(nls.localize(
                'vueport/saveStates/cannotRename',
                'This save state was written by an older version of VUEPort and cannot be named.'));
        }
        const bytes = await this.storage.read(entry.path);
        const described = describeSaveState(bytes);
        if (!described || !described.meta) {
            throw new Error(nls.localize(
                'vueport/saveStates/cannotRename',
                'This save state was written by an older version of VUEPort and cannot be named.'));
        }
        const trimmed = label.trim();
        const named = trimmed.length > 0;
        const meta: VesEmulatorSaveStateMeta = {
            ...described.meta,
            kind: named && entry.kind !== 'manual' ? 'manual' : described.meta.kind,
            label: named ? trimmed : undefined,
        };
        if (meta.kind === described.meta.kind) {
            await this.storage.write(entry.path, rewriteMeta(bytes, meta));
        } else {
            // A promoted state moves house as well: an automatic one is found
            // by its name when the rotation looks for what to drop, and the
            // suspended game's name is the one the next close writes over.
            const id = await this.freeId(rom, timestampId(new Date(meta.created || Date.now())));
            await this.storage.write(this.companions.saveState(rom, id), rewriteMeta(bytes, meta));
            await this.storage.delete(entry.path).catch(() => undefined);
        }
        await this.refresh();
    }

    /** The file itself, handed to the person — a download in a browser. */
    async exportState(entry: SaveStateEntry): Promise<void> {
        const rom = this.rom;
        const bytes = await this.storage.read(entry.path);
        const stem = rom ? this.storage.stem(rom.name) : 'vueport';
        await this.storage.export(`${stem}.${entry.id}.state`, bytes);
    }

    /**
     * Take a state file in, as a state of this ROM.
     *
     * Checked before it is kept rather than when it is loaded, so that a file
     * that belongs to another game is refused while somebody is still looking
     * at the file picker, rather than months later from a row in the browser.
     * Imported states are filed as manual whatever they were: an automatic
     * state somebody thought worth carrying to another machine has stopped
     * being one of the rotating ones.
     */
    async importState(fileName: string, bytes: Uint8Array): Promise<SaveStateEntry | undefined> {
        const rom = this.rom;
        const machine = this.machine;
        if (!rom) {
            return undefined;
        }
        const described = describeSaveState(bytes);
        const identity = machine?.identity();
        if (described && identity) {
            // Throws with the reason — wrong ROM, wrong emulator version,
            // linked pair — which is what the host puts in front of the person.
            unwrapSaveState(bytes, described.machines, identity);
        }
        const when = new Date();
        const id = timestampId(when);
        const meta: VesEmulatorSaveStateMeta = {
            kind: 'manual',
            created: described?.meta?.created ?? when.getTime(),
            label: described?.meta?.label ?? this.storage.stem(fileName),
            thumbnail: described?.meta?.thumbnail,
            romName: rom.name,
        };
        const stored = described?.meta ? rewriteMeta(bytes, meta) : bytes;
        await this.storage.write(this.companions.saveState(rom, id), stored);
        await this.refresh();
        return this.entries.find(entry => entry.id === id);
    }

    /**
     * Drop the automatic states past the newest `keep` of them.
     *
     * Only the automatic ones, ever: what makes them safe to take every minute
     * is that they are the only states that go away on their own.
     */
    async pruneAuto(keep: number): Promise<void> {
        const extra = this.autoStates.slice(Math.max(0, keep));
        if (extra.length === 0) {
            return;
        }
        for (const entry of extra) {
            await this.storage.delete(entry.path).catch(() => undefined);
        }
        await this.refresh();
    }

    /** Throw the suspended game away — what declining to resume does. */
    async clearSuspended(): Promise<void> {
        const suspended = this.suspended;
        if (suspended) {
            await this.storage.delete(suspended.path).catch(() => undefined);
            await this.refresh();
        }
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}

/**
 * The same file with a different metadata section.
 *
 * Rather than re-wrapping from the blocks, which would mean holding the whole
 * state as separate buffers to put one word back: everything up to the section
 * is unchanged, so the file is its own head plus a new tail. Only ever called
 * for a file that was read as version 3, which is the only version that has
 * the section and the length word this puts back.
 */
function rewriteMeta(stored: Uint8Array, next: VesEmulatorSaveStateMeta): Uint8Array {
    const header = new DataView(stored.buffer, stored.byteOffset, stored.byteLength);
    const version = header.getUint32(4);
    const metaBytes = version >= 3 ? header.getUint32(48 + 4) : 0;
    const encoded = new TextEncoder().encode(JSON.stringify(next));
    const head = stored.subarray(0, stored.length - metaBytes);
    const out = new Uint8Array(head.length + encoded.length);
    out.set(head, 0);
    out.set(encoded, head.length);
    new DataView(out.buffer).setUint32(48 + 4, encoded.length);
    return out;
}
