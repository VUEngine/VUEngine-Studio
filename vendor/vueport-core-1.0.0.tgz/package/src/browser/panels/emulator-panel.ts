import { nls } from '../../common/emulator-nls';
import { Disposable } from '../../common/emulator-events';
import { VueportReactWidget } from '../emulator-widget-base';
import { Message } from '@lumino/messaging';
import { Sim } from '../core/vb-core';
import { VesBreakpoints } from '../core/emulator-breakpoints';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { VesScreenRect } from './emulator-screen-panel';
import { RomHeader } from '../emulator-types';

/**
 * Identifies a panel type, and is what a persisted layout stores.
 *
 * Only inspectors are in here. The five surfaces that belong to the game
 * rather than to the machine — cheats, macros, patches, colors and
 * achievements — are not panels in either mode: they are shown beside the
 * screen and opened from the title bar, the same way in Play and in Debug.
 * See `EmulatorHost#renderCheats` for why, and what a layout holding one of
 * their old keys does now (`VueportDock#widgetFor` drops it).
 */
export enum EmulatorPanelType {
    ACTORS = 'actors',
    DISASSEMBLY = 'disassembly',
    ES_SOUND = 'esSound',
    MEMORY = 'memory',
    PROFILER = 'profiler',
    MEMORY_POOLS = 'memoryPools',
    REGISTERS = 'registers',
    ROM_INFO = 'romInfo',
    RUMBLE_PACK = 'rumblePack',
    SCREEN = 'screen',
    SRAM = 'sram',
    TERMINAL = 'terminal',
    VIP_BGMAPS = 'vipBgMaps',
    VIP_CHARACTERS = 'vipCharacters',
    VIP_FRAME_BUFFERS = 'vipFrameBuffers',
    VIP_OBJECTS = 'vipObjects',
    VIP_PALETTES = 'vipPalettes',
    VIP_WORLDS = 'vipWorlds',
    VCU = 'vcu',
    VSU = 'vsu',
}

/**
 * Each panel's title, as a function returning it rather than as the string
 * itself.
 *
 * This module is imported before the host installs its localization, so a table
 * of finished strings built here would be built while the fallback
 * implementation was still in place and would stay English for the life of the
 * process. Deferring the call to `emulatorPanelLabel` moves it to the moment a
 * title is actually shown. See `setLocalization`.
 */
const EMULATOR_PANEL_LABELS: Record<EmulatorPanelType, () => string> = {
  [EmulatorPanelType.REGISTERS]: () => nls.localize('vueport/debug/panels/registers/title', 'Registers'),
  [EmulatorPanelType.DISASSEMBLY]: () => nls.localize('vueport/debug/panels/disassembly/title', 'Disassembly'),
  [EmulatorPanelType.MEMORY]: () => nls.localize('vueport/debug/panels/memory/title', 'Memory'),
  [EmulatorPanelType.MEMORY_POOLS]: () => nls.localize('vueport/debug/panels/memoryPools/title', 'Memory Pools'),
  [EmulatorPanelType.PROFILER]: () => nls.localize('vueport/debug/panels/profiler/title', 'CPU Profiler'),
  [EmulatorPanelType.ACTORS]: () => nls.localize('vueport/debug/panels/actors/title', 'Actors'),
  [EmulatorPanelType.SCREEN]: () => nls.localize('vueport/debug/panels/screen/title', 'Screen'),
  [EmulatorPanelType.VIP_PALETTES]: () => nls.localize('vueport/debug/panels/palettes/title', 'Palettes'),
  [EmulatorPanelType.VIP_CHARACTERS]: () => nls.localize('vueport/debug/panels/characters/title', 'Characters'),
  [EmulatorPanelType.VIP_BGMAPS]: () => nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps'),
  [EmulatorPanelType.VIP_WORLDS]: () => nls.localize('vueport/debug/panels/worlds/title', 'Worlds'),
  [EmulatorPanelType.VIP_OBJECTS]: () => nls.localize('vueport/debug/panels/objects/title', 'Objects'),
  [EmulatorPanelType.VIP_FRAME_BUFFERS]: () => nls.localize('vueport/debug/panels/frameBuffers/title', 'Frame Buffers'),
  [EmulatorPanelType.VCU]: () => nls.localize('vueport/debug/panels/vcu/title', 'VCU'),
  [EmulatorPanelType.VSU]: () => nls.localize('vueport/debug/panels/vsu/title/title', 'VSU'),
  [EmulatorPanelType.TERMINAL]: () => nls.localize('vueport/debug/panels/terminal/title', 'Terminal'),
  [EmulatorPanelType.ROM_INFO]: () => nls.localize('vueport/debug/panels/romInfo/title', 'ROM Info'),
  [EmulatorPanelType.ES_SOUND]: () => nls.localize('vueport/debug/panels/esSound/title', 'ESSound'),
  [EmulatorPanelType.RUMBLE_PACK]: () => nls.localize('vueport/debug/panels/rumblePack/title', 'Rumble Pack'),
  [EmulatorPanelType.SRAM]: () => nls.localize('vueport/debug/panels/sram/title', 'SRAM'),
};

/** A panel's title, translated at the moment it is asked for. */
export function emulatorPanelLabel(type: EmulatorPanelType): string {
  return EMULATOR_PANEL_LABELS[type]();
}

/** Every panel type, for building a menu over all of them. */
export const EMULATOR_PANEL_TYPES = Object.keys(EMULATOR_PANEL_LABELS) as EmulatorPanelType[];

/**
 * Which machine of a linked pair the debugger is pointed at.
 *
 * `own` is this window's player, `peer` the other player's — the mirror this
 * window runs of their machine, which is bit-identical to the one they are
 * playing for as long as the session holds. Never `peer` outside a session:
 * there is no second machine to point at.
 */
export type InspectedSeat = 'own' | 'peer';

/**
 * What a debug panel is allowed to ask of the running emulator.
 *
 * Panels are handed this rather than the widget so that they cannot drive
 * emulation, only observe it.
 */
export interface DebugSource {
    /** The simulation being inspected, or undefined before it has booted. */
    readonly sim: Sim | undefined;
    /**
     * Which of a linked pair {@link sim} is.
     *
     * Always `own` for an emulator playing alone, which is what a panel that
     * does not care can carry on assuming. While a link session is running the
     * player can point the debugger at the other player's machine instead, and
     * a panel that says whose registers or whose memory it is showing reads
     * this to know.
     */
    readonly inspecting: InspectedSeat;
    /**
     * True while the other player's machine is there to be pointed at, so
     * chrome offering the choice can appear only when there is one.
     */
    readonly hasPeerSim: boolean;
    /** Whether VB Color-specific information may be exposed by inspectors. */
    readonly vbcSupportEnabled: boolean;
    /**
     * Whether the machine is actually running as a VB Color right now.
     *
     * Narrower than {@link vbcSupportEnabled}, which only says the feature is
     * not switched off globally: Auto still resolves to an original Virtual Boy
     * for a ROM whose header does not ask for color, and then there is no VCU
     * to inspect. Every color-only surface in the debugger keys off this, so
     * they appear together and for one reason.
     */
    readonly vbcHardwareActive: boolean;
    /** The header of the ROM currently loaded, parsed once at load time. */
    readonly romHeader: RomHeader;
    /** The ROM's size in MBit. */
    readonly romSize: number;
    /**
     * CRC32 of the whole ROM file, as eight lower-case hex digits — the same
     * identity the cheat database keys on. Undefined for a host that has not
     * supplied one.
     */
    readonly romChecksum: string | undefined;
    /**
     * The build mode the ROM was made with, as the build names it, or
     * undefined for one that was not built here — see `readBuildModeFromMap`.
     */
    readonly buildMode: string | undefined;
    /** Fires when emulation state changes in a way panels should redraw for. */
    onDidChange(listener: () => void): Disposable;
    /**
     * The symbols of the ROM being run, for panels that can say more with
     * them — where the engine put something, or what a name in the project
     * calls it. Resolves to undefined for a ROM that was not built here, or
     * was built without symbols beside it, which such a panel has to treat as
     * an ordinary state rather than a failure.
     *
     * Reading them is expensive enough that it only happens when something
     * asks, so a panel should call this from its refresh rather than
     * preemptively; the result is shared and cached for as long as the ROM is.
     */
    getSymbols(): Promise<SymbolIndex | undefined>;
    /**
     * Where each address came from in the source, for a panel that can show
     * it — and, in a host that has editors, for turning a breakpoint set on a
     * line into the address the machine stops at.
     *
     * Read from the build's own `.debug_line`, so it arrives with the symbols
     * and is absent for the same reasons: a ROM that was not built here, or a
     * host that cannot reach the files beside it.
     */
    getLineTable(): Promise<VesLineTable | undefined>;
    /**
     * Where the machine should stop.
     *
     * Read *and written* through, unlike everything else here — the one
     * exception to this interface being read-only, and a deliberate one: a
     * breakpoint is not a way to drive the machine, it is a note about where
     * it should pause, and the gutter that sets one is a view of the same set
     * an editor in the surrounding application sets. See `VesBreakpoints`.
     */
    readonly breakpoints: VesBreakpoints;
    /**
     * One source file as text, named exactly as the line table names it.
     *
     * The line table's paths are the files the compiler actually read, which
     * for a VUEngine build are the generated ones under `build/working` —
     * and those are the files its line numbers count in. Reading the original
     * instead would put the text half a file out of step with the numbers.
     */
    readSource(path: string): Promise<string | undefined>;
    /**
     * Mark rectangles on the picture, in the Virtual Boy's screen space, or
     * clear them with an empty list.
     *
     * The one thing here that changes what is on screen rather than only
     * reading it — but it draws over the picture rather than into it, so it
     * cannot affect what the machine is doing. A panel that sets these owns
     * them: it has to clear them when it stops being the one describing the
     * selection, including when it is hidden or closed.
     */
    setHighlights(rects: VesScreenRect[]): void;
    /**
     * Write bytes into the machine being inspected.
     *
     * The one route a panel changes memory by, rather than reaching for
     * `sim.writeMemory` itself, because in a linked session a write is not a
     * local matter: the same bytes have to land in the other window's copy of
     * that machine, on the same frame, or the two are running different games
     * from then on. Where they go is this object's business; a panel only has
     * to say what it wants written.
     *
     * Bytes rather than a buffer, because a poke is a handful of them and they
     * may have to travel to the other window — where nobody wants to think
     * about who owns a transferred ArrayBuffer.
     */
    write(address: number, bytes: number[]): Promise<void>;
    /**
     * How a panel's own controls were last left, remembered across sessions.
     *
     * Not state of the machine, so not really this interface's subject — but a
     * panel has nothing else it is handed, and routing it here keeps the
     * storage a host's business rather than each panel reaching for one. The
     * fallback is both the default and the type: a stored value of another
     * shape is discarded rather than handed back, so a panel whose control
     * changed type reads its own answer and not an old one.
     */
    panelPreference<T extends string | number | boolean>(
        kind: EmulatorPanelType, key: string, fallback: T): T;
    /** Remember one of {@link panelPreference}'s values. */
    setPanelPreference(
        kind: EmulatorPanelType, key: string, value: string | number | boolean): void;
}

/**
 * Base for the debug panels docked beside the screen.
 *
 * Panels poll rather than being pushed to, because the emulator produces fifty
 * frames a second and no inspector needs that. Polling only runs while a panel
 * is actually visible, so a stack of hidden tabs costs nothing.
 */
export abstract class Panel extends VueportReactWidget {

    /** Refreshes a second. Fast enough to read, slow enough to stay cheap. */
    protected static readonly POLL_HZ = 10;

    /**
     * How often this panel refreshes. Overridden by panels whose reads are
     * expensive enough that ten times a second is not worth it.
     */
    protected pollHz(): number {
        return Panel.POLL_HZ;
    }

    // toDisposeOnDetach is inherited from BaseWidget, which clears it on
    // detach; redeclaring it here would shadow that.
    protected pollTimer?: number;

    constructor(
        readonly kind: EmulatorPanelType,
        protected readonly source: DebugSource,
        instanceId: string
    ) {
        super();
        this.id = `vp-panel:${instanceId}:${kind}`;
        this.title.closable = true;
        this.addClass('vp-panel');
        this.addClass('vp-scroll');
    }

    /**
     * How a control of this panel's was last left, or `fallback` for one that
     * has never been touched.
     *
     * Written as a field initializer — `protected zoom = this.remembered('zoom', 4)`
     * — which is safe because `source` and `kind` are constructor parameters of
     * this class and so are already assigned by the time a subclass initializes
     * its own fields.
     */
    // Overloaded rather than generic so that a fallback written as a literal
    // — `this.remembered('zoom', 4)` — types the field as `number` and not as
    // the one value `4` it happens to start at.
    protected remembered(key: string, fallback: boolean): boolean;
    protected remembered(key: string, fallback: number): number;
    protected remembered(key: string, fallback: string): string;
    protected remembered(
        key: string, fallback: string | number | boolean
    ): string | number | boolean {
        return this.source.panelPreference(this.kind, key, fallback);
    }

    /** Remember a control's value, and hand it straight back to be assigned. */
    protected remember(key: string, value: boolean): boolean;
    protected remember(key: string, value: number): number;
    protected remember(key: string, value: string): string;
    protected remember(
        key: string, value: string | number | boolean
    ): string | number | boolean {
        this.source.setPanelPreference(this.kind, key, value);
        return value;
    }

    protected onAfterShow(msg: Message): void {
        super.onAfterShow(msg);
        this.startPolling();
    }

    protected onAfterAttach(msg: Message): void {
        // The base renders from here, so its implementation has to run.
        super.onAfterAttach(msg);
        if (this.isVisible) {
            this.startPolling();
        }
    }

    protected onAfterHide(msg: Message): void {
        super.onAfterHide(msg);
        this.stopPolling();
    }

    protected onBeforeDetach(msg: Message): void {
        this.stopPolling();
        super.onBeforeDetach(msg);
    }

    /**
     * Every poll tick re-renders through React, and this node (`.emulator-panel`,
     * see the constructor) is where `overflow: auto` actually lives for most
     * panels — the ones that just fill it with a table or a list rather than
     * managing their own inner scroll region (Terminal, the VIP inspectors).
     *
     * React reuses DOM nodes it can match up between renders, but a table
     * whose rows are keyed by something that legitimately changes under
     * polling — which row a filter now includes, say — can't always be
     * matched, and removing/reinserting the node currently under the
     * scrollbar is enough for the browser to reset scrollTop on its own.
     * Ten times a second, that reads as scrolling not working at all.
     * Saving and restoring it around the render is cheap insurance against
     * that, whichever panel's render happens to trigger it.
     */
    protected onUpdateRequest(msg: Message): void {
        const { scrollTop, scrollLeft } = this.node;
        super.onUpdateRequest(msg);
        this.node.scrollTop = scrollTop;
        this.node.scrollLeft = scrollLeft;
    }

    protected startPolling(): void {
        if (this.pollTimer !== undefined) {
            return;
        }
        this.poll();
        this.pollTimer = window.setInterval(() => this.poll(), 1000 / this.pollHz());
    }

    /**
     * One round of {@link refresh}, with a rejection swallowed.
     *
     * `refresh` is asynchronous in every panel that reads the machine, and the
     * machine can be taken away underneath it: changing the hardware model or
     * the VB Color gate is a power-on choice, so it stops the session and
     * starts a new one, and a read already in flight then rejects with "the
     * emulator core has been disposed". Nothing can be done about that and
     * nothing needs to be — the next tick reads the new session — but left
     * alone it surfaces as an unhandled rejection in the console.
     */
    protected poll(): void {
        const pending = this.refresh() as void | Promise<void>;
        if (pending instanceof Promise) {
            pending.catch(() => undefined);
        }
    }

    /** Pick up a changed poll rate, if the panel is currently polling. */
    protected restartPolling(): void {
        if (this.pollTimer !== undefined) {
            this.stopPolling();
            this.startPolling();
        }
    }

    protected stopPolling(): void {
        if (this.pollTimer !== undefined) {
            window.clearInterval(this.pollTimer);
            this.pollTimer = undefined;
        }
    }

    /**
     * Pull fresh data and redraw. Implementations should tolerate no sim.
     *
     * May be asynchronous; {@link poll} is what calls it, and what deals with
     * a read that the machine outlived.
     */
    protected abstract refresh(): void | Promise<void>;

    dispose(): void {
        this.stopPolling();
        super.dispose();
    }
}

/**
 * Whether a control the key went to wants the arrow keys for itself.
 *
 * A panel that walks its own contents with the arrows reads them on the node
 * around everything — so that they work wherever focus has landed in it —
 * and asks this about each one first. Anything typed into or dragged with
 * them answers yes, as do the listboxes, which move through their own
 * options. So does anything that put itself in the tab order: a control
 * tabbable in its own right handles its own keys, which is how the segmented
 * pickers move between their options and how a panel's second scrolling
 * region keeps its own arrow keys. `root` is the node reading the event,
 * which is itself in the tab order and is never what took the key.
 */
export function arrowKeysTaken(target: EventTarget | null, root: EventTarget | null): boolean {
    const taken = target instanceof Element ? target.closest(ARROW_KEY_CONTROLS) : undefined;
    return !!taken && taken !== root;
}

const ARROW_KEY_CONTROLS = 'input, select, textarea, [contenteditable="true"],'
    + ' [role="combobox"], [role="listbox"], [tabindex="0"]';

/** Format a number as a fixed-width hexadecimal string. */
export function hex(value: number, digits: number): string {
    return (value >>> 0).toString(16).toUpperCase().padStart(digits, '0');
}
