import { nls } from '../../common/emulator-nls';
import { VueportWidget } from '../emulator-widget-base';
import { Message } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import {
    DisplayMode,
    VbEyes,
    VbPalette,
    VbStereoLayout,
    VB_DEFAULT_DISPLAY_MODE,
    VB_LEVEL_STOPS,
    VB_SCREEN_HEIGHT,
    VB_SCREEN_WIDTH,
} from '../../common/vb-constants';
import { EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { EmulatorScale } from '../emulator-types';
import { composeAnaglyph } from '../../worker/vb-anaglyph';

/**
 * What is drawn around the picture where it does not fill the panel.
 *
 * `black` fills the panel behind the picture, the backdrop a real Virtual Boy
 * shows. `ambient` and `immersion` both cast a blurred halo out from the
 * picture's footprint — `ambient` in one fixed color, `immersion` from the
 * picture itself, fed frame by frame through {@link ScreenPanel.pushBackdrop}.
 * Both take an `intensity` from 0 to 1, applied as the halo's opacity — the
 * flat `ambient` fill at a fraction of it, so that the same number means about
 * the same strength either way. See `AMBIENT_INTENSITY_SCALE`.
 * `undefined` leaves the panel plain.
 */
export type EmulatorDecorationSpec =
    | { readonly kind: 'black' }
    | { readonly kind: 'ambient'; readonly color: string; readonly intensity: number }
    | { readonly kind: 'immersion'; readonly intensity: number };

/**
 * A rectangle in the Virtual Boy's own screen space, as the engine drew it.
 *
 * `parallax` is the sprite's, and is what separates the two eyes: the left is
 * drawn that far to the left of `x` and the right that far to the right, the
 * same way the VIP reads a world's `gp`.
 */
export interface VesScreenRect {
    x: number;
    y: number;
    width: number;
    height: number;
    parallax: number;
}

/**
 * How a highlight is drawn, matching the outline the Worlds panel puts round a
 * world's extents (`.emulator-vip-canvas-extents`) — the two are the same
 * mark and have to agree, but one is CSS and this one is drawn, so the color
 * is repeated by hand rather than shared.
 *
 * Green because the Virtual Boy's display is red: nothing underneath can be
 * this color, so the outline never disappears into the picture. Dashed for
 * the same reason — a broken line reads as an annotation rather than as
 * something the game drew. Three on, three off is what a CSS `dashed` border
 * comes out as at this width, which is what the Worlds panel outlines a world
 * with, so the two marks read alike.
 *
 * The widths are in the machine's own pixels, so they scale up with the
 * picture and stay visible however large it is shown.
 */
const HIGHLIGHT_COLOR = 'rgb(0, 255, 0)';
const HIGHLIGHT_FILL = 'rgba(0, 255, 0, 0.15)';
const HIGHLIGHT_LINE_WIDTH = 1;
const HIGHLIGHT_DASH = [3, 3];

/** A channel-wise blend of two packed 0xRRGGBB colors. */
function lerpColor(from: number, to: number, t: number): number {
    const r = Math.round(((from >> 16) & 0xff) + (((to >> 16) & 0xff) - ((from >> 16) & 0xff)) * t);
    const g = Math.round(((from >> 8) & 0xff) + (((to >> 8) & 0xff) - ((from >> 8) & 0xff)) * t);
    const b = Math.round((from & 0xff) + ((to & 0xff) - (from & 0xff)) * t);
    return (r << 16) | (g << 8) | b;
}

/**
 * The palette color a brightness stands for — the same piecewise interpolation
 * the renderer's `shade()` does, so the halo agrees with the picture. The four
 * palette entries are anchored at {@link VB_LEVEL_STOPS} and held flat above the
 * last one.
 */
function shade(palette: VbPalette, brightness: number): number {
    const [s0, s1, s2, s3] = VB_LEVEL_STOPS;
    if (brightness <= s1) {
        return lerpColor(palette[0], palette[1], s1 > s0 ? brightness / s1 : 0);
    }
    if (brightness <= s2) {
        return lerpColor(palette[1], palette[2], (brightness - s1) / (s2 - s1));
    }
    return lerpColor(palette[2], palette[3], Math.min((brightness - s2) / (s3 - s2), 1));
}

/**
 * How finely the frame's edge is read for the immersion halo.
 *
 * The picture is averaged into `COLUMNS x ROWS` cells; only the cells on the
 * border are ever used, one lamp each. This decides how closely the light can
 * follow the picture — the way the number of lamps does on a real Ambilight —
 * and nothing else. How the light is then laid out is `HALO_FIELD_*`.
 */
export const BACKDROP_COLUMNS = 48;
export const BACKDROP_ROWS = 30;

/**
 * The light field the halo is drawn from, in its own coordinates.
 *
 * The halo is not the picture stretched and blurred: it is the light the
 * picture's border casts. Every point out here sums the contribution of every
 * lamp on the border, falling off with distance — so the light dims as it goes
 * out, spreads into a fan rather than straight lines, and rounds off at the
 * corners, none of which extruding an edge can do.
 *
 * `WIDTH / (WIDTH - 2 * PAD)` is 1.75 and the same sum down is 2.2: the box the
 * halo fills, as a multiple of the picture. Deliberately independent of the
 * grid above, so reading the edge more finely does not make the light cost
 * more. The field carries no detail finer than {@link HALO_SIGMA} anyway, so
 * this only has to be fine enough for that.
 */
const HALO_FIELD_WIDTH = 48;
const HALO_FIELD_HEIGHT = 38;
const HALO_FIELD_PAD = 12;
/** The picture's own footprint inside the field: 32 x 20. */
const HALO_PICTURE_WIDTH = HALO_FIELD_WIDTH - HALO_FIELD_PAD * 2;
const HALO_PICTURE_HEIGHT = HALO_FIELD_HEIGHT - HALO_FIELD_PAD * 2;
/**
 * How wide a lamp's pool of light is, in field units — an eighth of the
 * picture's width. The knob that decides whether the halo reads as a few broad
 * washes or as a close echo of the edge.
 */
const HALO_SIGMA = 4;
const HALO_SIGMA2 = HALO_SIGMA * HALO_SIGMA;

/**
 * How much of the intensity setting `ambient` actually spends.
 *
 * The two halos answer the same control but do not start from the same place.
 * `ambient` is one flat color at full strength across its whole box, where
 * `immersion` is light that falls off from the border and is nowhere near full
 * except right against a bright edge — so at the same number ambient reads far
 * the stronger of the two. Halving it puts them within sight of each other,
 * which is what offering one slider for both implies.
 */
const AMBIENT_INTENSITY_SCALE = 0.5;

/**
 * Reduce an eye-packed frame to one brightness per cell of
 * {@link BACKDROP_COLUMNS} x {@link BACKDROP_ROWS}, per eye.
 *
 * Not the arithmetic mean. A Virtual Boy frame is mostly black, so a mean is
 * dominated by the black and a cell holding one bright sprite on an empty
 * background reads as almost dark — which is why an average is not what a real
 * Ambilight measures either. This weights each pixel by the light it actually
 * contributes (`sum of b squared / sum of b`), so a cell reports the brightness
 * of the light *in* it and empty space neither dims nor brightens it. A cell
 * with nothing in it is still black, because there is nothing to weight.
 *
 * A few samples per cell rather than every pixel: the answer feeds a wide
 * kernel that will smooth it anyway. A frame that already arrives at the grid's
 * size — what the worker sends, already reduced this way — falls out as itself.
 */
function averageEyes(source: Uint8ClampedArray, width: number, height: number): {
    left: Float64Array, right: Float64Array,
} {
    const cells = BACKDROP_COLUMNS * BACKDROP_ROWS;
    const leftSum = new Float64Array(cells);
    const leftLight = new Float64Array(cells);
    const rightSum = new Float64Array(cells);
    const rightLight = new Float64Array(cells);
    // About four samples across a cell on each axis. Rounded rather than
    // floored so a cell a few pixels wide still steps, instead of falling back
    // to reading every pixel.
    const step = Math.max(1, Math.min(4, Math.round(
        Math.min(width / BACKDROP_COLUMNS, height / BACKDROP_ROWS) / 4)));

    for (let y = 0; y < height; y += step) {
        const row = Math.min(BACKDROP_ROWS - 1, Math.floor((y * BACKDROP_ROWS) / height));
        for (let x = 0; x < width; x += step) {
            const cell = row * BACKDROP_COLUMNS
                + Math.min(BACKDROP_COLUMNS - 1, Math.floor((x * BACKDROP_COLUMNS) / width));
            const at = (y * width + x) * 4;
            const l = source[at];
            const r = source[at + 1];
            leftSum[cell] += l;
            leftLight[cell] += l * l;
            rightSum[cell] += r;
            rightLight[cell] += r * r;
        }
    }

    const left = new Float64Array(cells);
    const right = new Float64Array(cells);
    for (let cell = 0; cell < cells; cell++) {
        left[cell] = leftSum[cell] > 0 ? leftLight[cell] / leftSum[cell] : 0;
        right[cell] = rightSum[cell] > 0 ? rightLight[cell] / rightSum[cell] : 0;
    }
    return { left, right };
}

/**
 * Where the halo's lamps sit, and how bright the brightest lit point can be.
 *
 * All of it follows from the constants above and none of it from the frame, so
 * it is worked out once and kept. `peak` is what the field is divided by: a
 * border that is white all the way round puts exactly full brightness at the
 * point that receives the most light, and everywhere else is dimmer by however
 * much less light reaches it. That is what makes the falloff fall out of the
 * sum rather than being painted on afterwards.
 */
interface HaloLamps {
    /** Field coordinates, one entry per border cell of the grid. */
    x: Float64Array;
    y: Float64Array;
    /** Which grid cell each lamp takes its color from. */
    cell: Int32Array;
    peak: number;
}
let haloLamps: HaloLamps | undefined;

/**
 * Whether a field point sits behind the picture, where no light is ever seen.
 * The picture's own edge counts as lit: that is where the halo starts.
 */
function isHiddenByPicture(fx: number, fy: number): boolean {
    return fx > HALO_FIELD_PAD
        && fx < HALO_FIELD_PAD + HALO_PICTURE_WIDTH - 1
        && fy > HALO_FIELD_PAD
        && fy < HALO_FIELD_PAD + HALO_PICTURE_HEIGHT - 1;
}

function layoutHaloLamps(): HaloLamps {
    const x: number[] = [];
    const y: number[] = [];
    const cell: number[] = [];
    const add = (fx: number, fy: number, at: number) => {
        x.push(fx);
        y.push(fy);
        cell.push(at);
    };
    const spanX = HALO_PICTURE_WIDTH / BACKDROP_COLUMNS;
    const spanY = HALO_PICTURE_HEIGHT / BACKDROP_ROWS;
    for (let column = 0; column < BACKDROP_COLUMNS; column++) {
        const fx = HALO_FIELD_PAD + (column + 0.5) * spanX;
        add(fx, HALO_FIELD_PAD + 0.5, column);
        add(fx, HALO_FIELD_PAD + HALO_PICTURE_HEIGHT - 0.5, (BACKDROP_ROWS - 1) * BACKDROP_COLUMNS + column);
    }
    // The corners already went in with the top and bottom rows.
    for (let row = 1; row < BACKDROP_ROWS - 1; row++) {
        const fy = HALO_FIELD_PAD + (row + 0.5) * spanY;
        add(HALO_FIELD_PAD + 0.5, fy, row * BACKDROP_COLUMNS);
        add(HALO_FIELD_PAD + HALO_PICTURE_WIDTH - 0.5, fy, row * BACKDROP_COLUMNS + BACKDROP_COLUMNS - 1);
    }

    const lamps: HaloLamps = {
        x: Float64Array.from(x),
        y: Float64Array.from(y),
        cell: Int32Array.from(cell),
        peak: 1,
    };
    // The most light any point that is actually *shown* can be given. Geometry
    // only — the weights do not depend on what the lamps are showing.
    //
    // Over the lit points alone, not the whole field: the middle is walled in
    // by lamps on all four sides and takes far more light than anywhere outside
    // ever could, and normalizing by that would leave the halo a fraction of
    // the brightness it should be. Nobody sees the middle anyway.
    let peak = 0;
    for (let fy = 0; fy < HALO_FIELD_HEIGHT; fy++) {
        for (let fx = 0; fx < HALO_FIELD_WIDTH; fx++) {
            if (isHiddenByPicture(fx, fy)) {
                continue;
            }
            let weight = 0;
            for (let lamp = 0; lamp < lamps.x.length; lamp++) {
                const dx = fx + 0.5 - lamps.x[lamp];
                const dy = fy + 0.5 - lamps.y[lamp];
                weight += 1 / (1 + (dx * dx + dy * dy) / HALO_SIGMA2);
            }
            peak = Math.max(peak, weight);
        }
    }
    lamps.peak = peak;
    return lamps;
}

/** Expand a little-endian RGB555 word to the packed RGB888 used by the canvas. */
function rgb555(low: number, high: number): number {
    const word = low | (high << 8);
    const expand = (value: number) => Math.round(value * 255 / 31);
    return (expand(word & 31) << 16)
        | (expand((word >> 5) & 31) << 8)
        | expand((word >> 10) & 31);
}

/** Decode an already-reduced VBC grid into one real color per eye and cell. */
function colorEyes(source: Uint8ClampedArray, width: number, height: number): {
    left: Uint32Array, right: Uint32Array,
} {
    const cells = width * height;
    const left = new Uint32Array(cells);
    const right = new Uint32Array(cells);
    for (let cell = 0; cell < cells; cell++) {
        const at = cell * 4;
        left[cell] = rgb555(source[at], source[at + 1]);
        right[cell] = rgb555(source[at + 2], source[at + 3]);
    }
    return { left, right };
}

/**
 * The emulator's picture, in a panel of its own so it can be docked, resized
 * and rearranged alongside the debug views.
 *
 * The canvas is built imperatively rather than rendered by React: presentation
 * is transferred to the worker with transferControlToOffscreen, which can only
 * happen once per element, so an element that React might recreate would take
 * the picture with it.
 */
export class ScreenPanel extends VueportWidget {

    readonly kind = EmulatorPanelType.SCREEN;

    protected readonly frame: HTMLDivElement;
    /**
     * The box that clips the picture to its rounded corners.
     *
     * `border-radius` on the `<canvas>` itself is not reliably honored once the
     * browser gives the canvas its own compositing layer — the rounding shows
     * on the element box but not on the pixels. `overflow: hidden` on a plain
     * wrapper around it is. The overlay canvas goes in here too, so a highlight
     * drawn to the very edge is clipped the same way the picture is; the halo
     * stays outside, since it is meant to spill past the picture's footprint.
     */
    protected readonly picture: HTMLDivElement;

    /**
     * A line over the picture, for when the picture alone cannot say what is
     * going on. See {@link setPrompt}.
     */
    protected readonly prompt: HTMLDivElement;
    protected canvasElement?: HTMLCanvasElement;
    /**
     * A stand-in for the picture when no game is running — a still, run through
     * the current palette so a palette can be chosen with nothing loaded. Sits
     * in the picture beside the game canvas; only one of the two is shown.
     */
    protected placeholderCanvas?: HTMLCanvasElement;
    /**
     * The still's brightness, one byte per pixel at 384x224, one plane per eye
     * — the same plane twice for a one-eye screenshot. Undefined until a still
     * is set. Kept per eye so the stereo layouts can arrange them the way the
     * live renderer arranges the real picture.
     */
    protected placeholderLeft?: Uint8ClampedArray;
    protected placeholderRight?: Uint8ClampedArray;
    protected placeholderShown = false;
    /**
     * The last picture the worker sent for the `immersion` halo, kept so the
     * halo can be put back when the still stops standing in for it.
     *
     * The two feed the halo at very different rates: the still paints once,
     * when it is chosen, where a live frame arrives on a poll that stops the
     * moment the game is paused. Without a copy to repaint from, coming back
     * from the still to a paused picture would leave the still's halo behind
     * it. See {@link repaintBackdrop}.
     */
    protected liveBackdrop?: {
        pixels: Uint8ClampedArray, width: number, height: number, colorMode: boolean,
    };
    /**
     * The halo behind the picture; see {@link setDecoration}. Its own canvas,
     * drawn at a low resolution and blurred wide by CSS — a flat fill for
     * `ambient`, the picture's own pixels for `immersion`.
     */
    protected readonly glow: HTMLCanvasElement;
    protected decoration?: EmulatorDecorationSpec;
    /**
     * A second canvas over the picture, for marking things on it without
     * touching the frame the worker owns — that one has been transferred and
     * cannot be drawn to from here at all.
     */
    protected overlayCanvas?: HTMLCanvasElement;
    protected highlights: VesScreenRect[] = [];
    /** The picture's displayed size in CSS pixels, from the last layout. */
    protected pictureBox = { width: 0, height: 0 };
    /**
     * How much larger than the picture the halo's box is, per axis. The
     * `immersion` grid carries its own ring of extruded edge color and so
     * wants the room to show it; a flat `ambient` fill only has to spill a
     * little before the blur takes over.
     */
    protected glowSpread = { x: 1, y: 1 };

    protected displayMode: DisplayMode = VB_DEFAULT_DISPLAY_MODE;
    protected scale = 'auto';

    /**
     * Where the picture is while it is somewhere other than this panel.
     *
     * Set by {@link lendPicture}; it is what the picture is sized against for
     * as long as it is away.
     */
    protected borrower?: HTMLElement;
    /**
     * The borrower is not a Lumino widget, so no resize message arrives when
     * it changes size. Watching it is what stands in for one.
     */
    protected borrowerResize?: ResizeObserver;
    /** Whether the borrowed picture fills its box; see {@link lendPicture}. */
    protected borrowerFit = false;
    /**
     * Whether the borrower wants the decoration and the scale kept, rather than
     * the plain fitted picture a palette window used to lend. The Display
     * preview does — its whole point is seeing them at work.
     */
    protected borrowerDecorate = false;

    constructor(instanceId: string) {
        super();
        this.id = `vp-panel:${instanceId}:${EmulatorPanelType.SCREEN}`;
        this.title.label = nls.localize('vueport/debug/panels/screen', 'Screen');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.SCREEN);
        this.title.closable = false;
        this.addClass('vp-screen-panel');

        this.frame = document.createElement('div');
        this.frame.className = 'vp-screen-frame';
        this.node.appendChild(this.frame);

        // First child, so it sits behind the picture and the overlay. Both of
        // those are given an explicit z-index in CSS to keep it that way.
        this.glow = document.createElement('canvas');
        this.glow.className = 'vp-screen-glow';
        this.frame.appendChild(this.glow);

        // The picture and its overlay share one wrapper, which is what carries
        // the rounded corners — see the field's doc comment.
        this.picture = document.createElement('div');
        this.picture.className = 'vp-screen-picture';
        this.frame.appendChild(this.picture);

        this.placeholderCanvas = document.createElement('canvas');
        this.placeholderCanvas.className = 'vp-screen-placeholder';
        this.placeholderCanvas.width = VB_SCREEN_WIDTH;
        this.placeholderCanvas.height = VB_SCREEN_HEIGHT;
        this.placeholderCanvas.hidden = true;
        this.picture.appendChild(this.placeholderCanvas);

        this.overlayCanvas = document.createElement('canvas');
        this.overlayCanvas.className = 'vp-screen-overlay';
        this.picture.appendChild(this.overlayCanvas);

        // Last in the picture, so it covers both canvases. Empty and hidden
        // until something has a reason to put words there — see setPrompt.
        this.prompt = document.createElement('div');
        this.prompt.className = 'vp-screen-prompt';
        this.prompt.hidden = true;
        this.picture.appendChild(this.prompt);

        this.badges = document.createElement('div');
        this.badges.className = 'vp-screen-badges';
        this.node.appendChild(this.badges);

        this.stateBadges = document.createElement('div');
        this.stateBadges.className = 'vp-screen-state-badges';
        this.node.appendChild(this.stateBadges);

        this.strip = document.createElement('div');
        this.strip.className = 'vp-strip-layer';
        this.node.appendChild(this.strip);
    }

    /**
     * A corner of the picture for the chrome to put things in.
     *
     * Empty, and stays empty as far as this panel is concerned: everything in
     * it is rendered by whoever owns the emulator, through a React portal.
     * This panel is imperative DOM — the canvas has to keep its identity
     * across renders, which is the whole reason — so it offers a place rather
     * than trying to draw what belongs to the chrome.
     *
     * Over the picture rather than beside it: what goes here says something
     * about what is running, and follows the picture wherever the dock puts
     * it.
     */
    readonly badges: HTMLDivElement;

    /**
     * The opposite corner, for what the machine is doing.
     *
     * Two slots rather than one because the two say different kinds of thing.
     * `badges` is the session: cheats somebody switched on, a macro recording,
     * a profile being taken — all of them things a person set up and might
     * forget. This is the machine: paused, muted, fast-forwarding. They wear
     * the same pill and behave the same way — press one to put a stop to what
     * it is announcing; which corner it is in is what says which kind it is.
     *
     * It earns its place when the chrome hides itself. With a toolbar on
     * screen the lit buttons say all of this already, and a host using that
     * chrome puts nothing here.
     */
    readonly stateBadges: HTMLDivElement;

    /**
     * Where the floating transport lives — see `EmulatorControlStrip` and the
     * `immersive` chrome on `Emulator`.
     *
     * A third slot beside the two above, and for the same reason: anything
     * put here follows the picture wherever the dock puts it. That matters
     * more here than for the badges, because the transport is meant to be
     * usable rather than just legible — a strip positioned against the whole
     * window would float over whatever panel happened to be in front in
     * Debug mode, one tile among several rather than the screen's own. Tabbed
     * out of view, this node is hidden along with the rest of the panel, and
     * so is whatever is portalled into it: no screen visible, no floating
     * controls for it either.
     */
    readonly strip: HTMLDivElement;

    /**
     * Hand out a fresh canvas for a new emulation session.
     *
     * Any previous one has already given up control to a worker that is going
     * away, so it is replaced rather than reused.
     */
    takeCanvas(): HTMLCanvasElement {
        this.canvasElement?.remove();
        // Belonged to the session that has gone; the new one sends its own.
        this.liveBackdrop = undefined;
        const canvas = document.createElement('canvas');
        canvas.width = this.displayMode.width;
        canvas.height = this.displayMode.height;
        // Kept out of sight while the still stands in for it.
        canvas.hidden = this.placeholderShown;
        // Before the overlay, so the overlay stays on top of it.
        this.picture.insertBefore(canvas, this.overlayCanvas ?? null);
        this.canvasElement = canvas;
        this.relayout();
        return canvas;
    }

    /**
     * Show the running picture somewhere other than the dock, until it is
     * given back.
     *
     * The canvas cannot be copied: presentation belongs to the worker, and one
     * element holds it. So a second view of what the machine is drawing means
     * moving the one that exists — the frame goes whole, keeping the overlay
     * with it, and is sized against its new home instead of this panel.
     *
     * For something that covers the dock while it is up, since the panel is
     * left empty meanwhile: the Display settings, where seeing the picture is
     * how a palette is chosen.
     *
     * `fit` (default true) fills the borrower rather than following the scale
     * the dock is set to — the whole-number scales that keep the machine's
     * pixels square would otherwise leave it a small picture in a large box.
     * `decorate` (default false) keeps the decoration classes and the halo the
     * dock shows, rather than the plain picture a borrower usually wants; the
     * Display preview passes `{ fit: false, decorate: true }` so both the scale
     * and the decoration can be seen at work.
     */
    lendPicture(host: HTMLElement, opts: { fit?: boolean, decorate?: boolean } = {}): void {
        const fit = opts.fit ?? true;
        const decorate = opts.decorate ?? false;
        if (this.borrower === host && this.borrowerFit === fit && this.borrowerDecorate === decorate) {
            return;
        }
        this.returnPicture();
        this.borrower = host;
        this.borrowerFit = fit;
        this.borrowerDecorate = decorate;
        host.appendChild(this.frame);
        this.borrowerResize = new ResizeObserver(() => this.relayout());
        this.borrowerResize.observe(host);
        this.applyDecoration();
        // `applyDecoration` leaves the immersion halo blank for the next frame
        // to fill, and a paused game sends none — so put back what it had.
        this.repaintBackdrop();
        this.relayout();
    }

    /**
     * The picture's shape, in the machine's own pixels.
     *
     * For a borrower that has to give the picture a box of its own: the frame
     * fills whatever holds it, so a container sized by its content would
     * measure nothing and the picture would never be laid out at all. An
     * aspect ratio breaks that circle — see `EmulatorScreenPreview`. Which
     * shape it is depends on the display mode: the stereo layouts present two
     * eyes at once and are correspondingly wider or taller.
     */
    get pictureSize(): { width: number, height: number } {
        return { width: this.displayMode.width, height: this.displayMode.height };
    }

    /** Put a lent picture back in the panel. Does nothing if it is here. */
    returnPicture(): void {
        if (!this.borrower) {
            return;
        }
        this.borrowerResize?.disconnect();
        this.borrowerResize = undefined;
        this.borrower = undefined;
        this.borrowerFit = false;
        this.borrowerDecorate = false;
        // Before the badges, which stayed behind and belong over the picture.
        this.node.insertBefore(this.frame, this.badges);
        this.applyDecoration();
        this.repaintBackdrop();
        this.relayout();
    }

    setDisplayMode(mode: DisplayMode): void {
        this.displayMode = mode;
        this.renderPlaceholder();
        this.relayout();
    }

    /**
     * Mark rectangles on the picture, or clear it with an empty list.
     *
     * The rectangles are in the Virtual Boy's screen space; placing them is
     * this panel's job, since only it knows how the current mode arranges the
     * two eyes.
     */
    setHighlights(rects: VesScreenRect[]): void {
        this.highlights = rects;
        this.drawHighlights();
    }

    setScale(scale: string): void {
        this.scale = scale;
        this.relayout();
    }

    /**
     * Choose what fills the panel around the picture, or `undefined` for
     * nothing. `immersion` also needs the picture's pixels — see
     * {@link pushBackdrop} — and shows no halo until the first frame arrives.
     */
    setDecoration(spec: EmulatorDecorationSpec | undefined): void {
        this.decoration = spec;
        this.applyDecoration();
        this.renderPlaceholder();
        this.repaintBackdrop();
    }

    /**
     * Give the panel a still to show when there is no game — a screenshot the
     * host points to, read once into a brightness plane so the current palette
     * can recolor it. `undefined` forgets it.
     */
    async setPlaceholder(src: string | undefined): Promise<void> {
        if (src === undefined) {
            this.placeholderLeft = undefined;
            this.placeholderRight = undefined;
            this.renderPlaceholder();
            return;
        }
        try {
            const bitmap = await createImageBitmap(await (await fetch(src)).blob());
            // A Virtual Boy screenshot that is much wider than 4:3 is the two
            // eyes side by side; take them as two planes so the stereo modes
            // have a real left and right to place. Anything else is one eye,
            // used for both.
            const stereo = bitmap.width >= bitmap.height * 3;
            this.placeholderLeft = this.readPlane(bitmap, 0, stereo ? bitmap.width / 2 : bitmap.width);
            this.placeholderRight = stereo
                ? this.readPlane(bitmap, bitmap.width / 2, bitmap.width / 2)
                : this.placeholderLeft;
            bitmap.close();
            this.renderPlaceholder();
        } catch {
            // No still to show; the preview falls back to an empty picture.
        }
    }

    /** One eye of the still: a slice of the bitmap as a 384x224 brightness plane. */
    protected readPlane(bitmap: ImageBitmap, sourceX: number, sourceWidth: number): Uint8ClampedArray | undefined {
        const scratch = document.createElement('canvas');
        scratch.width = VB_SCREEN_WIDTH;
        scratch.height = VB_SCREEN_HEIGHT;
        const context = scratch.getContext('2d');
        if (!context) {
            return undefined;
        }
        context.drawImage(
            bitmap, sourceX, 0, sourceWidth, bitmap.height, 0, 0, VB_SCREEN_WIDTH, VB_SCREEN_HEIGHT);
        const { data } = context.getImageData(0, 0, VB_SCREEN_WIDTH, VB_SCREEN_HEIGHT);
        const plane = new Uint8ClampedArray(VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT);
        for (let i = 0; i < plane.length; i++) {
            plane[i] = Math.max(data[i * 4], data[i * 4 + 1], data[i * 4 + 2]);
        }
        return plane;
    }

    /**
     * Put a line over the picture, or take it away again with `undefined`.
     *
     * For the one thing a black picture cannot explain about itself: a window
     * the browser will not let start. Emulation is clocked by the audio, and a
     * page nobody has touched may not produce any — so the second player's
     * window, which its opener rather than a person brought into being, shows
     * nothing until it is clicked. See `audioStillBlocked` in `vb-core.ts`.
     *
     * Deliberately not a button. Any pointer or key event in the window is the
     * gesture the browser is waiting for, so there is nothing here to hit; the
     * prompt only has to be read.
     */
    setPrompt(text: string | undefined): void {
        this.prompt.textContent = text ?? '';
        this.prompt.hidden = text === undefined;
    }

    /**
     * Show the still instead of the game canvas, or the other way round.
     *
     * The game keeps rendering in its worker either way — one canvas is just
     * hidden — which costs nothing worth avoiding for a picture this small.
     */
    showPlaceholder(show: boolean): void {
        if (this.placeholderShown === show) {
            return;
        }
        this.placeholderShown = show;
        if (this.placeholderCanvas) {
            this.placeholderCanvas.hidden = !show;
        }
        if (this.canvasElement) {
            this.canvasElement.hidden = show;
        }
        this.renderPlaceholder();
        this.repaintBackdrop();
        this.relayout();
    }

    /**
     * Paint the still through the current palette, laid out the way the current
     * rendering mode would lay out a live picture: one eye on its own, the two
     * mixed for Anaglyph, or the split and interleaved arrangements the stereo
     * modes present. The same brightness-to-color mapping {@link paintBackdrop}
     * does for the halo, drawn sharp into the picture instead of blurred behind.
     */
    protected renderPlaceholder(): void {
        const canvas = this.placeholderCanvas;
        const left = this.placeholderLeft;
        const right = this.placeholderRight;
        if (!canvas || !left || !right || !this.placeholderShown) {
            return;
        }
        const context = canvas.getContext('2d');
        if (!context) {
            return;
        }
        const { palette, anaglyph, layout, eyes, width, height } = this.displayMode;
        if (canvas.width !== width || canvas.height !== height) {
            canvas.width = width;
            canvas.height = height;
        }
        const image = context.createImageData(width, height);
        const out = image.data;
        const src = (plane: Uint8ClampedArray, sx: number, sy: number): number =>
            plane[Math.min(VB_SCREEN_HEIGHT - 1, sy) * VB_SCREEN_WIDTH + Math.min(VB_SCREEN_WIDTH - 1, sx)];

        for (let cy = 0; cy < height; cy++) {
            for (let cx = 0; cx < width; cx++) {
                let rgb: number;
                if (layout === VbStereoLayout.OVERLAY) {
                    rgb = eyes === VbEyes.BOTH
                        ? composeAnaglyph(
                            shade(palette, src(left, cx, cy) / 255),
                            shade(palette, src(right, cx, cy) / 255),
                            anaglyph)
                        : shade(palette, src(eyes === VbEyes.RIGHT ? right : left, cx, cy) / 255);
                } else {
                    // Which eye this canvas pixel belongs to, and where in that
                    // eye's plane it is sampled from — the inverse of the
                    // placement `strokeEye` uses for the highlights.
                    let eye: 0 | 1;
                    let sx: number;
                    let sy = cy;
                    if (layout === VbStereoLayout.SIDE_BY_SIDE) {
                        eye = cx < VB_SCREEN_WIDTH ? 0 : 1;
                        sx = cx % VB_SCREEN_WIDTH;
                    } else if (layout === VbStereoLayout.CYBERSCOPE) {
                        const half = width / 2;
                        eye = cx < half ? 0 : 1;
                        sx = Math.round((cx % half) * (VB_SCREEN_WIDTH / half));
                    } else if (layout === VbStereoLayout.HLI) {
                        eye = (cy % 2) as 0 | 1;
                        sx = cx;
                        sy = Math.floor(cy / 2);
                    } else {
                        // VLI
                        eye = (cx % 2) as 0 | 1;
                        sx = Math.floor(cx / 2);
                    }
                    rgb = shade(palette, src(eye === 1 ? right : left, sx, sy) / 255);
                }
                const i = (cy * width + cx) * 4;
                out[i] = (rgb >> 16) & 0xff;
                out[i + 1] = (rgb >> 8) & 0xff;
                out[i + 2] = rgb & 0xff;
                out[i + 3] = 0xff;
            }
        }
        context.putImageData(image, 0, 0);

        // The still feeds its own immersion halo — there is no worker frame to.
        if (this.decoration?.kind === 'immersion') {
            const packed = new Uint8ClampedArray(left.length * 4);
            for (let i = 0; i < left.length; i++) {
                packed[i * 4] = left[i];
                packed[i * 4 + 1] = right[i];
            }
            this.paintBackdrop(packed, VB_SCREEN_WIDTH, VB_SCREEN_HEIGHT);
        }
    }

    /**
     * Hand the panel a frame of the picture for the `immersion` halo.
     *
     * A reduced stereo frame from {@link Sim.readBackdrop}. Legacy cells
     * carry the two eye brightnesses and are mapped through the palette; VBC
     * cells carry two RGB555 colors and bypass it. Ignored unless `immersion`
     * is the decoration and the picture is here or lent to a borrower that
     * keeps the decoration.
     *
     * Kept but not painted while the still stands in for the picture: the halo
     * belongs to what is on show, and the game goes on running behind the
     * Display preview, so painting every frame it sends would throw the still's
     * own halo away a few times a second. Kept rather than dropped so the live
     * halo is current again the moment the still steps aside.
     */
    pushBackdrop(pixels: ArrayBuffer, width: number, height: number, colorMode = false): void {
        if (this.decoration?.kind !== 'immersion' || (this.borrower && !this.borrowerDecorate)) {
            return;
        }
        const source = new Uint8ClampedArray(pixels);
        this.liveBackdrop = { pixels: source, width, height, colorMode };
        if (this.placeholderShown) {
            return;
        }
        this.paintBackdrop(source, width, height, colorMode);
    }

    /**
     * Put the halo back in step with whichever picture is on show — the still
     * when it stands in, the last frame the worker sent otherwise.
     *
     * For the moments where the halo's own source changes rather than the
     * picture: switching the Display preview between the still and the live
     * image, or turning `immersion` on while the game is paused and no frame is
     * coming. Does nothing for the other decorations, which
     * {@link applyDecoration} draws in full.
     */
    protected repaintBackdrop(): void {
        // The still's halo is `renderPlaceholder`'s to draw — it has the planes
        // — and is drawn there whenever the still itself is, so there is
        // nothing to put back for it here.
        if (this.decoration?.kind !== 'immersion' || this.placeholderShown) {
            return;
        }
        if (this.liveBackdrop) {
            const { pixels, width, height, colorMode } = this.liveBackdrop;
            this.paintBackdrop(pixels, width, height, colorMode);
        }
    }

    /**
     * Put the decoration on the frame: the classes CSS keys off, and the flat
     * fill the `ambient` halo is. A borrowed picture wears none of it — the
     * halo belongs behind the picture where it plays, not in the small box a
     * palette window lends it — unless the borrower asked to keep it, which the
     * Display preview does.
     */
    protected applyDecoration(): void {
        const spec = this.decoration;
        const borrowed = this.borrower !== undefined && !this.borrowerDecorate;
        const glowing = spec !== undefined && spec.kind !== 'black' && !borrowed;
        this.frame.classList.toggle(
            'vp-decoration-black', spec?.kind === 'black' && !borrowed);
        this.frame.classList.toggle('vp-decoration-glow', glowing);

        // The halo's strength; hidden anyway when not glowing, but kept in step
        // so a change while it is up takes effect without a repaint.
        this.glow.style.opacity = spec !== undefined && spec.kind !== 'black' && !borrowed
            ? String(spec.intensity * (spec.kind === 'ambient' ? AMBIENT_INTENSITY_SCALE : 1))
            : '0';

        const context = this.glow.getContext('2d');
        if (!context) {
            return;
        }
        if (glowing && spec.kind === 'ambient') {
            if (this.glow.width !== 1 || this.glow.height !== 1) {
                this.glow.width = 1;
                this.glow.height = 1;
            }
            context.fillStyle = spec.color;
            context.fillRect(0, 0, 1, 1);
            // One flat color: a little larger than the picture is all it needs
            // before the blur carries it the rest of the way out.
            this.glowSpread = { x: 1.15, y: 1.15 };
            this.sizeGlow();
        } else {
            // Nothing, black, a borrowed picture, or immersion waiting for its
            // first frame: leave no stale color showing.
            context.clearRect(0, 0, this.glow.width, this.glow.height);
        }
    }

    /**
     * Draw the light the frame's border casts.
     *
     * The frame is averaged into cells and its border cells become lamps, each
     * mapped through the palette. Every point outside the picture then sums
     * what all of them throw at it, falling off with distance — so the light
     * dims outward, fans out from a bright spot instead of running straight,
     * and rounds off round the corners. The area behind the picture is never
     * seen; it is filled from the nearest lit point so that the blur over the
     * top has something continuous to work with rather than an edge.
     *
     * Any frame size is accepted: what the worker sends is already the grid,
     * what the still feeds it is a whole 384x224, and both average the same way.
     */
    protected paintBackdrop(
        source: Uint8ClampedArray, width: number, height: number, colorMode = false
    ): void {
        const context = this.glow.getContext('2d');
        if (!context || width < 1 || height < 1) {
            return;
        }
        const { left, right } = colorMode
            ? colorEyes(source, width, height)
            : averageEyes(source, width, height);
        const lamps = haloLamps ??= layoutHaloLamps();
        const wide = HALO_FIELD_WIDTH;
        const tall = HALO_FIELD_HEIGHT;
        if (this.glow.width !== wide || this.glow.height !== tall) {
            this.glow.width = wide;
            this.glow.height = tall;
        }
        const image = context.createImageData(wide, tall);
        const out = image.data;
        const { palette, anaglyph, layout, eyes } = this.displayMode;
        // The one layout that mixes the eyes into a pixel rather than showing
        // one on its own; every other mode is monochrome through the palette.
        const isAnaglyph = layout === VbStereoLayout.OVERLAY && eyes === VbEyes.BOTH;

        // What each lamp is showing. One palette lookup per lamp, and only the
        // border has lamps, so this does not grow with the grid's interior.
        const count = lamps.cell.length;
        const lampRed = new Float64Array(count);
        const lampGreen = new Float64Array(count);
        const lampBlue = new Float64Array(count);
        for (let lamp = 0; lamp < count; lamp++) {
            const cell = lamps.cell[lamp];
            const leftColor = colorMode ? left[cell] : shade(palette, left[cell] / 255);
            const rightColor = colorMode ? right[cell] : shade(palette, right[cell] / 255);
            const rgb = isAnaglyph
                ? composeAnaglyph(leftColor, rightColor, anaglyph)
                : eyes === VbEyes.RIGHT ? rightColor : leftColor;
            lampRed[lamp] = (rgb >> 16) & 0xff;
            lampGreen[lamp] = (rgb >> 8) & 0xff;
            lampBlue[lamp] = rgb & 0xff;
        }

        const insideLeft = HALO_FIELD_PAD;
        const insideTop = HALO_FIELD_PAD;
        const insideRight = HALO_FIELD_PAD + HALO_PICTURE_WIDTH - 1;
        const insideBottom = HALO_FIELD_PAD + HALO_PICTURE_HEIGHT - 1;
        const scale = 1 / lamps.peak;

        for (let y = 0; y < tall; y++) {
            for (let x = 0; x < wide; x++) {
                // Behind the picture there is nothing to light. Take the nearest
                // lit point instead of summing one nobody will ever see.
                const hidden = isHiddenByPicture(x, y);
                const px = (hidden ? Math.min(insideRight, Math.max(insideLeft, x)) : x) + 0.5;
                const py = (hidden ? Math.min(insideBottom, Math.max(insideTop, y)) : y) + 0.5;
                let red = 0;
                let green = 0;
                let blue = 0;
                for (let lamp = 0; lamp < count; lamp++) {
                    const dx = px - lamps.x[lamp];
                    const dy = py - lamps.y[lamp];
                    const weight = 1 / (1 + (dx * dx + dy * dy) / HALO_SIGMA2);
                    red += lampRed[lamp] * weight;
                    green += lampGreen[lamp] * weight;
                    blue += lampBlue[lamp] * weight;
                }
                const at = (y * wide + x) * 4;
                out[at] = red * scale;
                out[at + 1] = green * scale;
                out[at + 2] = blue * scale;
                out[at + 3] = 0xff;
            }
        }
        context.putImageData(image, 0, 0);
        this.glowSpread = {
            x: HALO_FIELD_WIDTH / HALO_PICTURE_WIDTH,
            y: HALO_FIELD_HEIGHT / HALO_PICTURE_HEIGHT,
        };
        this.sizeGlow();
    }

    /**
     * The halo's box: the picture's, grown by whatever spread the last paint
     * wants — and a blur to match.
     *
     * The blur has to follow the box. The grid is a fixed number of cells but
     * the box it is stretched over is not, so a fixed radius smooths away most
     * of the grid at a small scale and leaves the cells showing at a large one.
     * Sized from the cell instead, the halo looks the same at every scale.
     */
    protected sizeGlow(): void {
        const width = Math.round(this.pictureBox.width * this.glowSpread.x);
        const height = Math.round(this.pictureBox.height * this.glowSpread.y);
        this.glow.style.width = `${width}px`;
        this.glow.style.height = `${height}px`;
        // A flat `ambient` fill is a single cell with no grid to smooth; what it
        // wants is enough blur to soften its own edge, which is a share of the
        // box rather than a multiple of a cell.
        const blur = this.glow.width > 2
            ? (width / this.glow.width) * 1.2
            : width * 0.06;
        this.glow.style.filter = `blur(${Math.round(Math.min(96, Math.max(8, blur)))}px) saturate(1.4)`;
    }

    protected onResize(msg: Widget.ResizeMessage): void {
        super.onResize(msg);
        // Lumino already knows this widget's own size when it sends a real
        // one — see `relayout`'s own doc comment for why measuring the DOM a
        // second time here instead would risk disagreeing with it.
        this.relayout(msg.width >= 0 && msg.height >= 0 ? { width: msg.width, height: msg.height } : undefined);
    }

    protected onAfterShow(msg: Message): void {
        super.onAfterShow(msg);
        this.relayout();
    }

    /** The panel has a size only once it is in the document. */
    protected onAfterAttach(msg: Message): void {
        super.onAfterAttach(msg);
        this.relayout();
    }

    /**
     * Size the picture within the panel.
     *
     * The backing store is whatever the display mode presents at; this only
     * decides how large it appears. Integer scales are preferred so that the
     * pixels stay square and sharp.
     *
     * `known` is the box to lay out against, when the caller already has it —
     * `onResize` passes Lumino's own `ResizeMessage` dimensions, which is what
     * Lumino itself just wrote to this node's `style.width`/`style.height` as
     * the authoritative answer. Every other caller here has no such message,
     * and measures the DOM directly instead, same as always. The two normally
     * agree, but do not have to: this panel is sized by a bare `ResizeObserver`
     * with no Lumino layout above it (see `Emulator.tsx`), and Lumino only
     * re-applies `style.height` — and sends the message this reads — when its
     * own cached size differs from what it just computed; a DOM read landing
     * on a stale intermediate value at the wrong moment would otherwise stick
     * until some unrelated resize happened to correct it, which is what left
     * a gap at the bottom of the picture every so often.
     */
    protected relayout(known?: { width: number, height: number }): void {
        // The still stands in for the game canvas while it is shown, and is
        // drawn at the same geometry the mode would give a live picture.
        const canvas = this.placeholderShown ? this.placeholderCanvas : this.canvasElement;
        if (!canvas) {
            return;
        }

        // A lent picture is sized against the borrower, which sends no resize
        // message of its own — see `lendPicture`'s own ResizeObserver — so a
        // known size only applies here when the picture is where Lumino thinks
        // it is.
        const available = known && !this.borrower ? known : (this.borrower ?? this.node).getBoundingClientRect();
        const { width, height } = this.displayMode;
        if (available.width < 1 || available.height < 1) {
            return;
        }

        const rule = this.borrower && this.borrowerFit ? EmulatorScale.FIT : this.scale;
        const fit = Math.min(available.width / width, available.height / height);
        let scale: number;
        if (rule === EmulatorScale.FIT) {
            scale = fit;
        } else if (rule === EmulatorScale.AUTO) {
            scale = Math.max(1, Math.floor(fit));
        } else {
            const requested = parseInt(rule.substring(1), 10);
            scale = Math.max(1, Math.min(Number.isFinite(requested) ? requested : 1, Math.floor(fit) || 1));
        }

        // Never overflow the panel, even at a forced scale in a small dock
        scale = Math.min(scale, fit);

        canvas.style.width = `${Math.floor(width * scale)}px`;
        canvas.style.height = `${Math.floor(height * scale)}px`;

        // The halo is laid out from the picture's footprint, grown by the
        // spread its own content asks for; see `sizeGlow`.
        this.pictureBox = { width: Math.floor(width * scale), height: Math.floor(height * scale) };
        this.sizeGlow();

        // Keep the overlay at the display mode's logical resolution too. In
        // particular, a normal 384x224 picture stays 384x224 at x2 rather than
        // allocating and repainting a 768x448 surface (or larger on HiDPI).
        // CSS enlarges both canvases together.
        const overlay = this.overlayCanvas;
        if (overlay) {
            if (overlay.width !== width || overlay.height !== height) {
                overlay.width = width;
                overlay.height = height;
            }
            overlay.style.width = canvas.style.width;
            overlay.style.height = canvas.style.height;
            this.drawHighlights();
        }
    }

    /**
     * Paint the marked rectangles, once per eye the current mode shows.
     *
     * Where those eyes end up on the canvas is the inverse of what the
     * renderer's shader does to get from a canvas pixel back to a source one,
     * so the two have to agree: side by side puts the right eye a screen
     * width along, Cyberscope squeezes each eye into 256 columns, and the
     * interleaved modes double one axis and offset the right eye by a line.
     */
    protected drawHighlights(): void {
        const overlay = this.overlayCanvas;
        const context = overlay?.getContext('2d');
        if (!overlay || !context) {
            return;
        }
        context.resetTransform();
        context.clearRect(0, 0, overlay.width, overlay.height);
        if (this.highlights.length === 0) {
            return;
        }

        const { layout, eyes } = this.displayMode;
        // OVERLAY shows whichever eye it was asked for; every other layout
        // puts both of them somewhere on the canvas.
        const showLeft = layout !== VbStereoLayout.OVERLAY || eyes !== VbEyes.RIGHT;
        const showRight = layout !== VbStereoLayout.OVERLAY || eyes !== VbEyes.LEFT;

        context.strokeStyle = HIGHLIGHT_COLOR;
        context.fillStyle = HIGHLIGHT_FILL;
        context.lineWidth = HIGHLIGHT_LINE_WIDTH;
        context.setLineDash(HIGHLIGHT_DASH);

        for (const rect of this.highlights) {
            if (showLeft) {
                this.strokeEye(context, rect, 0);
            }
            if (showRight) {
                this.strokeEye(context, rect, 1);
            }
        }
    }

    /** One rectangle, placed for one eye under the current layout. */
    protected strokeEye(context: CanvasRenderingContext2D, rect: VesScreenRect, eye: 0 | 1): void {
        // The VIP draws the left eye a parallax to the left of the world's x
        // and the right eye the same distance to the right.
        const sourceX = rect.x + (eye === 0 ? -rect.parallax : rect.parallax);
        let { x, y, width, height } = { x: sourceX, y: rect.y, width: rect.width, height: rect.height };

        switch (this.displayMode.layout) {
            case VbStereoLayout.SIDE_BY_SIDE:
                x += eye * VB_SCREEN_WIDTH;
                break;
            case VbStereoLayout.CYBERSCOPE: {
                // Each eye is squeezed into half of a 512-wide canvas.
                const squeeze = (this.displayMode.width / 2) / VB_SCREEN_WIDTH;
                x = x * squeeze + eye * (this.displayMode.width / 2);
                width *= squeeze;
                break;
            }
            case VbStereoLayout.HLI:
                y = y * 2 + eye;
                height *= 2;
                break;
            case VbStereoLayout.VLI:
                x = x * 2 + eye;
                width *= 2;
                break;
            default:
                // OVERLAY draws both eyes over the same pixels.
                break;
        }

        // The fill is not dashed — setLineDash only touches the stroke — so the
        // wash is continuous under a broken outline.
        context.fillRect(x, y, width, height);
        // Half-pixel inset so a one-pixel stroke lands on a pixel rather than
        // straddling the boundary between two, which is what would blur it.
        context.strokeRect(
            x + 0.5, y + 0.5, Math.max(width - 1, 0), Math.max(height - 1, 0)
        );
    }
}
