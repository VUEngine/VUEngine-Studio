import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { arrowKeysTaken, hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { exportVipImage, VipCanvas, VipExportFile } from './emulator-vip-canvas';
import {
    decodeVipObject,
    decodeVipWorld,
    drawVipChar,
    drawVipObject,
    encodeVipObject,
    forEachVipObjectPixel,
    forEachVipWorldPixel,
    isVipObjectVisible,
    sameVipBytes,
    VIP_BGMAP_COUNT,
    VIP_BGMAP_PALETTES,
    VIP_CHAR_COUNT,
    VIP_CHAR_COUNT_EXTENDED,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SIZE,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_OAM_BASE,
    VIP_OAM_BLOCK_BYTES,
    VIP_OBJECT_BYTES,
    VIP_OBJECT_COUNT,
    VIP_OBJECT_GROUP_COUNT,
    VIP_OBJECT_GROUP_ENDS,
    VIP_OBJECT_PALETTES,
    vipCharSegmentAddress,
    vipCharSegmentCount,
    VipCharacters,
    VipEye,
    vipIntensitiesForRegister,
    VipIntensityWatcher,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VIP_WORLD_BASE,
    VIP_WORLD_BLOCK_BYTES,
    VIP_WORLD_BYTES,
    VIP_WORLD_COUNT,
    VipObject,
    vipObjectAddress,
    vipObjectExtents,
    vipObjectGroupForWorld,
    vipObjectGroupOf,
    vipObjectGroupRange,
    VipWorld,
    VipWorldMap,
    VipWorldMode,
    vipWorldSample,
    vipOverplaneSegment,
} from './emulator-vip-memory';
import { VcuColors, vcuPlacement, vipShade } from './emulator-vcu-colors';
import { VIP_CONTEXT_FACTOR, VipWorldSources } from './emulator-vip-world-sources';
import { VipObjectCluster, vipObjectClusterOf, vipObjectClusters } from './emulator-vip-object-clusters';
import { field, numberInput, stacked } from './emulator-vip-detail';
import {
    decodeVcuColorAttr,
    decodeVcuPixelAttr,
    encodeVcuColorAttr,
    encodeVcuPixelAttr,
    readVbcState,
    VbcState,
    vbcCharMask,
    VCU_CHARACTER_COLOR_BASE,
    VCU_CHARACTER_PIXEL_ATTR_BASE,
    VCU_CRAM_BASE,
    VCU_CRAM_ENTRY_BYTES,
    VCU_CRAM_PALETTE_SIZE,
    VCU_OBJ_COLOR_BASE,
    VCU_OBJ_PIXEL_ATTR_BASE,
    VCU_PIXEL_SLOT_COUNT,
    VcuColorAttr,
    VcuPixelAttr,
    vcuPlacementPalette,
    vcuRgb888,
} from './emulator-vcu-memory';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';
import { Sim } from '../core/vb-core';
import RadioSelect from '../components/kit/RadioSelect';
import Select from '../components/kit/Select';
import Switch from '../components/kit/Switch';

/**
 * Scale of the single-character preview, source pixels to screen pixels: 8
 * of them at 27 is the 216-pixel preview the sidebar is sized to hold.
 */
const CHARACTER_ZOOM = 27;

/** The screen preview is screen-sized, so it needs less zoom than a character. */
const MAX_PREVIEW_ZOOM = 4;

/** A screen position, read as a signed 10-bit field. */
const JX_MIN = -0x200;
const JX_MAX = 0x1ff;
/** ...and a parallax, as a signed 14-bit one. */
const JP_MIN = -0x2000;
const JP_MAX = 0x1fff;
/** JY is the one that is not signed: eight bits, top to bottom of the screen. */
const JY_MAX = 0xff;

/**
 * What the preview draws: the selected object on its own, or the frame it is
 * part of — the Worlds panel's two modes, asked of an object.
 *
 * Context draws every world the VIP draws, in its order, with the objects in
 * the red the hardware emits and every other world faded to gray, so that
 * what is an object and what is background can be told apart at a glance.
 */
type ObjectPreviewMode = 'solo' | 'context';

/**
 * How wide a figure's preview in the Figures list is drawn, and how tall it
 * is let to become — the width of the sidebar, as the BGMaps panel's Used by
 * previews are.
 */
const FIGURE_PREVIEW_WIDTH = 208;
const FIGURE_PREVIEW_MAX_HEIGHT = 96;
/** Small figures are blown up, but not so far that one fills the group. */
const FIGURE_PREVIEW_MAX_ZOOM = 4;

/** Whole-number zoom where the figure allows it, so its pixels stay square. */
function figurePreviewZoom(image: ImageData): number {
    const fit = Math.min(
        FIGURE_PREVIEW_WIDTH / image.width, FIGURE_PREVIEW_MAX_HEIGHT / image.height, FIGURE_PREVIEW_MAX_ZOOM
    );
    return fit >= 1 ? Math.floor(fit) : fit;
}

/** One line of the Figures list, with the picture under it. */
interface FigureEntry {
    cluster: VipObjectCluster;
    /** The object group the figure's objects are in, which is one per figure. */
    group?: number;
    image: ImageData;
}

/**
 * Dim the color just written at `offset` to the brightness Context draws the
 * worlds around the objects at — the color version of their gray.
 */
function fadeColor(pixels: Uint8ClampedArray, offset: number): void {
    pixels[offset] = Math.round(pixels[offset] * VIP_CONTEXT_FACTOR);
    pixels[offset + 1] = Math.round(pixels[offset + 1] * VIP_CONTEXT_FACTOR);
    pixels[offset + 2] = Math.round(pixels[offset + 2] * VIP_CONTEXT_FACTOR);
}

/** The group filter with every SPT register's bit set. */
const ALL_OBJECT_GROUPS = (1 << VIP_OBJECT_GROUP_COUNT) - 1;

/** The palette groups a Color Attribute can name: its low six bits. */
const VCU_GROUP_MAX = 0x3f;

/**
 * What VB Color adds to the selected object: its byte of OBJ Color Attribute
 * RAM and its halfword of OBJ Pixel Color Attribute RAM, and the colors they
 * come to.
 *
 * Only the selected object's, rather than both blocks: nothing else in the
 * panel shows them, and three bytes a poll are less than three kilobytes.
 */
interface ObjectColor {
    /** The object these were read for, so a read that raced a new selection is not shown for it. */
    index: number;
    /** As read, so that an edit can write back the bits it does not name. */
    colorByte: number;
    pixelHalfword: number;
    /**
     * The Character's own OBJ entries, read only while they are the ones in
     * effect: CHRSEL set and CXCTRL.CCEN on.
     */
    character?: { color: VcuColorAttr; pixel: VcuPixelAttr };
    /** The CRAM palette the object draws with, and its four RGB888 entries. */
    palette: number;
    colors: number[];
}

/**
 * The VIP's object attribute memory: up to 1024 sprites.
 *
 * Three columns, the shape the Worlds and BGMaps panels have: the objects as
 * tiles, the fields of the one picked, and a preview of where on screen it
 * lands — alone, or in the frame the VIP draws around it. The tiles keep to
 * the objects actually drawn by default, since most of OAM in a typical game
 * is unused slots, and can be kept to some of the four object groups.
 * Rendering the previews is what makes this panel read character memory too,
 * and in Context world and BGMap memory as well; the list on its own needs
 * only OAM.
 */
export class ObjectsPanel extends Panel {

    protected objectBytes?: Uint8Array;
    /**
     * OAM as it was before the last change to it, which is what the figures
     * are told the objects' motion by; see vipObjectClusters.
     */
    protected previousObjectBytes?: Uint8Array;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[] = [];
    /**
     * World attribute memory, read only while the preview is in Context — or
     * in color under WCEN, for the palette offset an OBJ world gives its
     * objects.
     */
    protected worldBytes?: Uint8Array;
    /** The BGMap segments and param tables of the worlds Context draws. */
    protected readonly sources = new VipWorldSources();
    /**
     * What a VB Color game has switched on, and nothing otherwise — the one
     * test every color field and the extended characters go by; see
     * readVbcState.
     */
    protected vbc?: VbcState;
    /** The selected object's color attributes, read only while `vbc` is there. */
    protected objectColor?: ObjectColor;
    /** The VCU's color tables the previews draw with, read only while they are in color. */
    protected colors?: VcuColors;
    /** Reused from pixel to pixel while drawing in color, so that drawing does not allocate per pixel. */
    protected readonly placement = vcuPlacement();
    protected readonly sample = vipWorldSample();
    protected error?: string;

    /** The object the fields and the preview describe. There is always one. */
    protected selected = 0;
    /**
     * Whether the list keeps to the objects the VIP actually draws — the ones
     * switched on for an eye. On, because most of OAM in a typical game is
     * slots nothing has been put in.
     */
    protected showOnlyDrawn = this.remembered('showOnlyDrawn', true);
    /**
     * Whether the list keeps to the figure the selected object is part of,
     * and Context grays every other object.
     */
    protected onlyFigure = this.remembered('onlyFigure', false);
    /**
     * The object groups the panel keeps to, a bit per SPT register: the list
     * leaves the others out, and Context grays their objects like the worlds
     * around them. All four by default. The objects past the last group are
     * in none of them, so no group can leave them out — the VIP never draws
     * them, which is Show Only Drawn's question rather than this one's.
     */
    protected groupFilter = this.remembered('objectGroups', ALL_OBJECT_GROUPS);
    protected eye = this.remembered('eye', 'left') as VipEye;
    protected previewMode = this.remembered('previewMode', 'context') as ObjectPreviewMode;
    protected zoom = this.remembered('zoom', 1);
    protected showExtents = this.remembered('showExtents', true);
    /**
     * Whether the previews are shaded with an even ramp instead of the object
     * palette registers. Off: they resolve the brightness registers the way
     * the core does, so the real palettes look like the picture on screen.
     */
    protected showGenericPalette = this.remembered('showGenericPalette', false);
    /**
     * Whether the previews are drawn in the colors a VB Color game shows
     * rather than the VIP's red — while the game has the VCU unlocked, which
     * is the only time the switch is there. On, since that is what is on
     * screen.
     */
    protected vbColorPreview = this.remembered('vbColorPreview', true);

    protected image?: ImageData;
    /** The figures the drawn objects make up, as last worked out; see vipObjectClusters. */
    protected clusters: VipObjectCluster[] = [];
    /** What the Figures list shows, rebuilt with the clusters. */
    protected figures: FigureEntry[] = [];
    /** The figure the pointer is on in the Figures list, by its first object. */
    protected hoveredFigure?: number;
    /**
     * Whether the selected object's figure has been let go of, by clicking
     * it again in the Figures list: the object stays selected, but nothing
     * treats it as part of a figure until another object is picked.
     */
    protected figureReleased = false;
    protected dirty = true;
    protected readonly intensityWatcher = new VipIntensityWatcher();
    /** The SPT registers as last drawn: Context's groups follow them. */
    protected groupEnds?: string;

    constructor(
        source: DebugSource,
        instanceId: string,
        /** Where Export PNG hands its file; no button without it. */
        protected readonly exportFile?: VipExportFile
    ) {
        super(EmulatorPanelType.VIP_OBJECTS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/objects/title', 'Objects');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_OBJECTS);
        // The three columns each scroll on their own, so the panel's own
        // scrolling is switched off and the layout is hung on this class,
        // which the Worlds and BGMaps panels wear too — see the stylesheet.
        this.addClass('vp-vip-panel');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.objectBytes = undefined;
            this.previousObjectBytes = undefined;
            this.clusters = [];
            this.figures = [];
            this.registers = undefined;
            this.charSegments = [];
            this.worldBytes = undefined;
            this.sources.clear();
            this.vbc = undefined;
            this.objectColor = undefined;
            this.colors = undefined;
            this.image = undefined;
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));

            // First, since it decides how wide OAM's character field is.
            const vbc = await readVbcState(this.source, sim);
            if (vbcCharMask(vbc) !== vbcCharMask(this.vbc)) {
                this.dirty = true;
            }
            this.vbc = vbc;

            const objectBytes = new Uint8Array(await sim.readMemory(VIP_OAM_BASE, VIP_OAM_BLOCK_BYTES));
            if (!sameVipBytes(objectBytes, this.objectBytes)) {
                this.previousObjectBytes = this.objectBytes;
                this.objectBytes = objectBytes;
                this.dirty = true;
            }

            await this.readCharacters(sim);
            await this.readWorlds(sim);
            await this.readColors(sim);
            this.objectColor = await this.readObjectColor(sim);

            if (this.intensityWatcher.changed(this.registers)) {
                this.dirty = true;
            }
            const registers = this.registers;
            const groupEnds = VIP_OBJECT_GROUP_ENDS.map(register => registers.getUint16(register, true)).join();
            if (groupEnds !== this.groupEnds) {
                this.groupEnds = groupEnds;
                this.dirty = true;
            }
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        if (this.dirty && this.registers) {
            // The figures first: Only Current Figure grays by them.
            const characters = new VipCharacters(this.charSegments);
            this.clusters = vipObjectClusters(
                this.objects(), this.registers, characters, this.eye,
                this.previousObjectBytes && this.objects(this.previousObjectBytes)
            );
            this.figures = this.buildFigures(this.registers, characters);
            this.image = this.rasterize(this.registers);
            this.dirty = false;
        }
        this.update();
    }

    /**
     * Read character memory: the VIP's four segments, and with CHREXT the
     * VCU's four more, which objects naming characters 2048-4095 draw from.
     * The extension's segments are let go of when CHREXT goes off, since how
     * many segments there are is what VipCharacters reads the mask from.
     */
    protected async readCharacters(sim: Sim): Promise<void> {
        const count = vipCharSegmentCount(!!this.vbc?.chrext);
        if (this.charSegments.length > count) {
            this.charSegments.length = count;
            this.dirty = true;
        }
        const segments = await Promise.all(Array.from(
            { length: count },
            (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
        ));
        segments.forEach((buffer, index) => {
            const bytes = new Uint8Array(buffer);
            if (!sameVipBytes(bytes, this.charSegments[index])) {
                this.charSegments[index] = bytes;
                this.dirty = true;
            }
        });
    }

    /**
     * Read the worlds Context draws around the objects, and the maps and
     * param tables they draw from. Solo draws the object alone, so there
     * this lets go of all of it rather than reading VRAM nothing looks at —
     * save world attribute memory in color under WCEN, where which OBJ world
     * draws an object's group decides the palette offset it is drawn with.
     */
    protected async readWorlds(sim: Sim): Promise<void> {
        const context = this.previewMode === 'context';
        if (!context && !(this.inColor() && this.vbc?.wcen)) {
            if (this.worldBytes) {
                this.worldBytes = undefined;
                this.sources.clear();
                this.dirty = true;
            }
            return;
        }
        const worldBytes = new Uint8Array(await sim.readMemory(VIP_WORLD_BASE, VIP_WORLD_BLOCK_BYTES));
        if (!sameVipBytes(worldBytes, this.worldBytes)) {
            this.worldBytes = worldBytes;
            this.dirty = true;
        }
        if (!context) {
            this.sources.clear();
        } else if (await this.sources.read(sim, this.contextWorlds())) {
            this.dirty = true;
        }
    }

    /** Whether the previews are drawn in VB Color: switched on, and a game that has it on. */
    protected inColor(): boolean {
        return !!this.vbc && this.vbColorPreview;
    }

    /**
     * Read the VCU tables drawing the previews in color takes, and let go of
     * them otherwise. Called after readWorlds, since in Context the BGMap
     * segments it read are the ones whose cells are colored — those, and the
     * segment an overplane world's OVR cell is in.
     */
    protected async readColors(sim: Sim): Promise<void> {
        const vbc = this.vbc;
        if (!vbc || !this.vbColorPreview) {
            if (this.colors) {
                this.colors = undefined;
                this.dirty = true;
            }
            return;
        }
        const segments: number[] = [];
        if (this.previewMode === 'context') {
            this.sources.bgMapSegments.forEach((bytes, segment) => bytes && segments.push(segment));
            for (const world of this.contextWorlds()) {
                const segment = vipOverplaneSegment(world);
                if (world.mode !== VipWorldMode.OBJECT && world.overplane && segment < VIP_BGMAP_COUNT) {
                    segments.push(segment);
                }
            }
        }
        const colors = await VcuColors.read(sim, vbc, { segments, objects: true, worlds: true });
        if (!colors.same(this.colors)) {
            this.dirty = true;
        }
        this.colors = colors;
    }

    /**
     * The selected object's VB Color attributes, or nothing while the game
     * has not unlocked the VCU — when every one of them would read zero.
     *
     * With CHRSEL set and CXCTRL.CCEN on, the VCU takes palette group and
     * Pixel Color Attribute from the object's Character instead, so those are
     * read too: they, not the object's own, are what is on screen. The four
     * colors are the CRAM palette that comes to, before any OBJ world's
     * palette offset (WCEN) — which world draws the object is the frame's
     * business rather than the object's.
     */
    protected async readObjectColor(sim: Sim): Promise<ObjectColor | undefined> {
        const vbc = this.vbc;
        const object = this.object();
        if (!vbc || !object) {
            return undefined;
        }
        const index = object.index;
        const [color, pixel] = await Promise.all([
            sim.readMemory(VCU_OBJ_COLOR_BASE + index, 1),
            sim.readMemory(VCU_OBJ_PIXEL_ATTR_BASE + index * 2, 2),
        ]);
        const colorByte = new Uint8Array(color)[0];
        const pixelHalfword = new DataView(pixel).getUint16(0, true);

        let character: ObjectColor['character'];
        if (decodeVcuColorAttr(colorByte).chrsel && vbc.ccen) {
            // A Cell byte and an OBJ byte per Character, the OBJ one second.
            const [characterColor, characterPixel] = await Promise.all([
                sim.readMemory(VCU_CHARACTER_COLOR_BASE + object.char * 2 + 1, 1),
                sim.readMemory(VCU_CHARACTER_PIXEL_ATTR_BASE + object.char * 2, 2),
            ]);
            character = {
                color: decodeVcuColorAttr(new Uint8Array(characterColor)[0]),
                pixel: decodeVcuPixelAttr(new DataView(characterPixel).getUint16(0, true)),
            };
        }

        const group = (character?.color ?? decodeVcuColorAttr(colorByte)).group;
        const palette = vcuPlacementPalette(group, object.palette);
        const cram = new DataView(await sim.readMemory(
            VCU_CRAM_BASE + palette * VCU_CRAM_PALETTE_SIZE * VCU_CRAM_ENTRY_BYTES,
            VCU_CRAM_PALETTE_SIZE * VCU_CRAM_ENTRY_BYTES
        ));
        const colors = Array.from({ length: VCU_CRAM_PALETTE_SIZE }, (unused, entry) =>
            cram.getUint32(entry * VCU_CRAM_ENTRY_BYTES, true));
        return { index, colorByte, pixelHalfword, character, palette, colors };
    }

    /**
     * How many bits of an object's character halfword name its character:
     * twelve under VB Color's CHREXT, the VIP's eleven otherwise.
     */
    protected charMask(): number {
        return vbcCharMask(this.vbc);
    }

    /**
     * All thirty-two worlds, in the order the VIP draws them: 31 first.
     * Empty unless the preview is in Context, the one thing that reads them
     * — or in color under WCEN, for their palette offsets.
     */
    protected allWorlds(): VipWorld[] {
        const bytes = this.worldBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return Array.from({ length: VIP_WORLD_COUNT }, (unused, position) => {
            const index = VIP_WORLD_COUNT - 1 - position;
            return decodeVipWorld(view, index, index * VIP_WORLD_BYTES);
        });
    }

    /**
     * The worlds the VIP draws into the eye being shown, in its order: up to
     * the one that ends the frame, which is not drawn itself. An OBJECT world
     * is drawn if either eye asks for it — its objects then pick their own
     * eye — and any other world only if this one does.
     */
    protected contextWorlds(): VipWorld[] {
        const worlds: VipWorld[] = [];
        for (const world of this.allWorlds()) {
            if (world.end) {
                break;
            }
            const drawn = world.mode === VipWorldMode.OBJECT
                ? world.lon || world.ron
                : this.eye === 'left' ? world.lon : world.ron;
            if (drawn) {
                worlds.push(world);
            }
        }
        return worlds;
    }

    /** The selected object, decoded out of the last read of OAM. */
    protected object(): VipObject | undefined {
        const bytes = this.objectBytes;
        if (!bytes) {
            return undefined;
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return decodeVipObject(view, this.selected, this.selected * VIP_OBJECT_BYTES, this.charMask());
    }

    /**
     * The figure the selected object is part of, or undefined for an object
     * that is a figure of one — or not drawn, and so part of none.
     */
    protected figure(): VipObjectCluster | undefined {
        if (this.figureReleased) {
            return undefined;
        }
        const cluster = vipObjectClusterOf(this.clusters, this.selected);
        return cluster && cluster.objects.length > 1 ? cluster : undefined;
    }

    /**
     * The objects Only Current Figure keeps to: the selected object's figure,
     * or the object alone when it is a figure of one.
     */
    protected figureObjects(): Set<number> {
        return new Set(this.figure()?.objects ?? [this.selected]);
    }

    /**
     * The figures of more than one object, each with a picture of it, in
     * OAM order. Built with the clusters rather than while rendering, since
     * the panel re-renders whenever the pointer moves over the list.
     */
    protected buildFigures(registers: DataView, characters: VipCharacters): FigureEntry[] {
        const bytes = this.objectBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return this.clusters
            .filter(cluster => cluster.objects.length > 1)
            .sort((a, b) => a.objects[0] - b.objects[0])
            .map(cluster => ({
                cluster,
                group: vipObjectGroupOf(registers, cluster.objects[0]),
                image: this.rasterizeFigure(registers, view, cluster, characters),
            }));
    }

    /**
     * One figure on its own, cut to the rectangle it covers: its objects
     * from the last index down, so a lower one lands on top as on screen.
     *
     * On black for the Figures list; `transparent` leaves what no object
     * draws see-through instead, for the exported file, which is a sprite
     * to be put on something else.
     */
    protected rasterizeFigure(
        registers: DataView, view: DataView, cluster: VipObjectCluster, characters: VipCharacters,
        transparent = false
    ): ImageData {
        const width = Math.max(1, Math.min(cluster.width, VIP_FRAME_BUFFER_WIDTH));
        const height = Math.max(1, Math.min(cluster.height, VIP_FRAME_BUFFER_HEIGHT));
        const pixels = new Uint8ClampedArray(width * height * 4);
        if (!transparent) {
            for (let offset = 3; offset < pixels.length; offset += 4) {
                pixels[offset] = 255;
            }
        }
        const charMask = this.charMask();
        const colors = this.inColor() ? this.colors : undefined;
        const offsets = colors && this.groupWorldOffsets(colors);
        for (let at = cluster.objects.length - 1; at >= 0; at--) {
            const index = cluster.objects[at];
            const object = decodeVipObject(view, index, index * VIP_OBJECT_BYTES, charMask);
            const extents = vipObjectExtents(object, this.eye);
            // Moved into the figure's own rectangle, by its screen position
            // rather than its fields: JY wraps, and a figure straddling the
            // top edge would otherwise come apart.
            const top = extents.y > 0xff - VIP_CHAR_SIZE ? extents.y - 0x100 : extents.y;
            const moved = { ...object, jx: object.jx - cluster.x, jy: top - cluster.y };
            if (colors && offsets) {
                this.drawObjectInColor(
                    pixels, width, height, moved, characters, registers, colors,
                    this.objectWorldOffset(offsets, registers, index)
                );
                continue;
            }
            const intensities = this.intensities(registers, object.palette);
            forEachVipObjectPixel(moved, width, height, characters, this.eye, (x, y, value) => {
                if (value !== 0) {
                    const offset = (y * width + x) * 4;
                    pixels[offset] = intensities[value];
                    pixels[offset + 3] = 255;
                }
            });
        }
        return new ImageData(pixels, width, height);
    }

    /**
     * Write the selected object's figure out as a PNG, cut to its rectangle
     * and see-through around it, in the eye and palettes the panel is set
     * to. Nothing while the selected object is not part of a figure.
     */
    protected async exportFigure(): Promise<void> {
        const figure = this.figure();
        const bytes = this.objectBytes;
        if (!this.exportFile || !figure || !bytes || !this.registers) {
            return;
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const image = this.rasterizeFigure(
            this.registers, view, figure, new VipCharacters(this.charSegments), true);
        const objects = figure.objects;
        await exportVipImage(
            this.exportFile, `figure-${objects[0]}-${objects[objects.length - 1]}-${this.eye}.png`, image);
    }

    /**
     * Pick a figure out of the list — its first object, unless one of its
     * own is picked already — or, clicked again, let go of it.
     */
    protected selectFigure(cluster: VipObjectCluster): void {
        if (!cluster.objects.includes(this.selected)) {
            this.selectObject(cluster.objects[0]);
            this.revealSelected();
            return;
        }
        // One of its own is selected already, so the click is either the
        // one that lets the figure go or the one that takes it back.
        this.figureReleased = !this.figureReleased;
        this.dirty = true;
        this.refresh();
    }

    /**
     * A click in the Figures list that lands on none of its figures — the
     * space between and under them — lets go of the selected one, as a
     * second click on it does.
     */
    protected onFiguresClick(event: React.MouseEvent): void {
        if (this.figure() && !(event.target as Element).closest('button')) {
            this.figureReleased = true;
            this.dirty = true;
            this.refresh();
        }
    }

    protected setHoveredFigure(first: number | undefined): void {
        if (this.hoveredFigure !== first) {
            this.hoveredFigure = first;
            this.update();
        }
    }

    protected setOnlyFigure(value: boolean): void {
        this.onlyFigure = this.remember('onlyFigure', value);
        this.dirty = true;
        this.refresh();
    }

    protected selectObject(index: number): void {
        if (Number.isNaN(index)) {
            return;
        }
        const selected = Math.min(VIP_OBJECT_COUNT - 1, Math.max(0, index));
        if (selected !== this.selected) {
            this.figureReleased = false;
        }
        this.selected = selected;
        this.dirty = true;
        this.refresh();
    }

    protected setShowGenericPalette(value: boolean): void {
        this.showGenericPalette = this.remember('showGenericPalette', value);
        this.dirty = true;
        this.refresh();
    }

    protected setVbColorPreview(value: boolean): void {
        this.vbColorPreview = this.remember('vbColorPreview', value);
        this.dirty = true;
        this.refresh();
    }

    protected setEye(eye: VipEye): void {
        this.eye = this.remember('eye', eye) as VipEye;
        this.dirty = true;
        this.refresh();
    }

    /**
     * Whether the preview is of the one object or of the frame around it.
     * Context draws from world and BGMap memory too, so the sources are read
     * again rather than only the picture being drawn again.
     */
    protected setPreviewMode(mode: ObjectPreviewMode): void {
        this.previewMode = this.remember('previewMode', mode) as ObjectPreviewMode;
        this.dirty = true;
        this.refresh();
    }

    /**
     * Keep the panel to the given groups. An object the list no longer holds
     * would leave the fields describing something that cannot be pointed at,
     * so the selection moves to the first object that is still listed.
     */
    protected setGroupFilter(groups: number[]): void {
        this.groupFilter = this.remember('objectGroups', groups.reduce((mask, group) => mask | 1 << group, 0));
        const listed = this.listedObjects();
        if (listed.length > 0 && !listed.some(object => object.index === this.selected)) {
            this.selectObject(listed[0].index);
            this.revealSelected();
            return;
        }
        this.dirty = true;
        this.refresh();
    }

    protected setShowOnlyDrawn(value: boolean): void {
        this.showOnlyDrawn = this.remember('showOnlyDrawn', value);
        this.update();
    }

    /** The shading an object palette produces, or the generic ramp instead. */
    protected intensities(registers: DataView, palette: number): number[] {
        return this.showGenericPalette
            ? VIP_GENERIC_PALETTE_INTENSITIES
            : vipIntensitiesForRegister(registers, VIP_OBJECT_PALETTES[palette]);
    }

    /**
     * The shade a pixel value is drawn with in color: the two bits of the
     * JPLT or GPLT register it selects, or the value itself under Generic
     * Palette — the even ramp, as the red previews draw it.
     */
    protected shade(register: number, value: number): number {
        return this.showGenericPalette ? value : vipShade(register, value);
    }

    /**
     * The palette offset WCEN has each object group drawn with: that of the
     * OBJ world that draws the group, and 0 for a group no world draws — or
     * when the world memory saying which does is not read.
     */
    protected groupWorldOffsets(colors: VcuColors): number[] {
        const offsets = Array.from({ length: VIP_OBJECT_GROUP_COUNT }, () => 0);
        const all = this.allWorlds();
        for (const world of all) {
            const group = world.mode === VipWorldMode.OBJECT ? vipObjectGroupForWorld(all, world.index) : undefined;
            if (group !== undefined) {
                offsets[group] = colors.worldOffset(world.index);
            }
        }
        return offsets;
    }

    /** One object's share of {@link groupWorldOffsets}. */
    protected objectWorldOffset(offsets: readonly number[], registers: DataView, index: number): number {
        const group = vipObjectGroupOf(registers, index);
        return group === undefined ? 0 : offsets[group];
    }

    /**
     * Paint one object in the colors the VB Color draws it with, or at the
     * faded worlds' brightness for an object Context leaves in the
     * background. A pixel the hardware leaves out — value 0 without OPQ, or
     * a Pixel Color Slot's 0xFF — is left as it is, which is the hole the
     * red previews leave for value 0.
     *
     * The character's own coordinates are worked out here rather than taken
     * from forEachVipObjectPixel, which does not pass them on: a Pixel Color
     * Slot is laid out over the unflipped character.
     */
    protected drawObjectInColor(
        pixels: Uint8ClampedArray,
        width: number,
        height: number,
        object: VipObject,
        characters: VipCharacters,
        registers: DataView,
        colors: VcuColors,
        worldOffset: number,
        faded = false
    ): void {
        const placement = colors.object(object.index, object.char, object.palette, this.placement);
        const register = registers.getUint16(VIP_OBJECT_PALETTES[object.palette], true) & 0xff;
        const left = vipObjectExtents(object, this.eye).x;
        for (let row = 0; row < VIP_CHAR_SIZE; row++) {
            const y = object.jy + row;
            if (y < 0 || y >= height) {
                continue;
            }
            const charY = object.vFlip ? VIP_CHAR_SIZE - 1 - row : row;
            for (let column = 0; column < VIP_CHAR_SIZE; column++) {
                const x = left + column;
                if (x < 0 || x >= width) {
                    continue;
                }
                const charX = object.hFlip ? VIP_CHAR_SIZE - 1 - column : column;
                const value = characters.pixel(object.char, charX, charY);
                const offset = (y * width + x) * 4;
                if (colors.put(pixels, offset, placement, value, charX, charY, this.shade(register, value), worldOffset)
                    && faded) {
                    fadeColor(pixels, offset);
                }
            }
        }
    }

    /**
     * Patch the selected object and write it back to OAM.
     *
     * The whole eight-byte entry goes back rather than the one halfword that
     * changed: an object is small enough that rewriting it whole is simpler
     * than tracking which field lives where, and the values not being edited
     * are written back exactly as they were read.
     */
    protected async writeObject(patch: Partial<VipObject>): Promise<void> {
        const sim = this.source.sim;
        const object = this.object();
        if (!sim || !object) {
            return;
        }

        const bytes: number[] = [];
        encodeVipObject({ ...object, ...patch }, this.charMask()).forEach(halfword => {
            bytes.push(halfword & 0xff, (halfword >> 8) & 0xff);
        });
        await this.source.write(vipObjectAddress(this.selected), bytes);

        this.dirty = true;
        await this.refresh();
    }

    /** The selected object's color attributes, if they were read for it. */
    protected selectedColor(): ObjectColor | undefined {
        const color = this.objectColor;
        return this.vbc && color && color.index === this.selected ? color : undefined;
    }

    /**
     * Patch the selected object's OBJ Color Attribute byte. The bit neither
     * field names is written back as it was read; see encodeVcuColorAttr.
     */
    protected async writeObjectColor(patch: Partial<VcuColorAttr>): Promise<void> {
        const color = this.selectedColor();
        if (!this.source.sim || !color) {
            return;
        }
        const byte = encodeVcuColorAttr({ ...decodeVcuColorAttr(color.colorByte), ...patch }, color.colorByte);
        await this.source.write(VCU_OBJ_COLOR_BASE + color.index, [byte]);
        await this.refresh();
    }

    /** ...and its OBJ Pixel Color Attribute halfword, the same way. */
    protected async writeObjectPixel(patch: Partial<VcuPixelAttr>): Promise<void> {
        const color = this.selectedColor();
        if (!this.source.sim || !color) {
            return;
        }
        const halfword = encodeVcuPixelAttr(
            { ...decodeVcuPixelAttr(color.pixelHalfword), ...patch }, color.pixelHalfword
        );
        await this.source.write(VCU_OBJ_PIXEL_ATTR_BASE + color.index * 2, [halfword & 0xff, (halfword >> 8) & 0xff]);
        await this.refresh();
    }

    /**
     * A screen-sized bitmap of what the preview shows.
     *
     * In Solo that is the selected object alone. In Context it is the frame
     * the VIP draws for the eye being shown: every world in its order, the
     * objects in red and every other world faded to gray. The selected object
     * is not singled out in the bitmap — the outline over it does that — so
     * the picture keeps the overlap the hardware would draw.
     *
     * In color — VB Color switched on, by the game and in the panel — both
     * are drawn in the colors the VCU gives them instead, the worlds around
     * the objects dimmed by the same factor as the gray.
     */
    protected rasterize(registers: DataView): ImageData {
        const width = VIP_FRAME_BUFFER_WIDTH;
        const height = VIP_FRAME_BUFFER_HEIGHT;
        const pixels = new Uint8ClampedArray(width * height * 4);
        for (let offset = 3; offset < pixels.length; offset += 4) {
            pixels[offset] = 255;
        }

        const characters = new VipCharacters(this.charSegments);
        if (this.previewMode === 'context') {
            this.rasterizeContext(registers, pixels, width, height, characters);
            return new ImageData(pixels, width, height);
        }

        const object = this.object();
        const colors = this.inColor() ? this.colors : undefined;
        if (object && colors) {
            this.drawObjectInColor(
                pixels, width, height, object, characters, registers, colors,
                this.objectWorldOffset(this.groupWorldOffsets(colors), registers, object.index)
            );
        } else if (object) {
            drawVipObject(
                pixels,
                width,
                height,
                object,
                characters,
                this.intensities(registers, object.palette),
                this.eye
            );
        }
        return new ImageData(pixels, width, height);
    }

    /**
     * The frame the selected object is part of, drawn into `pixels`.
     *
     * Pixel value 0 is left alone rather than painted, which is the
     * transparency the hardware gives it. Which group an OBJECT world draws
     * is decided by the drawing order, and within a group the objects are
     * drawn from the last index down, so a lower index lands on top — both
     * as the Worlds panel draws them; see vipObjectGroupForWorld.
     */
    protected rasterizeContext(
        registers: DataView,
        pixels: Uint8ClampedArray,
        width: number,
        height: number,
        characters: VipCharacters
    ): void {
        const bytes = this.objectBytes;
        const all = this.allWorlds();
        const palettes = this.showGenericPalette
            ? [0, 1, 2, 3].map(() => VIP_GENERIC_PALETTE_INTENSITIES)
            : VIP_BGMAP_PALETTES.map(register => vipIntensitiesForRegister(registers, register));
        const shades = [0, 1, 2, 3].map(palette => this.intensities(registers, palette));
        const colors = this.inColor() ? this.colors : undefined;
        const gplts = VIP_BGMAP_PALETTES.map(register => registers.getUint16(register, true) & 0xff);

        for (const world of this.contextWorlds()) {
            if (world.mode !== VipWorldMode.OBJECT && colors) {
                this.drawWorldInColor(world, pixels, width, height, characters, colors, gplts);
                continue;
            }
            if (world.mode !== VipWorldMode.OBJECT) {
                const map = new VipWorldMap(world, this.sources.bgMapSegments, characters);
                forEachVipWorldPixel(
                    world, width, height, this.eye, this.sources.params(world.index),
                    (destX, destY, x, y) => {
                        const intensity = map.intensity(x, y, palettes);
                        if (intensity === 0) {
                            return;
                        }
                        const gray = Math.round(intensity * VIP_CONTEXT_FACTOR);
                        const offset = (destY * width + destX) * 4;
                        pixels[offset] = gray;
                        pixels[offset + 1] = gray;
                        pixels[offset + 2] = gray;
                    }
                );
                continue;
            }

            const group = vipObjectGroupForWorld(all, world.index);
            const range = group === undefined ? undefined : vipObjectGroupRange(registers, group);
            if (!bytes || group === undefined || !range) {
                continue;
            }
            // A group the filter leaves out is still drawn, since it is still
            // on screen, but gray, like the worlds around the objects — and
            // so is every object outside the figure, under Only Current Figure.
            const groupFaded = (this.groupFilter & 1 << group) === 0;
            const figure = this.onlyFigure ? this.figureObjects() : undefined;
            const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
            const charMask = this.charMask();
            const worldOffset = colors ? colors.worldOffset(world.index) : 0;
            for (let index = Math.min(range.last, VIP_OBJECT_COUNT - 1); index >= range.first; index--) {
                const object = decodeVipObject(view, index, index * VIP_OBJECT_BYTES, charMask);
                if (!(this.eye === 'left' ? object.lon : object.ron)) {
                    continue;
                }
                const intensities = shades[object.palette];
                const faded = groupFaded || (figure !== undefined && !figure.has(index));
                if (colors) {
                    this.drawObjectInColor(
                        pixels, width, height, object, characters, registers, colors, worldOffset, faded
                    );
                    continue;
                }
                forEachVipObjectPixel(object, width, height, characters, this.eye, (destX, destY, value) => {
                    if (value === 0) {
                        return;
                    }
                    // Red, because that is the color the hardware emits; the
                    // other two channels are written either way, since a world
                    // under the object may have left gray in them.
                    const gray = faded ? Math.round(intensities[value] * VIP_CONTEXT_FACTOR) : 0;
                    const offset = (destY * width + destX) * 4;
                    pixels[offset] = faded ? gray : intensities[value];
                    pixels[offset + 1] = gray;
                    pixels[offset + 2] = gray;
                });
            }
        }
    }

    /**
     * One BG world of Context's frame in color, at the faded brightness the
     * worlds around the objects are drawn with — dimmed rather than grayed,
     * since in color the objects no longer stand out by being red.
     */
    protected drawWorldInColor(
        world: VipWorld,
        pixels: Uint8ClampedArray,
        width: number,
        height: number,
        characters: VipCharacters,
        colors: VcuColors,
        gplts: readonly number[]
    ): void {
        const map = new VipWorldMap(world, this.sources.bgMapSegments, characters);
        const sample = this.sample;
        const placement = this.placement;
        const worldOffset = colors.worldOffset(world.index);
        forEachVipWorldPixel(
            world, width, height, this.eye, this.sources.params(world.index),
            (destX, destY, x, y) => {
                map.sample(x, y, sample);
                colors.cell(sample.segment, sample.cell, sample.char, sample.palette, placement);
                const offset = (destY * width + destX) * 4;
                const shade = this.shade(gplts[sample.palette], sample.value);
                if (colors.put(pixels, offset, placement, sample.value, sample.charX, sample.charY, shade, worldOffset)) {
                    fadeColor(pixels, offset);
                }
            }
        );
    }

    /** Just the selected object's character, at its own zoom. */
    protected rasterizeCharacter(registers: DataView, object: VipObject): ImageData {
        const pixels = new Uint8ClampedArray(VIP_CHAR_SIZE * VIP_CHAR_SIZE * 4);
        const colors = this.inColor() ? this.colors : undefined;
        if (colors) {
            // Drawn as an object of its own at the top left, flips and all;
            // what the hardware leaves out of it stays black, as value 0 is
            // in the red one, rather than turning into a transparent hole.
            for (let offset = 3; offset < pixels.length; offset += 4) {
                pixels[offset] = 255;
            }
            const worldOffset = this.objectWorldOffset(this.groupWorldOffsets(colors), registers, object.index);
            this.drawObjectInColor(
                pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE, { ...object, jx: 0, jp: 0, jy: 0 },
                new VipCharacters(this.charSegments), registers, colors, worldOffset
            );
            return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
        }
        drawVipChar(
            pixels,
            VIP_CHAR_SIZE,
            0,
            0,
            new VipCharacters(this.charSegments),
            object.char,
            this.intensities(registers, object.palette),
            object.hFlip,
            object.vFlip
        );
        return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        const bytes = this.objectBytes;
        const registers = this.registers;
        if (!bytes || !registers) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }

        const object = this.object();
        if (!object) {
            return undefined;
        }

        // Focusable, and the arrow keys are read here rather than on the
        // list: wherever focus has landed in the panel they walk the objects.
        return <div
            className='vp-columns'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/objects/title', 'Objects')}
            onKeyDown={event => this.onPanelKey(event)}
        >
            {this.renderTiles()}
            <div className='vp-sidebar vp-scroll'>
                {this.renderObjectGroup(object, registers)}
                {this.renderPropertiesGroup(object)}
                {this.renderColorGroup(object)}
                {this.renderFiguresGroup()}
            </div>
            {this.renderPreview(object)}
        </div>;
    }

    /** Every object, decoded out of the last read of OAM — or out of `bytes`. */
    protected objects(bytes = this.objectBytes): VipObject[] {
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const charMask = this.charMask();
        return Array.from({ length: VIP_OBJECT_COUNT }, (unused, index) =>
            decodeVipObject(view, index, index * VIP_OBJECT_BYTES, charMask));
    }

    /**
     * The objects the list shows: all thousand of them, or only the ones
     * switched on for an eye, and of those only the ones in the groups the
     * filter keeps.
     */
    protected listedObjects(): VipObject[] {
        if (this.onlyFigure) {
            const figure = this.figureObjects();
            return this.objects().filter(object => figure.has(object.index));
        }
        const registers = this.registers;
        const groups = this.groupFilter;
        return this.objects().filter(object => {
            if (this.showOnlyDrawn && !isVipObjectVisible(object)) {
                return false;
            }
            if (!registers) {
                return true;
            }
            const group = vipObjectGroupOf(registers, object.index);
            return group === undefined || (groups & 1 << group) !== 0;
        });
    }

    /**
     * The objects in OAM order, boiled down to what tells them apart: the
     * index and the eyes it is drawn to on one line, the character it shows
     * and its flips under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next object does not mean leaving the one being read.
     */
    protected renderTiles(): React.ReactNode {
        const listed = this.listedObjects();
        const figure = new Set(this.figure()?.objects ?? []);
        return <div className='vp-tiles vp-scroll'>
            {listed.map(object => {
                const flips = `${object.hFlip ? 'H' : ''}${object.vFlip ? 'V' : ''}`;
                return <button
                    type='button'
                    key={object.index}
                    className={`vp-tile${isVipObjectVisible(object) ? '' : ' inactive'}`
                        + `${object.index === this.selected ? ' selected' : ''}`
                        + `${object.index !== this.selected && figure.has(object.index) ? ' related' : ''}`}
                    aria-pressed={object.index === this.selected}
                    tabIndex={-1}
                    title={hex(vipObjectAddress(object.index), 8)}
                    onClick={() => this.selectObject(object.index)}
                    onMouseEnter={() => this.light({ kind: 'object', object: object.index })}
                    onMouseLeave={() => this.light(undefined)}
                >
                    <span className='vp-tile-index'>{object.index}</span>
                    <span className='vp-tile-mark'>
                        {`${object.lon ? 'L' : '\u2013'}${object.ron ? 'R' : '\u2013'}`}
                    </span>
                    <span className='vp-tile-note'>
                        {nls.localize('vueport/debug/panels/objects/tileCharacter', 'Char {0}', object.char)}
                    </span>
                    {flips && <span className='vp-tile-flag'>{flips}</span>}
                </button>;
            })}
            {listed.length === 0 &&
                <div className='vp-footer'>
                    {this.groupFilter === ALL_OBJECT_GROUPS
                        ? nls.localize('vueport/debug/panels/objects/noObjects', 'No objects are being drawn.')
                        : nls.localize('vueport/debug/panels/objects/noGroupObjects', 'No objects in these groups.')}
                </div>
            }
        </div>;
    }

    /**
     * Walk the objects with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by index, so the keys reach what
     * the list shows and stop at its ends. The event is stopped rather than
     * only defaulted, because the emulator listens for keys on the node this
     * panel sits inside and would otherwise read an arrow as the D-pad.
     */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        const steps: Record<string, number> = {
            ArrowUp: -1, ArrowLeft: -1, ArrowDown: 1, ArrowRight: 1, PageUp: -8, PageDown: 8,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        const listed = this.listedObjects();
        if (listed.length === 0) {
            return;
        }
        const at = listed.findIndex(object => object.index === this.selected);
        const to = home ? 0 : end ? listed.length - 1 : Math.max(0, at) + step;
        this.selectObject(listed[Math.min(listed.length - 1, Math.max(0, to))].index);
        this.revealSelected();
    }

    /**
     * Select an object the screen inspector points at, letting go of a
     * filter that would leave it out of the list rather than selecting
     * something the list does not show.
     */
    reveal(target: ScreenInspectorTarget): void {
        if (target.kind !== 'object') {
            return;
        }
        if (!this.listedObjects().some(object => object.index === target.object)) {
            this.onlyFigure = this.remember('onlyFigure', false);
            this.groupFilter = this.remember('objectGroups', ALL_OBJECT_GROUPS);
        }
        this.selectObject(target.object);
        this.revealSelected();
    }

    /** Keep the picked object's tile in view, and the ring on it. */
    protected revealSelected(): void {
        requestAnimationFrame(() => {
            const tile = this.node.querySelector<HTMLElement>('.vp-tile.selected');
            tile?.scrollIntoView({ block: 'nearest' });
            tile?.focus({ preventScroll: true });
        });
    }

    /** The object itself: which one it is, and the character it shows. */
    protected renderObjectGroup(object: VipObject, registers: DataView): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/objects/object', 'Object')}</legend>
            <div className='vp-detail-fields'>
                {field(nls.localize('vueport/debug/panels/objects/index', 'Index'), object.index)}
                {field(
                    nls.localize('vueport/debug/panels/objects/address', 'Address'),
                    hex(vipObjectAddress(object.index), 8)
                )}
                {this.renderFigureField()}
            </div>
            <VipCanvas image={this.rasterizeCharacter(registers, object)} zoom={CHARACTER_ZOOM} />
        </fieldset>;
    }

    /**
     * Everything OAM holds for one object, in a grid three fields wide: what
     * it draws, where it lands, and the flags that mirror it and pick the
     * eyes it is drawn to.
     *
     * Its own height and no more: the room left over in the sidebar is the
     * Figures list's, whose length depends on the game.
     */
    protected renderPropertiesGroup(object: VipObject): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/objects/properties', 'Properties')}</legend>
            <div className='vp-scroll-body vp-scroll'>
                <div className='vp-grid'>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/character', 'Character'),
                            // Up to 4095 under VB Color's CHREXT, whose characters
                            // 2048 and up are in the VCU's extension.
                            numberInput(object.char, 0,
                                (this.vbc?.chrext ? VIP_CHAR_COUNT_EXTENDED : VIP_CHAR_COUNT) - 1,
                                value => this.writeObject({ char: value }))
                        )}
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/palette', 'Palette'),
                            <Select
                                value={String(object.palette)}
                                onChange={next => this.writeObject({ palette: parseInt(next, 10) })}
                                options={VIP_OBJECT_PALETTES.map((unused, index) => ({
                                    value: String(index),
                                    label: `JPLT${index}`,
                                }))}
                            />,
                            undefined,
                            2
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('JX', numberInput(object.jx, JX_MIN, JX_MAX,
                            value => this.writeObject({ jx: value })))}
                        {stacked('JY', numberInput(object.jy, 0, JY_MAX,
                            value => this.writeObject({ jy: value })))}
                        {stacked('JP', numberInput(object.jp, JP_MIN, JP_MAX,
                            value => this.writeObject({ jp: value })))}
                    </div>
                    {/* A pair of switches needs more than a third of the
                        group: a row each, spanning it. */}
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/flip', 'Flip'),
                            <div className='vp-flags-row'>
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/hFlip', 'H-flip'),
                                    nls.localize('vueport/debug/panels/objects/horizontal', 'H'),
                                    object.hFlip,
                                    value => this.writeObject({ hFlip: value })
                                )}
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/vFlip', 'V-flip'),
                                    nls.localize('vueport/debug/panels/objects/vertical', 'V'),
                                    object.vFlip,
                                    value => this.writeObject({ vFlip: value })
                                )}
                            </div>,
                            undefined,
                            3
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/eyes', 'Eyes'),
                            <div className='vp-flags-row'>
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/left', 'Left'),
                                    nls.localize('vueport/debug/panels/objects/leftShort', 'L'),
                                    object.lon,
                                    value => this.writeObject({ lon: value })
                                )}
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/right', 'Right'),
                                    nls.localize('vueport/debug/panels/objects/rightShort', 'R'),
                                    object.ron,
                                    value => this.writeObject({ ron: value })
                                )}
                            </div>,
                            undefined,
                            3
                        )}
                    </div>
                </div>
            </div>
        </fieldset>;
    }

    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips and the eyes are, that is its only full name.
     * `hint`, when given, is the tooltip in its place.
     */
    protected renderToggle(
        label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string
    ): React.ReactNode {
        return <span className='vp-toggle' title={hint ?? label}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{name}</span>
        </span>;
    }

    /**
     * What VB Color adds to the object: the CRAM palette it draws with, and
     * the two attributes that pick it — its OBJ Color Attribute (palette
     * group, CHRSEL) and its OBJ Pixel Color Attribute (PCE, OPQ, slot).
     *
     * Only while a VB Color game has unlocked the VCU. A bit that CXCTRL
     * leaves without effect is still shown as it stands, with a line saying
     * so, since a game setting CHRSEL before CCEN is exactly the kind of
     * thing someone opens this to find.
     */
    protected renderColorGroup(object: VipObject): React.ReactNode {
        const vbc = this.vbc;
        const color = this.selectedColor();
        if (!vbc || !color) {
            return undefined;
        }
        const own = decodeVcuColorAttr(color.colorByte);
        const pixel = decodeVcuPixelAttr(color.pixelHalfword);
        const character = color.character;
        // What draws: the Character's entries under CHRSEL with CCEN, the
        // object's own otherwise.
        const drawnPixel = character?.pixel ?? pixel;
        const first = color.palette * VCU_CRAM_PALETTE_SIZE;
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/objects/vbColor', 'VB Color')}</legend>
            <div className='vp-detail-fields'>
                {field(
                    nls.localize('vueport/debug/panels/objects/cramPalette', 'CRAM Palette'),
                    <>
                        {color.palette}
                        <span className='vp-vcu-backdrop'>
                            {color.colors.map((entry, index) => {
                                const css = vcuRgb888(entry).css;
                                return <span
                                    key={index}
                                    className='vp-vcu-backdrop-swatch'
                                    style={{ backgroundColor: css }}
                                    title={`CRAM ${hex(first + index, 3)} · ${css}`}
                                />;
                            })}
                        </span>
                    </>,
                    nls.localize(
                        'vueport/debug/panels/objects/cramPaletteHint',
                        'The palette the object draws with: its palette group times four, plus JPLTS'
                    ) + (vbc.wcen
                        ? nls.localize(
                            'vueport/debug/panels/objects/cramPaletteWorldHint',
                            ', before the palette offset of the OBJ world that draws it (WCEN)'
                        )
                        : '')
                )}
                {character && field(
                    nls.localize('vueport/debug/panels/objects/characterGroup', 'Character Group'),
                    character.color.group,
                    nls.localize(
                        'vueport/debug/panels/objects/characterGroupHint',
                        'The palette group in effect: CHRSEL is set and CXCTRL.CCEN is on, so it is Character {0}\'s',
                        object.char
                    )
                )}
                {character && field(
                    nls.localize('vueport/debug/panels/objects/characterPixels', 'Character Pixels'),
                    [
                        character.pixel.enabled ? 'PCE' : undefined,
                        character.pixel.opaque ? 'OPQ' : undefined,
                        nls.localize('vueport/debug/panels/objects/slotNumber', 'Slot {0}', character.pixel.slot),
                    ].filter(part => part !== undefined).join(' · '),
                    nls.localize(
                        'vueport/debug/panels/objects/characterPixelsHint',
                        'The Pixel Color Attribute in effect: CHRSEL is set and CXCTRL.CCEN is on, so it is'
                        + ' Character {0}\'s',
                        object.char
                    )
                )}
            </div>
            <div className='vp-grid'>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/objects/group', 'Group'),
                        numberInput(own.group, 0, VCU_GROUP_MAX, value => this.writeObjectColor({ group: value })),
                        nls.localize(
                            'vueport/debug/panels/objects/groupFieldHint',
                            'OBJ Color Attribute bits 5-0: the palette group, four CRAM palettes'
                            + ' picked between by JPLTS'
                        )
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/objects/slot', 'Slot'),
                        numberInput(pixel.slot, 0, VCU_PIXEL_SLOT_COUNT - 1,
                            value => this.writeObjectPixel({ slot: value })),
                        nls.localize(
                            'vueport/debug/panels/objects/slotHint',
                            'OBJ Pixel Color Attribute bits 9-0: the Pixel Color Slot PCE draws with'
                        ),
                        2
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/objects/colorAttribute', 'Color Attribute'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize(
                                    'vueport/debug/panels/objects/chrsel',
                                    'CHRSEL: palette and pixel attribute from the Character (with CCEN)'
                                ),
                                'CHRSEL',
                                own.chrsel,
                                value => this.writeObjectColor({ chrsel: value })
                            )}
                        </div>,
                        undefined,
                        3
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/objects/pixelAttribute', 'Pixel Attribute'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize(
                                    'vueport/debug/panels/objects/pce',
                                    'PCE: palettes per pixel from the Pixel Color Slot (with PCEN)'
                                ),
                                'PCE',
                                pixel.enabled,
                                value => this.writeObjectPixel({ enabled: value })
                            )}
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/objects/opq', 'OPQ: pixel value 0 is opaque'),
                                'OPQ',
                                pixel.opaque,
                                value => this.writeObjectPixel({ opaque: value })
                            )}
                        </div>,
                        undefined,
                        3
                    )}
                </div>
            </div>
            {own.chrsel && !vbc.ccen && <span className='hint'>{nls.localize(
                'vueport/debug/panels/objects/chrselOff',
                'CHRSEL is set, but CXCTRL.CCEN is off: the object\'s own group and pixel attribute draw it.'
            )}</span>}
            {drawnPixel.enabled && !vbc.pcen && <span className='hint'>{nls.localize(
                'vueport/debug/panels/objects/pceOff',
                'PCE is set, but CXCTRL.PCEN is off: no Pixel Color Slot is used.'
            )}</span>}
        </fieldset>;
    }

    /**
     * How the preview is drawn and what the list holds, as a bar under the
     * preview rather than a group in the sidebar: the sidebar's room belongs
     * to the object and its figures, and these are about the whole panel.
     */
    protected renderDisplayControls(): React.ReactNode {
        const registers = this.registers;
        const groups = Array.from({ length: VIP_OBJECT_GROUP_COUNT }, (unused, group) => group);
        return <div className='vp-preview-controls'>
            <div className='vp-preview-controls-range'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/objects/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={MAX_PREVIEW_ZOOM}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            {/* The three questions of what is shown — which eye, how much of
                the frame, which groups — as one row. */}
            <div className='vp-preview-controls-row'>
                <RadioSelect
                    options={[{
                        value: 'left',
                        label: nls.localize('vueport/debug/panels/objects/leftEye', 'Left Eye'),
                    }, {
                        value: 'right',
                        label: nls.localize('vueport/debug/panels/objects/rightEye', 'Right Eye'),
                    }]}
                    defaultValue={this.eye}
                    onChange={options => this.setEye(options[0].value as VipEye)}
                />
                <RadioSelect
                    options={[{
                        value: 'context',
                        label: nls.localize('vueport/debug/panels/objects/inContext', 'In Context'),
                        tooltip: this.inColor()
                            ? nls.localize(
                                'vueport/debug/panels/objects/inContextColorHint',
                                'Every world the VIP draws, in its own order, with the objects in color and the rest'
                                + ' dimmed'
                            )
                            : nls.localize(
                                'vueport/debug/panels/objects/inContextHint',
                                'Every world the VIP draws, in its own order, with the objects in red and the rest gray'
                            ),
                    }, {
                        value: 'solo',
                        label: nls.localize('vueport/debug/panels/objects/solo', 'Solo'),
                        tooltip: nls.localize(
                            'vueport/debug/panels/objects/soloHint',
                            'The selected object on its own, drawn whether or not the hardware would draw it'
                        ),
                    }]}
                    defaultValue={this.previewMode}
                    onChange={options => this.setPreviewMode(options[0].value as ObjectPreviewMode)}
                />
                {/* Beside In Context, since it is there that a group the filter
                    leaves out shows, grayed. Any number of groups can be on, none
                    included. */}
                <RadioSelect
                    options={groups.map(group => {
                        const range = registers && vipObjectGroupRange(registers, group);
                        return {
                            value: group,
                            label: `SPT${group}`,
                            tooltip: range
                                ? nls.localize(
                                    'vueport/debug/panels/objects/groupHint',
                                    'Group {0}, objects {1} to {2}',
                                    group, range.first, range.last
                                )
                                : nls.localize(
                                    'vueport/debug/panels/objects/groupEmptyHint',
                                    'Group {0}, which the SPT registers leave empty',
                                    group
                                ),
                        };
                    })}
                    defaultValue={groups.filter(group => (this.groupFilter & 1 << group) !== 0)}
                    onChange={options => this.setGroupFilter(options.map(option => option.value as number))}
                    canSelectMany
                    allowBlank
                />
            </div>
            <div className='vp-preview-controls-switches'>
                {/* Only while a VB Color game has the VCU unlocked: without
                    it there is no color to draw in. */}
                {this.vbc && this.renderToggle(
                    nls.localize('vueport/debug/panels/objects/vbColorPreview', 'Colorized'),
                    nls.localize('vueport/debug/panels/objects/vbColorPreview', 'Colorized'),
                    this.vbColorPreview,
                    value => this.setVbColorPreview(value),
                    nls.localize(
                        'vueport/debug/panels/objects/vbColorPreviewHint',
                        'Draw in the colors the VB Color shows rather than the VIP\'s red'
                    )
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/objects/genericPalette', 'Generic Palette'),
                    nls.localize('vueport/debug/panels/objects/genericPalette', 'Generic Palette'),
                    this.showGenericPalette,
                    value => this.setShowGenericPalette(value)
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/objects/showOnlyDrawn', 'Show Only Drawn'),
                    nls.localize('vueport/debug/panels/objects/showOnlyDrawn', 'Show Only Drawn'),
                    this.showOnlyDrawn,
                    value => this.setShowOnlyDrawn(value)
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/objects/showOutline', 'Show Outline'),
                    nls.localize('vueport/debug/panels/objects/showOutline', 'Show Outline'),
                    this.showExtents,
                    value => { this.showExtents = this.remember('showExtents', value); this.update(); }
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/objects/onlyFigure', 'Only Current Figure'),
                    nls.localize('vueport/debug/panels/objects/onlyFigure', 'Only Current Figure'),
                    this.onlyFigure,
                    value => this.setOnlyFigure(value)
                )}
            </div>
            {this.exportFile &&
                <div className='vp-preview-controls-row'>
                    <button
                        type='button'
                        className='vp-button secondary'
                        disabled={!this.figure()}
                        title={this.figure()
                            ? nls.localize(
                                'vueport/debug/panels/objects/exportFigureHint',
                                'Save the selected object\'s figure as a PNG, cut to its size'
                                + ' and transparent around it')
                            : nls.localize(
                                'vueport/debug/panels/objects/exportFigureNone',
                                'The selected object is not part of a figure of more than one object')}
                        onClick={() => { this.exportFigure().catch(() => undefined); }}
                    >
                        {nls.localize('vueport/debug/panels/objects/exportFigure', 'Export Figure')}
                    </button>
                </div>
            }
        </div>;
    }

    /**
     * Every figure of more than one object, with a picture of each — the
     * Objects panel's counterpart of the BGMaps panel's Used by, and built
     * the same way: the pointer outlines a figure in the preview, a click
     * picks it. The groups the SPT filter leaves out are left out here too.
     */
    protected renderFiguresGroup(): React.ReactNode {
        const current = new Set(this.figure()?.objects ?? []);
        const figures = this.figures.filter(entry =>
            entry.group === undefined || (this.groupFilter & 1 << entry.group) !== 0);
        return <fieldset
            className='vp-inspector-group vp-grows vp-objects-figures'
            onClick={event => this.onFiguresClick(event)}
        >
            <legend>{nls.localize('vueport/debug/panels/objects/figures', 'Figures')}</legend>
            <div className='vp-scroll-body vp-scroll'>
                {figures.length === 0
                    ? <span className='hint'>{nls.localize(
                        'vueport/debug/panels/objects/noFigures',
                        'No figures of more than one object are being drawn.'
                    )}</span>
                    : figures.map(({ cluster, group, image }) => {
                        const first = cluster.objects[0];
                        const selected = current.has(first);
                        return <button
                            type='button'
                            key={first}
                            className={'vp-used-by-world vp-objects-figure' + (selected ? ' selected' : '')}
                            aria-pressed={selected}
                            title={nls.localize(
                                'vueport/debug/panels/objects/figuresHint',
                                'Select this figure'
                            )}
                            onMouseEnter={() => this.setHoveredFigure(first)}
                            onMouseLeave={() => this.setHoveredFigure(undefined)}
                            onClick={() => this.selectFigure(cluster)}
                        >
                            <span className='vp-detail-field'>
                                <span className='label'>
                                    {`${first}\u2013${cluster.objects[cluster.objects.length - 1]}`}
                                    {group !== undefined && <span className='hint'>{`SPT${group}`}</span>}
                                </span>
                                <span className='value'>{nls.localize(
                                    'vueport/debug/panels/objects/figureCount',
                                    '{0} objects',
                                    cluster.objects.length
                                )}</span>
                            </span>
                            <VipCanvas image={image} zoom={figurePreviewZoom(image)} />
                        </button>;
                    })
                }
            </div>
        </fieldset>;
    }

    /**
     * How many objects the figure the selected one belongs to has, and which
     * stretch of OAM they come from. A guess, which the hint says: the
     * hardware has no notion of a figure; see vipObjectClusters.
     */
    protected renderFigureField(): React.ReactNode {
        const figure = this.figure();
        const objects = figure?.objects;
        return field(
            nls.localize('vueport/debug/panels/objects/figure', 'Figure'),
            objects
                ? nls.localize(
                    'vueport/debug/panels/objects/figureObjects',
                    '{0} objects, {1}\u2013{2}',
                    objects.length, objects[0], objects[objects.length - 1]
                )
                : '\u2013',
            nls.localize(
                'vueport/debug/panels/objects/figureHint',
                'The objects that most likely make up one figure with this one: drawn to the same eyes,'
                + ' at about the same depth, touching on screen and written as one run of OAM'
            )
        );
    }

    protected renderPreview(object: VipObject): React.ReactNode {
        // The figure under the pointer in the Figures list, while there is
        // one; the selected object's own otherwise.
        const hovered = this.hoveredFigure === undefined
            ? undefined
            : vipObjectClusterOf(this.clusters, this.hoveredFigure);
        const figure = hovered ?? this.figure();
        // The picture scrolls on its own, and the controls under it stay put
        // however far it is zoomed.
        return <div className='vp-preview vp-preview-with-controls'>
            <div className='vp-preview-view vp-scroll'>
                {this.image &&
                    <VipCanvas
                        image={this.image}
                        zoom={this.zoom}
                        extents={this.showExtents ? vipObjectExtents(object, this.eye) : undefined}
                        around={(this.showExtents || hovered) && figure ? figure : undefined}
                    />
                }
            </div>
            {this.renderDisplayControls()}
        </div>;
    }
}
