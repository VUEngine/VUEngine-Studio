import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import { arrowKeysTaken, hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { VipCanvas } from './emulator-vip-canvas';
import {
    decodeVipObject,
    drawVipChar,
    drawVipObject,
    encodeVipObject,
    isVipObjectVisible,
    sameVipBytes,
    VIP_CHAR_COUNT,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SEGMENTS,
    VIP_CHAR_SIZE,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_OAM_BASE,
    VIP_OAM_BLOCK_BYTES,
    VIP_OBJECT_BYTES,
    VIP_OBJECT_COUNT,
    VIP_OBJECT_PALETTES,
    vipCharSegmentAddress,
    VipCharacters,
    VipEye,
    vipIntensitiesForRegister,
    VipIntensityWatcher,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VipObject,
    vipObjectAddress,
} from './emulator-vip-memory';
import { field, numberInput, stacked } from './emulator-vip-detail';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';
import { Sim } from '../core/vb-core';
import RadioSelect from '../components/kit/RadioSelect';
import Select from '../components/kit/Select';
import Switch from '../components/kit/Switch';

/**
 * Scale of the single-character preview, source pixels to screen pixels: 8
 * of them at 27 is the 216-pixel preview the sidebar is sized to hold.
 */
const CHARACTER_ZOOM = 27;

/** The screen preview is screen-sized, so it needs less zoom than a character. */
const MAX_PREVIEW_ZOOM = 4;

/** A screen position, read as a signed 10-bit field. */
const JX_MIN = -0x200;
const JX_MAX = 0x1ff;
/** ...and a parallax, as a signed 14-bit one. */
const JP_MIN = -0x2000;
const JP_MAX = 0x1fff;
/** JY is the one that is not signed: eight bits, top to bottom of the screen. */
const JY_MAX = 0xff;

/**
 * The VIP's object attribute memory: up to 1024 sprites.
 *
 * Three columns, the shape the Worlds and BGMaps panels have: the objects as
 * tiles, the fields of the one picked, and a preview of where on screen it
 * lands. The tiles keep to the objects actually drawn by default, since most
 * of OAM in a typical game is unused slots. Rendering the previews is what
 * makes this panel read character memory too; the list on its own needs only
 * OAM.
 */
export class ObjectsPanel extends Panel {

    protected objectBytes?: Uint8Array;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[] = [];
    protected error?: string;

    /** The object the fields and the preview describe. There is always one. */
    protected selected = 0;
    /**
     * Whether the list keeps to the objects the VIP actually draws — the ones
     * switched on for an eye. On, because most of OAM in a typical game is
     * slots nothing has been put in.
     */
    protected showOnlyDrawn = this.remembered('showOnlyDrawn', true);
    protected eye = this.remembered('eye', 'left') as VipEye;
    protected zoom = this.remembered('zoom', 1);
    /**
     * Whether the previews are shaded with an even ramp instead of the object
     * palette registers. Off: they resolve the brightness registers the way
     * the core does, so the real palettes look like the picture on screen.
     */
    protected showGenericPalette = this.remembered('showGenericPalette', false);

    protected image?: ImageData;
    protected dirty = true;
    protected readonly intensityWatcher = new VipIntensityWatcher();

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.VIP_OBJECTS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/objects/title', 'Objects');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_OBJECTS);
        // The three columns each scroll on their own, so the panel's own
        // scrolling is switched off and the layout is hung on this class,
        // which the Worlds and BGMaps panels wear too — see the stylesheet.
        this.addClass('vp-vip-panel');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.objectBytes = undefined;
            this.registers = undefined;
            this.charSegments = [];
            this.image = undefined;
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));

            const objectBytes = new Uint8Array(await sim.readMemory(VIP_OAM_BASE, VIP_OAM_BLOCK_BYTES));
            if (!sameVipBytes(objectBytes, this.objectBytes)) {
                this.objectBytes = objectBytes;
                this.dirty = true;
            }

            await this.readCharacters(sim);

            if (this.intensityWatcher.changed(this.registers)) {
                this.dirty = true;
            }
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        if (this.dirty && this.registers) {
            this.image = this.rasterize(this.registers);
            this.dirty = false;
        }
        this.update();
    }

    protected async readCharacters(sim: Sim): Promise<void> {
        const segments = await Promise.all(VIP_CHAR_SEGMENTS.map(
            (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
        ));
        segments.forEach((buffer, index) => {
            const bytes = new Uint8Array(buffer);
            if (!sameVipBytes(bytes, this.charSegments[index])) {
                this.charSegments[index] = bytes;
                this.dirty = true;
            }
        });
    }

    /** The selected object, decoded out of the last read of OAM. */
    protected object(): VipObject | undefined {
        const bytes = this.objectBytes;
        if (!bytes) {
            return undefined;
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return decodeVipObject(view, this.selected, this.selected * VIP_OBJECT_BYTES);
    }

    protected selectObject(index: number): void {
        if (Number.isNaN(index)) {
            return;
        }
        this.selected = Math.min(VIP_OBJECT_COUNT - 1, Math.max(0, index));
        this.dirty = true;
        this.refresh();
    }

    protected setShowGenericPalette(value: boolean): void {
        this.showGenericPalette = this.remember('showGenericPalette', value);
        this.dirty = true;
        this.refresh();
    }

    protected setEye(eye: VipEye): void {
        this.eye = this.remember('eye', eye) as VipEye;
        this.dirty = true;
        this.refresh();
    }

    protected setShowOnlyDrawn(value: boolean): void {
        this.showOnlyDrawn = this.remember('showOnlyDrawn', value);
        this.update();
    }

    /** The shading an object palette produces, or the generic ramp instead. */
    protected intensities(registers: DataView, palette: number): number[] {
        return this.showGenericPalette
            ? VIP_GENERIC_PALETTE_INTENSITIES
            : vipIntensitiesForRegister(registers, VIP_OBJECT_PALETTES[palette]);
    }

    /**
     * Patch the selected object and write it back to OAM.
     *
     * The whole eight-byte entry goes back rather than the one halfword that
     * changed: an object is small enough that rewriting it whole is simpler
     * than tracking which field lives where, and the values not being edited
     * are written back exactly as they were read.
     */
    protected async writeObject(patch: Partial<VipObject>): Promise<void> {
        const sim = this.source.sim;
        const object = this.object();
        if (!sim || !object) {
            return;
        }

        const bytes: number[] = [];
        encodeVipObject({ ...object, ...patch }).forEach(halfword => {
            bytes.push(halfword & 0xff, (halfword >> 8) & 0xff);
        });
        await this.source.write(vipObjectAddress(this.selected), bytes);

        this.dirty = true;
        await this.refresh();
    }

    /** A screen-sized bitmap of what the selected object alone draws. */
    protected rasterize(registers: DataView): ImageData {
        const width = VIP_FRAME_BUFFER_WIDTH;
        const height = VIP_FRAME_BUFFER_HEIGHT;
        const pixels = new Uint8ClampedArray(width * height * 4);
        for (let offset = 3; offset < pixels.length; offset += 4) {
            pixels[offset] = 255;
        }

        const object = this.object();
        if (object) {
            drawVipObject(
                pixels,
                width,
                height,
                object,
                new VipCharacters(this.charSegments),
                this.intensities(registers, object.palette),
                this.eye
            );
        }
        return new ImageData(pixels, width, height);
    }

    /** Just the selected object's character, at its own zoom. */
    protected rasterizeCharacter(registers: DataView, object: VipObject): ImageData {
        const pixels = new Uint8ClampedArray(VIP_CHAR_SIZE * VIP_CHAR_SIZE * 4);
        drawVipChar(
            pixels,
            VIP_CHAR_SIZE,
            0,
            0,
            new VipCharacters(this.charSegments),
            object.char,
            this.intensities(registers, object.palette),
            object.hFlip,
            object.vFlip
        );
        return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        const bytes = this.objectBytes;
        const registers = this.registers;
        if (!bytes || !registers) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }

        const object = this.object();
        if (!object) {
            return undefined;
        }

        // Focusable, and the arrow keys are read here rather than on the
        // list: wherever focus has landed in the panel they walk the objects.
        return <div
            className='vp-columns'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/objects/title', 'Objects')}
            onKeyDown={event => this.onPanelKey(event)}
        >
            {this.renderTiles()}
            <div className='vp-sidebar vp-scroll'>
                {this.renderObjectGroup(object, registers)}
                {this.renderPropertiesGroup(object)}
                {this.renderDisplayGroup()}
            </div>
            {this.renderPreview()}
        </div>;
    }

    /** Every object, decoded out of the last read of OAM. */
    protected objects(): VipObject[] {
        const bytes = this.objectBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return Array.from({ length: VIP_OBJECT_COUNT }, (unused, index) =>
            decodeVipObject(view, index, index * VIP_OBJECT_BYTES));
    }

    /**
     * The objects the list shows: all thousand of them, or only the ones
     * switched on for an eye.
     */
    protected listedObjects(): VipObject[] {
        const objects = this.objects();
        return this.showOnlyDrawn ? objects.filter(isVipObjectVisible) : objects;
    }

    /**
     * The objects in OAM order, boiled down to what tells them apart: the
     * index and the eyes it is drawn to on one line, the character it shows
     * and its flips under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next object does not mean leaving the one being read.
     */
    protected renderTiles(): React.ReactNode {
        const listed = this.listedObjects();
        return <div className='vp-tiles vp-scroll'>
            {listed.map(object => {
                const flips = `${object.hFlip ? 'H' : ''}${object.vFlip ? 'V' : ''}`;
                return <button
                    type='button'
                    key={object.index}
                    className={`vp-tile${isVipObjectVisible(object) ? '' : ' inactive'}`
                        + `${object.index === this.selected ? ' selected' : ''}`}
                    aria-pressed={object.index === this.selected}
                    tabIndex={-1}
                    title={hex(vipObjectAddress(object.index), 8)}
                    onClick={() => this.selectObject(object.index)}
                >
                    <span className='vp-tile-index'>{object.index}</span>
                    <span className='vp-tile-mark'>
                        {`${object.lon ? 'L' : '\u2013'}${object.ron ? 'R' : '\u2013'}`}
                    </span>
                    <span className='vp-tile-note'>
                        {nls.localize('vueport/debug/panels/objects/tileCharacter', 'Char {0}', object.char)}
                    </span>
                    {flips && <span className='vp-tile-flag'>{flips}</span>}
                </button>;
            })}
            {listed.length === 0 &&
                <div className='vp-footer'>
                    {nls.localize('vueport/debug/panels/objects/noObjects', 'No objects are being drawn.')}
                </div>
            }
        </div>;
    }

    /**
     * Walk the objects with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by index, so the keys reach what
     * the list shows and stop at its ends. The event is stopped rather than
     * only defaulted, because the emulator listens for keys on the node this
     * panel sits inside and would otherwise read an arrow as the D-pad.
     */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        const steps: Record<string, number> = {
            ArrowUp: -1, ArrowLeft: -1, ArrowDown: 1, ArrowRight: 1, PageUp: -8, PageDown: 8,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        const listed = this.listedObjects();
        if (listed.length === 0) {
            return;
        }
        const at = listed.findIndex(object => object.index === this.selected);
        const to = home ? 0 : end ? listed.length - 1 : Math.max(0, at) + step;
        this.selectObject(listed[Math.min(listed.length - 1, Math.max(0, to))].index);
        this.revealSelected();
    }

    /** Keep the picked object's tile in view, and the ring on it. */
    protected revealSelected(): void {
        requestAnimationFrame(() => {
            const tile = this.node.querySelector<HTMLElement>('.vp-tile.selected');
            tile?.scrollIntoView({ block: 'nearest' });
            tile?.focus({ preventScroll: true });
        });
    }

    /** The object itself: which one it is, and the character it shows. */
    protected renderObjectGroup(object: VipObject, registers: DataView): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/objects/object', 'Object')}</legend>
            <div className='vp-detail-fields'>
                {field(nls.localize('vueport/debug/panels/objects/index', 'Index'), object.index)}
                {field(
                    nls.localize('vueport/debug/panels/objects/address', 'Address'),
                    hex(vipObjectAddress(object.index), 8)
                )}
            </div>
            <VipCanvas image={this.rasterizeCharacter(registers, object)} zoom={CHARACTER_ZOOM} />
        </fieldset>;
    }

    /**
     * Everything OAM holds for one object, in a grid three fields wide: what
     * it draws, where it lands, and the flags that mirror it and pick the
     * eyes it is drawn to.
     */
    protected renderPropertiesGroup(object: VipObject): React.ReactNode {
        return <fieldset className='vp-inspector-group vp-grows'>
            <legend>{nls.localize('vueport/debug/panels/objects/properties', 'Properties')}</legend>
            <div className='vp-scroll-body vp-scroll'>
                <div className='vp-grid'>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/character', 'Character'),
                            numberInput(object.char, 0, VIP_CHAR_COUNT - 1,
                                value => this.writeObject({ char: value }))
                        )}
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/palette', 'Palette'),
                            <Select
                                value={String(object.palette)}
                                onChange={next => this.writeObject({ palette: parseInt(next, 10) })}
                                options={VIP_OBJECT_PALETTES.map((unused, index) => ({
                                    value: String(index),
                                    label: `JPLT${index}`,
                                }))}
                            />,
                            undefined,
                            2
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('JX', numberInput(object.jx, JX_MIN, JX_MAX,
                            value => this.writeObject({ jx: value })))}
                        {stacked('JY', numberInput(object.jy, 0, JY_MAX,
                            value => this.writeObject({ jy: value })))}
                        {stacked('JP', numberInput(object.jp, JP_MIN, JP_MAX,
                            value => this.writeObject({ jp: value })))}
                    </div>
                    {/* A pair of switches needs more than a third of the
                        group: a row each, spanning it. */}
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/flip', 'Flip'),
                            <div className='vp-flags-row'>
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/hFlip', 'H-flip'),
                                    nls.localize('vueport/debug/panels/objects/horizontal', 'H'),
                                    object.hFlip,
                                    value => this.writeObject({ hFlip: value })
                                )}
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/vFlip', 'V-flip'),
                                    nls.localize('vueport/debug/panels/objects/vertical', 'V'),
                                    object.vFlip,
                                    value => this.writeObject({ vFlip: value })
                                )}
                            </div>,
                            undefined,
                            3
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/objects/eyes', 'Eyes'),
                            <div className='vp-flags-row'>
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/left', 'Left'),
                                    nls.localize('vueport/debug/panels/objects/leftShort', 'L'),
                                    object.lon,
                                    value => this.writeObject({ lon: value })
                                )}
                                {this.renderToggle(
                                    nls.localize('vueport/debug/panels/objects/right', 'Right'),
                                    nls.localize('vueport/debug/panels/objects/rightShort', 'R'),
                                    object.ron,
                                    value => this.writeObject({ ron: value })
                                )}
                            </div>,
                            undefined,
                            3
                        )}
                    </div>
                </div>
            </div>
        </fieldset>;
    }

    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips and the eyes are, that is its only full name.
     */
    protected renderToggle(
        label: string, name: string, value: boolean, onChange: (value: boolean) => void
    ): React.ReactNode {
        return <span className='vp-toggle' title={label}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{name}</span>
        </span>;
    }

    protected renderDisplayGroup(): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/objects/display', 'Display')}</legend>
            {/* Name, track and readout as three columns, the way the other
                VIP panels lay their sliders out. */}
            <div className='vp-ranges'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/objects/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={MAX_PREVIEW_ZOOM}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            <RadioSelect
                options={[{
                    value: 'left',
                    label: nls.localize('vueport/debug/panels/objects/leftEye', 'Left Eye'),
                }, {
                    value: 'right',
                    label: nls.localize('vueport/debug/panels/objects/rightEye', 'Right Eye'),
                }]}
                defaultValue={this.eye}
                onChange={options => this.setEye(options[0].value as VipEye)}
                fitSpace
            />
            {this.renderToggle(
                nls.localize('vueport/debug/panels/objects/genericPalette', 'Generic Palette'),
                nls.localize('vueport/debug/panels/objects/genericPalette', 'Generic Palette'),
                this.showGenericPalette,
                value => this.setShowGenericPalette(value)
            )}
            {this.renderToggle(
                nls.localize('vueport/debug/panels/objects/showOnlyDrawn', 'Show Only Drawn'),
                nls.localize('vueport/debug/panels/objects/showOnlyDrawn', 'Show Only Drawn'),
                this.showOnlyDrawn,
                value => this.setShowOnlyDrawn(value)
            )}
        </fieldset>;
    }

    protected renderPreview(): React.ReactNode {
        return this.image
            ? <div className='vp-preview vp-scroll'>
                <VipCanvas image={this.image} zoom={this.zoom} />
            </div>
            : undefined;
    }
}
