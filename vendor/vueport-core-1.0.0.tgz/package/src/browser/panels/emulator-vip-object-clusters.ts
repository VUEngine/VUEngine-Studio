import {
    isVipObjectVisible,
    VIP_CHAR_SIZE,
    VipCharacters,
    VipEye,
    VipObject,
    vipObjectExtents,
    vipObjectGroupOf,
} from './emulator-vip-memory';

/**
 * One guess at a figure the game has put together out of objects: which of
 * them it is made of, and the screen rectangle they cover for one eye.
 */
export interface VipObjectCluster {
    /** The objects' indexes, lowest first. */
    objects: number[];
    x: number;
    y: number;
    width: number;
    height: number;
}

/**
 * How many slots may lie between two objects of one figure in OAM.
 *
 * Engines write a sprite's objects as one run, and a cell of it with nothing
 * to draw may still take a slot — switched off rather than left out — so a
 * run is allowed a few holes before it counts as two.
 */
const MAX_INDEX_GAP = 4;

/**
 * How far apart in depth two objects of one figure may be.
 *
 * Not zero: games give a figure relief by setting its layers a step or two
 * apart — Jack Bros draws its characters' bodies at JP 4 and the details on
 * them at 5 — while two figures that are meant to be apart in depth are
 * usually further apart than that.
 */
const MAX_PARALLAX_GAP = 2;

/**
 * How far two objects may disagree about how far they moved since the last
 * look, in pixels per axis, and still count as moving alike.
 *
 * Not zero: a figure's cells shift against each other a little from one
 * animation frame to the next — Wario Land's by three or four pixels.
 */
const MAX_MOTION_GAP = 4;

/**
 * How much of a figure's motion has to be known, and how much of what is
 * known has to fall into groups that moved alike, before the figure is split
 * along them. Anything less is more likely slots being handed out afresh
 * than two things going their own ways.
 */
const MIN_KNOWN_MOTION = 0.75;
const MIN_GROUPED_MOTION = 0.9;

/**
 * How far an object may have moved for the move to count as one.
 *
 * Further than this, and the slot most likely holds a different object than
 * last time — games hand OAM out afresh every frame, and a slot then jumps
 * from one figure to another. Its motion is then unknown rather than wrong.
 */
const MAX_MOTION = 32;

/**
 * Group the drawn objects into the figures they most likely make up.
 *
 * The hardware has no such thing — OAM is a flat list of 8×8 cells — so this
 * is a guess from three things a figure's objects nearly always share:
 *
 * - They sit next to each other on screen: two of them are linked when their
 *   cells touch or overlap, corners included.
 * - They sit at about the same depth, since a figure whose parts had very
 *   different parallax would come apart in 3D, and they are drawn to the
 *   same eyes: Wario Land, for one, draws its hero as two sets of objects,
 *   one per eye. This is what separates two figures that merely touch on
 *   screen.
 * - They are one run of OAM, in one object group: a sprite's objects are
 *   written together, so a run that breaks — a gap of more than a few slots,
 *   or an SPT boundary — ends one figure even where the next one touches it.
 *
 * Given `previous` — the objects as they were at the last look — there is a
 * fourth, since a figure moves as one: a figure whose objects clearly moved
 * in two or more different ways is split along them. That is what tells two
 * figures apart that touch, at one depth, in one run of OAM, which the other
 * three cannot. It is applied with care, because what it compares is slots
 * rather than objects: Wario Land rearranges its hero's slots with every
 * frame of animation, so a figure is only split when nearly all of its
 * motion is known and nearly all of that falls into a few clear groups, well
 * apart — see splitByMotion.
 *
 * Linking is transitive, so a figure only needs each of its cells to touch
 * one other. Objects the VIP does not draw — switched off for both eyes, or
 * past the last group — are left out, and so are objects whose character is
 * blank: games park unused objects that way, often right next to a figure,
 * and one of those would join two figures that have nothing to do with each
 * other. An object that touches nothing is a figure of one.
 */
export function vipObjectClusters(
    objects: readonly VipObject[],
    registers: DataView,
    characters: VipCharacters,
    eye: VipEye,
    previous?: readonly VipObject[]
): VipObjectCluster[] {
    const blank = new Map<number, boolean>();
    const isBlank = (char: number): boolean => {
        let answer = blank.get(char);
        if (answer === undefined) {
            answer = true;
            for (let pixel = 0; pixel < VIP_CHAR_SIZE * VIP_CHAR_SIZE && answer; pixel++) {
                answer = characters.pixel(char, pixel % VIP_CHAR_SIZE, pixel / VIP_CHAR_SIZE | 0) === 0;
            }
            blank.set(char, answer);
        }
        return answer;
    };
    // An object past the last group is never drawn, whatever its eye bits
    // say, and is usually a stale entry a game has stopped counting.
    const drawn = objects.filter(object =>
        isVipObjectVisible(object)
        && vipObjectGroupOf(registers, object.index) !== undefined
        && !isBlank(object.char));

    // Runs of OAM: consecutive drawn objects, in one group, with no more than
    // a few slots between them.
    const run = new Map<number, number>();
    let current = -1;
    drawn.forEach((object, position) => {
        const before = drawn[position - 1];
        if (!before
            || object.index - before.index > MAX_INDEX_GAP
            || vipObjectGroupOf(registers, object.index) !== vipObjectGroupOf(registers, before.index)) {
            current++;
        }
        run.set(object.index, current);
    });

    // Union-find over the drawn objects, by position in `drawn`.
    const parent = drawn.map((unused, position) => position);
    const find = (position: number): number => {
        while (parent[position] !== position) {
            parent[position] = parent[parent[position]];
            position = parent[position];
        }
        return position;
    };

    // Only objects of one run can be linked, and a run is a short stretch of
    // OAM, so each object is compared with the ones after it in its run.
    for (let a = 0; a < drawn.length; a++) {
        for (let b = a + 1; b < drawn.length && run.get(drawn[b].index) === run.get(drawn[a].index); b++) {
            if (objectsLinked(drawn[a], drawn[b])) {
                parent[find(b)] = find(a);
            }
        }
    }

    const members = new Map<number, VipObject[]>();
    drawn.forEach((object, position) => {
        const root = find(position);
        const list = members.get(root);
        if (list) {
            list.push(object);
        } else {
            members.set(root, [object]);
        }
    });

    return [...members.values()].flatMap(list => splitByMotion(list, previous)).map(list => {
        // With JY read the way objectRow reads it, so that a figure
        // straddling the top edge is outlined where it is.
        const extents = list.map(object => ({ ...vipObjectExtents(object, eye), y: objectRow(object) }));
        const left = Math.min(...extents.map(extent => extent.x));
        const top = Math.min(...extents.map(extent => extent.y));
        const right = Math.max(...extents.map(extent => extent.x + extent.width));
        const bottom = Math.max(...extents.map(extent => extent.y + extent.height));
        return {
            objects: list.map(object => object.index),
            x: left,
            y: top,
            width: right - left,
            height: bottom - top,
        };
    });
}

/** The figure the given object is part of, if it is drawn at all. */
export function vipObjectClusterOf(
    clusters: readonly VipObjectCluster[], index: number
): VipObjectCluster | undefined {
    return clusters.find(cluster => cluster.objects.includes(index));
}

/**
 * JY is eight bits and wraps: an object a few rows above the top of the
 * screen is written as a value near 255. Read that way, it would be two
 * hundred rows away from the parts of its figure that are on screen.
 */
function objectRow(object: VipObject): number {
    return object.jy > 0xff - VIP_CHAR_SIZE ? object.jy - 0x100 : object.jy;
}

/**
 * Whether two objects are drawn to the same eyes, at about one depth, and
 * their cells touch or overlap.
 */
function objectsLinked(a: VipObject, b: VipObject): boolean {
    return a.lon === b.lon
        && a.ron === b.ron
        && Math.abs(a.jp - b.jp) <= MAX_PARALLAX_GAP
        && Math.abs(a.jx - b.jx) <= VIP_CHAR_SIZE
        && Math.abs(objectRow(a) - objectRow(b)) <= VIP_CHAR_SIZE;
}

/**
 * How far an object moved since `previous` was read, or undefined when that
 * cannot be told: nothing to compare with, a slot that was not drawn to the
 * same eyes then, or a jump too far to be the same object moving.
 */
function motionOf(
    object: VipObject, previous: readonly VipObject[] | undefined
): { x: number, y: number } | undefined {
    const before = previous?.[object.index];
    if (!before || before.lon !== object.lon || before.ron !== object.ron) {
        return undefined;
    }
    const x = object.jx - before.jx;
    const y = objectRow(object) - objectRow(before);
    return Math.abs(x) <= MAX_MOTION && Math.abs(y) <= MAX_MOTION ? { x, y } : undefined;
}

/**
 * One figure, or the figures it turns out to be once its motion is looked at.
 *
 * The objects' motions are sorted into groups that moved alike. The figure
 * stays whole unless most of its motion is known, nearly all of that is in
 * groups of two objects or more, and at least two of those groups moved
 * clearly differently — further apart than any animation would shift a
 * figure's own cells. It is then split: each object goes with its group, an
 * object whose motion is not known goes with a neighbour whose is, and each
 * group falls apart further if its objects do not touch.
 */
function splitByMotion(list: VipObject[], previous: readonly VipObject[] | undefined): VipObject[][] {
    if (!previous || list.length < 4) {
        return [list];
    }
    const motions = new Map<number, { x: number, y: number }>();
    list.forEach(object => {
        const motion = motionOf(object, previous);
        if (motion) {
            motions.set(object.index, motion);
        }
    });
    if (motions.size < 4 || motions.size < list.length * MIN_KNOWN_MOTION) {
        return [list];
    }

    // Grouped around the first motion of each group: fine for groups as far
    // apart as the ones that are acted on have to be.
    const groups: { x: number, y: number, objects: number[] }[] = [];
    motions.forEach((motion, index) => {
        const group = groups.find(candidate =>
            Math.abs(candidate.x - motion.x) <= MAX_MOTION_GAP && Math.abs(candidate.y - motion.y) <= MAX_MOTION_GAP);
        if (group) {
            group.objects.push(index);
        } else {
            groups.push({ ...motion, objects: [index] });
        }
    });
    const solid = groups.filter(group => group.objects.length > 1);
    const grouped = solid.reduce((sum, group) => sum + group.objects.length, 0);
    const apart = solid.some(a => solid.some(b =>
        Math.abs(a.x - b.x) > 2 * MAX_MOTION_GAP || Math.abs(a.y - b.y) > 2 * MAX_MOTION_GAP));
    if (solid.length < 2 || grouped < motions.size * MIN_GROUPED_MOTION || !apart) {
        return [list];
    }

    // Label each object with its group, then hand the unlabelled ones — not
    // known, or in a group of one — the label of a labelled neighbour, until
    // there is nothing left to hand out.
    const label = new Map<number, number>();
    solid.forEach((group, id) => group.objects.forEach(index => label.set(index, id)));
    for (let changed = true; changed;) {
        changed = false;
        for (const object of list) {
            if (label.has(object.index)) {
                continue;
            }
            const neighbour = list.find(other => label.has(other.index) && objectsLinked(object, other));
            if (neighbour) {
                label.set(object.index, label.get(neighbour.index)!);
                changed = true;
            }
        }
    }

    // Components of touching objects with one label each.
    const parts: VipObject[][] = [];
    const placed = new Set<number>();
    for (const seed of list) {
        if (placed.has(seed.index)) {
            continue;
        }
        const part = [seed];
        placed.add(seed.index);
        for (let at = 0; at < part.length; at++) {
            for (const other of list) {
                if (!placed.has(other.index)
                    && label.get(other.index) === label.get(part[at].index)
                    && objectsLinked(part[at], other)) {
                    placed.add(other.index);
                    part.push(other);
                }
            }
        }
        parts.push(part.sort((a, b) => a.index - b.index));
    }
    return parts;
}
