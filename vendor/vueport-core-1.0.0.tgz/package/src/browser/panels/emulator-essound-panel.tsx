import { MusicNotes, Plug } from '@phosphor-icons/react';
import { formatLogTime } from '../../common/emulator-log';
import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import EmptyContainer from '../components/kit/EmptyContainer';
import {
    ES_SOUND_FIRST_MP3,
    ES_SOUND_FIRST_WAV,
    ES_SOUND_LAST_MP3,
    ES_SOUND_LAST_WAV,
} from '../../common/emulator-essound';
import { ES_SOUND_HISTORY_LENGTH, EsSoundPlayer } from '../emulator-essound-player';
import { EmulatorPanelType, hex, DebugSource, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import HContainer from '../components/kit/HContainer';

export class EsSoundPanel extends Panel {

    constructor(
        source: DebugSource,
        instanceId: string,
        protected readonly player: EsSoundPlayer
    ) {
        super(EmulatorPanelType.ES_SOUND, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/esSound', 'ESSound');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.ES_SOUND);
        this.addClass('vp-split');
        this.toDispose.push(this.player.onDidChange(() => this.update()));
    }

    protected startPolling(): void {
        this.refresh();
    }

    protected refresh(): void {
        this.update();
    }

    protected render(): React.ReactNode {
        if (!this.player.isScanned) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }

        const tracks = this.player.list;
        const playing = this.player.playing;
        // Where the last scan looked, and why it could not. "None found" reads
        // the same whether the folder was empty, holds files named something
        // the hardware would never ask for, or could not be read at all — so
        // the folder is named and any refusal repeated verbatim.
        const lookedIn = this.player.lookedIn;
        const failure = this.player.scanFailure;

        return <>
            {tracks.length === 0
                ? <EmptyContainer
                    title={failure
                        ? nls.localize('vueport/debug/panels/esSound/unreadable', 'The ROM\'s folder could not be read')
                        : nls.localize('vueport/debug/panels/esSound/noFiles', 'No ESSound audio files found')}
                    description={failure
                        ? nls.localize(
                            'vueport/debug/panels/esSound/unreadableDescription',
                            'Looked in {0}: {1}',
                            lookedIn ?? '?', failure)
                        : nls.localize(
                            'vueport/debug/panels/esSound/noFilesDescription',
                            'Put {0} up to {1} and/or {2} up to {3} next to the ROM, then load it again. Until there is \
something to play, the emulator will pretend that it does not support ESSound. Looked in {4}.',
                            `${ES_SOUND_FIRST_MP3}.mp3`,
                            `${ES_SOUND_LAST_MP3}.mp3`,
                            `${ES_SOUND_FIRST_WAV}.wav`,
                            `${ES_SOUND_LAST_WAV}.wav`,
                            lookedIn ?? '?',
                        )}
                    icon={<MusicNotes size={32} />}
                />
                : <HContainer>
                    <fieldset className='vp-inspector-group vp-essound-files'>
                        <legend>
                            {nls.localize('vueport/debug/panels/esSound/files', 'Files')}
                        </legend>
                        <table className='vp-table vp-essound-table'>
                            <thead>
                                <tr>
                                    <th>{nls.localize('vueport/debug/panels/esSound/track', 'Track')}</th>
                                    <th>{nls.localize('vueport/general/file', 'File')}</th>
                                    <th>{nls.localize('vueport/debug/panels/esSound/size', 'Size')}</th>
                                    <th>{nls.localize('vueport/debug/panels/esSound/state', 'State')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {tracks.map(track => (
                                    <tr key={track.id}>
                                        <td>{track.id}</td>
                                        <td className='name'>{track.name}</td>
                                        <td>{Math.round(track.size / 1024)} KB</td>
                                        <td>{playing.includes(track.id)
                                            ? nls.localize('vueport/debug/panels/esSound/playing', 'Playing')
                                            : ''}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </fieldset>
                    {this.renderHistory()}
                </HContainer>
            }
        </>;
    }

    protected renderHistory(): React.ReactNode {
        const commands = this.player.commands;
        return <div className='vp-detail vp-scroll'>
            <fieldset className='vp-inspector-group vp-essound-history vp-scroll'>
                <legend>
                    {nls.localize('vueport/debug/panels/esSound/lastCommands', 'Last {0} Commands', ES_SOUND_HISTORY_LENGTH)}
                </legend>
                {commands.length === 0
                    ? <div className='vp-footer'>
                        {nls.localize('vueport/debug/panels/esSound/noCommands', 'The game has not written to the ESSound port.')}
                    </div>
                    : <table className='vp-table vp-essound-table'>
                        <tbody>
                            {commands.map((entry, index) => (
                                <tr key={index} className={entry.problem ? 'inactive' : ''} title={entry.problem}>
                                    <td className='vp-log-time'>{formatLogTime(entry.time)}</td>
                                    <td><code>{hex(entry.message.raw, 4)}</code></td>
                                    <td className='name'>{entry.description}</td>
                                    <td className='name'>{entry.problem ?? ''}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                }
            </fieldset>
        </div>;
    }
}
