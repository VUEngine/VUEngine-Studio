import { Message } from '@lumino/messaging';
import { CaretDown, CaretRight, Gauge, Plug, Record, Stop, X } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import {
    LiveProfileFrame,
    LiveProfileFunction,
    LiveProfileSnapshot,
    VES_LIVE_PROFILE_ROOT,
} from '../../common/emulator-live-profile';
import {
    VB_CLOCK_RATE, VB_CLOCKS_PER_BUFFER, VB_INTERRUPT_VECTOR_BASE, VbInterrupt,
} from '../../common/vb-constants';
import EmptyContainer from '../components/kit/EmptyContainer';
import PanelFilter from '../components/kit/PanelFilter';
import { BYTES_PER_MBIT } from '../emulator-types';
import { findFunctionAt, functionDisplayName, SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { emulatorPanelLabel, EmulatorPanelType, hex, DebugSource, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import {
    nextTableSort, SortableHeader, sortTableRows, TableSort,
} from './emulator-sortable-table';

/** Why the panel has nothing to show, when it has nothing to show. */
enum ProfilerStatus {
    OK = 'ok',
    NOT_RUNNING = 'notRunning',
    WAITING = 'waiting',
}

/** One row of the table, named and placed in a section. */
interface ProfilerRow extends LiveProfileFunction {
    name: string;
    section: string;
    /** True for the row that holds what was already running when it began. */
    root: boolean;
}

/**
 * A section of the table, and the functions nested under it.
 *
 * Sections and functions used to be two tables side by side, which asked the
 * reader to hold a name in their head while they looked for it in the other
 * one. They are the same clocks grouped twice, so this is one group per
 * section with its own functions inside it.
 */
interface ProfilerGroup {
    /** Sorting and grouping key, since two sections can be shown alike. */
    id: string;
    name: string;
    /** Clocks in the section itself, in the frame on show and over the window. */
    self: number;
    selfAvg: number;
    selfPeak: number;
    calls: number;
    /** How many functions of the section ran, for the row's own hint. */
    functions: number;
    /** The functions listed under it, after the filter and the quiet fold. */
    rows: ProfilerRow[];
    /**
     * The single row a group *is*, rather than contains.
     *
     * "Already running" is not a section with functions in it — it is one row
     * that no function name would improve — so it sits at the top level with
     * the sections rather than alone inside one.
     */
    leaf?: ProfilerRow;
    /**
     * A leaf the filter or the quiet fold has taken out.
     *
     * A section stays listed whatever happens to the rows inside it, because
     * the figures on it are the section's own and still true. A leaf has no
     * figures of its own to keep: hiding its row is hiding it.
     */
    hidden?: boolean;
}

type ProfilerColumn = 'name' | 'self' | 'avg' | 'peak' | 'total' | 'calls' | 'cost';

/** What a reader saved to compare against, and when. */
interface ProfilerBaseline {
    /** Each section's average share of a frame, as a percentage. */
    shares: Map<string, number>;
    /** What it was called, for a section that has since stopped running. */
    names: Map<string, string>;
    /** The busy average the whole thing had, which is the headline figure. */
    busy: number;
}

/** Functions below this share of a frame are folded away by default. */
const QUIET_SHARE = 0.001;

/** A section that holds one row rather than a class's worth of them. */
const ROOT_GROUP = '\u0000root';

/** How far a section has to move against the baseline to be worth saying. */
const BASELINE_THRESHOLD = 0.1;

/** How many moved sections the baseline line names before it stops. */
const BASELINE_MOVERS = 3;

/**
 * The other profiler, the recording one, as far as this panel can drive it.
 *
 * Handed in by the dock from its host rather than reached through the debug
 * source, which is read-only on purpose; absent on a host that offers no
 * recording, and the panel then shows no button for it.
 */
export interface VesProfileRecordingControl {
    isProfiling(): boolean;
    /** Start a recording — the host asks first — or stop one and export it. */
    toggleProfiling(): void;
}

/**
 * Where the machine's clocks are going, frame by frame, while it runs.
 *
 * The emulator has had a profiler since Phase 6, but of the other kind: record
 * a session, replay it afterwards following every instruction, export the call
 * tree. That answers "where did those thirty seconds go" exactly, and answers
 * nothing at all until the run is over. This is the question a developer asks
 * while they are still holding the controller — is this frame too expensive,
 * and what in it — so it measures the run as it happens and redraws a few
 * times a second.
 *
 * What it measures is clocks, not samples: the core decrements the clock
 * budget it is given as it runs, and the execute callback can read that word,
 * so every instruction's cost is known to the clock rather than estimated from
 * how often a sampler happened to land on it. Percentages here are shares of a
 * real frame — {@link VB_CLOCKS_PER_BUFFER} clocks at 20 MHz — and not shares
 * of a sample count.
 *
 * The panel is built around one frame at a time. The timeline draws the whole
 * window so a bad frame can be *seen* rather than averaged away, and clicking
 * one pins it: the table below then says where that frame's clocks went, and
 * goes on saying it after the frame has scrolled out of the window, because
 * what was pinned is kept rather than asked for again.
 *
 * Three things about the figures are worth knowing before reading them:
 *
 * - **Idle is measured, not inferred.** A game waiting for the next frame
 *   either `halt`s, which stops the processor while the clock runs on, or
 *   spins in a loop until the interrupt arrives — VUEngine's frame loop is a
 *   bare `while(!hasGameFrameStarted())`, and a spinning machine is busy by
 *   every measure the processor has. Both are found: see
 *   {@link VesLiveProfileCollector.harvestWait}, which is what keeps the
 *   headline from reading 100% on most of the games ever written for the
 *   machine. Where a wait was found, the headline says so and names it, since
 *   a loop is only called waiting by measurement rather than by declaration.
 * - **Names need the build.** Without the `.elf` beside the ROM every row is an
 *   address. The profile is exactly as accurate either way; only the labels
 *   change.
 * - **The first row is not a function.** Profiling starts in the middle of a
 *   game, inside a stack of calls that happened before anything was watching,
 *   and what those frames run collects under one row — see
 *   {@link VES_LIVE_PROFILE_ROOT}.
 */
export class ProfilerPanel extends Panel {

    /**
     * Slower than the default ten.
     *
     * Every refresh aggregates the whole window — a hundred frames of a few
     * hundred functions — on the worker thread, which is the thread that is
     * also emulating. Five times a second is faster than a reader can take a
     * table in, and leaves the worker to get on with it.
     */
    protected static readonly PROFILER_POLL_HZ = 5;

    protected status = ProfilerStatus.NOT_RUNNING;
    protected snapshot?: LiveProfileSnapshot;
    protected symbols?: SymbolIndex;
    /** The machine profiling was switched on for, so a change of seat re-arms. */
    protected armed?: Sim;
    protected error?: string;
    /** Guards against a slow read being overlapped by the next tick. */
    protected reading = false;
    protected sort: TableSort<ProfilerColumn> = { column: 'avg', direction: 'descending' };
    /** Whether functions too small to matter are listed as well. */
    protected showQuiet = false;
    /**
     * Narrows the function list by name. Not remembered across sessions: a
     * filter is a question about the frame in front of you, and a profiler
     * that came back silently hiding most of its rows would be read as a
     * profiler that had stopped seeing them.
     */
    protected functionFilter = '';
    /**
     * The frame the reader clicked in the timeline, by its number.
     *
     * Set the moment it is clicked; {@link pinned} follows on the next read,
     * which is what actually freezes the figures.
     */
    protected pin?: number;
    /**
     * That frame, kept.
     *
     * The window is a couple of seconds long, so a pinned frame leaves it
     * almost immediately — and a spike you cannot go on looking at is no
     * better than a peak percentage. Once the worker has handed it over it
     * stays here until the pin is dropped.
     */
    protected pinned?: LiveProfileFrame;
    /** Sections the reader has opened or closed, over {@link autoOpen}. */
    protected readonly sectionOpen = new Map<string, boolean>();
    /**
     * The section opened without being asked, once, on the first figures.
     *
     * A table of nothing but collapsed section rows is a worse first sight
     * than the list of functions this replaced, and a build with no symbols
     * has a single section holding everything — which collapsed would be a
     * panel with one row in it. So the busiest section starts open. Decided
     * once rather than every refresh, because the busiest section changes
     * places while a game runs and a table that opened and shut by itself
     * would be unusable.
     */
    protected autoOpen?: string;
    /** What the figures are being compared against, if anything. */
    protected baseline?: ProfilerBaseline;

    constructor(
        source: DebugSource,
        instanceId: string,
        protected readonly recording?: VesProfileRecordingControl,
    ) {
        super(EmulatorPanelType.PROFILER, source, instanceId);
        this.title.label = emulatorPanelLabel(EmulatorPanelType.PROFILER);
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.PROFILER);
    }

    protected pollHz(): number {
        return ProfilerPanel.PROFILER_POLL_HZ;
    }

    /**
     * Profiling is on only while this panel is.
     *
     * It costs a callback on every emulated instruction — measured at 1.5x on
     * a call-heavy loop, which the core has the headroom for but which nobody
     * should be paying for a panel they closed. So the panel owns the switch,
     * and every way out of view turns it off again.
     */
    protected onAfterHide(msg: Message): void {
        super.onAfterHide(msg);
        this.disarm();
    }

    protected onBeforeDetach(msg: Message): void {
        this.disarm();
        super.onBeforeDetach(msg);
    }

    dispose(): void {
        this.disarm();
        super.dispose();
    }

    protected disarm(): void {
        const armed = this.armed;
        this.armed = undefined;
        this.snapshot = undefined;
        // Everything below describes a run that is over: a pinned frame of a
        // profile that no longer exists, a baseline taken from it, and which
        // of its sections were open.
        this.pin = undefined;
        this.pinned = undefined;
        this.baseline = undefined;
        this.autoOpen = undefined;
        this.sectionOpen.clear();
        // The machine may be gone already, which is not a failure: it took the
        // profiler with it.
        armed?.setLiveProfiler(false).catch(() => undefined);
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.disarm();
            this.status = ProfilerStatus.NOT_RUNNING;
            this.update();
            return;
        }
        if (this.reading) {
            return;
        }
        this.reading = true;

        try {
            if (this.armed !== sim) {
                // Either the first tick, or the debugger has been pointed at
                // the other machine of a linked pair.
                this.armed?.setLiveProfiler(false).catch(() => undefined);
                this.armed = sim;
                this.snapshot = undefined;
                await sim.setLiveProfiler(true);
            }
            // The pinned frame is asked for only until it has been handed
            // over: it is a frame that has already happened and will not
            // change, and it outlives the window it came from.
            const wanted = this.pinned ? undefined : this.pin;
            // Read before the symbols: a profile without names is still a
            // profile, and a project whose `.elf` is tens of megabytes should
            // not hold up the first frame of figures.
            const snapshot = await sim.readLiveProfile(wanted);
            // Asked for every time rather than kept: the source caches them
            // for as long as the ROM is loaded, so this costs nothing and a
            // ROM swapped underneath the panel renames its rows by itself.
            this.symbols = await this.source.getSymbols();
            this.snapshot = snapshot;
            if (snapshot && wanted !== undefined) {
                this.capture(snapshot, wanted);
            }
            this.status = snapshot && snapshot.frames > 0
                ? ProfilerStatus.OK
                : ProfilerStatus.WAITING;
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
            this.status = ProfilerStatus.NOT_RUNNING;
        } finally {
            this.reading = false;
            this.update();
        }
    }

    /**
     * Keep the frame that was pinned, or drop the pin if it got away.
     *
     * A frame can only be unpacked while it is still in the window, and the
     * window is two seconds long — so a click that arrives late has nothing
     * to pin, and the honest response is to go back to the live figures
     * rather than to show an empty table headed by a frame number.
     */
    protected capture(snapshot: LiveProfileSnapshot, wanted: number): void {
        if (snapshot.pinned) {
            this.pinned = snapshot.pinned;
        } else if (wanted <= snapshot.framesSeen - snapshot.frames) {
            this.pin = undefined;
        }
    }

    protected render(): React.ReactNode {
        const snapshot = this.snapshot;
        const recording = this.renderRecording();
        if (this.status !== ProfilerStatus.OK || !snapshot) {
            return recording
                ? <div className='vp-profiler'>{recording}{this.renderEmpty()}</div>
                : this.renderEmpty();
        }
        // Named once and used twice: naming an address is a search through
        // the build's symbols, and the table and the baseline below it are
        // looking at the same rows.
        const rows = this.rows(snapshot);
        return <div className='vp-profiler'>
            {recording}
            {this.renderSummary(snapshot)}
            {this.renderTable(snapshot, this.groups(snapshot, rows))}
            {this.renderBaseline(snapshot, rows)}
        </div>;
    }

    /**
     * The switch for the recording profiler, above the live figures.
     *
     * Here rather than in the title bar because it is this panel's question
     * asked the other way: the figures below answer "what is this frame
     * costing" while the game runs, a recording answers "where did the whole
     * session go" once it is over. Shown while there is a machine to record,
     * and always while a recording runs, so it can be stopped from here.
     */
    protected renderRecording(): React.ReactNode {
        const control = this.recording;
        if (!control) {
            return undefined;
        }
        const active = control.isProfiling();
        if (!active && !this.source.sim) {
            return undefined;
        }
        return <div className='vp-profiler-recording'>
            <button
                type='button'
                className={active ? 'vp-button' : 'vp-button secondary'}
                aria-pressed={active}
                onClick={() => { control.toggleProfiling(); this.update(); }}
            >
                {active ? <Stop size={14} weight='fill' /> : <Record size={14} weight='fill' />}
                {active
                    ? nls.localize('vueport/debug/panels/profiler/stopRecording', 'Stop Profiling and Export')
                    : nls.localize('vueport/debug/panels/profiler/startRecording', 'Start Profiling')}
            </button>
            {/* What the button does is easy to mistake for what the panel
                does, so the hint says where the result goes and that the
                figures below are not it. */}
            <span className='hint'>
                {active
                    ? nls.localize(
                        'vueport/debug/panels/profiler/recordingActive',
                        'Recording. Stopping replays the session and exports its call tree as a file for \
profiler.firefox.com. The figures below go on measuring meanwhile.'
                    )
                    : nls.localize(
                        'vueport/debug/panels/profiler/recordingIdle',
                        'Records the whole session and exports its call tree as a file for \
profiler.firefox.com. It does not replace the figures below.'
                    )}
            </span>
        </div>;
    }

    protected renderEmpty(): React.ReactNode {
        const titles: Record<ProfilerStatus, string> = {
            [ProfilerStatus.OK]: '',
            [ProfilerStatus.NOT_RUNNING]: this.error ?? nls.localize(
                'vueport/debug/panels/general/notRunning', 'The emulator is not running.'
            ),
            [ProfilerStatus.WAITING]: nls.localize(
                'vueport/debug/panels/profiler/waiting', 'Waiting for the first frame.'
            ),
        };
        const descriptions: Partial<Record<ProfilerStatus, string>> = {
            [ProfilerStatus.WAITING]: nls.localize(
                'vueport/debug/panels/profiler/waitingDescription',
                'Figures appear as soon as the machine completes a frame. A machine that is paused \
completes none.'
            ),
        };
        return <EmptyContainer
            title={titles[this.status]}
            description={descriptions[this.status]}
            icon={this.status === ProfilerStatus.WAITING ? <Gauge size={32} /> : <Plug size={32} />}
        />;
    }

    /**
     * The headline and the window it came out of.
     *
     * Busy rather than idle, because that is the number a developer is trying
     * to keep down, and against the frame rather than against what was
     * accounted for — a frame that overran is over 100% and should look it.
     * One frame at a time: the newest, or the pinned one, which is the whole
     * point of being able to pin one.
     */
    protected renderSummary(snapshot: LiveProfileSnapshot): React.ReactNode {
        const frame = this.pinned;
        const budget = snapshot.frameClocks;
        // Halted and waiting are the same thing to a reader — the frame was
        // not being used — and different things to the machine, which is why
        // they are measured apart and added up here.
        const halted = frame ? frame.halted : snapshot.halted;
        const waiting = frame ? frame.waited : snapshot.waiting;
        const clocks = frame ? frame.clocks : snapshot.clocks;
        const busy = clocks - halted - waiting;
        const number = frame ? frame.number : snapshot.framesSeen;
        const busyAvg = snapshot.clocksAvg - snapshot.haltedAvg - snapshot.waitingAvg;
        const busyShare = share(busy, budget);
        const over = busy > budget;
        const waitingAt = frame ? frame.waitAt : snapshot.waitingAt;
        const pictures = Math.round(budget / VB_CLOCKS_PER_BUFFER);

        return <div className='vp-profiler-summary'>
            <div className='vp-profiler-headline'>
                {/* Over the frame, not merely at it: a machine that never
                    waits is at exactly 100% and is not in trouble, while one
                    whose frame ran long is — and the clocks say which without
                    going through a rounded percentage. */}
                <strong className={over ? 'vp-profiler-over' : undefined}>
                    {busyShare.toFixed(1)}%
                </strong>
                <span className={over ? 'vp-profiler-overran' : 'hint'}>
                    {over
                        ? nls.localize(
                            'vueport/debug/panels/profiler/overran',
                            'frame {0} overran by {1}', count(number), millis(busy - budget)
                        )
                        : nls.localize(
                            'vueport/debug/panels/profiler/busy',
                            'of frame {0} busy · {1} idle',
                            count(number), duration(halted + waiting)
                        )}
                </span>
                {/* Where the idling was, when it was a loop rather than a
                    halted processor: the one thing a reader has to be able to
                    check, since what makes a loop a wait is measured rather
                    than declared. */}
                {waiting > 0 && <span className='hint vp-profiler-waiting'>
                    {waitingAt === VES_LIVE_PROFILE_ROOT
                        ? nls.localize(
                            'vueport/debug/panels/profiler/waitingInRoot',
                            '{0} of it spinning in a loop that was already running',
                            duration(waiting)
                        )
                        : nls.localize(
                            'vueport/debug/panels/profiler/waitingIn',
                            '{0} of it spinning in {1}',
                            duration(waiting),
                            this.describe(waitingAt, nls.localize(
                                'vueport/debug/panels/profiler/other', 'Other')).name
                        )}
                </span>}
                <span className='hint vp-profiler-window'>
                    {nls.localize(
                        'vueport/debug/panels/profiler/window',
                        'avg {0}% · {1} frames · {2}',
                        percent(busyAvg, budget),
                        count(snapshot.frames),
                        this.symbols
                            ? nls.localize('vueport/debug/panels/profiler/named', 'named from the build')
                            : nls.localize('vueport/debug/panels/profiler/unnamed', 'no symbols: addresses only')
                    )}
                    {/* A frame here is the game's, not the VIP's: a machine
                        drawing every second picture is given both of them to
                        do it in, and the budget everything is a share of says
                        so. Worth stating, since it is the reader's own
                        `__FRAME_CYCLE` coming back at them. */}
                    {pictures > 1 && ` · ${nls.localize(
                        'vueport/debug/panels/profiler/pictures',
                        '{0} pictures to a frame', count(pictures)
                    )}`}
                    {snapshot.resets > 0 && ` · ${nls.localize(
                        'vueport/debug/panels/profiler/resets', '{0} restarts', count(snapshot.resets)
                    )}`}
                </span>
            </div>
            {this.renderTimeline(snapshot)}
        </div>;
    }

    /**
     * The window, drawn.
     *
     * The hundred frames behind the averages were already being kept; all a
     * peak percentage ever said about them was that one of them was bad. Here
     * they are one bar each, with the frame budget as a line across them, so a
     * spike is a thing you can point at — and clicking one pins it, which is
     * the only way to ask what was *in* a frame that has already gone.
     */
    protected renderTimeline(snapshot: LiveProfileSnapshot): React.ReactNode {
        const budget = snapshot.frameClocks;
        const history = snapshot.frameBusy;
        const oldest = snapshot.framesSeen - history.length + 1;
        // Tall enough for the worst frame, and never shorter than the budget:
        // a window with nothing over budget draws the line along the top,
        // which is where it belongs, and one with a spike in it keeps the
        // spike's height honest instead of clipping it.
        let scale = budget;
        for (const busy of history) {
            scale = Math.max(scale, busy);
        }

        return <div className='vp-profiler-timeline-block'>
            <div
                className='vp-profiler-timeline'
                role='group'
                aria-label={nls.localize(
                    'vueport/debug/panels/profiler/timeline',
                    'The last {0} frames. Pin one to see what was in it.', count(history.length)
                )}
                onKeyDown={event => this.onTimelineKey(event, oldest, snapshot.framesSeen)}
            >
                <div className='vp-profiler-budget' style={{ bottom: `${(100 * budget) / scale}%` }} />
                {history.map((busy, index) => {
                    const number = oldest + index;
                    const pinned = number === this.pin;
                    const label = nls.localize(
                        'vueport/debug/panels/profiler/frameBar',
                        'Frame {0}: {1}% of a frame', count(number), percent(busy, budget)
                    );
                    return <button
                        key={number}
                        type='button'
                        className={'vp-profiler-frame'
                            + (busy > budget ? ' over' : '')
                            + (pinned ? ' pinned' : '')}
                        // One stop for the whole row: a hundred of them in the
                        // tab order would be a hundred presses to get past the
                        // chart. The arrow keys move along it from there.
                        tabIndex={number === (this.pin ?? snapshot.framesSeen) ? 0 : -1}
                        aria-pressed={pinned}
                        aria-label={label}
                        title={label}
                        style={{ height: `${Math.max(2, (100 * busy) / scale)}%` }}
                        onClick={() => this.togglePin(number)}
                    />;
                })}
            </div>
            <div className='hint vp-profiler-axis'>
                <span>{nls.localize(
                    'vueport/debug/panels/profiler/framesAgo', '{0} frames ago', count(history.length)
                )}</span>
                <span>{nls.localize(
                    'vueport/debug/panels/profiler/budgetLine',
                    'the line is the {0} a frame has · click a frame to pin it', millis(budget)
                )}</span>
                <span>{nls.localize('vueport/debug/panels/profiler/axisNow', 'now')}</span>
            </div>
        </div>;
    }

    /**
     * Walking the timeline from the keyboard.
     *
     * The chart is one tab stop, so the arrows have to be what moves along it.
     * They move the pin rather than a cursor, because a highlight that is not
     * a pin would be a second kind of selection that does nothing.
     */
    protected onTimelineKey(
        event: React.KeyboardEvent, oldest: number, newest: number
    ): void {
        const at = this.pin ?? newest;
        let next: number | undefined;
        switch (event.key) {
            case 'ArrowLeft': next = Math.max(oldest, at - 1); break;
            case 'ArrowRight': next = Math.min(newest, at + 1); break;
            case 'Home': next = oldest; break;
            case 'End': next = newest; break;
            case 'Escape': next = undefined; break;
            default: return;
        }
        event.preventDefault();
        if (next === undefined) {
            this.unpin();
        } else {
            this.setPin(next);
        }
    }

    protected togglePin(number: number): void {
        if (this.pin === number) {
            this.unpin();
        } else {
            this.setPin(number);
        }
    }

    protected setPin(number: number): void {
        this.pin = number;
        this.pinned = undefined;
        this.update();
        // Straight away rather than on the next tick: the window moves fifty
        // times a second and the panel only reads it five, so waiting is two
        // hundred milliseconds in which the frame could leave.
        this.poll();
    }

    protected unpin(): void {
        this.pin = undefined;
        this.pinned = undefined;
        this.update();
    }

    /**
     * One table: sections, with their functions inside them.
     *
     * The frame columns are whichever frame the panel is on — the newest, or
     * the one pinned — and the window columns beside them are always the
     * window, which is what makes a single frame readable: 41% of this frame
     * against 12% on average is a different fact from 41% against 40%.
     */
    protected renderTable(
        snapshot: LiveProfileSnapshot,
        { groups, quiet, filtered }: { groups: ProfilerGroup[]; quiet: number; filtered: boolean }
    ): React.ReactNode {
        const frame = this.pinned;
        const sort = (column: ProfilerColumn) => {
            this.sort = nextTableSort(this.sort, column);
            this.update();
        };

        return <div className='vp-profiler-tree'>
            <div className='vp-profiler-tree-head'>
                <span className='vp-profiler-tree-title'>
                    {frame
                        ? nls.localize(
                            'vueport/debug/panels/profiler/pinnedTitle',
                            'Frame {0}, pinned — where the clocks went', count(frame.number)
                        )
                        : nls.localize(
                            'vueport/debug/panels/profiler/liveTitle',
                            'The last frame — where the clocks went'
                        )}
                </span>
                {this.pin !== undefined && <button
                    type='button'
                    className='vp-profiler-unpin'
                    onClick={() => this.unpin()}
                >{nls.localize('vueport/debug/panels/profiler/unpin', 'Unpin')}</button>}
                <PanelFilter
                    value={this.functionFilter}
                    placeholder={nls.localize('vueport/debug/panels/profiler/filter', 'Filter functions')}
                    onChange={value => { this.functionFilter = value; this.update(); }}
                />
            </div>
            <div className='vp-profiler-rows vp-scroll'>
                <table className='vp-profiler-table vp-table vp-selectable-table'>
                    <thead>
                        <tr>
                            <SortableHeader className='vp-profiler-name'
                                column='name' sort={this.sort} onSort={sort}>
                                {nls.localize(
                                    'vueport/debug/panels/profiler/sectionFunction', 'Section / Function')}
                            </SortableHeader>
                            <SortableHeader column='self' sort={this.sort} onSort={sort}
                                title={nls.localize(
                                    'vueport/debug/panels/profiler/selfHint',
                                    'The share of that one frame — the newest, or the pinned one — spent \
in this code itself, not counting anything it called.'
                                )}>
                                {frame
                                    ? nls.localize(
                                        'vueport/debug/panels/profiler/frameColumn',
                                        'Frame {0}', count(frame.number))
                                    : nls.localize('vueport/debug/panels/profiler/now', 'Now')}
                            </SortableHeader>
                            <SortableHeader column='avg' sort={this.sort} onSort={sort}>
                                {nls.localize('vueport/debug/panels/profiler/avg', 'Avg')}
                            </SortableHeader>
                            <SortableHeader column='peak' sort={this.sort} onSort={sort}
                                title={nls.localize(
                                    'vueport/debug/panels/profiler/peakHint',
                                    'The worst frame of the window. A section adds up its functions\' \
worst frames, which is an upper bound on it: they were not all at their worst in the same frame.'
                                )}>
                                {nls.localize('vueport/debug/panels/profiler/peak', 'Peak')}
                            </SortableHeader>
                            <SortableHeader column='total' sort={this.sort} onSort={sort}
                                title={nls.localize(
                                    'vueport/debug/panels/profiler/totalHint',
                                    'The share of that frame spent in this function and in everything it \
called. A function that only calls others has all of its time here and none in the frame column.'
                                )}>
                                {nls.localize('vueport/debug/panels/profiler/total', 'Total')}
                            </SortableHeader>
                            <SortableHeader column='calls' sort={this.sort} onSort={sort}>
                                {nls.localize('vueport/debug/panels/profiler/calls', 'Calls')}
                            </SortableHeader>
                            <SortableHeader column='cost' sort={this.sort} onSort={sort}
                                title={nls.localize(
                                    'vueport/debug/panels/profiler/costHint',
                                    'Microseconds of the machine\'s own time per call, in that frame. \
What a single call costs, however often it happens to be made.'
                                )}>
                                {nls.localize('vueport/debug/panels/profiler/cost', 'µs/call')}
                            </SortableHeader>
                            <th className='vp-profiler-share'>
                                {nls.localize('vueport/debug/panels/profiler/share', 'Share')}
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {groups.map(group => group.leaf
                            ? this.renderRow(group.leaf, snapshot, false)
                            : <React.Fragment key={group.id}>
                                {this.renderSection(group, snapshot)}
                                {this.isOpen(group.id)
                                    && group.rows.map(row => this.renderRow(row, snapshot, true))}
                            </React.Fragment>)}
                    </tbody>
                </table>
                {groups.length === 0 && quiet === 0 && <div className='hint'>
                    {nls.localize(
                        'vueport/debug/panels/profiler/noneMatch', 'No function matches the filter.')}
                </div>}
                {quiet > 0 && <button type='button' className='vp-profiler-more'
                    onClick={() => { this.showQuiet = !this.showQuiet; this.update(); }}>
                    {this.showQuiet
                        ? nls.localize('vueport/debug/panels/profiler/hideQuiet', 'Hide {0} below a tenth of a percent', count(quiet))
                        : nls.localize('vueport/debug/panels/profiler/showQuiet', 'Show {0} below a tenth of a percent', count(quiet))}
                </button>}
            </div>
            {filtered && <div className='hint vp-profiler-filtered'>
                {nls.localize(
                    'vueport/debug/panels/profiler/filteredSections',
                    'Section figures are the whole section, filter or no filter.'
                )}
            </div>}
        </div>;
    }

    /** A section's own row: the sum of what is folded underneath it. */
    protected renderSection(
        group: ProfilerGroup, snapshot: LiveProfileSnapshot
    ): React.ReactNode {
        const open = this.isOpen(group.id);
        return <tr className='vp-profiler-section'>
            <td className='vp-profiler-name'>
                <button
                    type='button'
                    className='vp-profiler-toggle'
                    aria-expanded={open}
                    onClick={() => this.toggleSection(group.id)}
                    title={nls.localize(
                        'vueport/debug/panels/profiler/sectionFunctions',
                        '{0} functions of this section ran', count(group.functions)
                    )}
                >
                    {open
                        ? <CaretDown size={11} weight='fill' />
                        : <CaretRight size={11} weight='fill' />}
                    <span>{group.name}</span>
                </button>
            </td>
            <td className='vp-profiler-number'>
                {percent(group.self, snapshot.frameClocks)}%
            </td>
            <td className='vp-profiler-number'>
                {percent(group.selfAvg, snapshot.frameClocks)}%
            </td>
            <td className='vp-profiler-number'>
                {percent(group.selfPeak, snapshot.frameClocks)}%
            </td>
            {/* A section has no inclusive time and no cost per call: its
                inclusive time counts whatever it called in other sections, so
                a column of them would add up to more than the frame. */}
            <td className='vp-profiler-number' />
            <td className='vp-profiler-number'>{count(group.calls)}</td>
            <td className='vp-profiler-number' />
            <td className='vp-profiler-share'>
                {bar(this.weight(group), snapshot.frameClocks)}
            </td>
        </tr>;
    }

    protected renderRow(
        row: ProfilerRow, snapshot: LiveProfileSnapshot, nested: boolean
    ): React.ReactNode {
        return <tr key={row.address} className={row.root ? 'hint' : undefined}>
            <td className={`vp-profiler-name${nested ? ' vp-profiler-nested' : ''}`}
                title={row.root ? nls.localize(
                    'vueport/debug/panels/profiler/rootHint',
                    'Everything that was already running when profiling started. Those calls \
happened before anything was watching, so there is no name for them — the game\'s own main loop is \
one of them.'
                ) : `0x${hex(row.address, 8)}`}>
                {row.root ? row.name : <code>{row.name}</code>}
            </td>
            <td className='vp-profiler-number'>
                {percent(row.self, snapshot.frameClocks)}%
            </td>
            <td className='vp-profiler-number'>
                {percent(row.selfAvg, snapshot.frameClocks)}%
            </td>
            <td className='vp-profiler-number'>
                {percent(row.selfPeak, snapshot.frameClocks)}%
            </td>
            <td className='vp-profiler-number'>
                {row.root ? '' : `${percent(row.total, snapshot.frameClocks)}%`}
            </td>
            <td className='vp-profiler-number'>{row.root ? '' : count(row.calls)}</td>
            <td className='vp-profiler-number'>
                {row.calls > 0 ? micros(row.self / row.calls) : ''}
            </td>
            <td className='vp-profiler-share'>
                {bar(this.weight(row), snapshot.frameClocks)}
            </td>
        </tr>;
    }

    /**
     * What the figures are being measured against, if anything.
     *
     * The question a profiler is usually open for is not "what does this
     * cost" but "did what I just changed help", and answering that from
     * memory across a rebuild is how a percent and a half goes unnoticed.
     * Averages rather than the pinned frame: a baseline is a claim about how
     * the game runs, and one frame is not one.
     */
    protected renderBaseline(
        snapshot: LiveProfileSnapshot, rows: ProfilerRow[]
    ): React.ReactNode {
        const baseline = this.baseline;
        return <div className='vp-profiler-baseline'>
            <button
                type='button'
                className='vp-button secondary'
                onClick={() => { this.baseline = this.takeBaseline(snapshot, rows); this.update(); }}
                title={nls.localize(
                    'vueport/debug/panels/profiler/baselineHint',
                    'Remember what the window averages are now, and show what has moved since.'
                )}
            >
                {baseline
                    ? nls.localize('vueport/debug/panels/profiler/baselineReplace', 'Take a new baseline')
                    : nls.localize('vueport/debug/panels/profiler/baselineSave', 'Save as baseline')}
            </button>
            {baseline && <span className='hint vp-profiler-movers'>
                {this.renderMovers(snapshot, rows, baseline)}
            </span>}
            {baseline && <button
                type='button'
                className='vp-profiler-baseline-clear'
                aria-label={nls.localize(
                    'vueport/debug/panels/profiler/baselineClear', 'Forget the baseline')}
                onClick={() => { this.baseline = undefined; this.update(); }}
            ><X size={11} /></button>}
        </div>;
    }

    /** The sections that have moved furthest since the baseline was taken. */
    protected renderMovers(
        snapshot: LiveProfileSnapshot, rows: ProfilerRow[], baseline: ProfilerBaseline
    ): React.ReactNode {
        const now = this.shares(snapshot, rows);
        const moved: { id: string; name: string; delta: number }[] = [];
        // Both ways round the join: a section that has stopped running
        // altogether is the biggest improvement there is, and it is not in
        // the table any more to be found.
        for (const id of new Set([...now.keys(), ...baseline.shares.keys()])) {
            const delta = (now.get(id)?.share ?? 0) - (baseline.shares.get(id) ?? 0);
            if (Math.abs(delta) >= BASELINE_THRESHOLD) {
                moved.push({
                    id,
                    name: now.get(id)?.name ?? baseline.names.get(id) ?? id,
                    delta,
                });
            }
        }
        moved.sort((left, right) => Math.abs(right.delta) - Math.abs(left.delta));

        const busyNow = share(snapshot.clocksAvg - snapshot.haltedAvg, snapshot.frameClocks);
        const busyDelta = busyNow - baseline.busy;
        return <>
            {nls.localize(
                'vueport/debug/panels/profiler/baselineBusy',
                'vs baseline: busy {0}', points(busyDelta)
            )}
            {moved.slice(0, BASELINE_MOVERS).map(entry => <span key={entry.id}>
                {' · '}
                <span className={entry.delta > 0 ? 'vp-profiler-worse' : 'vp-profiler-better'}>
                    {`${entry.name} ${points(entry.delta)}`}
                </span>
            </span>)}
            {moved.length === 0 && ` · ${nls.localize(
                'vueport/debug/panels/profiler/baselineSteady',
                'no section has moved by a tenth of a point'
            )}`}
        </>;
    }

    protected takeBaseline(
        snapshot: LiveProfileSnapshot, rows: ProfilerRow[]
    ): ProfilerBaseline {
        const sections = this.shares(snapshot, rows);
        return {
            shares: new Map([...sections].map(([id, section]) => [id, section.share])),
            names: new Map([...sections].map(([id, section]) => [id, section.name])),
            busy: share(snapshot.clocksAvg - snapshot.haltedAvg, snapshot.frameClocks),
        };
    }

    /**
     * Every section's average share of a frame, whatever is being listed.
     *
     * A baseline is taken from the whole profile rather than from the table:
     * a filter is a question about what to show, and a comparison that
     * quietly left out whatever was typed at the time would report every
     * section it had not been looking at as having appeared out of nowhere.
     */
    protected shares(
        snapshot: LiveProfileSnapshot, rows: ProfilerRow[]
    ): Map<string, { name: string; share: number }> {
        const sections = new Map<string, { name: string; share: number }>();
        for (const row of rows) {
            const id = row.root ? ROOT_GROUP : row.section;
            let section = sections.get(id);
            if (!section) {
                section = { name: row.root ? row.name : row.section, share: 0 };
                sections.set(id, section);
            }
            section.share += share(row.selfAvg, snapshot.frameClocks);
        }
        return sections;
    }

    protected isOpen(id: string): boolean {
        // A filter is a question about function names, so it opens whatever
        // it found: a match hidden inside a collapsed section would read as
        // no match at all.
        return this.functionFilter.trim() !== ''
            || (this.sectionOpen.get(id) ?? id === this.autoOpen);
    }

    protected toggleSection(id: string): void {
        this.sectionOpen.set(id, !this.isOpen(id));
        this.update();
    }

    /**
     * The clocks a row is read by: the frame on show, or the window average.
     *
     * The share bar and the sections' order both follow this, so pinning a
     * frame reorders the table into what that frame cost rather than leaving
     * it sorted by a window the reader has just stepped out of.
     */
    protected weight(row: { self: number; selfAvg: number }): number {
        return this.pinned ? row.self : row.selfAvg;
    }

    /**
     * The snapshot as sections with functions under them, sorted and folded.
     *
     * Section figures are the whole section, whatever the filter is doing to
     * the rows inside it: the filter asks which functions to list, not what a
     * section costs, and a section total that moved as you typed would be a
     * different number every keystroke.
     */
    protected groups(snapshot: LiveProfileSnapshot, rows: ProfilerRow[]): {
        groups: ProfilerGroup[]; quiet: number; filtered: boolean;
    } {
        const needle = this.functionFilter.trim().toLowerCase();
        const limit = snapshot.frameClocks * QUIET_SHARE;
        const groups = new Map<string, ProfilerGroup>();
        let quiet = 0;

        for (const row of rows) {
            const id = row.root ? ROOT_GROUP : row.section;
            let group = groups.get(id);
            if (!group) {
                group = {
                    id, name: row.root ? row.name : row.section,
                    self: 0, selfAvg: 0, selfPeak: 0, calls: 0, functions: 0, rows: [],
                };
                groups.set(id, group);
            }
            group.self += row.self;
            group.selfAvg += row.selfAvg;
            // The sum of each function's worst frame, which is not one frame's
            // worth — an upper bound on the section rather than a measurement
            // of it, and labeled as such in the header's hint.
            group.selfPeak += row.selfPeak;
            group.calls += row.calls;
            group.functions++;
            const matches = needle === ''
                || row.name.toLowerCase().includes(needle)
                || row.section.toLowerCase().includes(needle);
            const audible = this.showQuiet || this.weight(row) >= limit;
            if (!matches || !audible) {
                if (matches) {
                    quiet++;
                }
                if (row.root) {
                    group.hidden = true;
                }
                continue;
            }
            if (row.root) {
                group.leaf = row;
                continue;
            }
            group.rows.push(row);
        }

        let listed = [...groups.values()].filter(group => !group.hidden);
        if (needle !== '') {
            listed = listed.filter(group => group.rows.length > 0 || group.leaf);
        }
        this.rememberAutoOpen(listed);

        const sorted = sortTableRows(listed, this.sort, (group, column) => {
            switch (column) {
                case 'name': return group.name;
                case 'self': return group.self;
                case 'avg': return group.selfAvg;
                case 'peak': return group.selfPeak;
                case 'calls': return group.calls;
                // Sections have neither of the last two columns, so ordering
                // by one of them orders them by the clocks they are read by
                // instead of dropping them all to the bottom.
                default: return this.weight(group);
            }
        });
        for (const group of sorted) {
            group.rows = sortTableRows(group.rows, this.sort, (row, column) => {
                switch (column) {
                    case 'name': return row.name;
                    case 'self': return row.self;
                    case 'avg': return row.selfAvg;
                    case 'peak': return row.selfPeak;
                    case 'total': return row.total;
                    case 'calls': return row.calls;
                    case 'cost': return row.calls > 0 ? row.self / row.calls : undefined;
                }
            });
        }
        return { groups: sorted, quiet, filtered: needle !== '' };
    }

    /** Pick the section that starts open, once — see {@link autoOpen}. */
    protected rememberAutoOpen(groups: ProfilerGroup[]): void {
        if (this.autoOpen !== undefined) {
            return;
        }
        let busiest: ProfilerGroup | undefined;
        for (const group of groups) {
            if (!group.leaf && (!busiest || group.selfAvg > busiest.selfAvg)) {
                busiest = group;
            }
        }
        this.autoOpen = busiest?.id;
    }

    /**
     * The snapshot's addresses, named and grouped.
     *
     * With a frame pinned the rows *are* that frame: only what ran in it, with
     * that frame's own clocks in the frame columns, joined to the window for
     * the averages beside them. A function the window still remembers but that
     * frame never ran is not a row — it would be a line of zeroes in a table
     * headed "where the clocks went".
     */
    protected rows(snapshot: LiveProfileSnapshot): ProfilerRow[] {
        const other = nls.localize('vueport/debug/panels/profiler/other', 'Other');
        const pinned = this.pinned;
        if (!pinned) {
            return snapshot.functions.map(entry => ({
                ...entry, ...this.describe(entry.address, other),
            }));
        }
        const window = new Map(snapshot.functions.map(entry => [entry.address, entry]));
        return pinned.functions.map(entry => {
            const seen = window.get(entry.address);
            return {
                address: entry.address,
                self: entry.self,
                total: entry.total,
                calls: entry.calls,
                // Zeroes where the window has nothing to say, which happens
                // once the pinned frame has scrolled out from under it.
                selfAvg: seen?.selfAvg ?? 0,
                selfPeak: seen?.selfPeak ?? 0,
                totalAvg: seen?.totalAvg ?? 0,
                totalPeak: seen?.totalPeak ?? 0,
                totalMin: seen?.totalMin ?? 0,
                callsAvg: seen?.callsAvg ?? 0,
                frames: seen?.frames ?? 0,
                ...this.describe(entry.address, other),
            };
        });
    }

    /**
     * What to call an address, and which section it belongs to.
     *
     * Three kinds of row, and the two that are not functions are the ones a
     * reader would otherwise puzzle over: the frames that were already open
     * when profiling began, and the interrupt handlers hardware enters without
     * a call.
     */
    protected describe(
        address: number, other: string
    ): { name: string; section: string; root: boolean } {
        if (address === VES_LIVE_PROFILE_ROOT) {
            return {
                name: nls.localize('vueport/debug/panels/profiler/alreadyRunning', 'Already running'),
                section: nls.localize('vueport/debug/panels/profiler/unattributed', 'Unattributed'),
                root: true,
            };
        }
        const level = interruptLevelOf(address);
        if (level !== undefined) {
            return {
                name: nls.localize(
                    'vueport/debug/panels/profiler/interrupt', 'Interrupt: {0}', VbInterrupt[level]
                ),
                section: nls.localize('vueport/debug/panels/profiler/interrupts', 'Interrupts'),
                root: false,
            };
        }
        const symbol = this.symbols
            && findFunctionAt(this.symbols, address, this.source.romSize * BYTES_PER_MBIT);
        if (!symbol || !this.symbols) {
            return { name: `0x${hex(address, 8)}`, section: other, root: false };
        }
        const name = functionDisplayName(this.symbols, symbol.name);
        const split = name.indexOf('::');
        return {
            name,
            section: split > 0 ? name.slice(0, split) : other,
            root: false,
        };
    }
}

/** The interrupt a vector address belongs to, if it is one. */
function interruptLevelOf(address: number): VbInterrupt | undefined {
    const offset = address - VB_INTERRUPT_VECTOR_BASE;
    if (offset < 0 || offset > VbInterrupt.VPU * 0x10 || (offset & 0x0f) !== 0) {
        return undefined;
    }
    return offset >> 4;
}

/** A share of a whole, as a number rather than as something to show. */
function share(part: number, whole: number): number {
    return whole > 0 ? (100 * part) / whole : 0;
}

/**
 * A share of a frame, to one decimal.
 *
 * Whole percents are too coarse here: a function at 0.4% of a frame is a
 * different thing from one at 0.0%, and rounding both to zero hides exactly
 * the long tail this table is read for.
 */
function percent(part: number, whole: number): string {
    return share(part, whole).toFixed(1);
}

/**
 * A move in percentage points, signed.
 *
 * Points rather than percent, and said so: a section that went from 10% of a
 * frame to 17% has moved seven points and gone up by seventy percent, and the
 * two readings are far enough apart to be worth a unit that cannot be mistaken.
 */
function points(delta: number): string {
    return `${delta > 0 ? '+' : delta < 0 ? '−' : ''}${Math.abs(delta).toFixed(1)}pp`;
}

/** Clocks as microseconds of the machine's own time. */
function micros(clocks: number): string {
    const value = (clocks * 1e6) / VB_CLOCK_RATE;
    return `${value >= 100 ? Math.round(value) : value.toFixed(value >= 10 ? 1 : 2)} µs`;
}

/**
 * Clocks as a time, in whichever unit does not need five digits.
 *
 * A call costs microseconds and an idle frame costs milliseconds, and the same
 * figure is read in both places.
 */
function duration(clocks: number): string {
    return (clocks * 1e6) / VB_CLOCK_RATE >= 1000 ? millis(clocks) : micros(clocks);
}

/** Clocks as milliseconds, which is the unit a frame budget is quoted in. */
function millis(clocks: number): string {
    return `${((clocks * 1000) / VB_CLOCK_RATE).toFixed(1)} ms`;
}

function count(value: number): string {
    return value.toLocaleString('en-US');
}

/** A fill bar, clamped at the frame it is a share of. */
function bar(part: number, whole: number): React.ReactNode {
    return <div className='vp-profiler-bar'>
        <div style={{ width: `${Math.min(100, share(part, whole))}%` }} />
    </div>;
}
