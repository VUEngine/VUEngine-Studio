/** VB Color VCU aperture and its memory-mapped control block. */
export const VCU_MEMORY_BASE = 0x03000000;
/** 128 BG and 128 OBJ palettes of four packed RGB555 colors. */
export const VCU_CRAM_BASE = 0x03079000;
export const VCU_CRAM_COLORS = 1024;
export const VCU_CRAM_BYTES = VCU_CRAM_COLORS * 2;
export const VCU_REGISTER_BASE = 0x0307f800;
/**
 * The whole block, not just the part with names on it.
 *
 * VBC 1.1 reserves `0x0307F800`-`0x0307F8FF` — see `VBC_STATUS.md` — while
 * only the first sixteen bytes are documented registers. Reading the lot costs
 * one 256-byte fetch and is what lets the panel show the rest as it stands,
 * rather than leaving fifteen sixteenths of the block invisible because
 * nothing here has a name for it yet.
 */
export const VCU_REGISTER_BLOCK_BYTES = 0x100;
/** How much of the block above is named registers. */
export const VCU_NAMED_REGISTER_BYTES = 0x10;

export enum VcuRegister {
    VBCID0 = 0x00,
    VBCID1 = 0x02,
    VBCVER = 0x04,
    VBCCTRL = 0x06,
    CPUSPD = 0x08,
    COLCTRL = 0x0a,
    CBKPAL = 0x0c,
    LNKCTRL = 0x0e,
}

export const VBC_ID0_VALUE = 0x4256;
export const VBC_ID1_VALUE = 0x2143;
export const VBC_VERSION_VALUE = 0x0101;

/** How many CRAM entries make one palette — four, as on the VIP. */
export const VCU_CRAM_PALETTE_SIZE = 4;
/** BG palettes come first in CRAM, then the same number of OBJ palettes. */
export const VCU_CRAM_BG_PALETTES = 128;

/** Convert the VCU's low-to-high R5G5B5 word into a CSS color. */
export function vcuRgb555(value: number): { css: string; dark: boolean } {
    const expand = (component: number): number => (component << 3) | (component >> 2);
    const red = expand(value & 0x1f);
    const green = expand((value >> 5) & 0x1f);
    const blue = expand((value >> 10) & 0x1f);
    const byte = (component: number): string => component.toString(16).toUpperCase().padStart(2, '0');
    return {
        css: `#${byte(red)}${byte(green)}${byte(blue)}`,
        dark: red * 299 + green * 587 + blue * 114 < 128000,
    };
}
