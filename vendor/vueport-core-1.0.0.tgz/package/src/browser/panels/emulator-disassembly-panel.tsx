import { ArrowUUpLeft, Circle, Crosshair, Pause, Play, Plug, Warning } from '@phosphor-icons/react';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { nls } from '../../common/emulator-nls';
import { DisassemblyLine, StopReason } from '../../common/vb-protocol';
import EmptyContainer from '../components/kit/EmptyContainer';
import { annotateDisassembly, attachSourceLines, DisassemblyRow } from '../core/emulator-disassembly';
import { romOffsetOf, VesLineTable } from '../core/emulator-line-table';
import { functionDisplayName, SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { BYTES_PER_MBIT } from '../emulator-types';
import { DebugSource, EmulatorPanelType, hex, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';

/** How many instructions the window holds. */
const LINES = 48;

/** How much of the window sits above the program counter while following. */
const LEAD = 8;

/**
 * A source path as short as it can be and still say which file it is.
 *
 * The recorded paths are absolute and go through the build's own working
 * directory, which is most of their length and none of their meaning.
 */
function shortPath(path: string): string {
    const parts = path.split('/').filter(Boolean);
    return parts.slice(-2).join('/');
}

/** How many jumps back the history keeps. */
const MAX_HISTORY = 64;

/**
 * How small the rail's thumb may get.
 *
 * A window of forty-eight instructions is a few hundred bytes of a cartridge
 * that may be a megabyte, so the honest proportion rounds to nothing. The
 * floor keeps something to take hold of; what it costs is that the thumb's
 * size stops meaning anything, which it never did at that scale anyway.
 */
const MIN_THUMB = 18;

/** Where the cartridge is mapped, which is where a build's addresses point. */
const CART_WINDOW_BASE = 0x07000000;

/**
 * The machine's run state, as far as this panel can drive it.
 *
 * Handed in by the dock from its host rather than reached through the debug
 * source, which reads the machine and deliberately cannot drive it — the same
 * arrangement the CPU Profiler's record button has. Absent on a host that
 * offers no control, and the panel then reads the program without being able
 * to stop it, which is what every host had before breakpoints existed.
 */
export interface VesExecutionControl {
    isPaused(): boolean;
    setPaused(paused: boolean): void;
}

/**
 * What the program is, as the machine reads it.
 *
 * The panel used to show forty-eight lines around the program counter and
 * nothing else — no names, nowhere to stop, and a window that redrew rather
 * than scrolled. Three things were added, and they lean on each other: the
 * symbols name what the listing points at, the listing can be walked and
 * followed, and the machine can be stopped somewhere while you read it.
 *
 * Stopping is the part with a cost. Breakpoints are checked on every
 * instruction the core executes, so they are armed in the core only while
 * this panel holds some, and given back when it is closed or hidden.
 */
export class DisassemblyPanel extends Panel {

    protected lines: DisassemblyLine[] = [];
    protected error?: string;
    protected follow = this.remembered('follow', true);
    /** The address the window starts at while not following. */
    protected address = 0;
    /** Where the machine is, which the gutter marks. */
    protected pc?: number;

    /** Armed addresses, which the gutter draws and the core is told about. */
    protected breakpoints = new Set<number>();
    /** The line Run to Cursor means, set by clicking one. */
    protected selected?: number;
    /** Addresses jumped from, newest last. */
    protected history: number[] = [];

    protected symbols?: SymbolIndex;
    protected lineTable?: VesLineTable;
    /**
     * Source files, by the path the line table names, split into lines.
     *
     * Null for one that could not be read, which is as worth remembering as
     * the text: without it the panel would ask for the same missing file on
     * every refresh.
     */
    protected sources = new Map<string, string[] | null>();
    /** Whether the source view is on, which is a per-panel choice. */
    protected showSource = this.remembered('source', true);

    /** Held while the rail is being dragged, as the offset within the thumb. */
    protected railGrab?: number;

    protected watched?: Sim;
    protected readonly watching = new DisposableCollection();
    protected scroller: HTMLElement | undefined;

    constructor(
        source: DebugSource,
        instanceId: string,
        protected readonly control?: VesExecutionControl,
    ) {
        super(EmulatorPanelType.DISASSEMBLY, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/disassembly/title', 'Disassembly');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.DISASSEMBLY);
        this.toDispose.push(this.watching);
    }

    protected pollHz(): number {
        return 4;
    }

    protected async refresh(): Promise<void> {
        this.followMachine();
        const sim = this.source.sim;
        if (!sim) {
            this.lines = [];
            this.pc = undefined;
            this.update();
            return;
        }

        this.symbols = await this.source.getSymbols();
        if (this.showSource && this.lineTable === undefined) {
            this.lineTable = await this.source.getLineTable();
        }

        try {
            const { pc } = await sim.readRegisters();
            this.pc = pc >>> 0;
            if (this.follow) {
                // Started a few instructions above the program counter, so
                // there is something to read on the way in rather than the
                // current instruction sitting on the top edge.
                this.lines = await sim.disassemble(this.pc, LINES, LEAD);
                this.address = this.lines[0]?.address ?? this.pc;
            } else {
                this.lines = await sim.disassemble(this.address, LINES);
            }
            this.error = undefined;
        } catch (error) {
            this.lines = [];
            this.error = error instanceof Error ? error.message : String(error);
        }
        this.update();
    }

    /** Point the panel at whatever machine there is now. */
    protected followMachine(): void {
        const sim = this.source.sim;
        if (sim === this.watched) {
            return;
        }
        this.watching.dispose();
        this.watched = sim;
        this.lineTable = undefined;
        this.sources.clear();
        this.breakpoints.clear();
        this.history = [];
        this.selected = undefined;
        if (!sim) {
            return;
        }
        // A breakpoint suspends the machine, and the first thing anybody
        // wants then is to see where it stopped.
        this.watching.push(sim.onStopped(stop => {
            this.follow = this.remember('follow', true);
            this.pc = stop.address;
            this.selected = stop.address;
            if (stop.reason !== StopReason.STEP) {
                this.update();
            }
            this.refresh().catch(() => undefined);
        }));
        this.watching.push({
            dispose: () => { sim.setBreakpoints([]).catch(() => undefined); },
        });
    }

    /**
     * Set or clear one, through the shared set rather than a set of its own.
     *
     * The source line travels with it where there is one, so a breakpoint put
     * on an instruction here is the same breakpoint an editor would show on
     * that line — and survives a rebuild moving the code, which is what
     * `VesBreakpoints.reresolve` is for. Arming the machine is the dock's
     * business: this set is not this panel's alone, and it stays armed while
     * this panel is closed.
     */
    protected toggleBreakpoint(row: DisassemblyRow): void {
        this.source.breakpoints.toggle(row.line.address, row.source);
        this.update();
    }

    // --- driving the machine ------------------------------------------------

    protected get paused(): boolean {
        return this.control?.isPaused() ?? false;
    }

    protected async step(): Promise<void> {
        const sim = this.watched;
        if (!sim || !this.paused) {
            return;
        }
        await sim.stepInstruction();
        this.follow = this.remember('follow', true);
        await this.refresh();
    }

    /**
     * One instruction, or the whole of the call it makes.
     *
     * The panel decides which, because it is the one holding the listing: a
     * call is stepped over by arming the instruction after it and letting the
     * machine run into it, and anything else is an ordinary step.
     */
    protected async stepOver(): Promise<void> {
        const sim = this.watched;
        if (!sim || !this.paused || this.pc === undefined) {
            return;
        }
        const here = this.lines.find(line => line.address === this.pc);
        if (!here || !/^jal$/i.test(here.mnemonic)) {
            await this.step();
            return;
        }
        await this.runTo((here.address + here.code.length) >>> 0);
    }

    protected async runTo(address: number): Promise<void> {
        const sim = this.watched;
        if (!sim) {
            return;
        }
        await sim.runTo(address);
        this.control?.setPaused(false);
    }

    // --- naming -------------------------------------------------------------

    /**
     * The listing with everything the symbols can say about it.
     *
     * Worked out in `emulator-disassembly`, which is a pure function of the
     * lines and the symbol index and so can be run over a real build without
     * a browser — see `tests/disassembly-symbols-probe.mjs`.
     */
    protected rows(): DisassemblyRow[] {
        const romBytes = Math.max(0, this.source.romSize) * BYTES_PER_MBIT;
        const rows = annotateDisassembly(this.lines, this.symbols, romBytes);
        if (!this.showSource) {
            return rows;
        }
        attachSourceLines(rows, this.lineTable, romBytes);
        this.requestSources(rows);
        return rows;
    }

    /**
     * Read the files this window turned out to need, once each.
     *
     * From the render, because that is where it becomes known which files
     * those are, and asynchronously because nothing should wait on a disk to
     * draw a listing: the line arrives on the next refresh, which is a tenth
     * of a second later.
     */
    protected requestSources(rows: DisassemblyRow[]): void {
        for (const row of rows) {
            const file = row.source?.file;
            if (file === undefined || this.sources.has(file)) {
                continue;
            }
            // Claimed before the read, so a file asked for twice in one frame
            // is still only read once.
            this.sources.set(file, null);
            this.source.readSource(file)
                .then(text => {
                    if (text !== undefined) {
                        this.sources.set(file, text.split(/\r?\n/));
                        this.update();
                    }
                })
                .catch(() => { /* an unreadable file stays null */ });
        }
    }

    /** One line of a source file, or undefined while it is not to hand. */
    protected sourceText(file: string, line: number): string | undefined {
        const text = this.sources.get(file);
        return text ? text[line - 1]?.trim() : undefined;
    }

    // --- moving around ------------------------------------------------------

    /** Stop following and leave the window where it is. */
    protected pin(): void {
        if (this.follow) {
            this.follow = this.remember('follow', false);
        }
    }

    protected goTo(address: number, remember = true): void {
        if (remember && this.lines.length > 0) {
            this.history.push(this.address);
            if (this.history.length > MAX_HISTORY) {
                this.history.shift();
            }
        }
        this.pin();
        this.address = address >>> 0;
        this.selected = address >>> 0;
        this.refresh().catch(() => undefined);
    }

    /**
     * Back to where the machine is, and stay with it.
     *
     * Following is otherwise given up by anything that moves the window on
     * purpose — see `pin` — so this is how somebody who has read their way
     * across the program gets back to what is running.
     */
    protected goToProgramCounter(): void {
        this.follow = this.remember('follow', true);
        if (this.pc !== undefined) {
            this.selected = this.pc;
        }
        this.refresh().catch(() => undefined);
    }

    protected back(): void {
        const to = this.history.pop();
        if (to !== undefined) {
            this.pin();
            this.address = to;
            this.refresh().catch(() => undefined);
        }
    }

    /** Move the window by whole instructions, which is what a listing scrolls in. */
    protected scrollBy(instructions: number): void {
        if (instructions === 0 || this.lines.length === 0) {
            return;
        }
        this.pin();
        const sim = this.watched;
        if (!sim) {
            return;
        }
        if (instructions > 0) {
            const at = this.lines[Math.min(instructions, this.lines.length - 1)];
            this.address = at.address;
        } else {
            // Backwards is the core's own walk; nothing in the bytes before
            // an address says where the instruction before it began.
            sim.disassemble(this.address, 1, -instructions)
                .then(lines => {
                    if (lines.length > 0) {
                        this.address = lines[0].address;
                        this.refresh().catch(() => undefined);
                    }
                })
                .catch(() => undefined);
            return;
        }
        this.refresh().catch(() => undefined);
    }

    // --- the rail -----------------------------------------------------------

    /**
     * How far into the cartridge an address is, as a fraction.
     *
     * By ROM offset rather than by the address itself, because the same code
     * is reachable through two windows — the cartridge's own and the mirror
     * the machine boots from — and only the offset is the same in both. So
     * the thumb says where in the *program* the window is, whichever window
     * it happens to be reading through.
     */
    protected shareOf(address: number): number {
        const romBytes = this.romBytes;
        return romBytes > 0 ? romOffsetOf(address, romBytes) / romBytes : 0;
    }

    protected get romBytes(): number {
        return Math.max(0, this.source.romSize) * BYTES_PER_MBIT;
    }

    /** Where the thumb sits and how tall it is, down a rail of `height`. */
    protected railThumb(height: number): { top: number; size: number } {
        const size = Math.min(height, MIN_THUMB);
        const span = Math.max(0, height - size);
        return { top: this.shareOf(this.address) * span, size };
    }

    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void {
        const box = event.currentTarget.getBoundingClientRect();
        const { top, size } = this.railThumb(box.height);
        const at = event.clientY - box.top;
        // Taken hold of by the thumb, it is dragged from where it was held;
        // taken anywhere else, it jumps to the pointer and is held by its
        // middle — which is how every scrollbar with jump-to-click behaves.
        this.railGrab = at >= top && at < top + size ? at - top : size / 2;
        event.currentTarget.setPointerCapture(event.pointerId);
        this.scrubRail(box, event.clientY);
    }

    protected scrubRail(box: DOMRect, clientY: number): void {
        const romBytes = this.romBytes;
        if (this.railGrab === undefined || romBytes <= 0) {
            return;
        }
        const { size } = this.railThumb(box.height);
        const span = Math.max(1, box.height - size);
        const share = Math.min(1, Math.max(0, (clientY - box.top - this.railGrab) / span));
        // Into the cartridge window, which is where a build's own addresses
        // are and where the machine runs; the mirror is only the vectors.
        this.pin();
        this.address = (CART_WINDOW_BASE + Math.floor(share * romBytes)) >>> 0;
        this.refresh().catch(() => undefined);
    }

    protected releaseRail(event: React.PointerEvent<HTMLDivElement>): void {
        if (this.railGrab === undefined) {
            return;
        }
        this.railGrab = undefined;
        event.currentTarget.releasePointerCapture(event.pointerId);
        this.update();
    }

    /** Take what the Go To box was given: an address, or a routine's name. */
    protected goToText(text: string): void {
        const trimmed = text.trim();
        if (trimmed.length === 0) {
            return;
        }
        const asHex = /^(0x)?([0-9a-fA-F]{1,8})$/.exec(trimmed);
        if (asHex) {
            this.goTo(Number.parseInt(asHex[2], 16) >>> 0);
            return;
        }
        const wanted = trimmed.toLowerCase();
        const found = this.symbols?.codeSymbols.find(symbol =>
            functionDisplayName(this.symbols!, symbol.name).toLowerCase() === wanted
            || symbol.name.toLowerCase() === wanted
            || symbol.name.replace(/^_/, '').toLowerCase() === wanted);
        if (found) {
            this.goTo(found.address);
        }
    }

    // --- drawing ------------------------------------------------------------

    protected render(): React.ReactNode {
        if (!this.source.sim) {
            return <EmptyContainer
                title={nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')}
                icon={<Plug size={32} />}
            />;
        }
        if (this.error) {
            return <div className='vp-disassembly'>
                {this.renderToolbar()}
                <EmptyContainer title={this.error} icon={<Warning size={32} />} />
            </div>;
        }

        return <div className='vp-disassembly'>
            {this.renderToolbar()}
            <div className='vp-disassembly-body'>
                <div
                    className='vp-disassembly-lines vp-scroll'
                    tabIndex={0}
                    ref={element => { this.scroller = element ?? undefined; }}
                    onWheel={event => {
                        event.preventDefault();
                        this.scrollBy(Math.sign(event.deltaY) * 3);
                    }}
                    onKeyDown={event => this.onKey(event)}
                >
                    {this.rows().map(row => this.renderRow(row))}
                </div>
                {this.renderRail()}
            </div>
        </div>;
    }

    /**
     * The scrollbar, over the cartridge rather than over the lines.
     *
     * The listing is a window of forty-eight instructions, not a list long
     * enough to scroll — so a scrollbar over its own content would say only
     * how far down forty-eight lines you are, which is nothing anybody wants
     * to know. This says where in the program the window sits, and takes you
     * anywhere in it. The Memory panel's rail answers the same question the
     * same way.
     *
     * Absent for a ROM whose size nothing reported: there is then no extent
     * to be a fraction of.
     */
    protected renderRail(): React.ReactNode {
        if (this.romBytes <= 0) {
            return undefined;
        }
        const height = this.scroller?.clientHeight ?? 0;
        const { top, size } = this.railThumb(height || 1);
        return <div
            className={`vp-disassembly-rail${this.railGrab !== undefined ? ' dragging' : ''}`}
            role='scrollbar'
            aria-orientation='vertical'
            aria-label={nls.localize('vueport/debug/panels/disassembly/scrub', 'Position in the cartridge')}
            onPointerDown={event => this.grabRail(event)}
            onPointerMove={event => {
                if (this.railGrab !== undefined) {
                    this.scrubRail(event.currentTarget.getBoundingClientRect(), event.clientY);
                }
            }}
            onPointerUp={event => this.releaseRail(event)}
            onPointerCancel={event => this.releaseRail(event)}
        >
            {/* Where the machine is, so the rail says how far from it you have
                read as well as where you are. */}
            {this.pc !== undefined && <div
                className='vp-disassembly-rail-pc'
                style={{ top: `${this.shareOf(this.pc) * 100}%` }}
                title={`0x${hex(this.pc, 8)}`}
            />}
            <div
                className='vp-disassembly-rail-thumb'
                style={{ top: `${top}px`, height: `${size}px` }}
            />
        </div>;
    }

    protected onKey(event: React.KeyboardEvent): void {
        if (event.key === 'Backspace' || (event.key === 'ArrowLeft' && event.altKey)) {
            event.preventDefault();
            this.back();
        } else if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.scrollBy(1);
        } else if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.scrollBy(-1);
        }
    }

    protected renderToolbar(): React.ReactNode {
        const paused = this.paused;
        const stopped = this.control !== undefined && paused;
        return <div className='vp-panel-toolbar vp-disassembly-toolbar'>
            {this.control && <button
                className={`vp-button${paused ? '' : ' secondary'}`}
                onClick={() => this.control?.setPaused(!paused)}
            >
                {paused
                    ? <><Play size={13} weight='fill' />{nls.localize('vueport/debug/panels/disassembly/run', 'Run')}</>
                    : <><Pause size={13} weight='fill' />{nls.localize('vueport/debug/panels/disassembly/pause', 'Pause')}</>}
            </button>}
            <button
                className='vp-button secondary'
                disabled={!stopped}
                onClick={() => { this.step().catch(() => undefined); }}
            >
                {nls.localize('vueport/debug/panels/disassembly/step', 'Step')}
            </button>
            <button
                className='vp-button secondary'
                disabled={!stopped}
                onClick={() => { this.stepOver().catch(() => undefined); }}
            >
                {nls.localize('vueport/debug/panels/disassembly/over', 'Over')}
            </button>
            <button
                className='vp-button secondary'
                disabled={this.control === undefined || this.selected === undefined}
                onClick={() => {
                    if (this.selected !== undefined) {
                        this.runTo(this.selected).catch(() => undefined);
                    }
                }}
            >
                {nls.localize('vueport/debug/panels/disassembly/runToCursor', 'Run to cursor')}
            </button>
            <button
                className={`vp-button secondary vp-disassembly-here${this.follow ? ' active' : ''}`}
                disabled={this.pc === undefined}
                title={nls.localize('vueport/debug/panels/disassembly/toPc',
                    'Go to the program counter and follow it')}
                onClick={() => this.goToProgramCounter()}
            >
                <Crosshair size={14} />
            </button>
            <button
                className='vp-button secondary vp-disassembly-back'
                disabled={this.history.length === 0}
                title={nls.localize('vueport/debug/panels/disassembly/back', 'Back')}
                onClick={() => this.back()}
            >
                <ArrowUUpLeft size={14} />
            </button>
            <input
                className='vp-input vp-disassembly-goto'
                spellCheck={false}
                placeholder={nls.localize('vueport/debug/panels/disassembly/goTo', 'Go to symbol or address…')}
                onKeyDown={event => {
                    if (event.key === 'Enter') {
                        this.goToText((event.target as HTMLInputElement).value);
                    }
                }}
            />
            <label className='vp-disassembly-source-toggle'>
                <input
                    type='checkbox'
                    checked={this.showSource}
                    onChange={event => {
                        this.showSource = this.remember('source', event.target.checked);
                        this.refresh().catch(() => undefined);
                    }}
                />
                {nls.localize('vueport/debug/panels/disassembly/source', 'Source')}
            </label>
        </div>;
    }

    protected renderRow(row: DisassemblyRow): React.ReactNode {
        const { line } = row;
        const isPC = this.pc === line.address;
        const point = this.source.breakpoints.at(line.address);
        const armed = point !== undefined;
        const classes = ['vp-disassembly-line'];
        if (isPC) {
            classes.push('current');
        }
        if (this.selected === line.address) {
            classes.push('selected');
        }
        if (row.adrift) {
            classes.push('adrift');
        }

        const source = row.source;
        const text = source && this.sourceText(source.file, source.line);
        return <React.Fragment key={line.address}>
            {row.header && <div className='vp-disassembly-header'>
                <span className='name'>{row.header.name}</span>
                <span className='at'>{hex(row.header.address, 8)}</span>
                {row.header.size > 0 && <span className='size'>
                    {nls.localize('vueport/debug/panels/disassembly/bytes', '{0} bytes', row.header.size)}
                </span>}
            </div>}
            {/* The C this instruction came from, above the instructions it
                produced rather than beside each of them. */}
            {source && <div className='vp-disassembly-source'>
                <span className='at'>{`${shortPath(source.file)}:${source.line}`}</span>
                {text !== undefined && <span className='text'>{text}</span>}
            </div>}
            <div
                className={classes.join(' ')}
                onClick={() => { this.selected = line.address; this.update(); }}
            >
                <button
                    type='button'
                    className={`vp-disassembly-gutter${armed ? ' armed' : ''}`
                        + (point && !point.enabled ? ' off' : '')}
                    aria-label={nls.localize('vueport/debug/panels/disassembly/breakpoint', 'Breakpoint')}
                    title={point?.origin
                        ? `${shortPath(point.origin.file)}:${point.origin.line}`
                        : undefined}
                    onClick={event => {
                        event.stopPropagation();
                        this.toggleBreakpoint(row);
                    }}
                >
                    {isPC
                        ? <Play size={16} weight='fill' />
                        : <Circle size={16} weight='fill' />
                    }
                </button>
                <span className='address'>{hex(line.address, 8)}</span>
                <span className='code'>{line.code.map(byte => hex(byte, 2)).join(' ')}</span>
                {row.adrift
                    ? <span className='mnemonic adrift-note'>
                        {nls.localize(
                            'vueport/debug/panels/disassembly/adrift',
                            'not an instruction — the core mis-sized the branch above'
                        )}
                    </span>
                    : <>
                        <span className='mnemonic'>{line.mnemonic}</span>
                        <span className='operands'>{this.renderOperands(row)}</span>
                    </>}
            </div>
        </React.Fragment>;
    }

    protected renderOperands(row: DisassemblyRow): React.ReactNode {
        return <>
            {row.line.operands.map((operand, index) => {
                const target = row.targets.get(index);
                return <React.Fragment key={index}>
                    {index > 0 && ', '}
                    {target
                        ? <button
                            type='button'
                            className='vp-disassembly-target'
                            title={`0x${hex(target.address, 8)}`}
                            onClick={event => {
                                event.stopPropagation();
                                this.goTo(target.address);
                            }}
                        >{target.label}</button>
                        : operand}
                </React.Fragment>;
            })}
            {row.loaded && <button
                type='button'
                className='vp-disassembly-loaded'
                title={`0x${hex(row.loaded.address, 8)}`}
                onClick={event => {
                    event.stopPropagation();
                    this.goTo(row.loaded!.address);
                }}
            >{`→ ${row.loaded.label}`}</button>}
        </>;
    }
}
