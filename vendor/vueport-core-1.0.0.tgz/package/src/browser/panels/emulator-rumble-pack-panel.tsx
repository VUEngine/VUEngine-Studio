import { Message } from '@lumino/messaging';
import * as React from 'react';
import { Disposable } from '../../common/emulator-events';
import { formatLogTime } from '../../common/emulator-log';
import { nls } from '../../common/emulator-nls';
import {
    getRumbleEffectName,
    isRumblePlaying,
    RumbleCommand,
    rumbleEffectAmplitudeAt,
    rumbleEffectMs,
    rumbleEffectShape,
    RumbleState,
    VueportRumblePack,
} from '../../common/emulator-rumble';
import { EmulatorPanelType, DebugSource, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';

/**
 * The mark on the pack's face plate, traced from the hardware.
 *
 * Two paths and no `clipPath`, because the panel can be open twice at once —
 * a linked pair has a dock each — and two copies of an element with the same
 * id in one document is a thing that works until it does not. The hatching is
 * therefore the stripes already cut to the shape rather than stripes behind a
 * clip: seven bands every 10.4 units at 62 degrees, intersected with the
 * outline inset by the width of its own border. Computed once, written down
 * here; the plate is a pentagon 84 wide and 66 tall whose sides fall straight
 * for 44 and then run together to a point.
 *
 * RetroOnyx's, whose pack this is. On the plate to make the box look like the
 * device it stands for; it is one constant and one rule away from not being
 * there, if that is ever the wrong call.
 */
const PLATE_OUTLINE = 'M8 4L92 4L92 48L50 70L8 48Z';
const PLATE_HATCHING = 'M17.5 13.5L22.1 13.5L17.5 22.1Z'
    + 'M28.2 13.5L33.9 13.5L18.3 42.7L17.5 42.3L17.5 33.6Z'
    + 'M40.0 13.5L45.6 13.5L27.6 47.5L23.1 45.2Z'
    + 'M51.8 13.5L57.4 13.5L36.8 52.3L32.3 50.0Z'
    + 'M63.5 13.5L69.2 13.5L46.0 57.2L41.5 54.8Z'
    + 'M75.3 13.5L81.0 13.5L59.2 54.5L51.3 58.6Z'
    + 'M82.5 22.1L82.5 32.8L75.5 45.9L67.7 50.0Z';

/**
 * What the running game is asking a rumble pack to do, and whether one is
 * plugged in to do it.
 *
 * Everything but the connection block is shown either way. The rumble commands
 * a game broadcasts are read off the emulated link port, not off the hardware,
 * so decoding them is just as useful to somebody who owns no pack — which is
 * why the port is read for as long as a game is running, whether or not one is
 * plugged in and whether or not this host could even take one. A page cannot
 * open a serial port and still shows everything here but the buzz; see
 * `DecodingRumblePack`.
 *
 * The one thing that stops it is a second player: a link cable and a pack want
 * the same socket, so while a session is running the port is the cable's and
 * this panel says so rather than decoding the traffic between the two machines
 * as rumble commands nobody sent. See `applyRumbleForwarding` on the widget.
 *
 * Connection is pushed as an event, and so is every byte the port carries, so
 * the inherited polling is slowed right down; what it is left doing is
 * noticing a simulation appearing or going away.
 */
export class RumblePackPanel extends Panel {

    /**
     * The least time the motor box shakes for, in ms.
     *
     * A floor rather than an addition: an effect runs for its own measured
     * length now (see `RUMBLE_EFFECT_SHAPES`), and the shortest of them is a
     * 69 ms tick — four frames, which is a flicker rather than a shake. So
     * the short ones are stretched to where the eye can catch them and
     * everything else is left exactly as long as it really is.
     */
    protected static readonly MOTOR_MIN_MS = 120;

    /**
     * How often the box is redrawn while an effect runs, in ms.
     *
     * Only the 48 ramps need it — they change strength as they go, and a box
     * redrawn twice over a 320 ms rise would show two steps of it. Flat
     * effects look the same at every redraw, so this costs them nothing but
     * the redraw itself, which is a handful of nodes.
     */
    protected static readonly MOTOR_STEP_MS = 60;

    /** Set while a detection triggered from here is in flight. */
    protected detecting = false;
    /** Why the last detection failed, if it did. Cleared by the next attempt. */
    protected error: string | undefined;
    /** The redraw that carries a shake on, and the one that ends it. */
    protected motorTimer: ReturnType<typeof setTimeout> | undefined;

    constructor(
        source: DebugSource,
        instanceId: string,
        protected readonly rumblePack: VueportRumblePack
    ) {
        super(EmulatorPanelType.RUMBLE_PACK, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/rumblePack/title', 'Rumble Pack');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.RUMBLE_PACK);
    }

    protected onAfterAttach(msg: Message): void {
        super.onAfterAttach(msg);
        // Re-subscribed on every attach because toDisposeOnDetach is emptied
        // when the panel is detached, which a dock layout change does.
        this.toDisposeOnDetach.push(
            this.rumblePack.onDidChangeConnected(() => this.update())
        );
        // A detached panel has no shake left to end.
        this.toDisposeOnDetach.push(Disposable.create(() => {
            clearTimeout(this.motorTimer);
            this.motorTimer = undefined;
        }));
    }

    protected pollHz(): number {
        return 1;
    }

    protected refresh(): void {
        this.update();
    }

    protected async detect(): Promise<void> {
        // The port prompt is modal, but the button stays clickable behind a
        // detection that is only waiting on the device itself.
        if (this.detecting) {
            return;
        }
        this.detecting = true;
        this.error = undefined;
        this.update();
        try {
            await this.rumblePack.detect();
        } catch (error) {
            // Picking no device in the port prompt is swallowed by the service
            // itself; what reaches here is a port that could not be opened,
            // usually because something else already holds it.
            this.error = error instanceof Error ? error.message : String(error);
        } finally {
            this.detecting = false;
            this.update();
        }
    }

    protected render(): React.ReactNode {
        const commands = this.rumblePack.emulatedCommands;
        const rumbleState = this.rumblePack.emulatedRumbleState;

        return <div className='vp-rumble-pack'>
            {this.renderConnection(rumbleState)}
            {this.error && <div className='vp-rumble-pack-error'>{this.error}</div>}
            {this.renderEffect(rumbleState)}
            {this.renderCommands(commands)}
        </div>;
    }

    /**
     * The whole connection story, in one box.
     *
     * It used to be spread over three: a banner saying whether a pack was
     * attached, a note under it about the link cable, and rows further down
     * for the board, its USB ids and what the port was carrying. Between them
     * they answer one question — why is nothing buzzing — and answering it
     * meant reading all three and joining them up. So they are one line now:
     * what is attached, what the port is doing with it, and the one button
     * that can change the answer.
     *
     * There are exactly three situations, and the box says which it is in its
     * own right rather than by the absence of something: a pack is attached; a
     * link cable has the port the pack would have used; or there is no pack,
     * in which case the commands below are still worth reading.
     */
    protected renderConnection(state: RumbleState): React.ReactNode {
        const port = this.rumblePack.connected;
        // The cable has the one link port, so the pack is off until it is out.
        // See `applyRumbleForwarding` on the widget.
        const cabled = this.rumblePack.linkPortInUse === true;
        const info = this.rumblePack.deviceIds;
        // Undefined from a host written before the flag existed, and every one
        // of those could open a port. See `canConnect`.
        const canConnect = this.rumblePack.canConnect !== false;
        const mode = cabled ? 'cabled' : port ? 'connected' : 'disconnected';

        const detail: React.ReactNode = cabled
            // Why an attached pack is sitting still, and why there is no point
            // looking for one that is not: on the hardware the cable and the
            // pack want the same socket.
            ? nls.localize(
                'vueport/debug/panels/rumblePack/linkPortTaken',
                'Switched off while a second player is linked: a Rumble Pack and a link cable share the one link port.'
            )
            : port
                // The ids as they are written on the device's data sheet,
                // beside the name they belong to rather than a table apart
                // from it. Only they are monospaced: the rest of the line is a
                // sentence, and a sentence set in code font reads as something
                // to be typed back in.
                ? <>
                    {info && <><code>{usbId(info.vendor)} / {usbId(info.product)}</code> · </>}
                    {this.rumblePack.forwarding
                        ? nls.localize(
                            'vueport/debug/panels/rumblePack/forwardingOn',
                            'forwarding from the emulator'
                        )
                        : nls.localize(
                            'vueport/debug/panels/rumblePack/forwardingOff',
                            'idle until a game is running'
                        )}
                </>
                : !this.rumblePack.forwarding
                    ? nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')
                    : canConnect
                        ? nls.localize(
                            'vueport/debug/panels/rumblePack/decodingOnly',
                            'Connect your Rumble Pack via USB, then click "Detect".'
                        )
                        // Not a fault and not a thing to go looking for: this
                        // browser has no way to open a serial port, however
                        // many packs are plugged into the machine. Chromium
                        // ones do, and take the branch above — so this is
                        // about the browser rather than about the build.
                        : nls.localize(
                            'vueport/debug/panels/rumblePack/decodingOnlyHost',
                            'Not supported in this browser.'
                        );

        return <div className={`vp-rumble-pack-status ${mode}`}>
            {this.renderMotor(this.motorStrength(state), state.frequency)}
            <div className='vp-rumble-pack-status-text'>
                <div className='vp-rumble-pack-status-headline'>{port
                    ? nls.localize(
                        'vueport/debug/panels/rumblePack/connected',
                        'Connected',
                    )
                    : nls.localize('vueport/debug/panels/rumblePack/notConnected', 'No Rumble Pack connected')}
                </div>
                { /* }
                <div className='vp-rumble-pack-status-detail'>
                    {port && (this.rumblePack.deviceName ?? nls.localize(
                        'vueport/debug/panels/rumblePack/unknownBoard',
                        'Unknown board'
                    ))}
                </div>
                { */ }
                <div className='vp-rumble-pack-status-detail'>
                    {detail}
                </div>
                {/* What has gone down the wire, and what came back up it. Only
                    with hardware at the other end: with none attached the same
                    counter is bytes nobody received, which is a number about
                    the game rather than about the pack this box is for, and
                    nothing has answered to have a last word. */}
                {port && <div className='vp-rumble-pack-status-count'>
                    {nls.localize(
                        'vueport/debug/panels/rumblePack/bytesSent',
                        '{0} bytes sent',
                        this.rumblePack.emulatedByteCount
                    )}
                    {/* Beside the count rather than in a group of its own
                        below: both are one line about the conversation with
                        the device, and a fieldset holding a single row was
                        more furniture than answer. Shown only once there is a
                        reply — a dash was there to fill a table cell that no
                        longer exists. */}
                    {this.rumblePack.lastReply !== undefined && <>
                        {' · '}
                        {nls.localize('vueport/debug/panels/rumblePack/lastReply', 'Last reply')}
                        {': '}
                        <code>{this.rumblePack.lastReply}</code>
                    </>}
                    {/* Only when there are any. A game asking for more than the
                        board can take is the one thing that looks exactly like
                        a pack misbehaving, so it is worth saying out loud —
                        and silence is the ordinary case. */}
                    {(this.rumblePack.droppedCommands ?? 0) > 0 && <span className='vp-rumble-pack-dropped'>
                        {' · '}
                        {nls.localize(
                            'vueport/debug/panels/rumblePack/dropped',
                            '{0} dropped',
                            this.rumblePack.droppedCommands ?? 0
                        )}
                    </span>}
                </div>}
            </div>
            {/* Offered only where pressing it could find something: not while
                the cable has the port, and not in a build with nowhere to
                look. A button that can only fail is worse than none. */}
            {!cabled && canConnect && <button
                className='vp-button secondary'
                onClick={() => this.detect()}
                disabled={this.detecting}
            >
                {this.detecting
                    ? nls.localize('vueport/debug/panels/rumblePack/detecting', 'Searching...')
                    : port
                        ? nls.localize('vueport/debug/panels/rumblePack/reconnect', 'Reconnect')
                        : nls.localize('vueport/debug/panels/rumblePack/detect', 'Detect')}
            </button>}
        </div>;
    }

    /**
     * The pack itself: a box that shakes while the motor is running.
     *
     * The rest of the panel is numbers, and numbers are read one after another;
     * an effect is over by the time the third of them has been. This is the one
     * part that can be taken in without reading, which is what makes it worth
     * the space — and it is as true with no pack attached, where it shows what
     * a pack would be doing with the commands the game is sending.
     */
    protected renderMotor(strength: number | undefined, frequency: number | undefined): React.ReactNode {
        // Indicative, not literal: the frequency is the one the motor is
        // really driven at — measuring the pack found its peak at 164 Hz while
        // the emulator was asking for 160 — but 160 shakes a second is well
        // past what a screen can draw. So the range is mapped onto one that
        // still reads as the difference between a shudder and a buzz.
        const period = frequency === undefined
            ? 130
            : Math.min(200, Math.max(60, Math.round(200 - frequency / 3)));
        // Rounded, and the rounding is load-bearing: it is this element's key,
        // so a change of strength remounts it and the shake starts again at
        // the new size. A CSS animation already running is not obliged to
        // notice that a custom property inside its keyframes has moved.
        const amount = strength === undefined ? 0 : Math.round(strength * 10) / 10;

        return <div
            key={amount}
            className={`vp-rumble-pack-motor${strength === undefined ? '' : ' running'}`}
            style={{
                '--vp-rumble-period': `${period}ms`,
                '--vp-rumble-amount': amount,
            } as React.CSSProperties}
            // Decoration over what the Last Effect group already says in words.
            aria-hidden={true}
        >
            {/* The face plate's mark, which is what makes the box read as a
                pack rather than as a rectangle. See `PLATE_OUTLINE`. */}
            <svg className='vp-rumble-pack-plate' viewBox='-4 -4 108 82'>
                <path
                    d={PLATE_OUTLINE}
                    fill='none'
                    stroke='currentColor'
                    strokeWidth={7}
                    strokeLinejoin='round'
                />
                <path d={PLATE_HATCHING} fill='currentColor' />
            </svg>
        </div>;
    }

    /**
     * How hard to draw the motor as shaking, or undefined for still.
     *
     * Three things sit between `state.playing` and the answer. An effect ends
     * on its own after the length it was measured to run, whether or not the
     * game bothers to say so, which is `isRumblePlaying`. A ramp is a
     * different strength at its start than at its end, which is
     * `rumbleEffectAmplitudeAt`. And the shortest effects in the library are
     * over in a few frames, which is where {@link MOTOR_MIN_MS} comes in.
     *
     * The bytes bring their own redraws — the service fires on every one of
     * them — so the timer here is for the moments no byte arrives for: the
     * next step of a ramp, and the end of an effect nothing came to end.
     */
    protected motorStrength(state: RumbleState): number | undefined {
        const now = Date.now();
        const since = state.playingSince;
        if (state.playing !== true || since === undefined) {
            return undefined;
        }
        const elapsed = now - since;
        // Its own length, floored at what can be seen. `isRumblePlaying` is
        // the shared answer to "is it still going"; the floor is this box's
        // own business, since a badge reading "Playing" for 69 ms would be
        // no more use than a shake lasting 69 ms.
        const running = isRumblePlaying(state, now) || elapsed < RumblePackPanel.MOTOR_MIN_MS;
        if (!running) {
            return undefined;
        }

        const shape = rumbleEffectShape(state.effect);
        const length = Math.max(rumbleEffectMs(shape), RumblePackPanel.MOTOR_MIN_MS);
        if (this.motorTimer === undefined) {
            this.motorTimer = setTimeout(() => {
                this.motorTimer = undefined;
                this.update();
            }, Math.min(RumblePackPanel.MOTOR_STEP_MS, Math.max(16, length - elapsed)));
        }
        return rumbleEffectAmplitudeAt(shape, elapsed / length);
    }

    /**
     * The effect the forwarded bytes add up to, laid out the way the rumble
     * effect editor lays out the same settings.
     *
     * Every field is filled in only over time: the engine skips a command
     * whose value has not changed since the last effect (`Rumble.c` caches
     * them), so a game that never varies its frequency sends it once and a
     * field that has not been seen yet is genuinely unknown rather than zero.
     */
    protected renderEffect(state: RumbleState): React.ReactNode {
        const spec = this.rumblePack.emulatedSpec;
        const rows: [string, string][] = [
            [
                nls.localize('vueport/debug/panels/rumblePack/spec', 'Spec'),
                // No spec at all is the engine's own "nothing is playing"; one
                // without a name is an effect whose spec could not be named.
                spec
                    ? spec.name ?? nls.localize(
                        'vueport/debug/panels/rumblePack/unnamedSpec',
                        'Unnamed, at {0}',
                        `0x${spec.address.toString(16).toUpperCase().padStart(8, '0')}`
                    )
                    : '—',
            ],
            [
                nls.localize('vueport/debug/panels/rumblePack/effects/effect', 'Effect'),
                state.effect === undefined ? '—' : getRumbleEffectName(state.effect),
            ],
            [
                nls.localize('vueport/debug/panels/rumblePack/effects/frequency', 'Frequency'),
                state.frequency === undefined ? '—' : `${state.frequency} Hz`,
            ],
        ];

        return (
            <fieldset className='vp-inspector-group'>
                <legend>
                    {nls.localize('vueport/debug/panels/rumblePack/effect', 'Last Effect')}
                    {/* Not `state.playing`, which is only what the game last
                        asked for: an effect runs its own length and stops
                        without being told to. See `isRumblePlaying`. */}
                    {state.playing !== undefined && <span className='vp-rumble-pack-playing'>
                        {isRumblePlaying(state)
                            ? nls.localize('vueport/debug/panels/rumblePack/effectPlaying', 'Playing')
                            : nls.localize('vueport/debug/panels/rumblePack/effectStopped', 'Stopped')}
                    </span>}
                </legend>
                <table className='vp-rumble-pack-info'>
                    <tbody>
                        {rows.map(([label, value]) => <tr key={label}>
                            <th>{label}</th>
                            <td>{value}</td>
                        </tr>)}
                    </tbody>
                </table>
            </fieldset>
        );
    }

    /** The forwarded bytes mapped back to what each of them asked for. */
    protected renderCommands(commands: RumbleCommand[]): React.ReactNode {
        return (
            <fieldset className='vp-inspector-group'>
                <legend>
                    {nls.localize('vueport/debug/panels/rumblePack/commands', 'Last commands')}
                </legend>
                {commands.length === 0 && <div className='vp-panel-empty'>
                    {this.source.sim
                        ? nls.localize(
                            'vueport/debug/panels/rumblePack/noCommands',
                            'Nothing broadcast yet.'
                        )
                        : nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')}
                </div>}
                <div className='vp-rumble-pack-commands'>
                    {commands.map((command, index) => <div
                        key={index}
                        className={command.unknown ? 'unknown' : undefined}
                    >
                        <span className='vp-log-time'>{formatLogTime(command.at)}</span>
                        <code>{command.bytes.map(byte => byte.toString(16).toUpperCase().padStart(2, '0')).join(' ')}</code>
                        <span>{command.label}</span>
                    </div>)}
                </div>
            </fieldset>
        );
    }
}

/** A USB id as it is written on a device's data sheet, or a dash if unreported. */
function usbId(value: number | undefined): string {
    return value === undefined ? '—' : `0x${value.toString(16).toUpperCase().padStart(4, '0')}`;
}
