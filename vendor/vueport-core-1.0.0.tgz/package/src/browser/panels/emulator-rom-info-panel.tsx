import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import EmptyContainer from '../components/kit/EmptyContainer';
import { BuildMode } from '../core/emulator-elf';
import { MemoryArea, MemoryAreaKind, MemoryFootprint } from '../core/emulator-symbols';
import { VB_WRAM_SIZE } from '../../common/vb-constants';
import { BYTES_PER_MBIT, ROM_HEADER_MAKERS, vbColorSupportLabel } from '../emulator-types';
import { DebugSource, hex, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { Plug, Warning } from '@phosphor-icons/react';

/**
 * The share of a memory at which its bar starts saying so, which is the
 * threshold the Memory Pools panel warns at — a build with a tenth of its
 * cartridge left is in the same position as a pool with a tenth of its blocks
 * left, and there is no reason for the two panels to disagree about when that
 * becomes worth mentioning.
 */
const WARNING_THRESHOLD = 85;

/**
 * The areas in the order a bar stacks them, and what a legend calls each.
 *
 * Fixed rather than taken from the link order, so that the same kind is one
 * band however many sections contributed to it: `MemoryPool` sits inside
 * `.sdata` and would otherwise cut the initialized data into two bands with
 * the heap between them.
 */
const AREA_KINDS: MemoryAreaKind[] = [
    MemoryAreaKind.CODE,
    MemoryAreaKind.READ_ONLY,
    MemoryAreaKind.DATA,
    MemoryAreaKind.ZEROED,
    MemoryAreaKind.POOL,
];

function areaKindLabel(kind: MemoryAreaKind): string {
    switch (kind) {
        case MemoryAreaKind.CODE:
            return nls.localize('vueport/debug/panels/romInfo/area/code', 'Code');
        case MemoryAreaKind.READ_ONLY:
            return nls.localize('vueport/debug/panels/romInfo/area/readOnly', 'Read-only data');
        case MemoryAreaKind.DATA:
            return nls.localize('vueport/debug/panels/romInfo/area/data', 'Initialized data');
        case MemoryAreaKind.ZEROED:
            return nls.localize('vueport/debug/panels/romInfo/area/zeroed', 'Zeroed data');
        case MemoryAreaKind.POOL:
            return nls.localize('vueport/debug/panels/romInfo/area/pool', 'Memory pools');
    }
}

/**
 * A header field, shown at the width the cartridge gives it.
 *
 * The four are fixed-width on the hardware — twenty characters of name, four
 * of game code, two of maker, one of version — and a field padded out to that
 * width says how much of it a game used. `min-width` rather than `width`
 * because the version is a byte and could print three digits; a field is never
 * clipped to make the point.
 */
function field(text: React.ReactNode, characters: number): React.ReactNode {
    return <code
        className='vp-rom-info-field'
        style={{ minWidth: `${characters}ch` }}
    >{text}</code>;
}

/** One band of a bar: everything of one kind, and what it was made of. */
interface AreaBand {
    kind: MemoryAreaKind;
    bytes: number;
    /** The sections behind it, in link order, for the band's tooltip. */
    sections: string[];
}

/**
 * The cartridge header, parsed once when the ROM is loaded, and what the build
 * beside it spent.
 *
 * Almost nothing here is read from the running simulation — the header is
 * pushed by the widget whenever a ROM (re)loads, and the budgets come out of
 * the `.elf`, which does not change while a ROM is running — so there is
 * nothing that benefits from polling ten times a second. It still polls, at a
 * slow rate, purely as a safety net; opening the panel always shows the
 * current header regardless, since the base class refreshes immediately on
 * attach and on show.
 */
export class RomInfoPanel extends Panel {

    /**
     * What the build claimed before it ran, or undefined for a ROM with no
     * `.elf` beside it — which is every ROM that was not built here, and so an
     * ordinary state rather than a failure.
     */
    protected footprint?: MemoryFootprint;

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.ROM_INFO, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/romInfo/title', 'ROM Info');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.ROM_INFO);
    }

    protected pollHz(): number {
        return 1;
    }

    protected async refresh(): Promise<void> {
        // The symbols are read once per ROM and held by the host, so asking on
        // every tick is a promise that has already settled.
        const footprint = (await this.source.getSymbols())?.footprint;
        this.footprint = footprint && (footprint.rom.length > 0 || footprint.wram.length > 0)
            ? footprint
            : undefined;
        this.update();
    }

    protected render(): React.ReactNode {
        if (!this.source.sim) {
            return <EmptyContainer
                title={nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')}
                icon={<Plug size={32} />}
            />;
        }

        const { romHeader, romSize, buildMode, romChecksum } = this.source;
        const maker = ROM_HEADER_MAKERS[romHeader.maker];
        // The build writes the mode in lower case; this is how it is spelled
        // everywhere else in the application, and it carries the description
        // the Build view shows for it.
        const mode = Object.values(BuildMode).find(known => known.toLowerCase() === buildMode);

        return <div className='vp-rom-info-panel'>
            {/* A ROM with no header of its own parses into noise rather than
                into nothing, so the fields below are shown either way and this
                says which of the two they are. */}
            {romSize > 0 && !romHeader.valid && <div className='vp-rom-info-invalid'>
                <Warning size={14} weight='fill' />
                {nls.localize('vueport/debug/panels/romInfo/headerInvalid', 'Header Invalid')}
            </div>}
            <div className='vp-rom-info-columns'>
                {/* What the cartridge says about itself on the left, and what
                    the file itself is on the right. */}
                <table>
                    <tbody>
                        <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/name', 'Name')}</th>
                            <td>{field(romHeader.name.trim(), 20)}</td>
                        </tr>
                        <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/code', 'Code')}</th>
                            <td>{field(romHeader.code, 4)}</td>
                        </tr>
                        <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/maker', 'Maker')}</th>
                            <td>{field(romHeader.maker, 2)}{maker && <> ({maker})</>}</td>
                        </tr>
                        <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/version', 'Version')}</th>
                            <td>1.{field(romHeader.version, 1)}</td>
                        </tr>
                    </tbody>
                </table>
                <table>
                    <tbody>
                        <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/size', 'Size')}</th>
                            <td><code>{romSize}</code> MBit</td>
                        </tr>
                        {romChecksum && <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/checksum', 'CRC32')}</th>
                            <td><code>{romChecksum}</code></td>
                        </tr>}
                        {/* A ROM that was not built here has no map file to read
                            the mode out of, and a row saying so every time says
                            nothing. */}
                        {buildMode && <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/buildMode/title', 'Build Mode')}</th>
                            <td><code>{mode ?? buildMode}</code></td>
                        </tr>}
                        {/* The one field of the header that is not a Virtual
                            Boy's, so it is shown where the rest of VB Color is:
                            only when the feature is switched on. */}
                        {this.source.vbcSupportEnabled && <tr>
                            <th>{nls.localize('vueport/debug/panels/romInfo/vbColor', 'VB Color')}</th>
                            <td>
                                <code>{hex(romHeader.vbcSupport, 2)}</code>
                                {' '}({vbColorSupportLabel(romHeader.vbcSupport)})
                            </td>
                        </tr>}
                    </tbody>
                </table>
            </div>
            {this.renderBudgets(romSize)}
        </div>;
    }

    /**
     * What the build spent of the two memories it cannot grow.
     *
     * Only for a ROM with an `.elf` beside it: the figures are the linker's,
     * and nothing in a bare ROM says which of its bytes are code, which are
     * artwork, or how much of WRAM the game will be standing in.
     */
    protected renderBudgets(romSize: number): React.ReactNode {
        if (!this.footprint) {
            return undefined;
        }
        return <div className='vp-rom-info-budgets'>
            {romSize > 0 && budget(
                nls.localize('vueport/debug/panels/romInfo/usage/rom', 'ROM usage'),
                this.footprint.rom,
                romSize * BYTES_PER_MBIT)}
            {budget(
                nls.localize('vueport/debug/panels/romInfo/usage/wram', 'WRAM usage'),
                this.footprint.wram,
                VB_WRAM_SIZE)}
        </div>;
    }
}

/** One memory: what is in it, how much of it is left, and what filled it. */
function budget(label: string, areas: MemoryArea[], capacity: number): React.ReactNode {
    const bands = bandsOf(areas);
    const used = bands.reduce((sum, band) => sum + band.bytes, 0);
    const share = percent(used, capacity);
    return <div className='vp-rom-info-budget'>
        <div className='vp-rom-info-budget-head'>
            <span>{label}</span>
            <span className={share >= WARNING_THRESHOLD ? 'vp-rom-info-warn' : undefined}>
                {nls.localize(
                    'vueport/debug/panels/romInfo/budget/used',
                    '{0} of {1} · {2}%', kb(used), kb(capacity), `${share}`)}
            </span>
        </div>
        <div className='vp-rom-info-bar'>
            {bands.map(band => <div
                key={band.kind}
                className={`vp-rom-info-area vp-rom-info-area-${band.kind}`}
                style={{ width: `${width(band.bytes, capacity)}%` }}
                title={`${areaKindLabel(band.kind)} · ${kb(band.bytes)}\n${band.sections.join(', ')}`}
            />)}
        </div>
        <div className='vp-rom-info-legend'>
            {bands.map(band => <span key={band.kind}>
                <i className={`vp-rom-info-area-${band.kind}`} />
                {areaKindLabel(band.kind)} {kb(band.bytes)}
            </span>)}
        </div>
    </div>;
}

/** The areas gathered into one band per kind, in the order a bar stacks them. */
function bandsOf(areas: MemoryArea[]): AreaBand[] {
    return AREA_KINDS
        .map(kind => {
            const own = areas.filter(area => area.kind === kind);
            return {
                kind,
                bytes: own.reduce((sum, area) => sum + area.bytes, 0),
                // A kind can be several sections, and a section can appear
                // twice once the heap has been cut out of the middle of it.
                sections: [...new Set(own.map(area => area.name))],
            };
        })
        .filter(band => band.bytes > 0);
}

/**
 * A band's share of the bar, unrounded — the bands have to add up to the share
 * the figures state, and five roundings would not.
 */
function width(bytes: number, capacity: number): number {
    return capacity <= 0 ? 0 : Math.min(100, (100 * bytes) / capacity);
}

/** A whole-number percentage, saturating rather than rounding up to 100. */
function percent(part: number, whole: number): number {
    if (whole <= 0) {
        return 0;
    }
    const share = (100 * part) / whole;
    return share > 0 && share < 1 ? 1 : Math.min(100, Math.round(share));
}

/**
 * Bytes at the scale they are worth reading at.
 *
 * Three of them, because these figures span four orders of magnitude in the
 * same panel: a band can be a handful of bytes, which `0 KB` would report as
 * nothing at all, while a decimal on a megabyte of ROM is noise. `38.2 KB` of
 * WRAM is the case in the middle, and the one somebody can act on.
 */
function kb(bytes: number): string {
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    const value = bytes / 1024;
    return `${value.toLocaleString('en-US', { maximumFractionDigits: value < 100 ? 1 : 0 })} KB`;
}
