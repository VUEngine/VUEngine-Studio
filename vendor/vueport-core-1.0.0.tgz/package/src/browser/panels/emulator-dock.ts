import { Disposable, Emitter } from '../../common/emulator-events';
import { Drag } from '@lumino/dragdrop';
import { Message } from '@lumino/messaging';
import { DockLayout, DockPanel, TabBar, Widget } from '@lumino/widgets';
import { VueportRumblePack } from '../../common/emulator-rumble';
import { EsSoundPlayer } from '../emulator-essound-player';
import { Sim } from '../core/vb-core';
import { VesBreakpoints } from '../core/emulator-breakpoints';
import { VesLineTable } from '../core/emulator-line-table';
import { SymbolIndex } from '../core/emulator-symbols';
import { EMPTY_ROM_HEADER, RomHeader } from '../emulator-types';
import { DisassemblyPanel } from './emulator-disassembly-panel';
import { EsSoundPanel } from './emulator-essound-panel';
import { MemoryPanel } from './emulator-memory-panel';
import { ActorsPanel } from './emulator-actors-panel';
import { MemoryPoolsPanel } from './emulator-memory-pools-panel';
import { ProfilerPanel } from './emulator-profiler-panel';
import {
    EMULATOR_PANEL_TYPES,
    EmulatorPanelType,
    DebugSource,
    InspectedSeat,
    Panel,
} from './emulator-panel';
import { RegistersPanel } from './emulator-registers-panel';
import { RomInfoPanel } from './emulator-rom-info-panel';
import { SramPanel } from './emulator-sram-panel';
import { RumblePackPanel } from './emulator-rumble-pack-panel';
import { ScreenPanel, VesScreenRect } from './emulator-screen-panel';
import { VueportTabBar } from './emulator-tab-bar';
import { TerminalPanel } from './emulator-terminal-panel';
import { BgMapsPanel } from './emulator-vip-bgmaps-panel';
import { CharactersPanel } from './emulator-vip-characters-panel';
import { FrameBuffersPanel } from './emulator-vip-framebuffers-panel';
import { ObjectsPanel } from './emulator-vip-objects-panel';
import { PalettesPanel } from './emulator-vip-palettes-panel';
import { WorldsPanel } from './emulator-vip-worlds-panel';
import { VcuPanel } from './emulator-vcu-panel';
import { VsuPanel } from './emulator-vsu-panel';

/** Panels other than the screen, which is always present. */
/**
 * Every panel that is not the screen.
 *
 * Derived rather than listed. It used to be a list beside the enum, and a
 * panel added to one and not the other was a panel that could be opened from
 * the command palette — which builds one directly — but not from a tab group's
 * "+", and that was dropped from the layout the next time it was restored:
 * both of those go through `widgetFor`, which checks this. Being a copy of the
 * enum, the list could only ever be wrong.
 *
 * The screen is left out because it is not a debug panel and is never created
 * on demand; `widgetFor` answers for it separately.
 */
export const EMULATOR_DEBUG_PANELS = EMULATOR_PANEL_TYPES
    .filter(kind => kind !== EmulatorPanelType.SCREEN);

/**
 * How long a changed panel control waits before being written out.
 *
 * Long enough that a slider dragged across its range stores once rather than
 * forty times, short enough that a window closed straight after a change has
 * already written it — and `dispose` flushes anyway.
 */
const PANEL_PREFERENCE_WRITE_DELAY_MS = 400;

/**
 * The arrangement a freshly opened emulator starts with, and what Reset
 * Layout restores: the screen over a strip of the text panels on the left,
 * every inspector tabbed together on the right, and the two halves even.
 *
 * Every group takes its share of a resize, so the proportions here are what a
 * window of any size keeps.
 *
 * Memory Pools and Actors are deliberately absent. Both read VUEngine's own
 * structures out of a running build — its heap, its class hierarchy — so they
 * say nothing about a ROM that was not built with it, which is most of them.
 * They remain openable, and a host that knows its ROMs are VUEngine's says so
 * by passing a layout of its own (`VueportDockHost#defaultLayout`).
 */
const DEFAULT_LAYOUT: AreaLayout = {
    type: 'split-area',
    orientation: 'horizontal',
    sizes: [50, 50],
    children: [
        {
            type: 'split-area',
            orientation: 'vertical',
            sizes: [70, 30],
            children: [
                { type: 'tab-area', panels: [EmulatorPanelType.SCREEN], currentIndex: 0 },
                {
                    type: 'tab-area',
                    panels: [
                        EmulatorPanelType.ROM_INFO,
                        EmulatorPanelType.MEMORY,
                        EmulatorPanelType.TERMINAL,
                    ],
                    currentIndex: 0,
                },
            ],
        },
        {
            type: 'tab-area',
            panels: [
                EmulatorPanelType.VIP_CHARACTERS,
                EmulatorPanelType.VIP_BGMAPS,
                EmulatorPanelType.VIP_WORLDS,
                EmulatorPanelType.VIP_OBJECTS,
                EmulatorPanelType.VCU,
                EmulatorPanelType.REGISTERS,
            ],
            currentIndex: 0,
        }
    ],
};

/**
 * The emulator's dockable area.
 *
 * Panels can be dragged, split, resized, tabbed and closed like any other dock
 * area, and the arrangement is saved so it survives reopening the emulator.
 * Reset Layout puts it back to the built-in default (DEFAULT_LAYOUT), which is
 * also what a freshly opened emulator starts with. That dragging is sealed off
 * from the rest of the application in both directions — see `trackOwnDrag`
 * and `blockForeignOverlay` — so none of it can end up as a tab in the main
 * shell, and nothing from the shell can end up docked here.
 */
/**
 * What the dock needs from whatever it is embedded in.
 *
 * Both are about coexisting with an outer dock that is also tracking the
 * pointer, which is a situation only VES has: standing alone there is
 * nothing above this dock to confuse, so a host may leave them out entirely.
 */
export interface VueportDockHost {
    /**
     * Tell the surrounding shell to forget the drag it thinks is happening,
     * because this dock is handling it. See `trackOwnDrag`.
     */
    cancelForeignDrag?(): void;
    /**
     * The arrangement a fresh emulator starts with, and what Reset Layout
     * restores. Left out to take the built-in one — see `DEFAULT_LAYOUT` for
     * what that is and what it deliberately leaves closed.
     */
    defaultLayout?: AreaLayout;
    /**
     * The recording profiler — record a session, replay it, export the call
     * tree — for the CPU Profiler panel's own button. Not part of
     * `DebugSource` either: starting a recording drives the
     * emulator, which that interface deliberately cannot. Left out on a host
     * that offers no recording; the button then does not appear.
     */
    isProfiling?(): boolean;
    toggleProfiling?(): void;
    /**
     * Whether the machine is stopped, and how to stop or start it, for the
     * Disassembly panel's own controls.
     *
     * Not part of `DebugSource` for the same reason the profiler's button is
     * not: that interface reads the machine and deliberately cannot drive it,
     * and pausing is driving. A host that leaves these out gets a panel that
     * reads the program but cannot stop it, which is what every host had
     * before breakpoints existed.
     */
    isPaused?(): boolean;
    setPaused?(paused: boolean): void;
    /**
     * The build's line table, and the source files it names, for the
     * Disassembly panel's source view.
     *
     * Both optional and both about the same thing: a host that can reach the
     * files a build left behind can show the C each instruction came from,
     * and one that cannot shows the instructions alone. Read through the host
     * rather than here because it owns the file access and the caching, the
     * same way `symbolLoader` does.
     */
    lineTable?(): Promise<VesLineTable | undefined>;
    readSource?(path: string): Promise<string | undefined>;
    /**
     * Where the panels' own control settings are kept — see
     * `DebugSource.panelPreference`. Read once when the dock is
     * built and written back whole whenever one changes; a host that leaves
     * them out gets panels that remember nothing past this session.
     */
    readPanelPreferences?(): Record<string, string | number | boolean>;
    writePanelPreferences?(state: Record<string, string | number | boolean>): void;
    /**
     * Hand a file a panel made to the person — the Characters panel's PNG of
     * the character sheet.
     *
     * Not part of `DebugSource` either: that interface is about the machine,
     * and where a file somebody asked for should land is the host's business
     * — a download in the browser, a file in the project in VES. The panel
     * says what the file is called and the host is free to put its own stamp
     * on the name. A host that leaves this out gets a panel with no Export
     * button rather than one whose button fails.
     */
    exportFile?(name: string, data: Uint8Array): Promise<void>;
}

export class VueportDock extends DockPanel implements DebugSource {

    readonly screen: ScreenPanel;

    protected currentSim: Sim | undefined;
    /**
     * The other player's machine, while a link session is running.
     *
     * This window runs it alongside its own — see `emulator-core-service.ts` —
     * so pointing an inspector at it costs nothing and shows the same thing
     * the other player's own debugger would.
     */
    protected currentPeerSim: Sim | undefined;
    protected currentInspecting: InspectedSeat = 'own';
    /**
     * Where a panel's writes go, when something other than this owns that.
     *
     * Set by the host while a link session is running: a write then has to
     * reach both windows on one frame rather than this window now. Returning
     * false means it could not be arranged and the write should go straight
     * in. See `write`.
     */
    protected writeRoute:
        | ((seat: InspectedSeat, address: number, bytes: number[]) => boolean)
        | undefined;
    protected currentVbcSupportEnabled = true;
    protected currentVbcHardwareActive = false;
    protected currentRomHeader: RomHeader = EMPTY_ROM_HEADER;
    protected currentRomSize = 0;
    protected currentBuildMode?: string;
    protected currentRomChecksum?: string;
    protected panelPreferenceState: Record<string, string | number | boolean> | undefined;
    protected panelPreferenceWrite?: number;
    protected readonly panels = new Map<EmulatorPanelType, Panel>();
    protected readonly onDidChangeEmitter = new Emitter<void>();
    protected readonly onDidChangeLayoutEmitter = new Emitter<void>();
    protected readonly onDidRequestAddPanelEmitter = new Emitter<TabBar<Widget>>();
    protected readonly onDidRequestResetLayoutEmitter = new Emitter<void>();

    /** Fires when the arrangement changes, so it can be persisted. */
    readonly onDidChangeLayout = this.onDidChangeLayoutEmitter.event;

    /**
     * Fires when a tab group's "+" is pressed, with the group it was pressed
     * on — which is where whatever the user then picks should land.
     *
     * The dock raises this rather than asking for a panel itself, because
     * choosing one is a quick pick, and that belongs to the view contribution
     * that owns the Add Panel command.
     */
    readonly onDidRequestAddPanel = this.onDidRequestAddPanelEmitter.event;

    /**
     * A tab bar's reset button was pressed.
     *
     * The dock does not reset itself: the host decides whether to ask first,
     * and owns the persisted layout that has to be cleared alongside.
     */
    readonly onDidRequestResetLayout = this.onDidRequestResetLayoutEmitter.event;

    constructor(
        protected readonly instanceId: string,
        protected readonly host: VueportDockHost,
        // Neither of these is part of DebugSource: the rumble pack is
        // external hardware rather than something the simulation exposes, and
        // the ESSound player is the host's, not the machine's. Each is handed
        // to the one panel that needs it instead of to all of them.
        //
        // The cheats, the macros, the patches and the colorization used to
        // arrive here too, for the four panels that showed them. They no
        // longer dock in either mode — they are shown beside the screen and
        // opened from the title bar — so the dock has no business holding the
        // stores behind them.
        protected readonly rumblePack: VueportRumblePack,
        protected readonly esSound: EsSoundPlayer,
        // Unlike those, this one *is* part of DebugSource: the
        // symbols describe the ROM the simulation is running, so a panel may
        // ask for them the same way it asks for memory. It arrives as a
        // callback because reading them belongs to the widget, which owns both
        // the file access and the caching. See `getSymbols`.
        protected readonly symbolLoader: () => Promise<SymbolIndex | undefined>
    ) {
        // Refuses a tab dragged in from outside. Lumino checks this on the
        // panel being dropped into, so it is only half of the boundary — see
        // enforceDragBoundary for the other half, and why this alone is not
        // redundant with it.
        //
        // `addButtonEnabled` puts Lumino's own "+" on every tab bar this dock
        // creates, now and later. It renders as an empty div and leaves the
        // glyph to CSS, the same way the close icon does.
        super({
            mode: 'multiple-document',
            tabsConstrained: true,
            addButtonEnabled: true,
            // Lumino sizes a split handle's own DOM box to this, in an inline
            // style that a CSS `min-width` cannot shrink further — the 1px
            // line the CSS draws only ever showed through when this happened
            // to already be 1. The wider grab area is meant to come from
            // `--vp-sash-width` on the handle's `::after` regardless of the
            // handle's own box — see the `contain: none` override beside that
            // rule in emulator-widget.css for what actually makes that true.
            spacing: 1,
            // Tab bars of our own, for the scrollbar they carry.
            renderer: {
                createTabBar: () => {
                    const tabBar = new VueportTabBar();
                    tabBar.resetRequested.connect(() => this.onDidRequestResetLayoutEmitter.fire());
                    return tabBar;
                },
                createHandle: () => DockPanel.defaultRenderer.createHandle(),
            },
        });
        this.addClass('vp-dock');
        this.screen = new ScreenPanel(instanceId);
        this.layoutModified.connect(() => {
            // A rebuilt layout brings fresh tab bars, visible by default; in
            // Play mode they must go back down again.
            this.updatePlayModeTabBars();
            this.onDidChangeLayoutEmitter.fire();
        });
        this.addRequested.connect((unused, tabBar) => this.onDidRequestAddPanelEmitter.fire(tabBar));
    }

    /**
     * Double-clicking empty space in a tab row asks for a panel to put there,
     * the same as its "+" — a double-click on a strip of tabs reads as "give me
     * another one", and applications commonly treat it that way.
     *
     * Capture phase, so this runs on the way *down* to the tab bar: the tab bar
     * stops the event on the way back up to keep it away from the surrounding
     * application (see `VueportTabBar`), which would otherwise mean the
     * dock never saw it.
     */
    protected readonly addOnDoubleClickListener = (event: Event) => {
        const target = event.target as HTMLElement | null;
        if (!target) {
            return;
        }
        // Only the empty part of the row. A tab has its own meaning, and the
        // "+" already does this through Lumino's own signal.
        if (target.closest('.lm-TabBar-tab') || target.closest('.lm-TabBar-addButton')) {
            return;
        }
        const tabBar = [...this.tabBars()].find(bar => bar.node.contains(target));
        if (tabBar) {
            event.preventDefault();
            this.onDidRequestAddPanelEmitter.fire(tabBar);
        }
    };

    protected onAfterAttach(msg: Message): void {
        super.onAfterAttach(msg);
        this.node.addEventListener('dblclick', this.addOnDoubleClickListener, true);
        // Capture phase, and on the document rather than this.node, so these
        // see every pointer move and every Lumino drag event in the whole
        // application, not just ones over this dock.
        const document = this.node.ownerDocument;
        document.addEventListener('pointermove', this.pointerMoveListener, true);
        document.addEventListener('lm-dragenter', this.dragEnterListener, true);
        // Bubble phase, on this dock's own node, and registered *after*
        // `super.onAfterAttach` has bound Lumino's own handlers to that same
        // node — so those still run first and this only decides whether the
        // event may continue upwards. See `sealDragFromAncestors`.
        for (const type of VueportDock.DRAG_EVENTS) {
            this.node.addEventListener(type, this.sealDragListener);
        }
    }

    protected onBeforeDetach(msg: Message): void {
        const document = this.node.ownerDocument;
        document.removeEventListener('pointermove', this.pointerMoveListener, true);
        document.removeEventListener('lm-dragenter', this.dragEnterListener, true);
        this.node.removeEventListener('dblclick', this.addOnDoubleClickListener, true);
        for (const type of VueportDock.DRAG_EVENTS) {
            this.node.removeEventListener(type, this.sealDragListener);
        }
        super.onBeforeDetach(msg);
    }

    protected static readonly DRAG_EVENTS = ['lm-dragenter', 'lm-dragover', 'lm-dragleave', 'lm-drop'] as const;

    protected readonly pointerMoveListener = (event: Event) => this.trackOwnDrag(event as PointerEvent);
    protected readonly dragEnterListener = (event: Event) => this.blockForeignOverlay(event as Drag.Event);
    protected readonly sealDragListener = (event: Event) => this.sealDragFromAncestors(event as Drag.Event);

    /**
     * Keep this dock's own drag events from reaching the dock panels it is
     * nested inside — which is what left drop indicators stranded over the
     * shell's left, right and top edges.
     *
     * This dock is a `DockPanel` inside a Theia widget inside the shell's main
     * `DockPanel`, and Lumino binds `lm-drag*` on `this.node` in the *bubble*
     * phase. So every drag event in here travels up through the ancestor dock
     * panel on its way out, and two asymmetries in Lumino's own handlers turn
     * that into a stuck overlay:
     *
     * - `_evtDragOver` calls `_showOverlay(…)` as the second operand of an
     *   `||`, so the overlay is shown as a *side effect* of deciding the drop
     *   is invalid, and `stopPropagation()` only happens on the accepting
     *   branch. Any position this dock declines — over the screen panel, or a
     *   gap between panels — therefore bubbles on, and the ancestor obligingly
     *   shows its own drop indicator for a drag that can never land there.
     * - `_evtDragLeave` *does* call `stopPropagation()` for a drag whose
     *   source is this panel. So the leave that would have hidden that
     *   indicator is exactly the event the ancestor never receives.
     *
     * Hence the asymmetry is self-sustaining: the ancestor is told to show,
     * and never told to hide. `trackOwnDrag`'s `overlay.hide(0)` cannot help,
     * because that hides *this* dock's overlay, not an ancestor's.
     *
     * Only this dock's own drags are sealed. A foreign tab dragged across the
     * emulator on its way to the main area must still reach the panel that can
     * accept it — `tabsConstrained` already refuses the drop here, and Lumino's
     * own handlers deliberately leave that case propagating.
     */
    protected sealDragFromAncestors(event: Drag.Event): void {
        if (event.source === this) {
            event.stopPropagation();
        }
    }

    /** The `Drag` this dock's own tab bar started, for as long as one is in flight. */
    protected get ownDrag(): Drag | null {
        return (this as unknown as { _drag: Drag | null })._drag;
    }

    /**
     * Keep this dock's own drag from leaking into the rest of the
     * application, in every sense that turned out to matter. Three separate
     * problems, addressed together because each has a different, unrelated
     * cause:
     *
     * 1. **A foreign panel showing its own drop-target overlay.** Handled by
     *    `blockForeignOverlay`, on `lm-dragenter`.
     *
     * 2. **`ApplicationShell` revealing a collapsed sidebar or the bottom
     *    panel near a screen edge, mid-drag.** Its "drag near an edge for
     *    500ms" gate (`onDragOver`) measures from `dragState.startTime`,
     *    which is set the moment *any* `lm-dragenter` fires anywhere in the
     *    application — including ones entirely within this dock's own tab
     *    bars, during perfectly ordinary in-dock dragging. An real drag
     *    gesture easily takes longer than 500ms before ever nearing an edge,
     *    so by the time one is reached the gate is already open and the
     *    panel expands on the very first qualifying tick — no interception
     *    at the boundary, however early, can prevent that, because the clock
     *    started long before the boundary was ever approached. The only fix
     *    is to keep that clock from ever running while the drag is still
     *    ours: `trackOwnDrag`, on every `pointermove` for as long as this
     *    dock has a drag in flight, unconditionally clears `dragState`
     *    (private — there is no public way to opt a drag out of this) so it
     *    is never more than one tick old, wherever the cursor currently is.
     *
     * 3. **Ending the gesture once it truly leaves.** Also `trackOwnDrag`:
     *    once the raw cursor position falls outside this dock's own
     *    rectangle, it calls `Drag.dispose()` — Lumino's own sanctioned way
     *    to abort mid-gesture, the same thing pressing Escape does, and what
     *    `DockPanel`'s own `dispose()` calls on a drag it still has in
     *    flight. That tears down the pointer tracking driving every later
     *    dragenter/dragover/drop, so nothing gets another tick to react to
     *    this drag again. The tab itself was only ever hidden while dragged,
     *    never actually removed from its tab bar, so it simply reappears
     *    where it was — exactly what already happens when an ordinary drag
     *    is canceled over invalid space. `overlay.hide(0)` alongside it is
     *    cheap insurance for this dock's own drop-target indicator, in case
     *    the `dragleave` `dispose()` sends on its way out does not reach it.
     *
     * Position is read straight from the event rather than resolved through
     * Lumino's own `elementFromPoint`-based target tracking, deliberately:
     * two earlier designs built on `lm-dragenter`/`lm-dragover` each modeled
     * that machinery well enough to fix one symptom, then left another
     * boundary case (a still-stuck overlay, then this edge-expansion timing
     * issue) for the next region of the screen to surface. Raw cursor
     * position against this dock's own rectangle has no such subtlety.
     */
    protected trackOwnDrag(event: PointerEvent): void {
        const drag = this.ownDrag;
        // `isDisposed` matters as much as the null check. `DockPanel` clears
        // its `_drag` from the `then()` of `Drag.start()`, so between a drag
        // finishing and that callback running — and permanently, if that
        // callback is never registered — `_drag` still points at a dead drag.
        // Acting on one would clear `dragState` out from under a *foreign*
        // drag on every pointer move, and `ApplicationShell` guards both
        // `onDrop` and `onDragLeave` with `if (state)`, so its side panels
        // would then never collapse and its drag visuals never tear down.
        if (!drag || drag.isDisposed) {
            return;
        }

        this.host.cancelForeignDrag?.();

        const bounds = this.node.getBoundingClientRect();
        const inside = event.clientX >= bounds.left && event.clientX <= bounds.right
            && event.clientY >= bounds.top && event.clientY <= bounds.bottom;
        if (!inside) {
            // Deferred, never disposed inline, because this handler can be
            // running *inside* `Drag.start()`. Its last act is to dispatch a
            // synthetic `pointermove` on the document to kick the gesture off,
            // and it does that before returning its promise to `DockPanel`,
            // which has already assigned `_drag` and hidden the tab node. So a
            // tab detached at a point already outside this dock — dragging up
            // out of the dock, where the tab bars sit, is the easy way to do
            // that in one gesture — would otherwise be disposed re-entrantly.
            // `_finalize` nulls `_promise` before resolving it, so `start()`
            // would return null, `null.then(cleanup)` would throw inside the
            // signal handler, and the cleanup that clears `_drag` and unhides
            // the tab would never be registered: the tab stays invisible, and
            // `_onTabDetachRequested`'s `if (this._drag) return` then refuses
            // every future detach, killing drag and drop in this dock for good.
            // A microtask is enough — `then(cleanup)` is registered
            // synchronously, before this runs.
            queueMicrotask(() => {
                if (!drag.isDisposed) {
                    drag.dispose();
                }
                this.overlay.hide(0);
            });
        }
    }

    /**
     * Refuse one of this dock's own tabs onto a foreign panel's own overlay.
     *
     * The other direction — a foreign tab dragged in — is `tabsConstrained`
     * (set in the constructor), checked by Lumino's own `DockPanel` before
     * accepting a *drop*, which is enough on its own. Outgoing has no such
     * built-in support, since that check would have to run on whatever
     * foreign panel the drag has wandered onto, which knows nothing about
     * this dock — so this stops it here instead, in the capture phase, before
     * the event ever reaches that panel's own (bubble-phase) `_evtDragEnter`.
     * `stopPropagation()` alone, never `preventDefault()`: Lumino's own
     * `dispatchDragEnter` treats a *canceled* dragenter as *acceptance* —
     * `if (canceled) return currElem` — so calling `preventDefault()` to
     * reject, as an earlier version of this did, backfires by adopting the
     * foreign element as the drag's target instead of refusing it.
     */
    protected blockForeignOverlay(event: Drag.Event): void {
        if (event.source === this
            && event.mimeData.hasData('application/vnd.lumino.widget-factory')
            && !this.node.contains(event.target as Node)) {
            event.stopPropagation();
        }
    }

    /**
     * The machine the panels are reading.
     *
     * Falls back to this window's own whenever the other player's is not
     * there — a session that has just ended leaves panels pointed at a
     * machine that no longer exists otherwise, and every one of them would
     * show an empty readout rather than the game that is still running.
     */
    get sim(): Sim | undefined {
        if (this.currentInspecting === 'peer' && this.currentPeerSim) {
            return this.currentPeerSim;
        }
        return this.currentSim;
    }

    get inspecting(): InspectedSeat {
        return this.currentPeerSim ? this.currentInspecting : 'own';
    }

    get hasPeerSim(): boolean {
        return this.currentPeerSim !== undefined;
    }

    async write(address: number, bytes: number[]): Promise<void> {
        if (bytes.length === 0) {
            return;
        }
        const seat = this.inspecting;
        if (this.writeRoute?.(seat, address, bytes)) {
            return;
        }
        // Nothing took it, and it was aimed at the other player's machine. A
        // mirror is only worth anything while it is a copy of what the other
        // window is running, so writing into this one alone would not be a
        // half-measure — it would break the thing the panel is showing. The
        // only moment this happens is a session ending between the click and
        // this call, and dropping the write is the honest outcome.
        if (seat === 'peer') {
            return;
        }
        await this.sim?.writeMemory(address, new Uint8Array(bytes).buffer);
    }

    get vbcSupportEnabled(): boolean {
        return this.currentVbcSupportEnabled;
    }

    get vbcHardwareActive(): boolean {
        return this.currentVbcSupportEnabled && this.currentVbcHardwareActive;
    }

    get romHeader(): RomHeader {
        return this.currentRomHeader;
    }

    get romSize(): number {
        return this.currentRomSize;
    }

    get romChecksum(): string | undefined {
        return this.currentRomChecksum;
    }

    get buildMode(): string | undefined {
        return this.currentBuildMode;
    }

    panelPreference<T extends string | number | boolean>(
        kind: EmulatorPanelType, key: string, fallback: T
    ): T {
        const stored = this.panelPreferences()[`${kind}.${key}`];
        // Same type as the fallback or nothing: storage outlives a build, and
        // a panel that turned a checkbox into a slider must not be handed the
        // old `true`.
        return typeof stored === typeof fallback ? stored as T : fallback;
    }

    setPanelPreference(
        kind: EmulatorPanelType, key: string, value: string | number | boolean
    ): void {
        const state = this.panelPreferences();
        const id = `${kind}.${key}`;
        if (state[id] === value) {
            return;
        }
        state[id] = value;
        // Dragging a slider lands a value per step, and each write is a
        // serialize-and-store in the host. Coalesced to the end of the drag:
        // nothing reads these back until the emulator is opened again, so the
        // only cost of waiting is the one thing that makes them cheap.
        if (this.panelPreferenceWrite === undefined) {
            this.panelPreferenceWrite = window.setTimeout(() => {
                this.panelPreferenceWrite = undefined;
                this.host.writePanelPreferences?.({ ...state });
            }, PANEL_PREFERENCE_WRITE_DELAY_MS);
        }
    }

    /** The panels' settings, read from the host the first time one is asked for. */
    protected panelPreferences(): Record<string, string | number | boolean> {
        return this.panelPreferenceState ??= { ...this.host.readPanelPreferences?.() };
    }

    /** Write a pending change out now, rather than at the end of its delay. */
    protected flushPanelPreferences(): void {
        if (this.panelPreferenceWrite === undefined) {
            return;
        }
        window.clearTimeout(this.panelPreferenceWrite);
        this.panelPreferenceWrite = undefined;
        this.host.writePanelPreferences?.({ ...this.panelPreferences() });
    }

    onDidChange(listener: () => void): Disposable {
        return this.onDidChangeEmitter.event(listener);
    }

    getSymbols(): Promise<SymbolIndex | undefined> {
        return this.symbolLoader();
    }

    getLineTable(): Promise<VesLineTable | undefined> {
        return this.host.lineTable?.() ?? Promise.resolve(undefined);
    }

    /**
     * Where the machine should stop.
     *
     * On the dock rather than in the panel that draws the gutter, because it
     * is not only that panel's: a host with editors sets breakpoints on
     * source lines and reaches this the same way. See `VesBreakpoints`.
     */
    readonly breakpoints = new VesBreakpoints();
    protected readonly armOnChange =
        this.breakpoints.onDidChange(() => this.armBreakpoints());

    readSource(path: string): Promise<string | undefined> {
        return this.host.readSource?.(path) ?? Promise.resolve(undefined);
    }

    setHighlights(rects: VesScreenRect[]): void {
        this.screen.setHighlights(rects);
    }

    setSim(sim: Sim | undefined): void {
        this.currentSim = sim;
        this.armBreakpoints();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Hand the machine the set as it stands.
     *
     * From here rather than from the panel, and regardless of whether that
     * panel is open: a breakpoint set on a line in an editor has to work
     * while nobody is looking at a disassembly, and that is the whole point
     * of the set living outside it. Nothing is armed when nothing is set, so
     * a session that uses no breakpoints still pays nothing for them.
     */
    protected armBreakpoints(): void {
        this.currentSim?.setBreakpoints(this.breakpoints.armed())
            .catch(() => { /* the machine may already be gone */ });
    }

    /**
     * Offer, or stop offering, the other player's machine to the inspectors.
     *
     * Taking it away points them back at this window's own rather than
     * leaving them on nothing, which is what ending a session should look
     * like: the debugger goes back to the game still in front of the player.
     */
    setPeerSim(sim: Sim | undefined): void {
        if (this.currentPeerSim === sim) {
            return;
        }
        this.currentPeerSim = sim;
        if (!sim) {
            this.currentInspecting = 'own';
        }
        this.onDidChangeEmitter.fire();
    }

    /** Point every inspector at one machine or the other. */
    setInspecting(seat: InspectedSeat): void {
        if (this.currentInspecting === seat) {
            return;
        }
        this.currentInspecting = seat;
        this.onDidChangeEmitter.fire();
    }

    /** Hand a link session the panels' writes. See {@link writeRoute}. */
    setWriteRoute(
        route: ((seat: InspectedSeat, address: number, bytes: number[]) => boolean)
            | undefined,
    ): void {
        this.writeRoute = route;
    }

    /**
     * Keep VB Color-only debugger surfaces in step with the machine.
     *
     * Two facts, set together because they change together: the global gate,
     * and whether what is running is a VB Color at all. The second is what the
     * color-only surfaces key off — see `vbcHardwareActive` on
     * {@link DebugSource}.
     *
     * The VCU panel is not one of them any more. It used to be closed outright
     * whenever the machine was not a VB Color, on the grounds that a tab for
     * absent hardware invites the question of what is wrong with it — but that
     * also meant the panel could not be opened at all except in color mode,
     * and a tab that disappears when the hardware mode changes is the more
     * confusing of the two. It stays open and says which machine is running.
     */
    setVbcSupportEnabled(enabled: boolean, hardwareActive = this.currentVbcHardwareActive): void {
        if (this.currentVbcSupportEnabled === enabled
            && this.currentVbcHardwareActive === hardwareActive) {
            return;
        }
        this.currentVbcHardwareActive = hardwareActive;
        this.currentVbcSupportEnabled = enabled;
        this.onDidChangeEmitter.fire();
    }

    /** Called whenever a ROM is (re)loaded, independently of the sim changing. */
    setRomInfo(
        romHeader: RomHeader,
        romSize: number,
        buildMode?: string,
        romChecksum?: string,
    ): void {
        this.currentRomHeader = romHeader;
        this.currentRomSize = romSize;
        this.currentBuildMode = buildMode;
        this.currentRomChecksum = romChecksum;
        this.onDidChangeEmitter.fire();
    }

    /** Open a debug panel, or focus it if it is already there. */
    togglePanel(kind: EmulatorPanelType): void {
        const existing = this.panels.get(kind);
        if (existing && !existing.isDisposed) {
            if (existing.isAttached) {
                this.focusWidget(existing);
                return;
            }
            existing.dispose();
        }

        const panel = this.createPanel(kind);
        this.panels.set(kind, panel);
        // Beside the screen rather than on top of it, so opening an inspector
        // never hides what it is inspecting.
        this.addWidget(panel, { mode: 'split-right', ref: this.screen });
        this.focusWidget(panel);
    }

    /**
     * Open a panel in one particular tab group — what a group's "+" does.
     *
     * A panel that is already open elsewhere is moved rather than duplicated:
     * Lumino's `addWidget` relocates a widget the layout already contains, so
     * the same call covers both cases.
     */
    addPanelTo(kind: EmulatorPanelType, tabBar: TabBar<Widget>): void {
        const panel = this.widgetFor(kind);
        if (!panel) {
            return;
        }
        // Already in this group: there is nothing to move, and asking Lumino
        // to insert a widget next to itself is an error.
        if (this.tabBarFor(panel) !== tabBar) {
            const ref = tabBar.currentTitle?.owner;
            this.addWidget(panel, ref ? { mode: 'tab-after', ref } : { mode: 'split-right', ref: this.screen });
        }
        this.focusWidget(panel);
    }

    /** The tab group a widget is currently in, if it is in one. */
    protected tabBarFor(widget: Widget): TabBar<Widget> | undefined {
        for (const tabBar of this.tabBars()) {
            if (tabBar.titles.includes(widget.title)) {
                return tabBar;
            }
        }
        return undefined;
    }

    isPanelOpen(kind: EmulatorPanelType): boolean {
        const panel = this.panels.get(kind);
        return !!panel && !panel.isDisposed && panel.isAttached;
    }

    /** Open *and* on top of its tab group, rather than behind another tab. */
    isPanelVisible(kind: EmulatorPanelType): boolean {
        const panel = this.panels.get(kind);
        return !!panel && !panel.isDisposed && panel.isVisible;
    }

    protected createPanel(kind: EmulatorPanelType): Panel {
        switch (kind) {
            case EmulatorPanelType.REGISTERS: return new RegistersPanel(this, this.instanceId);
            case EmulatorPanelType.MEMORY: return new MemoryPanel(this, this.instanceId);
            case EmulatorPanelType.MEMORY_POOLS: return new MemoryPoolsPanel(this, this.instanceId);
            case EmulatorPanelType.PROFILER: return new ProfilerPanel(
                this, this.instanceId,
                this.host.isProfiling && this.host.toggleProfiling
                    ? {
                        isProfiling: () => this.host.isProfiling?.() ?? false,
                        toggleProfiling: () => this.host.toggleProfiling?.(),
                    }
                    : undefined);
            case EmulatorPanelType.ACTORS: return new ActorsPanel(this, this.instanceId);
            case EmulatorPanelType.DISASSEMBLY: return new DisassemblyPanel(
                this, this.instanceId,
                this.host.isPaused && this.host.setPaused
                    ? {
                        isPaused: () => this.host.isPaused?.() ?? false,
                        setPaused: (paused: boolean) => this.host.setPaused?.(paused),
                    }
                    : undefined);
            case EmulatorPanelType.VIP_PALETTES: return new PalettesPanel(this, this.instanceId);
            case EmulatorPanelType.VIP_CHARACTERS: return new CharactersPanel(
                this, this.instanceId,
                this.host.exportFile
                    ? (name, data) => this.host.exportFile?.(name, data) ?? Promise.resolve()
                    : undefined);
            case EmulatorPanelType.VIP_BGMAPS: return new BgMapsPanel(this, this.instanceId);
            case EmulatorPanelType.VIP_WORLDS: return new WorldsPanel(this, this.instanceId);
            case EmulatorPanelType.VIP_OBJECTS: return new ObjectsPanel(this, this.instanceId);
            case EmulatorPanelType.VIP_FRAME_BUFFERS: return new FrameBuffersPanel(this, this.instanceId);
            case EmulatorPanelType.VCU: return new VcuPanel(this, this.instanceId);
            case EmulatorPanelType.VSU: return new VsuPanel(this, this.instanceId);
            case EmulatorPanelType.TERMINAL: return new TerminalPanel(this, this.instanceId);
            case EmulatorPanelType.ROM_INFO: return new RomInfoPanel(this, this.instanceId);
            case EmulatorPanelType.SRAM: return new SramPanel(this, this.instanceId);
            case EmulatorPanelType.RUMBLE_PACK: return new RumblePackPanel(this, this.instanceId, this.rumblePack);
            case EmulatorPanelType.ES_SOUND: return new EsSoundPanel(this, this.instanceId, this.esSound);
            default: throw new Error(`Unknown emulator panel: ${kind}`);
        }
    }

    protected clearPanels(): void {
        for (const panel of this.panels.values()) {
            if (!panel.isDisposed) {
                panel.dispose();
            }
        }
        this.panels.clear();
    }

    /** Put the panels back to the built-in default arrangement (DEFAULT_LAYOUT). */
    resetLayout(): void {
        this.clearPanels();

        const main = this.deserializeArea(this.host.defaultLayout ?? DEFAULT_LAYOUT);
        if (main) {
            try {
                this.restoreLayout({ main });
            } catch {
                // A bug in the built-in default is still better recovered
                // from than left half-applied.
                this.clearPanels();
            }
        }

        // Not an "else": this is both the happy-path outcome, since
        // DEFAULT_LAYOUT includes the screen, and the fallback if building or
        // applying it failed above and left nothing docked at all.
        if (!this.screen.isAttached) {
            this.addWidget(this.screen);
        }
        this.onDidChangeLayoutEmitter.fire();
    }

    /**
     * Play mode: show only the screen, hiding whatever debug panels are open
     * without closing them. `restoreLayout` only unparents widgets that drop
     * out of the new config rather than disposing them, so this is fully
     * reversible — `applySerializedLayout`/`resetLayout` bring back exactly
     * what was open before, `widgetFor` finding the same still-live instances.
     *
     * The cheats, macros, patches, colors and achievements are not among the
     * panels this hides, because they are not panels: in both modes they are
     * shown beside the screen without the dock being involved at all — see
     * `EmulatorHost#renderCheats` — because somebody reaching for one should
     * not have to think about panels, tabs or layouts.
     */
    showScreenOnly(): void {
        const main = this.deserializeArea({ type: 'tab-area', panels: [EmulatorPanelType.SCREEN], currentIndex: 0 });
        if (main) {
            this.restoreLayout({ main });
        }
    }

    /**
     * The screen's own tab bar is pointless chrome when it is the only thing
     * docked (Play mode always leaves it that way, via showScreenOnly), so
     * hide it entirely rather than render a single-tab bar above the screen.
     */
    setPlayMode(active: boolean): void {
        this.toggleClass('vp-dock-play-mode', active);
        this.updatePlayModeTabBars();
    }

    /**
     * Keep Lumino's layout in step with the CSS that hides the tab bar in Play
     * mode.
     *
     * `.vp-dock-play-mode .lm-TabBar { display: none }` takes the bar off
     * the screen, but `DockLayout` still reserves its height — it only
     * collapses a tab bar whose widget it knows is hidden, and a CSS rule is
     * not that. Hiding the bar at the widget level too is what closes the empty
     * band above the picture.
     */
    protected updatePlayModeTabBars(): void {
        // `setHidden` re-fits the layout, which can re-enter through
        // `layoutModified`; the flag keeps that to a single pass.
        if (this.applyingPlayModeTabBars) {
            return;
        }
        this.applyingPlayModeTabBars = true;
        try {
            const play = this.hasClass('vp-dock-play-mode');
            for (const tabBar of this.tabBars()) {
                tabBar.setHidden(play);
            }
        } finally {
            this.applyingPlayModeTabBars = false;
        }
    }

    private applyingPlayModeTabBars = false;

    /**
     * Record the arrangement, including splits and their sizes.
     *
     * Lumino's own layout config holds widget instances, which cannot be
     * stored, so the tree is copied with each widget replaced by the kind of
     * panel it is. Restoring rebuilds the same tree with fresh instances.
     */
    serializeLayout(): VueportDockLayout {
        return { main: this.serializeArea(this.saveLayout().main) };
    }

    applySerializedLayout(layout: VueportDockLayout | undefined): void {
        const main = layout?.main ? this.deserializeArea(layout.main) : undefined;
        if (!main) {
            this.resetLayout();
            return;
        }

        try {
            this.restoreLayout({ main });
        } catch {
            // A stored layout can go stale, and a half-applied dock tree is
            // worse than the default one.
            this.resetLayout();
            return;
        }

        // The screen is not closable, so a layout that somehow lost it would
        // leave the emulator with nowhere to draw.
        if (!this.screen.isAttached) {
            this.addWidget(this.screen);
        }
    }

    protected serializeArea(area: DockLayout.AreaConfig | null): AreaLayout | undefined {
        if (!area) {
            return undefined;
        }
        if (area.type === 'tab-area') {
            const panels = area.widgets
                .map(widget => this.kindOf(widget))
                .filter((kind): kind is EmulatorPanelType => kind !== undefined);
            return panels.length === 0
                ? undefined
                : { type: 'tab-area', panels, currentIndex: Math.max(0, Math.min(area.currentIndex, panels.length - 1)) };
        }

        const children = area.children
            .map(child => this.serializeArea(child))
            .filter((child): child is AreaLayout => child !== undefined);
        if (children.length === 0) {
            return undefined;
        }
        return {
            type: 'split-area',
            orientation: area.orientation,
            children,
            sizes: area.sizes.slice(0, children.length),
        };
    }

    protected deserializeArea(area: AreaLayout): DockLayout.AreaConfig | undefined {
        if (area.type === 'tab-area') {
            const widgets = area.panels
                .map(kind => this.widgetFor(kind))
                .filter((widget): widget is Widget => widget !== undefined);
            return widgets.length === 0
                ? undefined
                : { type: 'tab-area', widgets, currentIndex: Math.max(0, Math.min(area.currentIndex, widgets.length - 1)) };
        }

        const children = area.children
            .map(child => this.deserializeArea(child))
            .filter((child): child is DockLayout.AreaConfig => child !== undefined);
        return children.length === 0
            ? undefined
            : { type: 'split-area', orientation: area.orientation, children, sizes: area.sizes.slice(0, children.length) };
    }

    protected kindOf(widget: Widget): EmulatorPanelType | undefined {
        if (widget === this.screen) {
            return EmulatorPanelType.SCREEN;
        }
        return widget instanceof Panel ? widget.kind : undefined;
    }

    /** The instance for a kind, creating a debug panel if it is not open yet. */
    protected widgetFor(kind: EmulatorPanelType): Widget | undefined {
        if (kind === EmulatorPanelType.SCREEN) {
            return this.screen;
        }
        if (!EMULATOR_DEBUG_PANELS.includes(kind)) {
            return undefined;
        }
        const existing = this.panels.get(kind);
        if (existing && !existing.isDisposed) {
            return existing;
        }
        const panel = this.createPanel(kind);
        this.panels.set(kind, panel);
        return panel;
    }

    protected focusWidget(widget: Widget): void {
        this.selectWidget(widget);
        widget.activate();
        this.revealTab(widget);
    }

    /**
     * Scroll a widget's tab into view.
     *
     * Tab rows scroll once there are more tabs than fit, so the tab of a panel
     * just opened or focused can be off the end of one — which would look like
     * nothing happened.
     */
    protected revealTab(widget: Widget): void {
        const tabBar = this.tabBarFor(widget);
        const index = tabBar?.titles.indexOf(widget.title) ?? -1;
        if (!tabBar || index < 0) {
            return;
        }
        tabBar.contentNode.children[index]?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    }

    dispose(): void {
        this.flushPanelPreferences();
        this.breakpoints.dispose();
        this.onDidChangeEmitter.dispose();
        this.onDidChangeLayoutEmitter.dispose();
        this.onDidRequestAddPanelEmitter.dispose();
        this.onDidRequestResetLayoutEmitter.dispose();
        super.dispose();
    }
}

export type AreaLayout =
    | { type: 'tab-area', panels: EmulatorPanelType[], currentIndex: number }
    | {
        type: 'split-area',
        orientation: 'horizontal' | 'vertical',
        children: AreaLayout[],
        sizes: number[]
    };

export interface VueportDockLayout {
    main?: AreaLayout;
}
