import { Funnel, IconProps, Info, Plug, Terminal, Warning, WarningOctagon } from '@phosphor-icons/react';
import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { formatLogTime, LOG_LEVELS, LogLevel, splitLogLevel } from '../../common/emulator-log';
import { nls } from '../../common/emulator-nls';
import EmptyContainer from '../components/kit/EmptyContainer';
import PanelFilter from '../components/kit/PanelFilter';
import { Sim } from '../core/vb-core';
import { DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';

/** Lines kept before the oldest are dropped. */
const MAX_LINES = 2000;

/**
 * How far off the bottom still counts as being at it.
 *
 * A few pixels rather than none: a browser's `scrollTop` is fractional at
 * anything but a whole device-pixel ratio, so a view scrolled all the way
 * down often reports itself a fraction short of it.
 */
const FOLLOW_SLACK = 4;

/**
 * How many of the panel's own scrolls may be waiting for their events.
 *
 * A bound rather than a size: each one is given back by the event it caused,
 * so the list is empty most of the time. The cap is there so that a scroll
 * whose event never came — one the browser folded into another, say — cannot
 * sit in the list indefinitely.
 */
const OWN_SCROLLS = 8;

/** One finished line of output, and what it announced itself as. */
interface TerminalLine {
    /** What the line says, with any `Warning:` prefix parted from it. */
    text: string;
    /**
     * When the line was finished, rather than when its first character
     * arrived: a line the program built up a character at a time — which is
     * how `Terminal::print` sends one — has no single moment before that.
     */
    at: number;
    level: LogLevel;
}

/** The icon each level wears on its switch. */
const LEVEL_ICONS: Record<LogLevel, React.ComponentType<IconProps>> = {
    info: Info,
    warning: Warning,
    error: WarningOctagon,
};

/**
 * Calls back once what React just drew is actually in the document.
 *
 * `createRoot().render()` does not draw there and then — it schedules — so a
 * panel that scrolls to the end of its content straight after asking for a
 * render scrolls to the end of the *previous* content, and lands a few lines
 * short of the output that render was about. A layout effect runs after the
 * commit and before the frame is painted, which is the moment that scroll has
 * to happen for nobody to see it happen.
 */
function AfterRender({ run }: { run(): void }): null {
    // No dependency list: every commit is one the panel may have to follow.
    React.useLayoutEffect(() => run());
    return null;
}

/**
 * Output the running program wrote to the terminal port.
 *
 * VUEngine's `Terminal::print` stores a string to a fixed address one byte at a
 * time and follows it with a newline. Capturing that means the core calls back
 * on every CPU write, so capture is switched on only while this panel is open
 * and torn down again when it closes — which is also why this is the one panel
 * that is pushed to rather than polled.
 *
 * Nothing appears for a shipping build: `Terminal::print` is compiled out
 * unless the ROM was built with debugging enabled.
 *
 * What a build does print is usually a lot of it, so the panel is as much a
 * way of not reading output as of reading it: the search narrows it by what a
 * line says, the level switches by what it announced itself as, and the two
 * compose — the search counts against what the switches left.
 */
export class TerminalPanel extends Panel {

    protected lines: TerminalLine[] = [];
    /** Text since the last newline, which is not a line yet. */
    protected partial = '';
    /**
     * When the partial line's first character arrived.
     *
     * A finished line is stamped when it finished, which an unfinished one by
     * definition cannot be. Taking the start instead is a sub-millisecond
     * difference in practice — `Terminal::print` writes a whole string in one
     * burst — and it keeps the time column filled rather than ragged.
     */
    protected partialAt = 0;

    protected follow = this.remembered('follow', true);
    /**
     * Set when output arrived that the view has not been scrolled down to yet.
     *
     * Following used to be done on every render, which is why it could not be
     * scrolled away from: this panel re-renders once a second whether or not
     * anything was written, so a reader who scrolled up was pulled back down
     * within the second. Now a render only follows output that is actually
     * new, and {@link onScroll} hands the choice back to whoever is scrolling.
     */
    protected pendingScroll = false;
    /**
     * Positions the panel put the view at that have not come back as scroll
     * events yet.
     *
     * A scroll event says where the view is, not who moved it, and it is
     * dispatched after the fact — so the panel's own scroll to the end can
     * arrive once output has moved the end further down, and read as somebody
     * having scrolled up. What the panel scrolled to, it knows exactly; an
     * event reporting one of those positions is its own and says nothing.
     * Several assignments in one frame come back as a single event with the
     * last of them, which is why a match drops everything up to it.
     */
    protected readonly ownScrolls: number[] = [];
    /**
     * Where the end of the output was before whatever has arrived since the
     * last scroll event was drawn.
     *
     * Reaching the end is how following is asked for again, and the end has
     * to mean where it was when the reader aimed at it: by the time the event
     * arrives, another burst may have pushed it down a screenful. Undefined
     * while nothing has arrived since.
     */
    protected endBefore?: number;

    /** What is being searched for. Not remembered: a search is about now. */
    protected search = '';
    /** Whether the search hides the rest rather than only dimming it. */
    protected onlyMatches = this.remembered('onlyMatches', false);
    /** Which levels are shown, each remembered on its own. */
    protected levels: Record<LogLevel, boolean> = {
        info: this.remembered('level.info', true),
        warning: this.remembered('level.warning', true),
        error: this.remembered('level.error', true),
    };

    /**
     * The machine whose output is on screen.
     *
     * Held so that a different one can be told from the same one carrying on:
     * what was captured belonged to the machine that has gone, and none of it
     * describes the one that replaced it. A reset and a different cartridge
     * keep the same simulation and are caught by `onRestart` instead.
     */
    protected watched?: Sim;
    /** What was set up to watch {@link watched}, given back with it. */
    protected readonly watching = new DisposableCollection();
    protected capturing = false;

    protected scroller: HTMLDivElement | undefined;
    /**
     * Held rather than written inline in the render, because React takes a
     * ref back and hands it out again whenever the function it was given
     * changes — which for one written inline is every render, and the panel
     * would be without its view at exactly the moment it wants to scroll it.
     */
    protected readonly takeScroller = (element: HTMLDivElement | null): void => {
        this.scroller = element ?? undefined;
    };

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.TERMINAL, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/terminal/title', 'Terminal');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.TERMINAL);

        this.toDispose.push(this.watching);
        this.toDisposeOnDetach.push(this.source.onDidChange(() => this.followMachine()));
    }

    protected onAfterAttach(msg: Message): void {
        // Set before the base renders: whatever is already here was written
        // before the view existed, so the first render is the one render
        // that always follows.
        this.pendingScroll = true;
        super.onAfterAttach(msg);
        this.followMachine();
    }

    /**
     * Capture costs the core a callback on every CPU write, so it is given
     * back the moment this panel is closed.
     *
     * The lines stay, and so does the machine they belong to: a panel dragged
     * from one side of the dock to the other is detached and attached again,
     * and that is not a reason to lose what it was showing.
     */
    protected onBeforeDetach(msg: Message): void {
        this.watching.dispose();
        this.capturing = false;
        super.onBeforeDetach(msg);
    }

    /**
     * Nothing to poll: output arrives as an event. The base class still drives
     * a timer, so it is slowed right down rather than left running at ten hertz.
     */
    protected pollHz(): number {
        return 1;
    }

    protected refresh(): void {
        // Output is pushed, so a poll only has to notice a simulation appearing
        // or going away.
        this.followMachine();
        // Rendered here too, even though nothing is polled for: ReactWidget
        // draws only from onUpdateRequest, so without this the panel — toolbar
        // and empty state alike — stayed blank until the first output arrived
        // and appended itself. It is also what swaps the empty state over when
        // a simulation appears or goes away.
        this.update();
    }

    /**
     * Point the capture at whatever machine there is now, and empty the panel
     * for a machine that is not the one the output came from.
     *
     * Both halves used to be missing. Capture was set up once and never
     * moved, so a second ROM opened with the panel already there went on
     * being listened to through the simulation the first one had — which by
     * then was writing nothing — and the first game's output stayed on
     * screen underneath as though it were the new game's.
     */
    protected followMachine(): void {
        const sim = this.source.sim;
        if (sim !== this.watched) {
            this.watching.dispose();
            this.capturing = false;
            this.watched = sim;
            this.clear();
        }
        if (!sim || this.capturing) {
            return;
        }
        this.capturing = true;

        sim.setTerminalCapture(true).catch(error => this.append(
            `\n${nls.localize(
                'vueport/debug/panels/terminal/failed',
                'Error: terminal capture could not be enabled: {0}',
                error instanceof Error ? error.message : String(error)
            )}\n`
        ));

        this.watching.push(sim.onTerminal(text => this.append(text)));
        // A reset, or another cartridge put into the same simulation. What is
        // on screen is a record of a run that is over — the line numbers, the
        // counts, the times are all about a machine that has started again —
        // so it goes, exactly as it does when the simulation itself is
        // replaced.
        this.watching.push(sim.onRestart(() => this.clear()));
        this.watching.push({ dispose: () => this.stopCapture(sim) });
    }

    protected stopCapture(sim: Sim): void {
        // The simulation is often already gone by the time a panel closes, in
        // which case there is nothing left to turn off.
        sim.setTerminalCapture(false).catch(() => { /* nothing to release */ });
    }

    protected append(text: string): void {
        if (this.partial === '') {
            this.partialAt = Date.now();
        }
        const combined = this.partial + text;
        const parts = combined.split('\n');
        this.partial = parts.pop() ?? '';
        const at = Date.now();
        // The split is what trims, and it trims what is left after the
        // prefix rather than the line as it arrived — see `splitLogLevel`.
        this.lines.push(...parts.map(line => ({ ...splitLogLevel(line), at })));

        // Read before the render draws it: this is where the end of the
        // output was, and is what somebody scrolling now is aiming at.
        if (this.endBefore === undefined && this.scroller) {
            this.endBefore = Math.max(
                0, this.scroller.scrollHeight - this.scroller.clientHeight,
            );
        }

        if (this.lines.length > MAX_LINES) {
            this.lines.splice(0, this.lines.length - MAX_LINES);
        }
        this.pendingScroll = true;
        this.update();
    }

    protected clear(): void {
        this.lines = [];
        this.partial = '';
        this.update();
    }

    /** Redraw, and put the view at the end of the output while doing it. */
    protected updateAndFollow(): void {
        this.pendingScroll = true;
        this.update();
    }

    /** Take the view to the end of the output, if that is what was asked for. */
    protected afterRender(): void {
        const view = this.scroller;
        if (!this.pendingScroll || !view) {
            return;
        }
        this.pendingScroll = false;
        if (!this.follow) {
            return;
        }
        const before = view.scrollTop;
        view.scrollTop = view.scrollHeight;
        // Only a scroll that moved the view will come back as an event, and
        // only those may be waited for — see {@link ownScrolls}.
        if (view.scrollTop !== before) {
            this.ownScrolls.push(view.scrollTop);
            this.ownScrolls.splice(0, this.ownScrolls.length - OWN_SCROLLS);
        }
    }

    /**
     * Scrolling is what turns following on and off.
     *
     * The button in the toolbar says whether the view is at the end of the
     * output, and scrolling away from the end is the plainest way of saying
     * you would rather it were not — a reader who has scrolled up to read
     * something should not have to find a control before the next line of
     * output takes it away again. Reaching the end says the opposite.
     *
     * The two directions are not asked the same question, and deliberately:
     *
     * - While following, the end means the end as it is now. Anything else is
     *   somebody having moved the view away, and following stops. Content
     *   *shrinking* — a Clear, a level switched off — takes the view with it
     *   and lands it at the end, which is the one case that reads as "still
     *   there" and is right to.
     * - While not following, the end means where the end was when the scroll
     *   was made, which is what {@link endBefore} keeps. Asking for the end
     *   as it is now would make it unreachable by hand: every burst of output
     *   moves it further down than the event that reports the scroll.
     */
    protected onScroll(): void {
        const view = this.scroller;
        if (!view) {
            return;
        }
        const top = view.scrollTop;

        const own = this.ownScrolls.indexOf(top);
        if (own >= 0) {
            this.ownScrolls.splice(0, own + 1);
            this.endBefore = undefined;
            return;
        }

        const end = Math.min(
            this.endBefore ?? Number.POSITIVE_INFINITY,
            view.scrollHeight - view.clientHeight,
        );
        this.endBefore = undefined;
        this.ownScrolls.length = 0;

        const follow = this.follow
            ? view.scrollHeight - top - view.clientHeight <= FOLLOW_SLACK
            : top >= end - FOLLOW_SLACK;
        if (follow !== this.follow) {
            this.follow = this.remember('follow', follow);
            this.update();
        }
    }

    /**
     * Whether anything has been captured at all.
     *
     * Asked of the trimmed partial rather than the raw one, so that the
     * padding around a line that has not finished arriving does not count as
     * output — otherwise the panel would drop its "waiting for output" the
     * moment a program wrote a space.
     */
    protected hasOutput(): boolean {
        return this.lines.length > 0 || this.partial.trim() !== '';
    }

    /** Whether a line answers the search, which an empty search does not ask. */
    protected matches(text: string): boolean {
        return this.search !== ''
            && text.toLowerCase().includes(this.search.toLowerCase());
    }

    protected render(): React.ReactNode {
        // What the level switches left, which is what the search counts
        // against: the two narrow in that order, so "3 of 418" is three of
        // the four hundred and eighteen lines on screen and not of every
        // line ever captured.
        const shown = this.lines.filter(line => this.levels[line.level]);
        // Split like the finished lines, and so trimmed like them. The raw
        // text is what goes on being built up; this is only how it reads.
        const partial = splitLogLevel(this.partial);
        const partialShown = partial.text !== '' && this.levels[partial.level];
        const searching = this.search !== '';
        const hiding = searching && this.onlyMatches;

        const partialMatched = partialShown && this.matches(partial.text);
        const matched = (searching ? shown.filter(line => this.matches(line.text)).length : 0)
            + (partialMatched ? 1 : 0);

        const rows = hiding ? shown.filter(line => this.matches(line.text)) : shown;
        const partialRow = partialShown && (!hiding || partialMatched);

        const counts = {} as Record<LogLevel, number>;
        for (const level of LOG_LEVELS) {
            counts[level] = 0;
        }
        for (const line of this.lines) {
            counts[line.level]++;
        }
        // Whether the badges get a column of their own. A build that only
        // ever prints plain messages has one kind of line, and a column
        // saying "Info" beside every one of them is a column of noise; the
        // moment something announces itself as more than that, saying which
        // is which is the whole point.
        const kinds = LOG_LEVELS.filter(
            level => counts[level] > 0 || partial.level === level,
        );
        // Looked up once for the whole render rather than once per line:
        // there can be two thousand of them, thirty times a second.
        const badges = kinds.length > 1 ? this.levelLabels() : undefined;

        return (
            <div className="vp-terminal">
                {/* Nothing captured yet, so nothing to search, filter or
                    clear: every control would be about output that is not
                    there, and what the panel has to say at that point — that
                    the machine is off, or that this build prints nothing — is
                    better said with the panel to itself.

                    The unfinished line counts as a line on screen: it is one,
                    and a program that never sends a newline would otherwise
                    have its whole output counted as nothing. */}
                {this.hasOutput() && this.renderToolbar(
                    shown.length + (partialShown ? 1 : 0), matched, searching, counts,
                )}
                <div
                    className={`vp-terminal-lines vp-scroll${badges ? ' badged' : ''}`}
                    onScroll={() => this.onScroll()}
                    ref={this.takeScroller}
                >
                    {rows.length === 0 && !partialRow
                        ? this.renderEmpty()
                        : (
                            <>
                                {rows.map((line, index) => this.renderLine(
                                    line, index, badges, false,
                                ))}
                                {partialRow && this.renderLine(
                                    { ...partial, at: this.partialAt }, 'partial', badges, true,
                                )}
                            </>
                        )}
                </div>
                {/* Last, so that everything above it is in the document by
                    the time it says the render is over. */}
                <AfterRender run={() => this.afterRender()} />
            </div>
        );
    }

    protected renderToolbar(
        shown: number, matched: number, searching: boolean,
        counts: Record<LogLevel, number>,
    ): React.ReactNode {
        const search = nls.localize('vueport/debug/panels/terminal/search', 'Search output');
        const onlyMatches = nls.localize('vueport/debug/panels/terminal/onlyMatches', 'Only matches');

        return <div className="vp-terminal-toolbar">
            <div className="vp-panel-toolbar vp-terminal-search-row">
                <PanelFilter
                    value={this.search}
                    placeholder={search}
                    missed={searching && matched === 0}
                    status={searching && <span className="vp-terminal-count">
                        {nls.localize(
                            'vueport/debug/panels/terminal/matchCount', '{0} of {1}', matched, shown,
                        )}
                    </span>}
                    onChange={value => {
                        this.search = value;
                        // What is on screen changes underneath, so a view that
                        // was at the end stays at the end rather than being
                        // left hanging somewhere in the middle of the result.
                        this.updateAndFollow();
                    }}
                />
                <button
                    type="button"
                    className={'vp-terminal-only-matches vp-button'
                        + (this.onlyMatches ? '' : ' secondary')}
                    aria-pressed={this.onlyMatches}
                    disabled={!searching}
                    title={nls.localize(
                        'vueport/debug/panels/terminal/onlyMatchesHint',
                        'Hide the lines the search did not find, rather than dimming them',
                    )}
                    onClick={() => {
                        this.onlyMatches = this.remember('onlyMatches', !this.onlyMatches);
                        this.updateAndFollow();
                    }}
                >
                    {onlyMatches}
                </button>
                {/* The same kind of control as Only matches, and for the
                    same reason: both are states the panel is in rather than
                    settings it holds, and a switch beside a button would say
                    they were two different kinds of thing. */}
                <button
                    type="button"
                    className={`vp-terminal-follow vp-button${this.follow ? '' : ' secondary'}`}
                    aria-pressed={this.follow}
                    title={nls.localize(
                        'vueport/debug/panels/terminal/followOutputHint',
                        'Keep the view at the end of the output as it arrives',
                    )}
                    onClick={() => {
                        this.follow = this.remember('follow', !this.follow);
                        this.updateAndFollow();
                    }}
                >
                    {nls.localize(
                        'vueport/debug/panels/terminal/followOutput', 'Follow output',
                    )}
                </button>
                {/* Never disabled: this toolbar is only here while there is
                    output, which is the only thing Clear needs. */}
                <button
                    className="vp-terminal-clear vp-button secondary"
                    onClick={() => this.clear()}
                >
                    {nls.localize('vueport/debug/panels/terminal/clear', 'Clear')}
                </button>
            </div>
            <div className="vp-panel-toolbar vp-terminal-filter-row">
                {this.renderLevels(counts)}
            </div>
        </div>;
    }

    /**
     * A switch per level, with how many lines it holds.
     *
     * Only the levels that have something to say get one, so a build that
     * announces nothing — and most output announces nothing, which is why a
     * line without a prefix counts as information — is not given two empty
     * switches to read past. A level switched off keeps its
     * switch whether or not it has lines, since a control that hides output
     * and then hides itself leaves nothing to explain where the output went.
     */
    protected renderLevels(counts: Record<LogLevel, number>): React.ReactNode {
        const labels = this.levelLabels();
        const wanted = LOG_LEVELS.filter(
            level => counts[level] > 0 || !this.levels[level],
        );
        // One kind of line, all of it shown: there is nothing here to choose
        // between, and a lone switch would only be chrome.
        if (wanted.length < 2 && wanted.every(level => this.levels[level])) {
            return undefined;
        }

        return wanted.map(level => {
            const on = this.levels[level];
            const Icon = LEVEL_ICONS[level];
            return <button
                key={level}
                type="button"
                className={`vp-terminal-level ${level}${on ? ' on' : ''}`}
                aria-pressed={on}
                title={nls.localize(
                    'vueport/debug/panels/terminal/levelToggle',
                    'Show or hide {0} lines',
                    labels[level],
                )}
                onClick={() => {
                    this.levels = { ...this.levels, [level]: !on };
                    this.remember(`level.${level}`, !on);
                    this.updateAndFollow();
                }}
            >
                <Icon size={13} />
                {labels[level]}
                <span className="vp-terminal-level-count">{counts[level]}</span>
            </button>;
        });
    }

    /** What each level is called, on its switch and on the badges. */
    protected levelLabels(): Record<LogLevel, string> {
        return {
            info: nls.localize('vueport/debug/panels/terminal/levelInfo', 'Info'),
            warning: nls.localize('vueport/debug/panels/terminal/levelWarning', 'Warning'),
            error: nls.localize('vueport/debug/panels/terminal/levelError', 'Error'),
        };
    }

    /**
     * One line: when it was written, what it announced itself as, and what it
     * says. `badges` is what each level is called, or undefined for output
     * that never announced anything and so wants no column for it.
     */
    protected renderLine(
        line: TerminalLine, key: React.Key,
        badges: Record<LogLevel, string> | undefined, partial: boolean,
    ): React.ReactNode {
        // Dimmed rather than hidden while a search is on and nothing is being
        // hidden: what surrounds a match is most of what a log is read for.
        const searching = this.search !== '';
        const hit = searching && this.matches(line.text);
        const classes = ['vp-terminal-line', line.level];
        if (partial) {
            classes.push('partial');
        }
        if (hit) {
            classes.push('match');
        } else if (searching && !this.onlyMatches) {
            classes.push('aside');
        }

        return <div className={classes.join(' ')} key={key}>
            <span className="vp-log-time">{formatLogTime(line.at)}</span>
            {badges && <span className={`vp-terminal-badge ${line.level}`}>
                {badges[line.level]}
            </span>}
            <span className="vp-terminal-text">
                {hit ? this.renderMatches(line.text) : line.text}
            </span>
        </div>;
    }

    /** The line with what was searched for picked out of it. */
    protected renderMatches(text: string): React.ReactNode {
        const needle = this.search.toLowerCase();
        const haystack = text.toLowerCase();
        const parts: React.ReactNode[] = [];
        let at = 0;
        for (let found = haystack.indexOf(needle); found >= 0;
            found = haystack.indexOf(needle, at)) {
            if (found > at) {
                parts.push(text.slice(at, found));
            }
            at = found + needle.length;
            parts.push(
                <mark className="vp-terminal-match" key={found}>
                    {text.slice(found, at)}
                </mark>,
            );
        }
        if (at < text.length) {
            parts.push(text.slice(at));
        }
        return parts;
    }

    protected renderEmpty(): React.ReactNode {
        // Asked in this order because something was captured is the more
        // particular fact: a machine that has gone away with output still on
        // screen, all of it filtered out, is a panel that looks empty for a
        // reason the reader can undo.
        if (this.hasOutput()) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/terminal/nothingShown',
                    'Nothing to show',
                )}
                description={nls.localize(
                    'vueport/debug/panels/terminal/nothingShownHint',
                    'The search or the level switches are hiding every line that was captured.',
                )}
                icon={<Funnel size={32} />}
            />;
        }
        if (!this.source.sim) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }
        return <EmptyContainer
            title={nls.localize(
                'vueport/debug/panels/terminal/waiting',
                'Waiting for output',
            )}
            description={nls.localize(
                'vueport/debug/panels/terminal/waitingHint',
                'This game has not yet written to the terminal output.',
            )}
            icon={<Terminal size={32} />}
        />;
    }
}
