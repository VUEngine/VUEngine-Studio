import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import { ScreenInspectorTarget } from './emulator-screen-inspector';
import { arrowKeysTaken, hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { field, numberInput, stacked } from './emulator-vip-detail';
import { exportVipImage, VipCanvas, VipExportFile } from './emulator-vip-canvas';
import { Sim } from '../core/vb-core';
import {
    decodeVipBgMapCell,
    decodeVipWorld,
    drawVipChar,
    encodeVipBgMapCell,
    forEachVipWorldPixel,
    sameVipBytes,
    VIP_BGMAP_BYTES,
    VIP_BGMAP_BASE,
    VIP_BGMAP_CELLS,
    VIP_BGMAP_COUNT,
    VIP_BGMAP_PALETTES,
    VIP_CHAR_COUNT,
    VIP_CHAR_COUNT_EXTENDED,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SIZE,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VIP_WORLD_BASE,
    VIP_WORLD_BLOCK_BYTES,
    VIP_WORLD_BYTES,
    VIP_WORLD_COUNT,
    VIP_WORLD_MODE_NAMES,
    vipBgMapAddress,
    VipBgMapCell,
    VipBgMapSegmentUse,
    vipBgMapSegmentUses,
    vipCharSegmentAddress,
    vipCharSegmentCount,
    vipWorldSourceExtents,
    VipCharacters,
    VipEye,
    vipIntensitiesForRegister,
    VipIntensityWatcher,
    vipParamTableAddress,
    vipParamTableBytes,
    VipWorld,
    VipWorldMap,
    VipWorldMode,
    vipWorldSample,
    vipWorldSegments,
    vipOverplaneSegment,
} from './emulator-vip-memory';
import { VcuColors, VcuPlacement, vcuPlacement, vipShade } from './emulator-vcu-colors';
import {
    decodeVcuColorAttr,
    decodeVcuPixelAttr,
    encodeVcuColorAttr,
    encodeVcuPixelAttr,
    readVbcState,
    vbcCharMask,
    VbcState,
    VCU_CELL_COLOR_BASE,
    VCU_CELL_PIXEL_ATTR_BASE,
    VCU_CHARACTER_COLOR_BASE,
    VCU_CHARACTER_PIXEL_ATTR_BASE,
    VCU_CRAM_BASE,
    VCU_CRAM_BYTES,
    VCU_CRAM_ENTRY_BYTES,
    VCU_CRAM_PALETTE_SIZE,
    VCU_PIXEL_SLOT_COUNT,
    VcuColorAttr,
    vcuPlacementPalette,
    VcuPixelAttr,
    vcuRgb888,
} from './emulator-vcu-memory';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';
import Select from '../components/kit/Select';
import Switch from '../components/kit/Switch';

/**
 * How much the sidebar's single-cell preview is blown up: 8 source pixels at
 * 27 is the 216-pixel preview the sidebar is sized to hold, the same one the
 * Objects and Characters panels show.
 */
const PREVIEW_ZOOM = 27;

/**
 * How wide a world's preview under Used by is drawn, and how tall it is let
 * to become. Scaled to fit rather than stretched, since a world with the
 * wrong proportions is no longer a picture of where anything is — the
 * Characters panel sizes the maps in its own Used by the same way.
 */
const WORLD_PREVIEW_WIDTH = 208;
const WORLD_PREVIEW_MAX_HEIGHT = 192;

/** Previews are of one eye; the parallax between them is not the point here. */
const PREVIEW_EYE: VipEye = 'left';

/**
 * How far the parts of a world that come out of some other segment are faded
 * in its preview, and they lose the hardware's red with it.
 *
 * The same treatment, and the same factor, as the worlds around the selected
 * one in the Worlds panel and the characters a filter leaves out in the
 * Characters panel: the subject in red, what surrounds it in gray. Drawn
 * in VB Color the faded part keeps its colors, only darkened as far — gray
 * would no longer say which part of the world it is, red would no longer
 * stand out.
 */
const OTHER_SEGMENT_FACTOR = 0.18;

/** Cells in one BGMap segment, and so Color Attribute entries per segment. */
const SEGMENT_CELLS = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;

/** The highest palette group a Color Attribute's six bits can name. */
const VCU_GROUP_MAX = 0x3f;

/** A pixel with nothing in it, drawn the way the red pictures draw pixel value 0. */
function putBlank(target: Uint8ClampedArray, offset: number): void {
    target[offset] = 0;
    target[offset + 1] = 0;
    target[offset + 2] = 0;
    target[offset + 3] = 255;
}

function worldPreviewZoom(image: ImageData): number {
    return Math.min(WORLD_PREVIEW_WIDTH / image.width, WORLD_PREVIEW_MAX_HEIGHT / image.height);
}

/** One line of Used by: which world, what it takes, and what it draws. */
interface UsedByWorld {
    index: number;
    /** BGMap, HBias or Affine — how it reads the map. */
    mode: string;
    /** Map, Params, or both. */
    takes: string;
    image?: ImageData;
}

/**
 * The fourteen BGMap segments, and the selected one rasterized as one 512x512
 * bitmap beside its fields — which inspect, and for the character, palette
 * and flips edit, one cell at a time.
 *
 * Three columns, the shape the Worlds panel has: the segments as tiles, the
 * fields of the one picked, and the map itself. Reads the selected segment's
 * cells plus the character memory they reference each refresh, and
 * re-rasterizes only when the pixels or the shading actually changed — see
 * the Characters panel, whose caching this mirrors. The tiles cost one more
 * read, of world attribute memory, since what a segment is being used for is
 * a fact about the worlds pointing at it rather than about the segment
 * itself.
 */
export class BgMapsPanel extends Panel {

    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[] = [];
    protected cells?: Uint8Array;
    /** The segment being shown, and those the Used by previews read from. */
    protected bgMapSegments: (Uint8Array | undefined)[] = [];
    /** The param tables of the worlds under Used by, by world index. */
    protected paramTables: (Uint8Array | undefined)[] = [];
    /** What Used by shows, rebuilt when the maps or the worlds move. */
    protected usedBy: UsedByWorld[] = [];
    protected worldBytes?: Uint8Array;
    /** Only while a VB Color game has unlocked the VCU; see `readVbcState`. */
    protected vbc?: VbcState;
    /**
     * The shown segment's Cell Color Attribute bytes and Cell Pixel Color
     * Attribute halfwords, and the color RAM they point into — read only
     * while `vbc` is there, for the selected cell's VB Color group. What
     * the pictures are drawn with is `colors`, so none of this marks the
     * image dirty.
     */
    protected cellColors?: Uint8Array;
    protected cellPixelAttrs?: DataView;
    protected cram?: DataView;
    /**
     * The Color Attribute byte and Pixel Color Attribute halfword of the
     * selected cell's character, which stand in for the cell's own under
     * CHRSEL and CCEN. Read for that one character rather than the 16 KiB of
     * both tables, and tagged with it, so that a selection which has moved on
     * is not shown the previous cell's.
     */
    protected characterColor?: { char: number, color: number, pixel: number };
    protected segment = 0;
    protected selected = 0;
    protected zoom = this.remembered('zoom', 1);
    protected showGrid = this.remembered('showGrid', false);
    /**
     * Whether the map is shaded with an even ramp instead of the palette
     * registers the game has set up. Off: the previews resolve the brightness
     * registers the way the core does, so the real palettes look like the
     * picture on screen. The even ramp is for reading the tile data itself.
     */
    protected showGenericPalette = this.remembered('showGenericPalette', false);
    /**
     * Whether the pictures are drawn in the colors a VB Color shows rather
     * than the VIP's red. On by default, but only ever in effect while the
     * game has switched color on — see `colorMode` — so a plain Virtual Boy
     * game is drawn as it always was whatever this says.
     */
    protected vbColorPreview = this.remembered('vbColorPreview', true);
    /**
     * The VCU tables the pictures are colored from, read only in color mode
     * and for the segments drawn — see `readPreviewColors`.
     */
    protected colors?: VcuColors;
    /**
     * The world whose read area is outlined on the map: the one the pointer
     * is over in Used by, or — once a row has been clicked — the one pinned
     * there. Hovering another previews it and leaving falls back to the
     * pinned one. Both are dropped when another segment is picked, since the
     * outline is about the map being shown.
     */
    protected hoveredWorld?: number;
    protected pinnedWorld?: number;

    protected image?: ImageData;
    protected dirty = true;
    protected readonly intensityWatcher = new VipIntensityWatcher();

    constructor(
        source: DebugSource,
        instanceId: string,
        /** Where Export PNG hands its file; no button without it. */
        protected readonly exportFile?: VipExportFile
    ) {
        super(EmulatorPanelType.VIP_BGMAPS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_BGMAPS);
        // The three columns each scroll on their own, so the panel's own
        // scrolling is switched off and the layout is hung on this class,
        // which the Worlds panel wears too — see the stylesheet.
        this.addClass('vp-vip-panel');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.registers = undefined;
            this.charSegments = [];
            this.cells = undefined;
            this.bgMapSegments = [];
            this.paramTables = [];
            this.worldBytes = undefined;
            this.usedBy = [];
            this.image = undefined;
            this.vbc = undefined;
            this.colors = undefined;
            this.clearColors();
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));
            this.vbc = await readVbcState(this.source, sim);

            // With CHREXT a cell can name the extension's characters too, so
            // its four segments are read after the VIP's — and dropped again,
            // with the twelve-bit mask, when the game switches it off.
            const count = vipCharSegmentCount(this.vbc?.chrext ?? false);
            if (this.charSegments.length !== count) {
                this.charSegments = this.charSegments.slice(0, count);
                this.dirty = true;
            }
            const segments = await Promise.all(Array.from({ length: count },
                (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
            ));
            segments.forEach((buffer, index) => {
                const bytes = new Uint8Array(buffer);
                if (!sameVipBytes(bytes, this.charSegments[index])) {
                    this.charSegments[index] = bytes;
                    this.dirty = true;
                }
            });

            const worldBytes = new Uint8Array(await sim.readMemory(VIP_WORLD_BASE, VIP_WORLD_BLOCK_BYTES));
            // The map itself does not depend on the worlds, so this has a
            // flag of its own: what it moves is the Used by list beside it.
            const worldsMoved = !sameVipBytes(worldBytes, this.worldBytes);
            this.worldBytes = worldBytes;

            const mapSegments = await this.readMaps(sim);
            await this.readColors(sim);
            await this.readPreviewColors(sim, mapSegments);

            if (this.intensityWatcher.changed(this.registers)) {
                this.dirty = true;
            }
            this.error = undefined;

            if (this.dirty || worldsMoved) {
                this.usedBy = this.buildUsedBy(this.registers);
            }
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        if (this.dirty && this.registers) {
            this.image = this.rasterize(this.registers);
            this.dirty = false;
        }
        this.update();
    }

    /**
     * The BGMap memory the panel draws from: the segment being shown, and
     * the maps and param tables of the worlds listed under Used by, which
     * their previews are made of.
     *
     * A world's map can span segments other than the one being looked at, so
     * this is the union rather than the one segment — but still only what
     * the list needs, rather than all fourteen every poll.
     */
    protected async readMaps(sim: Sim): Promise<number[]> {
        const worlds = this.usedByWorlds();
        const needed = [...new Set([
            this.segment,
            ...worlds.flatMap(world => vipWorldSegments(world)),
        ])];

        const maps = await Promise.all(needed.map(
            segment => sim.readMemory(vipBgMapAddress(segment), VIP_BGMAP_BYTES)));
        const segments: (Uint8Array | undefined)[] = [];
        needed.forEach((segment, index) => {
            const bytes = new Uint8Array(maps[index]);
            if (!sameVipBytes(bytes, this.bgMapSegments[segment])) {
                this.dirty = true;
            }
            segments[segment] = bytes;
        });
        this.bgMapSegments = segments;
        this.cells = segments[this.segment];

        const tables: (Uint8Array | undefined)[] = [];
        await Promise.all(worlds.map(async world => {
            const length = vipParamTableBytes(world);
            if (length > 0) {
                tables[world.index] = new Uint8Array(
                    await sim.readMemory(vipParamTableAddress(world.param), length));
            }
        }));
        this.paramTables = tables;
        return needed;
    }

    /** Whether the pictures are drawn in VB Color: the option, and color switched on. */
    protected colorMode(): boolean {
        return !!this.vbc && this.vbColorPreview;
    }

    /**
     * The VCU tables drawing the pictures in color takes, for the segments
     * they are drawn from — plus those the overplane cells of the worlds
     * under Used by sit in, whose Color Attributes the core takes from there.
     *
     * The pictures are drawn again only when something in them changed, the
     * way the map's cells and characters are compared; leaving color mode
     * drops the tables and redraws in red.
     */
    protected async readPreviewColors(sim: Sim, segments: number[]): Promise<void> {
        if (!this.vbc || !this.colorMode()) {
            if (this.colors) {
                this.colors = undefined;
                this.dirty = true;
            }
            return;
        }
        const overplanes = this.usedByWorlds()
            .filter(world => world.overplane)
            .map(world => vipOverplaneSegment(world));
        const colors = await VcuColors.read(sim, this.vbc, { segments: [...segments, ...overplanes], worlds: true });
        if (!colors.same(this.colors)) {
            this.dirty = true;
        }
        this.colors = colors;
    }

    /**
     * The VB Color side of the shown segment: its cells' Color and Pixel
     * Color Attributes, and color RAM for the swatches of the palette the
     * selected one ends up with.
     *
     * The whole segment's entries rather than the selected cell's, the way
     * the cells themselves are read, so that walking the map shows each
     * cell's at once instead of a poll later; with CRAM that is 16 KiB a
     * poll, and nothing at all on a game that has not switched color on.
     */
    protected async readColors(sim: Sim): Promise<void> {
        if (!this.vbc) {
            this.clearColors();
            return;
        }
        const first = this.segment * SEGMENT_CELLS;
        const [colors, pixels, cram] = await Promise.all([
            sim.readMemory(VCU_CELL_COLOR_BASE + first, SEGMENT_CELLS),
            sim.readMemory(VCU_CELL_PIXEL_ATTR_BASE + first * 2, SEGMENT_CELLS * 2),
            sim.readMemory(VCU_CRAM_BASE, VCU_CRAM_BYTES),
        ]);
        this.cellColors = new Uint8Array(colors);
        this.cellPixelAttrs = new DataView(pixels);
        this.cram = new DataView(cram);
        await this.readCharacterColor(sim);
    }

    protected clearColors(): void {
        this.cellColors = undefined;
        this.cellPixelAttrs = undefined;
        this.cram = undefined;
        this.characterColor = undefined;
    }

    /**
     * The selected cell's character's own color entries — only when they
     * are what the cell is drawn with, its CHRSEL set and CCEN on, since
     * otherwise nothing here shows them.
     */
    protected async readCharacterColor(sim: Sim): Promise<void> {
        const cells = this.cells;
        const colors = this.cellColors;
        if (!this.vbc?.ccen || !cells || !colors || !decodeVcuColorAttr(colors[this.selected]).chrsel) {
            this.characterColor = undefined;
            return;
        }
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);
        const char = decodeVipBgMapCell(view.getUint16(this.selected * 2, true), this.charMask()).char;
        // Byte 0 of a character's pair is its Cell palette, byte 1 its OBJ
        // one; the Pixel Color Attribute is one halfword for both.
        const [color, pixel] = await Promise.all([
            sim.readMemory(VCU_CHARACTER_COLOR_BASE + char * 2, 1),
            sim.readMemory(VCU_CHARACTER_PIXEL_ATTR_BASE + char * 2, 2),
        ]);
        this.characterColor = {
            char,
            color: new Uint8Array(color)[0],
            pixel: new DataView(pixel).getUint16(0, true),
        };
    }

    /** How many bits of a cell name its character: twelve with CHREXT. */
    protected charMask(): number {
        return vbcCharMask(this.vbc);
    }

    /** How many characters a cell can name: 2048, or 4096 with CHREXT. */
    protected charCount(): number {
        return this.vbc?.chrext ? VIP_CHAR_COUNT_EXTENDED : VIP_CHAR_COUNT;
    }

    protected setSegment(segment: number): void {
        if (Number.isNaN(segment)) {
            return;
        }
        this.segment = Math.min(VIP_BGMAP_COUNT - 1, Math.max(0, segment));
        // The outline was about the map being left behind.
        this.hoveredWorld = undefined;
        this.pinnedWorld = undefined;
        // Selected cell index is left as-is: it stays valid across a segment
        // switch (every map is 64x64), and keeping it lets you compare the
        // same position across maps.
        this.dirty = true;
        this.refresh();
    }

    /** Show a cell the screen inspector points at: its segment, and the cell selected and in view. */
    reveal(target: ScreenInspectorTarget): void {
        if (target.kind !== 'cell') {
            return;
        }
        const index = (target.address - VIP_BGMAP_BASE) >> 1;
        const cells = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;
        this.setSegment(Math.floor(index / cells));
        this.selectCell(index % cells);
        requestAnimationFrame(() => this.node.querySelector('.vp-canvas-selection')
            ?.scrollIntoView({ block: 'center', inline: 'center' }));
    }

    protected selectCell(cell: number): void {
        if (Number.isNaN(cell)) {
            return;
        }
        const count = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;
        this.selected = Math.min(count - 1, Math.max(0, cell));
        this.update();
        // The one read that is about the selected cell rather than the whole
        // segment, fetched now rather than at the next poll.
        const sim = this.source.sim;
        if (sim && this.vbc?.ccen) {
            this.readCharacterColor(sim).then(() => this.update(), () => undefined);
        }
    }

    protected setShowGenericPalette(value: boolean): void {
        this.showGenericPalette = this.remember('showGenericPalette', value);
        this.dirty = true;
        this.refresh();
    }

    /** Draw in VB Color or in red; the refresh reads or drops the tables. */
    protected setVbColorPreview(value: boolean): void {
        this.vbColorPreview = this.remember('vbColorPreview', value);
        this.dirty = true;
        this.refresh();
    }

    /**
     * Patch the selected cell — its character and/or its palette/flip bits —
     * and write the result back to VRAM. Callers are trusted to have already
     * clamped `char` to a valid character index; palette and the flip flags
     * come from a bounded dropdown and checkboxes respectively, so need no
     * clamping of their own.
     */
    protected async writeCell(patch: Partial<VipBgMapCell>): Promise<void> {
        const sim = this.source.sim;
        const cells = this.cells;
        if (!sim || !cells) {
            return;
        }

        const offset = this.selected * 2;
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);
        const current = decodeVipBgMapCell(view.getUint16(offset, true), this.charMask());
        const raw = encodeVipBgMapCell({ ...current, ...patch }, this.charMask());

        await this.source.write(vipBgMapAddress(this.segment) + offset, [raw & 0xff, raw >> 8]);

        this.dirty = true;
        await this.refresh();
    }

    /**
     * Patch the selected cell's Cell Color Attribute byte, keeping the bit
     * the encoder does not name as it was.
     */
    protected async writeColorAttr(patch: Partial<VcuColorAttr>): Promise<void> {
        const colors = this.cellColors;
        if (!this.source.sim || !colors) {
            return;
        }
        const previous = colors[this.selected];
        const raw = encodeVcuColorAttr({ ...decodeVcuColorAttr(previous), ...patch }, previous);
        await this.source.write(VCU_CELL_COLOR_BASE + this.segment * SEGMENT_CELLS + this.selected, [raw]);
        await this.refresh();
    }

    /** The same for its Cell Pixel Color Attribute halfword. */
    protected async writePixelAttr(patch: Partial<VcuPixelAttr>): Promise<void> {
        const pixels = this.cellPixelAttrs;
        if (!this.source.sim || !pixels) {
            return;
        }
        const previous = pixels.getUint16(this.selected * 2, true);
        const raw = encodeVcuPixelAttr({ ...decodeVcuPixelAttr(previous), ...patch }, previous);
        await this.source.write(
            VCU_CELL_PIXEL_ATTR_BASE + (this.segment * SEGMENT_CELLS + this.selected) * 2,
            [raw & 0xff, raw >> 8]
        );
        await this.refresh();
    }

    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][] {
        return this.showGenericPalette
            ? [0, 1, 2, 3].map(() => VIP_GENERIC_PALETTE_INTENSITIES)
            : VIP_BGMAP_PALETTES.map(register => vipIntensitiesForRegister(registers, register));
    }

    /**
     * The color counterpart of `palettes`: the shade each BGMap palette gives
     * each pixel value — the two bits of its GPLT register the value picks,
     * which is the CRAM entry within the cell's palette — or, with the
     * generic palette, the value itself, as the even ramp is.
     */
    protected shades(registers: DataView): number[][] {
        return VIP_BGMAP_PALETTES.map(register => {
            const byte = registers.getUint16(register, true) & 0xff;
            return [0, 1, 2, 3].map(value => this.showGenericPalette ? value : vipShade(byte, value));
        });
    }

    /** The tables to draw in color with, or nothing while the pictures are red. */
    protected previewColors(): VcuColors | undefined {
        return this.colorMode() ? this.colors : undefined;
    }

    /**
     * One cell's character in VB Color, where `drawVipChar` draws it in red:
     * flipped the same way, and with a pixel the hardware leaves out drawn
     * black, as the red pictures draw pixel value 0. `charX`/`charY` are the
     * character's own coordinates, since a Pixel Color Slot is laid out in
     * those rather than the flipped ones.
     */
    protected drawColorChar(
        target: Uint8ClampedArray, targetWidth: number, destX: number, destY: number,
        characters: VipCharacters, colors: VcuColors, placement: VcuPlacement,
        cell: VipBgMapCell, shades: number[][]
    ): void {
        for (let y = 0; y < VIP_CHAR_SIZE; y++) {
            for (let x = 0; x < VIP_CHAR_SIZE; x++) {
                const charX = cell.hFlip ? VIP_CHAR_SIZE - 1 - x : x;
                const charY = cell.vFlip ? VIP_CHAR_SIZE - 1 - y : y;
                const value = characters.pixel(cell.char, charX, charY);
                const offset = ((destY + y) * targetWidth + destX + x) * 4;
                if (!colors.put(target, offset, placement, value, charX, charY, shades[cell.palette][value])) {
                    putBlank(target, offset);
                }
            }
        }
    }

    protected rasterize(registers: DataView): ImageData | undefined {
        const cells = this.cells;
        if (!cells || this.charSegments.length === 0) {
            return undefined;
        }
        const characters = new VipCharacters(this.charSegments);
        const palettes = this.palettes(registers);
        const colors = this.previewColors();
        const shades = this.shades(registers);
        const placement = vcuPlacement();
        const size = VIP_BGMAP_CELLS * VIP_CHAR_SIZE;
        const pixels = new Uint8ClampedArray(size * size * 4);
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);

        for (let row = 0; row < VIP_BGMAP_CELLS; row++) {
            for (let column = 0; column < VIP_BGMAP_CELLS; column++) {
                const index = row * VIP_BGMAP_CELLS + column;
                const cell = decodeVipBgMapCell(view.getUint16(index * 2, true), characters.charMask);
                if (colors) {
                    colors.cell(this.segment, index, cell.char, cell.palette, placement);
                    this.drawColorChar(
                        pixels, size, column * VIP_CHAR_SIZE, row * VIP_CHAR_SIZE,
                        characters, colors, placement, cell, shades
                    );
                    continue;
                }
                drawVipChar(
                    pixels,
                    size,
                    column * VIP_CHAR_SIZE,
                    row * VIP_CHAR_SIZE,
                    characters,
                    cell.char,
                    palettes[cell.palette],
                    cell.hFlip,
                    cell.vFlip
                );
            }
        }
        return new ImageData(pixels, size, size);
    }

    /**
     * What the worlds currently being drawn do with each segment: which of
     * them read their map out of it, and whose param table is sitting in it.
     * A segment under neither is free.
     */
    protected segmentUses(): VipBgMapSegmentUse[] {
        return vipBgMapSegmentUses(this.worlds());
    }

    /** Every world, decoded out of the last read of world attribute memory. */
    protected worlds(): VipWorld[] {
        const bytes = this.worldBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return Array.from({ length: VIP_WORLD_COUNT }, (unused, index) =>
            decodeVipWorld(view, index, index * VIP_WORLD_BYTES));
    }

    /** The worlds Used by lists: those reading this segment, or kept in it. */
    protected usedByWorlds(): VipWorld[] {
        const use = this.segmentUses()[this.segment];
        if (!use) {
            return [];
        }
        const listed = new Set([...use.worlds, ...use.params]);
        return this.worlds()
            .filter(world => listed.has(world.index))
            .sort((a, b) => b.index - a.index);
    }

    /**
     * What Used by shows: a line per world, and under it a picture of what
     * that world draws, with the pixels it reads out of this segment picked
     * out.
     *
     * Rebuilt here rather than while rendering, because the panel re-renders
     * whenever the pointer moves over the list and these are rasterized.
     */
    protected buildUsedBy(registers: DataView): UsedByWorld[] {
        const use = this.segmentUses()[this.segment] ?? { worlds: [], params: [] };
        return this.usedByWorlds().map(world => ({
            index: world.index,
            mode: VIP_WORLD_MODE_NAMES[world.mode],
            takes: [
                use.worlds.includes(world.index) && nls.localize('vueport/debug/panels/bgmaps/asMap', 'Map'),
                use.params.includes(world.index) && nls.localize('vueport/debug/panels/bgmaps/asParams', 'Params'),
            ].filter(Boolean).join(', '),
            image: this.drawWorldPreview(registers, world),
        }));
    }

    /**
     * One world as it is actually drawn, with the part of it that comes out
     * of this segment picked out — red for this segment, faded gray for
     * whatever the world reads from its other ones. In VB Color, the colors
     * it is shown in, with the other segments' part darkened instead.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one. The three properties that place the finished
     * rectangle on the screen — GX, GY, GP — are the only ones dropped, since
     * the preview is the rectangle. Copied in spirit from the Characters
     * panel, which marks the selected character in its own Used by the same
     * way.
     */
    protected drawWorldPreview(registers: DataView, world: VipWorld): ImageData | undefined {
        const width = Math.min(world.w + 1, VIP_FRAME_BUFFER_WIDTH);
        const height = Math.min(world.h + 1, VIP_FRAME_BUFFER_HEIGHT);
        if (world.mode === VipWorldMode.OBJECT || width <= 0 || height <= 0) {
            return undefined;
        }
        // Drawn no finer than it is shown: sampling every second pixel is
        // less work than drawing all of them for the browser to throw away.
        const stride = Math.max(1, Math.ceil(width / WORLD_PREVIEW_WIDTH));
        const previewWidth = Math.ceil(width / stride);
        const previewHeight = Math.ceil(height / stride);
        const pixels = new Uint8ClampedArray(previewWidth * previewHeight * 4);

        const map = new VipWorldMap(world, this.bgMapSegments, new VipCharacters(this.charSegments));
        const palettes = this.palettes(registers);
        const params = this.paramTables[world.index];
        const view = params && new DataView(params.buffer, params.byteOffset, params.byteLength);
        const colors = this.previewColors();
        const shades = this.shades(registers);
        const worldOffset = colors?.worldOffset(world.index) ?? 0;
        // Reused for every pixel, so that drawing a world does not allocate
        // per pixel.
        const sample = vipWorldSample();
        const placement = vcuPlacement();
        forEachVipWorldPixel(
            { ...world, gx: 0, gy: 0, gp: 0 }, width, height, PREVIEW_EYE, view,
            (x, y, sourceX, sourceY) => {
                if (x % stride !== 0 || y % stride !== 0) {
                    return;
                }
                const offset = ((y / stride) * previewWidth + x / stride) * 4;
                if (colors) {
                    map.sample(sourceX, sourceY, sample);
                    colors.cell(
                        sample.segment, sample.cell, sample.char, sample.palette, placement);
                    const shade = shades[sample.palette][sample.value];
                    if (!colors.put(
                        pixels, offset, placement, sample.value, sample.charX, sample.charY, shade, worldOffset
                    )) {
                        putBlank(pixels, offset);
                    } else if (map.segmentAt(sourceX, sourceY) !== this.segment) {
                        pixels[offset] = Math.round(pixels[offset] * OTHER_SEGMENT_FACTOR);
                        pixels[offset + 1] = Math.round(pixels[offset + 1] * OTHER_SEGMENT_FACTOR);
                        pixels[offset + 2] = Math.round(pixels[offset + 2] * OTHER_SEGMENT_FACTOR);
                    }
                    return;
                }
                const intensity = map.intensity(sourceX, sourceY, palettes);
                if (map.segmentAt(sourceX, sourceY) === this.segment) {
                    // Red, the color the hardware emits, for the part of the
                    // world this segment is: it is the subject here.
                    pixels[offset] = intensity;
                } else {
                    const gray = Math.round(intensity * OTHER_SEGMENT_FACTOR);
                    pixels[offset] = gray;
                    pixels[offset + 1] = gray;
                    pixels[offset + 2] = gray;
                }
                pixels[offset + 3] = 255;
            }
        );
        return new ImageData(pixels, previewWidth, previewHeight);
    }

    /**
     * The area the hovered world reads out of this segment, for the outline
     * over the map, or undefined while nothing is hovered.
     */
    protected hoveredExtents(): { x: number, y: number, width: number, height: number } | undefined {
        const world = this.worlds()[this.hoveredWorld ?? this.pinnedWorld ?? -1];
        return world && vipWorldSourceExtents(world, this.segment);
    }

    protected setHoveredWorld(index: number | undefined): void {
        if (this.hoveredWorld !== index) {
            this.hoveredWorld = index;
            this.update();
        }
    }

    /** Keep the outline of one world up, or take it down again. */
    protected togglePinnedWorld(index: number): void {
        this.pinnedWorld = this.pinnedWorld === index ? undefined : index;
        this.update();
    }

    /**
     * A click in Used by that lands on none of its worlds — the space between
     * and under them — lets go of the pinned one, as a second click on it
     * does.
     */
    protected onUsedByClick(event: React.MouseEvent): void {
        if (this.pinnedWorld !== undefined && !(event.target as Element).closest('button')) {
            this.pinnedWorld = undefined;
            this.update();
        }
    }

    /**
     * The fourteen segments as tiles: the number and the worlds reading it on
     * one line, its address and — where one sits in it — Param under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next segment does not mean leaving the one being read.
     */
    protected renderTiles(uses: VipBgMapSegmentUse[]): React.ReactNode {
        // Focusable in its own right: the panel's arrow keys walk the cells
        // of the map, and in here they walk the segments instead.
        return <div
            className='vp-tiles vp-scroll'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps')}
            onKeyDown={event => this.onTilesKey(event)}
        >
            {uses.map((use, segment) => {
                const used = use.worlds.length > 0 || use.params.length > 0;
                return <button
                    type='button'
                    key={segment}
                    className={`vp-tile${used ? '' : ' inactive'}`
                        + `${segment === this.segment ? ' selected' : ''}`}
                    aria-pressed={segment === this.segment}
                    tabIndex={-1}
                    title={BgMapsPanel.segmentTitle(use)}
                    onClick={() => this.setSegment(segment)}
                >
                    <span className='vp-tile-index'>{segment}</span>
                    <span className='vp-tile-mark'>{use.worlds.length || '\u2013'}</span>
                    <span className='vp-tile-note vp-bgmaps-tile-address'>
                        {hex(vipBgMapAddress(segment), 8)}
                    </span>
                    {use.params.length > 0 &&
                        <span className='vp-tile-flag'>
                            {nls.localize('vueport/debug/panels/bgmaps/params', 'Params')}
                        </span>
                    }
                </button>;
            })}
        </div>;
    }

    /** What a tile's count stands for, spelled out on hover. */
    protected static segmentTitle(use: VipBgMapSegmentUse): string | undefined {
        const lines = [];
        if (use.worlds.length) {
            lines.push(nls.localize(
                'vueport/debug/panels/bgmaps/segmentWorldsHint', 'Worlds whose map this segment is part of'
            ) + `: ${use.worlds.join(', ')}`);
        }
        if (use.params.length) {
            lines.push(nls.localize(
                'vueport/debug/panels/bgmaps/segmentParamsHint', 'Worlds whose param table this segment holds'
            ) + `: ${use.params.join(', ')}`);
        }
        return lines.length ? lines.join('\n') : undefined;
    }

    /**
     * Walk the segments with the keyboard, from inside the tiles.
     *
     * Stopped rather than only defaulted: the emulator listens for keys on
     * the node this panel sits inside and would otherwise read an arrow as
     * the D-pad and move the game.
     */
    protected onTilesKey(event: React.KeyboardEvent): void {
        const steps: Record<string, number> = {
            ArrowUp: -1, ArrowLeft: -1, ArrowDown: 1, ArrowRight: 1,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.setSegment(home ? 0 : end ? VIP_BGMAP_COUNT - 1 : this.segment + step);
        this.revealSegment();
    }

    /**
     * Walk the cells of the map with the keyboard, from anywhere else in the
     * panel: a cell at a time sideways, a row at a time up and down, a
     * screenful with Page keys, and the ends of the map with Home and End.
     */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        const steps: Record<string, number> = {
            ArrowLeft: -1,
            ArrowRight: 1,
            ArrowUp: -VIP_BGMAP_CELLS,
            ArrowDown: VIP_BGMAP_CELLS,
            PageUp: -VIP_BGMAP_CELLS * 8,
            PageDown: VIP_BGMAP_CELLS * 8,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        const cells = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;
        this.selectCell(home ? 0 : end ? cells - 1 : this.selected + step);
        this.revealCell();
    }

    /** Keep the picked segment's tile in view, and the ring on it. */
    protected revealSegment(): void {
        requestAnimationFrame(() => {
            const tile = this.node.querySelector<HTMLElement>('.vp-tile.selected');
            tile?.scrollIntoView({ block: 'nearest' });
            tile?.focus({ preventScroll: true });
        });
    }

    /** Keep the picked cell in view as the keys walk off the visible map. */
    protected revealCell(): void {
        requestAnimationFrame(() => this.node
            .querySelector('.vp-canvas-selection')
            ?.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
    }

    /**
     * Just the selected cell's character, for the sidebar preview — in the
     * colors its cell gives it, in color mode, CHRSEL and slot included.
     */
    protected rasterizePreview(registers: DataView, characters: VipCharacters, cell: VipBgMapCell): ImageData {
        const pixels = new Uint8ClampedArray(VIP_CHAR_SIZE * VIP_CHAR_SIZE * 4);
        const colors = this.previewColors();
        if (colors) {
            const placement = colors.cell(this.segment, this.selected, cell.char, cell.palette);
            this.drawColorChar(
                pixels, VIP_CHAR_SIZE, 0, 0, characters, colors, placement, cell, this.shades(registers));
        } else {
            const palettes = this.palettes(registers);
            drawVipChar(
                pixels, VIP_CHAR_SIZE, 0, 0, characters, cell.char, palettes[cell.palette], cell.hFlip, cell.vFlip);
        }
        return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        if (!this.registers) {
            return (
                <EmptyContainer
                    title={nls.localize(
                        'vueport/general/notRunning',
                        'The emulator is not running.',
                    )}
                    icon={<Plug size={32} />}
                />
            );
        }
        if (!this.image || !this.cells) {
            return <div className='vp-panel-empty'>
                {nls.localize('vueport/debug/panels/bgmaps/reading', 'Reading VIP memory…')}
            </div>;
        }

        const registers = this.registers;
        const cells = this.cells;
        const selected = this.selected;
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);
        const cell = decodeVipBgMapCell(view.getUint16(selected * 2, true), this.charMask());
        const address = vipBgMapAddress(this.segment) + selected * 2;

        const characters = new VipCharacters(this.charSegments);
        const preview = this.rasterizePreview(registers, characters, cell);

        const uses = this.segmentUses();
        const use = uses[this.segment] ?? { worlds: [], params: [] };

        // Focusable, and the arrow keys are read here rather than on the map:
        // wherever focus has landed in the panel they walk its cells. The
        // tiles are in the tab order in their own right and so keep their own
        // handler, which walks the segments; see `arrowKeysTaken`.
        return <div
            className='vp-columns'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps')}
            onKeyDown={event => this.onPanelKey(event)}
        >
            {this.renderTiles(uses)}
            <div className='vp-sidebar vp-scroll'>
                {this.renderSegmentGroup(use)}
                {this.renderCharacterGroup(preview)}
                {this.renderCellGroup(cell, address)}
                {this.vbc && this.renderColorGroup(this.vbc, cell)}
                {this.renderUsedByGroup()}
            </div>
            {/* The map scrolls on its own, and the controls under it stay
                put however far it is zoomed. */}
            <div className='vp-preview vp-preview-with-controls'>
                <div className='vp-preview-view vp-scroll'>
                    <VipCanvas
                        image={this.image}
                        zoom={this.zoom}
                        cellSize={VIP_CHAR_SIZE}
                        showGrid={this.showGrid}
                        extents={this.hoveredExtents()}
                        selected={{ x: selected % VIP_BGMAP_CELLS, y: Math.floor(selected / VIP_BGMAP_CELLS) }}
                        onPick={(x, y) => {
                            const picked = Math.floor(y / VIP_CHAR_SIZE) * VIP_BGMAP_CELLS
                                + Math.floor(x / VIP_CHAR_SIZE);
                            this.selectCell(picked);
                        }}
                        onHover={point => this.light(point && {
                            kind: 'cell',
                            address: VIP_BGMAP_BASE + (this.segment * VIP_BGMAP_CELLS * VIP_BGMAP_CELLS
                                + Math.floor(point.y / VIP_CHAR_SIZE) * VIP_BGMAP_CELLS
                                + Math.floor(point.x / VIP_CHAR_SIZE)) * 2,
                        })}
                    />
                </div>
                {this.renderDisplayControls()}
            </div>
        </div>;
    }

    /** The segment itself: where it is, and what is reading it. */
    protected renderSegmentGroup(use: VipBgMapSegmentUse): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/segment', 'Segment')}</legend>
            <div className='vp-detail-fields'>
                {field(nls.localize('vueport/debug/panels/bgmaps/map', 'Map'), this.segment)}
                {field(
                    nls.localize('vueport/debug/panels/bgmaps/address', 'Address'),
                    hex(vipBgMapAddress(this.segment), 8)
                )}
            </div>
        </fieldset>;
    }

    /**
     * The worlds this segment is part of, and what each of them takes from
     * it: the cells of its map, the param table it steps its rows with, or
     * both — with a picture of what each one draws, the part of it coming
     * out of this segment in red and the rest faded.
     *
     * The group that gives way when the sidebar is taller than the panel —
     * it is the only one here whose length depends on the game, and a list
     * scrolling inside itself is better than the groups under it going off
     * the bottom.
     */
    protected renderUsedByGroup(): React.ReactNode {
        return <fieldset
            className='vp-inspector-group vp-grows vp-bgmaps-used-by'
            onClick={event => this.onUsedByClick(event)}
        >
            <legend>{nls.localize('vueport/debug/panels/bgmaps/usedBy', 'Used by')}</legend>
            {/* The previews scroll within the group rather than the sidebar
                scrolling around it: a segment half a dozen worlds read from
                would otherwise push the Display controls off the bottom. */}
            <div className='vp-scroll-body vp-scroll'>
                {this.usedBy.length === 0
                    ? <span className='hint'>{nls.localize(
                        'vueport/debug/panels/bgmaps/usedByNothing',
                        'No world being drawn reads this segment.'
                    )}</span>
                    : this.usedBy.map(world =>
                        // The row `field` draws and the world under it, both
                        // inside the button: the pointer picks out on the map
                        // what the row names, a click keeps that outline up,
                        // and the picture is part of what is being pointed
                        // at rather than something sitting beside it.
                        <button
                            type='button'
                            key={world.index}
                            className={'vp-used-by-world vp-bgmaps-used-by-world'
                                + (world.index === this.pinnedWorld ? ' selected' : '')}
                            aria-pressed={world.index === this.pinnedWorld}
                            title={nls.localize(
                                'vueport/debug/panels/bgmaps/usedByHint',
                                'Outline where this world reads from the map'
                            )}
                            onMouseEnter={() => this.setHoveredWorld(world.index)}
                            onMouseLeave={() => this.setHoveredWorld(undefined)}
                            onClick={() => this.togglePinnedWorld(world.index)}
                        >
                            <span className='vp-detail-field'>
                                <span className='label'>
                                    {nls.localize('vueport/debug/panels/bgmaps/world', 'World {0}', world.index)}
                                    <span className='hint'>{world.mode}</span>
                                </span>
                                <span className='value'>{world.takes}</span>
                            </span>
                            {world.image &&
                                <VipCanvas image={world.image} zoom={worldPreviewZoom(world.image)} />
                            }
                        </button>
                    )
                }
            </div>
        </fieldset>;
    }

    /** The one cell, at a size worth looking at. */
    protected renderCharacterGroup(preview: ImageData): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/character', 'Character')}</legend>
            <VipCanvas image={preview} zoom={PREVIEW_ZOOM} />
        </fieldset>;
    }

    /**
     * Everything one cell holds, in a grid three fields wide: where it is,
     * what it draws, and how.
     *
     * This is the group that gives way when the sidebar is taller than the
     * panel — the others are a few lines each and nothing in them can be cut
     * short.
     */
    protected renderCellGroup(cell: VipBgMapCell, address: number): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/cell', 'Cell')}</legend>
            <div className='vp-grid'>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/cell', 'Cell'),
                        numberInput(
                            this.selected, 0, VIP_BGMAP_CELLS * VIP_BGMAP_CELLS - 1,
                            value => this.selectCell(value)
                        )
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/address', 'Address'),
                        <input className='vp-input' readOnly value={hex(address, 8)} />,
                        undefined,
                        2
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/character', 'Character'),
                        numberInput(cell.char, 0, this.charCount() - 1, value => this.writeCell({ char: value }))
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/palette', 'Palette'),
                        <Select
                            value={String(cell.palette)}
                            onChange={next => this.writeCell({ palette: parseInt(next, 10) })}
                            options={VIP_BGMAP_PALETTES.map((unused, index) => ({
                                value: String(index),
                                label: `BG ${index}`,
                            }))}
                        />,
                        undefined,
                        2
                    )}
                </div>
                {/* A pair of switches needs more than a third of the group,
                    so it takes the row. */}
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/flip', 'Flip'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/horizontalFlip', 'Horizontal Flip'),
                                nls.localize('vueport/debug/panels/bgmaps/horizontal', 'H'),
                                cell.hFlip,
                                value => this.writeCell({ hFlip: value })
                            )}
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/verticalFlip', 'Vertical Flip'),
                                nls.localize('vueport/debug/panels/bgmaps/vertical', 'V'),
                                cell.vFlip,
                                value => this.writeCell({ vFlip: value })
                            )}
                        </div>,
                        undefined,
                        3
                    )}
                </div>
            </div>
        </fieldset>;
    }

    /**
     * What a VB Color draws the selected cell with: its Cell Color Attribute
     * (palette group, CHRSEL), its Cell Pixel Color Attribute (slot, PCE,
     * OPQ), and the CRAM palette the two come to — the cell's group above its
     * two palette bits, as the core resolves it.
     *
     * Only there while the game has switched color on; see `readVbcState`.
     * A bit that is set but switched off in CXCTRL gets a line under the
     * fields saying so, since what the cell holds and what it is drawn with
     * then part ways, and that is exactly what is easy to miss.
     */
    protected renderColorGroup(vbc: VbcState, cell: VipBgMapCell): React.ReactNode {
        const colors = this.cellColors;
        const pixels = this.cellPixelAttrs;
        if (!colors || !pixels) {
            return undefined;
        }
        const attr = decodeVcuColorAttr(colors[this.selected]);
        const pixel = decodeVcuPixelAttr(pixels.getUint16(this.selected * 2, true));

        // With CHRSEL and CCEN the character's entries stand in for both of
        // the cell's; until they have been read for this cell, nothing is
        // said about what they come to rather than something wrong.
        const byCharacter = attr.chrsel && vbc.ccen;
        const character = byCharacter && this.characterColor?.char === cell.char ? this.characterColor : undefined;
        const group = byCharacter ? character && decodeVcuColorAttr(character.color).group : attr.group;
        const palette = group === undefined ? undefined : vcuPlacementPalette(group, cell.palette);
        const drawnPixel = byCharacter ? character && decodeVcuPixelAttr(character.pixel) : pixel;

        const notes: string[] = [];
        if (attr.chrsel && !vbc.ccen) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/chrselWithoutCcen',
                'CHRSEL is set, but CXCTRL.CCEN is off: the cell\'s own attributes apply.'
            ));
        }
        if (byCharacter) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/chrselFromCharacter',
                'CHRSEL with CXCTRL.CCEN: palette group and pixel attribute come from Character {0}, not from the cell.',
                cell.char
            ));
        }
        if (drawnPixel?.enabled && !vbc.pcen) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/pceWithoutPcen',
                'PCE is set, but CXCTRL.PCEN is off: no Pixel Color Slot applies.'
            ));
        } else if (drawnPixel?.enabled) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/pixelSlotInUse',
                'Drawn through Pixel Color Slot {0}; its zero bytes fall back to the palette below.',
                drawnPixel.slot
            ));
        } else if (drawnPixel?.opaque) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/opqWithoutPce',
                'OPQ only has an effect while a Pixel Color Slot applies.'
            ));
        }
        if (vbc.wcen) {
            notes.push(nls.localize(
                'vueport/debug/panels/bgmaps/worldOffset',
                'CXCTRL.WCEN is on: each world adds its own palette offset to this.'
            ));
        }

        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/vbColor', 'VB Color')}</legend>
            <div className='vp-grid'>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/colorGroup', 'Group'),
                        numberInput(attr.group, 0, VCU_GROUP_MAX, value => this.writeColorAttr({ group: value })),
                        nls.localize(
                            'vueport/debug/panels/bgmaps/colorGroupHint',
                            'Cell Color Attribute bits 5-0: the CRAM palette is this times four plus the cell\'s palette'
                        )
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/colorFlags', 'Flags'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize(
                                    'vueport/debug/panels/bgmaps/chrsel',
                                    'Palette and Pixel Attribute From the Character (CHRSEL)'
                                ),
                                'CHRSEL',
                                attr.chrsel,
                                value => this.writeColorAttr({ chrsel: value })
                            )}
                        </div>,
                        undefined,
                        2
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/pixelSlot', 'Slot'),
                        numberInput(pixel.slot, 0, VCU_PIXEL_SLOT_COUNT - 1, value => this.writePixelAttr({ slot: value })),
                        nls.localize(
                            'vueport/debug/panels/bgmaps/pixelSlotHint',
                            'Cell Pixel Color Attribute bits 9-0: the Pixel Color Slot used with PCE'
                        )
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/colorFlags', 'Flags'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/pce', 'Use the Pixel Color Slot (PCE)'),
                                'PCE',
                                pixel.enabled,
                                value => this.writePixelAttr({ enabled: value })
                            )}
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/opq', 'Pixel Value 0 Is Opaque (OPQ)'),
                                'OPQ',
                                pixel.opaque,
                                value => this.writePixelAttr({ opaque: value })
                            )}
                        </div>,
                        undefined,
                        2
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/cramPalette', 'CRAM Palette'),
                        <div className='vp-bgmaps-cram-palette'>
                            <input className='vp-input' readOnly value={palette === undefined ? '…' : palette} />
                            {palette !== undefined && this.renderPaletteSwatches(palette)}
                        </div>,
                        nls.localize(
                            'vueport/debug/panels/bgmaps/cramPaletteHint',
                            'The palette the cell is drawn with: its group times four plus its palette'
                        ),
                        3
                    )}
                </div>
            </div>
            {notes.map(note => <div key={note} className='hint'>{note}</div>)}
        </fieldset>;
    }

    /**
     * The four colors of one CRAM palette, the way the VCU panel shows the
     * backdrop's: a number alone sends you counting into its CRAM grid.
     */
    protected renderPaletteSwatches(palette: number): React.ReactNode {
        const cram = this.cram;
        if (!cram) {
            return undefined;
        }
        const first = palette * VCU_CRAM_PALETTE_SIZE;
        return <span className='vp-vip-swatches'>
            {Array.from({ length: VCU_CRAM_PALETTE_SIZE }, (unused, index) => {
                const color = vcuRgb888(cram.getUint32((first + index) * VCU_CRAM_ENTRY_BYTES, true));
                return <span
                    key={index}
                    className='vp-vip-swatch'
                    style={{ backgroundColor: color.css }}
                    title={`CRAM ${hex(first + index, 3)} · ${color.css}`}
                />;
            })}
        </span>;
    }

    /**
     * How the map is drawn, under it rather than as a group in the sidebar —
     * the Objects panel's arrangement: the scale on a line of its own, the
     * switches under it in two columns, to the right.
     */
    /**
     * Write the segment out as a PNG, 512 pixels square, drawn as the panel
     * shows it — palettes, Generic Palette and Colorized as they are set —
     * but without the grid and the outlines, which are viewing aids.
     */
    protected async exportPng(): Promise<void> {
        if (this.exportFile && this.image) {
            await exportVipImage(this.exportFile, `bgmap-${this.segment}.png`, this.image);
        }
    }

    protected renderDisplayControls(): React.ReactNode {
        return <div className='vp-preview-controls'>
            <div className='vp-preview-controls-range'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/bgmaps/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={8}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            <div className='vp-preview-controls-switches'>
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/bgmaps/genericPalette', 'Generic Palette'),
                    nls.localize('vueport/debug/panels/bgmaps/genericPalette', 'Generic Palette'),
                    this.showGenericPalette,
                    value => this.setShowGenericPalette(value)
                )}
                {/* Only while the game has switched color on: without it
                    there is nothing to draw in but red. */}
                {this.vbc && this.renderToggle(
                    nls.localize('vueport/debug/panels/bgmaps/vbColorPreview', 'Colorized'),
                    nls.localize('vueport/debug/panels/bgmaps/vbColorPreview', 'Colorized'),
                    this.vbColorPreview,
                    value => this.setVbColorPreview(value),
                    nls.localize(
                        'vueport/debug/panels/bgmaps/vbColorPreviewHint',
                        'Draw in the colors the VB Color shows rather than the VIP\'s red'
                    )
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/bgmaps/showGrid', 'Show Grid'),
                    nls.localize('vueport/debug/panels/bgmaps/showGrid', 'Show Grid'),
                    this.showGrid,
                    value => { this.showGrid = this.remember('showGrid', value); this.update(); }
                )}
            </div>
            {this.exportFile &&
                <div className='vp-preview-controls-row'>
                    <button
                        type='button'
                        className='vp-button secondary'
                        title={nls.localize(
                            'vueport/debug/panels/bgmaps/exportPngHint',
                            'Save this segment as a PNG, at its own size and drawn as shown here')}
                        onClick={() => { this.exportPng().catch(() => undefined); }}
                    >
                        {nls.localize('vueport/debug/panels/bgmaps/exportPng', 'Export PNG')}
                    </button>
                </div>
            }
        </div>;
    }

    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips are, that is the only full name it has. `hint`,
     * where there is one, says more on hover than the name can.
     */
    protected renderToggle(
        label: string, name: string, value: boolean, onChange: (value: boolean) => void, hint?: string
    ): React.ReactNode {
        return <span className='vp-toggle' title={hint ?? label}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{name}</span>
        </span>;
    }
}
