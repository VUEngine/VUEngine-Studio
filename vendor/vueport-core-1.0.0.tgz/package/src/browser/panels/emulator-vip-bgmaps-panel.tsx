import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import { arrowKeysTaken, hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { field, numberInput, stacked } from './emulator-vip-detail';
import { VipCanvas } from './emulator-vip-canvas';
import { Sim } from '../core/vb-core';
import {
    decodeVipBgMapCell,
    decodeVipWorld,
    drawVipChar,
    encodeVipBgMapCell,
    forEachVipWorldPixel,
    sameVipBytes,
    VIP_BGMAP_BYTES,
    VIP_BGMAP_CELLS,
    VIP_BGMAP_COUNT,
    VIP_BGMAP_PALETTES,
    VIP_CHAR_COUNT,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SEGMENTS,
    VIP_CHAR_SIZE,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VIP_WORLD_BASE,
    VIP_WORLD_BLOCK_BYTES,
    VIP_WORLD_BYTES,
    VIP_WORLD_COUNT,
    VIP_WORLD_MODE_NAMES,
    vipBgMapAddress,
    VipBgMapCell,
    VipBgMapSegmentUse,
    vipBgMapSegmentUses,
    vipCharSegmentAddress,
    vipWorldSourceExtents,
    VipCharacters,
    VipEye,
    vipIntensitiesForRegister,
    VipIntensityWatcher,
    vipParamTableAddress,
    vipParamTableBytes,
    VipWorld,
    VipWorldMap,
    VipWorldMode,
    vipWorldSegments,
} from './emulator-vip-memory';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';
import Select from '../components/kit/Select';
import Switch from '../components/kit/Switch';

/**
 * How much the sidebar's single-cell preview is blown up: 8 source pixels at
 * 27 is the 216-pixel preview the sidebar is sized to hold, the same one the
 * Objects and Characters panels show.
 */
const PREVIEW_ZOOM = 27;

/**
 * How wide a world's preview under Used by is drawn, and how tall it is let
 * to become. Scaled to fit rather than stretched, since a world with the
 * wrong proportions is no longer a picture of where anything is — the
 * Characters panel sizes the maps in its own Used by the same way.
 */
const WORLD_PREVIEW_WIDTH = 208;
const WORLD_PREVIEW_MAX_HEIGHT = 192;

/** Previews are of one eye; the parallax between them is not the point here. */
const PREVIEW_EYE: VipEye = 'left';

/**
 * How far the parts of a world that come out of some other segment are faded
 * in its preview, and they lose the hardware's red with it.
 *
 * The same treatment, and the same factor, as the worlds around the selected
 * one in the Worlds panel and the characters a filter leaves out in the
 * Characters panel: the subject in red, what surrounds it in gray.
 */
const OTHER_SEGMENT_FACTOR = 0.18;

function worldPreviewZoom(image: ImageData): number {
    return Math.min(WORLD_PREVIEW_WIDTH / image.width, WORLD_PREVIEW_MAX_HEIGHT / image.height);
}

/** One line of Used by: which world, what it takes, and what it draws. */
interface UsedByWorld {
    index: number;
    /** BGMap, HBias or Affine — how it reads the map. */
    mode: string;
    /** Map, Params, or both. */
    takes: string;
    image?: ImageData;
}

/**
 * The fourteen BGMap segments, and the selected one rasterized as one 512x512
 * bitmap beside its fields — which inspect, and for the character, palette
 * and flips edit, one cell at a time.
 *
 * Three columns, the shape the Worlds panel has: the segments as tiles, the
 * fields of the one picked, and the map itself. Reads the selected segment's
 * cells plus the character memory they reference each refresh, and
 * re-rasterizes only when the pixels or the shading actually changed — see
 * the Characters panel, whose caching this mirrors. The tiles cost one more
 * read, of world attribute memory, since what a segment is being used for is
 * a fact about the worlds pointing at it rather than about the segment
 * itself.
 */
export class BgMapsPanel extends Panel {

    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[] = [];
    protected cells?: Uint8Array;
    /** The segment being shown, and those the Used by previews read from. */
    protected bgMapSegments: (Uint8Array | undefined)[] = [];
    /** The param tables of the worlds under Used by, by world index. */
    protected paramTables: (Uint8Array | undefined)[] = [];
    /** What Used by shows, rebuilt when the maps or the worlds move. */
    protected usedBy: UsedByWorld[] = [];
    protected worldBytes?: Uint8Array;
    protected segment = 0;
    protected selected = 0;
    protected zoom = this.remembered('zoom', 1);
    protected showGrid = this.remembered('showGrid', false);
    /**
     * Whether the map is shaded with an even ramp instead of the palette
     * registers the game has set up. Off: the previews resolve the brightness
     * registers the way the core does, so the real palettes look like the
     * picture on screen. The even ramp is for reading the tile data itself.
     */
    protected showGenericPalette = this.remembered('showGenericPalette', false);
    /**
     * The world whose read area is outlined on the map: the one the pointer
     * is over in Used by, or — once a row has been clicked — the one pinned
     * there. Hovering another previews it and leaving falls back to the
     * pinned one. Both are dropped when another segment is picked, since the
     * outline is about the map being shown.
     */
    protected hoveredWorld?: number;
    protected pinnedWorld?: number;

    protected image?: ImageData;
    protected dirty = true;
    protected readonly intensityWatcher = new VipIntensityWatcher();

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.VIP_BGMAPS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_BGMAPS);
        // The three columns each scroll on their own, so the panel's own
        // scrolling is switched off and the layout is hung on this class,
        // which the Worlds panel wears too — see the stylesheet.
        this.addClass('vp-vip-panel');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.registers = undefined;
            this.charSegments = [];
            this.cells = undefined;
            this.bgMapSegments = [];
            this.paramTables = [];
            this.worldBytes = undefined;
            this.usedBy = [];
            this.image = undefined;
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));

            const segments = await Promise.all(VIP_CHAR_SEGMENTS.map(
                (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
            ));
            segments.forEach((buffer, index) => {
                const bytes = new Uint8Array(buffer);
                if (!sameVipBytes(bytes, this.charSegments[index])) {
                    this.charSegments[index] = bytes;
                    this.dirty = true;
                }
            });

            const worldBytes = new Uint8Array(await sim.readMemory(VIP_WORLD_BASE, VIP_WORLD_BLOCK_BYTES));
            // The map itself does not depend on the worlds, so this has a
            // flag of its own: what it moves is the Used by list beside it.
            const worldsMoved = !sameVipBytes(worldBytes, this.worldBytes);
            this.worldBytes = worldBytes;

            await this.readMaps(sim);

            if (this.intensityWatcher.changed(this.registers)) {
                this.dirty = true;
            }
            this.error = undefined;

            if (this.dirty || worldsMoved) {
                this.usedBy = this.buildUsedBy(this.registers);
            }
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        if (this.dirty && this.registers) {
            this.image = this.rasterize(this.registers);
            this.dirty = false;
        }
        this.update();
    }

    /**
     * The BGMap memory the panel draws from: the segment being shown, and
     * the maps and param tables of the worlds listed under Used by, which
     * their previews are made of.
     *
     * A world's map can span segments other than the one being looked at, so
     * this is the union rather than the one segment — but still only what
     * the list needs, rather than all fourteen every poll.
     */
    protected async readMaps(sim: Sim): Promise<void> {
        const worlds = this.usedByWorlds();
        const needed = [...new Set([
            this.segment,
            ...worlds.flatMap(world => vipWorldSegments(world)),
        ])];

        const maps = await Promise.all(needed.map(
            segment => sim.readMemory(vipBgMapAddress(segment), VIP_BGMAP_BYTES)));
        const segments: (Uint8Array | undefined)[] = [];
        needed.forEach((segment, index) => {
            const bytes = new Uint8Array(maps[index]);
            if (!sameVipBytes(bytes, this.bgMapSegments[segment])) {
                this.dirty = true;
            }
            segments[segment] = bytes;
        });
        this.bgMapSegments = segments;
        this.cells = segments[this.segment];

        const tables: (Uint8Array | undefined)[] = [];
        await Promise.all(worlds.map(async world => {
            const length = vipParamTableBytes(world);
            if (length > 0) {
                tables[world.index] = new Uint8Array(
                    await sim.readMemory(vipParamTableAddress(world.param), length));
            }
        }));
        this.paramTables = tables;
    }

    protected setSegment(segment: number): void {
        if (Number.isNaN(segment)) {
            return;
        }
        this.segment = Math.min(VIP_BGMAP_COUNT - 1, Math.max(0, segment));
        // The outline was about the map being left behind.
        this.hoveredWorld = undefined;
        this.pinnedWorld = undefined;
        // Selected cell index is left as-is: it stays valid across a segment
        // switch (every map is 64x64), and keeping it lets you compare the
        // same position across maps.
        this.dirty = true;
        this.refresh();
    }

    protected selectCell(cell: number): void {
        if (Number.isNaN(cell)) {
            return;
        }
        const count = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;
        this.selected = Math.min(count - 1, Math.max(0, cell));
        this.update();
    }

    protected setShowGenericPalette(value: boolean): void {
        this.showGenericPalette = this.remember('showGenericPalette', value);
        this.dirty = true;
        this.refresh();
    }

    /**
     * Patch the selected cell — its character and/or its palette/flip bits —
     * and write the result back to VRAM. Callers are trusted to have already
     * clamped `char` to a valid character index; palette and the flip flags
     * come from a bounded dropdown and checkboxes respectively, so need no
     * clamping of their own.
     */
    protected async writeCell(patch: Partial<VipBgMapCell>): Promise<void> {
        const sim = this.source.sim;
        const cells = this.cells;
        if (!sim || !cells) {
            return;
        }

        const offset = this.selected * 2;
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);
        const current = decodeVipBgMapCell(view.getUint16(offset, true));
        const raw = encodeVipBgMapCell({ ...current, ...patch });

        await this.source.write(vipBgMapAddress(this.segment) + offset, [raw & 0xff, raw >> 8]);

        this.dirty = true;
        await this.refresh();
    }

    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][] {
        return this.showGenericPalette
            ? [0, 1, 2, 3].map(() => VIP_GENERIC_PALETTE_INTENSITIES)
            : VIP_BGMAP_PALETTES.map(register => vipIntensitiesForRegister(registers, register));
    }

    protected rasterize(registers: DataView): ImageData | undefined {
        const cells = this.cells;
        if (!cells || this.charSegments.length === 0) {
            return undefined;
        }
        const characters = new VipCharacters(this.charSegments);
        const palettes = this.palettes(registers);
        const size = VIP_BGMAP_CELLS * VIP_CHAR_SIZE;
        const pixels = new Uint8ClampedArray(size * size * 4);
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);

        for (let row = 0; row < VIP_BGMAP_CELLS; row++) {
            for (let column = 0; column < VIP_BGMAP_CELLS; column++) {
                const cell = decodeVipBgMapCell(view.getUint16((row * VIP_BGMAP_CELLS + column) * 2, true));
                drawVipChar(
                    pixels,
                    size,
                    column * VIP_CHAR_SIZE,
                    row * VIP_CHAR_SIZE,
                    characters,
                    cell.char,
                    palettes[cell.palette],
                    cell.hFlip,
                    cell.vFlip
                );
            }
        }
        return new ImageData(pixels, size, size);
    }

    /**
     * What the worlds currently being drawn do with each segment: which of
     * them read their map out of it, and whose param table is sitting in it.
     * A segment under neither is free.
     */
    protected segmentUses(): VipBgMapSegmentUse[] {
        return vipBgMapSegmentUses(this.worlds());
    }

    /** Every world, decoded out of the last read of world attribute memory. */
    protected worlds(): VipWorld[] {
        const bytes = this.worldBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return Array.from({ length: VIP_WORLD_COUNT }, (unused, index) =>
            decodeVipWorld(view, index, index * VIP_WORLD_BYTES));
    }

    /** The worlds Used by lists: those reading this segment, or kept in it. */
    protected usedByWorlds(): VipWorld[] {
        const use = this.segmentUses()[this.segment];
        if (!use) {
            return [];
        }
        const listed = new Set([...use.worlds, ...use.params]);
        return this.worlds()
            .filter(world => listed.has(world.index))
            .sort((a, b) => b.index - a.index);
    }

    /**
     * What Used by shows: a line per world, and under it a picture of what
     * that world draws, with the pixels it reads out of this segment picked
     * out.
     *
     * Rebuilt here rather than while rendering, because the panel re-renders
     * whenever the pointer moves over the list and these are rasterized.
     */
    protected buildUsedBy(registers: DataView): UsedByWorld[] {
        const use = this.segmentUses()[this.segment] ?? { worlds: [], params: [] };
        return this.usedByWorlds().map(world => ({
            index: world.index,
            mode: VIP_WORLD_MODE_NAMES[world.mode],
            takes: [
                use.worlds.includes(world.index) && nls.localize('vueport/debug/panels/bgmaps/asMap', 'Map'),
                use.params.includes(world.index) && nls.localize('vueport/debug/panels/bgmaps/asParams', 'Params'),
            ].filter(Boolean).join(', '),
            image: this.drawWorldPreview(registers, world),
        }));
    }

    /**
     * One world as it is actually drawn, with the part of it that comes out
     * of this segment picked out — red for this segment, faded gray for
     * whatever the world reads from its other ones.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one. The three properties that place the finished
     * rectangle on the screen — GX, GY, GP — are the only ones dropped, since
     * the preview is the rectangle. Copied in spirit from the Characters
     * panel, which marks the selected character in its own Used by the same
     * way.
     */
    protected drawWorldPreview(registers: DataView, world: VipWorld): ImageData | undefined {
        const width = Math.min(world.w + 1, VIP_FRAME_BUFFER_WIDTH);
        const height = Math.min(world.h + 1, VIP_FRAME_BUFFER_HEIGHT);
        if (world.mode === VipWorldMode.OBJECT || width <= 0 || height <= 0) {
            return undefined;
        }
        // Drawn no finer than it is shown: sampling every second pixel is
        // less work than drawing all of them for the browser to throw away.
        const stride = Math.max(1, Math.ceil(width / WORLD_PREVIEW_WIDTH));
        const previewWidth = Math.ceil(width / stride);
        const previewHeight = Math.ceil(height / stride);
        const pixels = new Uint8ClampedArray(previewWidth * previewHeight * 4);

        const map = new VipWorldMap(world, this.bgMapSegments, new VipCharacters(this.charSegments));
        const palettes = this.palettes(registers);
        const params = this.paramTables[world.index];
        const view = params && new DataView(params.buffer, params.byteOffset, params.byteLength);
        forEachVipWorldPixel(
            { ...world, gx: 0, gy: 0, gp: 0 }, width, height, PREVIEW_EYE, view,
            (x, y, sourceX, sourceY) => {
                if (x % stride !== 0 || y % stride !== 0) {
                    return;
                }
                const offset = ((y / stride) * previewWidth + x / stride) * 4;
                const intensity = map.intensity(sourceX, sourceY, palettes);
                if (map.segmentAt(sourceX, sourceY) === this.segment) {
                    // Red, the color the hardware emits, for the part of the
                    // world this segment is: it is the subject here.
                    pixels[offset] = intensity;
                } else {
                    const gray = Math.round(intensity * OTHER_SEGMENT_FACTOR);
                    pixels[offset] = gray;
                    pixels[offset + 1] = gray;
                    pixels[offset + 2] = gray;
                }
                pixels[offset + 3] = 255;
            }
        );
        return new ImageData(pixels, previewWidth, previewHeight);
    }

    /**
     * The area the hovered world reads out of this segment, for the outline
     * over the map, or undefined while nothing is hovered.
     */
    protected hoveredExtents(): { x: number, y: number, width: number, height: number } | undefined {
        const world = this.worlds()[this.hoveredWorld ?? this.pinnedWorld ?? -1];
        return world && vipWorldSourceExtents(world, this.segment);
    }

    protected setHoveredWorld(index: number | undefined): void {
        if (this.hoveredWorld !== index) {
            this.hoveredWorld = index;
            this.update();
        }
    }

    /** Keep the outline of one world up, or take it down again. */
    protected togglePinnedWorld(index: number): void {
        this.pinnedWorld = this.pinnedWorld === index ? undefined : index;
        this.update();
    }

    /**
     * The fourteen segments as tiles: the number and the worlds reading it on
     * one line, its address and — where one sits in it — Param under them.
     *
     * A column of its own rather than a table above the fields, so that
     * moving to the next segment does not mean leaving the one being read.
     */
    protected renderTiles(uses: VipBgMapSegmentUse[]): React.ReactNode {
        // Focusable in its own right: the panel's arrow keys walk the cells
        // of the map, and in here they walk the segments instead.
        return <div
            className='vp-tiles vp-scroll'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps')}
            onKeyDown={event => this.onTilesKey(event)}
        >
            {uses.map((use, segment) => {
                const used = use.worlds.length > 0 || use.params.length > 0;
                return <button
                    type='button'
                    key={segment}
                    className={`vp-tile${used ? '' : ' inactive'}`
                        + `${segment === this.segment ? ' selected' : ''}`}
                    aria-pressed={segment === this.segment}
                    tabIndex={-1}
                    title={BgMapsPanel.segmentTitle(use)}
                    onClick={() => this.setSegment(segment)}
                >
                    <span className='vp-tile-index'>{segment}</span>
                    <span className='vp-tile-mark'>{use.worlds.length || '\u2013'}</span>
                    <span className='vp-tile-note vp-bgmaps-tile-address'>
                        {hex(vipBgMapAddress(segment), 8)}
                    </span>
                    {use.params.length > 0 &&
                        <span className='vp-tile-flag'>
                            {nls.localize('vueport/debug/panels/bgmaps/params', 'Params')}
                        </span>
                    }
                </button>;
            })}
        </div>;
    }

    /** What a tile's count stands for, spelled out on hover. */
    protected static segmentTitle(use: VipBgMapSegmentUse): string | undefined {
        const lines = [];
        if (use.worlds.length) {
            lines.push(nls.localize(
                'vueport/debug/panels/bgmaps/segmentWorldsHint', 'Worlds whose map this segment is part of'
            ) + `: ${use.worlds.join(', ')}`);
        }
        if (use.params.length) {
            lines.push(nls.localize(
                'vueport/debug/panels/bgmaps/segmentParamsHint', 'Worlds whose param table this segment holds'
            ) + `: ${use.params.join(', ')}`);
        }
        return lines.length ? lines.join('\n') : undefined;
    }

    /**
     * Walk the segments with the keyboard, from inside the tiles.
     *
     * Stopped rather than only defaulted: the emulator listens for keys on
     * the node this panel sits inside and would otherwise read an arrow as
     * the D-pad and move the game.
     */
    protected onTilesKey(event: React.KeyboardEvent): void {
        const steps: Record<string, number> = {
            ArrowUp: -1, ArrowLeft: -1, ArrowDown: 1, ArrowRight: 1,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.setSegment(home ? 0 : end ? VIP_BGMAP_COUNT - 1 : this.segment + step);
        this.revealSegment();
    }

    /**
     * Walk the cells of the map with the keyboard, from anywhere else in the
     * panel: a cell at a time sideways, a row at a time up and down, a
     * screenful with Page keys, and the ends of the map with Home and End.
     */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        const steps: Record<string, number> = {
            ArrowLeft: -1,
            ArrowRight: 1,
            ArrowUp: -VIP_BGMAP_CELLS,
            ArrowDown: VIP_BGMAP_CELLS,
            PageUp: -VIP_BGMAP_CELLS * 8,
            PageDown: VIP_BGMAP_CELLS * 8,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        const cells = VIP_BGMAP_CELLS * VIP_BGMAP_CELLS;
        this.selectCell(home ? 0 : end ? cells - 1 : this.selected + step);
        this.revealCell();
    }

    /** Keep the picked segment's tile in view, and the ring on it. */
    protected revealSegment(): void {
        requestAnimationFrame(() => {
            const tile = this.node.querySelector<HTMLElement>('.vp-tile.selected');
            tile?.scrollIntoView({ block: 'nearest' });
            tile?.focus({ preventScroll: true });
        });
    }

    /** Keep the picked cell in view as the keys walk off the visible map. */
    protected revealCell(): void {
        requestAnimationFrame(() => this.node
            .querySelector('.vp-canvas-selection')
            ?.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
    }

    /** Just the selected cell's character, for the sidebar preview. */
    protected rasterizePreview(characters: VipCharacters, palettes: number[][], cell: VipBgMapCell): ImageData {
        const pixels = new Uint8ClampedArray(VIP_CHAR_SIZE * VIP_CHAR_SIZE * 4);
        drawVipChar(pixels, VIP_CHAR_SIZE, 0, 0, characters, cell.char, palettes[cell.palette], cell.hFlip, cell.vFlip);
        return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        if (!this.registers) {
            return (
                <EmptyContainer
                    title={nls.localize(
                        'vueport/debug/panels/general/notRunning',
                        'The emulator is not running.',
                    )}
                    icon={<Plug size={32} />}
                />
            );
        }
        if (!this.image || !this.cells) {
            return <div className='vp-panel-empty'>
                {nls.localize('vueport/debug/panels/bgmaps/reading', 'Reading VIP memory…')}
            </div>;
        }

        const registers = this.registers;
        const cells = this.cells;
        const selected = this.selected;
        const view = new DataView(cells.buffer, cells.byteOffset, cells.byteLength);
        const cell = decodeVipBgMapCell(view.getUint16(selected * 2, true));
        const address = vipBgMapAddress(this.segment) + selected * 2;

        const characters = new VipCharacters(this.charSegments);
        const palettes = this.palettes(registers);
        const preview = this.rasterizePreview(characters, palettes, cell);

        const uses = this.segmentUses();
        const use = uses[this.segment] ?? { worlds: [], params: [] };

        // Focusable, and the arrow keys are read here rather than on the map:
        // wherever focus has landed in the panel they walk its cells. The
        // tiles are in the tab order in their own right and so keep their own
        // handler, which walks the segments; see `arrowKeysTaken`.
        return <div
            className='vp-columns'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/bgmaps/title', 'BGMaps')}
            onKeyDown={event => this.onPanelKey(event)}
        >
            {this.renderTiles(uses)}
            <div className='vp-sidebar vp-scroll'>
                {this.renderSegmentGroup(use)}
                {this.renderCharacterGroup(preview)}
                {this.renderCellGroup(cell, address)}
                {this.renderUsedByGroup()}
                {this.renderDisplayGroup()}
            </div>
            <div className='vp-preview vp-scroll'>
                <VipCanvas
                    image={this.image}
                    zoom={this.zoom}
                    cellSize={VIP_CHAR_SIZE}
                    showGrid={this.showGrid}
                    extents={this.hoveredExtents()}
                    selected={{ x: selected % VIP_BGMAP_CELLS, y: Math.floor(selected / VIP_BGMAP_CELLS) }}
                    onPick={(x, y) => {
                        const picked = Math.floor(y / VIP_CHAR_SIZE) * VIP_BGMAP_CELLS
                            + Math.floor(x / VIP_CHAR_SIZE);
                        this.selectCell(picked);
                    }}
                />
            </div>
        </div>;
    }

    /** The segment itself: where it is, and what is reading it. */
    protected renderSegmentGroup(use: VipBgMapSegmentUse): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/segment', 'Segment')}</legend>
            <div className='vp-detail-fields'>
                {field(nls.localize('vueport/debug/panels/bgmaps/map', 'Map'), this.segment)}
                {field(
                    nls.localize('vueport/debug/panels/bgmaps/address', 'Address'),
                    hex(vipBgMapAddress(this.segment), 8)
                )}
            </div>
        </fieldset>;
    }

    /**
     * The worlds this segment is part of, and what each of them takes from
     * it: the cells of its map, the param table it steps its rows with, or
     * both — with a picture of what each one draws, the part of it coming
     * out of this segment in red and the rest faded.
     *
     * The group that gives way when the sidebar is taller than the panel —
     * it is the only one here whose length depends on the game, and a list
     * scrolling inside itself is better than the groups under it going off
     * the bottom.
     */
    protected renderUsedByGroup(): React.ReactNode {
        return <fieldset className='vp-inspector-group vp-grows vp-bgmaps-used-by'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/usedBy', 'Used by')}</legend>
            {/* The previews scroll within the group rather than the sidebar
                scrolling around it: a segment half a dozen worlds read from
                would otherwise push the Display controls off the bottom. */}
            <div className='vp-scroll-body vp-scroll'>
                {this.usedBy.length === 0
                    ? <span className='hint'>{nls.localize(
                        'vueport/debug/panels/bgmaps/usedByNothing',
                        'No world being drawn reads this segment.'
                    )}</span>
                    : this.usedBy.map(world =>
                        // The row `field` draws and the world under it, both
                        // inside the button: the pointer picks out on the map
                        // what the row names, a click keeps that outline up,
                        // and the picture is part of what is being pointed
                        // at rather than something sitting beside it.
                        <button
                            type='button'
                            key={world.index}
                            className={'vp-used-by-world vp-bgmaps-used-by-world'
                                + (world.index === this.pinnedWorld ? ' selected' : '')}
                            aria-pressed={world.index === this.pinnedWorld}
                            title={nls.localize(
                                'vueport/debug/panels/bgmaps/usedByHint',
                                'Outline where this world reads from the map'
                            )}
                            onMouseEnter={() => this.setHoveredWorld(world.index)}
                            onMouseLeave={() => this.setHoveredWorld(undefined)}
                            onClick={() => this.togglePinnedWorld(world.index)}
                        >
                            <span className='vp-detail-field'>
                                <span className='label'>
                                    {nls.localize('vueport/debug/panels/bgmaps/world', 'World {0}', world.index)}
                                    <span className='hint'>{world.mode}</span>
                                </span>
                                <span className='value'>{world.takes}</span>
                            </span>
                            {world.image &&
                                <VipCanvas image={world.image} zoom={worldPreviewZoom(world.image)} />
                            }
                        </button>
                    )
                }
            </div>
        </fieldset>;
    }

    /** The one cell, at a size worth looking at. */
    protected renderCharacterGroup(preview: ImageData): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/character', 'Character')}</legend>
            <VipCanvas image={preview} zoom={PREVIEW_ZOOM} />
        </fieldset>;
    }

    /**
     * Everything one cell holds, in a grid three fields wide: where it is,
     * what it draws, and how.
     *
     * This is the group that gives way when the sidebar is taller than the
     * panel — the others are a few lines each and nothing in them can be cut
     * short.
     */
    protected renderCellGroup(cell: VipBgMapCell, address: number): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/cell', 'Cell')}</legend>
            <div className='vp-grid'>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/cell', 'Cell'),
                        numberInput(
                            this.selected, 0, VIP_BGMAP_CELLS * VIP_BGMAP_CELLS - 1,
                            value => this.selectCell(value)
                        )
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/address', 'Address'),
                        <input className='vp-input' readOnly value={hex(address, 8)} />,
                        undefined,
                        2
                    )}
                </div>
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/character', 'Character'),
                        numberInput(cell.char, 0, VIP_CHAR_COUNT - 1, value => this.writeCell({ char: value }))
                    )}
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/palette', 'Palette'),
                        <Select
                            value={String(cell.palette)}
                            onChange={next => this.writeCell({ palette: parseInt(next, 10) })}
                            options={VIP_BGMAP_PALETTES.map((unused, index) => ({
                                value: String(index),
                                label: `BG ${index}`,
                            }))}
                        />,
                        undefined,
                        2
                    )}
                </div>
                {/* A pair of switches needs more than a third of the group,
                    so it takes the row. */}
                <div className='vp-grid-row'>
                    {stacked(
                        nls.localize('vueport/debug/panels/bgmaps/flip', 'Flip'),
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/horizontalFlip', 'Horizontal Flip'),
                                nls.localize('vueport/debug/panels/bgmaps/horizontal', 'H'),
                                cell.hFlip,
                                value => this.writeCell({ hFlip: value })
                            )}
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/bgmaps/verticalFlip', 'Vertical Flip'),
                                nls.localize('vueport/debug/panels/bgmaps/vertical', 'V'),
                                cell.vFlip,
                                value => this.writeCell({ vFlip: value })
                            )}
                        </div>,
                        undefined,
                        3
                    )}
                </div>
            </div>
        </fieldset>;
    }

    protected renderDisplayGroup(): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/bgmaps/display', 'Display')}</legend>
            {/* Name, track and readout as three columns, the way the
                Characters and Worlds panels lay their sliders out. */}
            <div className='vp-ranges'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/bgmaps/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={8}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            {this.renderToggle(
                nls.localize('vueport/debug/panels/bgmaps/showGrid', 'Show Grid'),
                nls.localize('vueport/debug/panels/bgmaps/showGrid', 'Show Grid'),
                this.showGrid,
                value => { this.showGrid = this.remember('showGrid', value); this.update(); }
            )}
            {this.renderToggle(
                nls.localize('vueport/debug/panels/bgmaps/genericPalette', 'Generic Palette'),
                nls.localize('vueport/debug/panels/bgmaps/genericPalette', 'Generic Palette'),
                this.showGenericPalette,
                value => this.setShowGenericPalette(value)
            )}
        </fieldset>;
    }

    /**
     * A setting that is on or off, as a switch with its name beside it.
     *
     * `label` names it for a screen reader — where the drawn name is a
     * letter, as the flips are, that is the only full name it has.
     */
    protected renderToggle(
        label: string, name: string, value: boolean, onChange: (value: boolean) => void
    ): React.ReactNode {
        return <span className='vp-toggle' title={label}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{name}</span>
        </span>;
    }
}
