import { Sim } from '../core/vb-core';
import {
    sameVipBytes,
    VIP_BGMAP_BYTES,
    VIP_BGMAP_COUNT,
    VIP_WORLD_COUNT,
    vipBgMapAddress,
    vipParamTableAddress,
    vipParamTableBytes,
    VipWorld,
    VipWorldMode,
    vipOverplaneSegment,
} from './emulator-vip-memory';

/**
 * How far the worlds around the one being looked at are faded in a Context
 * preview, and they lose the hardware's red with it.
 *
 * The same treatment, and the same factor, as the characters a filter leaves
 * out in the Characters panel: faint enough that the subject reads as the
 * subject, strong enough that what surrounds it is still legible. Gray as
 * well as faint because fading alone would put a neighbouring world and a
 * dark part of the subject on one scale.
 */
export const VIP_CONTEXT_FACTOR = 0.18;

/**
 * The BGMap segments and param tables a set of worlds maps from.
 *
 * Shared by the Worlds and Objects panels, whose Context previews both draw
 * the frame's worlds and so both have to read this much of VRAM. OBJECT
 * worlds are passed over: they draw from OAM, which each panel reads itself.
 */
export class VipWorldSources {

    /** Indexed by absolute BGMap segment; only the ones the worlds span are read. */
    bgMapSegments: (Uint8Array | undefined)[] = [];
    /** The H-bias or Affine tables of the worlds, by world index. */
    paramTables: (Uint8Array | undefined)[] = [];

    clear(): void {
        this.bgMapSegments = [];
        this.paramTables = [];
    }

    /**
     * Read what the given worlds map from, and answer whether any of it
     * differs from the last read.
     */
    async read(sim: Sim, sources: readonly VipWorld[]): Promise<boolean> {
        const worlds = sources.filter(world => world.mode !== VipWorldMode.OBJECT);
        let changed = false;

        // The union over the worlds, since several of them often map from
        // the same segment and none of them is worth reading twice.
        const needed = [...new Set(worlds.flatMap(world => VipWorldSources.worldSegments(world)))];
        const maps = await Promise.all(needed.map(segment => sim.readMemory(vipBgMapAddress(segment), VIP_BGMAP_BYTES)));
        const bgMapSegments: (Uint8Array | undefined)[] = [];
        needed.forEach((segment, index) => {
            const bytes = new Uint8Array(maps[index]);
            if (!sameVipBytes(bytes, this.bgMapSegments[segment])) {
                changed = true;
            }
            bgMapSegments[segment] = bytes;
        });
        this.bgMapSegments = bgMapSegments;

        const tables: (Uint8Array | undefined)[] = [];
        await Promise.all(worlds.map(async world => {
            const length = vipParamTableBytes(world);
            if (length > 0) {
                tables[world.index] = new Uint8Array(
                    await sim.readMemory(vipParamTableAddress(world.param), length)
                );
            }
        }));
        if (!VipWorldSources.sameParamTables(tables, this.paramTables)) {
            changed = true;
        }
        this.paramTables = tables;

        return changed;
    }

    /** One world's param table, as a view, or undefined when none was read. */
    params(index: number): DataView | undefined {
        const bytes = this.paramTables[index];
        return bytes ? new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength) : undefined;
    }

    /** Whether two reads of the param tables agree, absent tables included. */
    protected static sameParamTables(
        a: ReadonlyArray<Uint8Array | undefined>, b: ReadonlyArray<Uint8Array | undefined>
    ): boolean {
        for (let index = 0; index < VIP_WORLD_COUNT; index++) {
            if (!a[index] !== !b[index]) {
                return false;
            }
            if (a[index] && !sameVipBytes(a[index], b[index])) {
                return false;
            }
        }
        return true;
    }

    /**
     * The BGMap segments a world spans, in the order it lays them out: scx
     * across then scy down, from its base segment.
     *
     * Segments past the last real one are dropped rather than read — 14 and 15
     * are where world attribute and object memory live, not map data.
     */
    protected static worldSegments(world: VipWorld): number[] {
        const count = Math.min(world.scx * world.scy, VIP_BGMAP_COUNT);
        const segments = new Set<number>();
        for (let index = 0; index < count; index++) {
            const segment = (world.bgMap + index) & 0x0f;
            if (segment < VIP_BGMAP_COUNT) {
                segments.add(segment);
            }
        }
        // And the overplane cell's, which can lie outside the map.
        if (world.overplane && vipOverplaneSegment(world) < VIP_BGMAP_COUNT) {
            segments.add(vipOverplaneSegment(world));
        }
        return [...segments];
    }
}
