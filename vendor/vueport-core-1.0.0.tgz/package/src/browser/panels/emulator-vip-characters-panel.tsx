import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import { arrowKeysTaken, hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { VipCanvas } from './emulator-vip-canvas';
import { control, field, numberInput } from './emulator-vip-detail';
import {
    decodeVipWorld,
    drawVipChar,
    sameVipBytes,
    VIP_BGMAP_BYTES,
    VIP_BGMAP_CELLS,
    VIP_BGMAP_COUNT,
    VIP_CHAR_BYTES,
    VIP_CHAR_COUNT,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SEGMENTS,
    VIP_CHAR_SIZE,
    VIP_CHARS_PER_SEGMENT,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_OAM_BASE,
    VIP_OAM_BLOCK_BYTES,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VIP_WORLD_BASE,
    VIP_WORLD_BLOCK_BYTES,
    VIP_WORLD_BYTES,
    VIP_WORLD_COUNT,
    vipBgMapAddress,
    vipCharMirrorAddress,
    vipCharSegmentAddress,
    VipCharacters,
    vipCharacterUsage,
    VipCharacterUsage,
    vipChangedCharacters,
    vipDrawnWorlds,
    VIP_BGMAP_BASE,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    forEachVipWorldPixel,
    vipParamTableAddress,
    vipParamTableBytes,
    vipWorldMapSegment,
    VipEye,
    VipWorld,
    VipWorldMap,
    VipWorldMode,
    vipWorldSegments,
} from './emulator-vip-memory';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';
import RadioSelect from '../components/kit/RadioSelect';
import Switch from '../components/kit/Switch';
import { Sim } from '../core/vb-core';

const CHARS_PER_ROW_OPTIONS = [8, 16, 32];
const DEFAULT_CHARS_PER_ROW = 16;

/**
 * Scale of the single-character preview, source pixels to screen pixels.
 *
 * The eight-pixel character comes out at 216 across, which is what the sidebar
 * is laid out to: the preview sets the width and everything under it lines up
 * with its edges. See `--vp-characters-sidebar` in the stylesheet, which
 * is the same number said where the layout can read it.
 */
const PREVIEW_ZOOM = 27;

/**
 * How much room a map in Used by may take: the width of the sidebar, and no
 * more height than that leaves it still being a thumbnail.
 */
const MAP_PREVIEW_WIDTH = VIP_CHAR_SIZE * PREVIEW_ZOOM;
const MAP_PREVIEW_MAX_HEIGHT = 256;

/**
 * Which eye a world preview is drawn for.
 *
 * The two differ by parallax, which moves a world sideways by a few pixels
 * and changes nothing about which characters it draws. One of them has to be
 * picked, and the left is the one the Worlds panel shows first.
 */
const PREVIEW_EYE: VipEye = 'left';

/**
 * What to draw a map at so it fills the width without growing past that
 * height.
 *
 * Fractional on purpose: a map is one pixel to the cell, so a world 64 cells
 * across is scaled by 3.375 to reach the width, and holding it to whole
 * numbers would leave a fifth of the column empty. A map too tall for the
 * width — a world several segments high — is fitted to the height instead
 * rather than stretched, since a map with the wrong proportions is no longer
 * a picture of where anything is.
 */
function mapPreviewZoom(image: ImageData): number {
    return Math.min(MAP_PREVIEW_WIDTH / image.width, MAP_PREVIEW_MAX_HEIGHT / image.height);
}

/**
 * Which characters the atlas draws.
 *
 * `used` and `changed` blank the rest rather than closing the gaps they leave:
 * where a character sits in the sheet is its index, and a filter that reflowed
 * the grid would answer "which characters are these" with a different number
 * every time something moved.
 */
type CharacterFilter = 'all' | 'used' | 'changed';

const CHARACTER_FILTERS: CharacterFilter[] = ['all', 'used', 'changed'];

/**
 * A character the filter leaves out: ghosted rather than blanked, and gray
 * rather than the hardware's red.
 *
 * Faded far enough down that the sheet still reads as the handful of
 * characters the filter kept, but not so far that the rest of it disappears —
 * an empty square says a character is blank, which is a fact about character
 * memory and not about the filter. Gray as well as faint because fading alone
 * puts a filtered-out character and a dark kept one on one scale, and the
 * sheet then reads as a single picture with a gradient across it; without the
 * color they are two kinds of thing, which is what they are.
 */
const FILTERED_FACTOR = 0.18;
const FILTERED_INTENSITIES = VIP_GENERIC_PALETTE_INTENSITIES.map(
    intensity => Math.round(intensity * FILTERED_FACTOR));

/** How a character is shaded in the atlas. See {@link CharactersPanel#shadingFor}. */
interface CharacterShading {
    intensities: number[];
    /** Whether to take the color out of it once it is drawn. */
    gray?: boolean;
}

/**
 * How long a character stays marked as changed, in milliseconds.
 *
 * The panel polls a few times a second rather than watching every frame, so
 * "changed" means "changed between the last two reads" — and on its own that
 * is a mark that appears and is gone again before it can be read. Holding it
 * for a moment is what makes streaming animation visible as the handful of
 * characters it actually touches. The VSU panel marks a rewritten waveform
 * bank the same way, and for the same length of time.
 */
const CHANGED_MS = 1200;

/** Every BGMap segment, since Used by has something to say about all of them. */
const VIP_BGMAP_SEGMENTS = Array.from({ length: VIP_BGMAP_COUNT }, (unused, segment) => segment);

/** One line of Used by: who uses the character, how often, and their map. */
interface MapPreview {
    key: string;
    label: string;
    note?: string;
    cells: number;
    image?: ImageData;
}

/** The character one cell of a segment names, ignoring its palette and flips. */
function cellChar(bytes: Uint8Array, cell: number): number | undefined {
    const offset = cell * 2;
    return offset + 1 < bytes.length
        ? (bytes[offset] | (bytes[offset + 1] << 8)) & 0x07ff
        : undefined;
}

/** Whether two reads agree on which segments the drawn worlds map from. */
function sameDrawnSegments(a: ReadonlyArray<boolean>, b: ReadonlyArray<boolean>): boolean {
    return a.length === b.length && a.every((drawn, segment) => drawn === b[segment]);
}

/**
 * Take the color out of one character of an already-drawn sheet.
 *
 * Done to the pixels afterwards rather than by drawing them gray in the first
 * place: what a pixel value is worth is the palette's business, and every view
 * in the debugger reads those as the red the hardware emits. This is a remark
 * about one character made on the way past, not a second kind of palette.
 */
function grayOut(pixels: Uint8ClampedArray, width: number, destX: number, destY: number): void {
    for (let y = 0; y < VIP_CHAR_SIZE; y++) {
        for (let x = 0; x < VIP_CHAR_SIZE; x++) {
            const offset = ((destY + y) * width + destX + x) * 4;
            pixels[offset + 1] = pixels[offset];
            pixels[offset + 2] = pixels[offset];
        }
    }
}

/**
 * Every character currently in VRAM, laid out as one atlas, with a sidebar
 * for inspecting one character at a time.
 *
 * Reads all four character segments each refresh and re-rasterizes only when
 * the pixels — or what the panel knows about them — actually changed, so a
 * paused emulator costs its reads per poll and no drawing at all.
 *
 * Alongside the pixels it cross-references what refers to them: the cells of
 * the BGMap segments the drawn worlds map from, and the objects OAM has
 * switched on. That is what "Used by" in the sidebar answers and what the In
 * use filter keeps — the atlas otherwise shows a thousand characters with no
 * hint of which quarter of it the game is actually using. Only what is being
 * drawn is counted; see {@link VipCharacterUsage}.
 */
export class CharactersPanel extends Panel {

    protected error?: string;
    protected registers?: DataView;
    protected charSegments: (Uint8Array | undefined)[] = [];
    /**
     * The whole of BGMap memory, as one buffer.
     *
     * One rather than fourteen because the param tables an H-bias or Affine
     * world reads live in it too, at an address rather than in a segment —
     * see {@link paramsFor}, which hands one out as a view over these bytes.
     */
    protected bgMapBytes?: Uint8Array;
    /** The same bytes, cut into segments: views, not copies. */
    protected bgMapSegments: (Uint8Array | undefined)[] = [];
    protected oamBytes?: Uint8Array;
    protected usage?: VipCharacterUsage;
    /**
     * When each character's pixels were last seen to change, as a
     * `performance.now()` reading; 0 for one that has not changed since the
     * panel was opened. See {@link CHANGED_MS}.
     */
    protected readonly changedAt = new Float64Array(VIP_CHAR_COUNT);

    // Remembered across sessions; the selected character is not, because it
    // belongs to the ROM that happened to be running.
    protected charsPerRow = this.rememberedCharsPerRow();
    protected zoom = this.remembered('zoom', 3);
    protected showGrid = this.remembered('showGrid', true);
    protected showSegments = this.remembered('showSegments', true);
    protected filter = this.rememberedFilter();
    protected selected = 0;

    protected image?: ImageData;
    /** The same pixels as {@link image}, cut into the four segments. */
    protected segmentImages: ImageData[] = [];
    /** The worlds the VIP is drawing, which Used by attributes its cells to. */
    protected worlds: VipWorld[] = [];
    /** Their attribute memory, to notice when one of them moves. */
    protected worldBytes?: Uint8Array;
    /** Which BGMap segments those worlds map from. */
    protected drawnSegments: boolean[] = [];
    /** What Used by shows for the selected character. See {@link buildMapPreviews}. */
    protected mapPreviews: MapPreview[] = [];
    /** Cleared whenever character memory moves; see {@link characterAverages}. */
    protected averages?: Uint8Array;
    /** Which characters the drawn worlds show. See {@link markDrawnCharacters}. */
    protected drawnChars?: Uint8Array;
    protected dirty = true;

    constructor(
        source: DebugSource,
        instanceId: string,
        /**
         * How a finished PNG reaches the person, from the host that knows
         * where files go — a download in the browser, a file in the project
         * in VES. Left out by a host that cannot take one, and then the panel
         * simply has no Export button.
         */
        protected readonly exportFile?: (name: string, data: Uint8Array) => Promise<void>
    ) {
        super(EmulatorPanelType.VIP_CHARACTERS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/characters/title', 'Characters');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_CHARACTERS);
        // A toolbar above the inspector, which manages its own inner
        // scrolling: this is the column the two sit in.
        this.addClass('vp-characters');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.registers = undefined;
            this.charSegments = [];
            this.bgMapBytes = undefined;
            this.bgMapSegments = [];
            this.oamBytes = undefined;
            this.usage = undefined;
            this.image = undefined;
            this.segmentImages = [];
            this.mapPreviews = [];
            this.drawnChars = undefined;
            this.worlds = [];
            this.drawnSegments = [];
            this.averages = undefined;
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));
            await this.readCharacters(sim);
            await this.readReferences(sim);
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        // The window a character counts as changed for runs out on its own, so
        // under that filter the picture keeps changing while memory does not.
        if (this.filter === 'changed') {
            this.dirty = true;
        }
        if (this.dirty) {
            this.rasterize();
            this.dirty = false;
        }
        this.update();
    }

    /** The four character segments, and which characters of them moved. */
    protected async readCharacters(sim: Sim): Promise<void> {
        const segments = await Promise.all(VIP_CHAR_SEGMENTS.map(
            (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
        ));
        const now = performance.now();
        segments.forEach((buffer, index) => {
            const bytes = new Uint8Array(buffer);
            const previous = this.charSegments[index];
            if (sameVipBytes(bytes, previous)) {
                return;
            }
            // Nothing "changed" on the first read of a segment: there is no
            // earlier state for it to differ from, and marking all 512 would
            // make the Changed filter show the whole atlas once per open.
            if (previous) {
                this.markChanged(index, bytes, previous, now);
            }
            this.charSegments[index] = bytes;
            this.averages = undefined;
            this.dirty = true;
        });
    }

    /** Timestamp the characters of one segment whose bytes are not what they were. */
    protected markChanged(segment: number, bytes: Uint8Array, previous: Uint8Array, now: number): void {
        for (const char of vipChangedCharacters(bytes, previous)) {
            this.changedAt[segment * VIP_CHARS_PER_SEGMENT + char] = now;
        }
    }

    /**
     * What currently refers to character memory: the cells of the BGMap
     * segments the drawn worlds map from, and OAM.
     *
     * The segments are chosen rather than all fourteen read, both because a
     * hundred kilobytes of reads a poll is a lot to pay for something nothing
     * is drawing and because a segment no world maps from holds whatever the
     * last scene left in it, which is not evidence of anything.
     */
    protected async readReferences(sim: Sim): Promise<void> {
        const worldBytes = new Uint8Array(await sim.readMemory(VIP_WORLD_BASE, VIP_WORLD_BLOCK_BYTES));
        const view = new DataView(worldBytes.buffer, worldBytes.byteOffset, worldBytes.byteLength);
        const worlds = vipDrawnWorlds(Array.from({ length: VIP_WORLD_COUNT }, (unused, index) =>
            decodeVipWorld(view, index, index * VIP_WORLD_BYTES)));

        const drawn: boolean[] = new Array(VIP_BGMAP_COUNT).fill(false);
        for (const world of worlds) {
            if (world.mode !== VipWorldMode.OBJECT) {
                for (const segment of vipWorldSegments(world)) {
                    drawn[segment] = true;
                }
            }
        }

        // A segment at a time, because a read is capped well below the size of
        // BGMap memory, but into one buffer: what comes back is the region as
        // the hardware lays it out, param tables included.
        const read = await Promise.all(VIP_BGMAP_SEGMENTS.map(
            segment => sim.readMemory(vipBgMapAddress(segment), VIP_BGMAP_BYTES)));
        const bgMapBytes = new Uint8Array(VIP_BGMAP_COUNT * VIP_BGMAP_BYTES);
        read.forEach((buffer, segment) => bgMapBytes.set(new Uint8Array(buffer), segment * VIP_BGMAP_BYTES));
        const changedBytes = !sameVipBytes(bgMapBytes, this.bgMapBytes);
        let changed = changedBytes || !sameDrawnSegments(drawn, this.drawnSegments);

        this.bgMapBytes = bgMapBytes;
        this.bgMapSegments = VIP_BGMAP_SEGMENTS.map(segment => bgMapBytes.subarray(
            segment * VIP_BGMAP_BYTES, (segment + 1) * VIP_BGMAP_BYTES));
        this.drawnSegments = drawn;
        // Part of the comparison, unlike the segments' bytes alone: a world
        // that only scrolled draws a different part of the same map, and both
        // what is in use and what Used by counts follow the window.
        if (!sameVipBytes(worldBytes, this.worldBytes)) {
            this.worldBytes = worldBytes;
            changed = true;
        }
        this.worlds = worlds;

        const oam = new Uint8Array(await sim.readMemory(VIP_OAM_BASE, VIP_OAM_BLOCK_BYTES));
        if (!sameVipBytes(oam, this.oamBytes)) {
            this.oamBytes = oam;
            changed = true;
        }

        if (changed || !this.usage) {
            this.usage = vipCharacterUsage(this.bgMapSegments, this.oamBytes, this.drawnSegments);
            this.dirty = true;
        }
    }

    /**
     * The remembered column count, held to the three the slider offers: it is
     * stored as the width rather than as a slider position, and a width that
     * is no longer on offer would leave the slider with no step to sit on.
     */
    protected rememberedCharsPerRow(): number {
        const stored = this.remembered('charsPerRow', DEFAULT_CHARS_PER_ROW);
        return CHARS_PER_ROW_OPTIONS.includes(stored) ? stored : DEFAULT_CHARS_PER_ROW;
    }

    /** The remembered filter, or All for a stored value that is no longer one. */
    protected rememberedFilter(): CharacterFilter {
        const stored = this.remembered('filter', 'all');
        return CHARACTER_FILTERS.includes(stored as CharacterFilter) ? stored as CharacterFilter : 'all';
    }

    protected setCharsPerRow(charsPerRow: number): void {
        this.charsPerRow = this.remember('charsPerRow', charsPerRow);
        this.dirty = true;
        this.refresh();
    }

    protected setFilter(filter: CharacterFilter): void {
        this.filter = this.remember('filter', filter) as CharacterFilter;
        this.dirty = true;
        this.refresh();
    }

    protected selectCharacter(char: number): void {
        if (Number.isNaN(char)) {
            return;
        }
        this.selected = Math.min(VIP_CHAR_COUNT - 1, Math.max(0, char));
        // Used by is about the selected character alone, maps included, so
        // picking another one is what makes those thumbnails stale.
        this.buildMapPreviews();
        this.update();
    }

    /** Whether the current filter keeps a character. */
    protected shown(char: number, now: number): boolean {
        switch (this.filter) {
            // Nothing has been cross-referenced yet on the very first poll;
            // showing everything until it has beats blanking the atlas.
            case 'used': return this.drawnChars
                ? this.drawnChars[char] === 1 || (this.usage?.objectCount(char) ?? 0) > 0
                : true;
            case 'changed': return now - this.changedAt[char] < CHANGED_MS;
            default: return true;
        }
    }

    /**
     * How one character is shaded in the atlas: as it is, or ghosted.
     *
     * Two states rather than three. Fading the characters nothing refers to
     * while showing all of them is the same statement the In use filter makes,
     * only quieter, and saying it in two places left the sheet with two kinds
     * of gray to tell apart. What is in use is the filter's question now.
     */
    protected shadingFor(char: number, now: number): CharacterShading {
        return this.shown(char, now)
            ? { intensities: VIP_GENERIC_PALETTE_INTENSITIES }
            : { intensities: FILTERED_INTENSITIES, gray: true };
    }

    protected rasterize(): void {
        const now = performance.now();
        this.markDrawnCharacters();
        this.image = this.drawAtlas(char => this.shadingFor(char, now));
        this.segmentImages = this.image ? this.sliceSegments(this.image) : [];
        this.buildMapPreviews();
    }

    /** The whole of character memory as one bitmap, shaded by `shadingFor`. */
    protected drawAtlas(shadingFor: (char: number) => CharacterShading): ImageData | undefined {
        if (this.charSegments.length === 0) {
            return undefined;
        }
        const characters = new VipCharacters(this.charSegments);
        const width = this.charsPerRow * VIP_CHAR_SIZE;
        const height = (VIP_CHAR_COUNT / this.charsPerRow) * VIP_CHAR_SIZE;
        const pixels = new Uint8ClampedArray(width * height * 4);

        for (let char = 0; char < VIP_CHAR_COUNT; char++) {
            const x = (char % this.charsPerRow) * VIP_CHAR_SIZE;
            const y = Math.floor(char / this.charsPerRow) * VIP_CHAR_SIZE;
            const shading = shadingFor(char);
            drawVipChar(pixels, width, x, y, characters, char, shading.intensities);
            if (shading.gray) {
                grayOut(pixels, width, x, y);
            }
        }
        return new ImageData(pixels, width, height);
    }

    /**
     * A thumbnail per BGMap segment whose cells name the selected character:
     * the map one pixel to the cell, with those cells picked out.
     *
     * A count on its own says a character is used forty times and leaves where
     * as the question — and where, in a map, is a shape: the letters of a line
     * of text, the bricks along a floor. At this size the map is a silhouette
     * rather than a picture, which is enough to recognize what part of the
     * screen is being looked at and to see the marks against it.
     */
    protected buildMapPreviews(): void {
        const usage = this.usage;
        if (!usage) {
            this.mapPreviews = [];
            return;
        }
        const characters = new VipCharacters(this.charSegments);
        const rows: MapPreview[] = [];
        const drawnFrom = new Set<number>();

        // A world first, because a world is the thing on the screen: the map
        // it reads is how it is built, and "BGMap 3" only answers "where is
        // this character being drawn" for somebody who already knows which
        // world reads BGMap 3.
        for (const world of this.worlds) {
            if (world.mode === VipWorldMode.OBJECT) {
                continue;
            }
            const maps = new Set<number>();
            let cells = 0;
            this.eachDrawnCell(world, new VipWorldMap(world, this.bgMapSegments, characters),
                (char, segment) => {
                    if (char === this.selected) {
                        cells++;
                        maps.add(segment);
                    }
                });
            if (cells === 0) {
                continue;
            }
            const named = [...maps].sort((a, b) => a - b);
            named.forEach(segment => drawnFrom.add(segment));
            rows.push({
                key: `world-${world.index}`,
                label: nls.localize('vueport/debug/panels/characters/usedByWorld', 'World {0}', world.index),
                // Which of its segments those cells are in, since a world's
                // map can span several and the answer is a fact about memory
                // that the world itself does not show.
                note: named.length === 1
                    ? nls.localize('vueport/debug/panels/characters/usedByBgMap', 'BGMap {0}', named[0])
                    : nls.localize(
                        'vueport/debug/panels/characters/usedByBgMaps', 'BGMaps {0}', named.join(', ')),
                cells,
                image: this.drawWorldPreview(world),
            });
        }

        // ...and then the cells no world showed. A map can hold a character
        // no world reads, and a world reads a window onto its map rather than
        // all of it, so a character can sit in a drawn map and still never be
        // drawn. Either way it is in memory and not on the screen, which is
        // the difference between a leftover and a mystery.
        for (const { segment, cells } of usage.bgMapCounts(this.selected)) {
            if (!drawnFrom.has(segment)) {
                rows.push({
                    key: `bgmap-${segment}`,
                    label: nls.localize('vueport/debug/panels/characters/usedByBgMap', 'BGMap {0}', segment),
                    cells,
                    image: this.drawSegmentPreview(segment),
                });
            }
        }
        this.mapPreviews = rows;
    }

    /**
     * Which characters the drawn worlds actually show, and the objects' too.
     *
     * The In use filter's answer. It has to be the same walk the Used by rows
     * are counted from, or the two disagree about the same character: a map
     * being read is not the same as every cell of it being drawn, and a
     * character sitting in a corner of a map the world never scrolls to is
     * not in use by any reading of the word.
     */
    protected markDrawnCharacters(): void {
        const drawn = new Uint8Array(VIP_CHAR_COUNT);
        const characters = new VipCharacters(this.charSegments);
        for (const world of this.worlds) {
            if (world.mode !== VipWorldMode.OBJECT) {
                this.eachDrawnCell(world, new VipWorldMap(world, this.bgMapSegments, characters),
                    char => { drawn[char] = 1; });
            }
        }
        this.drawnChars = drawn;
    }

    /**
     * Walk the cells one world draws, once each, with the segment each came
     * from.
     *
     * The walk is over pixels, because only the pixels know where they come
     * from once a param table is shifting each row of them — but a cell is
     * eight pixels across, so the lookup only happens where the run of pixels
     * moves into a new cell, and a set keeps a cell the world draws twice from
     * being counted twice.
     */
    protected eachDrawnCell(
        world: VipWorld, map: VipWorldMap, visit: (char: number, segment: number) => void
    ): void {
        const width = Math.min(world.w + 1, VIP_FRAME_BUFFER_WIDTH);
        const height = Math.min(world.h + 1, VIP_FRAME_BUFFER_HEIGHT);
        if (width <= 0 || height <= 0) {
            return;
        }
        // Both are powers of two — a world's map is 1, 2, 4 or 8 segments to
        // a side — so the mask is the wrap the hardware does, negatives
        // included.
        const across = world.scx * VIP_BGMAP_CELLS;
        const down = world.scy * VIP_BGMAP_CELLS;
        const seen = new Set<number>();
        let last = -1;
        forEachVipWorldPixel(
            { ...world, gx: 0, gy: 0, gp: 0 }, width, height, PREVIEW_EYE, this.paramsFor(world),
            (unusedX, unusedY, sourceX, sourceY) => {
                const cellX = (sourceX >> 3) & (across - 1);
                const cellY = (sourceY >> 3) & (down - 1);
                const key = cellY * across + cellX;
                if (key === last || seen.has(key)) {
                    last = key;
                    return;
                }
                last = key;
                seen.add(key);
                visit(map.char(sourceX, sourceY), vipWorldMapSegment(world, cellX, cellY));
            });
    }

    /**
     * One BGMap segment, a pixel to the cell.
     *
     * A whole map rather than a window, because a segment no world reads has
     * no window: there is nothing drawing it to say which part of it matters.
     */
    protected drawSegmentPreview(segment: number): ImageData | undefined {
        const bytes = this.bgMapSegments[segment];
        return bytes === undefined
            ? undefined
            : this.drawCells(VIP_BGMAP_CELLS, VIP_BGMAP_CELLS, this.characterAverages(),
                (x, y) => cellChar(bytes, y * VIP_BGMAP_CELLS + x));
    }

    /**
     * One world as it is actually drawn, with the pixels that come from the
     * selected character picked out.
     *
     * Its own rectangle rather than the map behind it: a world shows a window
     * W+1 by H+1 onto its map, from MX/MY, shifted per row by its param table
     * where it has one — so the map on its own would answer "where is this
     * character" with a picture of somewhere the world never looks. Every
     * property that decides where a pixel comes from is applied by
     * {@link forEachVipWorldPixel}; the only ones dropped here are the three
     * that place the finished rectangle on the screen (GX, GY, GP), since the
     * preview is the rectangle.
     */
    protected drawWorldPreview(world: VipWorld): ImageData | undefined {
        const width = Math.min(world.w + 1, VIP_FRAME_BUFFER_WIDTH);
        const height = Math.min(world.h + 1, VIP_FRAME_BUFFER_HEIGHT);
        if (width <= 0 || height <= 0) {
            return undefined;
        }
        // Drawn no finer than it is shown: a world the width of the screen is
        // squeezed into a sidebar either way, and sampling every second pixel
        // to get there is four times less work than drawing all of them and
        // letting the browser throw three quarters away.
        const stride = Math.max(1, Math.ceil(width / MAP_PREVIEW_WIDTH));
        const previewWidth = Math.ceil(width / stride);
        const previewHeight = Math.ceil(height / stride);
        const pixels = new Uint8ClampedArray(previewWidth * previewHeight * 4);

        const map = new VipWorldMap(world, this.bgMapSegments, new VipCharacters(this.charSegments));
        const palettes = [0, 1, 2, 3].map(() => VIP_GENERIC_PALETTE_INTENSITIES);
        const box = { ...world, gx: 0, gy: 0, gp: 0 };
        forEachVipWorldPixel(box, width, height, PREVIEW_EYE, this.paramsFor(world), (x, y, sx, sy) => {
            if (x % stride !== 0 || y % stride !== 0) {
                return;
            }
            const offset = ((y / stride) * previewWidth + x / stride) * 4;
            if (map.char(sx, sy) === this.selected) {
                // White, which nothing else in these views is: the picture is
                // drawn in the hardware's red, and a mark in a brighter red
                // would be just another shade of what it is marking.
                pixels[offset] = 255;
                pixels[offset + 1] = 255;
                pixels[offset + 2] = 255;
            } else {
                pixels[offset] = map.intensity(sx, sy, palettes);
            }
            pixels[offset + 3] = 255;
        });
        return new ImageData(pixels, previewWidth, previewHeight);
    }

    /**
     * The param table one world reads, as a view over BGMap memory.
     *
     * The tables live in the same region as the maps do, so the read that
     * fetched the segments has already fetched these; a world whose table
     * runs past the end of the region gets none rather than a short one,
     * which the drawing treats as a world with no per-row shift at all.
     */
    protected paramsFor(world: VipWorld): DataView | undefined {
        const bytes = this.bgMapBytes;
        const length = vipParamTableBytes(world);
        if (!bytes || length <= 0) {
            return undefined;
        }
        const offset = vipParamTableAddress(world.param) - VIP_BGMAP_BASE;
        return offset >= 0 && offset + length <= bytes.length
            ? new DataView(bytes.buffer, bytes.byteOffset + offset, length)
            : undefined;
    }

    /**
     * A grid of cells as a bitmap, one pixel each: the character's average
     * brightness, or white where it is the selected one.
     *
     * At this size a map is a silhouette rather than a picture, which is
     * enough to recognize which part of the screen is being looked at and to
     * see the marks against it.
     */
    protected drawCells(
        width: number,
        height: number,
        averages: Uint8Array,
        charAt: (x: number, y: number) => number | undefined
    ): ImageData {
        const pixels = new Uint8ClampedArray(width * height * 4);
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const char = charAt(x, y);
                const offset = (y * width + x) * 4;
                if (char === this.selected) {
                    // White, which nothing else in these views is: the map is
                    // drawn in the hardware's red, and a mark in a brighter
                    // red would be just another shade of the picture it is
                    // marking.
                    pixels[offset] = 255;
                    pixels[offset + 1] = 255;
                    pixels[offset + 2] = 255;
                } else if (char !== undefined) {
                    pixels[offset] = averages[char];
                }
                pixels[offset + 3] = 255;
            }
        }
        return new ImageData(pixels, width, height);
    }

    /**
     * How bright each character is on average, which is what a cell comes out
     * as when a whole map is drawn one pixel to the cell.
     *
     * Built once per read of character memory rather than per thumbnail: a
     * segment has four thousand cells and a character sixty-four pixels, so
     * doing it the other way round is the same sixty-four lookups over and
     * over for every cell that happens to name the same character.
     */
    protected characterAverages(): Uint8Array {
        if (!this.averages) {
            const characters = new VipCharacters(this.charSegments);
            const averages = new Uint8Array(VIP_CHAR_COUNT);
            for (let char = 0; char < VIP_CHAR_COUNT; char++) {
                let total = 0;
                for (let y = 0; y < VIP_CHAR_SIZE; y++) {
                    for (let x = 0; x < VIP_CHAR_SIZE; x++) {
                        total += VIP_GENERIC_PALETTE_INTENSITIES[characters.pixel(char, x, y)];
                    }
                }
                averages[char] = total / (VIP_CHAR_SIZE * VIP_CHAR_SIZE);
            }
            this.averages = averages;
        }
        return this.averages;
    }

    /**
     * The atlas cut into its four character segments.
     *
     * Views onto the same pixels rather than four more buffers: a segment is
     * a whole number of rows of the sheet whatever the column count, so each
     * one's rows are already contiguous.
     */
    protected sliceSegments(image: ImageData): ImageData[] {
        const rows = (VIP_CHARS_PER_SEGMENT / this.charsPerRow) * VIP_CHAR_SIZE;
        const bytes = rows * image.width * 4;
        return VIP_CHAR_SEGMENTS.map((unused, segment) => new ImageData(
            image.data.subarray(segment * bytes, (segment + 1) * bytes), image.width, rows));
    }

    /** Just the selected character, for the sidebar preview. */
    protected rasterizePreview(characters: VipCharacters, char: number): ImageData {
        const pixels = new Uint8ClampedArray(VIP_CHAR_SIZE * VIP_CHAR_SIZE * 4);
        // Full strength whatever the atlas is doing: the preview is what the
        // character is, not how this view happens to be filtering it.
        drawVipChar(pixels, VIP_CHAR_SIZE, 0, 0, characters, char, VIP_GENERIC_PALETTE_INTENSITIES);
        return new ImageData(pixels, VIP_CHAR_SIZE, VIP_CHAR_SIZE);
    }

    /**
     * Write the sheet out as a PNG, at one screen pixel per source pixel.
     *
     * Neither filtered nor dimmed, and without the grid: this is the file
     * somebody lines up against the source art they built the characters
     * from, and the viewing aids would be in the way of that.
     */
    protected async exportPng(): Promise<void> {
        const exportFile = this.exportFile;
        const image = this.drawAtlas(() => ({ intensities: VIP_GENERIC_PALETTE_INTENSITIES }));
        if (!exportFile || !image) {
            return;
        }
        const canvas = document.createElement('canvas');
        canvas.width = image.width;
        canvas.height = image.height;
        canvas.getContext('2d')?.putImageData(image, 0, 0);
        const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'));
        if (blob) {
            await exportFile('characters.png', new Uint8Array(await blob.arrayBuffer()));
        }
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        if (!this.registers) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }
        if (!this.image) {
            return <div className='vp-panel-empty'>
                {nls.localize('vueport/debug/panels/characters/reading', 'Reading VIP memory…')}
            </div>;
        }

        return <>
            {/* The arrow keys are read here as well as on the sheet, so that
                they walk the characters wherever focus has landed in the
                panel — a switch, a slider's row, the sidebar. The sheet is
                in the tab order in its own right and so is left to its own
                handler; see `arrowKeysTaken`. */}
            <div
                className='vp-inspector'
                tabIndex={0}
                aria-label={nls.localize('vueport/debug/panels/characters/title', 'Characters')}
                onKeyDown={event => this.onPanelKey(event)}
            >
                <div className='vp-inspector-sidebar vp-scroll'>
                    {this.renderSelected()}
                    {this.renderUsedBy()}
                    {this.renderDisplayGroup()}
                </div>
                {/* Focusable so the arrow keys have somewhere to land —
                    clicking a character puts focus here, and from then on the
                    sheet can be walked without going back to the mouse. */}
                <div
                    className='vp-inspector-main vp-scroll vp-characters-atlas'
                    tabIndex={0}
                    aria-label={nls.localize('vueport/debug/panels/characters/title', 'Characters')}
                    onKeyDown={event => this.onAtlasKey(event)}
                >
                    {this.renderAtlas()}
                </div>
            </div>
        </>;
    }

    /**
     * The character being inspected: its pixels first, then where it lives.
     *
     * A group like the two under it, rather than the bare block it started
     * as: three things in a sidebar that are each a heading and a list of
     * facts should look like three of the same thing.
     */
    protected renderSelected(): React.ReactNode {
        const selected = this.selected;
        const segment = selected >> 9;
        const charInSegment = selected % VIP_CHARS_PER_SEGMENT;
        const address = vipCharSegmentAddress(segment) + charInSegment * VIP_CHAR_BYTES;
        const mirror = vipCharMirrorAddress(segment) + charInSegment * VIP_CHAR_BYTES;
        const preview = this.rasterizePreview(new VipCharacters(this.charSegments), selected);

        return <fieldset className='vp-inspector-group vp-characters-selected'>
            <legend>{nls.localize('vueport/debug/panels/characters/currentCharacter', 'Current Character')}</legend>
            <VipCanvas image={preview} zoom={PREVIEW_ZOOM} />
            <div className='vp-detail-fields'>
                {control(
                    nls.localize('vueport/debug/panels/characters/char', 'Char'),
                    numberInput(selected, 0, VIP_CHAR_COUNT - 1, char => this.selectCharacter(char))
                )}
                {/* Which segment a character is in is only a fact worth
                    stating while the sheet is divided into them; with the
                    divisions off, the sheet is one run of indices and so is
                    this. */}
                {this.showSegments &&
                    field(nls.localize('vueport/debug/panels/characters/segment', 'Segment'), segment)}
                {field(
                    nls.localize('vueport/debug/panels/characters/address', 'Address'),
                    <code>{hex(address, 8)}</code>
                )}
                {field(
                    nls.localize('vueport/debug/panels/characters/mirror', 'Mirror'),
                    <code>{hex(mirror, 8)}</code>,
                    nls.localize(
                        'vueport/debug/panels/characters/mirrorHint',
                        'Where the same character is reachable a second time, in the contiguous '
                        + 'mirror of the four segments')
                )}
            </div>
        </fieldset>;
    }

    /**
     * Who refers to the selected character right now, and only to it.
     *
     * Reads as a list of places rather than a count, because the useful
     * question about a character in an atlas is which map or how many sprites
     * it turned up in, not how many references exist in total — and each map
     * comes with a thumbnail of itself, marked where those cells are.
     */
    protected renderUsedBy(): React.ReactNode {
        const objects = this.usage?.objectCount(this.selected) ?? 0;
        const maps = this.mapPreviews;

        return <fieldset className='vp-inspector-group vp-characters-used-by'>
            <legend>{nls.localize('vueport/debug/panels/characters/usedBy', 'Used by')}</legend>
            {/* The maps scroll within the group rather than the sidebar
                scrolling around it: a character used in half a dozen of them
                would otherwise push the Display controls off the bottom, and
                the two things that are always there are the two things that
                should always be reachable. */}
            <div className='vp-characters-used-by-body vp-scroll'>
                {maps.map(({ key, label, note, cells, image }) =>
                    <div className='vp-characters-map' key={key}>
                        {/* Not the shared field(), because this row has three
                            parts rather than two: who, where, and how often. */}
                        <div className='vp-detail-field'>
                            <span className='label'>
                                {label}
                                {note && <span className='hint'>{note}</span>}
                            </span>
                            <span className='value'>{cells === 1
                                ? nls.localize('vueport/debug/panels/characters/usedByOneCell', '1 cell')
                                : nls.localize('vueport/debug/panels/characters/usedByCells', '{0} cells', cells)}
                            </span>
                        </div>
                        {image && <VipCanvas image={image} zoom={mapPreviewZoom(image)} />}
                    </div>)}
                {objects > 0 && field(
                    nls.localize('vueport/debug/panels/objects/title', 'Objects'),
                    `${objects}`
                )}
                {maps.length === 0 && objects === 0 &&
                    <span className='hint'>{nls.localize(
                        'vueport/debug/panels/characters/usedByNothing',
                        'Nothing being drawn refers to this character.'
                    )}</span>
                }
            </div>
        </fieldset>;
    }

    protected renderDisplayGroup(): React.ReactNode {
        return <fieldset className='vp-inspector-group vp-characters-display'>
            <legend>{nls.localize('vueport/debug/panels/characters/display', 'Display')}</legend>
            {/* What the sheet shows comes before how it is laid out: the rest
                of this group is furniture, and this is the one control that
                changes which characters are there to look at. */}
            <RadioSelect
                options={[{
                    value: 'all',
                    label: nls.localize('vueport/debug/panels/characters/showAll', 'All'),
                }, {
                    value: 'used',
                    label: nls.localize('vueport/debug/panels/characters/showUsed', 'Used'),
                    tooltip: nls.localize(
                        'vueport/debug/panels/characters/showUsedHint',
                        'Only the characters a drawn BGMap cell or a switched-on object refers to'),
                }, {
                    value: 'changed',
                    label: nls.localize('vueport/debug/panels/characters/showChanged', 'Changed'),
                    tooltip: nls.localize(
                        'vueport/debug/panels/characters/showChangedHint',
                        'Only the characters whose pixels were rewritten in the last second'),
                }]}
                defaultValue={this.filter}
                onChange={options => this.setFilter(options[0].value as CharacterFilter)}
                fitSpace
            />
            {/* The two sliders share one grid so that their names, their
                tracks and their readouts line up as three columns rather than
                each row being laid out on its own and starting wherever its
                own label happens to end. */}
            <div className='vp-characters-ranges'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/characters/columns', 'Columns')}</span>
                    <input
                        type='range'
                        min={0}
                        max={CHARS_PER_ROW_OPTIONS.length - 1}
                        value={CHARS_PER_ROW_OPTIONS.indexOf(this.charsPerRow)}
                        onChange={e => this.setCharsPerRow(CHARS_PER_ROW_OPTIONS[parseInt(e.target.value, 10)])}
                    />
                    <span className='hint'>{this.charsPerRow}</span>
                </label>
                <label>
                    <span>{nls.localize('vueport/debug/panels/characters/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={8}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            {/* Both on one line: they are the two things that can be drawn
                over the sheet, they are named in a word each, and a column of
                two switches is a column of mostly empty row. */}
            <div className='vp-characters-toggles'>
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/characters/grid', 'Grid'),
                    this.showGrid,
                    on => {
                        this.showGrid = this.remember('showGrid', on);
                        this.update();
                    }
                )}
                {this.renderToggle(
                    nls.localize('vueport/debug/panels/characters/segments', 'Segments'),
                    this.showSegments,
                    on => {
                        this.showSegments = this.remember('showSegments', on);
                        this.update();
                    }
                )}
            </div>
            {this.exportFile &&
                <button
                    type='button'
                    className='vp-button secondary vp-characters-export'
                    title={nls.localize(
                        'vueport/debug/panels/characters/exportPngHint',
                        'Save the whole sheet as a PNG, at its own size and unfiltered')}
                    onClick={() => { this.exportPng().catch(() => undefined); }}
                >
                    {nls.localize('vueport/debug/panels/characters/exportPng', 'Export PNG')}
                </button>
            }
        </fieldset>;
    }

    /**
     * One of the Display group's settings, as a switch.
     *
     * A switch rather than a checkbox because these take effect the moment
     * they are thrown — see the kit component, and the SRAM panel's toggles,
     * which are laid out the same way: the control, then the name beside it.
     */
    protected renderToggle(
        label: string, value: boolean, onChange: (value: boolean) => void, hint?: string
    ): React.ReactNode {
        return <span className='vp-characters-toggle' title={hint}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{label}</span>
        </span>;
    }

    /**
     * Walk the sheet with the keyboard: a character at a time, a row at a
     * time, a segment at a time, or to either end of it.
     *
     * The event is stopped rather than only defaulted, because the emulator
     * listens for keys on the node this panel sits inside and would otherwise
     * read an arrow as the D-pad and move the game while the sheet is being
     * read. Anything this does not handle is left alone and carries on to it.
     */
    /** The sheet's own arrow keys, from anywhere in the panel. */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        this.onAtlasKey(event);
    }

    protected onAtlasKey(event: React.KeyboardEvent): void {
        const steps: Record<string, number> = {
            ArrowLeft: -1,
            ArrowRight: 1,
            ArrowUp: -this.charsPerRow,
            ArrowDown: this.charsPerRow,
            PageUp: -VIP_CHARS_PER_SEGMENT,
            PageDown: VIP_CHARS_PER_SEGMENT,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.selectCharacter(home ? 0 : end ? VIP_CHAR_COUNT - 1 : this.selected + step);
        this.revealSelection();
    }

    /**
     * Scroll the selection back into view after the keyboard moved it.
     *
     * After the next frame rather than now: the selection is drawn by the
     * render this has just asked for, and the element to scroll to does not
     * exist until that has happened.
     */
    protected revealSelection(): void {
        requestAnimationFrame(() => this.node
            .querySelector('.vp-canvas-selection')
            ?.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
    }

    /** The sheet: one canvas, or one per segment under its own heading. */
    protected renderAtlas(): React.ReactNode {
        const image = this.image;
        if (!image) {
            return undefined;
        }
        if (!this.showSegments) {
            return this.renderCanvas(image, 0);
        }
        // As wide as the sheet under it, whatever the column count and scale
        // leave the panel with: a rule that ran the width of the panel would
        // be dividing the room the sheet sits in rather than the sheet.
        const width = image.width * this.zoom;
        return <div className='vp-characters-segments'>
            {this.segmentImages.map((segmentImage, segment) => {
                const first = segment * VIP_CHARS_PER_SEGMENT;
                const last = first + VIP_CHARS_PER_SEGMENT - 1;
                return <React.Fragment key={segment}>
                    <div className='vp-characters-segment-heading' style={{ width }}>
                        <span className='label'>
                            {nls.localize('vueport/debug/panels/characters/segmentNumber', 'Segment {0}', segment)}
                        </span>
                        <span className='rule' />
                        {/* At scale 1 the sheet is narrower than this line
                            wants to be, and the range is the part of it that
                            repeats what the Char field already says. */}
                        {this.zoom > 1 &&
                            <span className='range'>
                                {`${`${first}`.padStart(4, '0')}–${`${last}`.padStart(4, '0')}`}
                            </span>}
                    </div>
                    {this.renderCanvas(segmentImage, first)}
                </React.Fragment>;
            })}
        </div>;
    }

    /**
     * One canvas of the sheet, whose top-left character is `first`.
     *
     * Split or not, a canvas only knows the range it draws, so both the
     * selection outline and a click are in its own coordinates and offset by
     * that first index on the way in and out.
     */
    protected renderCanvas(image: ImageData, first: number): React.ReactNode {
        const offset = this.selected - first;
        const count = (image.width / VIP_CHAR_SIZE) * (image.height / VIP_CHAR_SIZE);
        const holdsSelection = offset >= 0 && offset < count;
        return <VipCanvas
            image={image}
            zoom={this.zoom}
            cellSize={VIP_CHAR_SIZE}
            showGrid={this.showGrid}
            selected={holdsSelection
                ? { x: offset % this.charsPerRow, y: Math.floor(offset / this.charsPerRow) }
                : undefined}
            onPick={(x, y) => this.selectCharacter(
                first + Math.floor(y / VIP_CHAR_SIZE) * this.charsPerRow + Math.floor(x / VIP_CHAR_SIZE))}
        />;
    }
}
