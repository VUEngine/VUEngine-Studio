import { CaretDown, CaretRight, Database, Plug, X } from '@phosphor-icons/react';
import { Message } from '@lumino/messaging';
import * as React from 'react';
import { DisposableCollection } from '../../common/emulator-events';
import { formatLogTime } from '../../common/emulator-log';
import { nls } from '../../common/emulator-nls';
import { DEFAULT_SAVE_RAM_SIZE } from '../../common/emulator-save-state';
import {
    foldTouchRecord,
    makeTouchRecord,
    markTouchRecord,
    touchFillPercent,
    TOUCH_BYTES,
    TOUCHED_READ,
    TOUCHED_WRITE,
} from '../../common/emulator-sram-map';
import { VbDataType } from '../../common/vb-constants';
import { MAX_SRAM_RUNS, SramRun } from '../../common/vb-protocol';
import EmptyContainer from '../components/kit/EmptyContainer';
import Switch from '../components/kit/Switch';
import { findFunctionAt, functionDisplayName, SymbolIndex } from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { BYTES_PER_MBIT } from '../emulator-types';
import { DebugSource, EmulatorPanelType, hex, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';

/**
 * How many bursts the panel keeps.
 *
 * A burst is a row, so this is a count of rows rather than of accesses: a
 * whole save written in one sweep is one of them. What is left when a game
 * keeps touching its save is a window on the recent past, which is what
 * somebody watching wants — the last thing that happened, not the hundred
 * thousandth byte before it.
 */
const MAX_BURSTS = 1000;

/**
 * How many bytes are kept across all bursts together.
 *
 * The rows are cheap and the bytes inside them are not, so the two are capped
 * separately: this is what bounds the memory the panel holds, and the oldest
 * bursts are given up whole when it is reached.
 */
const MAX_BYTES = 200000;

/**
 * How long a burst may pause before the next run starts a new one.
 *
 * A save longer than one tick arrives over consecutive ticks — twenty
 * milliseconds apart — and has to read as one thing; a save screen visited
 * twice is two. This sits between the two.
 */
const BURST_GAP_MS = 250;

/** The save map's grid. One cell is the mapped extent divided by all of them. */
const MAP_COLUMNS = 32;
const MAP_ROWS = 4;
const MAP_CELLS = MAP_COLUMNS * MAP_ROWS;

/** How many of a burst's bytes are listed when it is opened. */
const MAX_DETAIL_ROWS = 256;

/**
 * A size in bytes, as somebody reading a save would say it.
 *
 * Rounded, because not every size here is a round one: the window and the
 * extent are powers of two, but how far up a game has written is wherever its
 * last byte fell, and printing that exactly gives "7.266053199768066 MB".
 * Two decimals is as fine as the number is worth reading, and a size that
 * happens to be round still prints without a fraction.
 */
function size(bytes: number): string {
    if (bytes >= 1024 * 1024) {
        return `${+(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }
    if (bytes >= 1024) {
        return `${+(bytes / 1024).toFixed(2)} KB`;
    }
    return `${bytes} B`;
}

/** How wide an access was, from the data type the instruction used. */
function widthOf(type: number): string {
    switch (type) {
        case VbDataType.S16:
        case VbDataType.U16:
            return '16';
        case VbDataType.S32:
        case VbDataType.F32:
            return '32';
        default:
            return '8';
    }
}

/**
 * One row of the list: what one instruction did to one stretch of the save,
 * for as long as it kept doing it.
 *
 * The unit the panel is built on, because it is the unit a game works in. A
 * save is written by a loop, and a loop is one thing that happened — five
 * hundred rows saying so are five hundred copies of the same fact, and they
 * push the only other thing that happened off the end of the list.
 *
 * The worker gathers each tick's share of that into a {@link SramRun}; this
 * is the same thing carried across ticks, which is what turns a save too long
 * for one tick into one row instead of several.
 */
interface SramBurst {
    /** Stable across renders, so React keeps the row somebody opened. */
    id: number;
    /** When the batch carrying the first run arrived. */
    at: number;
    /** When the batch carrying the most recent one did. */
    until: number;
    write: boolean;
    /** The instruction behind every byte in it. */
    pc: number;
    /** The lowest and highest save offset it has reached, inclusive. */
    first: number;
    last: number;
    /** How many bytes crossed the bus, across all of its runs. */
    bytes: number;
    /**
     * The runs themselves, in arrival order.
     *
     * Kept as they came rather than flattened to one object per byte: a game
     * reading its save on every frame would otherwise cost an allocation per
     * byte read, and where each byte went is arithmetic on the run.
     */
    runs: SramRun[];
}

/** Where a run's `index`th byte landed, as the bus saw it. */
function addressIn(run: SramRun, index: number): number {
    return run.address + index * run.stride;
}

/** The lowest and highest address a run reached, in that order. */
function extentOf(run: SramRun): [number, number] {
    const end = addressIn(run, run.values.length - 1);
    return run.address <= end ? [run.address, end] : [end, run.address];
}

/**
 * What a game is doing with its save data, as it does it.
 *
 * Reads as well as writes, which is the point: a save that is written and
 * never read back, or read back from the wrong address, looks exactly like a
 * save that works right up until the game is started again. Neither half can
 * be seen from the outside — cart RAM is memory like any other, and the
 * emulator only notices a save at all when it writes the file out.
 *
 * Both directions come from the core's own access callbacks rather than from
 * polling, so nothing is missed between frames. They cost a call out of the
 * core on every access, which is why each is asked for only while its switch
 * is on and both are given back when the panel closes. The switches are one
 * control rather than two views: what is not shown is not captured either,
 * because a game that reads its save on every frame — Wario Land does — costs
 * real speed to watch and nothing at all to leave alone.
 *
 * Three things are made of what arrives. The map says which of the save's
 * bytes have been touched and how, which is the question the panel exists for
 * — was it written and then read back from the same place — answered at a
 * glance rather than by scrolling. The list gathers what one instruction did
 * into one row, so a save is a line rather than a screenful. And the caller
 * column names the instruction where the symbols can, and narrows the list to
 * it when clicked, which is how the one routine writing where it should not
 * is found.
 */
export class SramPanel extends Panel {

    /** Oldest first, the way they happened; the list draws them the other way. */
    protected bursts: SramBurst[] = [];
    /** Bytes held across all of them, against {@link MAX_BYTES}. */
    protected byteCount = 0;
    protected nextBurstId = 1;

    /**
     * What the save map has seen, one entry per {@link TOUCH_BYTES}; see
     * `TOUCHED_*`. Folded into cells when it is drawn, not before.
     */
    protected touched = makeTouchRecord(DEFAULT_SAVE_RAM_SIZE);
    /** Which marks the switches let through, for the map; see `TOUCHED_*`. */
    protected get shown(): number {
        return (this.showWrites ? TOUCHED_WRITE : 0) | (this.showReads ? TOUCHED_READ : 0);
    }

    /** Whether the map has anything to draw, which is what decides if it is. */
    protected get anything(): boolean {
        return this.touched.some(state => (state & this.shown) !== 0);
    }

    /**
     * How much of the bus the cartridge's save answers on.
     *
     * Not a constant, because it decides what an address means: the core
     * indexes its buffer by masked address, so the same byte of the chip is
     * reachable at several addresses and only this says which byte a given one
     * is. In practice a cartridge is now given the whole of Game Pak RAM and
     * nothing mirrors, but the panel still asks rather than assuming — a
     * machine set to emulate a narrower window is exactly the case somebody
     * would open this panel to watch.
     */
    protected window = DEFAULT_SAVE_RAM_SIZE;

    /**
     * How far up the window the game has written, in bytes.
     *
     * Read from the machine rather than added up from what arrived here, and
     * the difference matters: the capture is given back whenever this panel is
     * behind another tab, so what arrived here is only what the game did while
     * somebody was watching. This is the whole of what the save holds — the
     * same figure the save file is written at — so the two numbers in the
     * caption cannot disagree with what ends up on disk.
     */
    protected used = DEFAULT_SAVE_RAM_SIZE;

    /** How many batches arrived full, and so were cut short by the worker. */
    protected dropped = 0;

    /** Which directions are being watched, and so which are being shown. */
    protected showWrites = this.remembered('writes', true);
    protected showReads = this.remembered('reads', true);

    /** The one instruction the list is narrowed to, if any. */
    protected caller?: number;
    /** Bursts opened to show the bytes inside them, by id. */
    protected opened = new Set<number>();

    protected symbols?: SymbolIndex;
    /** A program counter to the routine holding it, worked out once each. */
    protected names = new Map<number, string | undefined>();

    /** The machine being watched, and what was set up to watch it. */
    protected watched?: Sim;
    protected readonly watching = new DisposableCollection();

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.SRAM, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/sram/title', 'SRAM');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.SRAM);
        this.toDispose.push(this.watching);
    }

    /**
     * What arrives does so as events, but what is drawn is drawn on the poll.
     *
     * The worker hands over a batch every tick, fifty times a second, and
     * redrawing the list on each of them is redrawing it fifty times a second
     * — for a game that reads its save continuously, that is the whole list
     * reconciled on every frame, and it is the interface's own thread that
     * pays. Nothing is lost by drawing at the ordinary rate instead: the
     * batches are still taken as they come, and ten times a second is faster
     * than anybody reads.
     */
    protected pollHz(): number {
        return Panel.POLL_HZ;
    }

    /**
     * Give the capture back while this panel is behind another tab.
     *
     * A hidden panel is not being read, and watching the save is not free: it
     * is a call out of the core on every access the game makes, paid whether
     * or not anybody can see the result. The base class already stops the
     * poll on hide for the same reason; this is the half the poll does not
     * cover, because what fills this panel arrives as events.
     *
     * What was gathered stays gathered, so coming back to the tab shows what
     * was there rather than an empty panel — with the gap that the machine
     * carried on unwatched, which is the price of not slowing it down for a
     * panel nobody is looking at.
     */
    protected onAfterShow(msg: Message): void {
        super.onAfterShow(msg);
        if (this.watched) {
            this.capture(this.watched, this.showWrites, this.showReads);
            // What the game wrote while this panel was behind another tab was
            // not watched, so the figure in hand is as old as the last time it
            // was visible. The machine still knows.
            this.readCartRam(this.watched);
        }
    }

    protected onAfterHide(msg: Message): void {
        super.onAfterHide(msg);
        if (this.watched) {
            this.capture(this.watched, false, false);
        }
    }

    protected async refresh(): Promise<void> {
        this.follow();
        // Cached by the host for as long as the ROM is, so this is a promise
        // that has already settled on every tick but the first.
        const symbols = await this.source.getSymbols();
        if (symbols !== this.symbols) {
            this.symbols = symbols;
            this.names.clear();
        }
        this.update();
    }

    /**
     * Point the capture at whatever machine there is now.
     *
     * Closing a ROM takes the simulation away and opening one brings a new
     * one, so this covers both: what was gathered belonged to the machine
     * that has gone, and none of it describes the one that replaced it. A
     * reset keeps the same simulation, and is caught by `onRestart` instead.
     */
    protected follow(): void {
        const sim = this.source.sim;
        if (sim === this.watched) {
            return;
        }
        this.watching.dispose();
        this.watched = sim;
        this.clear();
        if (!sim) {
            return;
        }

        // Asked for rather than assumed. Two numbers and not the buffer: the
        // window is 16 MiB of Game Pak RAM, and reading it across the worker
        // boundary to learn its length would be the most expensive thing this
        // panel ever did.
        this.readCartRam(sim);

        this.watching.push(sim.onSram(runs => this.append(runs)));
        this.watching.push(sim.onRestart(() => this.clear()));
        this.watching.push({ dispose: () => this.capture(sim, false, false) });
        if (this.isVisible) {
            this.capture(sim, this.showWrites, this.showReads);
        }
    }

    protected capture(sim: Sim, writes: boolean, reads: boolean): void {
        sim.setSramCapture(writes, reads).catch(() => {
            // Nothing to show rather than nothing at all: the panel still
            // draws, and its empty state is already the honest answer.
        });
    }

    /** Throw one of the two switches, which is a capture as much as a filter. */
    protected watchDirection(direction: 'writes' | 'reads', wanted: boolean): void {
        if (direction === 'writes') {
            this.showWrites = this.remember('writes', wanted);
        } else {
            this.showReads = this.remember('reads', wanted);
        }
        if (this.watched && this.isVisible) {
            this.capture(this.watched, this.showWrites, this.showReads);
        }
        this.update();
    }

    /** Take the window and the high-water mark the machine actually has. */
    protected readCartRam(sim: Sim): void {
        sim.cartRamInfo()
            .then(info => {
                this.setWindow(info.size);
                // Only ever upwards within a session, and never below the
                // baseline: a save file is never written shorter than that, so
                // a smaller figure would describe a file that cannot exist.
                this.used = Math.max(this.used, info.used, DEFAULT_SAVE_RAM_SIZE);
            })
            .catch(() => { /* the default window stands */ });
    }

    /**
     * Take the window the machine actually has.
     *
     * A different size is a different cartridge, and every offset already
     * gathered was masked with the old one — so rather than rescale them into
     * something that would read as fact, the panel starts again.
     *
     * The record is resized with it. It is kept at a fixed granularity
     * (see {@link TOUCH_BYTES}) so that the map widening as a game reaches
     * further up the save costs nothing; only the window itself changing,
     * which means a different cartridge, throws anything away.
     */
    protected setWindow(bytes: number): void {
        if (bytes <= 0 || (bytes & (bytes - 1)) !== 0 || bytes === this.window) {
            return;
        }
        this.window = bytes;
        this.touched = makeTouchRecord(bytes);
        this.used = DEFAULT_SAVE_RAM_SIZE;
        this.clear();
    }

    /**
     * How much of the save the map draws.
     *
     * The extent the game has reached, rounded up to a power of two, rather
     * than the window: with the whole of Game Pak RAM backed, a map of the
     * window would be one lit cell in 128 for every game ever made, and the
     * other 127 would be saying nothing about anything. Floored at the
     * baseline so that the ordinary case reads exactly as it always has.
     */
    protected get extent(): number {
        let extent = DEFAULT_SAVE_RAM_SIZE;
        while (extent < this.used && extent < this.window) {
            extent *= 2;
        }
        return extent;
    }

    protected append(runs: SramRun[]): void {
        const at = Date.now();
        // A full batch is the worker's cap, which means the tick was cut
        // short. Said out loud rather than passed over, so a gap in the list
        // is never mistaken for a gap in what the game did.
        if (runs.length >= MAX_SRAM_RUNS) {
            this.dropped++;
        }
        for (const run of runs) {
            this.record(run, at);
        }
        this.trim();
        // No update here on purpose; the poll draws. See pollHz.
    }

    /** Put one run on the end of the burst it continues, or start a new one. */
    protected record(run: SramRun, at: number): void {
        if (run.values.length === 0) {
            return;
        }
        const mask = this.window - 1;
        const [low, high] = extentOf(run);
        const first = low & mask;
        const last = high & mask;
        const burst = this.bursts[this.bursts.length - 1];

        if (burst && this.joins(burst, run, first, last, at)) {
            burst.runs.push(run);
            burst.first = Math.min(burst.first, first);
            burst.last = Math.max(burst.last, last);
            burst.bytes += run.values.length;
            burst.until = at;
        } else {
            this.bursts.push({
                id: this.nextBurstId++,
                at,
                until: at,
                write: run.write,
                pc: run.pc,
                first,
                last,
                bytes: run.values.length,
                runs: [run],
            });
        }

        this.byteCount += run.values.length;
        this.touch(first, last, run.write);
    }

    /**
     * Whether a run carries on the burst before it.
     *
     * One instruction, one direction, no pause, and a stretch the burst
     * already reaches or is about to. A run the worker had to cut at the end
     * of a tick picks up where it left off, which is what this is for;
     * anything else is a second thing happening.
     */
    protected joins(
        burst: SramBurst, run: SramRun, first: number, last: number, at: number
    ): boolean {
        const reach = Math.max(1, Math.abs(run.stride));
        return burst.write === run.write
            && burst.pc === run.pc
            && at - burst.until <= BURST_GAP_MS
            && first >= burst.first - reach
            && last <= burst.last + reach;
    }

    /**
     * Mark the cells a run covered.
     *
     * Kept apart from the bursts on purpose: the map is every byte touched
     * since the machine started, and giving up the oldest row to stay inside
     * a cap is not the same as the game never having been there.
     */
    protected touch(first: number, last: number, write: boolean): void {
        markTouchRecord(this.touched, first, last, write ? TOUCHED_WRITE : TOUCHED_READ);
        // A run reaching further up the save than the machine was last asked
        // about widens the map at once, rather than at the next time somebody
        // happens to look away and back.
        this.used = Math.max(this.used, last + 1);
    }

    /** Give up whole bursts from the front until both caps are met again. */
    protected trim(): void {
        while (this.bursts.length > MAX_BURSTS
            || (this.byteCount > MAX_BYTES && this.bursts.length > 1)) {
            const gone = this.bursts.shift();
            if (!gone) {
                return;
            }
            this.byteCount -= gone.bytes;
            this.opened.delete(gone.id);
        }
    }

    protected clear(): void {
        this.bursts = [];
        this.byteCount = 0;
        this.opened.clear();
        this.touched.fill(0);
        this.dropped = 0;
        this.caller = undefined;
        this.update();
    }

    protected visible(): SramBurst[] {
        return this.bursts.filter(burst => {
            if (!(burst.write ? this.showWrites : this.showReads)) {
                return false;
            }
            return this.caller === undefined || burst.pc === this.caller;
        });
    }

    /**
     * What the build calls the routine a program counter is in, where there is
     * a build to ask.
     *
     * A ROM that was not built here has no symbols and so no names, which is
     * an ordinary state: the address is shown instead, and it still groups and
     * filters exactly the same way.
     */
    protected nameOf(pc: number): string | undefined {
        if (!this.symbols) {
            return undefined;
        }
        if (this.names.has(pc)) {
            return this.names.get(pc);
        }
        const romBytes = Math.max(0, this.source.romSize) * BYTES_PER_MBIT;
        const found = romBytes > 0 ? findFunctionAt(this.symbols, pc, romBytes) : undefined;
        const name = found ? functionDisplayName(this.symbols, found.name) : undefined;
        this.names.set(pc, name);
        return name;
    }

    /** The caller as it is written in a row or a chip, named or bare. */
    protected callerLabel(pc: number): string {
        return this.nameOf(pc) ?? `0x${hex(pc, 8)}`;
    }

    protected render(): React.ReactNode {
        if (!this.source.sim) {
            return <EmptyContainer
                title={nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')}
                icon={<Plug size={32} />}
            />;
        }

        const rows = this.visible();

        return <div className='vp-sram'>
            {this.renderToolbar()}
            {/* Nothing has been touched yet, so there is no map of it: a grid
                of empty cells says only that the panel has a grid. */}
            {this.anything && this.renderMap()}

            {this.dropped > 0 && <div className='vp-sram-dropped'>
                {nls.localize('vueport/debug/panels/sram/dropped',
                    'A burst was longer than could be captured, so some accesses are missing.')}
            </div>}

            <div className='vp-sram-list vp-scroll'>
                {rows.length === 0
                    ? this.renderEmpty()
                    : this.renderList(rows)}
            </div>
        </div>;
    }

    protected renderToolbar(): React.ReactNode {
        // Bytes rather than rows: a row is a run, and how long the runs were
        // is the other half of what happened. Only the directions being
        // watched are counted, for the same reason only they are listed.
        const counts: string[] = [];
        if (this.showWrites) {
            counts.push(nls.localize('vueport/debug/panels/sram/writeCount', '{0} writes',
                this.bursts.reduce((sum, burst) => sum + (burst.write ? burst.bytes : 0), 0)));
        }
        if (this.showReads) {
            counts.push(nls.localize('vueport/debug/panels/sram/readCount', '{0} reads',
                this.bursts.reduce((sum, burst) => sum + (burst.write ? 0 : burst.bytes), 0)));
        }

        return <div className='vp-panel-toolbar'>
            {this.renderSwitch('writes', nls.localize('vueport/debug/panels/sram/writes', 'Writes'))}
            {this.renderSwitch('reads', nls.localize('vueport/debug/panels/sram/reads', 'Reads'))}
            {/* Set by clicking a caller in the list, and given up here — the
                filter is a place the list put you, so the way out belongs
                where every other control is. */}
            {this.caller !== undefined && <button
                type='button'
                className='vp-sram-caller-chip'
                title={nls.localize('vueport/debug/panels/sram/showAllCallers', 'Show every caller again')}
                onClick={() => {
                    this.caller = undefined;
                    this.update();
                }}
            >
                {this.callerLabel(this.caller)}
                <X size={12} />
            </button>}
            {/* The switches decide what is captured and so belong here from
                the start; a count of nothing and a Clear with nothing to
                clear are chrome around an empty state. */}
            {this.bursts.length > 0 && <>
                <span className='vp-sram-counts'>{counts.join(', ')}</span>
                <button className='vp-button secondary' onClick={() => this.clear()}>
                    {nls.localize('vueport/debug/panels/sram/clear', 'Clear')}
                </button>
            </>}
        </div>;
    }

    protected renderSwitch(direction: 'writes' | 'reads', label: string): React.ReactNode {
        const on = direction === 'writes' ? this.showWrites : this.showReads;
        return <span className={`vp-sram-toggle ${direction}`}>
            <Switch
                label={label}
                value={on}
                onChange={wanted => this.watchDirection(direction, wanted)}
            />
            <span>{label}</span>
        </span>;
    }

    /**
     * The save itself, one cell per block of it, coloured by what happened
     * there.
     *
     * A cell is written if anything ever wrote it, read if it was only ever
     * read, and neither otherwise — the order matters, because a byte written
     * and read back is a byte that works and a byte only read is one the game
     * expected to find something in.
     */
    protected renderMap(): React.ReactNode {
        const extent = this.extent;
        const perCell = extent / MAP_CELLS;
        const { marks: folded, covered } = foldTouchRecord(this.touched, extent, MAP_CELLS);
        return <div className='vp-sram-map'>
            <div className='vp-sram-caption'>
                <div>
                    {nls.localize('vueport/debug/panels/sram/map', 'SRAM map')}
                </div>
                <div>
                    {/* What the save holds against what the cartridge could
                        hold. The first is what a save file of it would cost;
                        the second is the window the core was given, which is
                        the whole of Game Pak RAM unless somebody narrowed it
                        to emulate a real cartridge. */}
                    {nls.localize('vueport/debug/panels/sram/usedOf', '{0} used of {1}',
                        size(this.used), size(this.window))}{' · '}
                    0x{hex(0, 4)}–0x{hex(extent - 1, 4)}
                </div>
            </div>
            <div
                className='vp-sram-cells'
                style={{ gridTemplateColumns: `repeat(${MAP_COLUMNS}, 1fr)` }}
            >
                {Array.from(folded, (marks, cell) => {
                    // What is not being watched is not on the map either, so
                    // that the two switches govern the whole panel and not
                    // only its list.
                    const state = marks & this.shown;
                    const fill = state === 0 ? 0 : touchFillPercent(covered[cell]);
                    return <div
                        key={cell}
                        className={'vp-sram-cell'
                            + (state & TOUCHED_WRITE ? ' written' : state & TOUCHED_READ ? ' read' : '')}
                        // How solid the cell is drawn: a cell standing for a
                        // megabyte of which a kilobyte was written is not the
                        // same as a full one, and drawing them alike is the
                        // map's only way of lying. See `foldTouchRecord`.
                        style={{ '--vp-sram-fill': `${fill.toFixed(1)}%` } as React.CSSProperties}
                        title={`0x${hex(cell * perCell, 4)}–0x${hex((cell + 1) * perCell - 1, 4)}`
                            // An untouched cell says only which bytes it
                            // stands for; the legend has no entry for it.
                            + (state === 0 ? '' : ` · ${this.cellState(state)}`)
                            // And a part-filled one says how much, or a faint
                            // cell would be a mystery rather than a measurement.
                            + (state === 0 || covered[cell] >= 1 ? ''
                                : ` · ${size(Math.round(covered[cell] * perCell))} of it`)}
                    />;
                })}
            </div>
        </div>;
    }

    /** What a map cell's marks say, for its legend and for its tooltip. */
    protected cellState(state: number): string {
        if (state & TOUCHED_WRITE) {
            return nls.localize('vueport/debug/panels/sram/written', 'written');
        }

        return nls.localize('vueport/debug/panels/sram/readOnly', 'read only');
    }

    protected renderEmpty(): React.ReactNode {
        if (!this.showWrites && !this.showReads) {
            return <EmptyContainer
                title={nls.localize('vueport/debug/panels/sram/nothingWatched', 'Nothing is being watched')}
                description={nls.localize('vueport/debug/panels/sram/nothingWatchedHint',
                    'Turn either writes or reads on.')}
                icon={<Database size={32} />}
            />;
        }
        return <EmptyContainer
            title={this.caller !== undefined || this.bursts.length > 0
                ? nls.localize('vueport/debug/panels/sram/filteredOut', 'Nothing matches the filter')
                : nls.localize('vueport/debug/panels/sram/waiting', 'Waiting for save data')}
            description={nls.localize('vueport/debug/panels/sram/waitingHint',
                'Nothing appears until the game accesses SRAM.')}
            icon={<Database size={32} />}
        />;
    }

    /** Newest first, so a save that has just happened is where the eye is. */
    protected renderList(rows: SramBurst[]): React.ReactNode {
        return <table className='vp-sram-table'>
            <thead>
                <tr>
                    <th className='vp-sram-open' />
                    <th>{nls.localize('vueport/debug/panels/sram/time', 'Time')}</th>
                    <th>{nls.localize('vueport/debug/panels/sram/range', 'Range')}</th>
                    <th className='number'>{nls.localize('vueport/debug/panels/sram/bytes', 'Bytes')}</th>
                    <th>{nls.localize('vueport/debug/panels/sram/from', 'From')}</th>
                </tr>
            </thead>
            <tbody>
                {rows.slice().reverse().map((burst, i) => this.renderBurst(burst, i))}
            </tbody>
        </table>;
    }

    /** Open a burst's bytes, or put them away again. */
    protected toggle(id: number): void {
        if (this.opened.has(id)) {
            this.opened.delete(id);
        } else {
            this.opened.add(id);
        }
        this.update();
    }

    protected renderBurst(burst: SramBurst, index: number): React.ReactNode {
        const opened = this.opened.has(burst.id);
        const single = burst.first === burst.last;
        return <React.Fragment key={burst.id}>
            {/* The whole row opens it, rather than the caret alone: the row is
                what somebody is looking at, and a caret is a small target for
                a list this dense. The caret stays as the sign that there is
                something under it. */}
            <tr
                className={`vp-sram-${burst.write ? 'write' : 'read'}`
                    + ` ${index % 2 === 0 ? 'even' : 'odd'}${opened ? ' opened' : ''}`}
                role='button'
                tabIndex={0}
                aria-expanded={opened}
                aria-label={nls.localize('vueport/debug/panels/sram/bytesIn', 'Bytes in this burst')}
                onClick={() => this.toggle(burst.id)}
                onKeyDown={event => {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        this.toggle(burst.id);
                    }
                }}
            >
                <td className='vp-sram-open'>
                    {opened ? <CaretDown size={11} weight='fill' /> : <CaretRight size={11} weight='fill' />}
                </td>
                <td className='vp-log-time'>{formatLogTime(burst.at)}</td>
                <td className='vp-sram-range'>
                    <b>{burst.write
                        ? nls.localize('vueport/debug/panels/sram/write', 'W')
                        : nls.localize('vueport/debug/panels/sram/read', 'R')}</b>
                    {/* Offsets into the save, which is what a game's own code
                        counts in; the full bus address is in the detail. */}
                    {single
                        ? hex(burst.first, 4)
                        : `${hex(burst.first, 4)}–${hex(burst.last, 4)}`}
                </td>
                <td className='number'>{burst.bytes}</td>
                <td>
                    <button
                        type='button'
                        className='vp-sram-caller'
                        title={`0x${hex(burst.pc, 8)}`}
                        onClick={event => {
                            // The row opens the bytes; this one column does
                            // something else, so it keeps the click.
                            event.stopPropagation();
                            this.caller = this.caller === burst.pc ? undefined : burst.pc;
                            this.update();
                        }}
                    >
                        {this.callerLabel(burst.pc)}
                    </button>
                </td>
            </tr>
            {opened && <tr className='vp-sram-detail'>
                <td />
                <td colSpan={4}>{this.renderDetail(burst)}</td>
            </tr>}
        </React.Fragment>;
    }

    /**
     * The bytes a burst carried, for when the run itself is not the question —
     * which byte went where, and how wide the instruction was.
     *
     * Cut off well short of a whole burst: a save's worth of rows under one
     * opened line would be the list this panel was rewritten to stop being,
     * and the beginning of a run is where anything surprising about it is.
     */
    protected renderDetail(burst: SramBurst): React.ReactNode {
        const mask = this.window - 1;
        const rows: React.ReactNode[] = [];
        for (const run of burst.runs) {
            for (let index = 0; index < run.values.length && rows.length < MAX_DETAIL_ROWS; index++) {
                const address = addressIn(run, index) >>> 0;
                rows.push(<tr key={rows.length}>
                    <td>{hex(address & mask, 4)}</td>
                    <td>0x{hex(address, 8)}</td>
                    <td>0x{hex(run.values[index], 2)}</td>
                    <td>{widthOf(run.type)}</td>
                </tr>);
            }
        }

        return <div className='vp-sram-bytes vp-scroll'>
            <table>
                <thead>
                    <tr>
                        <th>{nls.localize('vueport/debug/panels/sram/offset', 'Offset')}</th>
                        <th>{nls.localize('vueport/debug/panels/sram/address', 'Address')}</th>
                        <th>{nls.localize('vueport/debug/panels/sram/value', 'Value')}</th>
                        <th>{nls.localize('vueport/debug/panels/sram/width', 'Width')}</th>
                    </tr>
                </thead>
                <tbody>{rows}</tbody>
            </table>
            {burst.bytes > rows.length && <div className='vp-sram-more'>
                {nls.localize('vueport/debug/panels/sram/more', 'and {0} more', burst.bytes - rows.length)}
            </div>}
        </div>;
    }
}
