import { Message } from '@lumino/messaging';
import { ArrowUDownLeft, MagnifyingGlass, Plug, PushPin, X } from '@phosphor-icons/react';
import * as React from 'react';
import { nls } from '../../common/emulator-nls';
import {
    isWram, VB_MAX_MEMORY_READ, VB_REGION_BYTES, VB_ROM_BASE, VB_VSU_MAP_BYTES, VB_WRAM_SIZE,
} from '../../common/vb-constants';
import EmptyContainer from '../components/kit/EmptyContainer';
import RadioSelect from '../components/kit/RadioSelect';
import { debounce, Debounced } from '../components/kit/Utils';
import { ancestryOf } from '../core/emulator-classes';
import { findStructMemberAt, VesStruct } from '../core/emulator-dwarf';
import { romOffsetOf } from '../core/emulator-line-table';
import {
    BLOCK_HEADER_BYTES, parseMemoryPoolLayout, readMemoryPoolBlocks, symbolsMatchRunningBuild,
} from '../core/emulator-memory-pool';
import {
    findFunctionAt, findSymbolAt, functionDisplayName, structNameOf, SymbolIndex,
} from '../core/emulator-symbols';
import { Sim } from '../core/vb-core';
import { BYTES_PER_MBIT } from '../emulator-types';
import { DebugSource, EmulatorPanelType, emulatorPanelLabel, hex, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';

const BYTES_PER_ROW = 16;

/**
 * One of the eight places the bus decodes to, and how much of it answers.
 *
 * Every region is {@link VB_REGION_BYTES} wide — that is what the three
 * decoded bits mean, and the list says so. What sits behind one is usually far
 * smaller and repeats across the rest: 64 KB of WRAM across the whole of
 * region 5, a handful of registers across the whole of region 2. `mapped` is
 * that part, and it is what the list walks, because scrolling 16 MB of WRAM
 * would be 256 passes over the same 64 KB — not browsing memory, browsing a
 * repeat.
 *
 * Both numbers are shown, because they answer different questions and a
 * caption giving only the second would be claiming region 2 is 64 bytes long,
 * which is not what any memory map of this machine says.
 */
export interface VbMemoryRegion {
    /** What the region is, spelled out. */
    label: string;
    /** What the map bar calls it. */
    short: string;
    /** Where it begins; it runs for {@link VB_REGION_BYTES} from here. */
    address: number;
    /**
     * How much of it answers with something of its own, before the mirrors
     * start. Zero for the one only the running machine knows — the cartridge
     * ROM, whose extent is the size of the ROM that was loaded.
     */
    mapped: number;
}

/**
 * The VCU aperture, offered only while a VB Color is running.
 *
 * Kept out of {@link VB_MEMORY_REGIONS} rather than grayed out in it: on an
 * original Virtual Boy there is nothing at `0x03000000` to jump to, and a
 * button that lands on a page of open bus is worse than no button.
 */
export const VCU_MEMORY_REGION: VbMemoryRegion = {
    label: 'VCU (VB Color)',
    address: 0x03000000,
    short: 'VCU',
    // The Color Framebuffer at the bottom, Color RAM at 0x03079000 and the
    // register block above it, which ends the aperture at 0x0307F900.
    mapped: 0x80000,
};

export const VB_MEMORY_REGIONS: VbMemoryRegion[] = [
    {
        label: 'VIP — Virtual Image Processor',
        address: 0x00000000,
        short: 'VIP',
        // VRAM, the world and object attribute blocks, the registers at
        // 0x0005F800 and the character mirrors, which run out at 0x00080000.
        mapped: 0x80000,
    },
    {
        label: 'VSU — Virtual Sound Unit',
        address: 0x01000000,
        short: 'VSU',
        // The waveform tables through to SSTOP, rounded up to a whole row.
        mapped: Math.ceil(VB_VSU_MAP_BYTES / BYTES_PER_ROW) * BYTES_PER_ROW,
    },
    {
        label: 'Miscellaneous Hardware',
        address: 0x02000000,
        short: 'Regs',
        // The link, timer, pad and wait-control registers end at 0x02000027;
        // the round number past them also takes in the engine's terminal port
        // at 0x02000030, which is software rather than hardware but is looked
        // at often enough to be worth being able to land on.
        mapped: 0x40,
    },
    {
        label: 'Game Pak Expansion',
        address: 0x04000000,
        short: 'EXP',
        // Unmapped on a bare machine; an expansion that answers at all answers
        // at the bottom of the region, which is where ESSound's one port is.
        mapped: 0x40,
    },
    {
        label: 'WRAM',
        address: 0x05000000,
        short: 'WRAM',
        mapped: VB_WRAM_SIZE,
    },
    {
        label: 'Game Pak RAM',
        address: 0x06000000,
        short: 'RAM',
        // How much a cartridge actually carries is not something the core
        // reports, so this is what every Virtual Boy cartridge with a save has.
        mapped: 0x2000,
    },
    {
        label: 'Game Pak ROM',
        address: VB_ROM_BASE,
        short: 'ROM',
        mapped: 0,
    },
];

/**
 * A row's height, which the virtualized list needs as a number and the
 * stylesheet needs as a length. Handed to the CSS as a custom property rather
 * than written in both places, so the two can never drift apart — a
 * disagreement of one pixel would show as the rows sliding away from the
 * scrollbar the further down you went.
 */
const ROW_HEIGHT = 18;

/**
 * The ruler's height, which is a row's because the ruler *is* a row — the only
 * way to be sure the digits stand over the columns they number.
 *
 * It matters to the arithmetic as well as to the layout. The ruler is sticky,
 * so it takes a row's worth of space at the top of the list and then covers a
 * row's worth of it once the list is scrolled; the two cancel, which is why the
 * first row on screen is simply `scrollTop / ROW_HEIGHT`. Revealing a row at
 * the *bottom* has no such cancellation and has to allow for it.
 */
const RULER_HEIGHT = ROW_HEIGHT;

/** Rows kept rendered above and below the viewport, so scrolling has slack. */
const OVERSCAN = 8;

/** Rows assumed before the panel has been measured, for the first paint. */
const DEFAULT_VIEWPORT_ROWS = 24;

/** How long a byte stays marked after it changes. */
const FLASH_MS = 700;

const MAX_WATCHES = 16;

/**
 * How long the search box waits after the last keystroke.
 *
 * The box drives three things that are read while typing — whether Find can be
 * pressed, whether the clear cross is there, whether the last search is still
 * being reported as having found nothing — and settling them per keystroke
 * made the toolbar twitch under the hands of whoever was typing.
 */
const SEARCH_SETTLE_MS = 250;

/**
 * The smallest either scrollbar's thumb may be drawn.
 *
 * The map is over a megabyte of cartridge and a panel shows a few hundred
 * bytes of it, so a thumb sized honestly would be a fraction of a pixel. This
 * is the floor that keeps it visible and grabbable; it costs a little accuracy
 * at the ends of the travel, which is what every scrollbar trades away.
 */
const MIN_THUMB = 18;

/**
 * How far the scroller is pushed past its clip, to take its own vertical
 * scrollbar out of sight — see `.vp-memory-clip`.
 *
 * Wide enough for a native bar on a platform that draws a broad one, since
 * `--vp-scrollbar-width` is only what this interface asks for and Firefox
 * gives the operating system's.
 */
const SCROLLBAR_GUTTER = 20;

/**
 * How much of a region a search reads at a time.
 *
 * The widest window a read may ask for, because a search over a megabyte of
 * cartridge is round trips before it is anything else, and each one is the
 * worker walking the bus a byte at a time.
 */
const SEARCH_WINDOW = VB_MAX_MEMORY_READ;

/** Bytes read at the selection, which is what the inspector strip decodes. */
const INSPECT_BYTES = 4;

/** A region placed in the scrollable list. */
interface MappedRegion {
    region: VbMemoryRegion;
    /**
     * What answers, with the ROM's resolved from the ROM that is loaded. The
     * region itself is always {@link VB_REGION_BYTES}; this is the part of it
     * the list walks.
     */
    mapped: number;
    /** Data rows it contributes. */
    rows: number;
    /** Index of its caption row; the data rows follow it. */
    firstRow: number;
}

/** What is at a row of the list. */
interface MemoryRow {
    entry: MappedRegion;
    /** Absent for the caption row a region begins with. */
    address?: number;
}

/** A run of bytes that has been read, and where from. */
interface MemoryChunk {
    address: number;
    bytes: Uint8Array;
}

/** What the symbols say the selected byte is part of. */
interface MemoryWhere {
    /** The symbol, function or class it belongs to. */
    owner: string;
    /** How far into that it is. */
    offset: number;
    /** The field itself, where a layout was found for the object. */
    field?: string;
}

/**
 * The layout to read an object by: its own class', or the nearest ancestor the
 * build described that fits in the block.
 *
 * The Actors panel's `layoutFor` without its stop at `Actor` — that one is
 * reading actors and gives up once the chain leaves them, while a hex dump is
 * looking at whatever happens to be under the cursor and any layout that fits
 * is better than none. Both send the search up the chain for the same two
 * reasons; see the comment there.
 */
function layoutFor(index: SymbolIndex, className: string, availableBytes: number): VesStruct | undefined {
    for (const ancestor of ancestryOf(index.classes, className)) {
        const struct = index.structs.get(structNameOf(ancestor));
        if (struct && struct.byteSize <= availableBytes) {
            return struct;
        }
    }
    return undefined;
}

/** What a search is looking for, and how its bytes are compared. */
interface MemoryNeedle {
    bytes: Uint8Array;
    /**
     * Whether a letter matches either case. Set for a needle that was typed
     * as text, where {@link bytes} is already folded to lower case and the
     * memory being searched is folded a byte at a time to match it.
     */
    folded: boolean;
}

/** `A`-`Z` folded to lower case, and every other byte left as it is. */
function fold(byte: number): number {
    return byte >= 0x41 && byte <= 0x5a ? byte + 0x20 : byte;
}

/** A needle typed as text: its bytes, folded so either case matches. */
function textNeedle(text: string): MemoryNeedle {
    const bytes = new TextEncoder().encode(text);
    for (let at = 0; at < bytes.length; at++) {
        bytes[at] = fold(bytes[at]);
    }
    return { bytes, folded: true };
}

/** A size at the scale it reads at, for a region caption. */
function sizeOf(bytes: number): string {
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
        return `${Math.round(bytes / 1024)} KB`;
    }
    const mb = bytes / (1024 * 1024);
    return `${mb.toLocaleString('en-US', { maximumFractionDigits: mb < 10 ? 1 : 0 })} MB`;
}

/**
 * Hex view of the address space.
 *
 * One list over the whole memory map rather than a page at a time: the regions
 * are laid end to end, each behind a caption saying what it is, and the list is
 * virtualized so that only what is on screen is ever read or rendered. Which
 * region the view is in drives the map bar above it, and picking one there
 * scrolls to it — the two are the same control read in both directions.
 *
 * Reads go through the CPU's view of memory rather than the state struct, so
 * mirroring and mapped hardware registers read exactly as the running program
 * sees them. Writes go out through {@link DebugSource.write} for the same
 * reason the VIP editors do: in a linked session a poke has to reach both
 * machines or the two stop running the same game.
 */
export class MemoryPanel extends Panel {

    /** Where the view was left, so reopening the panel returns to it. */
    protected address = this.remembered('address', 0x05000000);
    /** The byte the inspector strip is reading, if any. */
    protected selected?: number;

    /** The regions as they are currently laid out, and what built that. */
    protected map: MappedRegion[] = [];
    protected totalRows = 0;
    protected mapSignature?: string;

    /** What has been read for the rows on screen. */
    protected chunks: MemoryChunk[] = [];
    /** The four bytes at the selection, which the inspector strip decodes. */
    protected selectedBytes?: Uint8Array;
    /** Read for the watch list, coalesced into as few reads as it allows. */
    protected watchChunks: MemoryChunk[] = [];
    /** When each byte on screen last changed, for the mark that fades. */
    protected readonly changedAt = new Map<number, number>();

    /** Addresses pinned to the watch list, in the order they were pinned. */
    protected watches: number[] = [];

    /** What the symbols say about {@link selected}, and which address it is for. */
    protected where?: MemoryWhere;
    protected whereFor?: number;

    /**
     * What will be searched for, which lags the box by {@link SEARCH_SETTLE_MS}.
     *
     * The box itself is uncontrolled, like the address box and for the same
     * reason: what is being typed lives in the DOM, where a redraw ten times a
     * second cannot reach it.
     */
    protected search = '';
    /** Set when the last search ran out without finding anything. */
    protected searchMissed = false;
    protected searching = false;
    protected readonly searchInput = React.createRef<HTMLInputElement>();
    protected readonly settleSearch: Debounced<[string]> = debounce((text: string) => {
        this.search = text;
        this.searchMissed = false;
        this.update();
    }, SEARCH_SETTLE_MS);

    /** The first nibble of a byte being typed over, before the second arrives. */
    protected pending?: { address: number, nibble: number };

    protected scroller?: HTMLDivElement;
    protected scrollTop = 0;
    protected viewportHeight = 0;
    protected resize?: ResizeObserver;
    /**
     * The region scrubber's width, measured rather than expressed in percent.
     *
     * Its thumb has a minimum size, so where it sits is not a share of the
     * track but a position along what is left of the track once the thumb is
     * taken out of it — which is a length, and needs one to work from.
     */
    protected locatorWidth = 0;
    protected locatorResize?: ResizeObserver;
    /** A scroll position to apply once the rows behind it have been rendered. */
    protected pendingScrollTop?: number;

    /**
     * Where in its thumb each scrollbar was taken hold of, while it is being
     * dragged. Undefined for one nobody has hold of.
     */
    protected railGrab?: number;
    protected locatorGrab?: number;
    /**
     * The region the locator is scrubbing.
     *
     * Held for the length of the drag rather than read from the view each
     * time: the point of the control is to move within one region, and a
     * rounding that put the top row a byte outside it would otherwise hand the
     * rest of the drag to its neighbour.
     */
    protected locatorEntry?: MappedRegion;

    /** Guards the poll against a read it has not finished yet. */
    protected reading = false;
    protected readAgain = false;

    /**
     * The address box, which is uncontrolled so that polling cannot overwrite
     * a half-typed address. Its value therefore lives in the DOM rather than
     * here, and is put back in step after each render — but only while nobody
     * is typing into it. See {@link onUpdateRequest}.
     */
    protected readonly addressInput = React.createRef<HTMLInputElement>();

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.MEMORY, source, instanceId);
        this.title.label = emulatorPanelLabel(EmulatorPanelType.MEMORY);
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.MEMORY);
        this.watches = this.readWatches();
    }

    // --- the map ---------------------------------------------------------

    /**
     * Lay the regions out, if what they are made of has changed.
     *
     * The ROM's extent is the only part that moves, and it moves when a ROM is
     * loaded; the VCU appears and disappears with the hardware gate. Anything
     * else would rebuild this ten times a second for nothing.
     */
    protected rebuildMap(): void {
        const romBytes = Math.max(0, this.source.romSize) * BYTES_PER_MBIT;
        const signature = `${romBytes}:${this.source.vbcHardwareActive}`;
        if (signature === this.mapSignature) {
            return;
        }
        const first = this.mapSignature === undefined;
        this.mapSignature = signature;

        // By address, so the list reads up the memory map — the VCU sits
        // between the hardware registers and cartridge expansion.
        const regions = (this.source.vbcHardwareActive
            ? [...VB_MEMORY_REGIONS, VCU_MEMORY_REGION]
            : [...VB_MEMORY_REGIONS]).sort((a, b) => a.address - b.address);

        let row = 0;
        this.map = [];
        for (const region of regions) {
            const mapped = region.address === VB_ROM_BASE ? romBytes : region.mapped;
            if (mapped <= 0) {
                // A region with nothing behind it is still offered in the map
                // bar, disabled; it is only the list it stays out of.
                continue;
            }
            const rows = Math.ceil(mapped / BYTES_PER_ROW);
            this.map.push({ region, mapped, rows, firstRow: row });
            row += rows + 1;
        }
        this.totalRows = row;

        // First time round, open where the panel was left.
        if (first && this.map.length > 0) {
            this.scrollToRow(this.rowOf(this.canonical(this.address) ?? this.map[0].region.address));
        }
    }

    /** The placed region an address falls in, by the three bits the bus decodes. */
    protected entryOf(address: number): MappedRegion | undefined {
        const region = (address >>> 24) & 7;
        return this.map.find(entry => ((entry.region.address >>> 24) & 7) === region);
    }

    /**
     * An address as the list holds it.
     *
     * Every region is mirrored across its 16 MB, so an address anywhere in one
     * names a byte the list already shows once — the interrupt vectors at
     * `0xFFFFFE00` are the top of the cartridge seen through region 7's mirror,
     * and typing them should land on those ROM bytes rather than on nothing.
     * Undefined for a region with nothing in it, which is the honest answer for
     * `0x03000000` on a machine that is not a VB Color.
     */
    protected canonical(address: number): number | undefined {
        const entry = this.entryOf(address);
        if (!entry || entry.mapped <= 0) {
            return undefined;
        }
        return (entry.region.address + ((address >>> 0) & 0x00ffffff) % entry.mapped) >>> 0;
    }

    /** What is at a row of the list. */
    protected rowAt(index: number): MemoryRow | undefined {
        for (const entry of this.map) {
            if (index >= entry.firstRow + 1 + entry.rows) {
                continue;
            }
            if (index < entry.firstRow) {
                return undefined;
            }
            if (index === entry.firstRow) {
                return { entry };
            }
            const offset = (index - entry.firstRow - 1) * BYTES_PER_ROW;
            return { entry, address: (entry.region.address + offset) >>> 0 };
        }
        return undefined;
    }

    /** The row holding an address, which has to be one the map places. */
    protected rowOf(address: number): number {
        const entry = this.entryOf(address);
        if (!entry) {
            return 0;
        }
        return entry.firstRow + 1 + Math.floor((address - entry.region.address) / BYTES_PER_ROW);
    }

    // --- the viewport ----------------------------------------------------

    protected rowsInView(): number {
        const height = this.viewportHeight || DEFAULT_VIEWPORT_ROWS * ROW_HEIGHT;
        return Math.max(1, Math.ceil(height / ROW_HEIGHT));
    }

    protected firstRenderedRow(): number {
        return Math.max(0, Math.floor(this.scrollTop / ROW_HEIGHT) - OVERSCAN);
    }

    protected renderedRows(): number {
        return this.rowsInView() + OVERSCAN * 2;
    }

    /** The first address actually on screen, which is what the map bar reads. */
    protected topAddress(): number | undefined {
        const first = Math.floor(this.scrollTop / ROW_HEIGHT);
        for (let row = first; row < Math.min(this.totalRows, first + this.rowsInView() + 1); row++) {
            const at = this.rowAt(row);
            if (at?.address !== undefined) {
                return at.address;
            }
        }
        return this.map[0]?.region.address;
    }

    protected scrollToRow(row: number): void {
        // A third of the way down rather than at the very top: an address
        // jumped to usually wants the bytes before it as much as the ones after.
        this.pendingScrollTop = Math.max(0, (row - Math.floor(this.rowsInView() / 3)) * ROW_HEIGHT);
    }

    /** Bring a row into view without moving if it is already there. */
    protected revealRow(row: number): void {
        const first = Math.ceil(this.scrollTop / ROW_HEIGHT);
        const last = Math.floor(
            (this.scrollTop + (this.viewportHeight || 0) - RULER_HEIGHT) / ROW_HEIGHT) - 1;
        if (row < first) {
            this.pendingScrollTop = row * ROW_HEIGHT;
        } else if (row > last) {
            this.pendingScrollTop = Math.max(0,
                RULER_HEIGHT + (row + 1) * ROW_HEIGHT - (this.viewportHeight || ROW_HEIGHT));
        }
    }

    /** Put a row directly under the ruler, which is where a scrubber aims. */
    protected pinRowToTop(row: number): void {
        const target = Math.max(0, row * ROW_HEIGHT);
        if (this.scroller) {
            this.scroller.scrollTop = target;
        } else {
            this.pendingScrollTop = target;
        }
    }

    /** The region the view is currently in, which both scrollbars read. */
    protected currentEntry(): MappedRegion | undefined {
        const top = this.topAddress();
        return top === undefined ? undefined : this.entryOf(top);
    }

    // --- the two scrollbars ----------------------------------------------
    //
    // Neither is the browser's. The vertical one is over the whole map, where
    // a native bar is useless: the list is a million pixels tall and the thumb
    // rounds to nothing, which is what perfect-scrollbar was already drawing
    // here — a rail with a zero-height thumb in it. Ours has a floor, and it
    // shows the regions as bands, so it says where in the machine you are and
    // not only how far down a list. The horizontal one is not a scrollbar over
    // content at all; it moves within the region the view is in, which is the
    // distance anybody actually wants to cover.

    /** Where the map rail's thumb sits, in pixels down a rail of `height`. */
    protected railThumb(height: number): { top: number, size: number, span: number } {
        const total = this.totalRows * ROW_HEIGHT;
        const size = Math.min(height,
            Math.max(MIN_THUMB, total > 0 ? (height * height) / total : height));
        const span = Math.max(0, height - size);
        const scrollable = Math.max(0, total - height);
        return { top: scrollable > 0 ? (this.scrollTop / scrollable) * span : 0, size, span };
    }

    protected grabRail(event: React.PointerEvent<HTMLDivElement>): void {
        const box = event.currentTarget.getBoundingClientRect();
        const { top, size } = this.railThumb(box.height);
        const at = event.clientY - box.top;
        // Taken hold of by the thumb, it is dragged from where it was held;
        // taken anywhere else, it jumps to the pointer and is held by its
        // middle — which is how every scrollbar with jump-to-click behaves.
        this.railGrab = at >= top && at < top + size ? at - top : size / 2;
        event.currentTarget.setPointerCapture(event.pointerId);
        this.scrubRail(box, event.clientY);
        this.update();
    }

    protected scrubRail(box: DOMRect, clientY: number): void {
        if (this.railGrab === undefined || !this.scroller) {
            return;
        }
        const { span } = this.railThumb(box.height);
        const scrollable = Math.max(0, this.totalRows * ROW_HEIGHT - box.height);
        const top = Math.max(0, Math.min(span, clientY - box.top - this.railGrab));
        // Straight at the element: the scroll event it fires is what redraws
        // the rows, so a drag stays as responsive as a wheel.
        this.scroller.scrollTop = span > 0 ? (top / span) * scrollable : 0;
    }

    /**
     * Where the region scrubber's thumb sits, in pixels across a track of
     * `width`, and how far it can travel.
     */
    protected locatorThumb(
        width: number, entry: MappedRegion
    ): { left: number, size: number, span: number, scrollable: number } {
        const visible = this.rowsInView() * BYTES_PER_ROW;
        const share = entry.mapped > 0 ? Math.min(1, visible / entry.mapped) : 1;
        const size = Math.min(width, Math.max(MIN_THUMB, share * width));
        const span = Math.max(0, width - size);
        const scrollable = Math.max(0, entry.mapped - visible);
        const top = this.topAddress();
        const offset = top === undefined ? 0 : top - entry.region.address;
        const left = scrollable > 0
            ? Math.max(0, Math.min(1, offset / scrollable)) * span
            : 0;
        return { left, size, span, scrollable };
    }

    protected grabLocator(event: React.PointerEvent<HTMLDivElement>): void {
        const entry = this.currentEntry();
        if (!entry) {
            return;
        }
        const box = event.currentTarget.getBoundingClientRect();
        const { left, size } = this.locatorThumb(box.width, entry);
        const at = event.clientX - box.left;
        this.locatorEntry = entry;
        this.locatorGrab = at >= left && at < left + size ? at - left : size / 2;
        event.currentTarget.setPointerCapture(event.pointerId);
        this.scrubLocator(box, event.clientX);
        this.update();
    }

    protected scrubLocator(box: DOMRect, clientX: number): void {
        const entry = this.locatorEntry;
        if (this.locatorGrab === undefined || !entry) {
            return;
        }
        const { span, scrollable } = this.locatorThumb(box.width, entry);
        const left = Math.max(0, Math.min(span, clientX - box.left - this.locatorGrab));
        const offset = span > 0 ? Math.round((left / span) * scrollable) : 0;
        this.pinRowToTop(this.rowOf(entry.region.address + offset));
    }

    /** Let go of whichever scrollbar was being dragged. */
    protected releaseDrag(event: React.PointerEvent<HTMLDivElement>): void {
        this.railGrab = undefined;
        this.locatorGrab = undefined;
        this.locatorEntry = undefined;
        if (event.currentTarget.hasPointerCapture(event.pointerId)) {
            event.currentTarget.releasePointerCapture(event.pointerId);
        }
        this.update();
    }

    protected readonly setScroller = (element: HTMLDivElement | null): void => {
        if (element === this.scroller) {
            return;
        }
        this.resize?.disconnect();
        this.resize = undefined;
        this.scroller = element ?? undefined;
        if (!element) {
            return;
        }
        this.viewportHeight = element.clientHeight;
        this.resize = new ResizeObserver(() => {
            if (this.scroller && this.scroller.clientHeight !== this.viewportHeight) {
                this.viewportHeight = this.scroller.clientHeight;
                this.update();
            }
        });
        this.resize.observe(element);
    };

    protected readonly setLocator = (element: HTMLDivElement | null): void => {
        this.locatorResize?.disconnect();
        this.locatorResize = undefined;
        if (!element) {
            return;
        }
        this.locatorWidth = element.clientWidth;
        this.locatorResize = new ResizeObserver(() => {
            if (element.clientWidth !== this.locatorWidth) {
                this.locatorWidth = element.clientWidth;
                this.update();
            }
        });
        this.locatorResize.observe(element);
    };

    protected onScrolled(element: HTMLDivElement): void {
        if (element.scrollTop === this.scrollTop) {
            return;
        }
        this.scrollTop = element.scrollTop;
        const top = this.topAddress();
        if (top !== undefined) {
            this.address = this.remember('address', top);
        }
        // Redraw immediately from what has already been read, and go and get
        // whatever has just come into view.
        this.update();
        this.poll();
    }

    protected onUpdateRequest(msg: Message): void {
        super.onUpdateRequest(msg);

        const scroller = this.scroller;
        const target = this.pendingScrollTop;
        if (scroller && target !== undefined) {
            this.pendingScrollTop = undefined;
            scroller.scrollTop = target;
            this.scrollTop = scroller.scrollTop;
            // Again after the frame: a jump made in the same breath as the map
            // growing — a ROM finishing loading — would otherwise be clamped to
            // the height the list had before the rows behind it existed.
            requestAnimationFrame(() => {
                if (this.scroller && this.scroller.scrollTop !== target) {
                    this.scroller.scrollTop = target;
                    this.scrollTop = this.scroller.scrollTop;
                    this.update();
                }
            });
        }

        const box = this.addressInput.current;
        if (box && box.ownerDocument.activeElement !== box) {
            const wanted = hex(this.selected ?? this.address, 8);
            if (box.value !== wanted) {
                box.value = wanted;
            }
        }
    }

    protected onBeforeDetach(msg: Message): void {
        this.resize?.disconnect();
        this.resize = undefined;
        this.locatorResize?.disconnect();
        this.locatorResize = undefined;
        // A keystroke still in the air would land on a panel that has gone.
        this.settleSearch.cancel();
        super.onBeforeDetach(msg);
    }

    // --- reading ---------------------------------------------------------

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.chunks = [];
            this.watchChunks = [];
            this.selectedBytes = undefined;
            this.mapSignature = undefined;
            this.update();
            return;
        }
        if (this.reading) {
            // Scrolling can ask faster than the reads come back. Remembering
            // that it asked is what stops a fling from settling on a window
            // that was never fetched.
            this.readAgain = true;
            return;
        }

        this.reading = true;
        try {
            do {
                this.readAgain = false;
                this.rebuildMap();
                await this.read(sim);
            } while (this.readAgain);
        } finally {
            this.reading = false;
        }
        this.update();
    }

    protected async read(sim: Sim): Promise<void> {
        const chunks: MemoryChunk[] = [];
        for (const run of this.visibleRuns()) {
            chunks.push({
                address: run.address,
                bytes: new Uint8Array(await sim.readMemory(run.address, run.length)),
            });
        }
        this.noteChanges(chunks);
        this.chunks = chunks;

        if (this.selected !== undefined) {
            this.selectedBytes = new Uint8Array(await sim.readMemory(this.selected, INSPECT_BYTES));
            // Only when the selection moves: naming it means the symbol table,
            // and for an object in a pool the whole heap as well.
            if (this.whereFor !== this.selected) {
                this.whereFor = this.selected;
                this.where = await this.describe(sim, this.selected);
            }
        } else {
            this.selectedBytes = undefined;
            this.where = undefined;
            this.whereFor = undefined;
        }

        const watchChunks: MemoryChunk[] = [];
        for (const run of this.watchRuns()) {
            watchChunks.push({
                address: run.address,
                bytes: new Uint8Array(await sim.readMemory(run.address, run.length)),
            });
        }
        this.watchChunks = watchChunks;
    }

    /** The rows on screen, as the fewest contiguous reads that cover them. */
    protected visibleRuns(): { address: number, length: number }[] {
        const runs: { address: number, length: number }[] = [];
        const first = this.firstRenderedRow();
        const last = Math.min(this.totalRows, first + this.renderedRows());
        for (let row = first; row < last; row++) {
            const at = this.rowAt(row);
            if (!at || at.address === undefined) {
                continue;
            }
            const remaining = at.entry.region.address + at.entry.mapped - at.address;
            const length = Math.min(BYTES_PER_ROW, remaining);
            const previous = runs[runs.length - 1];
            if (previous && previous.address + previous.length === at.address) {
                previous.length += length;
            } else {
                runs.push({ address: at.address, length });
            }
        }
        return runs;
    }

    /**
     * The watched addresses as reads.
     *
     * Coalesced, because watching half a dozen fields of one struct is the
     * usual case and six round trips a tick for bytes that are next to each
     * other would be six times the traffic for the same answer.
     */
    protected watchRuns(): { address: number, length: number }[] {
        const runs: { address: number, length: number }[] = [];
        for (const address of [...this.watches].sort((a, b) => a - b)) {
            const previous = runs[runs.length - 1];
            const end = address + INSPECT_BYTES;
            if (previous && address - (previous.address + previous.length) <= BYTES_PER_ROW * 4
                && (address >>> 24) === (previous.address >>> 24)) {
                previous.length = Math.max(previous.length, end - previous.address);
            } else {
                runs.push({ address, length: INSPECT_BYTES });
            }
        }
        return runs;
    }

    protected byteAt(address: number, chunks: MemoryChunk[] = this.chunks): number | undefined {
        for (const chunk of chunks) {
            const at = address - chunk.address;
            if (at >= 0 && at < chunk.bytes.length) {
                return chunk.bytes[at];
            }
        }
        return undefined;
    }

    /** Stamp the bytes that differ from what was on screen a tick ago. */
    protected noteChanges(next: MemoryChunk[]): void {
        const now = Date.now();
        for (const chunk of next) {
            for (let at = 0; at < chunk.bytes.length; at++) {
                const address = chunk.address + at;
                const before = this.byteAt(address);
                if (before !== undefined && before !== chunk.bytes[at]) {
                    this.changedAt.set(address, now);
                }
            }
        }
        for (const [address, when] of this.changedAt) {
            if (now - when > FLASH_MS) {
                this.changedAt.delete(address);
            }
        }
    }

    // --- naming ----------------------------------------------------------

    /**
     * What the build calls the byte under the cursor.
     *
     * Three answers, in the order they are worth having: the function it is
     * inside, for the cartridge; the data symbol it is inside, for everything
     * the linker named; and, for an address in WRAM that is neither, the live
     * object holding it and which of that object's fields it is. The last one
     * is the only one that has to read the machine, and the only reason this
     * is not run on every tick.
     */
    protected async describe(sim: Sim, address: number): Promise<MemoryWhere | undefined> {
        const symbols = await this.source.getSymbols();
        if (!symbols) {
            return undefined;
        }

        const romBytes = Math.max(0, this.source.romSize) * BYTES_PER_MBIT;
        if (((address >>> 24) & 7) === 7 && romBytes > 0) {
            const found = findFunctionAt(symbols, address, romBytes);
            if (found) {
                return {
                    owner: functionDisplayName(symbols, found.name),
                    offset: romOffsetOf(address, romBytes) - romOffsetOf(found.address, romBytes),
                };
            }
        }

        const data = findSymbolAt(symbols, address);
        if (data) {
            return { owner: data.symbol.name.replace(/^_/, ''), offset: data.offset };
        }

        return this.describeOccupant(sim, symbols, address);
    }

    /** The object in a pool block holding an address, and the field it is in. */
    protected async describeOccupant(
        sim: Sim, symbols: SymbolIndex, address: number
    ): Promise<MemoryWhere | undefined> {
        if (!isWram(address) || !symbols.memoryPool || symbols.structs.size === 0) {
            return undefined;
        }
        try {
            const region = new Uint8Array(
                await sim.readMemory(symbols.memoryPool.address, symbols.memoryPool.size));
            const layout = parseMemoryPoolLayout(symbols.memoryPool.address, region);
            // The same check the Actors panel makes, and for the same reason:
            // from another build every offset here would be wrong together.
            if (!layout || !symbolsMatchRunningBuild(layout, symbols.vTables)) {
                return undefined;
            }
            const block = readMemoryPoolBlocks(layout, region).find(candidate =>
                address >= candidate.objectAddress
                && address < candidate.address + candidate.blockSize);
            if (!block) {
                return undefined;
            }
            const className = symbols.vTables.get(block.vTable);
            if (className === undefined) {
                return undefined;
            }
            const offset = address - block.objectAddress;
            const struct = layoutFor(symbols, className, block.blockSize - BLOCK_HEADER_BYTES);
            return {
                owner: className,
                offset,
                field: struct ? findStructMemberAt(struct, offset)?.path : undefined,
            };
        } catch {
            // The heap is read out of the machine, which can be taken away
            // between the selection and this; the strip simply says less.
            return undefined;
        }
    }

    // --- going places ----------------------------------------------------

    protected goto(address: number, select = true): void {
        const canonical = this.canonical(address);
        if (canonical === undefined) {
            return;
        }
        this.address = this.remember('address', canonical);
        if (select) {
            this.selected = canonical;
            this.pending = undefined;
        }
        this.scrollToRow(this.rowOf(canonical));
        this.update();
        this.poll();
    }

    /**
     * Jump to whatever the address box holds, ignoring anything that is not an
     * address. Typing is how it is edited, so most of what passes through here
     * is half-finished and silently doing nothing is the useful response.
     */
    protected gotoTypedAddress(): void {
        const typed = this.addressInput.current?.value.trim().replace(/^0x/i, '') ?? '';
        // parseInt would take "12nonsense" as 0x12; nothing that is not
        // entirely hex digits was an address anyone meant to go to.
        if (!/^[0-9a-f]+$/i.test(typed)) {
            return;
        }
        this.goto(parseInt(typed, 16));
    }

    /**
     * Go to the top of a region, which is what the map bar asks for.
     *
     * Its caption row rather than its first byte, and pinned to the top
     * rather than set a third of the way down the way {@link goto} places an
     * address. A third of the way down is right for an address — what is
     * before it is context — but for the start of a region it would put the
     * top of the view in the region *above*, and the map bar reads the top of
     * the view. Pressing WRAM would light up Game Pak Expansion.
     */
    protected gotoRegion(region: VbMemoryRegion): void {
        const entry = this.map.find(placed => placed.region.address === region.address);
        if (!entry) {
            return;
        }
        this.address = this.remember('address', entry.region.address);
        this.pinRowToTop(entry.firstRow);
        this.update();
        this.poll();
    }

    protected select(address: number): void {
        this.selected = address;
        this.pending = undefined;
        this.address = this.remember('address', address);
        this.update();
        this.poll();
    }

    /** Move the selection by bytes, stopping at the ends of its region. */
    protected moveSelection(by: number): void {
        if (this.selected === undefined) {
            return;
        }
        const entry = this.entryOf(this.selected);
        if (!entry) {
            return;
        }
        const low = entry.region.address;
        const high = low + entry.mapped - 1;
        const next = Math.min(high, Math.max(low, this.selected + by));
        this.selected = next >>> 0;
        this.pending = undefined;
        this.address = this.remember('address', this.selected);
        this.revealRow(this.rowOf(this.selected));
        this.update();
        this.poll();
    }

    // --- editing ---------------------------------------------------------

    /**
     * Type over the selected byte, a nibble at a time.
     *
     * Two digits make a byte, so the first is held and shown in place of the
     * low nibble until the second arrives — which is what makes it clear a
     * write is half-entered rather than already made.
     */
    protected async typeNibble(digit: number): Promise<void> {
        const address = this.selected;
        if (address === undefined) {
            return;
        }
        if (this.pending && this.pending.address === address) {
            const value = ((this.pending.nibble << 4) | digit) & 0xff;
            this.pending = undefined;
            await this.source.write(address, [value]);
            this.moveSelection(1);
            return;
        }
        this.pending = { address, nibble: digit };
        this.update();
    }

    protected onRowsKeyDown(event: React.KeyboardEvent): void {
        const handled = (): void => {
            event.preventDefault();
            // The emulator listens for keys on an ancestor of this node and
            // treats anything that is not a field being typed into as game
            // input — a hex digit here would otherwise press a button too.
            event.stopPropagation();
        };

        if (event.ctrlKey || event.metaKey || event.altKey) {
            return;
        }

        switch (event.key) {
            case 'ArrowLeft': handled(); this.moveSelection(-1); return;
            case 'ArrowRight': handled(); this.moveSelection(1); return;
            case 'ArrowUp': handled(); this.moveSelection(-BYTES_PER_ROW); return;
            case 'ArrowDown': handled(); this.moveSelection(BYTES_PER_ROW); return;
            case 'PageUp': handled(); this.moveSelection(-BYTES_PER_ROW * this.rowsInView()); return;
            case 'PageDown': handled(); this.moveSelection(BYTES_PER_ROW * this.rowsInView()); return;
            case 'Escape':
                if (this.pending) {
                    handled();
                    this.pending = undefined;
                    this.update();
                }
                return;
        }

        if (/^[0-9a-fA-F]$/.test(event.key)) {
            handled();
            this.typeNibble(parseInt(event.key, 16));
        }
    }

    // --- watches ---------------------------------------------------------

    protected readWatches(): number[] {
        return this.remembered('watches', '')
            .split(',')
            .map(text => parseInt(text, 16))
            .filter(address => Number.isFinite(address))
            .map(address => address >>> 0)
            .slice(0, MAX_WATCHES);
    }

    protected setWatches(watches: number[]): void {
        this.watches = watches;
        this.remember('watches', watches.map(address => hex(address, 8)).join(','));
        this.update();
        this.poll();
    }

    protected toggleWatch(address: number): void {
        if (this.watches.includes(address)) {
            this.setWatches(this.watches.filter(watched => watched !== address));
        } else if (this.watches.length < MAX_WATCHES) {
            this.setWatches([...this.watches, address]);
        }
    }

    // --- searching -------------------------------------------------------

    /**
     * What to look for, read as bytes where it can be and as text otherwise.
     *
     * Hex wins a tie: in a hex dump `2A` is far more often the byte than the
     * two letters. Quotes force the other reading.
     *
     * Text is matched without regard to case, which is what somebody typing a
     * word into a search box means by it — and the only reading that is any
     * use against a machine where the same string turns up shouted in a ROM
     * header and in mixed case in a message. Bytes are matched exactly: `41`
     * asked for that byte, not for either letter it might spell.
     */
    protected parseNeedle(text: string): MemoryNeedle | undefined {
        const trimmed = text.trim();
        if (trimmed.length === 0) {
            return undefined;
        }
        const quoted = /^"(.*)"$/.exec(trimmed) ?? /^'(.*)'$/.exec(trimmed);
        if (quoted) {
            return quoted[1].length > 0 ? textNeedle(quoted[1]) : undefined;
        }
        const digits = trimmed.replace(/^0x/i, '').replace(/\s+/g, '');
        if (/^[0-9a-f]+$/i.test(digits) && digits.length % 2 === 0) {
            const bytes = new Uint8Array(digits.length / 2);
            for (let at = 0; at < bytes.length; at++) {
                bytes[at] = parseInt(digits.slice(at * 2, at * 2 + 2), 16);
            }
            return { bytes, folded: false };
        }
        return textNeedle(trimmed);
    }

    /**
     * The whole map once round, starting just past where the cursor is.
     *
     * Regions are not contiguous, so a search is a walk over segments rather
     * than one range — and the segment it started in has to come round again
     * at the end, for the part of it that was behind the cursor.
     */
    protected searchSegments(from: number): { address: number, end: number }[] {
        const entry = this.entryOf(from) ?? this.map[0];
        if (!entry) {
            return [];
        }
        const start = this.map.indexOf(entry);
        const segments: { address: number, end: number }[] = [
            { address: from, end: entry.region.address + entry.mapped },
        ];
        for (let step = 1; step < this.map.length; step++) {
            const next = this.map[(start + step) % this.map.length];
            segments.push({ address: next.region.address, end: next.region.address + next.mapped });
        }
        segments.push({ address: entry.region.address, end: from });
        return segments.filter(segment => segment.end > segment.address);
    }

    /** Empty the box, which is the one thing that writes to it from here. */
    protected clearSearch(): void {
        this.settleSearch.cancel();
        this.search = '';
        this.searchMissed = false;
        if (this.searchInput.current) {
            this.searchInput.current.value = '';
        }
        this.update();
    }

    protected async findNext(): Promise<void> {
        const sim = this.source.sim;
        const needle = this.parseNeedle(this.search);
        if (!sim || !needle || needle.bytes.length === 0 || this.searching) {
            return;
        }
        this.searching = true;
        this.searchMissed = false;
        this.update();
        try {
            const from = ((this.selected ?? this.address ?? 0) + 1) >>> 0;
            for (const segment of this.searchSegments(from)) {
                const found = await this.scan(sim, segment, needle);
                if (found !== undefined) {
                    this.goto(found);
                    return;
                }
            }
            this.searchMissed = true;
        } catch (error) {
            // Nothing found is what the box says either way; the reason goes
            // where a reason can be read.
            console.error('[emulator] the memory search could not finish:', error);
            this.searchMissed = true;
        } finally {
            this.searching = false;
            this.update();
        }
    }

    /** One segment, read a window at a time with the needle's overlap kept. */
    protected async scan(
        sim: Sim, segment: { address: number, end: number }, needle: MemoryNeedle
    ): Promise<number | undefined> {
        const wanted = needle.bytes;
        // A match can straddle two windows, so each one reaches back over the
        // last needle-worth of the one before it — the overlap comes out of
        // the step rather than being added to the window, which may not grow.
        const step = Math.max(1, SEARCH_WINDOW - (wanted.length - 1));
        for (let at = segment.address; at < segment.end; at += step) {
            const length = Math.min(SEARCH_WINDOW, segment.end - at);
            if (length < wanted.length) {
                return undefined;
            }
            const window = new Uint8Array(await sim.readMemory(at, length));
            if (needle.folded) {
                // Folded here rather than in the comparison: a window is read
                // once and looked at as many times as it has positions, so
                // this is one pass instead of one per position.
                for (let byte = 0; byte < window.length; byte++) {
                    window[byte] = fold(window[byte]);
                }
            }
            for (let start = 0; start + wanted.length <= window.length; start++) {
                let matched = true;
                for (let byte = 0; byte < wanted.length; byte++) {
                    if (window[start + byte] !== wanted[byte]) {
                        matched = false;
                        break;
                    }
                }
                if (matched) {
                    return (at + start) >>> 0;
                }
            }
        }
        return undefined;
    }

    // --- rendering -------------------------------------------------------

    protected render(): React.ReactNode {
        if (!this.source.sim) {
            return <EmptyContainer
                title={nls.localize('vueport/debug/panels/general/notRunning', 'The emulator is not running.')}
                icon={<Plug size={32} />}
            />;
        }

        return <div
            className='vp-memory'
            style={{
                '--vp-memory-row': `${ROW_HEIGHT}px`,
                '--vp-memory-gutter': `${SCROLLBAR_GUTTER}px`,
            } as React.CSSProperties}
        >
            {this.renderMapBar()}
            {this.renderRows()}
            {this.renderInspector()}
            {this.renderWatches()}
        </div>;
    }

    /** Which region the view is in, and how far through it. */
    /**
     * Which region the view is in, and a scrubber for moving within it.
     *
     * The horizontal counterpart to the map rail: that one covers the whole
     * machine, this one covers the region under it, which is the distance a
     * megabyte of cartridge makes awkward to cross any other way.
     */
    protected renderMapBar(): React.ReactNode {
        const top = this.topAddress();
        const here = top !== undefined ? this.entryOf(top) : undefined;
        const regions = this.source.vbcHardwareActive
            ? [...VB_MEMORY_REGIONS, VCU_MEMORY_REGION].sort((a, b) => a.address - b.address)
            : VB_MEMORY_REGIONS;

        const width = this.locatorWidth || 1;
        const thumb = here ? this.locatorThumb(width, here) : undefined;
        const offset = here && top !== undefined ? top - here.region.address : 0;

        return <div className='vp-memory-map'>
            {/* A wrapper of its own: the control is a styled component whose
                class names are generated, so this is the only stable handle on
                the regions it offers — which is what the VCU aperture's
                appearing and disappearing with the hardware is checked by. */}
            <div className='vp-memory-regions'>
                <RadioSelect
                    fitSpace
                    options={regions.map(region => ({
                        value: region.short,
                        label: region.short,
                        tooltip: region.label,
                        // Offered but not reachable: nothing has been laid out for
                        // it, which for the cartridge means no ROM is loaded.
                        disabled: !this.map.some(entry => entry.region.address === region.address),
                    }))}
                    defaultValue={here?.region.short ?? ''}
                    allowBlank
                    onChange={options => {
                        const picked = regions.find(region => region.short === options[0]?.value);
                        if (picked) {
                            this.gotoRegion(picked);
                        }
                    }}
                />
                {this.renderToolbar()}
            </div>
            <div className='vp-memory-locator'>
                <div
                    className={`vp-memory-locator-track${this.locatorGrab !== undefined ? ' dragging' : ''}`}
                    ref={this.setLocator}
                    role='scrollbar'
                    aria-orientation='horizontal'
                    aria-label={nls.localize(
                        'vueport/debug/panels/memory/scrubRegion', 'Position within the region')}
                    onPointerDown={e => this.grabLocator(e)}
                    onPointerMove={e => {
                        if (this.locatorGrab !== undefined) {
                            this.scrubLocator(e.currentTarget.getBoundingClientRect(), e.clientX);
                        }
                    }}
                    onPointerUp={e => this.releaseDrag(e)}
                    onPointerCancel={e => this.releaseDrag(e)}
                >
                    {thumb && <div
                        className='vp-memory-locator-thumb'
                        style={{ left: `${thumb.left}px`, width: `${thumb.size}px` }}
                    />}
                </div>
                <span className='vp-memory-locator-text'>
                    {here
                        ? nls.localize('vueport/debug/panels/memory/withinRegion',
                            '0x{0} of 0x{1} mapped', hex(offset, 6), hex(here.mapped, 6))
                        : nls.localize('vueport/debug/panels/memory/nothingMapped', 'Nothing mapped')}
                </span>
            </div>
        </div>;
    }

    /**
     * The map rail: the whole address space as one bar, the regions as bands
     * in it, and a thumb for the part on screen.
     */
    protected renderRail(): React.ReactNode {
        if (this.totalRows === 0) {
            return undefined;
        }
        const height = this.viewportHeight || 1;
        const { top, size: thumbHeight } = this.railThumb(height);
        // Once, not once per band: it walks the rows to find the top address.
        const here = this.currentEntry();
        return <div
            className={`vp-memory-rail${this.railGrab !== undefined ? ' dragging' : ''}`}
            role='scrollbar'
            aria-orientation='vertical'
            aria-label={nls.localize('vueport/debug/panels/memory/scrubMap', 'Position in the memory map')}
            onPointerDown={e => this.grabRail(e)}
            onPointerMove={e => {
                if (this.railGrab !== undefined) {
                    this.scrubRail(e.currentTarget.getBoundingClientRect(), e.clientY);
                }
            }}
            onPointerUp={e => this.releaseDrag(e)}
            onPointerCancel={e => this.releaseDrag(e)}
        >
            {this.map.map((entry, index) => <div
                key={entry.region.short}
                className={`vp-memory-rail-band${index % 2 === 1 ? ' alternate' : ''}${entry === here ? ' here' : ''}`}
                style={{
                    top: `${(entry.firstRow / this.totalRows) * 100}%`,
                    height: `${((entry.rows + 1) / this.totalRows) * 100}%`,
                }}
                title={`${entry.region.label} · ${sizeOf(entry.mapped)} mapped`}
            />)}
            <div
                className='vp-memory-rail-thumb'
                style={{ top: `${top}px`, height: `${thumbHeight}px` }}
            />
        </div>;
    }

    protected renderToolbar(): React.ReactNode {
        const watched = this.selected !== undefined && this.watches.includes(this.selected);
        return <div className='vp-memory-toolbar'>
            <input
                ref={this.addressInput}
                className='vp-input vp-memory-address'
                spellCheck={false}
                aria-label={nls.localize('vueport/debug/panels/memory/address', 'Address')}
                defaultValue={hex(this.address, 8)}
                onKeyDown={e => {
                    if (e.key === 'Enter') {
                        this.gotoTypedAddress();
                    }
                }}
            />
            <button
                className='vp-button secondary'
                title={nls.localize('vueport/debug/panels/memory/goTo', 'Go to address')}
                onClick={() => this.gotoTypedAddress()}
            >
                <ArrowUDownLeft size={14} />
            </button>

            <div className={`vp-panel-filter vp-memory-search${this.searchMissed ? ' missed' : ''}`}>
                <MagnifyingGlass size={15} />
                <input
                    ref={this.searchInput}
                    type='text'
                    spellCheck={false}
                    defaultValue={this.search}
                    placeholder={nls.localize('vueport/debug/panels/memory/search', 'Search bytes or text')}
                    aria-label={nls.localize('vueport/debug/panels/memory/search', 'Search bytes or text')}
                    onChange={e => this.settleSearch(e.target.value)}
                    onKeyDown={e => {
                        if (e.key === 'Enter') {
                            // Asked for outright, so there is nothing left to
                            // wait for: take the box as it stands and go.
                            this.settleSearch.cancel();
                            this.search = e.currentTarget.value;
                            this.findNext();
                        }
                    }}
                />
                {this.search.length > 0 &&
                    <button
                        type='button'
                        className='vp-panel-filter-clear'
                        aria-label={nls.localize('vueport/general/clear', 'Clear')}
                        onClick={() => this.clearSearch()}
                    >
                        <X size={14} />
                    </button>}
            </div>
            <button
                className='vp-button secondary'
                disabled={this.searching || this.parseNeedle(this.search) === undefined}
                title={nls.localize('vueport/debug/panels/memory/findNext', 'Find next, wrapping around the map')}
                onClick={() => this.findNext()}
            >
                {nls.localize('vueport/debug/panels/memory/find', 'Find')}
            </button>

            <button
                className={`vp-button secondary${watched ? ' vp-memory-watching' : ''}`}
                disabled={this.selected === undefined
                    || (!watched && this.watches.length >= MAX_WATCHES)}
                title={nls.localize('vueport/debug/panels/memory/watch', 'Pin the selected address to the watch list')}
                onClick={() => this.selected !== undefined && this.toggleWatch(this.selected)}
            >
                <PushPin size={14} weight={watched ? 'fill' : 'regular'} />
                {nls.localize('vueport/debug/panels/memory/watchShort', 'Watch')}
            </button>
        </div>;
    }

    protected renderRows(): React.ReactNode {
        const first = this.firstRenderedRow();
        const count = Math.min(this.renderedRows(), Math.max(0, this.totalRows - first));
        const rows: React.ReactNode[] = [];
        for (let row = first; row < first + count; row++) {
            rows.push(this.renderRow(row));
        }

        return <div className='vp-memory-dump'>
            {/* The scroller is deliberately not marked `vp-scroll`:
                perfect-scrollbar would take it over and draw a thumb whose
                height rounds to zero over a list this tall, which is the
                scrollbar this panel was missing. The map rail beside it is
                the vertical scrollbar instead, and the clip is what keeps the
                native one it still has out of sight — see the stylesheet. */}
            <div className='vp-memory-clip'>
                <div
                    className='vp-memory-scroll'
                    ref={this.setScroller}
                    tabIndex={0}
                    onScroll={e => this.onScrolled(e.currentTarget)}
                    onKeyDown={e => this.onRowsKeyDown(e)}
                >
                    {this.renderRuler()}
                    <div
                        className='vp-memory-spacer'
                        style={{ height: `${this.totalRows * ROW_HEIGHT}px` }}
                    >
                        <div
                            className='vp-memory-viewport'
                            style={{ transform: `translateY(${first * ROW_HEIGHT}px)` }}
                        >
                            {rows}
                        </div>
                    </div>
                </div>
            </div>
            {this.renderRail()}
        </div>;
    }

    /**
     * The column ruler, which stays at the top of the list.
     *
     * Built out of the same three parts a row is, so the digits sit over the
     * columns they number without either side knowing a width.
     */
    protected renderRuler(): React.ReactNode {
        return <div className='vp-memory-row vp-memory-ruler'>
            <span className='address'>
                {nls.localize('vueport/debug/panels/memory/addressColumn', 'ADDRESS')}
            </span>
            <span className='bytes'>
                {Array.from({ length: BYTES_PER_ROW }, (unused, column) =>
                    <span
                        key={column}
                        className={`byte${column % 4 === 3 ? ' group' : ''}`}
                    >{column.toString(16).toUpperCase()}</span>)}
            </span>
            <span className='ascii'>
                {nls.localize('vueport/debug/panels/memory/asciiColumn', 'ASCII')}
            </span>
        </div>;
    }

    protected renderRow(row: number): React.ReactNode {
        const at = this.rowAt(row);
        if (!at) {
            return <div className='vp-memory-row' key={row} />;
        }
        if (at.address === undefined) {
            const { region, mapped } = at.entry;
            return <div className='vp-memory-row vp-memory-caption' key={row}>
                <span className='name'>{region.label}</span>
                {/* The region, then what of it answers. Both, because the bus
                    gives every region 16 MB and only a fraction of that is
                    ever anything but a mirror — a caption with one number
                    would be saying the wrong one whichever it picked. */}
                <span className='range'>
                    {hex(region.address, 8)}–{hex(region.address + VB_REGION_BYTES - 1, 8)}
                </span>
                <span className='mapped'>
                    {'• '}
                    {mapped < VB_REGION_BYTES
                        ? nls.localize('vueport/debug/panels/memory/mappedAndMirrored',
                            '{0} mapped, mirrored across the rest', sizeOf(mapped))
                        : nls.localize('vueport/debug/panels/memory/allMapped', '{0} mapped', sizeOf(mapped))}
                </span>
            </div>;
        }

        const base = at.address;
        const limit = at.entry.region.address + at.entry.mapped;
        const now = Date.now();

        const cells: React.ReactNode[] = [];
        const characters: React.ReactNode[] = [];
        for (let column = 0; column < BYTES_PER_ROW; column++) {
            const address = base + column;
            const beyond = address >= limit;
            const value = beyond ? undefined : this.byteAt(address);
            const selected = address === this.selected;
            const editing = this.pending?.address === address;
            const changed = this.changedAt.has(address) && now - this.changedAt.get(address)! < FLASH_MS;
            const state = [
                'byte',
                column % 4 === 3 ? 'group' : '',
                beyond ? 'beyond' : '',
                selected ? 'selected' : '',
                editing ? 'editing' : '',
                changed ? 'changed' : '',
                value === undefined && !beyond ? 'unread' : '',
            ].filter(Boolean).join(' ');

            cells.push(<span
                key={column}
                className={state}
                onMouseDown={beyond ? undefined : () => this.select(address)}
            >
                {beyond ? '' : editing
                    ? `${this.pending!.nibble.toString(16).toUpperCase()}_`
                    : value === undefined ? '··' : hex(value, 2)}
            </span>);

            characters.push(<span
                key={column}
                className={`char${selected ? ' selected' : ''}${changed ? ' changed' : ''}`}
                onMouseDown={beyond ? undefined : () => this.select(address)}
            >
                {value !== undefined && value >= 0x20 && value < 0x7f
                    ? String.fromCharCode(value)
                    : beyond ? ' ' : '.'}
            </span>);
        }

        return <div className='vp-memory-row' key={row}>
            <span className='address'>{hex(base, 8)}</span>
            <span className='bytes'>{cells}</span>
            <span className='ascii'>{characters}</span>
        </div>;
    }

    /** The selected byte, read every way it might have been meant. */
    protected renderInspector(): React.ReactNode {
        const address = this.selected;
        const bytes = this.selectedBytes;
        if (address === undefined || !bytes || bytes.length < INSPECT_BYTES) {
            return <div className='vp-memory-inspector empty'>
                {nls.localize('vueport/debug/panels/memory/pickAByte',
                    'Pick a byte to read it as a number, or type over it to write.')}
            </div>;
        }

        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const u8 = view.getUint8(0);
        const s16 = view.getInt16(0, true);
        const readings: [string, string][] = [
            ['u8', `${u8}`],
            ['s8', `${view.getInt8(0)}`],
            ['u16', `${view.getUint16(0, true)}`],
            ['s16', `${s16}`],
            ['u32', `${view.getUint32(0, true)}`],
            ['s32', `${view.getInt32(0, true)}`],
            // The engine's fixed point: sixteen bits with six of them
            // fractional, which is what every position and speed in a
            // VUEngine game is stored as.
            ['fix10.6', (s16 / 64).toFixed(3)],
        ];

        return <div className='vp-memory-inspector'>
            <code className='at'>{hex(address, 8)}</code>
            {readings.map(([name, text]) =>
                <span className='reading' key={name}><i>{name}</i>{text}</span>)}
            {this.where && <span className='where'>
                {nls.localize('vueport/debug/panels/memory/in', 'in')}
                {' '}<b>{this.where.owner}</b>
                {this.where.offset > 0 && <> +0x{hex(this.where.offset, 2)}</>}
                {this.where.field && <> · <em>{this.where.field}</em></>}
            </span>}
        </div>;
    }

    protected renderWatches(): React.ReactNode {
        if (this.watches.length === 0) {
            return undefined;
        }
        return <div className='vp-memory-watches'>
            {this.watches.map(address => {
                const low = this.byteAt(address, this.watchChunks);
                const high = this.byteAt(address + 1, this.watchChunks);
                return <div className='vp-memory-watch' key={address}>
                    <button
                        className='vp-memory-watch-address'
                        title={nls.localize('vueport/debug/panels/memory/goToWatch', 'Go to this address')}
                        onClick={() => this.goto(address)}
                    >
                        {hex(address, 8)}
                    </button>
                    <code className='vp-memory-watch-byte'>
                        {low === undefined ? '··' : hex(low, 2)}
                    </code>
                    <code className='vp-memory-watch-word'>
                        {low === undefined || high === undefined
                            ? '····'
                            : hex(low | (high << 8), 4)}
                    </code>
                    <button
                        className='vp-memory-watch-remove'
                        aria-label={nls.localize('vueport/debug/panels/memory/unwatch', 'Stop watching')}
                        onClick={() => this.toggleWatch(address)}
                    >
                        <X size={12} />
                    </button>
                </div>;
            })}
        </div>;
    }
}
