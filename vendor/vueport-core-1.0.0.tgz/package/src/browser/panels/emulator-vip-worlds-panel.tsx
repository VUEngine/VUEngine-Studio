import { Plug, Warning } from '@phosphor-icons/react';
import { nls } from '../../common/emulator-nls';
import * as React from 'react';
import RadioSelect from '../components/kit/RadioSelect';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Sim } from '../core/vb-core';
import { arrowKeysTaken, EmulatorPanelType, hex, DebugSource, Panel } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import { VipCanvas } from './emulator-vip-canvas';
import { control, field, numberInput, stacked } from './emulator-vip-detail';
import {
    decodeVipObject,
    decodeVipWorld,
    encodeVipWorldHead,
    forEachVipObjectPixel,
    forEachVipWorldPixel,
    sameVipBytes,
    VIP_BGMAP_BYTES,
    VIP_BGMAP_COUNT,
    VIP_BGMAP_PALETTES,
    VIP_CHAR_SEGMENT_BYTES,
    VIP_CHAR_SEGMENTS,
    VIP_FRAME_BUFFER_HEIGHT,
    VIP_FRAME_BUFFER_WIDTH,
    VIP_GENERIC_PALETTE_INTENSITIES,
    VIP_GRAPHICS_POLL_HZ,
    VIP_HBIAS_ENTRY_BYTES,
    VIP_OAM_BASE,
    VIP_OAM_BLOCK_BYTES,
    VIP_OBJECT_BYTES,
    VIP_OBJECT_COUNT,
    VIP_OBJECT_PALETTES,
    VIP_REGISTER_BASE,
    VIP_REGISTER_BLOCK_BYTES,
    VIP_WORLD_BASE,
    VIP_WORLD_BLOCK_BYTES,
    VIP_WORLD_BYTES,
    VIP_WORLD_COUNT,
    VIP_WORLD_MODE_NAMES,
    vipBgMapAddress,
    VipCharacters,
    vipCharSegmentAddress,
    VipEye,
    vipHBiasRow,
    vipIntensitiesForRegister,
    VipIntensityWatcher,
    vipObjectGroupForWorld,
    vipObjectGroupRange,
    vipParamRows,
    vipParamTableAddress,
    vipParamTableBytes,
    VipWorld,
    vipWorldAddress,
    vipWorldExtents,
    VipWorldField,
    VipWorldMap,
    VipWorldMode,
} from './emulator-vip-memory';
import Select from '../components/kit/Select';
import Switch from '../components/kit/Switch';

/** The preview is screen-sized, so it needs less zoom than a tile atlas does. */
const MAX_PREVIEW_ZOOM = 4;

/** A halfword read as signed, which is how the position fields are decoded. */
const SIGNED_MIN = -0x8000;
const SIGNED_MAX = 0x7fff;
/** ...and as unsigned, which is how the size and param fields are. */
const UNSIGNED_MAX = 0xffff;

/**
 * The param register's low four bits are masked off when the engine writes it
 * (`WORLD_PARAM` in `world.h`), so the table it points at moves 32 bytes at a
 * time.
 */
const PARAM_STEP = 0x10;

/**
 * What the preview draws: the selected world on its own, or the frame it is
 * part of.
 *
 * Solo answers "what is in this world", Context answers "where is it in the
 * picture, and what is in front of it" — the second of which is what a world
 * that cannot be found on screen needs, since the preview then shows it being
 * covered rather than showing nothing at all.
 */
type WorldPreviewMode = 'solo' | 'context';

/**
 * How far the worlds around the selected one are faded, and they lose the
 * hardware's red with it.
 *
 * The same treatment, and the same factor, as the characters a filter leaves
 * out in the Characters panel: faint enough that the selected world reads as
 * the subject, strong enough that what surrounds it is still legible. Gray as
 * well as faint because fading alone would put a neighbouring world and a
 * dark part of the selected one on one scale.
 */
const CONTEXT_FACTOR = 0.18;

/**
 * The VIP's 32 world attribute entries.
 *
 * Three columns, all decoded straight out of world attribute memory: the
 * thirty-two worlds in drawing order, the selected one's fields to read and
 * edit, and a preview of what that world alone puts on screen. Rendering that
 * preview is what makes this panel read character and BGMap memory too; the
 * list and the fields need neither.
 */
export class WorldsPanel extends Panel {

    protected error?: string;
    protected registers?: DataView;
    protected worldBytes?: Uint8Array;
    protected charSegments: (Uint8Array | undefined)[] = [];
    /** Indexed by absolute BGMap segment; only the ones the world spans are read. */
    protected bgMapSegments: (Uint8Array | undefined)[] = [];
    /** The H-bias or Affine tables of the worlds being drawn, by world index. */
    protected paramTables: (Uint8Array | undefined)[] = [];
    /** Object attribute memory, read only while an OBJECT world is drawn. */
    protected oamBytes?: Uint8Array;

    /**
     * The world the fields and the preview describe. There is always one:
     * drawing starts at world 31, so that is where the panel opens.
     */
    protected selected = VIP_WORLD_COUNT - 1;
    protected hbiasRow = 0;
    protected eye = this.remembered('eye', 'left') as VipEye;
    protected previewMode = this.remembered('previewMode', 'context') as WorldPreviewMode;
    protected zoom = this.remembered('zoom', 1);
    /**
     * Whether the preview shades the pixel values with an even ramp instead
     * of the palette registers the game has set up.
     *
     * Off: the preview now resolves the brightness registers the way the core
     * does, so with the real palettes it looks like the picture on screen —
     * which is what the world is being compared against. The even ramp is for
     * reading the tile data itself, palettes and fades taken out of it.
     */
    protected showGenericPalette = this.remembered('showGenericPalette', false);
    /**
     * Whether the panel keeps to the worlds the VIP actually draws: the list
     * stops before the world that ends the frame, and Context leaves out
     * that world, everything past it, and whatever is switched off for the
     * eye being shown.
     *
     * On, because the question the panel usually answers is what the
     * hardware puts on screen. Turning it off is for the times the answer is
     * that it puts nothing there.
     */
    protected showOnlyDrawn = this.remembered('showOnlyDrawn', true);
    protected showExtents = this.remembered('showExtents', true);

    protected image?: ImageData;
    protected dirty = true;
    protected readonly intensityWatcher = new VipIntensityWatcher();

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.VIP_WORLDS, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/worlds/title', 'Worlds');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VIP_WORLDS);
        // The three columns each scroll on their own, so the panel's own
        // scrolling is switched off and the layout is hung on this class,
        // which the BGMaps panel wears too — see the stylesheet.
        this.addClass('vp-vip-panel');
    }

    protected pollHz(): number {
        return VIP_GRAPHICS_POLL_HZ;
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.registers = undefined;
            this.worldBytes = undefined;
            this.charSegments = [];
            this.bgMapSegments = [];
            this.paramTables = [];
            this.oamBytes = undefined;
            this.image = undefined;
            this.update();
            return;
        }

        try {
            this.registers = new DataView(await sim.readMemory(VIP_REGISTER_BASE, VIP_REGISTER_BLOCK_BYTES));

            const worldBytes = new Uint8Array(await sim.readMemory(VIP_WORLD_BASE, VIP_WORLD_BLOCK_BYTES));
            if (!sameVipBytes(worldBytes, this.worldBytes)) {
                this.worldBytes = worldBytes;
                this.dirty = true;
            }

            // Which memory the preview needs follows from the worlds that
            // were just read, so this is a second round of reads rather than
            // part of the first.
            await this.readSources(sim);

            if (this.intensityWatcher.changed(this.registers)) {
                this.dirty = true;
            }
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }

        if (this.dirty && this.registers) {
            this.image = this.rasterize(this.registers);
            this.dirty = false;
        }
        this.update();
    }

    /**
     * All thirty-two worlds, in the order the VIP draws them: 31 first, since
     * that is the first one the hardware considers.
     */
    protected allWorlds(): VipWorld[] {
        const bytes = this.worldBytes;
        if (!bytes) {
            return [];
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return Array.from({ length: VIP_WORLD_COUNT }, (unused, position) => {
            const index = VIP_WORLD_COUNT - 1 - position;
            return decodeVipWorld(view, index, index * VIP_WORLD_BYTES);
        });
    }

    /**
     * The worlds the list shows: all of them, or the ones before the world
     * that ends the frame.
     *
     * That world is left out with the rest: the End flag stops drawing at it
     * rather than after it, so the VIP never draws the world carrying it,
     * and from there down there is nothing on screen to look at unless it is
     * being looked for.
     */
    protected listedWorlds(): VipWorld[] {
        const worlds = this.allWorlds();
        const end = worlds.findIndex(world => world.end);
        return this.showOnlyDrawn && end >= 0 ? worlds.slice(0, end) : worlds;
    }

    /**
     * The worlds the preview draws, in the order the VIP draws them.
     *
     * Solo is the selected world alone, whether or not the hardware would
     * draw it — a world switched off is exactly the one worth looking at.
     * Context is what the list holds, which is the same question asked of
     * the same switch.
     */
    protected drawnWorlds(): VipWorld[] {
        if (this.previewMode === 'solo') {
            const world = this.world();
            return world ? [world] : [];
        }
        return this.listedWorlds();
    }

    /**
     * The worlds whose memory has to be read: the ones the preview draws, and
     * the selected one whether or not it is among them.
     *
     * A world past the one that ends the frame is not drawn in Context, but
     * its fields are still what the panel is showing — the H-bias table
     * beside them would otherwise read as zeros.
     */
    protected sourceWorlds(): VipWorld[] {
        const worlds = this.drawnWorlds();
        const selected = worlds.some(world => world.index === this.selected) ? undefined : this.world();
        return selected ? [...worlds, selected] : worlds;
    }

    /** Read the character, BGMap, param and object memory the preview draws from. */
    protected async readSources(sim: Sim): Promise<void> {
        const sources = this.sourceWorlds();
        if (sources.length === 0) {
            this.charSegments = [];
            this.bgMapSegments = [];
            this.paramTables = [];
            this.oamBytes = undefined;
            return;
        }

        // An OBJECT world draws from OAM under the SPT registers rather than
        // from a map of its own, so the maps and the param tables are read
        // for the rest of them. Characters are read for both: the objects are
        // made of them too.
        const worlds = sources.filter(world => world.mode !== VipWorldMode.OBJECT);

        const segments = await Promise.all(VIP_CHAR_SEGMENTS.map(
            (unused, index) => sim.readMemory(vipCharSegmentAddress(index), VIP_CHAR_SEGMENT_BYTES)
        ));
        segments.forEach((buffer, index) => {
            const bytes = new Uint8Array(buffer);
            if (!sameVipBytes(bytes, this.charSegments[index])) {
                this.charSegments[index] = bytes;
                this.dirty = true;
            }
        });

        // The union over the drawn worlds, since in Context several of them
        // map from the same segment and none of them is worth reading twice.
        const needed = [...new Set(worlds.flatMap(world => WorldsPanel.worldSegments(world)))];
        const maps = await Promise.all(needed.map(segment => sim.readMemory(vipBgMapAddress(segment), VIP_BGMAP_BYTES)));
        const bgMapSegments: (Uint8Array | undefined)[] = [];
        needed.forEach((segment, index) => {
            const bytes = new Uint8Array(maps[index]);
            if (!sameVipBytes(bytes, this.bgMapSegments[segment])) {
                this.dirty = true;
            }
            bgMapSegments[segment] = bytes;
        });
        this.bgMapSegments = bgMapSegments;

        const tables: (Uint8Array | undefined)[] = [];
        await Promise.all(worlds.map(async world => {
            const length = vipParamTableBytes(world);
            if (length > 0) {
                tables[world.index] = new Uint8Array(
                    await sim.readMemory(vipParamTableAddress(world.param), length)
                );
            }
        }));
        if (!WorldsPanel.sameParamTables(tables, this.paramTables)) {
            this.dirty = true;
        }
        this.paramTables = tables;

        // All of OAM, in one read: an object group is a range of it, and
        // which objects a group holds changes with the SPT registers from one
        // frame to the next.
        if (sources.some(world => world.mode === VipWorldMode.OBJECT)) {
            const oam = new Uint8Array(await sim.readMemory(VIP_OAM_BASE, VIP_OAM_BLOCK_BYTES));
            if (!sameVipBytes(oam, this.oamBytes)) {
                this.oamBytes = oam;
                this.dirty = true;
            }
        } else if (this.oamBytes) {
            this.oamBytes = undefined;
            this.dirty = true;
        }
    }

    /** Whether two reads of the param tables agree, absent tables included. */
    protected static sameParamTables(
        a: ReadonlyArray<Uint8Array | undefined>, b: ReadonlyArray<Uint8Array | undefined>
    ): boolean {
        for (let index = 0; index < VIP_WORLD_COUNT; index++) {
            if (!a[index] !== !b[index]) {
                return false;
            }
            if (a[index] && !sameVipBytes(a[index], b[index])) {
                return false;
            }
        }
        return true;
    }

    /**
     * The BGMap segments a world spans, in the order it lays them out: scx
     * across then scy down, from its base segment.
     *
     * Segments past the last real one are dropped rather than read — 14 and 15
     * are where world attribute and object memory live, not map data.
     */
    protected static worldSegments(world: VipWorld): number[] {
        const count = Math.min(world.scx * world.scy, VIP_BGMAP_COUNT);
        const segments = new Set<number>();
        for (let index = 0; index < count; index++) {
            const segment = (world.bgMap + index) & 0x0f;
            if (segment < VIP_BGMAP_COUNT) {
                segments.add(segment);
            }
        }
        return [...segments];
    }

    /** The selected world, decoded out of the last read of world memory. */
    protected world(): VipWorld | undefined {
        const bytes = this.worldBytes;
        if (!bytes) {
            return undefined;
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        return decodeVipWorld(view, this.selected, this.selected * VIP_WORLD_BYTES);
    }

    /** The selected world's param table, as a view, or undefined when it has none. */
    protected params(): DataView | undefined {
        return this.paramsFor(this.selected);
    }

    /** One world's param table, as a view, or undefined when none was read. */
    protected paramsFor(index: number): DataView | undefined {
        const bytes = this.paramTables[index];
        return bytes ? new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength) : undefined;
    }

    protected selectWorld(index: number): void {
        if (Number.isNaN(index)) {
            return;
        }
        this.selected = Math.min(VIP_WORLD_COUNT - 1, Math.max(0, index));
        this.dirty = true;
        this.refresh();
    }

    protected setShowOnlyDrawn(value: boolean): void {
        this.showOnlyDrawn = this.remember('showOnlyDrawn', value);
        // A world the list no longer holds would leave the fields describing
        // something that cannot be pointed at, so the selection comes back
        // to the last world that is still listed.
        const listed = this.listedWorlds();
        if (listed.length > 0 && !listed.some(world => world.index === this.selected)) {
            this.selected = listed[listed.length - 1].index;
        }
        this.dirty = true;
        // More worlds to draw is more of VRAM to read, so this goes back to
        // the sources rather than only re-drawing what is already here.
        this.refresh();
    }

    protected setShowGenericPalette(value: boolean): void {
        this.showGenericPalette = this.remember('showGenericPalette', value);
        this.dirty = true;
        this.refresh();
    }

    /**
     * Whether the preview is of the one world or of the frame around it.
     *
     * Context draws from more of VRAM than Solo does — every drawn world's
     * map segments and param table — so the sources are read again rather
     * than only the picture being drawn again.
     */
    protected setPreviewMode(mode: WorldPreviewMode): void {
        this.previewMode = this.remember('previewMode', mode) as WorldPreviewMode;
        this.dirty = true;
        this.refresh();
    }

    protected setEye(eye: VipEye): void {
        this.eye = this.remember('eye', eye) as VipEye;
        this.dirty = true;
        this.refresh();
    }

    /** The four BGMap palettes' shading, or the same generic ramp four times. */
    protected palettes(registers: DataView): number[][] {
        return this.showGenericPalette
            ? [0, 1, 2, 3].map(() => VIP_GENERIC_PALETTE_INTENSITIES)
            : VIP_BGMAP_PALETTES.map(register => vipIntensitiesForRegister(registers, register));
    }

    // --- Writing ------------------------------------------------------------

    /** Write one halfword of VRAM and pick the change straight back up. */
    protected async writeHalfword(address: number, value: number): Promise<void> {
        const sim = this.source.sim;
        if (!sim || Number.isNaN(value)) {
            return;
        }
        await this.source.write(address, [value & 0xff, (value >> 8) & 0xff]);
        this.dirty = true;
        await this.refresh();
    }

    /** One field of the selected world's attribute entry. */
    protected writeField(worldField: VipWorldField, value: number): void {
        this.writeHalfword(vipWorldAddress(this.selected) + worldField * 2, value);
    }

    /**
     * Everything the head halfword packs together, which has to be rewritten
     * whole: the mode, the map size and base, and the four flags.
     */
    protected writeHead(patch: Partial<VipWorld>): void {
        const world = this.world();
        if (world) {
            this.writeField(VipWorldField.HEAD, encodeVipWorldHead({ ...world, ...patch }));
        }
    }

    /** One eye's shift on one row of an H-bias world's param table. */
    protected writeHBias(world: VipWorld, row: number, eye: VipEye, value: number): void {
        const address = vipParamTableAddress(world.param) + row * VIP_HBIAS_ENTRY_BYTES + (eye === 'left' ? 0 : 2);
        this.writeHalfword(address, value);
    }

    // --- Rendering ----------------------------------------------------------

    /**
     * A screen-sized bitmap of what the preview shows.
     *
     * In Solo that is the selected world alone. In Context it is every world
     * the VIP would draw, in the order it draws them — 31 downwards, over one
     * another, stopping at the world that ends the frame — with everything
     * but the selected one faded and gray. The area nothing covers stays
     * opaque black; the Frame Buffers panel is the view that shows what the
     * hardware itself composited, objects and column table included.
     *
     * A pixel whose palette entry is black is left alone rather than painted,
     * which is the transparency the hardware gives palette index 0. Worlds in
     * OBJECT mode draw nothing here: their objects come out of OAM, which the
     * Objects panel lists.
     */
    protected rasterize(registers: DataView): ImageData {
        const width = VIP_FRAME_BUFFER_WIDTH;
        const height = VIP_FRAME_BUFFER_HEIGHT;
        const pixels = new Uint8ClampedArray(width * height * 4);
        for (let offset = 3; offset < pixels.length; offset += 4) {
            pixels[offset] = 255;
        }

        const palettes = this.palettes(registers);
        const characters = new VipCharacters(this.charSegments);
        const context = this.previewMode === 'context';
        for (const world of this.drawnWorlds()) {
            // Solo draws the selected world whatever its eye flags say;
            // Context is the frame, so there a world is drawn only if the
            // hardware would draw it — unless the undrawn ones are wanted.
            // An OBJECT world is drawn if either eye asks for it, and its
            // objects then pick their own eye; see vipObjectGroupForWorld.
            const drawn = world.mode === VipWorldMode.OBJECT
                ? world.lon || world.ron
                : this.eye === 'left' ? world.lon : world.ron;
            if (context && !drawn && this.showOnlyDrawn) {
                continue;
            }
            const faded = context && world.index !== this.selected;
            const paint = (destX: number, destY: number, intensity: number): void => {
                if (intensity === 0) {
                    return;
                }
                const offset = (destY * width + destX) * 4;
                // Red, because that is the color the hardware emits; the
                // other two channels are written either way, since a faded
                // world may have left gray in them.
                const gray = faded ? Math.round(intensity * CONTEXT_FACTOR) : 0;
                pixels[offset] = faded ? gray : intensity;
                pixels[offset + 1] = gray;
                pixels[offset + 2] = gray;
            };

            if (world.mode === VipWorldMode.OBJECT) {
                this.drawObjects(registers, world, characters, width, height, paint);
                continue;
            }

            const map = new VipWorldMap(world, this.bgMapSegments, characters);
            forEachVipWorldPixel(
                world, width, height, this.eye, this.paramsFor(world.index),
                (destX, destY, x, y) => paint(destX, destY, map.intensity(x, y, palettes))
            );
        }
        return new ImageData(pixels, width, height);
    }

    /**
     * The objects one OBJECT world puts on screen.
     *
     * Which of the four groups it draws is not in the world entry but in the
     * drawing order — see {@link objectGroupFor} — and within a group the
     * objects are drawn from the last index down to the first, so a lower
     * index lands on top. An object carries its own eye bits, which are what
     * decide whether it is in this eye's picture; the world's decide only
     * whether the world is drawn at all. Both of those are measured against
     * the core in `tests/object-group-probe.mjs`.
     */
    protected drawObjects(
        registers: DataView,
        world: VipWorld,
        characters: VipCharacters,
        width: number,
        height: number,
        paint: (destX: number, destY: number, intensity: number) => void
    ): void {
        const bytes = this.oamBytes;
        const group = this.objectGroupFor(world.index);
        if (!bytes || group === undefined) {
            return;
        }
        const range = vipObjectGroupRange(registers, group);
        if (!range) {
            return;
        }
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        const shades = [0, 1, 2, 3].map(palette => this.objectPalette(registers, palette));
        for (let index = Math.min(range.last, VIP_OBJECT_COUNT - 1); index >= range.first; index--) {
            const object = decodeVipObject(view, index, index * VIP_OBJECT_BYTES);
            if (!(this.eye === 'left' ? object.lon : object.ron)) {
                continue;
            }
            const intensities = shades[object.palette];
            forEachVipObjectPixel(object, width, height, characters, this.eye,
                (destX, destY, value) => paint(destX, destY, intensities[value]));
        }
    }

    /** Which object group the given world draws, over the whole world list. */
    protected objectGroupFor(index: number): number | undefined {
        return vipObjectGroupForWorld(this.allWorlds(), index);
    }

    /** One object palette's shading, or the generic ramp in its place. */
    protected objectPalette(registers: DataView, palette: number): number[] {
        return this.showGenericPalette
            ? VIP_GENERIC_PALETTE_INTENSITIES
            : vipIntensitiesForRegister(registers, VIP_OBJECT_PALETTES[palette]);
    }

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        const bytes = this.worldBytes;
        if (!bytes) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }

        const selected = this.world();
        if (!selected) {
            return undefined;
        }

        // Focusable, and the arrow keys are read here rather than on the
        // list: wherever focus has landed in the panel — a tile, a switch,
        // the preview — the arrows walk the worlds. Clicking anywhere that
        // does not take focus itself lands here too.
        return <div
            className='vp-columns'
            tabIndex={0}
            aria-label={nls.localize('vueport/debug/panels/worlds/title', 'Worlds')}
            onKeyDown={event => this.onPanelKey(event)}
        >
            {this.renderList(this.listedWorlds())}
            <div className='vp-sidebar vp-scroll'>
                {this.renderWorldGroup(selected)}
                {this.renderPropertiesGroup(selected)}
                {selected.mode === VipWorldMode.HBIAS && this.renderHBiasGroup(selected)}
                {this.renderDisplayGroup()}
            </div>
            {this.renderPreview(selected)}
        </div>;
    }

    /**
     * The thirty-two worlds in drawing order, boiled down to what tells them
     * apart at a glance: the index, the mode, which eyes they are drawn to,
     * and the one that ends the frame.
     *
     * Tiles rather than table rows. There are four things to say about a
     * world and only one of them is a number, so a row of columns spent most
     * of its width on padding between them; a tile stacks the four and is
     * read as one thing. A column of its own rather than a table above the
     * fields, so that picking another world does not mean leaving the world
     * being looked at: the list, that world's fields and its preview are all
     * on screen at once.
     */
    protected renderList(worlds: VipWorld[]): React.ReactNode {
        return <div className='vp-tiles vp-scroll'>
            {worlds.map(world => {
                const drawn = world.lon || world.ron;
                return <button
                    type='button'
                    key={world.index}
                    className={`vp-tile${drawn ? '' : ' inactive'}`
                        + `${world.index === this.selected ? ' selected' : ''}`}
                    aria-pressed={world.index === this.selected}
                    tabIndex={-1}
                    title={hex(vipWorldAddress(world.index), 8)}
                    onClick={() => this.selectWorld(world.index)}
                >
                    <span className='vp-tile-index'>{world.index}</span>
                    <span className='vp-tile-mark'>
                        {`${world.lon ? 'L' : '\u2013'}${world.ron ? 'R' : '\u2013'}`}
                    </span>
                    <span className='vp-tile-note'>{VIP_WORLD_MODE_NAMES[world.mode]}</span>
                    {world.end &&
                        <span
                            className='vp-tile-flag'
                            title={nls.localize('vueport/debug/panels/worlds/endHint', 'Drawing stops at this world')}
                        >
                            {nls.localize('vueport/debug/panels/worlds/end', 'End')}
                        </span>
                    }
                </button>;
            })}
        </div>;
    }

    /**
     * Walk the worlds with the keyboard, one at a time or a screenful.
     *
     * By position in the list rather than by world index, so that the keys
     * reach exactly what the list shows and stop at its ends — with only the
     * drawn worlds listed, the ones from End down are not there to be walked
     * into.
     * The event is stopped rather than only defaulted, because the emulator
     * listens for keys on the node this panel sits inside and would otherwise
     * read an arrow as the D-pad and move the game while the panel is being
     * read — the Characters panel's sheet is walked the same way.
     */
    protected onPanelKey(event: React.KeyboardEvent): void {
        if (arrowKeysTaken(event.target, event.currentTarget)) {
            return;
        }
        const steps: Record<string, number> = {
            ArrowUp: -1,
            ArrowLeft: -1,
            ArrowDown: 1,
            ArrowRight: 1,
            PageUp: -8,
            PageDown: 8,
        };
        const step = steps[event.key];
        const home = event.key === 'Home';
        const end = event.key === 'End';
        if (step === undefined && !home && !end) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        const listed = this.listedWorlds();
        if (listed.length === 0) {
            return;
        }
        const at = listed.findIndex(world => world.index === this.selected);
        const to = home ? 0 : end ? listed.length - 1 : Math.max(0, at) + step;
        this.selectWorld(listed[Math.min(listed.length - 1, Math.max(0, to))].index);
        this.revealSelected();
    }

    /**
     * Scroll the picked world's tile into view and put focus on it, so that
     * the ring and the selection are the same tile and the next arrow key
     * carries on from there.
     */
    protected revealSelected(): void {
        requestAnimationFrame(() => {
            const tile = this.node.querySelector<HTMLElement>('.vp-tile.selected');
            tile?.scrollIntoView({ block: 'nearest' });
            tile?.focus({ preventScroll: true });
        });
    }

    protected renderWorldGroup(world: VipWorld): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/worlds/world', 'World')}</legend>
            <div className='vp-detail-fields'>
                {field(nls.localize('vueport/debug/panels/worlds/index', 'Index'), world.index)}
                {field(
                    nls.localize('vueport/debug/panels/worlds/address', 'Address'),
                    hex(vipWorldAddress(world.index), 8)
                )}
                {field(
                    'Head',
                    hex(world.head, 4),
                    nls.localize('vueport/debug/panels/worlds/headHint', 'Header register')
                )}
            </div>
        </fieldset>;
    }

    /**
     * Everything the head halfword and the position registers hold, in a grid
     * three fields wide.
     *
     * The registers come in sets — the two segment counts, the three G and
     * the three M coordinates, the size pair, the param register and where it
     * points — and each set is a row of the grid, so the shape of the entry
     * is legible before a single value is read. Names sit above their
     * controls; beside them they would cost more width than the column has.
     */
    protected renderPropertiesGroup(world: VipWorld): React.ReactNode {
        const sizeHint = nls.localize('vueport/debug/panels/worlds/sizeHint', 'Register value, which is size minus one');
        const scHint = nls.localize('vueport/debug/panels/worlds/scHint', 'Segments across and down');
        const signed = (value: number, write: (next: number) => void) =>
            numberInput(value, SIGNED_MIN, SIGNED_MAX, write);
        return <fieldset className='vp-inspector-group vp-grows'>
            <legend>{nls.localize('vueport/debug/panels/worlds/properties', 'Properties')}</legend>
            <div className='vp-scroll-body vp-scroll'>
                <div className='vp-grid'>
                    <div className='vp-grid-row'>
                        {stacked('Mode', <Select
                            value={String(world.mode)}
                            onChange={next => this.writeHead({ mode: parseInt(next, 10) as VipWorldMode })}
                            options={Object.entries(VIP_WORLD_MODE_NAMES).map(([mode, name]) => ({
                                value: mode,
                                label: name,
                            }))}
                        />, undefined, 2)}
                        {stacked(
                            nls.localize('vueport/debug/panels/worlds/map', 'Map'),
                            numberInput(world.bgMap, 0, 0x0f, value => this.writeHead({ bgMap: value })),
                            nls.localize('vueport/debug/panels/worlds/bgMapHint', 'Base BGMap segment')
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('Sc X', this.segmentCountInput(world.scx, v => this.writeHead({ scx: v })), scHint)}
                        {stacked('Sc Y', this.segmentCountInput(world.scy, v => this.writeHead({ scy: v })), scHint)}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('GX', signed(world.gx, v => this.writeField(VipWorldField.GX, v)))}
                        {stacked('GY', signed(world.gy, v => this.writeField(VipWorldField.GY, v)))}
                        {stacked('GP', signed(world.gp, v => this.writeField(VipWorldField.GP, v)))}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('MX', signed(world.mx, v => this.writeField(VipWorldField.MX, v)))}
                        {stacked('MY', signed(world.my, v => this.writeField(VipWorldField.MY, v)))}
                        {stacked('MP', signed(world.mp, v => this.writeField(VipWorldField.MP, v)))}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked('W', numberInput(world.w, 0, UNSIGNED_MAX,
                            v => this.writeField(VipWorldField.W, v)), sizeHint)}
                        {stacked('H', numberInput(world.h, 0, UNSIGNED_MAX,
                            v => this.writeField(VipWorldField.H, v)), sizeHint)}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/worlds/param', 'Param'),
                            numberInput(
                                world.param, 0, UNSIGNED_MAX,
                                v => this.writeField(VipWorldField.PARAM, v), PARAM_STEP
                            ),
                            nls.localize(
                                'vueport/debug/panels/worlds/paramHint',
                                'Register value, which is a halfword offset into BGMap memory'
                            )
                        )}
                        {stacked(
                            nls.localize('vueport/debug/panels/worlds/paramAddress', 'Param address'),
                            <input className='vp-input' readOnly value={hex(vipParamTableAddress(world.param), 8)} />,
                            nls.localize(
                                'vueport/debug/panels/worlds/paramAddressHint',
                                'Where the H-bias or Affine table the param register points at starts'
                            ),
                            2
                        )}
                    </div>
                    <div className='vp-grid-row'>
                        {stacked(
                            nls.localize('vueport/debug/panels/worlds/overplane', 'Overplane'),
                            numberInput(
                                world.overplaneCell, 0, UNSIGNED_MAX,
                                v => this.writeField(VipWorldField.OVERPLANE_CELL, v)
                            ),
                            nls.localize('vueport/debug/panels/worlds/overplaneHint', 'The cell drawn outside the map'),
                            2
                        )}
                        <div
                            className='vp-grid-switch'
                            title={nls.localize(
                                'vueport/debug/panels/worlds/overplaneFlagHint',
                                'Draw the overplane outside the map instead of repeating it'
                            )}
                        >
                            <Switch
                                label={nls.localize('vueport/debug/panels/worlds/overplane', 'Overplane')}
                                value={world.overplane}
                                onChange={value => this.writeHead({ overplane: value })}
                            />
                        </div>
                    </div>
                </div>
                <div className='vp-detail-flags'>
                    {/* Named the way the fields above them are, so the group
                        reads as one list of settings rather than as a grid
                        with a row of loose switches under it. The two eyes go
                        on one line: the same question asked twice, read as a
                        pair. */}
                    <div className='vp-inspector-field'>
                        <label>{nls.localize('vueport/debug/panels/worlds/eyes', 'Eyes')}</label>
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/worlds/left', 'Left'),
                                world.lon,
                                value => this.writeHead({ lon: value })
                            )}
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/worlds/right', 'Right'),
                                world.ron,
                                value => this.writeHead({ ron: value })
                            )}
                        </div>
                    </div>
                    <div className='vp-inspector-field'>
                        <label>{nls.localize('vueport/debug/panels/worlds/flags', 'Flags')}</label>
                        <div className='vp-flags-row'>
                            {this.renderToggle(
                                nls.localize('vueport/debug/panels/worlds/end', 'End'),
                                world.end,
                                value => this.writeHead({ end: value }),
                                nls.localize('vueport/debug/panels/worlds/endHint', 'Drawing stops at this world')
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </fieldset>;
    }

    /**
     * One of the panel's settings, as a switch.
     *
     * A switch rather than a checkbox because these take effect the moment
     * they are thrown — see the kit component, and the Characters panel's
     * toggles, which are laid out the same way: the control, then the name
     * beside it.
     */
    protected renderToggle(
        label: string, value: boolean, onChange: (value: boolean) => void, hint?: string
    ): React.ReactNode {
        return <span className='vp-toggle' title={hint}>
            <Switch label={label} value={value} onChange={onChange} />
            <span>{label}</span>
        </span>;
    }

    /** A picker for one of the four map sizes a world can have per axis. */
    protected segmentCountInput(value: number, commit: (value: number) => void): React.JSX.Element {
        return <Select
            value={String(value)}
            onChange={next => commit(parseInt(next, 10))}
            options={[1, 2, 4, 8].map(count => ({ value: String(count), label: String(count) }))}
        />;
    }

    protected renderHBiasGroup(world: VipWorld): React.ReactNode {
        const rows = vipParamRows(world);
        const row = Math.min(this.hbiasRow, Math.max(0, rows - 1));
        const entry = vipHBiasRow(this.params(), row);
        const address = vipParamTableAddress(world.param) + row * VIP_HBIAS_ENTRY_BYTES;
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/worlds/hbias', 'H-bias')}</legend>
            <div className='vp-detail-fields'>
                {control(
                    nls.localize('vueport/debug/panels/worlds/index', 'Index'),
                    numberInput(row, 0, Math.max(0, rows - 1), value => { this.hbiasRow = value; this.update(); }),
                    nls.localize('vueport/debug/panels/worlds/hbiasRowHint', 'Which row of the table to show; there is one per row of the world')
                )}
                {field(nls.localize('vueport/debug/panels/worlds/address', 'Address'), hex(address, 8))}
                {control(
                    nls.localize('vueport/debug/panels/worlds/left', 'Left'),
                    numberInput(entry?.left ?? 0, SIGNED_MIN, SIGNED_MAX, value => this.writeHBias(world, row, 'left', value))
                )}
                {control(
                    nls.localize('vueport/debug/panels/worlds/right', 'Right'),
                    numberInput(entry?.right ?? 0, SIGNED_MIN, SIGNED_MAX, value => this.writeHBias(world, row, 'right', value))
                )}
            </div>
        </fieldset>;
    }

    protected renderDisplayGroup(): React.ReactNode {
        return <fieldset className='vp-inspector-group'>
            <legend>{nls.localize('vueport/debug/panels/worlds/display', 'Display')}</legend>
            {/* Name, track and readout as three columns, the way the
                Characters panel's sliders are laid out. */}
            <div className='vp-ranges'>
                <label>
                    <span>{nls.localize('vueport/debug/panels/worlds/scale', 'Scale')}</span>
                    <input
                        type='range'
                        min={1}
                        max={MAX_PREVIEW_ZOOM}
                        value={this.zoom}
                        onChange={e => {
                            this.zoom = this.remember('zoom', parseInt(e.target.value, 10));
                            this.update();
                        }}
                    />
                    <span className='hint'>{this.zoom}</span>
                </label>
            </div>
            {/* Both fill the group: they are the two questions the preview
                asks — which eye, and how much of the frame — and a segmented
                control that stops short of the edge reads as a stray. */}
            <RadioSelect
                options={[{
                    value: 'left',
                    label: nls.localize('vueport/debug/panels/worlds/leftEye', 'Left Eye'),
                }, {
                    value: 'right',
                    label: nls.localize('vueport/debug/panels/worlds/rightEye', 'Right Eye'),
                }]}
                defaultValue={this.eye}
                onChange={options => this.setEye(options[0].value as VipEye)}
                fitSpace
            />
            <RadioSelect
                options={[{
                    value: 'context',
                    label: nls.localize('vueport/debug/panels/worlds/inContext', 'In Context'),
                    tooltip: nls.localize(
                        'vueport/debug/panels/worlds/inContextHint',
                        'Every world the VIP draws, in its own order, with all but the selected one faded'
                    ),
                }, {
                    value: 'solo',
                    label: nls.localize('vueport/debug/panels/worlds/solo', 'Solo'),
                    tooltip: nls.localize(
                        'vueport/debug/panels/worlds/soloHint',
                        'The selected world on its own, drawn whether or not the hardware would draw it'
                    ),
                }]}
                defaultValue={this.previewMode}
                onChange={options => this.setPreviewMode(options[0].value as WorldPreviewMode)}
                fitSpace
            />
            {this.renderToggle(
                nls.localize('vueport/debug/panels/worlds/genericPalette', 'Generic Palette'),
                this.showGenericPalette,
                value => this.setShowGenericPalette(value)
            )}
            {this.renderToggle(
                nls.localize('vueport/debug/panels/worlds/showOutline', 'Show Outline'),
                this.showExtents,
                value => { this.showExtents = this.remember('showExtents', value); this.update(); }
            )}
            {this.renderToggle(
                nls.localize('vueport/debug/panels/worlds/hideUndrawn', 'Hide Undrawn'),
                this.showOnlyDrawn,
                value => this.setShowOnlyDrawn(value),
                nls.localize(
                    'vueport/debug/panels/worlds/showOnlyDrawnHint',
                    'Leave out the worlds the VIP skips: the one that ends the frame and everything'
                    + ' past it, and — in Context — those switched off for this eye'
                )
            )}
        </fieldset>;
    }

    /**
     * What an OBJECT world is drawing, which the world entry itself does not
     * say: the group it takes is decided by how many OBJECT worlds the VIP
     * drew before reaching it.
     */
    protected objectWorldNote(world: VipWorld): string {
        const group = this.objectGroupFor(world.index);
        if (group === undefined) {
            return nls.localize(
                'vueport/debug/panels/worlds/objectWorldUnreached',
                'An Object world, but the VIP never reaches it: there is no object group left for it.'
            );
        }
        const range = this.registers && vipObjectGroupRange(this.registers, group);
        return range
            ? nls.localize(
                'vueport/debug/panels/worlds/objectWorldGroup',
                'Drawing object group {0}, objects {1} to {2}, which the Objects panel lists.',
                group, range.first, range.last
            )
            : nls.localize(
                'vueport/debug/panels/worlds/objectWorldEmpty',
                'Drawing object group {0}, which the SPT registers leave empty.',
                group
            );
    }

    protected renderPreview(world: VipWorld): React.ReactNode {
        if (!this.image) {
            return undefined;
        }
        return <div className='vp-preview vp-scroll'>
            <VipCanvas
                image={this.image}
                zoom={this.zoom}
                extents={this.showExtents ? vipWorldExtents(world, this.eye) : undefined}
            />
            {world.mode === VipWorldMode.OBJECT &&
                <div className='vp-footer'>{this.objectWorldNote(world)}</div>
            }
        </div>;
    }
}
