import { nls } from '../../common/emulator-nls';
import { Message } from '@lumino/messaging';
import * as React from 'react';
import { VB_VSU_BASE } from '../../common/vb-constants';
import { hex, DebugSource, Panel, EmulatorPanelType } from './emulator-panel';
import { emulatorPanelTitleIcon } from './emulator-panel-icons';
import {
    decodeVsuChannel,
    VSU_CHANNEL_COUNT,
    VSU_CHANNEL_SHORT_NAMES,
    VSU_MODULATION_BASE,
    VSU_MODULATION_BYTES,
    VSU_REGISTER_BASE,
    VSU_REGISTER_BLOCK_BYTES,
    VSU_WAVEFORM_BASES,
    VSU_WAVEFORM_BYTES,
    VsuChannel,
    VsuChannelKind,
    VsuEnvelopeDirection,
    VsuSweepDirection,
    VsuSweepModulationFunction,
    vsuChannelAddress,
    vsuChannelLevel,
    vsuModulationSamples,
    vsuNoteOf,
    vsuSamplesEqual,
    vsuWaveformSamples,
} from './emulator-vsu-memory';
import { Sim } from '../core/vb-core';
import EmptyContainer from '../components/kit/EmptyContainer';
import { Plug, Warning } from '@phosphor-icons/react';

/** Sparkline geometry, in the same units as its viewBox. */
const SPARK_WIDTH = 64;
const SPARK_HEIGHT = 18;
/**
 * The waveform plots under the strips, which are read rather than glanced at:
 * tall enough for the six bits of a sample to be a shape and not a squiggle.
 */
const PLOT_WIDTH = 64;
const PLOT_HEIGHT = 64;
/** Waveform samples are six-bit. */
const SAMPLE_MAX = 63;
/** Modulation steps are signed bytes, so the plot is drawn around a middle. */
const MODULATION_RANGE = 128;

/**
 * How far below full scale the output meter's bar reaches.
 *
 * The meter is measured sound rather than a programmed level, and sound is
 * read in decibels: a linear bar spends nine tenths of its length on the top
 * two bits of a signal and leaves everything quiet looking like silence.
 */
const METER_FLOOR_DB = 48;

/** How long a waveform bank is marked as having just changed, in milliseconds. */
const CHANGED_MS = 1200;

/** Amplitude 0-1 as decibels below full scale, or undefined for silence. */
function decibels(amplitude: number): number | undefined {
    return amplitude > 0 ? 20 * Math.log10(amplitude) : undefined;
}

/** Where an amplitude sits on the meter, 0 to 1. See {@link METER_FLOOR_DB}. */
function meterScale(amplitude: number): number {
    const db = decibels(amplitude);
    if (db === undefined) {
        return 0;
    }
    return Math.max(0, Math.min(1, 1 + db / METER_FLOOR_DB));
}

/**
 * A measured level as it is written beside its bar.
 *
 * Anything under the meter's floor reads as silence rather than as a number.
 * A mixed buffer is rarely exactly zero — a muted machine measures somewhere
 * around -800 dB, which is a denormal float and not a quiet sound — and
 * printing that instead of nothing would be a meter that never reads silent.
 */
function decibelLabel(amplitude: number): string {
    const db = decibels(amplitude);
    return db === undefined || db <= -METER_FLOOR_DB
        ? '−∞'
        : `${db > -0.05 ? '' : '−'}${Math.abs(db).toFixed(0)}`;
}

/**
 * One side of a channel, as a bar with its register value on it.
 *
 * The stereo volume and the envelope together, because either at zero is
 * silence and a column of volume numbers does not show that — a channel
 * switched on with its envelope at zero looks exactly like one that is
 * playing. Empty for a channel that is off, so a strip with no bars at all is
 * a strip making no sound.
 */
function levelBar(channel: VsuChannel, side: 'left' | 'right', label: string): React.JSX.Element {
    const level = vsuChannelLevel(channel, side);
    return <span className='vp-vsu-level' title={`${label} ${channel[side]}/15`}>
        <span className='vp-vsu-level-side'>{label}</span>
        <span className='vp-vsu-level-track'>
            <span className='vp-vsu-level-fill' style={{ width: `${Math.round(level * 100)}%` }} />
        </span>
    </span>;
}

/**
 * A table of samples as a polyline, scaled to the box it is drawn in.
 *
 * Inset by a line's width top and bottom, so that a bank held at zero — or at
 * full scale — is a line that can be seen rather than one drawn along the edge
 * of its own box and half clipped away.
 */
function plotPoints(
    samples: number[], width: number, height: number, max: number, inset = 1): string {
    if (samples.length < 2) {
        return '';
    }
    const step = width / (samples.length - 1);
    const span = height - inset * 2;
    return samples
        .map((sample, index) =>
            `${(index * step).toFixed(1)},${(height - inset - (sample / max) * span).toFixed(1)}`)
        .join(' ');
}

/**
 * The VSU as a mixer: one strip per channel, and the waveform banks they play
 * from underneath.
 *
 * This was a ten-column table, which is the shape of the register map rather
 * than the shape of what the register map is doing. Music moves, and a table
 * refreshed ten times a second only ever shows where it happens to be — six
 * rows of changing numbers, with nothing saying which of them is the loud one.
 * A strip says it by being drawn: a waveform, a note name, two level bars, and
 * a channel that is silent has nothing on it.
 *
 * Polled like every other inspector, but not from memory: real hardware never
 * lets the VSU's registers be read back and this core matches that (see
 * VB_VSU_BASE's own comment), so readVsu composes the map out of the core's
 * own decoded copy of the VSU instead. That copy is the machine's present
 * tense — a channel switched on before this panel existed reads as on, and one
 * the hardware switched off itself when its interval elapsed reads as off —
 * and where the core keeps both what a channel was given and what it is
 * playing, what it is playing is what arrives here. Bit layouts for the map
 * are decoded in emulator-vsu-memory.ts; see there for sourcing, and
 * worker/vb-vsu-layout.ts for how the core's copy is found.
 *
 * Muting and soloing are the emulator's, not the game's: the worker holds a
 * muted channel's stereo level at zero at every frame break and hands back
 * what the game asked for, so isolating one instrument neither writes to the
 * VSU nor changes what this panel says the machine is doing. Both are given up
 * when the panel closes — a silenced channel with nothing on screen to explain
 * it would be a bug report.
 */
export class VsuPanel extends Panel {

    protected channels?: VsuChannel[];
    protected waveforms: (number[] | undefined)[] = [];
    protected modulation?: number[];
    /** Peak of the machine's last frame of sound, per side, 0 to 1. */
    protected peakLeft = 0;
    protected peakRight = 0;
    protected error?: string;

    /**
     * When each waveform bank last changed, by bank; the modulation table is
     * the entry after them.
     *
     * Banks are not boot-time furniture. A driver rewrites one between notes
     * to change instrument, and a game with more than five voices' worth of
     * sounds reuses them constantly — so what they hold is polled like
     * everything else here, and one that has just changed is marked for
     * {@link CHANGED_MS} so that a rewrite is something you see happen rather
     * than something you notice afterwards.
     */
    protected changedAt: number[] = [];

    /** Channels muted by hand, by index. */
    protected readonly muted = new Set<number>();
    /** The one channel being listened to alone, if any. */
    protected soloed?: number;
    /** The mask last sent to the worker, so an unchanged one is not re-sent. */
    protected sentMask?: number;
    /** The machine that mask was sent to, so a new one is told again. */
    protected sentTo?: Sim;

    constructor(source: DebugSource, instanceId: string) {
        super(EmulatorPanelType.VSU, source, instanceId);
        this.title.label = nls.localize('vueport/debug/panels/vsu/title', 'VSU');
        this.title.icon = emulatorPanelTitleIcon(EmulatorPanelType.VSU);
    }

    protected async refresh(): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            this.channels = undefined;
            this.waveforms = [];
            this.modulation = undefined;
            this.peakLeft = 0;
            this.peakRight = 0;
            this.update();
            return;
        }

        try {
            const reading = await sim.readVsu();
            const map = new Uint8Array(reading.map);
            const registers = new DataView(map.buffer, VSU_REGISTER_BASE - VB_VSU_BASE, VSU_REGISTER_BLOCK_BYTES);
            this.channels = Array.from({ length: VSU_CHANNEL_COUNT }, (unused, index) => decodeVsuChannel(registers, index));
            this.readTables(map);
            this.peakLeft = reading.peakLeft;
            this.peakRight = reading.peakRight;
            this.error = undefined;
        } catch (error) {
            this.error = error instanceof Error ? error.message : String(error);
        }
        // After the read, so that a machine that has just appeared is told
        // about the mutes this panel is already showing.
        this.pushMutes().catch(() => undefined);
        this.update();
    }

    /**
     * The waveform banks and the modulation table, noting which have moved
     * since the last poll.
     *
     * The first reading of a table is not a change: everything would be marked
     * the moment the panel opened, which says nothing about the game.
     */
    protected readTables(map: Uint8Array): void {
        const now = Date.now();
        const previous = this.waveforms;
        this.waveforms = VSU_WAVEFORM_BASES.map(base =>
            vsuWaveformSamples(map.subarray(base - VB_VSU_BASE, base - VB_VSU_BASE + VSU_WAVEFORM_BYTES))
        );
        this.waveforms.forEach((samples, bank) => {
            if (previous[bank] !== undefined && !vsuSamplesEqual(previous[bank], samples)) {
                this.changedAt[bank] = now;
            }
        });

        const wasModulated = this.modulation;
        this.modulation = vsuModulationSamples(
            map.subarray(VSU_MODULATION_BASE - VB_VSU_BASE, VSU_MODULATION_BASE - VB_VSU_BASE + VSU_MODULATION_BYTES));
        if (wasModulated !== undefined && !vsuSamplesEqual(wasModulated, this.modulation)) {
            this.changedAt[this.waveforms.length] = now;
        }
    }

    /** Whether a table was written recently enough to still be marked. */
    protected justChanged(table: number): boolean {
        const at = this.changedAt[table];
        return at !== undefined && Date.now() - at < CHANGED_MS;
    }

    // --- muting -------------------------------------------------------------

    /**
     * Which channels the mixer is holding silent: what was muted by hand, or,
     * while a channel is soloed, every other channel.
     */
    protected muteMask(): number {
        let mask = 0;
        for (let index = 0; index < VSU_CHANNEL_COUNT; index++) {
            const silenced = this.soloed !== undefined
                ? index !== this.soloed
                : this.muted.has(index);
            if (silenced) {
                mask |= 1 << index;
            }
        }
        return mask;
    }

    /** Tell the machine what to hold silent, if that is not what it was told. */
    protected async pushMutes(mask = this.muteMask()): Promise<void> {
        const sim = this.source.sim;
        if (!sim) {
            // Nothing to tell, and nothing remembered about a machine that has
            // gone: the next one is told from scratch.
            this.sentMask = undefined;
            this.sentTo = undefined;
            return;
        }
        if (this.sentMask === mask && this.sentTo === sim) {
            return;
        }
        this.sentMask = mask;
        this.sentTo = sim;
        try {
            await sim.setVsuMutes(mask);
        } catch {
            // A core whose VSU cannot be found refuses this the same way it
            // refuses the read; the read's own message is what the panel shows,
            // and forgetting what was sent lets the next poll try again.
            this.sentMask = undefined;
        }
    }

    protected toggleMute(index: number): void {
        if (this.muted.has(index)) {
            this.muted.delete(index);
        } else {
            this.muted.add(index);
        }
        this.pushMutes().catch(() => undefined);
        this.update();
    }

    /**
     * Listen to one channel alone, or hand the mixer back to the mute buttons.
     *
     * One at a time: soloing another channel moves the solo rather than adding
     * to it, which is the question this button is pressed to answer — which of
     * the six is making that sound. The mutes are left alone underneath, so
     * dropping the solo brings back exactly the mixer that was there before.
     */
    protected toggleSolo(index: number): void {
        this.soloed = this.soloed === index ? undefined : index;
        this.pushMutes().catch(() => undefined);
        this.update();
    }

    protected clearMutes(): void {
        this.muted.clear();
        this.soloed = undefined;
        this.pushMutes().catch(() => undefined);
        this.update();
    }

    /**
     * Everything audible again when the panel goes away.
     *
     * Through the machine directly rather than {@link pushMutes}, which would
     * have nothing to send to by the time the panel is disposed of.
     */
    protected releaseMutes(): void {
        const sim = this.source.sim;
        this.muted.clear();
        this.soloed = undefined;
        this.sentMask = undefined;
        this.sentTo = undefined;
        if (sim) {
            sim.setVsuMutes(0).catch(() => undefined);
        }
    }

    /**
     * A closed panel leaves nothing muted.
     *
     * On detach rather than only on dispose: closing a tab takes the panel out
     * of the dock without disposing of it — the dock does that later, when the
     * panel is opened again — so a mute released only in `dispose` would
     * outlive the panel that explains it, and a channel would simply be missing
     * from the music with nothing on screen saying why.
     */
    protected onBeforeDetach(msg: Message): void {
        this.releaseMutes();
        super.onBeforeDetach(msg);
    }

    dispose(): void {
        this.releaseMutes();
        super.dispose();
    }

    // --- rendering ----------------------------------------------------------

    protected render(): React.ReactNode {
        if (this.error) {
            return <EmptyContainer
                title={this.error ?? nls.localize('vueport/general/error', 'Error')}
                icon={<Warning size={32} />}
            />;
        }
        const channels = this.channels;
        if (!channels) {
            return <EmptyContainer
                title={nls.localize(
                    'vueport/debug/panels/general/notRunning',
                    'The emulator is not running.',
                )}
                icon={<Plug size={32} />}
            />;
        }

        return <div className='vp-vsu'>
            {this.renderOutput()}
            <div className='vp-vsu-strips'>
                <div className='vp-vsu-caption'>
                    {nls.localize('vueport/debug/panels/vsu/channels', 'Channels')}
                </div>
                {channels.map(channel => this.renderStrip(channel))}
            </div>
            {this.renderTables(channels)}
        </div>;
    }

    /**
     * What the six of them come to, measured off the machine's own last frame
     * of sound.
     *
     * The one thing in the panel that is not a register: registers say what
     * each channel was asked for, and this says what actually left the VSU.
     * A game whose music has stopped, or whose master volume is down, is
     * silent here while its channels still read as playing.
     */
    protected renderOutput(): React.ReactNode {
        return (
            <div className='vp-vsu-output'>
                <div className='vp-vsu-caption'>
                    {nls.localize('vueport/debug/panels/vsu/output', 'Output')}
                </div>
                <div className='vp-vsu-output-bar'>
                    <span className='vp-vsu-output-meters'>
                        {([
                            ['L', this.peakLeft],
                            ['R', this.peakRight],
                        ] as [string, number][]).map(([side, peak]) => <span
                            key={side}
                            className='vp-vsu-level'
                            title={nls.localize('vueport/debug/panels/vsu/peak', 'Peak of the last frame')}
                        >
                            <span className='vp-vsu-level-side'>{side}</span>
                            <span className='vp-vsu-level-track'>
                                <span
                                    className='vp-vsu-level-fill'
                                    style={{ width: `${Math.round(meterScale(peak) * 100)}%` }}
                                />
                            </span>
                            <span className='vp-vsu-output-db'>{decibelLabel(peak)} dB</span>
                        </span>)}
                    </span>
                    {/* Only there when there is something to undo, and it undoes the
                lot: six strips of buttons is a lot of clicking back. */}
                    {(this.muted.size > 0 || this.soloed !== undefined) && <button
                        type='button'
                        className='vp-button secondary'
                        onClick={() => this.clearMutes()}
                    >
                        {nls.localize('vueport/debug/panels/vsu/unmuteAll', 'Unmute all')}
                    </button>}
                </div>
            </div>
        );
    }

    protected renderStrip(channel: VsuChannel): React.ReactNode {
        const silenced = this.soloed !== undefined
            ? this.soloed !== channel.index
            : this.muted.has(channel.index);
        return <div
            key={channel.index}
            className={'vp-vsu-strip'
                + (channel.enabled ? ' active' : ' inactive')
                + (silenced ? ' silenced' : '')}
            title={hex(vsuChannelAddress(channel.index), 8)}
        >
            <div className='vp-vsu-strip-buttons'>
                <button
                    type='button'
                    className={'vp-vsu-button' + (this.muted.has(channel.index) ? ' on' : '')}
                    aria-pressed={this.muted.has(channel.index)}
                    title={nls.localize('vueport/debug/panels/vsu/mute',
                        'Silence this channel in the emulator, without the game knowing')}
                    onClick={() => this.toggleMute(channel.index)}
                >M</button>
                <button
                    type='button'
                    className={'vp-vsu-button solo' + (this.soloed === channel.index ? ' on' : '')}
                    aria-pressed={this.soloed === channel.index}
                    title={nls.localize('vueport/debug/panels/vsu/solo', 'Hear this channel alone')}
                    onClick={() => this.toggleSolo(channel.index)}
                >S</button>
            </div>

            {/*
              * Whether the channel is sounding — SxINT bit 7, which is the bit
              * that decides whether it contributes anything at all, read from
              * the core rather than from what a game last asked for. The ring
              * marks a channel that will switch itself off when its interval
              * elapses, which is the moment the dot goes out.
              */}
            <span
                className={'vp-vsu-state'
                    + (channel.enabled ? ' on' : '')
                    + (channel.enabled && channel.interval.enabled ? ' timed' : '')}
                title={!channel.enabled
                    ? nls.localize('vueport/debug/panels/vsu/stateOff', 'Switched off')
                    : channel.interval.enabled
                        ? nls.localize(
                            'vueport/debug/panels/vsu/stateTimed',
                            'Playing, for {0}ms, after which the hardware switches it '
                            + 'off again.',
                            String(channel.interval.durationMs))
                        : nls.localize('vueport/debug/panels/vsu/stateOn', 'Playing')}
            />

            <span className='vp-vsu-strip-name'>
                {channel.index + 1}{' '}
                <span className='hint'>{VSU_CHANNEL_SHORT_NAMES[channel.kind]}</span>
            </span>

            {this.renderStripWave(channel)}
            {this.renderStripNote(channel)}

            <span className='vp-vsu-strip-levels'>
                {levelBar(channel, 'left', 'L')}
                {levelBar(channel, 'right', 'R')}
            </span>

            <span className='vp-vsu-strip-detail'>
                {this.renderEnvelope(channel)}
                {channel.interval.enabled && <span
                    className='vp-vsu-chip'
                    title={nls.localize('vueport/debug/panels/vsu/intervalHint',
                        'The hardware switches this channel off after this long')}
                >
                    {channel.interval.durationMs} ms
                </span>}
                {this.renderSweep(channel)}
            </span>
        </div>;
    }

    /**
     * The shape the channel is playing, where there is one.
     *
     * Noise has no waveform to draw — it is an LFSR, and a picture of one
     * would be a picture of whatever the panel invented — so it says its
     * period instead, which is the thing that makes one tap sound different
     * from another.
     */
    protected renderStripWave(channel: VsuChannel): React.ReactNode {
        if (channel.noise) {
            return <span className='vp-vsu-strip-wave hint' title={nls.localize(
                'vueport/debug/panels/vsu/noiseHint', 'Bit {0} of the shift register, repeating every {1} steps',
                String(channel.noise.tapBit), String(channel.noise.period))}
            >
                {nls.localize('vueport/debug/panels/vsu/tap', 'Tap')} {channel.noise.tap}
            </span>;
        }
        const samples = channel.waveform !== undefined ? this.waveforms[channel.waveform] : undefined;
        return <span className='vp-vsu-strip-wave'>
            {samples && <svg className='vp-vsu-spark' viewBox={`0 0 ${SPARK_WIDTH} ${SPARK_HEIGHT}`}>
                <polyline points={plotPoints(samples, SPARK_WIDTH, SPARK_HEIGHT, SAMPLE_MAX)} />
            </svg>}
            <span className='hint' title={nls.localize(
                'vueport/debug/panels/vsu/bankHint', 'The waveform bank this channel is playing')}
            >#{channel.waveform}</span>
        </span>;
    }

    /**
     * The note, because a sound driver was written in notes.
     *
     * The frequency is there too, and both are what the channel is playing
     * right now rather than what it was started at: a swept channel's note
     * walks while you watch it. Noise is a rate and not a pitch — it steps a
     * shift register rather than a waveform — so it is only ever shown as one.
     */
    protected renderStripNote(channel: VsuChannel): React.ReactNode {
        const note = channel.kind === VsuChannelKind.NOISE ? undefined : vsuNoteOf(channel.frequencyHz);
        return <span
            className='vp-vsu-strip-note'
            title={`${nls.localize('vueport/debug/panels/vsu/freq', 'Freq')} ${hex(channel.frequencyRaw, 3)}`
                + (note ? ` · ${note.cents >= 0 ? '+' : '−'}${Math.abs(note.cents)} cents` : '')}
        >
            {note
                ? <>{note.name}{' '}<span className='hint'>{Math.round(channel.frequencyHz)} Hz</span></>
                : <span className='hint'>{Math.round(channel.frequencyHz)} Hz</span>}
        </span>;
    }

    /**
     * The level the channel is at, and where it is going.
     *
     * The arrow and the step time say nothing about a channel whose envelope
     * is switched off: the level simply stays where SxEV0 put it, which is the
     * common case and what most sound drivers do.
     */
    protected renderEnvelope(channel: VsuChannel): React.ReactNode {
        const envelope = channel.envelope;
        return <span className='vp-vsu-chip' title={nls.localize(
            'vueport/debug/panels/vsu/envelope', 'Envelope')}
        >
            {nls.localize('vueport/debug/panels/vsu/env', 'env')} {envelope.initialValue}
            {envelope.enabled
                ? <>
                    {envelope.direction === VsuEnvelopeDirection.GROW ? '↑' : '↓'}
                    {' '}{envelope.stepMs}ms{envelope.repeat ? ' ↻' : ''}
                </>
                : <> {nls.localize('vueport/debug/panels/vsu/flat', 'flat')}</>}
        </span>;
    }

    /** Sweep or modulation, which only the fifth channel has. */
    protected renderSweep(channel: VsuChannel): React.ReactNode {
        const sweep = channel.sweepModulation;
        if (!sweep) {
            return undefined;
        }
        const off = !sweep.enabled || sweep.interval === 0;
        const modulating = sweep.function === VsuSweepModulationFunction.MODULATION;
        return <span className={'vp-vsu-chip' + (off ? '' : ' lit')}>
            {modulating
                ? nls.localize('vueport/debug/panels/vsu/modulation', 'mod')
                : nls.localize('vueport/debug/panels/vsu/sweep', 'sweep')}
            {' '}
            {sweep.direction === VsuSweepDirection.UP ? '↑' : '↓'}{sweep.shift}
            {' '}
            {off
                ? nls.localize('vueport/debug/panels/vsu/off', 'off')
                : `${sweep.intervalMs}ms${sweep.repeat ? ' ↻' : ''}`}
        </span>;
    }

    /**
     * The five waveform banks and the modulation table, drawn together.
     *
     * Together, because which bank a channel plays is a number in its strip
     * and means nothing without the shape behind it — and because the banks
     * are shared: two channels on the same bank change instrument together
     * whether anybody meant them to or not, which is visible here and nowhere
     * else. They are read on every poll like the rest of the panel, since a
     * driver rewrites them while the game plays.
     */
    protected renderTables(channels: VsuChannel[]): React.ReactNode {
        const sweeping = channels[VsuChannelKind.SWEEP]?.sweepModulation;
        const modulating = sweeping?.enabled
            && sweeping.function === VsuSweepModulationFunction.MODULATION;

        return <div className='vp-vsu-tables'>
            <div className='vp-vsu-caption'>
                <div>{nls.localize('vueport/debug/panels/vsu/waveforms', 'Waveform banks')}</div>
            </div>
            <div className='vp-vsu-bank-row'>
                {this.waveforms.map((samples, bank) => {
                    // Which channels would be heard changing if this bank did.
                    const players = channels
                        .filter(channel => channel.waveform === bank && channel.enabled)
                        .map(channel => channel.index + 1);
                    return <div
                        key={bank}
                        className={'vp-vsu-bank'
                            + (players.length > 0 ? ' playing' : '')
                            + (this.justChanged(bank) ? ' changed' : '')}
                        title={hex(VSU_WAVEFORM_BASES[bank], 8)}
                    >
                        <svg viewBox={`0 0 ${PLOT_WIDTH} ${PLOT_HEIGHT}`} preserveAspectRatio='none'>
                            {samples && <polyline
                                points={plotPoints(samples, PLOT_WIDTH, PLOT_HEIGHT, SAMPLE_MAX)}
                            />}
                        </svg>
                        <div className='vp-vsu-bank-label'>
                            <span>#{bank}</span>
                            {players.length > 0 && <span className='vp-vsu-bank-players'>
                                {players.join(' ')}
                            </span>}
                        </div>
                    </div>;
                })}

                {/* The modulation table is a waveform bank in every respect but
                    what it means, so it is drawn beside them — but only when
                    the one channel that can read it is set to. */}
                {modulating && <div
                    className={'vp-vsu-bank playing'
                        + (this.justChanged(this.waveforms.length) ? ' changed' : '')}
                    title={hex(VSU_MODULATION_BASE, 8)}
                >
                    <svg viewBox={`0 0 ${PLOT_WIDTH} ${PLOT_HEIGHT}`} preserveAspectRatio='none'>
                        {/* Signed, so the line is drawn around a middle the
                            waveform plots do not have. */}
                        <line
                            className='vp-vsu-bank-zero'
                            x1='0' y1={PLOT_HEIGHT / 2} x2={PLOT_WIDTH} y2={PLOT_HEIGHT / 2}
                        />
                        {this.modulation && <polyline points={plotPoints(
                            this.modulation.map(sample => sample + MODULATION_RANGE),
                            PLOT_WIDTH, PLOT_HEIGHT, MODULATION_RANGE * 2)}
                        />}
                    </svg>
                    <div className='vp-vsu-bank-label'>
                        <span>{nls.localize('vueport/debug/panels/vsu/modulationTable', 'Mod')}</span>
                        <span className='vp-vsu-bank-players'>5</span>
                    </div>
                </div>}
            </div>
        </div>;
    }
}
