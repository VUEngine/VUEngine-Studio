import { VirtualElement } from '@lumino/virtualdom';
import {
    CirclesThree,
    Code,
    Cpu,
    Database,
    FrameCorners,
    Gauge,
    GridNine,
    HardDrives,
    IconProps,
    ListNumbers,
    Monitor,
    MusicNotes,
    Palette,
    Pulse,
    SpeakerHigh,
    SquaresFour,
    Stack,
    Swatches,
    Table,
    TerminalWindow,
    User,
} from '@phosphor-icons/react';
import * as React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { nls } from '../../common/emulator-nls';
import { EmulatorPanelType } from './emulator-panel';

/**
 * The families a panel falls into, for the Add Panel picker's headings.
 *
 * Every panel now draws its own icon (see {@link EMULATOR_PANEL_ICON}) — this
 * is only what groups the picker into VIDEO (VIP), CPU, and the rest, so
 * twenty names read as a handful of short lists rather than one long
 * alphabetical column.
 */
export enum EmulatorPanelCategory {
    VIP = 'vip',
    CPU = 'cpu',
    MEMORY = 'memory',
    AUDIO = 'audio',
    HARDWARE = 'hardware',
    VUENGINE = 'vuengine',
}

/** A category's heading, in the order the picker groups panels by. */
export const EMULATOR_PANEL_CATEGORIES: { id: EmulatorPanelCategory; label(): string }[] = [
    { id: EmulatorPanelCategory.VIP, label: () => nls.localize('vueport/debug/panels/category/video', 'Video') },
    { id: EmulatorPanelCategory.CPU, label: () => nls.localize('vueport/debug/panels/category/cpu', 'CPU') },
    { id: EmulatorPanelCategory.MEMORY, label: () => nls.localize('vueport/debug/panels/category/memory', 'Memory') },
    { id: EmulatorPanelCategory.AUDIO, label: () => nls.localize('vueport/debug/panels/category/audio', 'Audio') },
    { id: EmulatorPanelCategory.HARDWARE, label: () => nls.localize('vueport/debug/panels/category/hardware', 'Hardware') },
    { id: EmulatorPanelCategory.VUENGINE, label: () => 'VUEngine' },
];

/** Which family each panel belongs to. The screen has none: the picker never offers it. */
const EMULATOR_PANEL_CATEGORY: Record<EmulatorPanelType, EmulatorPanelCategory> = {
    [EmulatorPanelType.ACTORS]: EmulatorPanelCategory.VUENGINE,
    [EmulatorPanelType.DISASSEMBLY]: EmulatorPanelCategory.CPU,
    [EmulatorPanelType.ES_SOUND]: EmulatorPanelCategory.AUDIO,
    [EmulatorPanelType.MEMORY_POOLS]: EmulatorPanelCategory.VUENGINE,
    [EmulatorPanelType.MEMORY]: EmulatorPanelCategory.MEMORY,
    [EmulatorPanelType.PROFILER]: EmulatorPanelCategory.CPU,
    [EmulatorPanelType.REGISTERS]: EmulatorPanelCategory.CPU,
    [EmulatorPanelType.ROM_INFO]: EmulatorPanelCategory.HARDWARE,
    [EmulatorPanelType.RUMBLE_PACK]: EmulatorPanelCategory.HARDWARE,
    [EmulatorPanelType.SCREEN]: EmulatorPanelCategory.HARDWARE,
    [EmulatorPanelType.SRAM]: EmulatorPanelCategory.MEMORY,
    [EmulatorPanelType.TERMINAL]: EmulatorPanelCategory.HARDWARE,
    [EmulatorPanelType.VIP_BGMAPS]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VIP_CHARACTERS]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VIP_FRAME_BUFFERS]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VIP_OBJECTS]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VIP_PALETTES]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VIP_WORLDS]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VCU]: EmulatorPanelCategory.VIP,
    [EmulatorPanelType.VSU]: EmulatorPanelCategory.AUDIO,
};

/** A panel's family and heading. */
export function emulatorPanelCategory(type: EmulatorPanelType): typeof EMULATOR_PANEL_CATEGORIES[number] {
    const id = EMULATOR_PANEL_CATEGORY[type];
    return EMULATOR_PANEL_CATEGORIES.find(category => category.id === id)!;
}

/**
 * One icon per panel, not one per family: twenty tabs that all carried an
 * eye or a grid told the family apart but not the tab, which is exactly the
 * thing a tab's icon is for. Chosen for what the panel actually shows —
 * Palettes gets a palette, Disassembly gets code, SRAM gets a floppy disk —
 * rather than reused wholesale from its category.
 */
const EMULATOR_PANEL_ICON: Record<EmulatorPanelType, React.ComponentType<IconProps>> = {
    [EmulatorPanelType.ACTORS]: User,
    [EmulatorPanelType.DISASSEMBLY]: Code,
    [EmulatorPanelType.ES_SOUND]: MusicNotes,
    [EmulatorPanelType.MEMORY_POOLS]: HardDrives,
    [EmulatorPanelType.MEMORY]: Table,
    [EmulatorPanelType.PROFILER]: Gauge,
    [EmulatorPanelType.REGISTERS]: ListNumbers,
    [EmulatorPanelType.ROM_INFO]: Cpu,
    [EmulatorPanelType.RUMBLE_PACK]: Pulse,
    [EmulatorPanelType.SCREEN]: Monitor,
    [EmulatorPanelType.SRAM]: Database,
    [EmulatorPanelType.TERMINAL]: TerminalWindow,
    [EmulatorPanelType.VIP_BGMAPS]: GridNine,
    [EmulatorPanelType.VIP_CHARACTERS]: SquaresFour,
    [EmulatorPanelType.VIP_FRAME_BUFFERS]: FrameCorners,
    [EmulatorPanelType.VIP_OBJECTS]: CirclesThree,
    [EmulatorPanelType.VIP_PALETTES]: Palette,
    [EmulatorPanelType.VIP_WORLDS]: Stack,
    [EmulatorPanelType.VCU]: Swatches,
    [EmulatorPanelType.VSU]: SpeakerHigh,
};

/** A panel's own icon — what its tab carries, and what the picker shows beside its name. */
export function emulatorPanelIcon(type: EmulatorPanelType): React.ComponentType<IconProps> {
    return EMULATOR_PANEL_ICON[type];
}

/**
 * A panel's icon as a Lumino title renderer, for its own tab.
 *
 * `Title.icon` wants a `VirtualElement.IRenderer` — Lumino's own render
 * contract, not React's — so this bridges the one real icon set the rest of
 * the application draws from into it, the same way `VueportReactWidget`
 * bridges a panel's own content: a React root mounted into whatever DOM node
 * Lumino hands over. `render` can be called again with a *different* host if
 * Lumino ever recreates the tab's icon element (its vdom diffing does not
 * promise otherwise), so the mounted root follows the host rather than being
 * created once and assumed to stay valid.
 */
export function emulatorPanelTitleIcon(type: EmulatorPanelType): VirtualElement.IRenderer {
    const Icon = emulatorPanelIcon(type);
    let root: Root | undefined;
    let mountedOn: HTMLElement | undefined;
    return {
        render(host: HTMLElement): void {
            if (mountedOn !== host || !root) {
                root?.unmount();
                root = createRoot(host);
                mountedOn = host;
            }
            root.render(React.createElement(Icon, { size: 16, weight: 'regular' }));
        },
        unrender(): void {
            // Deferred: React refuses to unmount a root from inside a render
            // or lifecycle it is currently running, which unrender can be
            // called from — the same reason VueportReactWidget defers its own.
            const toUnmount = root;
            root = undefined;
            mountedOn = undefined;
            setTimeout(() => toUnmount?.unmount(), 0);
        },
    };
}
