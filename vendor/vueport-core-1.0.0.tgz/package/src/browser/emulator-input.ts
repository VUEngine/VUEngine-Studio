import { VbKey } from '../common/vb-constants';
import { Disposable } from '../common/emulator-events';
import { VueportInputBindings } from '../common/emulator-settings';
import { Sim } from './core/vb-core';
import {
    EMULATOR_ACTION_COMMANDS,
    EMULATOR_ACTIONS,
    EMULATOR_GAMEPAD_BUTTONS,
    EMULATOR_GAMEPAD_INPUTS,
    EmulatorGamePadButton,
    emulatorGamePadCommand,
} from './emulator-commands';
import { EmulatorAction, EmulatorGamePadKeyCode } from './emulator-types';
import { GamepadProfileResolver, readGamepadFrame } from './emulator-gamepad';
import { GAMEPAD_KEY_TO_VB_KEY } from '../common/emulator-gamepad-profiles';

/**
 * One mapping: the keys currently bound to it, and what pressing them does.
 *
 * A game pad button is held, so it carries the pad code the core wants; an
 * action is run once, so it carries the action. Which of the two it is decides
 * how the key handler treats press and release.
 */
export interface EmulatorInputBinding {
    /** The key codes that trigger it, as `KeyboardEvent.code` spells them. */
    keys: string[];
    command: EmulatorAction | EmulatorGamePadKeyCode;
}

/**
 * The game pad codes the mappings speak, as the mask bits the core wants.
 *
 * Re-exported rather than defined here: it moved to
 * `emulator-gamepad-profiles.ts` when a physical pad grew its own mappings, so
 * that the keyboard and the pad could both reach it without either module
 * depending on the other. Kept exported from here because that is where every
 * caller already imports it from.
 */
export { GAMEPAD_KEY_TO_VB_KEY };

/**
 * Whether a key is being typed into something rather than played on the game
 * pad.
 *
 * The emulator listens for keys on its own outermost node, so that a click
 * anywhere in it — a toolbar button, a panel tab — leaves the keyboard still
 * driving the game. That is the behavior worth having, but it also means
 * every field inside the emulator sends what is typed into it to the game as
 * well: naming a cheat "Quick pause" would mute the sound, open the controller
 * reference and pause, and typing a hexadecimal address into the Memory panel
 * would write a save state on the way past. Which is why the one thing not
 * treated as game input is a key going into a control that takes typing.
 *
 * Buttons are deliberately not on the list. Focus lands on one whenever a
 * person presses it, and a game that stopped answering the keyboard because
 * somebody used the toolbar would be the worse bug by far.
 */
function isTypingTarget(target: EventTarget | null): boolean {
    if (!(target instanceof HTMLElement)) {
        return false;
    }
    // `select` and `input` cover the ones that take arrow keys as well as
    // letters — a range, a number field, a dropdown — which would otherwise
    // rewind or fast forward while being adjusted.
    return target.isContentEditable
        || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName);
}

/**
 * Which of the game pad's buttons a mask holds, in the order the on-screen
 * controller reference reads them: the left half top to bottom, then the right.
 *
 * The mask is the machine's — bits, in the order the hardware latches them —
 * and says nothing about what a person would call the button. This is the one
 * place that knows both, since it is the one place that has the two tables
 * side by side, so anything showing a recorded press asks here rather than
 * building a third table of its own.
 */
export function emulatorHeldButtons(keys: number): EmulatorGamePadButton[] {
    return EMULATOR_GAMEPAD_BUTTONS.filter(button =>
        (keys & GAMEPAD_KEY_TO_VB_KEY[EMULATOR_GAMEPAD_INPUTS[button].key]) !== 0);
}

/**
 * What the input controller needs from the emulator it drives.
 *
 * The controller decides *that* a button was pressed; the host decides what
 * that means. Keeping the split here is what lets the key handling move to
 * vueport without the emulator's action dispatch coming with it.
 */
export interface EmulatorInputHost {
    /** The simulation to push key masks into, once there is one. */
    readonly sim?: Sim;
    /**
     * Where a freshly built mask goes, when it should not go straight in.
     *
     * One machine answering one keyboard wants the mask applied the moment it
     * is built, which is what happens without this. A linked session does not:
     * the same press has to land on the same frame in both windows, so it is
     * booked against a frame rather than applied, and the session is what
     * knows which one. See `link-session.ts`.
     */
    sendKeys?(keys: number): void;
    /** Whether the emulator is on screen at all. */
    readonly isVisible: boolean;
    /** The low battery signal, which is folded into every mask. */
    readonly lowPower: boolean;
    /**
     * False before the ROM has booted, and while a window is taking typing —
     * the palette or settings window — so that typing in one does not also
     * play the game behind it.
     */
    isAcceptingInput(): boolean;
    /** True from the moment rewind is pressed until it is released. */
    readonly rewinding: boolean;
    stopRewinding(): void;
    /** Perform a held input: a game pad button, or rewind. */
    sendCommand(command: string, data?: unknown): void;
    canRunAction(action: EmulatorAction): boolean;
    runAction(action: EmulatorAction): void;
    /** Whether to read player 2's mappings rather than player 1's. */
    usesPlayer2Controls(): boolean;
    /**
     * Which player (1-based) this machine is, or undefined when it is the only
     * one. Undefined is right for a solo emulator — a second pad is a second
     * pair of hands on one game. A linked pair returns 1 and 2, and the
     * resolver decides which pads that means.
     */
    gamepadPlayer?(): number | undefined;
    /**
     * What each connected pad's buttons do, and which player it drives.
     *
     * Absent leaves the pads unread, which is what a host with no settings to
     * resolve them against wants; see `StoredGamepadProfiles` for the one both
     * the emulator and the settings page use.
     */
    gamepadProfiles?(): GamepadProfileResolver | undefined;
}

/**
 * What the controller reports to, and asks, on a macro's behalf.
 *
 * Declared here rather than imported from the macro store, so that neither
 * module depends on the other: the store satisfies this structurally. The
 * controller knows only that something is listening; what it does with what it
 * hears is the store's business.
 */
export interface EmulatorMacroHook {
    /** The player's own buttons changed, and this is what they now hold. */
    recordKeys(keys: number): void;
    /**
     * Move whatever is playing on by one frame.
     *
     * Called from the loop the game pad is already polled in, rather than from
     * a second one of the store's own: both want the same tick, and one
     * animation frame callback is cheaper than two.
     */
    tick(): void;
}

/**
 * Every attached controller's node, and which of them last had the keyboard.
 *
 * `takeFocus` hands the keyboard back to the game whenever nothing has a
 * better claim on it — but a second emulator in the same document is such a
 * claim, and standalone vueport never had to say so because it puts the other
 * player in a window of its own, where `hasFocus` settles it. Two emulators in
 * one window is what the studio's linked pair is: every click ran both
 * controllers' document listeners, the one attached last always won, and the
 * tab somebody was actually playing went deaf to the keyboard.
 */
const attachedNodes = new Set<HTMLElement>();
let keyboardOwner: HTMLElement | undefined;

/**
 * Keyboard and game pad input for one emulator.
 *
 * Owns the key masks, because they have exactly one correct value at a time and
 * two sources — the keyboard and a physical pad — that have to be combined
 * before the core sees either. The host asks for presses through `setKey` and
 * `tapKey` rather than touching the masks, so there is one place that knows
 * what the core is currently being told.
 */
export class EmulatorInputController implements Disposable {

    /** Currently held keyboard buttons, as a VbKey mask. */
    protected pressedKeys = 0;
    /** Currently held physical controller buttons, as a VbKey mask. */
    protected gamepadKeys = 0;
    /** Currently held by a macro playing back, as a VbKey mask. */
    protected macroKeys = 0;
    /**
     * Emulator actions whose pad control was held on the previous frame.
     *
     * A pad has no press and release events — it is polled — so an action bound
     * to one has to be edged by hand, or holding the button would run the
     * action sixty times a second. Held rather than counted, because rewind is
     * held down and needs its release as well as its press.
     */
    protected heldGamepadActions = new Set<EmulatorAction>();
    /**
     * What the player was last holding, so a macro is only told about changes.
     *
     * -1 rather than 0 to begin with, since 0 is a mask somebody can be
     * holding and the first report has to go out whatever it says.
     */
    protected reportedPlayerKeys = -1;
    /** Last mask handed to the core, so unchanged frames cost nothing. */
    protected appliedKeys = -1;
    /** The animation frame the game pad and macro playback share. */
    protected frameHandle?: number;
    /**
     * Whether the host was taking input on the previous frame, so that a window
     * giving the keyboard back can be told from every frame after it. See
     * `keepFocus`.
     */
    protected wasAcceptingInput = false;

    /** Every mapping, keyed by the button or action it drives. */
    protected _bindings: Record<string, EmulatorInputBinding> = {};

    /** Where button changes are reported, and playback is stepped. */
    protected macros: EmulatorMacroHook | undefined;

    protected node?: HTMLElement;
    protected screenNode?: HTMLElement;

    constructor(
        protected readonly host: EmulatorInputHost,
        protected readonly keymap: VueportInputBindings,
    ) { }

    get bindings(): Record<string, EmulatorInputBinding> {
        return this._bindings;
    }

    /**
     * The buttons the player themselves is holding, keyboard and pad together.
     *
     * What a macro records, and deliberately not what the core is given: the
     * mask that goes into the machine also carries a macro's own buttons and
     * the two signals that are not buttons at all.
     */
    get playerKeys(): number {
        return this.pressedKeys | this.gamepadKeys;
    }

    /** Introduce the macros, or take them away again. */
    setMacroHook(macros: EmulatorMacroHook | undefined): void {
        this.macros = macros;
        if (!macros) {
            this.setMacroKeys(0);
        }
    }

    /**
     * Hold exactly these buttons on a playing macro's behalf.
     *
     * Kept apart from the player's own rather than written into them, so that
     * a macro cannot leave a button down that somebody then has to press and
     * release to clear — and so that pressing something while one plays adds
     * to it instead of fighting it.
     */
    setMacroKeys(keys: number): void {
        if (keys === this.macroKeys) {
            return;
        }
        this.macroKeys = keys;
        this.applyKeys();
    }

    /**
     * Re-read every mapping out of the keybinding registry.
     *
     * Built from the two tables that already say what exists — the game pad's
     * buttons and the emulator's actions — rather than listed again here, so a
     * new action needs adding in one place and gets its mapping for free.
     */
    refreshBindings(): void {
        const player = this.host.usesPlayer2Controls() ? 2 : 1;
        const input: Record<string, EmulatorInputBinding> = {};

        for (const button of EMULATOR_GAMEPAD_BUTTONS) {
            input[button] = {
                keys: this.keymap.keyCodes(
                    emulatorGamePadCommand(button, player).id
                ),
                command: EMULATOR_GAMEPAD_INPUTS[button].key,
            };
        }

        for (const action of EMULATOR_ACTIONS) {
            input[action] = {
                keys: this.keymap.keyCodes(
                    EMULATOR_ACTION_COMMANDS[action].id
                ),
                command: action,
            };
        }

        this._bindings = input;
    }

    /** Listen on the emulator's node, and on its screen for focus. */
    attach(node: HTMLElement, screenNode: HTMLElement): void {
        this.node = node;
        this.screenNode = screenNode;
        node.tabIndex = 0;
        node.addEventListener('keydown', this.keyEventListener);
        node.addEventListener('keyup', this.keyEventListener);
        node.addEventListener('focusin', this.focusInListener);
        node.addEventListener('focusout', this.focusOutListener);
        screenNode.addEventListener('mousedown', this.focusListener);
        // On the document, not the node: the point of it is the clicks that land
        // outside the emulator. Bubbling, so whatever was clicked has already
        // had its say by the time the keyboard changes hands.
        node.ownerDocument.addEventListener('click', this.clickListener);
        attachedNodes.add(node);
        this.startInputLoop();
    }

    /**
     * Take the keyboard back.
     *
     * The emulator only hears keys while focus is somewhere inside the node
     * this listens on, and focus can leave it without anybody meaning it to —
     * pressing a button that then disappears drops focus onto the document,
     * which is nowhere. Anything that is about to promise the keyboard will be
     * heard calls this first; see the macro store's `startRecording`. It is also
     * taken back on its own — see `keepFocus`, which is what makes a game answer
     * the keyboard without being clicked first — and this is the outright
     * version, for a caller that has its own reason and cannot wait for a frame.
     */
    focus(): void {
        this.node?.focus();
    }

    detach(): void {
        this.node?.removeEventListener('keydown', this.keyEventListener);
        this.node?.removeEventListener('keyup', this.keyEventListener);
        this.node?.removeEventListener('focusin', this.focusInListener);
        this.node?.removeEventListener('focusout', this.focusOutListener);
        this.screenNode?.removeEventListener('mousedown', this.focusListener);
        this.node?.ownerDocument.removeEventListener('click', this.clickListener);
        if (this.node) {
            attachedNodes.delete(this.node);
            if (keyboardOwner === this.node) {
                // Nobody owns it now, so the emulator that is left can have it.
                keyboardOwner = undefined;
            }
        }
        this.stopInputLoop();
    }

    /** Hold or release one game pad button. */
    async setKey(vbKey: VbKey, down: boolean): Promise<void> {
        if (down) {
            this.pressedKeys |= vbKey;
        } else {
            this.pressedKeys &= ~vbKey;
        }
        await this.applyKeys();
    }

    /**
     * Press and release one button.
     *
     * The on-screen controls send a press rather than a hold, so it is released
     * again after long enough for the ROM to notice.
     */
    async tapKey(vbKey: VbKey): Promise<void> {
        this.pressedKeys |= vbKey;
        await this.applyKeys();
        setTimeout(() => {
            this.pressedKeys &= ~vbKey;
            this.applyKeys();
        }, 50);
    }

    /** Push the combined mask into the core, if it has changed. */
    async applyKeys(): Promise<void> {
        // Before the mask is built, so that a macro being recorded sees the
        // press at the moment it happened rather than a frame later.
        const player = this.playerKeys;
        if (player !== this.reportedPlayerKeys) {
            this.reportedPlayerKeys = player;
            this.macros?.recordKeys(player);
        }

        const keys = VbKey.SGN                            // marks a controller as present
            | (this.host.lowPower ? VbKey.PWR : 0)        // low battery signal
            | player
            // A macro's buttons and the player's are held at once: one adds to
            // the other rather than replacing it.
            | this.macroKeys;

        // The gamepad is polled every frame, and most frames change nothing.
        if (keys === this.appliedKeys) {
            return;
        }
        this.appliedKeys = keys;
        if (this.host.sendKeys) {
            this.host.sendKeys(keys);
            return;
        }
        await this.host.sim?.setKeys(keys);
    }

    /** Forget what the core was last told, so the next apply re-sends it. */
    invalidate(): void {
        this.appliedKeys = -1;
    }

    protected keyEventListener = (e: KeyboardEvent) => this.processKeyEvent(e);

    /**
     * Reclaim keyboard focus for the widget that owns the keydown listener.
     *
     * The screen used to be an iframe, which is its own focus scope, so
     * clicking into it and then pressing a key just worked. It is a plain
     * canvas now, nested inside the debug dock's own Lumino DockPanel — clicking
     * around inside that dock (switching tabs, focusing another panel's input)
     * moves DOM focus without ever involving the emulator, so the keydown
     * listener on its node stops receiving anything. Scoped to the screen
     * rather than the whole widget, so it does not fight over focus with, say,
     * typing an address into the Memory panel.
     */
    protected focusListener = () => this.node?.focus();

    /**
     * Remember which emulator the keyboard was last given to.
     *
     * `focusin` rather than `focus`, so that focus landing anywhere inside the
     * widget — the toolbar, a panel — counts as this emulator having it, which
     * is the same reach the key listener has.
     */
    protected focusInListener = () => {
        if (this.node) {
            keyboardOwner = this.node;
        }
    };

    /**
     * Focus leaving the emulator swallows the release, which would leave rewind
     * stuck on. Moves within it are fine and must not end it, since the toolbar
     * button lives there too.
     */
    protected focusOutListener = (e: FocusEvent) => {
        const next = e.relatedTarget;
        if (!(next instanceof Node) || !this.node?.contains(next)) {
            this.host.stopRewinding();
        }
    };

    protected processKeyEvent(e: KeyboardEvent): void {
        // Releasing rewind always ends it, before any of the guards below, since a
        // release that got filtered out would leave the emulator suspended with no
        // way back: pausing, or opening the controls overlay, while the key is held
        // is enough to change what those guards allow through.
        if (
            e.type === 'keyup' &&
            this.host.rewinding &&
            this.matchKey(this._bindings[EmulatorAction.Rewind]?.keys ?? [], e.code)
        ) {
            this.host.stopRewinding();
        }

        // do not process key input...
        if (
            e.repeat || // ... on repeated event firing
            !this.host.isVisible || // ... if emulator is not visible
            !this.host.isAcceptingInput() || // ... if it is not ready to take it
            isTypingTarget(e.target) // ... or the key is being typed into something
        ) {
            return;
        }

        for (const key in this._bindings) {
            if (!this._bindings.hasOwnProperty(key)) {
                continue;
            }
            const input = this._bindings[key];
            if (!this.matchKey(input.keys, e.code)) {
                continue;
            }
            // A game pad button is held, so it needs the press and the release;
            // rewind is held too, and its release is what ends it. Everything else
            // is an action, and acts once, through its command.
            if (GAMEPAD_KEY_TO_VB_KEY[input.command as EmulatorGamePadKeyCode] !== undefined
                || input.command === EmulatorAction.Rewind) {
                this.host.sendCommand(e.type, input.command);
            } else if (e.type === 'keydown' && this.host.canRunAction(input.command as EmulatorAction)) {
                this.host.runAction(input.command as EmulatorAction);
            }
        }
    }

    protected matchKey(keyCodes: string[], keyCode: string): boolean {
        return keyCodes.includes(keyCode);
    }

    /**
     * Run the emulator actions a pad has just started holding, and end the one
     * that is held rather than tapped.
     *
     * The guards are the keyboard's, for the same reasons `processKeyEvent`
     * gives: a release always ends rewind, before anything else, since a
     * release that got filtered out would leave the emulator suspended with no
     * way back. Everything else waits until the emulator is on screen and
     * taking input — but not on `isTypingTarget`, which has no meaning here: a
     * game pad is never what somebody is typing a cheat's name with.
     */
    protected dispatchGamepadActions(held: Set<EmulatorAction>): void {
        if (this.heldGamepadActions.has(EmulatorAction.Rewind)
            && !held.has(EmulatorAction.Rewind)
            && this.host.rewinding) {
            this.host.stopRewinding();
        }

        if (!this.host.isVisible || !this.host.isAcceptingInput()) {
            // Nothing is dispatched, but the held set still has to keep up:
            // remembering a button as held across a pause would swallow its
            // next press, and forgetting one would fire the moment play
            // resumed with the button still down.
            this.heldGamepadActions = held;
            return;
        }

        for (const action of held) {
            if (this.heldGamepadActions.has(action)) {
                continue;
            }
            // Rewind is held for as long as the button is, so it goes through
            // the same held-command path the keyboard uses rather than being
            // run once.
            if (action === EmulatorAction.Rewind) {
                this.host.sendCommand('keydown', action);
            } else if (this.host.canRunAction(action)) {
                this.host.runAction(action);
            }
        }

        this.heldGamepadActions = held;
    }

    /**
     * Take the keyboard back whenever nothing has a better claim on it.
     *
     * Keys are heard on the emulator's own node, so something inside it has to
     * hold focus for the game to answer the keyboard at all — and the very
     * gestures a person makes around a game are the ones that lose it. Pressing
     * the start page's button, or anything in the title bar, moves focus out of
     * the emulator; the button that started the game is gone from the DOM by the
     * time it is running, and removing the focused element leaves focus on the
     * document body, which hears nothing at all. Which is why a session used to
     * begin with a key press that did nothing and a click on the picture to make
     * the keyboard work.
     *
     * Called from the frame loop for the two moments a game should simply have
     * the keyboard: focus has fallen to nowhere, and a window that was taking
     * the keyboard has just closed. A click takes it back too — see
     * `clickListener` — which is the third of the three, and the one that is an
     * event because nothing about the frame it happens on says it happened.
     */
    protected keepFocus(): void {
        const accepting = this.host.isVisible && this.host.isAcceptingInput();
        // True on the one frame a modal window stops holding the keyboard: the
        // settings or game-info window closing, a picker answered. Read as an
        // edge rather than a state, so the game is given the keyboard once
        // rather than held onto it against everything else that wants it.
        const released = accepting && !this.wasAcceptingInput;
        this.wasAcceptingInput = accepting;
        if (released || this.focusIsNowhere()) {
            this.takeFocus();
        }
    }

    /** Whether focus is on nothing — the document body, or no element at all. */
    protected focusIsNowhere(): boolean {
        const owner = this.node?.ownerDocument;
        if (!owner) {
            return false;
        }
        const active = owner.activeElement;
        // Removing the element that had focus leaves it on one of these two,
        // depending on the browser; neither hears a key.
        return !active || active === owner.body || active === owner.documentElement;
    }

    /**
     * Give the keyboard to the game, unless something has a better claim on it.
     *
     * Not while a window is taking the keyboard — the same `isAcceptingInput`
     * the keys themselves pass in `processKeyEvent`, so a modal keeps them for
     * as long as it is up. Not from anything being typed into, which is the same
     * line `isTypingTarget` draws for the keys, and the reason clicking into a
     * panel's address field then typing still goes where it was aimed. And not
     * in a window nobody is looking at, which is what stops the second player's
     * window from grabbing at focus while somebody plays in the first.
     */
    protected takeFocus(): void {
        const node = this.node;
        if (!node || !this.host.isVisible || !this.host.isAcceptingInput()) {
            return;
        }
        const owner = node.ownerDocument;
        if (!owner.hasFocus()) {
            return;
        }
        const active = owner.activeElement;
        if (active && (node.contains(active) || isTypingTarget(active))) {
            return;
        }
        // Not out of another emulator's hands. Two of them in one document —
        // the studio's linked pair — both hear every click, and reclaiming on
        // each would hand the keyboard to whichever attached last rather than
        // to the one being played. Whoever had it last keeps it, until they go
        // away or somebody clicks into the other one, which is a focus of its
        // own and moves the ownership with it.
        if (keyboardOwner && keyboardOwner !== node
            && attachedNodes.has(keyboardOwner) && keyboardOwner.isConnected) {
            return;
        }
        node.focus({ preventScroll: true });
    }

    /**
     * A click anywhere hands the keyboard back to the game.
     *
     * Somebody who has just pressed a button in the chrome — fullscreen, a
     * panel's tab, a toggle in the settings column — is done with it and wants
     * to play; the button keeps the focus a click gives it otherwise, and the
     * game stays deaf until the picture is clicked. This is the screen's own
     * `mousedown` handler generalized to the rest of the window, and it leans on
     * the same guards: a field being typed into keeps focus, and a modal window
     * keeps it for everything inside it.
     *
     * `detail` is what tells a pressed button from a pressed key: activating a
     * focused button with Space or Enter sends a click too, and tabbing to a
     * control only to have the game take focus back a moment later would make
     * the interface unusable from the keyboard.
     */
    protected clickListener = (e: MouseEvent) => {
        if (e.detail > 0) {
            this.takeFocus();
        }
    };

    /**
     * The one loop input runs on: the game pad is read from it, and whatever
     * macro is playing is stepped along by it.
     *
     * Both want to be looked at once a frame and neither is worth a timer of
     * its own, so they share the animation frame the pad already needed.
     */
    protected startInputLoop(): void {
        if (this.frameHandle !== undefined) {
            return;
        }
        const frame = () => {
            this.frameHandle = requestAnimationFrame(frame);
            this.keepFocus();
            const resolver = this.host.gamepadProfiles?.();
            if (resolver) {
                // Solo, every pad feeds this machine (a second one is a second
                // pair of hands). Linked, each side reads only the pads
                // assigned to it — which the resolver decides, from the host's
                // player number.
                const pad = readGamepadFrame(resolver, this.host.gamepadPlayer?.());
                if (pad.keys !== this.gamepadKeys) {
                    this.gamepadKeys = pad.keys;
                    this.applyKeys();
                }
                this.dispatchGamepadActions(pad.actions);
            }
            this.macros?.tick();
        };
        this.frameHandle = requestAnimationFrame(frame);
    }

    protected stopInputLoop(): void {
        if (this.frameHandle !== undefined) {
            cancelAnimationFrame(this.frameHandle);
            this.frameHandle = undefined;
        }
    }

    dispose(): void {
        this.detach();
    }
}
