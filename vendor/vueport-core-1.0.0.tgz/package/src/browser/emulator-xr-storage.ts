/**
 * What is kept about playing in a headset between sittings — the screen's
 * size and depth, and what is around it — and how a click that may start one
 * is told apart. See `EmulatorXrController`.
 *
 * In the browser's own storage rather than among the settings: it is mostly
 * set from inside a headset, and it is the same for every host on a machine.
 */

import { nls } from '../common/emulator-nls';
import { clampXrScreen, XrBackdrop, XrScreen, XR_DEPTH_SCALE } from './emulator-xr';

/** Where the headset's screen size and depth are kept; see `EmulatorXrController.screen`. */
const XR_SCREEN_KEY = 'vueport.xrView';
/**
 * Where they were kept while the depth was still in the machine's own terms,
 * before `XR_DEPTH_SCALE`: read once, in the new terms, and let go.
 */
const XR_SCREEN_KEY_BEFORE_SCALE = 'vueport.xrScreen';

export function loadXrScreen(): XrScreen {
    try {
        const stored = localStorage.getItem(XR_SCREEN_KEY);
        if (stored) {
            return clampXrScreen(JSON.parse(stored) as Partial<XrScreen>);
        }
        const before = localStorage.getItem(XR_SCREEN_KEY_BEFORE_SCALE);
        if (before) {
            const old = JSON.parse(before) as Partial<XrScreen>;
            // The same depth as it was played at, in the headset's terms.
            const screen = clampXrScreen({
                width: old.width,
                depth: old.depth === undefined ? undefined : old.depth / XR_DEPTH_SCALE,
            });
            saveXrScreen(screen);
            localStorage.removeItem(XR_SCREEN_KEY_BEFORE_SCALE);
            return screen;
        }
    } catch {
        // Unreadable or refused: start out as anybody would.
    }
    return clampXrScreen({});
}

export function saveXrScreen(screen: XrScreen): void {
    try {
        localStorage.setItem(XR_SCREEN_KEY, JSON.stringify(screen));
    } catch {
        // Kept for this session only.
    }
}

/**
 * Whether the person has just done something the browser counts as asking —
 * a click, a key — which is what it grants a headset to. Browsers without the
 * User Activation API are given the benefit of the doubt: the worst a wrong
 * guess costs is a refusal, which the VR button in the title bar then makes up for.
 */
export function userActivationIsActive(): boolean {
    const activation = (navigator as Navigator & { userActivation?: { isActive: boolean } }).userActivation;
    return activation?.isActive ?? true;
}

/** Where the choice of what is around the screen is kept; see `EmulatorXrController.backdrop`. */
const XR_BACKDROP_KEY = 'vueport.xrBackdrop';
/** Where it was kept while it was only passthrough on or off: read once, and let go. */
const XR_PASSTHROUGH_KEY = 'vueport.xrPassthrough';

/** Every choice of what is around the screen, in the order a menu goes round them. */
export const XR_BACKDROPS: readonly XrBackdrop[] = ['black', 'passthrough', 'hologram'];

/** What a backdrop is called, in the headset's menu and in the settings pane alike. */
export function xrBackdropLabel(backdrop: XrBackdrop): string {
    switch (backdrop) {
        case 'passthrough':
            return nls.localize('vueport/xr/menu/backdrop/passthrough', 'Passthrough');
        case 'hologram':
            return nls.localize('vueport/xr/menu/backdrop/hologram', 'Hologram');
        default:
            return nls.localize('vueport/xr/menu/backdrop/black', 'Black');
    }
}

/** What was last wanted around the screen. */
export function loadXrBackdrop(): XrBackdrop {
    try {
        const stored = localStorage.getItem(XR_BACKDROP_KEY);
        if (XR_BACKDROPS.includes(stored as XrBackdrop)) {
            return stored as XrBackdrop;
        }
        const before = localStorage.getItem(XR_PASSTHROUGH_KEY);
        if (before !== null) {
            const backdrop: XrBackdrop = before === 'true' ? 'passthrough' : 'black';
            saveXrBackdrop(backdrop);
            localStorage.removeItem(XR_PASSTHROUGH_KEY);
            return backdrop;
        }
    } catch {
        // Unreadable or refused: a room of its own.
    }
    return 'black';
}

export function saveXrBackdrop(backdrop: XrBackdrop): void {
    try {
        localStorage.setItem(XR_BACKDROP_KEY, backdrop);
    } catch {
        // Kept for this session only.
    }
}

/** The one after it, for a menu that goes round them. */
export function nextXrBackdrop(backdrop: XrBackdrop): XrBackdrop {
    return XR_BACKDROPS[(XR_BACKDROPS.indexOf(backdrop) + 1) % XR_BACKDROPS.length];
}
