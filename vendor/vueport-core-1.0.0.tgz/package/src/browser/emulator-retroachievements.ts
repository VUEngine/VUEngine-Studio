/**
 * The RetroAchievements account and the achievement set for whatever ROM is
 * running — the DOM side's half of the integration, the worker's being
 * `vb-rcheevos.ts`.
 *
 * Held by the widget the way {@link CheatStore} is: constructed
 * once, told about the running session as it comes and goes, and read by the
 * Achievements panel through `onDidChange`. Logging in does not need a session
 * — it is a plain call to RetroAchievements' own login endpoint, independent of
 * the worker — so an account can be entered from Settings before any ROM is
 * open; a session only has to know the token to authenticate the achievement
 * engine with once one starts.
 */

import { Emitter, Event, Disposable, DisposableCollection } from '../common/emulator-events';
import { VueportNotifications } from '../common/emulator-host';
import { nls } from '../common/emulator-nls';
import { Core, Sim } from './core/vb-core';
import {
    RaAchievement,
    VesRaEvent,
    RaGame,
    RaLeaderboard,
    VesRaLeaderboardEntries,
} from '../common/vb-protocol';
import {
    AchievementBackup,
    AchievementBackupGame,
    achievementBackupByHash,
    achievementBackupToRaGame,
    achievementBackupToRaList,
} from './emulator-achievement-backup';

/** The RetroAchievements API endpoint every request in this file goes to. */
const RA_DOREQUEST = 'https://retroachievements.org/dorequest.php';

/** Where someone without an account goes to make one. */
export const RA_SIGN_UP_URL = 'https://retroachievements.org/createaccount.php';

/** A RetroAchievements user's public profile page. */
export function raUserProfileUrl(username: string): string {
    return `https://retroachievements.org/user/${encodeURIComponent(username)}`;
}

/**
 * The titles RetroAchievements sends back as if they were achievements of the
 * running set, to warn about the session rather than to be earned.
 *
 * The emulator ones arrive whenever the connecting client's user agent is not
 * on the allowlist — VUEPort's own state until RetroAchievements approves it
 * (see the client warning shown elsewhere in the panel). The version one
 * arrives when the ROM hashes to a build the set was not made for. None of
 * them carry points or unlock anything, so they are noise in the list rather
 * than something to show, count or announce.
 */
const RA_NOTICE_TITLES = new Set([
    'warning: unknown emulator',
    'unsupported emulator',
    'unsupported game version',
]);

/** The one notice the panel says something of its own about. */
const RA_UNSUPPORTED_VERSION_TITLE = 'unsupported game version';

/** Which of {@link RA_NOTICE_TITLES} a title is, normalized, or `undefined`. */
function raNoticeTitle(title: string): string | undefined {
    const normalized = title.trim().toLowerCase();
    return RA_NOTICE_TITLES.has(normalized) ? normalized : undefined;
}

/** One HTTP call a host can make on the engine's or the login flow's behalf. */
export interface RetroAchievementsTransport {
    /**
     * Whether this host can reach RetroAchievements at all.
     *
     * False in a browser: `dorequest.php` sends no CORS headers, so the page
     * cannot read the reply. The desktop shell proxies the request through its
     * own process, which is not subject to that.
     */
    readonly available: boolean;
    request(
        method: 'GET' | 'POST',
        url: string,
        body: string | undefined,
        contentType: string | undefined,
    ): Promise<{ status: number, body: string }>;
}

/** A transport for a host that cannot reach RetroAchievements at all. */
export const UNAVAILABLE_RA_TRANSPORT: RetroAchievementsTransport = {
    available: false,
    async request(): Promise<{ status: number, body: string }> {
        throw new Error('RetroAchievements cannot be reached from this build.');
    },
};

/** Where the logged-in account's username and API token are kept. */
export interface RetroAchievementsCredentials {
    load(): Promise<{ username: string, token: string } | undefined>;
    save(credentials: { username: string, token: string }): Promise<void>;
    clear(): Promise<void>;
}

/** The logged-in account, as much of it as the panel and the settings page want. */
export interface RetroAchievementsAccount {
    username: string;
    token: string;
    score: number;
    softcoreScore: number;
    /** The account's profile picture, on `media.retroachievements.org`, when it has one. */
    avatarUrl?: string;
}

/**
 * What the host does for hardcore mode, and where it keeps the preference.
 *
 * Handed to {@link RetroAchievementsService.setHardcoreControls}; a host that
 * never calls it leaves {@link RetroAchievementsService.hardcoreControlsAvailable}
 * false and the panel's hardcore switch does not appear. The service owns the
 * question the player is asked and the engine flag; the discipline hardcore
 * imposes on the rest of the emulator is the host's, since only it can restart
 * a ROM or move between Play and Debug.
 */
export interface RetroAchievementsHardcoreControls {
    /** The persisted hardcore preference. */
    isEnabled(): boolean;
    /** Persist a new value. */
    persist(enabled: boolean): void | Promise<void>;
    /**
     * Force Play mode, switch every cheat off, stop any running macro and
     * restart the ROM from the beginning. Run once, right after the player
     * confirms turning hardcore on — leaving hardcore needs none of it.
     */
    enter(): void | Promise<void>;
}

/**
 * The question put to the player before hardcore mode goes on.
 *
 * Here rather than in the host so both the panel switch and the command
 * palette ask it in the same words, and it is translated once.
 */
export function hardcoreConfirmation(): { title: string, message: string[], okLabel: string } {
    return {
        title: nls.localize('vueport/achievements/hardcore/confirmTitle', 'Turn on Hardcore Mode?'),
        message: [
            nls.localize('vueport/achievements/hardcore/confirmWhat',
                'Hardcore mode requires you to play without any aids. \
As such, cheats, macros and patches are switched off, loading a \
save state, rewinding and frame advance are disabled, and Debug mode is unavailable.'),
            nls.localize('vueport/achievements/hardcore/confirmPending',
                'VUEPort is still awaiting RetroAchievements approval, so hardcore unlocks can not be \
credited to your account yet.'),
        ],
        okLabel: nls.localize('vueport/achievements/hardcore/confirmOk', 'Turn on Hardcore Mode'),
    };
}

/**
 * Shown when the player reaches for something hardcore mode has taken away —
 * rewind, loading a save state, the cheats or macros panel, Debug mode. Says
 * why, and offers the way out, which is immediate and does not restart.
 */
export function hardcoreOnNotice(): { title: string, message: string[], okLabel: string } {
    return {
        title: nls.localize('vueport/achievements/hardcore/onTitle', 'Hardcore Mode is on'),
        message: [
            nls.localize('vueport/achievements/hardcore/onWhat',
                'Cheats, macros, patches, loading a save state, rewind, slow motion, frame advance and \
Debug mode are all disabled while hardcore mode is on.'),
            nls.localize('vueport/achievements/hardcore/onLeave',
                'You can turn it off now. Takes effect immediately and does not restart the game.'),
        ],
        okLabel: nls.localize('vueport/achievements/hardcore/onOff', 'Turn off Hardcore Mode'),
    };
}

/** Why RetroAchievements is not doing anything right now, for the panel to say so. */
export type RetroAchievementsUnavailableReason =
    | 'disabled'
    | 'transport'
    | 'engine'
    | 'not-logged-in'
    | 'no-rom'
    | 'not-recognized';

function formEncode(fields: Record<string, string>): string {
    return Object.entries(fields)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
        .join('&');
}

export class RetroAchievementsService implements Disposable {

    protected account: RetroAchievementsAccount | undefined;
    protected game: RaGame | undefined;
    protected achievements: RaAchievement[] = [];
    protected leaderboards: RaLeaderboard[] = [];
    /** Why there are no leaderboards, when the engine rather than the game is the reason. */
    protected leaderboardsReason: string | undefined;
    /**
     * The running attempts' values, by tracker id — not by leaderboard id:
     * the engine gives several leaderboards reading the same value one shared
     * tracker, so this is exactly the set of readouts to draw.
     */
    protected readonly trackers = new Map<number, string>();
    protected loadReason: string | undefined;
    protected engineReason: string | undefined;
    /**
     * Whether the set's achievements have arrived for the running ROM.
     *
     * The list alone cannot say: an answer carrying nothing but the notices of
     * {@link RA_NOTICE_TITLES} filters down to an empty list, which is a set
     * that is in but has nothing to show rather than one still on its way.
     */
    protected achievementsLoaded = false;
    /**
     * Whether RetroAchievements answered with its "unsupported game version"
     * notice for the running ROM — a set exists, but not for this build of it.
     * The notice itself is dropped like the rest of {@link RA_NOTICE_TITLES};
     * this is what is left of it, for the panel to say so in its own words.
     */
    protected unsupportedVersion = false;
    protected loggingIn = false;

    protected core: Core | undefined;
    protected sim: Sim | undefined;
    /**
     * The running ROM's hash, kept so a set can be (re-)loaded for it — after
     * a late login, in particular: a ROM opened before anyone signed in has
     * nothing to load a set for until now.
     */
    protected romHash: string | undefined;
    protected readonly sessionDisposables = new DisposableCollection();

    /** Set by the host; without it the panel's hardcore switch stays hidden. */
    protected hardcoreControls: RetroAchievementsHardcoreControls | undefined;

    /**
     * The offline snapshot of every VB set, and how to get it. The loader is
     * set by the host; it is called at most once, the first time a running ROM
     * has no live set, and its result is indexed by hash into `backupByHash`.
     */
    protected backupLoader: (() => Promise<AchievementBackup | undefined>) | undefined;
    protected backupByHash: Map<string, AchievementBackupGame> | undefined;
    protected backupTried = false;
    /** The snapshot's set for the running ROM, when the live one is missing. */
    protected backupGame: AchievementBackupGame | undefined;
    /** Memoized {@link RaGame} / list for {@link backupGame}. */
    protected backupView: { game: RaGame, list: RaAchievement[] } | undefined;

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires whenever anything the panel or the settings page shows has changed. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    protected readonly onUnlockedEmitter = new Emitter<{
        title: string, description: string, points: number, badgeUrl: string,
    }>();
    /** Fires once per earned achievement, for a host to show as a toast. */
    readonly onUnlocked = this.onUnlockedEmitter.event;

    protected readonly onDidChangeTrackersEmitter = new Emitter<void>();
    /**
     * Fires when a leaderboard attempt's readout changes — many times a
     * second while one is running.
     *
     * Deliberately not folded into `onDidChange`: that one redraws the whole
     * achievements panel, and a running timer would have it doing so every
     * frame. Only the small overlay over the picture listens here.
     */
    readonly onDidChangeTrackers: Event<void> = this.onDidChangeTrackersEmitter.event;

    protected readonly onLeaderboardAttemptEmitter =
        new Emitter<Extract<VesRaEvent, { kind: 'leaderboardAttempt' }>>();
    /**
     * Fires when an attempt starts, is abandoned, or is sent in — for a host
     * to show as a toast, the way {@link onUnlocked} is shown.
     */
    readonly onLeaderboardAttempt = this.onLeaderboardAttemptEmitter.event;

    protected readonly onScoreboardEmitter =
        new Emitter<Extract<VesRaEvent, { kind: 'leaderboardScoreboard' }>>();
    /**
     * Fires with the server's answer to a submission: where it put the
     * player, and the top of the board as it now stands. Always preceded by
     * an `onLeaderboardAttempt` for the same board, a round trip earlier.
     */
    readonly onScoreboard = this.onScoreboardEmitter.event;

    constructor(
        readonly transport: RetroAchievementsTransport,
        protected readonly credentials: RetroAchievementsCredentials,
        protected readonly notifications: VueportNotifications,
        /** Whether the setting that turns the whole feature on is set. */
        protected readonly enabled: () => boolean,
    ) { }

    /** Read a previously saved account back, if there is one. Call once at start-up. */
    async restore(): Promise<void> {
        const stored = await this.credentials.load().catch(() => undefined);
        if (!stored) {
            return;
        }
        this.account = { ...stored, score: 0, softcoreScore: 0 };
        this.changed();
        // A bare credential carries no score, softcore score or avatar — only
        // ever refreshed by an actual server round trip. Without this, Settings
        // showed zeroes and no avatar until a ROM opened and armed the engine
        // (`authenticateSession`, below); this reaches RetroAchievements the
        // same plain way `login` does, so the account looks right immediately.
        await this.refreshAccount().catch(() => undefined);
    }

    /**
     * Tell the service how to run hardcore mode. Call once at start-up, before
     * the panel is shown. See {@link RetroAchievementsHardcoreControls}.
     */
    setHardcoreControls(controls: RetroAchievementsHardcoreControls): void {
        this.hardcoreControls = controls;
        this.changed();
    }

    /**
     * Provide the offline snapshot loader — the shipped fallback for when the
     * live site cannot be reached. Call once at start-up; the loader itself is
     * only invoked the first time a running ROM turns out to have no live set.
     * See {@link emulator-achievement-backup}.
     */
    setBackupLoader(loader: () => Promise<AchievementBackup | undefined>): void {
        this.backupLoader = loader;
    }

    /** Whether what the panel is showing right now came from the offline snapshot. */
    get usingBackup(): boolean {
        return this.achievements.length === 0 && this.backupView !== undefined;
    }

    /** Load and index the snapshot, once. */
    protected async ensureBackup(): Promise<void> {
        if (this.backupTried || !this.backupLoader) {
            return;
        }
        this.backupTried = true;
        const data = await this.backupLoader().catch(() => undefined);
        if (data) {
            this.backupByHash = achievementBackupByHash(data);
        }
    }

    /**
     * Work out whether the snapshot has a set for the running ROM, and if so
     * build the panel's view of it. Called whenever the live picture changes —
     * a live set arriving takes precedence and clears this again.
     */
    protected async resolveBackup(): Promise<void> {
        // Wanted when someone is signed in and a running ROM still has no live
        // achievement list: the site is unreachable, the engine is missing, or
        // the site is up but not serving VUEPort a real set (the
        // unapproved-client case — a live `game` with no achievements still
        // counts). Signed out is left to the panel's own "sign in" prompt
        // rather than hidden behind a read-only list.
        const wanted = this.achievements.length === 0
            && this.romHash !== undefined
            && this.enabled()
            && this.account !== undefined;
        if (wanted) {
            await this.ensureBackup();
        }
        const match = wanted ? this.backupByHash?.get(this.romHash!.toLowerCase()) : undefined;
        if (match === this.backupGame) {
            return;
        }
        this.backupGame = match;
        this.backupView = match
            ? { game: achievementBackupToRaGame(match), list: achievementBackupToRaList(match) }
            : undefined;
        this.changed();
    }

    /** Whether the hardcore switch has a host to act through. */
    get hardcoreControlsAvailable(): boolean {
        return this.hardcoreControls !== undefined;
    }

    /** Whether hardcore mode is on right now. */
    get hardcore(): boolean {
        return this.hardcoreControls?.isEnabled() ?? false;
    }

    /**
     * Turn hardcore mode on or off.
     *
     * On: ask first (the prompt spells out what it disables and that it
     * restarts the ROM), then persist, run the host's `enter` — Play mode,
     * cheats off, macros stopped, ROM restarted — and arm the engine. Off:
     * persist and disarm the engine, no prompt and no restart; rc_client keeps
     * the hardcore unlocks already earned.
     */
    async setHardcore(enabled: boolean): Promise<void> {
        const controls = this.hardcoreControls;
        if (!controls || enabled === controls.isEnabled()) {
            return;
        }
        if (enabled && !await this.notifications.confirm(hardcoreConfirmation())) {
            return;
        }
        await controls.persist(enabled);
        if (enabled) {
            await controls.enter();
        }
        await this.applyHardcoreToEngine();
        this.changed();
    }

    /**
     * The player reached for something hardcore mode disables. Tell them why
     * and offer the way out — turning it off, which is immediate and does not
     * restart. Does nothing if hardcore is already off, so callers can route
     * every blocked control through this without checking first.
     */
    async offerToLeaveHardcore(): Promise<void> {
        if (!this.hardcore) {
            return;
        }
        if (await this.notifications.confirm(hardcoreOnNotice())) {
            await this.setHardcore(false);
        }
    }

    /**
     * Re-send the current hardcore flag to the running engine. Call after the
     * setting changes and once a session's engine is up.
     */
    async applyHardcoreToEngine(): Promise<void> {
        await this.core?.raSetHardcore(this.hardcore).catch(() => undefined);
    }

    /**
     * Refresh the current account's score, softcore score and avatar from
     * RetroAchievements — the same plain `login2` call `login` makes, with the
     * saved token standing in for a password.
     */
    async refreshAccount(): Promise<void> {
        if (!this.account || !this.transport.available) {
            return;
        }
        await this.requestLogin2({ r: 'login2', u: this.account.username, t: this.account.token });
        this.changed();
    }

    get isLoggedIn(): boolean {
        return this.account !== undefined;
    }

    get user(): RetroAchievementsAccount | undefined {
        return this.account;
    }

    get currentGame(): RaGame | undefined {
        return this.game ?? this.backupView?.game;
    }

    get list(): ReadonlyArray<RaAchievement> {
        return this.achievements.length > 0 ? this.achievements : this.backupView?.list ?? [];
    }

    /**
     * Whether the running ROM is a build RetroAchievements does not support,
     * so nothing in the set can be earned with it.
     */
    get unsupportedGameVersion(): boolean {
        return this.unsupportedVersion;
    }

    /**
     * Whether {@link list} is what there is, rather than what has arrived so
     * far — an empty list means "none" once this is true, and "not yet" until.
     */
    get listLoaded(): boolean {
        return this.achievementsLoaded || this.backupView !== undefined;
    }

    /**
     * The running game's leaderboards.
     *
     * Live only — the offline snapshot carries achievements and nothing else,
     * and a leaderboard without the server behind it has nothing to show but
     * its own name.
     */
    get leaderboardList(): ReadonlyArray<RaLeaderboard> {
        return this.leaderboards;
    }

    /** Why the engine, rather than the game, has no leaderboards to give. */
    get leaderboardsUnavailableDetail(): string | undefined {
        return this.leaderboardsReason;
    }

    /**
     * Whether attempts are being tracked at all right now.
     *
     * RetroAchievements only runs leaderboards in hardcore mode, so in
     * softcore every board reads `inactive` and the panel says why rather
     * than looking broken.
     */
    get leaderboardsActive(): boolean {
        return this.hardcore;
    }

    /** The running attempts' readouts, for the overlay over the picture. */
    get leaderboardTrackers(): ReadonlyArray<{ id: number, display: string }> {
        return [...this.trackers].map(([id, display]) => ({ id, display }));
    }

    /**
     * Ask RetroAchievements for a page of one leaderboard's entries.
     *
     * `aroundUser` asks for the page the signed-in player sits in the middle
     * of instead of the page beginning at `firstEntry`. Rejects when there is
     * no session, no account, or the engine cannot answer — the panel shows
     * the message.
     */
    async fetchLeaderboardEntries(
        leaderboardId: number,
        options: { firstEntry?: number, count?: number, aroundUser?: boolean } = {},
    ): Promise<VesRaLeaderboardEntries> {
        if (!this.core) {
            throw new Error('No game is running.');
        }
        return this.core.raFetchLeaderboardEntries(
            leaderboardId,
            options.firstEntry ?? 1,
            options.count ?? 25,
            options.aroundUser ?? false,
        );
    }

    /** Why nothing is showing right now, or undefined when everything is in order. */
    get unavailableReason(): RetroAchievementsUnavailableReason | undefined {
        if (!this.enabled()) {
            return 'disabled';
        }
        // The offline snapshot stands in for whatever is missing — no transport,
        // no account, no engine — as long as it has this ROM's set.
        if (this.backupView) {
            return undefined;
        }
        if (!this.transport.available) {
            return 'transport';
        }
        if (!this.account) {
            return 'not-logged-in';
        }
        if (this.engineReason) {
            return 'engine';
        }
        if (!this.core) {
            return 'no-rom';
        }
        if (!this.game) {
            return 'not-recognized';
        }
        return undefined;
    }

    /** More detail behind `unavailableReason`, when the engine or the server gave one. */
    get unavailableDetail(): string | undefined {
        return this.engineReason ?? this.loadReason;
    }

    /**
     * `dorequest.php?r=login2` with either a password or (from {@link restore}
     * and {@link refreshAccount}) a saved token in its place — the same
     * endpoint rcheevos itself would use, independent of any running session,
     * so the account can be set up and kept current before a ROM is ever
     * opened. What a session's engine additionally needs (`raLoginToken`)
     * happens in {@link setSession} once there is a worker to tell.
     */
    protected async requestLogin2(fields: Record<string, string>): Promise<void> {
        const response = await this.transport.request(
            'POST', RA_DOREQUEST, formEncode(fields), 'application/x-www-form-urlencoded',
        );
        const body = JSON.parse(response.body) as {
            Success?: boolean, User?: string, Token?: string,
            Score?: number, SoftcoreScore?: number, AvatarUrl?: string, Error?: string,
        };
        if (response.status !== 200 || !body.Success || !body.Token) {
            throw new Error(body.Error ?? `RetroAchievements answered ${response.status}.`);
        }
        this.account = {
            username: body.User ?? fields.u,
            token: body.Token,
            score: body.Score ?? 0,
            softcoreScore: body.SoftcoreScore ?? 0,
            avatarUrl: body.AvatarUrl,
        };
        await this.credentials.save({ username: this.account.username, token: this.account.token });
    }

    /** Log in with a RetroAchievements username and password. */
    async login(username: string, password: string): Promise<void> {
        if (!this.transport.available) {
            throw new Error('RetroAchievements needs the desktop application to connect.');
        }
        this.loggingIn = true;
        this.changed();
        try {
            await this.requestLogin2({ r: 'login2', u: username, p: password });
            if (this.core) {
                await this.authenticateSession(this.core);
                // A ROM opened before anyone signed in never got a chance to
                // ask for its set; a late login is that chance.
                if (this.romHash) {
                    await this.loadGame(this.romHash);
                }
            }
        } finally {
            this.loggingIn = false;
            this.changed();
        }
    }

    async logout(): Promise<void> {
        this.account = undefined;
        this.game = undefined;
        this.achievements = [];
        this.achievementsLoaded = false;
        this.unsupportedVersion = false;
        this.clearLeaderboards();
        await this.credentials.clear().catch(() => undefined);
        if (this.core) {
            await this.core.raLogout().catch(() => undefined);
        }
        // Signed out, but the running ROM's set can still be shown from the
        // snapshot.
        await this.resolveBackup();
        this.changed();
    }

    get isLoggingIn(): boolean {
        return this.loggingIn;
    }

    /**
     * Follow a session's worker: authenticate the engine and wire its events.
     * Call from `stop()` with `undefined` first — a session about to be torn
     * down should not go on delivering achievement events to a set that is
     * about to change under it.
     */
    async setSession(core: Core | undefined, sim: Sim | undefined): Promise<void> {
        this.sessionDisposables.dispose();
        this.core = core;
        this.sim = sim;
        this.game = undefined;
        this.achievements = [];
        this.achievementsLoaded = false;
        this.unsupportedVersion = false;
        this.clearLeaderboards();
        this.romHash = undefined;
        this.backupGame = undefined;
        this.backupView = undefined;

        if (!core) {
            this.changed();
            return;
        }

        this.sessionDisposables.push(core.onRetroAchievements(event => this.onEvent(core, event)));
        if (this.account && this.enabled() && this.transport.available) {
            await this.authenticateSession(core).catch(() => undefined);
        }
        this.changed();
    }

    /**
     * Identify the running ROM and load its set, if RetroAchievements is on and
     * an account is signed in. Silently does nothing otherwise — the panel's
     * `unavailableReason` says why.
     */
    async loadGame(hash: string | undefined): Promise<void> {
        this.romHash = hash;
        this.achievementsLoaded = false;
        this.unsupportedVersion = false;
        if (!hash || !this.sim || !this.account || !this.enabled() || !this.transport.available) {
            // Nothing live is going to arrive — stand the snapshot up instead,
            // if it has this ROM.
            await this.resolveBackup();
            return;
        }
        // Before the set loads, so a fresh session comes up in whichever mode
        // the player left hardcore in rather than rc_client's softcore default.
        await this.core?.raSetHardcore(this.hardcore).catch(() => undefined);
        await this.sim.raLoadGame(hash).catch(async error => {
            this.loadReason = error instanceof Error ? error.message : String(error);
            await this.resolveBackup();
            this.changed();
        });
    }

    protected async authenticateSession(core: Core): Promise<void> {
        if (!this.account) {
            return;
        }
        try {
            const refreshed = await core.raLoginToken(this.account.username, this.account.token);
            this.account = {
                username: refreshed.username, token: refreshed.token,
                score: refreshed.score, softcoreScore: refreshed.softcoreScore,
                avatarUrl: refreshed.avatarUrl,
            };
            // The token rc_client hands back is the one to keep using — it may
            // have been reissued.
            await this.credentials.save({ username: this.account.username, token: this.account.token })
                .catch(() => undefined);
        } catch (error) {
            this.notifications.warn(
                `RetroAchievements login failed: ${error instanceof Error ? error.message : String(error)}`);
        }
    }

    protected onEvent(core: Core, event: VesRaEvent): void {
        switch (event.kind) {
            case 'serverCall':
                this.serviceServerCall(core, event);
                return;
            case 'gameLoaded':
                this.game = event.game;
                this.loadReason = event.reason;
                if (event.game) {
                    this.engineReason = undefined;
                }
                // A live set won: drop the snapshot view. A miss: try to put
                // one up (`resolveBackup` no-ops if `this.game` is set).
                this.resolveBackup().catch(() => undefined);
                this.changed();
                return;
            case 'achievements':
                // RetroAchievements answers an unrecognized client string or an
                // unsupported ROM build with a fake achievement of its own rather
                // than an error — see `RA_NOTICE_TITLES`' doc comment. None are
                // the set's own achievements, so they are dropped before anything
                // counts or displays the list; the version notice leaves
                // `unsupportedVersion` behind for the panel to explain.
                this.unsupportedVersion = event.achievements.some(
                    a => raNoticeTitle(a.title) === RA_UNSUPPORTED_VERSION_TITLE);
                this.achievements = event.achievements.filter(a => !raNoticeTitle(a.title));
                this.achievementsLoaded = true;
                // A real list arrived — clear any snapshot view standing in for
                // it. (Still empty, e.g. the unapproved client: this keeps it.)
                this.resolveBackup().catch(() => undefined);
                this.changed();
                return;
            case 'unlocked': {
                // The same notices arrive as unlocks, too, the moment the set
                // loads. They are warnings rather than rewards: nothing about
                // them belongs in a toast celebrating an achievement, and the
                // version one has already been turned into a line of the
                // panel's own by the `achievements` event.
                const notice = raNoticeTitle(event.title);
                if (notice) {
                    if (notice === RA_UNSUPPORTED_VERSION_TITLE && !this.unsupportedVersion) {
                        this.unsupportedVersion = true;
                        this.changed();
                    }
                    return;
                }
                this.onUnlockedEmitter.fire(event);
                this.changed();
                return;
            }
            case 'engineUnavailable':
                this.engineReason = event.reason;
                this.resolveBackup().catch(() => undefined);
                this.changed();
                return;
            case 'challengeIndicator':
            case 'connection':
                this.changed();
                return;
            case 'leaderboards':
                this.leaderboards = event.leaderboards;
                this.leaderboardsReason = event.reason;
                this.changed();
                return;
            case 'leaderboardAttempt':
                // No `changed()`: an attempt starting or ending moves the
                // board between active and tracking, and the engine sends the
                // whole list straight after saying so — that is what redraws
                // the panel. This is only the toast.
                this.onLeaderboardAttemptEmitter.fire(event);
                return;
            case 'leaderboardTracker':
                if (event.show) {
                    this.trackers.set(event.trackerId, event.display);
                } else {
                    this.trackers.delete(event.trackerId);
                }
                // Deliberately not `changed()` — see `onDidChangeTrackers`.
                this.onDidChangeTrackersEmitter.fire();
                return;
            case 'leaderboardScoreboard':
                // Likewise the toast only. Nothing the panel shows depends on
                // it — a board's own standings are fetched when it is opened,
                // and this arrives a round trip after the attempt that
                // already redrew the list.
                this.onScoreboardEmitter.fire(event);
                return;
        }
    }

    protected async serviceServerCall(
        core: Core,
        call: Extract<VesRaEvent, { kind: 'serverCall' }>,
    ): Promise<void> {
        try {
            const response = await this.transport.request(call.method, call.url, call.body, call.contentType);
            await core.raProvideResponse(call.requestId, response.status, response.body);
        } catch {
            // The engine treats a zero status as "could not be reached" and
            // retries or reports offline on its own; nothing to do here beyond
            // saying so.
            await core.raProvideResponse(call.requestId, 0, '').catch(() => undefined);
        }
    }

    /**
     * Forget the leaderboards and any attempt in progress. The overlay is
     * told separately, since it does not listen to `onDidChange`.
     */
    protected clearLeaderboards(): void {
        this.leaderboards = [];
        this.leaderboardsReason = undefined;
        if (this.trackers.size > 0) {
            this.trackers.clear();
            this.onDidChangeTrackersEmitter.fire();
        }
    }

    protected changed(): void {
        this.onDidChangeEmitter.fire();
    }

    dispose(): void {
        this.sessionDisposables.dispose();
        this.onDidChangeEmitter.dispose();
        this.onUnlockedEmitter.dispose();
        this.onDidChangeTrackersEmitter.dispose();
        this.onLeaderboardAttemptEmitter.dispose();
        this.onScoreboardEmitter.dispose();
    }
}
