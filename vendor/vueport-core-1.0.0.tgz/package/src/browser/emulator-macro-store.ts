import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import {
    finishMacro,
    parseMacroFile,
    serializeMacroFile,
    Macro,
    MacroStep,
    macroIsEmpty,
    macroKeysAt,
} from '../common/emulator-macros';
import {
    readVesBrowserState,
    browserStateStorage,
    browserStateId,
    browserStateKey,
    writeVesBrowserState,
} from './emulator-browser-state';

interface StoredMacroState {
    looping?: string[];
}

/**
 * Where the shared macros' repeat switches are remembered.
 *
 * Its own *kind* rather than a ROM path that could not really exist: a kind no
 * per-ROM key uses cannot be collided with by any path at all, which is a
 * stronger thing to rely on than a filename nobody would choose.
 */
const GLOBAL_STATE_KEY = browserStateKey('global-macros', '');

/**
 * What the store needs from the thing that owns the key masks.
 *
 * Declared here rather than imported from `emulator-input`, so that neither
 * module depends on the other: the input controller satisfies this
 * structurally, and a test can satisfy it with four lines.
 */
export interface EmulatorMacroInput {
    /** The buttons a person is holding right now, as a VbKey mask. */
    readonly playerKeys: number;
    /**
     * Hold exactly these buttons on the macro's behalf.
     *
     * Kept apart from the player's own, and combined with them, so that
     * playing a macro does not take the controller away — pressing something
     * while one runs adds to it rather than fighting it.
     */
    setMacroKeys(keys: number): void;
    /** Make sure the keyboard is being heard; see `startRecording`. */
    focus(): void;
}

/** What the store is doing, which is the one thing the chrome shows about it. */
export enum MacroActivity {
    IDLE = 'idle',
    RECORDING = 'recording',
    PLAYING = 'playing',
}

/**
 * One emulator's macros: the list, the file it lives in, and the recording and
 * playback that fill and use it.
 *
 * Held by the widget rather than by the Macros panel, for the same two reasons
 * the cheats are: a macro plays on with that panel closed, and the file has to
 * be read as soon as the ROM is, whether or not anyone has opened it. The panel
 * edits through this and redraws on `onDidChange`.
 *
 * The file is `<rom>.vueport-macros.json` in the same place a ROM's saves go.
 * It holds the recorded definitions only; whether each macro repeats is UI
 * state and lives in the browser. JSON is the emulator's own format because,
 * unlike cheats, there is no published one to be compatible with.
 *
 * ## The clock
 *
 * Both recording and playback measure time with a clock this object advances
 * itself, out of `tick`, and only while the machine is actually running. Wall
 * time would have been simpler and wrong in the case that matters most:
 * somebody pausing in the middle of a recording, or opening a menu over the
 * game, would have that gap written into the macro and played back as a wait.
 *
 * It still measures real seconds rather than frames, so a macro recorded at
 * normal speed and played under fast forward runs against a game moving at a
 * different rate. Frames would be the exact unit, but nothing reports them
 * frame by frame from the worker; this is the accurate-where-it-counts
 * approximation, and Play mode — where macros are used — runs at one speed.
 */
export class MacroStore {

    /**
     * The running ROM's own macros, and the ones that belong to every game.
     *
     * Two lists and two files, presented as one list: see {@link list} for the
     * order and {@link locate} for how an index reaches the right one. Kept
     * apart rather than in one list with a flag because they are not one thing
     * — they are written to different files, survive different events, and
     * marking a macro global is exactly the act of moving it between them.
     */
    protected macros: Macro[] = [];
    protected globals: Macro[] = [];
    /** {@link list}'s answer, rebuilt on change rather than on every read. */
    protected combined: ReadonlyArray<Macro> = [];
    protected uri: string | undefined;
    protected browserStateKey: string | undefined;
    /** Set once a file has been read, so a first save cannot precede a load. */
    protected loaded = false;
    /** The same, for the shared file, which is read once and not per ROM. */
    protected globalsLoaded = false;
    protected input: EmulatorMacroInput | undefined;

    /** Whether the machine is running, which is what makes the clock advance. */
    protected running = false;
    /** Milliseconds of running time since this object was made. */
    protected clock = 0;
    /** When the clock was last advanced, on `performance.now`'s scale. */
    protected clockReadAt: number | undefined;

    protected recording: { steps: MacroStep[], from: number } | undefined;
    protected playback: { index: number, from: number, keys: number } | undefined;

    /**
     * Saves run one after another, for the reason the cheat store gives: an
     * edit and the edit undoing it are a write and a delete, and the wrong
     * order would leave the file behind.
     */
    protected persisting: Promise<void> = Promise.resolve();

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /**
     * Fires when the list, or what the store is doing with it, changes.
     *
     * Not on every tick: recording and playing are continuous, and a panel that
     * redrew sixty times a second to move a stopwatch would cost more than
     * everything else here put together. What is running is said once when it
     * starts and once when it stops; whoever wants the seconds counting up asks
     * for them on a timer of its own.
     */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    constructor(
        protected readonly storage: VueportStorage,
        protected readonly stateStorage?: browserStateStorage,
        /**
         * Where the macros that belong to every game are kept — see
         * `EmulatorCompanionFiles#globalMacros`. A host that leaves it out gets
         * per-ROM macros only, and nothing offers to make one global.
         *
         * A function rather than the path itself, because a host may not know
         * it yet when it builds this: the studio's is under a configuration
         * directory its application only hands out asynchronously, and the
         * store is built before that answer arrives. Read on every use, and
         * only when a global macro is actually read or written.
         */
        protected readonly resolveGlobalUri?: () => string | undefined,
    ) { }

    /** Where global macros are kept, if the host knows yet. */
    protected get globalUri(): string | undefined {
        return this.resolveGlobalUri?.();
    }

    /**
     * Every macro on offer for the running ROM: its own first, then the ones
     * marked global.
     *
     * One list because that is what a person has — a row of macros they can
     * play — and because everything that addresses a macro does so by its
     * place in this list. Its own first, so that recording a macro puts it
     * where the eye already is and a shared set does not push a game's own
     * work down the panel.
     */
    get list(): ReadonlyArray<Macro> {
        return this.combined;
    }

    /** Whether this store was given anywhere to keep global macros. */
    get supportsGlobal(): boolean {
        return this.globalUri !== undefined;
    }

    /**
     * Which list an index falls in, and where in it.
     *
     * The one place the two lists are joined, so that `play`, `update`,
     * `remove` and the rest each work in the combined index space without
     * knowing there are two.
     */
    protected locate(index: number): { list: Macro[], at: number, global: boolean } | undefined {
        if (index < 0) {
            return undefined;
        }
        if (index < this.macros.length) {
            return { list: this.macros, at: index, global: false };
        }
        const at = index - this.macros.length;
        return at < this.globals.length
            ? { list: this.globals, at, global: true }
            : undefined;
    }

    /**
     * Rebuild {@link list}, marking the shared ones on the way out.
     *
     * The two lists themselves never carry the flag — which list a macro is in
     * is the whole of the answer — so it is stamped on here, where the two
     * become one and the distinction would otherwise be lost.
     */
    protected recombine(): void {
        this.combined = [
            ...this.macros,
            ...this.globals.map(macro => ({ ...macro, global: true })),
        ];
    }

    get isLoaded(): boolean {
        return this.loaded;
    }

    /** Where the macros are stored, once a ROM is known. */
    get filePath(): string | undefined {
        return this.uri;
    }

    /** The keyboard and pad, once the host has introduced the two. */
    setInput(input: EmulatorMacroInput | undefined): void {
        this.input = input;
    }

    // ------------------------------------------------------------- the file

    /**
     * Read the macros belonging to a ROM, replacing whatever was loaded.
     *
     * `romPath` is the ROM as the companion files see it — the same argument
     * the cheat store takes — and the macros land beside its saves. The global
     * ones are read alongside, once: they do not belong to this ROM, so they
     * are not re-read when another is opened, and a failure to read them
     * leaves the ROM's own working.
     */
    async load(romPath: string): Promise<void> {
        this.stop();
        this.cancelRecording();
        const directory = this.storage.parent(romPath);
        const stem = this.storage.stem(romPath);
        this.uri = this.storage.join(directory, `${stem}.vueport-macros.json`);
        this.browserStateKey = browserStateKey('macros', romPath);
        this.macros = [];
        try {
            const read = await this.readMacroFile(this.uri, this.browserStateKey);
            this.macros = read.macros;
            this.loaded = true;
            if (this.saveBrowserState() && read.hadLegacyState) {
                await this.saveDefinitions();
            }
        } catch (error) {
            // A macro file that cannot be read is not worth failing a launch
            // over: the game runs, with no macros, and says why here.
            console.warn(`[emulator] could not read macros from ${this.uri}:`, error);
            this.loaded = false;
        }
        await this.loadGlobals();
        this.changed(false, false);
    }

    /** The shared file, read the first time any ROM is opened. */
    protected async loadGlobals(): Promise<void> {
        if (this.globalsLoaded || !this.globalUri) {
            return;
        }
        try {
            const read = await this.readMacroFile(this.globalUri, GLOBAL_STATE_KEY);
            this.globals = read.macros;
            this.globalsLoaded = true;
            if (this.saveGlobalBrowserState() && read.hadLegacyState) {
                await this.saveGlobalDefinitions();
            }
        } catch (error) {
            // As above, and with more reason: these belong to no game, so a
            // file that cannot be read must not stop the one being launched.
            console.warn(`[emulator] could not read global macros from ${this.globalUri}:`, error);
        }
    }

    /**
     * One macro file, with the repeat switches remembered for it applied.
     *
     * `hadLegacyState` says the file itself carried `loop`, which belongs in
     * browser storage now — the caller writes the file back to shed it.
     */
    protected async readMacroFile(
        uri: string, stateKey: string
    ): Promise<{ macros: Macro[], hadLegacyState: boolean }> {
        let macros: Macro[] = [];
        let hadLegacyState = false;
        if (await this.storage.exists(uri)) {
            const text = await this.storage.readText(uri);
            macros = parseMacroFile(text);
            try {
                const raw = JSON.parse(text) as { macros?: unknown[] };
                hadLegacyState = Array.isArray(raw?.macros)
                    && raw.macros.some(macro => macro !== null && typeof macro === 'object'
                        && Object.prototype.hasOwnProperty.call(macro, 'loop'));
            } catch {
                // The lenient parser above already turned malformed JSON
                // into an empty list; there is no legacy state to migrate.
            }
        }
        const stored = readVesBrowserState<StoredMacroState>(this.stateStorage, stateKey);
        const ids = stateIdsOf(macros);
        const looping = Array.isArray(stored?.looping)
            ? new Set(stored.looping.filter(id => typeof id === 'string'))
            : new Set(ids.filter((id, index) => macros[index].loop));
        return {
            macros: macros.map((macro, index) => ({
                ...macro,
                loop: looping.has(ids[index]) || undefined,
                // Which list a macro is in is what makes it global; a flag read
                // out of a file would only be a second, disagreeing answer.
                global: undefined as boolean | undefined,
            })),
            hadLegacyState,
        };
    }

    protected saveBrowserState(): boolean {
        return writeLoopState(this.stateStorage, this.browserStateKey, this.macros);
    }

    protected saveGlobalBrowserState(): boolean {
        return writeLoopState(
            this.stateStorage, this.globalUri && GLOBAL_STATE_KEY, this.globals);
    }

    /**
     * Write the definitions back, or take the file away once the last macro
     * is gone. Repeat switches are kept separately in browser storage.
     *
     * Saving on every edit, for the reason the cheat store saves on every edit:
     * a recording somebody made and then lost to a closed tab is worse than a
     * few kilobytes written more often than they strictly had to be.
     */
    protected async saveDefinitions(): Promise<void> {
        if (!this.loaded) {
            return;
        }
        await this.writeMacroFile(this.uri, this.macros);
    }

    protected async saveGlobalDefinitions(): Promise<void> {
        if (!this.globalsLoaded) {
            return;
        }
        await this.writeMacroFile(this.globalUri, this.globals);
    }

    protected async writeMacroFile(
        uri: string | undefined, macros: ReadonlyArray<Macro>
    ): Promise<void> {
        if (!uri) {
            return;
        }
        try {
            if (macros.length === 0) {
                if (await this.storage.exists(uri)) {
                    await this.storage.delete(uri);
                }
            } else {
                await this.storage.writeText(uri, serializeMacroFile(macros));
            }
        } catch (error) {
            console.warn(`[emulator] could not store macros in ${uri}:`, error);
        }
    }

    // -------------------------------------------------------------- the list

    /** Take one macro's name, or its loop flag. Returns nothing for a bad index. */
    update(index: number, patch: Partial<Pick<Macro, 'name' | 'loop'>>): void {
        const found = this.locate(index);
        if (!found) {
            return;
        }
        found.list[found.at] = { ...found.list[found.at], ...patch };
        this.changed(patch.name !== undefined, true);
    }

    remove(index: number): void {
        const found = this.locate(index);
        if (!found) {
            return;
        }
        // Whatever is playing is addressed by index, and every index after
        // this one is about to mean a different macro.
        this.stop();
        found.list.splice(found.at, 1);
        this.changed(true, true);
    }

    /**
     * Move a macro between this ROM's file and the shared one.
     *
     * Moved rather than copied or flagged: a macro is offered for every game
     * or for this one, and a copy in both places would drift into two macros
     * that were once the same and now quietly differ. Its repeat switch goes
     * with it — the switch is remembered against the macro's own identity, so
     * writing both sides' state after the move is all it takes.
     *
     * Whatever is playing stops first, for `remove`'s reason: the index of
     * every macro after this one is about to mean a different macro, and the
     * one being moved is about to be somewhere else entirely.
     */
    setGlobal(index: number, global: boolean): void {
        const found = this.locate(index);
        if (!found || !this.globalUri || found.global === global) {
            return;
        }
        this.stop();
        const [macro] = found.list.splice(found.at, 1);
        (global ? this.globals : this.macros).push(macro);
        this.changed(true, true);
    }

    /**
     * Add macros read from a file, on top of what is loaded.
     *
     * The same shape as the cheat store's import: anything with nothing to play
     * is dropped, a legacy loop flag is adopted into browser state, and the
     * number actually added is returned. Names are left as they are — a macro is
     * addressed by its place in the list, not its name, so a repeat is harmless.
     */
    importMacros(macros: readonly Macro[]): number {
        const added = macros.filter(macro => !macroIsEmpty(macro));
        this.macros.push(...added.map(macro => ({ ...macro, steps: macro.steps.map(step => ({ ...step })) })));
        if (added.length > 0) {
            this.changed(true, true);
        }
        return added.length;
    }

    // ------------------------------------------------------------ the clock

    /**
     * Whether the machine is running — which is whether time passes.
     *
     * The host calls this whenever it pauses, resumes, loads or stops a ROM.
     * Reading the clock first is what makes the switch lossless: the time up to
     * this moment is banked before it stops counting.
     */
    setRunning(running: boolean): void {
        this.readClock();
        this.running = running;
        this.clockReadAt = running ? performance.now() : undefined;
    }

    /**
     * The clock, brought up to date.
     *
     * Advanced on demand rather than on a timer, so it is correct whoever asks
     * and whenever — the frame loop, a key press between two frames, or the
     * panel drawing a stopwatch.
     */
    protected readClock(): number {
        const now = performance.now();
        if (this.running && this.clockReadAt !== undefined) {
            this.clock += now - this.clockReadAt;
        }
        this.clockReadAt = this.running ? now : undefined;
        return this.clock;
    }

    // ----------------------------------------------------------- recording

    get activity(): MacroActivity {
        if (this.recording) {
            return MacroActivity.RECORDING;
        }
        return this.playback ? MacroActivity.PLAYING : MacroActivity.IDLE;
    }

    get isRecording(): boolean {
        return this.recording !== undefined;
    }

    /** Which macro is playing, or undefined when none is. */
    get playingIndex(): number | undefined {
        return this.playback?.index;
    }

    /**
     * How far the current recording or playback has got, in milliseconds.
     *
     * Zero when neither is running. Read rather than pushed, since it changes
     * continuously and only whatever is drawing a stopwatch cares — see
     * `onDidChange`.
     */
    get elapsed(): number {
        const from = this.recording?.from ?? this.playback?.from;
        return from === undefined ? 0 : Math.max(0, this.readClock() - from);
    }

    /**
     * Start writing down what the controller does.
     *
     * Whatever is playing stops first: a macro recorded with another one
     * pressing buttons underneath it would contain both, and the one that
     * comes back would be neither.
     */
    startRecording(): void {
        this.stop();
        // Recording is a promise that the keyboard will be heard, so the first
        // thing it does is make sure it can be kept. Focus is easily somewhere
        // else by now: the button that starts a recording may be the one in
        // the empty panel, which this very call takes off the screen — and a
        // focused element that is removed drops focus onto the document, where
        // the emulator's key listener never sees it. A recording that hears
        // nothing looks exactly like macros being broken.
        this.input?.focus();
        const from = this.readClock();
        this.recording = {
            // What is held at the outset is part of the recording: somebody
            // recording a combo may well be holding a direction already.
            steps: [{ at: from, keys: this.input?.playerKeys ?? 0 }],
            from,
        };
        this.changed(false, false);
    }

    /**
     * Stop, keep what was recorded, and return where it landed in the list.
     *
     * Undefined when there was nothing to keep — the recording was canceled,
     * or no button was pressed during it. A macro of nothing is not worth a row
     * in the panel, and dropping it is kinder than making somebody delete it.
     */
    stopRecording(name: string): number | undefined {
        const recording = this.recording;
        this.recording = undefined;
        if (!recording) {
            return undefined;
        }
        const macro = finishMacro(name, recording.steps, this.readClock());
        if (macroIsEmpty(macro)) {
            this.changed(false, false);
            return undefined;
        }
        this.macros.push(macro);
        this.changed(true, true);
        return this.macros.length - 1;
    }

    /** Stop and throw away what was recorded. */
    cancelRecording(): void {
        if (!this.recording) {
            return;
        }
        this.recording = undefined;
        this.changed(false, false);
    }

    /**
     * The player's buttons changed. Called by the input controller.
     *
     * Only theirs — what a macro is holding is deliberately not fed back in, or
     * recording while one plays would copy it into the new macro.
     */
    recordKeys(keys: number): void {
        if (!this.recording) {
            return;
        }
        this.recording.steps.push({ at: this.readClock(), keys });
    }

    // ------------------------------------------------------------ playback

    /**
     * Play one macro from the top.
     *
     * Playing a second replaces the first rather than layering onto it: two
     * macros holding the same button, one letting go while the other still
     * wants it, is a knot with no correct answer. Playing the one that is
     * already playing stops it, which is what the panel's button means.
     */
    play(index: number): void {
        const found = this.locate(index);
        const macro = found?.list[found.at];
        if (!macro || macroIsEmpty(macro)) {
            return;
        }
        if (this.playback?.index === index) {
            this.stop();
            return;
        }
        // A macro takes the controller from another macro, but never from the
        // person: recording is stopped rather than played over.
        this.cancelRecording();
        this.playback = { index, from: this.readClock(), keys: 0 };
        this.input?.setMacroKeys(0);
        this.changed(false, false);
    }

    /** Let go of whatever a macro was holding, and stop it. */
    stop(): void {
        if (!this.playback) {
            return;
        }
        this.playback = undefined;
        this.input?.setMacroKeys(0);
        this.changed(false, false);
    }

    /**
     * Advance playback. Called once per animation frame by the input
     * controller, which already runs a loop for the game pad.
     *
     * Nothing happens here while the machine is stopped, because the clock does
     * not move — a macro paused mid-sequence resumes where it was rather than
     * having run on without the game.
     */
    tick(): void {
        const playback = this.playback;
        if (!playback) {
            return;
        }
        const found = this.locate(playback.index);
        const macro = found?.list[found.at];
        if (!macro) {
            this.stop();
            return;
        }
        let elapsed = this.readClock() - playback.from;
        if (elapsed >= macro.duration) {
            if (!macro.loop || macro.duration <= 0) {
                // The closing step already released everything; this is the
                // bookkeeping that says so and takes the macro off the air.
                this.stop();
                return;
            }
            // Wrapped rather than restarted from now, so a looping macro does
            // not drift by however long the frame it wrapped on was.
            const laps = Math.floor(elapsed / macro.duration);
            playback.from += laps * macro.duration;
            elapsed -= laps * macro.duration;
        }
        const keys = macroKeysAt(macro, elapsed);
        if (keys !== playback.keys) {
            playback.keys = keys;
            this.input?.setMacroKeys(keys);
        }
    }

    protected changed(persistDefinitions = true, persistState = true): void {
        // First, so that anything woken by the event below reads a list that
        // already matches the two behind it.
        this.recombine();
        if (persistState) {
            this.saveBrowserState();
            this.saveGlobalBrowserState();
        }
        if (persistDefinitions) {
            // Both files, because the one edit that touches both — marking a
            // macro global — is a removal from one and an addition to the
            // other, and writing only one of them would duplicate or lose it.
            this.persisting = this.persisting
                .then(() => this.saveDefinitions())
                .then(() => this.saveGlobalDefinitions());
        }
        this.onDidChangeEmitter.fire();
    }

    dispose(): void {
        this.stop();
        this.onDidChangeEmitter.dispose();
    }
}

/**
 * Stable identities let a repeat switch survive sorting, or editing another
 * macro in the same list. Of a list rather than of the store's own, because
 * there are two of them.
 */
function stateIdsOf(macros: ReadonlyArray<Macro>): string[] {
    const counts = new Map<string, number>();
    return macros.map(macro => {
        const base = JSON.stringify([macro.name, macro.duration, macro.steps]);
        const occurrence = counts.get(base) ?? 0;
        counts.set(base, occurrence + 1);
        return `${browserStateId(base)}:${occurrence}`;
    });
}

function writeLoopState(
    storage: browserStateStorage | undefined,
    key: string | undefined,
    macros: ReadonlyArray<Macro>,
): boolean {
    const ids = stateIdsOf(macros);
    const looping = macros.flatMap((macro, index) => macro.loop ? [ids[index]] : []);
    return writeVesBrowserState(storage, key, { looping }, macros.length === 0);
}
