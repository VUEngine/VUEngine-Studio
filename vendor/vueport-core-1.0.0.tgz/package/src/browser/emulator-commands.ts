import { nls } from '../common/emulator-nls';
import { Command } from '../common/emulator-command';
import { EmulatorAction, EmulatorGamePadKeyCode } from './emulator-types';

/**
 * The `when` clause every emulator input mapping is scoped to.
 *
 * Deliberately never true — the widget reads key presses itself so that it can
 * see releases as well, and a mapping that actually fired through the host's
 * dispatcher would only give it the press.
 */
export const EMULATOR_FOCUS_CONTEXT = 'emulatorFocus';

export namespace EmulatorCommands {

  export const INPUT_L_UP: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.lUp',
      label: 'Left D-Pad ⇧',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/lUp',
    'vueport/input/gamePads/category'
  );

  export const INPUT_L_RIGHT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.lRight',
      label: 'Left D-Pad ⇨',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/lRight',
    'vueport/input/gamePads/category'
  );

  export const INPUT_L_DOWN: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.lDown',
      label: 'Left D-Pad ⇩',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/lDown',
    'vueport/input/gamePads/category'
  );

  export const INPUT_L_LEFT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.lLeft',
      label: 'Left D-Pad ⇦',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/lLeft',
    'vueport/input/gamePads/category'
  );

  export const INPUT_START: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.start',
      label: 'Start',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/start',
    'vueport/input/gamePads/category'
  );

  export const INPUT_SELECT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.select',
      label: 'Select',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/select',
    'vueport/input/gamePads/category'
  );

  export const INPUT_L_TRIGGER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.lTrigger',
      label: 'Left Trigger',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/lTrigger',
    'vueport/input/gamePads/category'
  );

  export const INPUT_R_UP: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.rUp',
      label: 'Right D-Pad ⇧',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/rUp',
    'vueport/input/gamePads/category'
  );

  export const INPUT_R_RIGHT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.rRight',
      label: 'Right D-Pad ⇨',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/rRight',
    'vueport/input/gamePads/category'
  );

  export const INPUT_R_DOWN: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.rDown',
      label: 'Right D-Pad ⇩',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/rDown',
    'vueport/input/gamePads/category'
  );

  export const INPUT_R_LEFT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.rLeft',
      label: 'Right D-Pad ⇦',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/rLeft',
    'vueport/input/gamePads/category'
  );

  export const INPUT_B: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.b',
      label: 'B',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/b',
    'vueport/input/gamePads/category'
  );

  export const INPUT_A: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.a',
      label: 'A',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/a',
    'vueport/input/gamePads/category'
  );

  export const INPUT_R_TRIGGER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.controller.rTrigger',
      label: 'Right Trigger',
      category: 'Emulator Game Pad',
    },
    'vueport/input/gamePads/commands/rTrigger',
    'vueport/input/gamePads/category'
  );

  export const INPUT_SAVE_STATE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.saveState',
      label: 'Save State',
      category: 'Emulator',
    },
    'vueport/input/saveStateCommand',
    'vueport/commands/category'
  );

  /**
   * Put the game back to the newest state somebody made.
   *
   * Named for what it does now that there are no slots: there is no state
   * *selected* to load, so the key takes the last one — choosing among them is
   * what the browser beside the screen is for.
   */
  export const INPUT_LOAD_STATE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.loadState',
      label: 'Load Last State',
      category: 'Emulator',
    },
    'vueport/input/loadStateCommand',
    'vueport/commands/category'
  );

  export const INPUT_TOGGLE_FAST_FORWARD: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.toggleFastForward',
      label: 'Toggle Fast Forward',
      category: 'Emulator',
    },
    'vueport/input/toggleFastForwardCommand',
    'vueport/commands/category'
  );

  export const INPUT_PAUSE_TOGGLE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.pauseToggle',
      label: 'Toggle Pause',
      category: 'Emulator',
    },
    'vueport/input/pauseToggleCommand',
    'vueport/commands/category'
  );

  export const INPUT_TOGGLE_SLOWMOTION: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.toggleSlowmotion',
      label: 'Toggle Slow Motion',
      category: 'Emulator',
    },
    'vueport/input/toggleSlowmotionCommand',
    'vueport/commands/category'
  );

  export const INPUT_TOGGLE_LOW_POWER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.toggleLowPower',
      label: 'Toggle Low Power Signal',
      category: 'Emulator',
    },
    'vueport/input/toggleLowPower',
    'vueport/commands/category'
  );

  export const INPUT_REWIND: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.rewind',
      label: 'Rewind',
      category: 'Emulator',
    },
    'vueport/input/rewindCommand',
    'vueport/commands/category'
  );

  export const INPUT_FRAME_ADVANCE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.frameAdvance',
      label: 'Frame Advance',
      category: 'Emulator',
    },
    'vueport/input/frameAdvanceCommand',
    'vueport/commands/category'
  );

  export const INPUT_RESET: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.reset',
      label: 'Reset',
      category: 'Emulator',
    },
    'vueport/input/resetCommand',
    'vueport/commands/category'
  );

  export const INPUT_AUDIO_MUTE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.audioMute',
      label: 'Un/mute Audio',
      category: 'Emulator',
    },
    'vueport/input/audioMuteCommand',
    'vueport/commands/category'
  );

  export const INPUT_FULLSCREEN: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.fullscreen',
      label: 'Fullscreen',
      category: 'Emulator',
    },
    'vueport/input/fullscreenCommand',
    'vueport/commands/category'
  );

  /**
   * Opens the input settings — where the mappings are, and where the overlay
   * of the controller that names them is drawn.
   *
   * A new key rather than the old `toggleControlsOverlayCommand`: what it says
   * has changed, not just how it is worded, and a translation of the old
   * sentence would be a wrong answer rather than a stale one.
   */
  export const INPUT_TOGGLE_CONTROLS_OVERLAY: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.toggleControlsOverlay',
      label: 'Configure Input',
      category: 'Emulator',
    },
    'vueport/input/configureInputCommand',
    'vueport/commands/category'
  );

  export const INPUT_SCREENSHOT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.screenshot',
      label: 'Take Screenshot',
      category: 'Emulator',
    },
    'vueport/input/screenshotCommand',
    'vueport/commands/category'
  );

  /**
   * Starts a recording, and stops the one that is running — one command
   * rather than two, unlike profiling, because this is a thing somebody does
   * while playing and reaches for by the same key both times.
   */
  export const INPUT_VIDEO_RECORD: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.input.videoRecord',
      label: 'Record Video',
      category: 'Emulator',
    },
    'vueport/input/videoRecordCommand',
    'vueport/commands/category'
  );

  export const ADD_PANEL: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.panels.add',
      label: 'Add Panel...',
      category: 'Emulator',
      iconClass: 'codicon codicon-add',
    },
    'vueport/commands/addPanel',
    'vueport/commands/category'
  );

  export const RESET_LAYOUT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.panels.resetLayout',
      label: 'Reset Emulator Layout',
      category: 'Emulator',
      iconClass: 'codicon codicon-clear-all',
    },
    'vueport/commands/resetLayout',
    'vueport/commands/category'
  );

  /**
   * Profiling, as two commands rather than one toggle.
   *
   * Which of the two applies is decided by whether a recording is running, and
   * only that one is offered — a palette entry meaning opposite things at
   * different times is worse than two that each say what they do.
   */
  export const PLAY_MOVIE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.movie.play',
      label: 'Play Input Movie…',
      category: 'Emulator',
    },
    'vueport/commands/playMovie',
    'vueport/commands/category'
  );

  export const STOP_MOVIE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.movie.stop',
      label: 'Stop Input Movie',
      category: 'Emulator',
    },
    'vueport/commands/stopMovie',
    'vueport/commands/category'
  );

  export const PROFILE_START: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.profile.start',
      label: 'Start Profiling',
      category: 'Emulator',
    },
    'vueport/commands/profileStart',
    'vueport/commands/category'
  );

  export const PROFILE_STOP: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.profile.stop',
      label: 'Stop Profiling and Export',
      category: 'Emulator',
    },
    'vueport/commands/profileStop',
    'vueport/commands/category'
  );

  export const LINK_SECOND_PLAYER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.link.second',
      label: 'Link Second Player',
      category: 'Emulator',
    },
    'vueport/commands/linkSecondPlayer',
    'vueport/commands/category'
  );

  export const UNLINK_PLAYERS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.link.unlink',
      label: 'Unlink Players',
      category: 'Emulator',
    },
    'vueport/commands/unlinkPlayers',
    'vueport/commands/category'
  );

  /**
   * Point the debugger at the other player's machine, or back at this one.
   *
   * This window runs both — see `emulator-core-service.ts` — so what the
   * inspectors show of the other player's is what their own debugger would
   * show, frame for frame, and a poke aimed at it lands in both windows.
   */
  export const INSPECT_OTHER_PLAYER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.link.inspectOther',
      label: "Inspect the Other Player's Machine",
      category: 'Emulator',
    },
    'vueport/commands/inspectOtherPlayer',
    'vueport/commands/category'
  );

  export const INSPECT_OWN_PLAYER: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.link.inspectOwn',
      label: 'Inspect This Player’s Machine',
      category: 'Emulator',
    },
    'vueport/commands/inspectOwnPlayer',
    'vueport/commands/category'
  );

  export const RELINK_PLAYERS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.link.relink',
      label: 'Re-link Players',
      category: 'Emulator',
    },
    'vueport/commands/relinkPlayers',
    'vueport/commands/category'
  );

  /**
   * Showing the cheats beside the screen.
   *
   * Not one of the panels: the cheats are not docked in either mode, so this
   * is not "open the Cheats panel" but "show them there".
   */
  export const TOGGLE_CHEATS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.cheats.toggle',
      label: 'Show Cheats',
      category: 'Emulator',
    },
    'vueport/commands/toggleCheats',
    'vueport/commands/category'
  );

  /**
   * Showing the macros beside the screen.
   *
   * The macros' counterpart of TOGGLE_CHEATS, and there for the same reason:
   * they are not docked in either mode, so this is not "open the Macros
   * panel" but "show them there".
   */
  export const TOGGLE_MACROS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.macros.toggle',
      label: 'Show Macros',
      category: 'Emulator',
    },
    'vueport/commands/toggleMacros',
    'vueport/commands/category'
  );

  /** Show the VB Color editor beside the screen. */
  export const TOGGLE_COLORS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.colors.toggle',
      label: 'Show Colors',
      category: 'Emulator',
    },
    'vueport/commands/toggleColors',
    'vueport/commands/category'
  );

  export const TOGGLE_PATCHES: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.patches.toggle',
      label: 'Show Patches',
      category: 'Emulator',
    },
    'vueport/commands/togglePatches',
    'vueport/commands/category'
  );

  /**
   * Showing the save-state browser beside the screen.
   *
   * The cheats' arrangement exactly — see TOGGLE_CHEATS — and the control that
   * replaced the slot number in the transport: with every save making a new
   * state, the list of them is the thing worth a button.
   */
  export const TOGGLE_SAVE_STATES: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.saveStates.toggle',
      label: 'Show Save States',
      category: 'Emulator',
    },
    'vueport/commands/toggleSaveStates',
    'vueport/commands/category'
  );

  /**
   * Showing the RetroAchievements list beside the screen.
   *
   * TOGGLE_CHEATS' and TOGGLE_MACROS' counterpart, and there for the same
   * reason: it is not docked in either mode. Only one of the five strips is
   * open at a time.
   */
  export const TOGGLE_ACHIEVEMENTS: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.achievements.toggle',
      label: 'Show Achievements',
      category: 'Emulator',
    },
    'vueport/commands/toggleAchievements',
    'vueport/commands/category'
  );

  /** Enable or completely suppress VB Color hardware support. */
  export const TOGGLE_VBC_SUPPORT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.vbcSupport.toggle',
      label: 'Toggle VB Color Support',
      category: 'Emulator',
    },
    'vueport/commands/toggleVbcSupport',
    'vueport/commands/category'
  );

  /** Choose which physical Virtual Boy model the core should emulate. */
  export const SET_HARDWARE_MODE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.hardwareMode',
      label: 'Set Hardware Mode',
      category: 'Emulator',
    },
    'vueport/commands/setHardwareMode',
    'vueport/commands/category'
  );

  /**
   * Choose which save file the game plays on.
   *
   * A slot rather than a state: see `EMULATOR_SAVE_SLOTS`. Named "Save Game"
   * because that is what it holds — the game's own saved progress — and
   * because "save slot" on its own reads as the save *state* slot beside it.
   */
  export const SET_SAVE_SLOT: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.saveGameSlot',
      label: 'Select Save Game Slot',
      category: 'Emulator',
    },
    'vueport/commands/setSaveGameSlot',
    'vueport/commands/category'
  );

  /** Switching between Play mode and Debug mode. */
  export const TOGGLE_DEBUG_MODE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.mode.toggleDebug',
      label: 'Toggle Debug Mode',
      category: 'Emulator',
    },
    'vueport/commands/toggleDebugMode',
    'vueport/commands/category'
  );

  /**
   * Taking saved progress out of the application, and putting it back.
   *
   * A browser keeps cartridge RAM and save states where the person cannot
   * reach them — the origin-private file system, which has no path they could
   * type and which a cleared site goes away with. Progress somebody spent
   * hours on should not be hostage to that, and a save they made on one
   * machine should be playable on another.
   */
  export const EXPORT_SAVE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.save.export',
      label: 'Export Save Data…',
      category: 'Emulator',
    },
    'vueport/commands/exportSave',
    'vueport/commands/category'
  );

  export const IMPORT_SAVE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.save.import',
      label: 'Import Save Data…',
      category: 'Emulator',
    },
    'vueport/commands/importSave',
    'vueport/commands/category'
  );

  /**
   * The newest state somebody made, as a file they keep.
   *
   * One state rather than a chosen one, because choosing is what the browser
   * beside the screen is for — and every state in it has an Export of its own.
   * This is the command-palette shortcut for "the one I just made".
   */
  export const EXPORT_SAVE_STATE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.saveState.export',
      label: 'Export Latest Save State…',
      category: 'Emulator',
    },
    'vueport/commands/exportSaveState',
    'vueport/commands/category'
  );

  export const IMPORT_SAVE_STATE: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.saveState.import',
      label: 'Import Save State…',
      category: 'Emulator',
    },
    'vueport/commands/importSaveState',
    'vueport/commands/category'
  );

  /**
   * Erase the cartridge save in the slot being played, and restart on the
   * empty one. Only that slot: the other twenty-five are somebody else's
   * playthrough and are left alone.
   *
   * Not one of the action commands: it has no key mapping and no toolbar
   * button, because it throws away saved progress and wants to be reached
   * deliberately rather than by a stray click. The palette is the whole of its
   * surface; the confirmation dialog is the rest of its safety.
   *
   * The id stays `emulator.deleteSram` though the label no longer says SRAM:
   * a command id is what a host's key bindings and menus are written against,
   * and renaming it would break them for the sake of a word nobody sees.
   */
  export const DELETE_SRAM: Command = Command.toLocalizedCommand(
    {
      id: 'emulator.deleteSram',
      label: 'Delete Current Save Game Slot',
      category: 'Emulator',
    },
    'vueport/commands/deleteSram',
    'vueport/commands/category'
  );

};

/**
 * The controller's own buttons, as the emulator's state and its on-screen
 * reference both name them.
 */
export type EmulatorGamePadButton =
    'lUp' | 'lRight' | 'lDown' | 'lLeft' | 'rUp' | 'rRight' | 'rDown' | 'rLeft'
    | 'a' | 'b' | 'start' | 'select' | 'lTrigger' | 'rTrigger';

export interface EmulatorGamePadInput {
    /** What the emulator presses when one of the mapped keys is. */
    key: EmulatorGamePadKeyCode;
    /** The command the mapping hangs off, per player. */
    command: Command;
    player2: Command;
}

/**
 * The second player's copy of a game pad command.
 *
 * A separate command rather than a modifier on the first player's, because a
 * mapping *is* a keybinding and a keybinding belongs to exactly one command —
 * so two sets of keys means two sets of commands. They carry the first
 * player's labels, which already say which button they are, under a category
 * that says which player.
 */
function player2Command(command: Command): Command {
    const player2: Command = { id: `${command.id}.player2` };
    // Both read on access, for the reason `toLocalizedCommand` explains: this
    // runs while the module is being imported, long before the host has
    // installed its translations. Reading player one's label through its own
    // accessor is also what keeps the two in step.
    Object.defineProperty(player2, 'label', {
        enumerable: true,
        get: () => command.label,
    });
    Object.defineProperty(player2, 'category', {
        enumerable: true,
        get: () => nls.localize(
            'vueport/input/gamePads/categoryPlayer2',
            'Emulator Game Pad (Player 2)'
        ),
    });
    return player2;
}

/**
 * Every game pad button, with the commands that carry its key mappings.
 *
 * The order is the one the on-screen reference reads in, top to bottom of the
 * left half and then the right.
 */
export const EMULATOR_GAMEPAD_INPUTS: Record<EmulatorGamePadButton, EmulatorGamePadInput> = {
    lTrigger: input(EmulatorGamePadKeyCode.LT, EmulatorCommands.INPUT_L_TRIGGER),
    lUp: input(EmulatorGamePadKeyCode.LUp, EmulatorCommands.INPUT_L_UP),
    lRight: input(EmulatorGamePadKeyCode.LRight, EmulatorCommands.INPUT_L_RIGHT),
    lDown: input(EmulatorGamePadKeyCode.LDown, EmulatorCommands.INPUT_L_DOWN),
    lLeft: input(EmulatorGamePadKeyCode.LLeft, EmulatorCommands.INPUT_L_LEFT),
    select: input(EmulatorGamePadKeyCode.Select, EmulatorCommands.INPUT_SELECT),
    start: input(EmulatorGamePadKeyCode.Start, EmulatorCommands.INPUT_START),
    rTrigger: input(EmulatorGamePadKeyCode.RT, EmulatorCommands.INPUT_R_TRIGGER),
    rUp: input(EmulatorGamePadKeyCode.RUp, EmulatorCommands.INPUT_R_UP),
    rRight: input(EmulatorGamePadKeyCode.RRight, EmulatorCommands.INPUT_R_RIGHT),
    rDown: input(EmulatorGamePadKeyCode.RDown, EmulatorCommands.INPUT_R_DOWN),
    rLeft: input(EmulatorGamePadKeyCode.RLeft, EmulatorCommands.INPUT_R_LEFT),
    b: input(EmulatorGamePadKeyCode.B, EmulatorCommands.INPUT_B),
    a: input(EmulatorGamePadKeyCode.A, EmulatorCommands.INPUT_A),
};

function input(key: EmulatorGamePadKeyCode, command: Command): EmulatorGamePadInput {
    return { key, command, player2: player2Command(command) };
}

export const EMULATOR_GAMEPAD_BUTTONS = Object.keys(EMULATOR_GAMEPAD_INPUTS) as EmulatorGamePadButton[];

/** The command a button's mapping hangs off, for one player. */
export function emulatorGamePadCommand(button: EmulatorGamePadButton, player: number): Command {
    const gamePadInput = EMULATOR_GAMEPAD_INPUTS[button];
    return player === 2 ? gamePadInput.player2 : gamePadInput.command;
}

/**
 * The emulator's actions, and the commands they are invoked through.
 *
 * Everything that acts on a running emulator goes through one of these,
 * whether it came from the toolbar, the command palette, or a key. The key
 * mappings still reach the widget directly rather than through Theia's
 * dispatcher — see `EMULATOR_FOCUS_CONTEXT`, which is deliberately never true
 * so that the widget can see key releases as well as presses — but they now
 * end up in the same place everything else does.
 *
 * Keyed by the action, which is the emulator's own name for what it does; the
 * keys it answers to are whatever the keybinding registry says, and the
 * defaults for those live in `registerKeybindings`.
 */
export const EMULATOR_ACTION_COMMANDS: Record<EmulatorAction, Command> = {
    [EmulatorAction.PauseToggle]: EmulatorCommands.INPUT_PAUSE_TOGGLE,
    [EmulatorAction.Reset]: EmulatorCommands.INPUT_RESET,
    [EmulatorAction.AudioMute]: EmulatorCommands.INPUT_AUDIO_MUTE,
    [EmulatorAction.ToggleLowPower]: EmulatorCommands.INPUT_TOGGLE_LOW_POWER,
    [EmulatorAction.ToggleFastForward]: EmulatorCommands.INPUT_TOGGLE_FAST_FORWARD,
    [EmulatorAction.ToggleSlowmotion]: EmulatorCommands.INPUT_TOGGLE_SLOWMOTION,
    [EmulatorAction.FrameAdvance]: EmulatorCommands.INPUT_FRAME_ADVANCE,
    [EmulatorAction.Rewind]: EmulatorCommands.INPUT_REWIND,
    [EmulatorAction.SaveState]: EmulatorCommands.INPUT_SAVE_STATE,
    [EmulatorAction.LoadState]: EmulatorCommands.INPUT_LOAD_STATE,
    [EmulatorAction.Fullscreen]: EmulatorCommands.INPUT_FULLSCREEN,
    [EmulatorAction.ToggleControlsOverlay]: EmulatorCommands.INPUT_TOGGLE_CONTROLS_OVERLAY,
    [EmulatorAction.Screenshot]: EmulatorCommands.INPUT_SCREENSHOT,
    [EmulatorAction.VideoRecord]: EmulatorCommands.INPUT_VIDEO_RECORD,
};

export const EMULATOR_ACTIONS = Object.keys(EMULATOR_ACTION_COMMANDS) as EmulatorAction[];

/**
 * What to ask before putting the panels back.
 *
 * Here rather than in either host: the question is about the emulator's own
 * layout, so both hosts should ask it in the same words and it should be
 * translated once. Built on call, not at import, because the host installs its
 * localization during start-up.
 */
export function resetLayoutConfirmation(): {
  title: string,
  message: string,
  okLabel: string,
} {
  return {
    title: nls.localize('vueport/layout/reset/title', 'Reset Layout?'),
    message: nls.localize(
      'vueport/layout/reset/message',
      'The panels go back to their default arrangement. '
      + 'Any panels you have opened, moved or resized are lost.'
    ),
    okLabel: nls.localize('vueport/layout/reset/confirm', 'Reset'),
  };
}
