import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import {
    builtInCheatsFor,
    CHEAT_DATABASE,
    BuiltInCheat,
    CheatDatabaseEntry,
} from '../common/emulator-cheat-database';
import {
    enabledVesCheatCodes,
    parseVesCheatCodes,
    parseVesCheatFile,
    serializeVesCheatFile,
    Cheat,
    vesCheatCodeBytes,
} from '../common/emulator-cheats';
import { Sim } from './core/vb-core';
import { VbCheatWrite } from '../common/vb-protocol';
import {
    readVesBrowserState,
    browserStateStorage,
    browserStateId,
    browserStateKey,
    writeVesBrowserState,
} from './emulator-browser-state';

interface StoredCheatState {
    enabled?: string[];
}

/**
 * One emulator's cheats: the list, the file it lives in, and pushing the
 * enabled ones into the core.
 *
 * Held by the widget rather than by the Cheats panel, for two reasons: cheats
 * stay in effect while that panel is closed, and the file has to be loaded as
 * soon as the ROM is, whether or not anyone has opened the panel. The panel
 * edits through this and redraws on onDidChange.
 *
 * The file is `<rom>.cht` beside the ROM, the same convention save RAM
 * follows, in the format `vueport-cheats.ts` documents — so cheats
 * written by RetroArch, or by hand from gamehacking.org, are picked up as they
 * are. It exists only while there are cheats to put in it: the first one
 * creates it and removing the last one deletes it, rather than leaving a file
 * saying there are none beside every ROM that was ever run.
 */
export class CheatStore {

    /** The player's own, which is what the `.cht` file beside the ROM holds. */
    protected custom: Cheat[] = [];
    /** What the emulator ships for this ROM, if it knows it. */
    protected builtIn: Cheat[] = [];
    /** The old companion file used before switch state moved into the browser. */
    protected legacyStatePath: string | undefined;
    protected browserStateKey: string | undefined;
    protected sim: Sim | undefined;
    /** Set while a link session owns where these writes go. See `setScheduler`. */
    protected scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined;
    protected uri: string | undefined;
    /** Set once a file has been read, so a first save cannot precede a load. */
    protected loaded = false;
    /**
     * Saves run one after another rather than at once: an edit and the edit
     * undoing it are a write and a delete, and the wrong order would leave the
     * file behind.
     */
    protected persisting: Promise<void> = Promise.resolve();

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires whenever the list changes, whatever changed it. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    constructor(
        protected readonly storage: VueportStorage,
        /**
         * The cheats to ship. Defaults to the emulator's own, and is a
         * parameter so a host can add to them — and so this can be given a
         * fixture rather than whatever happens to be in the database today.
         */
        protected readonly database: CheatDatabaseEntry[] = CHEAT_DATABASE,
        protected readonly stateStorage?: browserStateStorage,
    ) { }

    /**
     * Every cheat, the shipped ones first.
     *
     * One list rather than two, because a player looking for a cheat does not
     * care where it came from — only the few operations that would change a
     * built-in care, and they check `builtIn` (see `remove` and `update`).
     */
    get list(): ReadonlyArray<Cheat> {
        return [...this.builtIn, ...this.custom];
    }

    /** Where a list index falls: a shipped cheat, or one of the player's. */
    protected at(index: number): { cheat: Cheat, custom: number } | undefined {
        if (index < 0) {
            return undefined;
        }
        if (index < this.builtIn.length) {
            return { cheat: this.builtIn[index], custom: -1 };
        }
        const custom = index - this.builtIn.length;
        return this.custom[custom] ? { cheat: this.custom[custom], custom } : undefined;
    }

    /** Where the cheats are stored, once a ROM is known. */
    get filePath(): string | undefined {
        return this.uri;
    }

    /** The file's name, for the panel to show. */
    get fileName(): string | undefined {
        return this.uri === undefined ? undefined : this.storage.name(this.uri);
    }

    get isLoaded(): boolean {
        return this.loaded;
    }

    /**
     * Read what belongs to a ROM, replacing whatever was loaded before.
     *
     * Three things, from three places: the player's definitions from the
     * `.cht` file beside the ROM, the shipped ones from the database, and the
     * current switches from browser storage. Older companion-file switches
     * are migrated once, then removed from disk.
     *
     * `romId` is the ROM's CRC32; without one the database is simply not
     * consulted, which is the ordinary case for homebrew and for a build in
     * progress.
     */
    async load(romPath: string, romId?: string): Promise<void> {
        const directory = this.storage.parent(romPath);
        const stem = this.storage.stem(romPath);
        this.uri = this.storage.join(directory, `${stem}.cht`);
        this.legacyStatePath = this.storage.join(directory, `${stem}.vueport-cheats.json`);
        this.browserStateKey = browserStateKey('cheats', romPath);
        this.custom = [];
        this.builtIn = [];
        try {
            if (await this.storage.exists(this.uri)) {
                this.custom = parseVesCheatFile(await this.storage.readText(this.uri));
            }
            const hadLegacyCustomState = this.custom.some(cheat => cheat.enabled);
            const legacyBuiltIns = await this.readLegacyEnabledBuiltIns();
            this.builtIn = this.readBuiltIn(romId, new Set());
            const stored = readVesBrowserState<StoredCheatState>(
                this.stateStorage, this.browserStateKey);
            const enabled = Array.isArray(stored?.enabled)
                ? new Set(stored.enabled.filter(id => typeof id === 'string'))
                : this.legacyEnabledIds(legacyBuiltIns);
            this.restoreEnabled(enabled);
            this.loaded = true;
            if (this.saveBrowserState()) {
                await this.removeLegacyState();
                // `cheatN_enable` is part of the external format. Keep it at
                // its neutral value; the current switch now belongs solely to
                // the browser.
                if (hadLegacyCustomState) {
                    await this.saveDefinitions();
                }
            }
        } catch (error) {
            // A cheat file that cannot be read is not worth failing a launch
            // over: the emulator runs, with no cheats, and says why.
            console.warn(`[emulator] could not read cheats from ${this.uri}:`, error);
            this.loaded = false;
        }
        this.changed(false, false);
    }

    /** The shipped cheats for a ROM, as cheats, with their state restored. */
    protected readBuiltIn(romId: string | undefined, enabled: Set<string>): Cheat[] {
        return builtInCheatsFor(romId, this.database).map((cheat: BuiltInCheat) => ({
            description: cheat.description,
            enabled: enabled.has(cheat.id),
            // Parsed from the published form, so a database entry can be
            // pasted from a cheat list unchanged — the same text the `.cht`
            // file holds.
            codes: parseVesCheatCodes(cheat.codes),
            notes: cheat.notes,
            builtIn: true,
            id: cheat.id,
        }));
    }

    /** Read the state companion used by older builds, for one-time migration. */
    protected async readLegacyEnabledBuiltIns(): Promise<Set<string>> {
        if (!this.legacyStatePath || !await this.storage.exists(this.legacyStatePath)) {
            return new Set();
        }
        try {
            const stored = JSON.parse(await this.storage.readText(this.legacyStatePath));
            return new Set(Array.isArray(stored?.enabled) ? stored.enabled : []);
        } catch (error) {
            // Nothing here is worth failing over: the worst case is that some
            // shipped cheats come up switched off.
            console.warn(`[emulator] could not read ${this.legacyStatePath}:`, error);
            return new Set();
        }
    }

    /** Stable-enough identities for user entries without adding ids to `.cht`. */
    protected stateIds(): string[] {
        const counts = new Map<string, number>();
        const custom = this.custom.map(cheat => {
            const base = JSON.stringify([
                cheat.description,
                cheat.notes ?? '',
                cheat.codes.map(code => [code.address, code.value, code.digits]),
            ]);
            const occurrence = counts.get(base) ?? 0;
            counts.set(base, occurrence + 1);
            return `custom:${browserStateId(base)}:${occurrence}`;
        });
        return [
            ...this.builtIn.map(cheat => `built-in:${cheat.id}`),
            ...custom,
        ];
    }

    protected legacyEnabledIds(builtIns: Set<string>): Set<string> {
        const ids = this.stateIds();
        return new Set(ids.filter((id, index) => index < this.builtIn.length
            ? builtIns.has(this.builtIn[index].id!)
            : this.custom[index - this.builtIn.length].enabled));
    }

    protected restoreEnabled(enabled: Set<string>): void {
        const ids = this.stateIds();
        this.builtIn = this.builtIn.map((cheat, index) => ({ ...cheat, enabled: enabled.has(ids[index]) }));
        this.custom = this.custom.map((cheat, index) => ({
            ...cheat,
            enabled: enabled.has(ids[this.builtIn.length + index]),
        }));
    }

    protected saveBrowserState(): boolean {
        const ids = this.stateIds();
        const enabled = this.list.flatMap((cheat, index) => cheat.enabled ? [ids[index]] : []);
        return writeVesBrowserState(
            this.stateStorage, this.browserStateKey, { enabled }, this.list.length === 0);
    }

    protected async removeLegacyState(): Promise<void> {
        const path = this.legacyStatePath;
        if (!path) {
            return;
        }
        try {
            if (await this.storage.exists(path)) {
                await this.storage.delete(path);
            }
        } catch (error) {
            console.warn(`[emulator] could not remove legacy cheat state ${path}:`, error);
        }
    }

    /** The simulation the enabled cheats apply to, or undefined once it is gone. */
    setSim(sim: Sim | undefined): void {
        this.sim = sim;
        this.apply();
    }

    /**
     * Route the writes through a link session instead of straight into the
     * machine, for as long as there is one.
     *
     * A cheat is a change nobody in the emulated program made, so in a linked
     * session it has to reach the other window's mirror of this machine as
     * well — and land on the same frame there, or the two are running
     * different games from that frame on. The session knows how to arrange
     * that and this does not, so it is handed the codes and says whether it
     * took them; false, and they go straight in as they always did.
     *
     * Undefined to go back to writing directly, which is what leaving a
     * session does.
     */
    setScheduler(scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined): void {
        // Deliberately not re-applying. Joining a session, what this machine
        // is already running under travels as the session's standing edits and
        // is in this machine already; leaving one, the switches made during it
        // went through the session and into this machine on the way. Applying
        // again here would send a redundant booking at each end of every
        // session, including an empty one when there are no cheats at all.
        this.scheduler = scheduler;
    }

    /**
     * The writes the enabled cheats amount to.
     *
     * What `apply` pushes, exposed because a link session has to send the same
     * list to the other window when a run starts — see `standingEdits` in
     * `link-session.ts`.
     */
    get writes(): VbCheatWrite[] {
        return enabledVesCheatCodes([...this.list]).map(code => ({
            address: code.address,
            value: code.value,
            bytes: vesCheatCodeBytes(code),
        }));
    }

    add(description: string): number {
        this.custom.push({ description, enabled: false, codes: [] });
        this.changed(true, true);
        return this.list.length - 1;
    }

    /**
     * Add a set of cheats read from a `.cht` file, on top of what is loaded.
     *
     * They come in as the player's own — a built-in flag or id from the file is
     * dropped — and off, whatever the file said: an import should not switch
     * writes on without the player choosing to. Returns how many were added.
     */
    importCheats(cheats: readonly Cheat[]): number {
        const added = cheats
            .filter(cheat => cheat.codes.length > 0)
            .map(cheat => ({
                description: cheat.description,
                enabled: false,
                codes: [...cheat.codes],
            }));
        this.custom.push(...added);
        if (added.length > 0) {
            this.changed(true, true);
        }
        return added.length;
    }

    /**
     * Take one of the player's cheats away.
     *
     * A shipped cheat is not the player's to remove — the next release may
     * correct it, and a copy deleted here would come back anyway — so this
     * quietly does nothing for one. The panel does not offer it either; this
     * is the guard behind that, not the whole of it.
     */
    remove(index: number): void {
        const found = this.at(index);
        if (!found || found.custom < 0) {
            return;
        }
        this.custom.splice(found.custom, 1);
        this.changed(true, true);
    }

    /**
     * Change one cheat: its name, whether it is on, or its codes.
     *
     * On a shipped cheat only `enabled` takes effect: what it is called and
     * what it writes are the database's to say.
     */
    update(index: number, patch: Partial<Cheat>): void {
        const found = this.at(index);
        if (!found) {
            return;
        }
        if (found.custom < 0) {
            if (patch.enabled === undefined || patch.enabled === found.cheat.enabled) {
                return;
            }
            this.builtIn[index] = { ...found.cheat, enabled: patch.enabled };
        } else {
            this.custom[found.custom] = { ...found.cheat, ...patch, builtIn: undefined, id: undefined };
        }
        const definitionChanged = found.custom >= 0
            && Object.keys(patch).some(key => key !== 'enabled');
        this.changed(definitionChanged, true);
    }

    /**
     * Switch every enabled cheat off at once.
     *
     * Hardcore mode calls this: a cheat still on would make the unlocks that
     * follow unearned. One `changed()` for the lot rather than one per cheat.
     */
    disableAll(): void {
        let any = false;
        const off = (cheat: Cheat): Cheat => {
            if (!cheat.enabled) {
                return cheat;
            }
            any = true;
            return { ...cheat, enabled: false };
        };
        this.builtIn = this.builtIn.map(off);
        this.custom = this.custom.map(off);
        if (any) {
            this.changed(false, true);
        }
    }

    /**
     * Push the enabled writes into the core, replacing whatever was there.
     *
     * The core repeats them at every frame break for as long as they are set,
     * so this is the only call needed — there is no per-frame work on this
     * side at all.
     */
    protected apply(): void {
        const codes = this.writes;
        // A linked session books them against a frame both windows can still
        // reach, and only falls through to here if it could not.
        if (this.scheduler?.(codes)) {
            return;
        }
        this.sim?.setCheats(codes);
    }

    /**
     * Write the definitions back, or take the file away once the last cheat
     * is gone. The current switches are deliberately neutralized here and
     * written to browser storage by `changed`.
     *
     * Saving on every edit is deliberate: a cheat is a few bytes of text, and
     * a list that quietly failed to outlive the window it was typed in would
     * be worse than a rare redundant write. A load that failed does not save,
     * so a file that could not be read is neither overwritten from an empty
     * list nor deleted.
     */
    protected async saveDefinitions(): Promise<void> {
        const uri = this.uri;
        if (!uri || !this.loaded) {
            return;
        }
        try {
            if (this.custom.length === 0) {
                if (await this.storage.exists(uri)) {
                    await this.storage.delete(uri);
                }
            } else {
                await this.storage.writeText(uri, serializeVesCheatFile(
                    this.custom.map(cheat => ({ ...cheat, enabled: false }))));
            }
        } catch (error) {
            console.warn(`[emulator] could not store cheats in ${uri}:`, error);
        }
    }

    protected changed(persistDefinitions = true, persistState = true): void {
        this.apply();
        if (persistState) {
            this.saveBrowserState();
        }
        if (persistDefinitions) {
            this.persisting = this.persisting.then(() => this.saveDefinitions());
        }
        this.onDidChangeEmitter.fire();
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}
