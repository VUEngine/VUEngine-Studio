import { Emitter, Event } from '../common/emulator-events';
import { cheatNotes, cheatTitle } from '../common/emulator-catalog-nls';
import { VueportStorage } from '../common/emulator-host';
import {
    anchorCheatCodeToRomTop,
    builtInCheatsFor,
    CHEAT_DATABASE,
    BuiltInCheat,
    CheatDatabaseEntry,
} from '../common/emulator-cheat-database';
import {
    enabledVesCheatCodes,
    parseVesCheatCodes,
    parseVesCheatFile,
    serializeVesCheatFile,
    Cheat,
    vesCheatCodeBytes,
} from '../common/emulator-cheats';
import { Sim } from './core/vb-core';
import { VbCheatWrite } from '../common/vb-protocol';
import {
    readVesBrowserState,
    browserStateStorage,
    browserStateId,
    browserStateKey,
    writeVesBrowserState,
} from './emulator-browser-state';

interface StoredCheatState {
    enabled?: string[];
}

/**
 * One emulator's cheats: the list, its file, and pushing enabled ones into the core. Held by the widget, not
 * the Cheats panel, as cheats stay active while it is closed and load with the ROM; the panel edits through
 * this. The file is `<rom>.cht` beside the ROM (like save RAM) in the format emulator-cheats.ts documents, so
 * RetroArch and gamehacking.org cheats work as they are. It only exists while there are cheats: the first one
 * creates it, removing the last deletes it
 */
export class CheatStore {

    // the player's own, which the `.cht` file beside the ROM holds
    protected custom: Cheat[] = [];
    // what the emulator ships for this ROM, if any
    protected builtIn: Cheat[] = [];
    protected browserStateKey: string | undefined;
    protected sim: Sim | undefined;
    // set while a link session owns where these writes go, see setScheduler
    protected scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined;
    protected uri: string | undefined;
    // set once a file has been read, so a first save cannot precede a load
    protected loaded = false;
    // saves run one after another: an edit and its undo are a write and a delete, and the wrong order would
    // leave the file behind
    protected persisting: Promise<void> = Promise.resolve();

    protected readonly onDidChangeEmitter = new Emitter<void>();
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    constructor(
        protected readonly storage: VueportStorage,
        // cheats to ship; defaults to the emulator's own, a parameter so a host can add some and tests can pass a fixture
        protected readonly database: CheatDatabaseEntry[] = CHEAT_DATABASE,
        protected readonly stateStorage?: browserStateStorage,
    ) { }

    // shipped ones first. One list, as players do not care where a cheat came from; the few operations that would
    // change a built-in check `builtIn` (see remove and update)
    get list(): ReadonlyArray<Cheat> {
        return [...this.builtIn, ...this.custom];
    }

    // where a list index falls: a shipped cheat, or one of the player's
    protected at(index: number): { cheat: Cheat, custom: number } | undefined {
        if (index < 0) {
            return undefined;
        }
        if (index < this.builtIn.length) {
            return { cheat: this.builtIn[index], custom: -1 };
        }
        const custom = index - this.builtIn.length;
        return this.custom[custom] ? { cheat: this.custom[custom], custom } : undefined;
    }

    // once a ROM is known
    get filePath(): string | undefined {
        return this.uri;
    }

    // for the panel to show
    get fileName(): string | undefined {
        return this.uri === undefined ? undefined : this.storage.name(this.uri);
    }

    get isLoaded(): boolean {
        return this.loaded;
    }

    /**
     * Reads what belongs to a ROM, replacing what was loaded: definitions from the `.cht` beside it, shipped ones from
     * the database, switches from browser storage. A `cheatN_enable` in the file is not taken as a switch, so a
     * cheat without a remembered switch starts off. `romId` is the CRC32; without it the database is skipped
     * (homebrew, builds in progress). `romSize` is the unpatched ROM's length, so shipped ROM writes still land when
     * a patch has grown the ROM (see anchorCheatCodeToRomTop)
     */
    async load(romPath: string, romId?: string, romSize?: number): Promise<void> {
        const directory = this.storage.parent(romPath);
        const stem = this.storage.stem(romPath);
        this.uri = this.storage.join(directory, `${stem}.cht`);
        this.browserStateKey = browserStateKey('cheats', romPath);
        this.custom = [];
        this.builtIn = [];
        try {
            if (await this.storage.exists(this.uri)) {
                this.custom = parseVesCheatFile(await this.storage.readText(this.uri));
            }
            this.builtIn = this.readBuiltIn(romId, romSize);
            const stored = readVesBrowserState<StoredCheatState>(
                this.stateStorage, this.browserStateKey);
            this.restoreEnabled(Array.isArray(stored?.enabled)
                ? new Set(stored.enabled.filter(id => typeof id === 'string'))
                : new Set());
            this.loaded = true;
        } catch (error) {
            // an unreadable cheat file is not worth failing a launch over: run without cheats and say why
            console.warn(`[emulator] could not read cheats from ${this.uri}:`, error);
            this.loaded = false;
        }
        this.changed(false, false);
    }

    // all off until restoreEnabled
    protected readBuiltIn(romId: string | undefined, romSize?: number): Cheat[] {
        return builtInCheatsFor(romId, this.database).map((cheat: BuiltInCheat) => ({
            // in the player's language: a shipped cheat's title is never stored, only its id (see stateIds)
            description: cheatTitle(cheat),
            enabled: false,
            // parsed from the published form, so database entries can be pasted from a cheat list unchanged
            codes: parseVesCheatCodes(cheat.codes)
                .map(code => romSize === undefined ? code : anchorCheatCodeToRomTop(code, romSize)),
            notes: cheatNotes(cheat),
            builtIn: true,
            id: cheat.id,
        }));
    }

    // stable-enough identities for user entries without adding ids to `.cht`
    protected stateIds(): string[] {
        const counts = new Map<string, number>();
        const custom = this.custom.map(cheat => {
            const base = JSON.stringify([
                cheat.description,
                cheat.notes ?? '',
                cheat.codes.map(code => [code.address, code.value, code.digits]),
            ]);
            const occurrence = counts.get(base) ?? 0;
            counts.set(base, occurrence + 1);
            return `custom:${browserStateId(base)}:${occurrence}`;
        });
        return [
            ...this.builtIn.map(cheat => `built-in:${cheat.id}`),
            ...custom,
        ];
    }

    protected restoreEnabled(enabled: Set<string>): void {
        const ids = this.stateIds();
        this.builtIn = this.builtIn.map((cheat, index) => ({ ...cheat, enabled: enabled.has(ids[index]) }));
        this.custom = this.custom.map((cheat, index) => ({
            ...cheat,
            enabled: enabled.has(ids[this.builtIn.length + index]),
        }));
    }

    protected saveBrowserState(): boolean {
        const ids = this.stateIds();
        const enabled = this.list.flatMap((cheat, index) => cheat.enabled ? [ids[index]] : []);
        return writeVesBrowserState(
            this.stateStorage, this.browserStateKey, { enabled }, this.list.length === 0);
    }

    // the simulation the enabled cheats apply to, or undefined once it is gone
    setSim(sim: Sim | undefined): void {
        this.sim = sim;
        this.apply();
    }

    /**
     * Routes the writes through a link session while there is one: a cheat must reach the other window's mirror
     * machine on the same frame, or the two diverge. The session books it and returns whether it took them; on
     * false they go straight in. Undefined goes back to writing directly, as when leaving a session
     */
    setScheduler(scheduler: ((codes: VbCheatWrite[]) => boolean) | undefined): void {
        // deliberately not re-applying: on joining, the running cheats travel as the session's standing edits and are
        // already in this machine; on leaving, switches made during it already went through. Applying again would send
        // a redundant booking at each end of every session
        this.scheduler = scheduler;
    }

    // what apply pushes; a link session sends the same list to the other window when a run starts (standingEdits
    // in link-session.ts)
    get writes(): VbCheatWrite[] {
        return enabledVesCheatCodes([...this.list]).map(code => ({
            address: code.address,
            value: code.value,
            bytes: vesCheatCodeBytes(code),
        }));
    }

    add(description: string): number {
        this.custom.push({ description, enabled: false, codes: [] });
        this.changed(true, true);
        return this.list.length - 1;
    }

    // adds cheats from a `.cht` file as the player's own (built-in flag and id dropped) and off, whatever the file
    // said, as an import should not switch writes on. Returns how many were added
    importCheats(cheats: readonly Cheat[]): number {
        const added = cheats
            .filter(cheat => cheat.codes.length > 0)
            .map(cheat => ({
                description: cheat.description,
                enabled: false,
                codes: [...cheat.codes],
            }));
        this.custom.push(...added);
        if (added.length > 0) {
            this.changed(true, true);
        }
        return added.length;
    }

    // a shipped cheat is not the player's to remove (the next release may correct it and it would come back), so
    // this does nothing for one; the guard behind the panel not offering it
    remove(index: number): void {
        const found = this.at(index);
        if (!found || found.custom < 0) {
            return;
        }
        this.custom.splice(found.custom, 1);
        this.changed(true, true);
    }

    // on a shipped cheat only `enabled` takes effect: name and writes are the database's
    update(index: number, patch: Partial<Cheat>): void {
        const found = this.at(index);
        if (!found) {
            return;
        }
        if (found.custom < 0) {
            if (patch.enabled === undefined || patch.enabled === found.cheat.enabled) {
                return;
            }
            this.builtIn[index] = { ...found.cheat, enabled: patch.enabled };
        } else {
            this.custom[found.custom] = { ...found.cheat, ...patch, builtIn: undefined, id: undefined };
        }
        const definitionChanged = found.custom >= 0
            && Object.keys(patch).some(key => key !== 'enabled');
        this.changed(definitionChanged, true);
    }

    // called by hardcore mode, as an active cheat would make following unlocks unearned; one changed() for all
    disableAll(): void {
        let any = false;
        const off = (cheat: Cheat): Cheat => {
            if (!cheat.enabled) {
                return cheat;
            }
            any = true;
            return { ...cheat, enabled: false };
        };
        this.builtIn = this.builtIn.map(off);
        this.custom = this.custom.map(off);
        if (any) {
            this.changed(false, true);
        }
    }

    // replaces what the core holds; the core repeats the writes at every frame break, so there is no per-frame work here
    protected apply(): void {
        const codes = this.writes;
        // a linked session books them against a frame both windows can still reach, falling through here only if it cannot
        if (this.scheduler?.(codes)) {
            return;
        }
        this.sim?.setCheats(codes);
    }

    /**
     * Writes the definitions back, or removes the file after the last cheat; switches are neutralized here and kept
     * in browser storage by changed. Saved on every edit, as a few bytes of text beat a list lost with the window.
     * A failed load does not save, so an unreadable file is neither overwritten nor deleted
     */
    protected async saveDefinitions(): Promise<void> {
        const uri = this.uri;
        if (!uri || !this.loaded) {
            return;
        }
        try {
            if (this.custom.length === 0) {
                if (await this.storage.exists(uri)) {
                    await this.storage.delete(uri);
                }
            } else {
                await this.storage.writeText(uri, serializeVesCheatFile(
                    this.custom.map(cheat => ({ ...cheat, enabled: false }))));
            }
        } catch (error) {
            console.warn(`[emulator] could not store cheats in ${uri}:`, error);
        }
    }

    protected changed(persistDefinitions = true, persistState = true): void {
        this.apply();
        if (persistState) {
            this.saveBrowserState();
        }
        if (persistDefinitions) {
            this.persisting = this.persisting.then(() => this.saveDefinitions());
        }
        this.onDidChangeEmitter.fire();
    }

    dispose(): void {
        this.onDidChangeEmitter.dispose();
    }
}
