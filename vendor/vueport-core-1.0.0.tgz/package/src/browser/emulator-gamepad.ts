/**
 * Physical controller input.
 *
 * Reads connected gamepads through the Gamepad API and folds them into one
 * Virtual Boy key mask, through whatever profile each pad resolves to. What a
 * profile is, and why the mapping is per device rather than fixed, is in
 * `emulator-gamepad-profiles.ts`; this module is the part that touches the
 * browser.
 *
 * Which pads feed a machine is a separate question from what their buttons do.
 * Solo, every pad drives the same machine, so a second controller is a second
 * pair of hands. A linked pair asks for player 1 and 2, and then each side gets
 * the pads assigned to it — by the person, in the Game Pads settings, or by
 * connection order when they have not said.
 */

import {
    GamepadDatabase,
    GamepadProfile,
    GamepadReading,
    GamepadUiAction,
    gamepadDeviceKey,
    gamepadName,
    pressedGamepadSources,
    readGamepadContribution,
    resolveGamepadProfile,
} from '../common/emulator-gamepad-profiles';
import { EmulatorAction } from './emulator-types';

export { gamepadName };

/**
 * Where pads come from instead of the Gamepad API, when a host reads them
 * itself — the desktop shell does, through SDL, because its webview's Gamepad
 * API misses pads a browser sees. See {@link setGamepadSource}.
 */
let gamepadSource: (() => (Gamepad | null)[]) | undefined;

/**
 * Read pads from here rather than from `navigator.getGamepads()`.
 *
 * Everything that reads a pad goes through {@link connectedGamepadList}, so
 * this is the one switch: the emulator's input, the settings, the rumble and
 * the interface steering all follow. A source also has to announce pads coming
 * and going the way the browser does, with `gamepadconnected` and
 * `gamepaddisconnected` on `window` — see {@link onGamepadsChanged}.
 */
export function setGamepadSource(source: (() => (Gamepad | null)[]) | undefined): void {
    gamepadSource = source;
}

/** Every pad the page can see right now, holes and all. */
function rawGamepads(): (Gamepad | null)[] {
    if (gamepadSource) {
        return gamepadSource();
    }
    // Not every environment exposes the API, and Electron returns a sparse
    // array with holes for disconnected slots.
    return typeof navigator.getGamepads === 'function' ? [...navigator.getGamepads()] : [];
}

/** The connected pads, in the order the Gamepad API reports them. */
export function connectedGamepadList(): Gamepad[] {
    const pads = rawGamepads().filter((pad): pad is Gamepad => pad !== null);
    if (heldAtConnect.size > pads.length) {
        // A pad that went away and comes back is new again.
        const present = new Set(pads.map(padKey));
        for (const key of heldAtConnect.keys()) {
            if (!present.has(key)) {
                heldAtConnect.delete(key);
            }
        }
    }
    return pads.map(withoutHeldAtConnect);
}

/**
 * What each pad had held the moment it turned up, by slot and id, until it is
 * let go. Buttons and axes by index.
 */
const heldAtConnect = new Map<string, { buttons: Set<number>, axes: Set<number> }>();

function padKey(pad: Gamepad): string {
    return `${pad.index}:${pad.id}`;
}

/** How near the middle an axis has to come back before it counts again. */
const AXIS_SETTLED = 0.25;

/** Past a stick's range: a hat at rest, as `emulator-gamepad-profiles.ts` reads one. */
const AXIS_HAT_REST = 1.05;

function isButtonHeld(button: GamepadButton | undefined): boolean {
    return button !== undefined && (button.pressed || button.value > 0.5);
}

function isAxisSettled(value: number): boolean {
    return Math.abs(value) < AXIS_SETTLED || Math.abs(value) > AXIS_HAT_REST;
}

/**
 * A pad as it would read with nothing held, for whatever was held when it
 * turned up and has not been let go since.
 *
 * A pad's first reading is not to be trusted. Before its first report an axis
 * reads whatever the system had for it, and on macOS that is the bottom of its
 * range: SDL takes that as the axis's value until the pad says otherwise, so
 * the 8BitDo 64's C-Up — an axis SDL turns into a button — read held the
 * moment the pad connected, and the game got R-Up. Firefox does the same with
 * a raw pad's axes. And a browser only shows a pad once a button has been
 * pressed on it, which is a press nobody meant for the game either.
 *
 * So whatever reads held on first sight counts as released until it has been:
 * a button once it is up, an axis once it is back near the middle (or at a
 * hat's rest). Done here, where every reader passes, so the game, the settings
 * and the interface steering all see the same thing.
 */
function withoutHeldAtConnect(pad: Gamepad): Gamepad {
    const key = padKey(pad);
    let held = heldAtConnect.get(key);
    if (!held) {
        held = { buttons: new Set(), axes: new Set() };
        pad.buttons.forEach((button, index) => {
            if (isButtonHeld(button)) {
                held!.buttons.add(index);
            }
        });
        pad.axes.forEach((value, index) => {
            if (!isAxisSettled(value)) {
                held!.axes.add(index);
            }
        });
        heldAtConnect.set(key, held);
    }
    for (const index of held.buttons) {
        if (!isButtonHeld(pad.buttons[index])) {
            held.buttons.delete(index);
        }
    }
    for (const index of held.axes) {
        if (isAxisSettled(pad.axes[index] ?? 0)) {
            held.axes.delete(index);
        }
    }
    if (held.buttons.size === 0 && held.axes.size === 0) {
        return pad;
    }

    // A copy rather than the pad itself, whose fields are read-only, and
    // rather than an object over it, whose getters refuse anything but a
    // real Gamepad.
    const released = { pressed: false, touched: false, value: 0 };
    const source = pad as unknown as Record<string, unknown>;
    return {
        id: pad.id,
        index: pad.index,
        mapping: pad.mapping,
        connected: pad.connected,
        timestamp: pad.timestamp,
        axes: pad.axes.map((value, index) => held!.axes.has(index) ? 0 : value),
        buttons: pad.buttons.map((button, index) => held!.buttons.has(index) ? released : button),
        vibrationActuator: source.vibrationActuator ?? null,
        hapticActuators: source.hapticActuators ?? [],
        // Not part of the Gamepad API: the desktop's pads carry it — see
        // `GamepadDescriptor.engine` in `emulator-gamepad-profiles.ts`.
        engine: source.engine,
    } as unknown as Gamepad;
}

/**
 * How a caller says which pads feed the machine being driven, and what each
 * one's buttons do.
 *
 * An interface rather than two arguments because both answers come from the
 * same settings and change at the same time — a pad being assigned to player 2
 * and a pad's mapping being edited are both "the input settings changed".
 */
export interface GamepadProfileResolver {
    /** The mapping in force for one pad. */
    profileFor(pad: Gamepad): GamepadProfile;
    /**
     * Whether this pad drives the machine asking.
     *
     * `player` is what the host asked for: 1 or 2 for a linked session, and
     * undefined for a solo one, where every pad counts.
     */
    drivesPlayer(pad: Gamepad, player: number | undefined): boolean;
}

/** What every connected pad is contributing this frame. */
export interface GamepadFrame {
    /** The Virtual Boy key mask, every driving pad folded together. */
    keys: number;
    /** Emulator actions whose bound control is held on any driving pad. */
    actions: Set<EmulatorAction>;
    /** The host's own actions held on any driving pad — see `GamepadUiAction`. */
    uiActions: Set<GamepadUiAction>;
}

const EMPTY_FRAME: GamepadFrame = { keys: 0, actions: new Set(), uiActions: new Set() };

/**
 * Read every pad that drives this machine, through its own profile.
 *
 * One pass for both the mask and the actions, because they come off the same
 * reading and this runs once per animation frame: two passes would poll the
 * pads twice for no gain.
 */
export function readGamepadFrame(
    resolver: GamepadProfileResolver,
    player?: number,
): GamepadFrame {
    const pads = connectedGamepadList().filter(pad => resolver.drivesPlayer(pad, player));
    if (pads.length === 0) {
        return EMPTY_FRAME;
    }

    let keys = 0;
    let actions: Set<EmulatorAction> | undefined;
    let uiActions: Set<GamepadUiAction> | undefined;
    for (const pad of pads) {
        const contribution = readGamepadContribution(pad, resolver.profileFor(pad));
        keys |= contribution.keys;
        if (contribution.actions.size > 0) {
            actions ??= new Set();
            for (const action of contribution.actions) {
                actions.add(action);
            }
        }
        if (contribution.uiActions.size > 0) {
            uiActions ??= new Set();
            for (const action of contribution.uiActions) {
                uiActions.add(action);
            }
        }
    }
    return { keys, actions: actions ?? EMPTY_FRAME.actions, uiActions: uiActions ?? EMPTY_FRAME.uiActions };
}

/**
 * Which controls are held on one pad right now, as source ids.
 *
 * What the Game Pads settings read: to notice the button somebody just pressed
 * while a mapping is being recorded, and to light the picture up while a
 * mapped control is held, which is how a person checks a mapping is right
 * without starting a game.
 *
 * `hats` is which of the pad's axes are hat switches; keep it across calls and
 * this fills it in (see `pressedGamepadSources`).
 */
export function readPressedSources(pad: Gamepad, deadZone: number, hats?: Set<number>): Set<string> {
    return pressedGamepadSources(pad as GamepadReading, deadZone, hats);
}

/**
 * The controllers the page can see, by the name the browser gives them.
 *
 * A caveat worth knowing before showing this to anyone: a pad that is plugged
 * in but has not been touched does not exist as far as a page is concerned.
 * The Gamepad API withholds it until a button is pressed, deliberately — the
 * list of devices attached to a machine is a fingerprint. So "nothing
 * connected" here means "nothing has been used", which is the honest thing for
 * a readout to say and the reason this one is worded the way it is.
 */
export function connectedGamepads(): string[] {
    return connectedGamepadList().map(pad => gamepadName(pad.id));
}

/**
 * Fires when a controller is plugged in or unplugged. Returns the unsubscribe.
 *
 * Events rather than polling: the emulator already reads the pads every frame
 * for their buttons, but a profile only has to be resolved again when the set
 * of pads changes, and that happens twice an hour rather than sixty times a
 * second.
 */
export function onGamepadsChanged(listener: () => void): () => void {
    if (typeof window === 'undefined') {
        return () => undefined;
    }
    window.addEventListener('gamepadconnected', listener);
    window.addEventListener('gamepaddisconnected', listener);
    return () => {
        window.removeEventListener('gamepadconnected', listener);
        window.removeEventListener('gamepaddisconnected', listener);
    };
}

/**
 * A resolver over stored profiles and stored player assignments.
 *
 * The one implementation both the emulator and the settings page use, so that
 * what the settings show a pad doing is what the game will do with it.
 *
 * Assignment is by device, which means two pads of the same model share an
 * assignment — there is nothing in a browser's id to tell them apart. Ties are
 * broken by connection order, so a pair of identical pads still lands one on
 * each player rather than both on the same one.
 */
export class StoredGamepadProfiles implements GamepadProfileResolver {

    /** Resolved profiles, by device key, rebuilt when the settings change. */
    protected cache = new Map<string, GamepadProfile>();

    constructor(
        protected stored: () => GamepadProfile[],
        /** Which player a device drives, by device key. Absent means either. */
        protected players: () => Record<string, number>,
        protected database?: () => GamepadDatabase | undefined,
    ) { }

    /** Drop the cache, so the next frame resolves against the new settings. */
    invalidate(): void {
        this.cache.clear();
    }

    profileFor(pad: Gamepad): GamepadProfile {
        const key = gamepadDeviceKey(pad.id);
        let profile = this.cache.get(key);
        if (!profile) {
            profile = resolveGamepadProfile(pad, this.stored(), this.database?.()).profile;
            this.cache.set(key, profile);
        }
        return profile;
    }

    drivesPlayer(pad: Gamepad, player: number | undefined): boolean {
        if (player === undefined) {
            // Solo: every pad is a pair of hands on the same machine.
            return true;
        }
        const assigned = this.players()[gamepadDeviceKey(pad.id)];
        if (assigned !== undefined) {
            return assigned === player;
        }
        // Nothing said, so fall back to what the Gamepad API's own order
        // implies — but only over the pads that have no assignment of their
        // own, since an assigned pad has already been spoken for.
        //
        // Compared by slot rather than by identity: `getGamepads` hands back a
        // fresh snapshot on every call, so the object here is never the same
        // object as the one in a list read a moment ago. `index` is the API's
        // own stable slot number and survives that.
        const unassigned = connectedGamepadList()
            .filter(other => this.players()[gamepadDeviceKey(other.id)] === undefined);
        return unassigned.findIndex(other => other.index === pad.index) === player - 1;
    }
}
