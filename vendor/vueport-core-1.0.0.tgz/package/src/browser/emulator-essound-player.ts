import { Emitter, Event } from '../common/emulator-events';
import { VueportStorage } from '../common/emulator-host';
import {
    decodeEsSoundMessage,
    describeEsSoundMessage,
    EsSoundCommand,
    esSoundAudibleWindow,
    esSoundBalance,
    esSoundFileInfo,
    esSoundFileName,
    EsSoundKind,
    esSoundKindOf,
    EsSoundMessage,
    ES_SOUND_TITLES_FILE,
    esSoundTrackOf,
    esSoundVolume,
    mp3GaplessInfo,
    parseEsSoundTitles,
} from '../common/emulator-essound';
import { Sim } from './core/vb-core';

/** One audio file found beside the ROM. */
export interface EsSoundTrack {
    id: number;
    kind: EsSoundKind;
    name: string;
    path: string;
    /** Bytes, for the panel to show. */
    size: number;
    /**
     * How long the music runs, in seconds: from the file's headers once they
     * have been read, and exact once the track has been decoded.
     */
    seconds?: number;
    /**
     * The title from `essound.json`, or else from the file's tags, when
     * either has one.
     */
    title?: string;
}

/** What one slot is playing, for the panel. */
export interface EsSoundNowPlaying {
    track: EsSoundTrack;
    /** Seconds into the music. */
    position: number;
    loop: boolean;
    /** Started from the panel rather than by the game. */
    manual: boolean;
    /** Not sounding: still being decoded, or held while the emulator is. */
    waiting: boolean;
}

/** One halfword the game sent, kept for the history list. */
export interface EsSoundHistoryEntry {
    time: number;
    message: EsSoundMessage;
    description: string;
    /** Why nothing happened, when nothing did. */
    problem?: string;
}

/**
 * ESSound's part of a save state: what is playing, where, and the levels the
 * game has set.
 *
 * Kept as plain data so it can go into the save state file as JSON beside the
 * core's own state — the audio is played on this side, so the core knows
 * nothing about it and restoring a state would otherwise leave whatever was
 * playing before running on.
 */
export interface EsSoundSnapshot {
    playing: { kind: EsSoundKind, track: number, position: number, loop: boolean }[];
    volumes: [number, number][];
    balances: [number, number][];
}

/** How many commands the history keeps. */
export const ES_SOUND_HISTORY_LENGTH = 20;

/** What browsers will actually play a track at; beyond this they mute it. */
const MIN_PLAYBACK_RATE = 0.25;
const MAX_PLAYBACK_RATE = 4;

/** What the hardware falls back to before SET VOLUME or SET BALANCE is used. */
const DEFAULT_VOLUME = 1;
const DEFAULT_BALANCE = 0;

/**
 * How much decoded audio is kept for tracks that are not playing, in bytes.
 *
 * Decoded audio is 32-bit float per sample and channel, some 22 MB for a
 * minute of stereo, and a game with a full soundtrack beside it would not
 * fit; the tracks used longest ago go first.
 */
const DECODED_BUDGET = 384 * 1024 * 1024;

/** A track decoded, and where its music lies in it. */
interface EsSoundBuffer {
    buffer: AudioBuffer;
    /** The audible part, in seconds: MP3s carry encoder silence at both ends. */
    start: number;
    end: number;
}

/**
 * One slot of the hardware: the MP3 player or the WAV player.
 *
 * ESSound can play one of each at a time, so a second PLAY on the same slot
 * replaces what it was playing rather than joining it.
 *
 * Played from decoded audio rather than through a media element: an element
 * seeks back to the start of its file for every loop and starts each file
 * with a load, and both are audible gaps in music. A buffer source loops on
 * the sample and starts at once.
 */
interface EsSoundSlot {
    track: number;
    loop: boolean;
    /**
     * Started from the panel. Such a track plays while the emulator is paused
     * — that is when it is usually asked for — and the game's own tracks are
     * held meanwhile.
     */
    manual: boolean;
    gain: GainNode;
    panner: StereoPannerNode;
    /** The decoded track, once it is; until then the slot waits silently. */
    audio?: EsSoundBuffer;
    /** What plays it. A source node plays once, so each start makes a new one. */
    source?: AudioBufferSourceNode;
    /** Position in the music, in seconds, at context time `since`, moving at `rate`. */
    position: number;
    since: number;
    rate: number;
}

/**
 * ESSound playback for one emulator: the files beside the ROM, the commands
 * the game sends, and the audio they produce.
 *
 * Held by the widget rather than by the ESSound panel, because a game's audio
 * has to keep playing whether or not anyone has that panel open — the panel
 * only shows what this is doing.
 *
 * Files are read through the file service and decoded into audio buffers,
 * which keep their place for as long as the memory budget allows, since a
 * game asks for the same handful of tracks over and over.
 */
export class EsSoundPlayer {

    protected tracks: EsSoundTrack[] = [];
    protected history: EsSoundHistoryEntry[] = [];
    protected sim: Sim | undefined;
    protected muted = false;
    protected paused = false;
    protected rewinding = false;
    protected speed = 1;
    /** Emulated seconds given up by the rewind currently in progress. */
    protected rewound = 0;
    /** Set once the ROM has been looked at, so the panel can tell "none" from "not yet". */
    protected scanned = false;
    /**
     * The folder the last scan looked in, and why it could not.
     *
     * Kept so the panel can say both. "No files found" is the same sentence
     * whether the folder was empty, whether the files in it are named
     * something the hardware would never ask for, or whether the folder could
     * not be read at all — and told apart only by naming the folder and
     * repeating the reason.
     */
    protected directory: string | undefined;
    protected failure: string | undefined;
    /** Why `essound.json` could not be used, when it is there and could not. */
    protected titlesFailure: string | undefined;

    /** Per-track volume and balance, as set before or during playback. */
    protected readonly volumes = new Map<number, number>();
    protected readonly balances = new Map<number, number>();

    protected context: AudioContext | undefined;
    protected readonly slots = new Map<EsSoundKind, EsSoundSlot>();
    /** Decoded tracks, least recently used first, and those being decoded. */
    protected readonly decoded = new Map<number, EsSoundBuffer>();
    protected readonly decoding = new Map<number, Promise<EsSoundBuffer>>();

    /**
     * Where a video recording listens, when one is running.
     *
     * A second destination beside the speakers rather than in place of them,
     * and in this player's own context — an audio graph cannot reach across
     * contexts, so what leaves here is a `MediaStream` and it is the recorder
     * that mixes it with the emulator's own sound. See
     * {@link EsSoundPlayer.openTap}.
     */
    protected tap: MediaStreamAudioDestinationNode | undefined;

    protected readonly onDidChangeEmitter = new Emitter<void>();
    /** Fires when the files, the history or what is playing change. */
    readonly onDidChange: Event<void> = this.onDidChangeEmitter.event;

    constructor(protected readonly storage: VueportStorage) { }

    get list(): ReadonlyArray<EsSoundTrack> {
        return this.tracks;
    }

    get commands(): ReadonlyArray<EsSoundHistoryEntry> {
        return this.history;
    }

    get isScanned(): boolean {
        return this.scanned;
    }

    /** Where the last scan looked, for the panel to name. */
    get lookedIn(): string | undefined {
        return this.directory;
    }

    /** Why that folder could not be read, when it could not. */
    get scanFailure(): string | undefined {
        return this.failure;
    }

    /** Why the titles file was passed over, for the panel to repeat. */
    get titlesProblem(): string | undefined {
        return this.titlesFailure;
    }

    /** Whether anything is worth watching the port for. */
    get hasTracks(): boolean {
        return this.tracks.length > 0;
    }

    /** The track each slot is playing, for the panel to mark. */
    get playing(): number[] {
        return [...this.slots.values()].map(slot => slot.track);
    }

    /** What each slot is playing, and how far in. */
    get nowPlaying(): EsSoundNowPlaying[] {
        const result: EsSoundNowPlaying[] = [];
        this.slots.forEach(slot => {
            const track = this.tracks.find(candidate => candidate.id === slot.track);
            if (track) {
                result.push({
                    track,
                    position: this.positionOf(slot),
                    loop: slot.loop,
                    manual: slot.manual,
                    waiting: !slot.source || this.context?.state !== 'running',
                });
            }
        });
        return result;
    }

    /**
     * Play a track from the panel, once and from the start, in place of
     * whatever its slot is playing — just as if the game had asked for it.
     */
    audition(id: number): void {
        const track = this.tracks.find(candidate => candidate.id === id);
        if (!track) {
            return;
        }
        this.play(track.id, track.kind, false, 0, true);
        this.applyContextState();
        this.onDidChangeEmitter.fire();
    }

    /**
     * Move a playing track to `seconds` into its music, from the panel.
     *
     * A track still being decoded starts there once it is; one held while
     * the emulator is paused waits there.
     */
    seek(id: number, seconds: number): void {
        const found = [...this.slots.entries()].find(([, candidate]) => candidate.track === id);
        if (!found) {
            return;
        }
        const [kind, slot] = found;
        this.dropSource(slot);
        slot.position = Math.max(0, seconds);
        if (slot.audio && !this.isHeld(slot)) {
            this.startSource(kind, slot, slot.audio);
        }
        this.onDidChangeEmitter.fire();
    }

    /** Stop a track from the panel, whoever started it. */
    stopTrack(id: number): void {
        const kind = esSoundKindOf(id);
        if (kind) {
            this.stop(kind, id);
            this.applyContextState();
            this.onDidChangeEmitter.fire();
        }
    }

    /**
     * Find the audio files beside a ROM.
     *
     * Which files exist is the whole configuration for now: a track id names a
     * file, and a file that is not there is a command that does nothing. A
     * later iteration will take the list from the project instead, and ignore
     * whatever happens to sit next to the ROM.
     */
    async scan(romPath: string): Promise<void> {
        await this.scanDirectory(this.storage.parent(romPath));
    }

    /**
     * The same, for a host that knows the folder rather than a file in it.
     *
     * Which is not always the ROM's own: a browser cannot see the folder a ROM
     * came from, so the tracks that arrive zipped with it are unpacked into
     * the emulator's storage and looked for there. See
     * `EmulatorCompanionFiles.sounds`, which is what decides.
     */
    async scanDirectory(directory: string): Promise<void> {
        this.stopAll();
        this.releaseDecoded();
        this.tracks = [];
        this.directory = directory;
        this.failure = undefined;
        this.titlesFailure = undefined;
        try {
            let titles: string | undefined;
            for (const child of await this.storage.list(directory)) {
                const id = esSoundTrackOf(child.name);
                const kind = id === undefined ? undefined : esSoundKindOf(id);
                if (id !== undefined && kind !== undefined) {
                    this.tracks.push({ id, kind, name: child.name, path: child.path, size: child.size });
                } else if (child.name.toLowerCase() === ES_SOUND_TITLES_FILE) {
                    titles = child.path;
                }
            }
            this.tracks.sort((one, other) => one.id - other.id);
            if (titles) {
                await this.readTitles(titles);
            }
            this.scanned = true;
            this.measure(this.tracks);
        } catch (error) {
            console.warn(`[emulator] could not look for ESSound files in ${directory}:`, error);
            this.failure = String(error);
            this.scanned = true;
        }
        this.onDidChangeEmitter.fire();
    }

    /** Name the tracks `essound.json` has titles for. */
    protected async readTitles(path: string): Promise<void> {
        try {
            const titles = parseEsSoundTitles(await this.storage.readText(path));
            this.tracks.forEach(track => track.title = titles.get(track.id));
        } catch (error) {
            console.warn(`[emulator] could not use ${path}:`, error);
            this.titlesFailure = error instanceof Error ? error.message : String(error);
        }
    }

    /**
     * Read each track's length and title from its headers, one file at a
     * time, behind the scan. Reading is cheap next to decoding, and what is
     * read is let go of at once.
     */
    protected async measure(tracks: EsSoundTrack[]): Promise<void> {
        for (const track of tracks) {
            if (this.tracks !== tracks) {
                return;  // scanned again meanwhile
            }
            if (track.seconds !== undefined) {
                continue;  // decoded already, which is exact
            }
            try {
                const info = esSoundFileInfo(track.kind, await this.storage.read(track.path));
                track.seconds ??= info.seconds;
                track.title ??= info.title;
                this.onDidChangeEmitter.fire();
            } catch (error) {
                console.warn(`[emulator] could not read ESSound file ${track.name}:`, error);
            }
        }
    }

    /**
     * The simulation to listen to, or undefined once it is gone.
     *
     * Watching the port costs the core a callback on every CPU write, so it is
     * only asked for when the ROM has files ESSound could play.
     */
    async setSim(sim: Sim | undefined): Promise<void> {
        this.sim = sim;
        this.stopAll();
        await sim?.setEsSoundCapture(this.hasTracks);
    }

    /** Follows the emulator's own mute, since this plays alongside it. */
    setMuted(muted: boolean): void {
        this.muted = muted;
        this.slots.forEach(slot => this.applyLevels(slot));
    }

    /**
     * Follows the emulator's speed, pitch and all.
     *
     * Fast forward and slow motion change how fast the machine runs, so its
     * own audio comes out higher or lower; a track played at the same rate
     * does the same thing, which is why the pitch is deliberately not
     * preserved. Rates outside what browsers will play are clamped rather
     * than left to silence the track.
     */
    setSpeed(speed: number): void {
        this.speed = Math.min(MAX_PLAYBACK_RATE, Math.max(MIN_PLAYBACK_RATE, speed));
        this.slots.forEach(slot => this.applySpeed(slot));
    }

    /**
     * Follows the emulator's rewind.
     *
     * Audio cannot be played backwards, so the tracks hold while the machine
     * walks back through its history and are then wound back by as much
     * emulated time as it gave up — one seek at the end rather than one per
     * step, since nothing is audible in between and seeking an MP3 sixty
     * times a second is not free.
     */
    setRewinding(rewinding: boolean): void {
        if (this.rewinding === rewinding) {
            return;
        }
        this.rewinding = rewinding;
        if (rewinding) {
            this.rewound = 0;
        } else {
            this.slots.forEach(slot => this.applyPosition(slot, this.rewound));
            this.rewound = 0;
        }
        this.applyContextState();
        this.onDidChangeEmitter.fire();
    }

    /** Emulated seconds the core has just walked back through. */
    rewind(seconds: number): void {
        this.rewound += seconds;
    }

    /**
     * Follows the emulator's own pause, for the same reason.
     *
     * Paused rather than stopped: the track keeps its position, so resuming
     * carries on where the game left off — and a track a paused emulator asks
     * for is made ready but not started, since nothing else about the machine
     * is running either.
     */
    setPaused(paused: boolean): void {
        if (this.paused === paused) {
            return;
        }
        this.paused = paused;
        this.applyContextState();
        this.onDidChangeEmitter.fire();
    }

    /** Whether a track should be running: only when the machine is. */
    protected get running(): boolean {
        return !this.paused && !this.rewinding;
    }

    /** What is playing and at what levels, for a save state to hold. */
    snapshot(): EsSoundSnapshot {
        return {
            playing: [...this.slots.entries()].map(([kind, slot]) => ({
                kind,
                track: slot.track,
                position: this.positionOf(slot),
                loop: slot.loop,
            })),
            volumes: [...this.volumes.entries()],
            balances: [...this.balances.entries()],
        };
    }

    /**
     * Put playback back as a snapshot found it.
     *
     * Restoring a state the game made before a track started is what stops the
     * previous track: everything currently playing goes first, whether or not
     * the snapshot has anything to put in its place.
     */
    restore(snapshot: EsSoundSnapshot): void {
        this.stopAll();
        this.volumes.clear();
        this.balances.clear();
        snapshot.volumes.forEach(([track, volume]) => this.volumes.set(track, volume));
        snapshot.balances.forEach(([track, balance]) => this.balances.set(track, balance));

        snapshot.playing.forEach(entry => this.play(entry.track, entry.kind, entry.loop, entry.position));
        this.onDidChangeEmitter.fire();
    }

    /** Take one halfword the game wrote to the port. */
    handle(raw: number): void {
        const message = decodeEsSoundMessage(raw);
        const problem = this.apply(message);
        this.history.unshift({ time: Date.now(), message, description: describeEsSoundMessage(message), problem });
        this.history = this.history.slice(0, ES_SOUND_HISTORY_LENGTH);
        this.onDidChangeEmitter.fire();
    }

    /** Act on one message, and say why if it could not be acted on. */
    protected apply(message: EsSoundMessage): string | undefined {
        if (message.kind === 'init') {
            // Init resets the levels; the click a real cartridge makes here is
            // hardware behavior rather than something worth reproducing.
            this.stopAll();
            this.volumes.clear();
            this.balances.clear();
            return undefined;
        }
        if (message.kind === 'stopAll') {
            this.stopAll();
            return undefined;
        }

        const kind = esSoundKindOf(message.track);
        if (!kind) {
            return `Track ${message.track} is outside both id ranges`;
        }

        switch (message.command) {
            case EsSoundCommand.PLAY:
            case EsSoundCommand.PLAY_LOOP:
                return this.play(message.track, kind, message.command === EsSoundCommand.PLAY_LOOP);
            case EsSoundCommand.STOP:
                this.stop(kind, message.track);
                return undefined;
            case EsSoundCommand.SET_VOLUME:
                this.volumes.set(message.track, esSoundVolume(message.value));
                this.refresh(message.track);
                this.prepare(message.track);
                return undefined;
            case EsSoundCommand.SET_BALANCE:
                this.balances.set(message.track, esSoundBalance(message.value));
                this.refresh(message.track);
                this.prepare(message.track);
                return undefined;
            default:
                return `Command ${message.command} is not one ESSound defines`;
        }
    }

    /**
     * Start a track on its slot, at `position` seconds into its music.
     *
     * A track not decoded yet starts once it is, from where it was asked to
     * start: late rather than with its beginning cut off.
     */
    protected play(track: number, kind: EsSoundKind, loop: boolean, position = 0, manual = false): string | undefined {
        const found = this.tracks.find(candidate => candidate.id === track);
        if (!found) {
            return `${esSoundFileName(track)} is not beside the ROM`;
        }

        this.stop(kind);
        const context = this.audioContext();
        const slot: EsSoundSlot = {
            track,
            loop,
            manual,
            gain: context.createGain(),
            panner: context.createStereoPanner(),
            position,
            since: context.currentTime,
            rate: this.speed,
        };
        slot.gain.connect(slot.panner).connect(context.destination);
        if (this.tap) {
            slot.panner.connect(this.tap);
        }
        this.slots.set(kind, slot);
        this.applyLevels(slot);

        const ready = this.decoded.get(track);
        if (ready) {
            this.touch(track, ready);
            this.startSource(kind, slot, ready);
            return undefined;
        }
        // Decoding is asynchronous, and the slot may have been taken over by
        // another track by the time it is done.
        this.decode(found).then(audio => {
            if (this.slots.get(kind) === slot) {
                this.startSource(kind, slot, audio);
                this.onDidChangeEmitter.fire();
            }
        }).catch(error => console.warn(`[emulator] ESSound could not decode ${found.name}:`, error));
        return undefined;
    }

    /**
     * Have a track decoded before it is played.
     *
     * A game that sets the levels of a track it is not playing is about to
     * play it — ESSound keeps levels per track for that very use — so this is
     * the moment to decode it: by the time PLAY comes, it starts on the spot.
     */
    protected prepare(track: number): void {
        if ([...this.slots.values()].some(slot => slot.track === track)) {
            return;
        }
        const found = this.tracks.find(candidate => candidate.id === track);
        if (found) {
            this.decode(found).catch(error => console.warn(`[emulator] ESSound could not decode ${found.name}:`, error));
        }
    }

    /** (Re)start a slot's source at the slot's current position. */
    protected startSource(kind: EsSoundKind, slot: EsSoundSlot, audio: EsSoundBuffer): void {
        const context = this.audioContext();
        const position = this.positionOf(slot);
        this.dropSource(slot);
        slot.audio = audio;
        const length = audio.end - audio.start;
        if (!slot.loop && position >= length) {
            this.stop(kind);
            return;
        }
        if (this.isHeld(slot)) {
            return;  // started by applyContextState when it may sound
        }
        const source = context.createBufferSource();
        source.buffer = audio.buffer;
        source.loop = slot.loop;
        source.loopStart = audio.start;
        source.loopEnd = audio.end;
        source.playbackRate.value = this.speed;
        source.connect(slot.gain);
        // A track played once is over when it ends, and the slot with it.
        source.onended = () => {
            if (slot.source === source && this.slots.get(kind) === slot) {
                this.stop(kind);
                this.applyContextState();
                this.onDidChangeEmitter.fire();
            }
        };
        const offset = slot.loop && length > 0 ? position % length : position;
        if (slot.loop) {
            source.start(0, audio.start + offset);
        } else {
            source.start(0, audio.start + offset, length - offset);
        }
        slot.source = source;
        slot.position = offset;
        slot.since = context.currentTime;
        slot.rate = this.speed;
    }

    /**
     * Where a slot is in its music, in seconds.
     *
     * Counted on the context's clock, which stands still while the context is
     * suspended — for a pause or a rewind — just as the track does.
     */
    protected positionOf(slot: EsSoundSlot): number {
        if (!slot.source || !this.context) {
            return slot.position;
        }
        const position = slot.position + (this.context.currentTime - slot.since) * slot.rate;
        const length = slot.audio ? slot.audio.end - slot.audio.start : 0;
        if (length <= 0) {
            return position;
        }
        return slot.loop ? position % length : Math.min(position, length);
    }

    /** Stop a slot, optionally only when it is playing one particular track. */
    protected stop(kind: EsSoundKind, track?: number): void {
        const slot = this.slots.get(kind);
        if (!slot || (track !== undefined && slot.track !== track)) {
            return;
        }
        this.dropSource(slot);
        slot.gain.disconnect();
        slot.panner.disconnect();
        this.slots.delete(kind);
    }

    protected dropSource(slot: EsSoundSlot): void {
        const source = slot.source;
        if (!source) {
            return;
        }
        slot.position = this.positionOf(slot);
        slot.source = undefined;
        source.onended = null;
        try {
            source.stop();
        } catch {
            // Already over.
        }
        source.disconnect();
    }

    protected stopAll(): void {
        [...this.slots.keys()].forEach(kind => this.stop(kind));
        this.onDidChangeEmitter.fire();
    }

    /**
     * Hold the whole audio graph while the machine is held.
     *
     * Suspending the context stops every source where it is and its clock
     * with it, so a pause or a rewind resumes exactly where it left off.
     *
     * Unless a track started from the panel is playing: then the context has
     * to run for it, and the game's tracks are held one by one instead —
     * their sources dropped, keeping the position, and started again when
     * they may sound.
     */
    protected applyContextState(): void {
        if (!this.context) {
            return;
        }
        const audible = this.running || [...this.slots.values()].some(slot => slot.manual);
        this.slots.forEach((slot, kind) => {
            if (this.isHeld(slot)) {
                if (audible) {
                    this.dropSource(slot);
                }
            } else if (!slot.source && slot.audio) {
                this.startSource(kind, slot, slot.audio);
            }
        });
        if (audible) {
            this.context.resume().catch(() => undefined);
        } else {
            this.context.suspend().catch(() => undefined);
        }
    }

    /** Whether a slot has to wait for the machine to run. */
    protected isHeld(slot: EsSoundSlot): boolean {
        return !this.running && !slot.manual;
    }

    protected applySpeed(slot: EsSoundSlot): void {
        if (!slot.source || !this.context) {
            slot.rate = this.speed;
            return;
        }
        // Rebase the clock first, so the position stays right across the change.
        slot.position = this.positionOf(slot);
        slot.since = this.context.currentTime;
        slot.rate = this.speed;
        slot.source.playbackRate.value = this.speed;
    }

    /**
     * Wind one track back, wrapping round rather than sticking at the start
     * when it is looping — a rewind through a loop point should land where the
     * loop actually was.
     */
    protected applyPosition(slot: EsSoundSlot, seconds: number): void {
        if (seconds <= 0) {
            return;
        }
        const length = slot.audio ? slot.audio.end - slot.audio.start : 0;
        let position = this.positionOf(slot) - seconds;
        if (slot.loop && length > 0) {
            position = ((position % length) + length) % length;
        }
        this.dropSource(slot);
        slot.position = Math.max(0, position);
        const kind = [...this.slots.entries()].find(([, candidate]) => candidate === slot)?.[0];
        if (kind && slot.audio) {
            this.startSource(kind, slot, slot.audio);
        }
    }

    /** Push a track's levels to it, if it happens to be the one playing. */
    protected refresh(track: number): void {
        this.slots.forEach(slot => {
            if (slot.track === track) {
                this.applyLevels(slot);
            }
        });
    }

    protected applyLevels(slot: EsSoundSlot): void {
        slot.gain.gain.value = this.muted ? 0 : this.volumes.get(slot.track) ?? DEFAULT_VOLUME;
        slot.panner.pan.value = this.balances.get(slot.track) ?? DEFAULT_BALANCE;
    }

    /**
     * Listen in on what ESSound is playing, for a recording to mix in.
     *
     * The levels the game has set are already in it — the tap hangs off each
     * slot's panner, downstream of the volume and balance the cartridge
     * commands — so what is recorded is what is heard, mute included. Tracks
     * that start later join by themselves.
     *
     * Opening one builds this player's audio context if a game has not played
     * anything yet, so that a recording started before the first sound still
     * has somewhere to take it from.
     */
    openTap(): MediaStream {
        if (!this.tap) {
            this.tap = this.audioContext().createMediaStreamDestination();
            this.slots.forEach(slot => slot.panner.connect(this.tap!));
        }
        return this.tap.stream;
    }

    /** Stop recording ESSound. The speakers are untouched either way. */
    closeTap(): void {
        if (!this.tap) {
            return;
        }
        this.slots.forEach(slot => {
            try {
                slot.panner.disconnect(this.tap!);
            } catch {
                // A slot built before the tap was opened is not connected to
                // it; disconnecting it anyway is not worth checking for.
            }
        });
        this.tap.disconnect();
        this.tap = undefined;
    }

    protected audioContext(): AudioContext {
        if (!this.context) {
            this.context = new AudioContext();
        }
        // A context created before the first gesture starts suspended. One
        // held for a pause stays that way until the pause is over.
        if (this.context.state === 'suspended' && this.running) {
            this.context.resume();
        }
        return this.context;
    }

    /** A track decoded, read and decoded once and kept within the budget. */
    protected decode(track: EsSoundTrack): Promise<EsSoundBuffer> {
        const ready = this.decoded.get(track.id);
        if (ready) {
            this.touch(track.id, ready);
            return Promise.resolve(ready);
        }
        const pending = this.decoding.get(track.id);
        if (pending) {
            return pending;
        }
        const work = (async () => {
            // Copied into an ArrayBuffer of its own: the buffer behind the read
            // may be shared, and decoding takes the one it is given.
            const bytes = new Uint8Array(await this.storage.read(track.path)).slice();
            const gapless = track.kind === 'mp3' ? mp3GaplessInfo(bytes) : undefined;
            const buffer = await this.audioContext().decodeAudioData(bytes.buffer);
            const audible = esSoundAudibleWindow(gapless, buffer.length, buffer.sampleRate);
            track.seconds = audible.end - audible.start;
            return { buffer, start: audible.start, end: audible.end };
        })();
        this.decoding.set(track.id, work);
        work.then(audio => {
            if (this.decoding.get(track.id) === work) {
                this.decoding.delete(track.id);
                this.touch(track.id, audio);
            }
        }, () => this.decoding.delete(track.id));
        return work;
    }

    /** Mark a track used now, and make room by letting go of the oldest. */
    protected touch(id: number, audio: EsSoundBuffer): void {
        this.decoded.delete(id);
        this.decoded.set(id, audio);
        const bytes = (entry: EsSoundBuffer) => entry.buffer.length * entry.buffer.numberOfChannels * 4;
        let total = 0;
        this.decoded.forEach(entry => total += bytes(entry));
        const playing = new Set([...this.slots.values()].map(slot => slot.track));
        for (const [other, entry] of this.decoded) {
            if (total <= DECODED_BUDGET) {
                break;
            }
            if (other !== id && !playing.has(other)) {
                this.decoded.delete(other);
                total -= bytes(entry);
            }
        }
    }

    protected releaseDecoded(): void {
        this.decoded.clear();
        this.decoding.clear();
    }

    dispose(): void {
        this.closeTap();
        this.stopAll();
        this.releaseDecoded();
        this.context?.close();
        this.onDidChangeEmitter.dispose();
    }
}
