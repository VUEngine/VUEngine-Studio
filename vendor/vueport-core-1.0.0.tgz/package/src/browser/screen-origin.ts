/**
 * Where the page is on the display, for a host that knows better than the page does. The interleaved rendering
 * modes need the display line the picture starts on (see DisplayOutput); a page only knows its window position in
 * whole CSS pixels, which at 125 or 150 % scaling is a line off at some places. A host with a native side, such
 * as the desktop application, can hand in the exact answer here.
 */
import { Disposable, Emitter, Event } from '../common/emulator-events';

export interface ScreenOriginSource {
    // in physical pixels of the display; undefined while not known
    origin(): { x: number, y: number } | undefined;
    readonly onDidChange: Event<void>;
}

let current: ScreenOriginSource | undefined;
let subscription: Disposable | undefined;
const changed = new Emitter<void>();

// hand in a better answer than the page's own, or take it away again
export function setScreenOriginSource(source: ScreenOriginSource | undefined): void {
    subscription?.dispose();
    current = source;
    subscription = source?.onDidChange(() => changed.fire());
    changed.fire();
}

export function screenOrigin(): { x: number, y: number } | undefined {
    return current?.origin();
}

export const onDidChangeScreenOrigin: Event<void> = changed.event;
