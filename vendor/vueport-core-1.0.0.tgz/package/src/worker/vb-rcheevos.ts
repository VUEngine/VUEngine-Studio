/**
 * The RetroAchievements engine, hosted in the emulator worker.
 *
 * Evaluating an achievement set means reading the machine's memory synchronously
 * once per emulated frame, and the worker is the only place that read is
 * synchronous — from the DOM it is a message round trip. So rcheevos runs here,
 * as a second WebAssembly module beside the core, talking to a thin C shim
 * (`../../wasm/rcheevos/shim/vueport-rc.c`) that flattens `rc_client` to functions with
 * only primitive parameters.
 *
 * This module never makes a network request. `rc_client` asks for one through
 * the shim's `vrc_server_call`, which becomes a `serverCall` event; the DOM
 * side makes the call (only the desktop shell can reach the RetroAchievements
 * API) and feeds the answer back with `raProvideResponse`.
 *
 * The rcheevos glue (`rcheevos.js` + `rcheevos.wasm`) is loaded lazily with
 * `importScripts` on the first login, and its absence is not an error: a build
 * that ships neither reports `engineUnavailable` and the panel says so, exactly
 * as the browser reports it cannot reach the API.
 */

import { VbDataType, VB_CART_RAM_BASE, VB_WRAM_BASE } from '../common/vb-constants';
import { VesRaEvent, VesRaLeaderboardEntries, VesRaUser } from '../common/vb-protocol';
import { WasmExports } from './vb-wasm';

/**
 * The Emscripten factory `rcheevos.js` defines on the worker global once
 * `importScripts` has run it. Only what this file touches is described.
 */
interface RcModuleFactory {
    (options?: Record<string, unknown>): Promise<RcModule>;
}

/** The bits of the worker global this file reaches for. */
interface RcWorkerScope {
    importScripts(...urls: string[]): void;
    createVueportRc?: RcModuleFactory;
}

interface RcModule {
    HEAPU8: Uint8Array;
    _malloc(size: number): number;
    _free(pointer: number): void;
    stringToUTF8(text: string, pointer: number, maxBytes: number): void;
    lengthBytesUTF8(text: string): number;

    /** Hooks the `--js-library` glue calls back into; we set these. */
    vrcReadMemory(address: number, buffer: number, length: number): number;
    vrcServerCall(
        requestId: number,
        method: string,
        url: string,
        post: string | undefined,
        contentType: string | undefined,
    ): void;
    vrcEmit(json: string): void;

    // --- the shim's exports ------------------------------------------------
    _vrc_create(): number;
    _vrc_destroy(client: number): void;
    _vrc_begin_login_password(client: number, username: number, password: number): void;
    _vrc_begin_login_token(client: number, username: number, token: number): void;
    _vrc_logout(client: number): void;
    _vrc_begin_load_game(client: number, hash: number): void;
    _vrc_unload_game(client: number): void;
    _vrc_reset(client: number): void;
    /**
     * Absent from a `rcheevos.wasm` built before this export was added — the
     * committed artifact until `build.mjs` is rerun — so every call is guarded
     * with a `typeof` check. Missing, the client stays in its `vrc_create`
     * default (softcore), which is the safe side to fail to.
     */
    _vrc_set_hardcore?(client: number, enabled: number): void;
    _vrc_do_frame(client: number): void;
    _vrc_idle(client: number): void;
    _vrc_provide_response(requestId: number, status: number, body: number): void;
    /**
     * Absent from an `rcheevos.wasm` built before leaderboards were added,
     * and guarded the same way `_vrc_set_hardcore` is. It doubles as the test
     * for whether this engine emits leaderboards at all — both come from the
     * same build — so a stale one is reported rather than leaving the panel
     * waiting forever on a list that is never coming.
     */
    _vrc_begin_fetch_leaderboard_entries?(
        client: number,
        fetchId: number,
        leaderboardId: number,
        firstEntry: number,
        count: number,
        aroundUser: number,
    ): void;
}

/** One in-flight `rc_client` request, kept so its answer can be routed back. */
interface PendingLogin {
    resolve: (user: VesRaUser) => void;
    reject: (error: Error) => void;
}

/** The same, for one outstanding page of leaderboard entries. */
interface PendingEntries {
    resolve: (entries: VesRaLeaderboardEntries) => void;
    reject: (error: Error) => void;
}

/**
 * The most entries one request may ask for.
 *
 * The shim writes an answer into a fixed 64 KB buffer and stops rather than
 * overflowing it, so the two ends have to agree on a ceiling; a hundred rows
 * of username, value and avatar URL fit inside it several times over, and no
 * page the panel shows comes near a hundred anyway.
 */
const VRC_MAX_ENTRIES = 100;

export class RetroAchievements {

    protected module: RcModule | undefined;
    protected client = 0;
    /** Set once loading has been tried, so a failed load is not retried forever. */
    protected loadAttempted = false;
    protected unavailableReason: string | undefined;

    /** Events waiting for the drive loop to flush them to the DOM. */
    protected readonly outbox: VesRaEvent[] = [];

    /** How the current session reads the machine's memory, or undefined when detached. */
    protected read: ((address: number) => number) | undefined;

    protected pendingLogin: PendingLogin | undefined;

    /** Outstanding {@link fetchLeaderboardEntries} calls, by the id sent to the shim. */
    protected readonly pendingEntries = new Map<number, PendingEntries>();
    protected nextFetchId = 1;

    /**
     * Told about every event the moment it is queued, so the worker can flush
     * it straight to the DOM instead of waiting for the next frame.
     *
     * Needed because a `serverCall` for login or a set load is queued by the
     * shim synchronously, but frames — the only other thing that flushes the
     * outbox — stop while the emulator is paused, e.g. behind the settings
     * dialog. Without this, signing in mid-session while paused hung forever:
     * the request never left the worker for the DOM to answer.
     */
    onPush: (() => void) | undefined;

    /** Whether a set is loaded and `doFrame` should be doing work. */
    protected gameLoaded = false;
    protected idleCountdown = 0;

    /**
     * The hardcore flag the DOM last asked for, remembered so it can be
     * applied to a client that does not exist yet — `setHardcore` is called
     * before the first login on a fresh session, which is what creates it.
     */
    protected hardcore = false;
    /** So the "engine too old for hardcore" warning is logged at most once. */
    protected warnedNoHardcoreExport = false;

    constructor(protected readonly moduleUrl: string | undefined) { }

    /**
     * Point the engine at a running simulation.
     *
     * `wasm` and `simPointer` belong to the main simulation only — never the
     * profile replay's scratch simulation or a linked peer, which must not feed
     * the achievement client.
     */
    attach(wasm: WasmExports, simPointer: number): void {
        this.read = address => wasm.vbRead(simPointer, address >>> 0, VbDataType.U8) & 0xff;
    }

    /** Stop reading a simulation that is going away, and drop any loaded set. */
    detach(): void {
        this.read = undefined;
        if (this.client && this.module && this.gameLoaded) {
            this.module._vrc_unload_game(this.client);
        }
        this.gameLoaded = false;
    }

    /** Events accumulated since the last call; the worker flushes these. */
    takeEvents(): VesRaEvent[] {
        if (this.outbox.length === 0) {
            return [];
        }
        return this.outbox.splice(0, this.outbox.length);
    }

    // --- Commands ---------------------------------------------------------

    async loginPassword(username: string, password: string): Promise<VesRaUser> {
        return this.login(client => this.withStrings([username, password],
            ([u, p]) => this.module!._vrc_begin_login_password(client, u, p)));
    }

    async loginToken(username: string, token: string): Promise<VesRaUser> {
        return this.login(client => this.withStrings([username, token],
            ([u, t]) => this.module!._vrc_begin_login_token(client, u, t)));
    }

    logout(): void {
        if (this.client && this.module) {
            this.module._vrc_logout(this.client);
        }
        this.gameLoaded = false;
        this.failPendingEntries('Signed out of RetroAchievements.');
    }

    async loadGame(hash: string): Promise<void> {
        if (!await this.ensureLoaded() || !this.client || !this.module) {
            this.push({ kind: 'gameLoaded', game: undefined, reason: this.unavailableReason ?? 'unavailable' });
            return;
        }
        this.withStrings([hash], ([h]) => this.module!._vrc_begin_load_game(this.client, h));
    }

    unloadGame(): void {
        if (this.client && this.module && this.gameLoaded) {
            this.module._vrc_unload_game(this.client);
        }
        this.gameLoaded = false;
        this.failPendingEntries('The game was unloaded.');
    }

    /**
     * Ask RetroAchievements for one page of a leaderboard's entries.
     *
     * Answered by the `lbentries` message the shim emits for this request's
     * own id, so several pages can be in flight without confusing one for
     * another — a "top of the board" and an "around me" request, say, which
     * the panel makes together.
     */
    async fetchLeaderboardEntries(
        leaderboardId: number, firstEntry: number, count: number, aroundUser: boolean,
    ): Promise<VesRaLeaderboardEntries> {
        if (!await this.ensureLoaded() || !this.client || !this.module) {
            throw new Error(this.unavailableReason ?? 'The RetroAchievements engine is unavailable.');
        }
        const begin = this.module._vrc_begin_fetch_leaderboard_entries;
        if (typeof begin !== 'function') {
            throw new Error(this.staleEngineMessage());
        }
        const fetchId = this.nextFetchId++;
        return new Promise<VesRaLeaderboardEntries>((resolve, reject) => {
            this.pendingEntries.set(fetchId, { resolve, reject });
            try {
                begin(
                    this.client,
                    fetchId,
                    leaderboardId,
                    Math.max(1, Math.floor(firstEntry)),
                    Math.min(VRC_MAX_ENTRIES, Math.max(1, Math.floor(count))),
                    aroundUser ? 1 : 0,
                );
            } catch (error) {
                this.pendingEntries.delete(fetchId);
                reject(error instanceof Error ? error : new Error(String(error)));
            }
        });
    }

    /**
     * Give up on every outstanding page. rc_client answers its own callbacks
     * even when a request fails, so this is for the cases where it never gets
     * the chance — a logout, an unload, or the whole module going away.
     */
    protected failPendingEntries(reason: string): void {
        const pending = [...this.pendingEntries.values()];
        this.pendingEntries.clear();
        for (const entry of pending) {
            entry.reject(new Error(reason));
        }
    }

    /** What to say when this `rcheevos.wasm` predates the export being reached for. */
    protected staleEngineMessage(): string {
        return 'This RetroAchievements engine has no leaderboard support; '
            + 'rerun packages/core/wasm/rcheevos/build.mjs.';
    }

    reset(): void {
        if (this.client && this.module) {
            this.module._vrc_reset(this.client);
        }
    }

    /**
     * Set the engine's hardcore flag. Kept even when there is no client yet,
     * so `applyHardcore` can arm the one `ensureLoaded` goes on to create.
     */
    setHardcore(enabled: boolean): void {
        this.hardcore = enabled;
        this.applyHardcore();
    }

    protected applyHardcore(): void {
        if (!this.client || !this.module) {
            return;
        }
        const set = this.module._vrc_set_hardcore;
        if (typeof set !== 'function') {
            if (this.hardcore && !this.warnedNoHardcoreExport) {
                this.warnedNoHardcoreExport = true;
                console.warn(
                    '[rcheevos] this rcheevos.wasm has no _vrc_set_hardcore export; '
                    + 'rerun packages/core/wasm/rcheevos/build.mjs to enable hardcore mode.');
            }
            return;
        }
        set(this.client, this.hardcore ? 1 : 0);
    }

    provideResponse(requestId: number, status: number, body: string): void {
        if (!this.client || !this.module) {
            return;
        }
        this.withStrings([body], ([b]) => this.module!._vrc_provide_response(requestId, status, b));
    }

    /**
     * Advance the achievement client by one emulated frame.
     *
     * Called from the drive loop at the same frame break `applyCheats` runs at,
     * for the attached simulation only. Cheap when no set is loaded.
     */
    doFrame(): void {
        if (!this.gameLoaded || !this.client || !this.module || !this.read) {
            return;
        }
        this.module._vrc_do_frame(this.client);
        // rc_client schedules its own work (the rich-presence ping, retries);
        // `idle` is how it gets a turn. Once a second is plenty.
        if (--this.idleCountdown <= 0) {
            this.idleCountdown = 50;
            this.module._vrc_idle(this.client);
        }
    }

    // --- Loading --------------------------------------------------------

    protected async ensureLoaded(): Promise<boolean> {
        if (this.module) {
            return true;
        }
        if (this.loadAttempted) {
            return false;
        }
        this.loadAttempted = true;

        if (!this.moduleUrl) {
            this.markUnavailable('This build ships no RetroAchievements engine.');
            return false;
        }

        try {
            // Loaded with `importScripts`, not `import()`: this is a classic
            // worker, and `tsc`'s CommonJS output turns `import()` into a
            // `require()` that throws in a browser. `rcheevos.js` is Emscripten
            // glue served beside the worker (see `main.tsx` for the URL, which
            // is build configuration, not user input) and defines the factory
            // `createVueportRc` on the worker global.
            const scope = self as unknown as RcWorkerScope;
            const url = this.moduleUrl;
            scope.importScripts(url);
            const factory = scope.createVueportRc;
            if (!factory) {
                this.markUnavailable('The RetroAchievements engine script defined nothing.');
                return false;
            }
            const wasmUrl = url.replace(/\.js$/, '.wasm');
            const module = await factory({
                locateFile: (path: string) => (path.endsWith('.wasm') ? wasmUrl : path),
            });

            module.vrcReadMemory = (address, buffer, length) => this.onReadMemory(address, buffer, length);
            module.vrcServerCall = (id, method, requestUrl, post, contentType) =>
                this.push({
                    kind: 'serverCall',
                    requestId: id,
                    method: method === 'POST' ? 'POST' : 'GET',
                    url: requestUrl,
                    body: post,
                    contentType,
                });
            module.vrcEmit = json => this.onEmit(json);

            this.module = module;
            this.client = module._vrc_create();
            if (!this.client) {
                this.markUnavailable('The RetroAchievements engine could not start.');
                this.module = undefined;
                return false;
            }
            // The client is fresh from `vrc_create`, which leaves it softcore;
            // carry over whatever the DOM asked for before it existed.
            this.applyHardcore();
            return true;
        } catch (error) {
            this.markUnavailable(error instanceof Error ? error.message : String(error));
            return false;
        }
    }

    protected markUnavailable(reason: string): void {
        this.unavailableReason = reason;
        this.push({ kind: 'engineUnavailable', reason });
    }

    protected async login(begin: (client: number) => void): Promise<VesRaUser> {
        if (!await this.ensureLoaded() || !this.client) {
            throw new Error(this.unavailableReason ?? 'The RetroAchievements engine is unavailable.');
        }
        if (this.pendingLogin) {
            throw new Error('A RetroAchievements login is already in progress.');
        }
        return new Promise<VesRaUser>((resolve, reject) => {
            this.pendingLogin = { resolve, reject };
            try {
                begin(this.client);
            } catch (error) {
                this.pendingLogin = undefined;
                reject(error instanceof Error ? error : new Error(String(error)));
            }
        });
    }

    // --- Callbacks from the shim ---------------------------------------

    protected onReadMemory(address: number, buffer: number, length: number): number {
        if (!this.read || !this.module) {
            return 0;
        }
        const real = this.toRealAddress(address >>> 0);
        if (real === undefined) {
            return 0;
        }
        const heap = this.module.HEAPU8;
        for (let i = 0; i < length; i++) {
            const next = this.toRealAddress((address + i) >>> 0);
            if (next === undefined) {
                return i;
            }
            heap[buffer + i] = this.read(next);
        }
        return length;
    }

    /**
     * RetroAchievements' Virtual Boy address space is two regions: `0x000000`
     * onward is WRAM, `0x010000` onward is cartridge RAM. Anything past that is
     * not addressable and reads as nothing.
     */
    protected toRealAddress(raAddress: number): number | undefined {
        if (raAddress < 0x10000) {
            return (VB_WRAM_BASE + raAddress) >>> 0;
        }
        if (raAddress < 0x20000) {
            return (VB_CART_RAM_BASE + (raAddress - 0x10000)) >>> 0;
        }
        return undefined;
    }

    protected onEmit(json: string): void {
        let message: Record<string, unknown>;
        try {
            message = JSON.parse(json) as Record<string, unknown>;
        } catch {
            return;
        }

        switch (message.t) {
            case 'login': {
                const pending = this.pendingLogin;
                this.pendingLogin = undefined;
                if (!pending) {
                    return;
                }
                if (message.ok && message.user) {
                    const u = message.user as Record<string, unknown>;
                    pending.resolve({
                        username: String(u.username ?? ''),
                        displayName: String(u.display ?? u.username ?? ''),
                        token: String(u.token ?? ''),
                        score: Number(u.score ?? 0),
                        softcoreScore: Number(u.softcore ?? 0),
                        avatarUrl: typeof u.avatar === 'string' ? u.avatar : undefined,
                    });
                } else {
                    pending.reject(new Error(String(message.err ?? 'RetroAchievements refused the login.')));
                }
                return;
            }
            case 'load': {
                this.gameLoaded = Boolean(message.ok && message.game);
                this.idleCountdown = 0;
                // An engine too old to emit a leaderboard list will never send
                // one, so say so here rather than leaving the panel waiting.
                if (this.gameLoaded && typeof this.module?._vrc_begin_fetch_leaderboard_entries !== 'function') {
                    this.push({ kind: 'leaderboards', leaderboards: [], reason: this.staleEngineMessage() });
                }
                const game = message.game as Record<string, unknown> | undefined;
                this.push({
                    kind: 'gameLoaded',
                    game: this.gameLoaded && game ? {
                        id: Number(game.id ?? 0),
                        title: String(game.title ?? ''),
                        iconUrl: String(game.icon ?? ''),
                        achievementCount: Number(game.count ?? 0),
                        pointsTotal: Number(game.points ?? 0),
                    } : undefined,
                    reason: message.ok ? undefined : String(message.err ?? 'not recognized'),
                });
                return;
            }
            case 'achlist': {
                const list = Array.isArray(message.achievements) ? message.achievements : [];
                this.push({
                    kind: 'achievements',
                    achievements: list.map(raw => {
                        const a = raw as Record<string, unknown>;
                        const measured = a.measured as Record<string, unknown> | undefined;
                        // The shim only sends `type` for the three rc_client calls
                        // out (1 missable, 2 progression, 3 win) — an ordinary
                        // achievement (0, or the field left out entirely) has none.
                        const type = a.type === 1 ? 'missable' : a.type === 2 ? 'progression'
                            : a.type === 3 ? 'win' : undefined;
                        return {
                            id: Number(a.id ?? 0),
                            title: String(a.title ?? ''),
                            description: String(a.desc ?? ''),
                            points: Number(a.points ?? 0),
                            badgeUrl: String(a.badge ?? ''),
                            state: a.state === 'unlocked' ? 'unlocked'
                                : a.state === 'unsupported' ? 'unsupported' : 'locked',
                            unlockedHardcore: Boolean(a.hardcore),
                            bucket: Number(a.bucket ?? 0),
                            measured: measured ? {
                                percent: Number(measured.percent ?? 0),
                                display: String(measured.display ?? ''),
                            } : undefined,
                            type,
                            rarity: typeof a.rarity === 'number' ? a.rarity : undefined,
                            rarityHardcore: typeof a.rarityHardcore === 'number' ? a.rarityHardcore : undefined,
                            unlockTime: typeof a.unlockTime === 'number' ? a.unlockTime : undefined,
                        };
                    }),
                });
                return;
            }
            case 'unlock': {
                this.push({
                    kind: 'unlocked',
                    id: Number(message.id ?? 0),
                    title: String(message.title ?? ''),
                    description: String(message.desc ?? ''),
                    points: Number(message.points ?? 0),
                    badgeUrl: String(message.badge ?? ''),
                    hardcore: Boolean(message.hardcore),
                });
                return;
            }
            case 'challenge': {
                this.push({
                    kind: 'challengeIndicator',
                    id: Number(message.id ?? 0),
                    show: Boolean(message.show),
                    badgeUrl: String(message.badge ?? ''),
                });
                return;
            }
            case 'conn': {
                this.push({ kind: 'connection', online: Boolean(message.online) });
                return;
            }
            case 'lblist': {
                const list = Array.isArray(message.leaderboards) ? message.leaderboards : [];
                this.push({
                    kind: 'leaderboards',
                    leaderboards: list.map(raw => {
                        const l = raw as Record<string, unknown>;
                        return {
                            id: Number(l.id ?? 0),
                            title: String(l.title ?? ''),
                            description: String(l.desc ?? ''),
                            format: l.format === 'time' ? 'time' as const
                                : l.format === 'value' ? 'value' as const : 'score' as const,
                            lowerIsBetter: Boolean(l.lower),
                            state: l.state === 'active' ? 'active' as const
                                : l.state === 'tracking' ? 'tracking' as const
                                    : l.state === 'unsupported' ? 'unsupported' as const
                                        : 'inactive' as const,
                            value: typeof l.value === 'string' ? l.value : undefined,
                        };
                    }),
                });
                return;
            }
            case 'lbattempt': {
                this.push({
                    kind: 'leaderboardAttempt',
                    id: Number(message.id ?? 0),
                    title: String(message.title ?? ''),
                    description: String(message.desc ?? ''),
                    state: message.state === 'started' ? 'started'
                        : message.state === 'failed' ? 'failed' : 'submitted',
                    value: typeof message.value === 'string' ? message.value : undefined,
                });
                return;
            }
            case 'lbtrack': {
                this.push({
                    kind: 'leaderboardTracker',
                    trackerId: Number(message.id ?? 0),
                    show: Boolean(message.show),
                    display: String(message.display ?? ''),
                });
                return;
            }
            case 'lbboard': {
                const top = Array.isArray(message.top) ? message.top : [];
                this.push({
                    kind: 'leaderboardScoreboard',
                    id: Number(message.id ?? 0),
                    submittedScore: String(message.submitted ?? ''),
                    bestScore: String(message.best ?? ''),
                    rank: Number(message.rank ?? 0),
                    total: Number(message.total ?? 0),
                    topEntries: top.map(raw => {
                        const e = raw as Record<string, unknown>;
                        return {
                            rank: Number(e.rank ?? 0),
                            user: String(e.user ?? ''),
                            score: String(e.score ?? ''),
                        };
                    }),
                });
                return;
            }
            case 'lbentries': {
                // Settles one `fetchLeaderboardEntries`, so it resolves a
                // promise rather than becoming an event — the same as `login`.
                const pending = this.pendingEntries.get(Number(message.fetch ?? 0));
                if (!pending) {
                    return;
                }
                this.pendingEntries.delete(Number(message.fetch ?? 0));
                if (!message.ok) {
                    pending.reject(new Error(String(
                        message.err ?? 'RetroAchievements did not answer with this leaderboard.')));
                    return;
                }
                const rows = Array.isArray(message.entries) ? message.entries : [];
                pending.resolve({
                    total: Number(message.total ?? 0),
                    userIndex: Number(message.userIndex ?? -1),
                    entries: rows.map(raw => {
                        const e = raw as Record<string, unknown>;
                        return {
                            rank: Number(e.rank ?? 0),
                            user: String(e.user ?? ''),
                            display: String(e.display ?? ''),
                            submitted: Number(e.submitted ?? 0),
                            avatarUrl: typeof e.avatar === 'string' ? e.avatar : undefined,
                        };
                    }),
                });
                return;
            }
        }
    }

    // --- Helpers -------------------------------------------------------

    protected push(event: VesRaEvent): void {
        this.outbox.push(event);
        // A tracker update is the one event that arrives every frame, and it
        // only ever arrives from `doFrame` — which is only reached from the
        // drive loop and from `stepFrame`, both of which flush the outbox
        // when they are done. Waking the worker for each one individually
        // would turn a running attempt into a message per frame for no gain;
        // everything else here is rare enough that going straight out is
        // exactly what is wanted (see `onPush`).
        if (event.kind !== 'leaderboardTracker') {
            this.onPush?.();
        }
    }

    /**
     * Copy strings into the rcheevos heap for the duration of one synchronous
     * call, then free them. Every shim entry point that takes text follows this
     * pattern.
     */
    protected withStrings<T>(texts: string[], use: (pointers: number[]) => T): T {
        if (!this.module) {
            throw new Error('The RetroAchievements engine is not loaded.');
        }
        const module = this.module;
        const pointers = texts.map(text => {
            const size = module.lengthBytesUTF8(text) + 1;
            const pointer = module._malloc(size);
            module.stringToUTF8(text, pointer, size);
            return pointer;
        });
        try {
            return use(pointers);
        } finally {
            for (const pointer of pointers) {
                module._free(pointer);
            }
        }
    }

    dispose(): void {
        if (this.client && this.module) {
            this.module._vrc_destroy(this.client);
        }
        this.client = 0;
        this.module = undefined;
        this.read = undefined;
        this.pendingLogin?.reject(new Error('The emulator core has been disposed.'));
        this.pendingLogin = undefined;
        this.failPendingEntries('The emulator core has been disposed.');
    }
}
