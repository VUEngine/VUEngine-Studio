/**
 * The frames shown before the current one, for a screenshot that blends.
 *
 * The live renderer keeps its own frames before, as textures in its own
 * context — which nothing else can read. A screenshot composed to settings of
 * its own is drawn by a second renderer, and to blend it needs the same frames
 * the picture on screen was made of: the one before for `full`, and the two
 * before that too for `smart`, which compares them. So every presented frame
 * is also copied here, following the renderer's rules for what counts as the
 * frame before: see `FrameKind`.
 *
 * Four buffers that take turns, like the renderer's textures; a present costs
 * one copy of a 344 KB frame.
 */

import { Frame, FrameKind } from '../common/vb-protocol';
import {
    FrameBlending,
    VB_SCREEN_HEIGHT,
    VB_SCREEN_WIDTH,
    VBC_FRAME_BYTES,
    vbFrameBytes,
} from '../common/vb-constants';

/** Room for the larger of the two transports; a legacy frame uses the first part. */
const FRAME_BYTES = VBC_FRAME_BYTES;

/** How far flicker reaches into the pixels around it; the renderer's MASK_REACH. */
const MASK_REACH = 2;

/** The cells flicker is also counted in, and how much of one must flicker; the renderer's. */
const MASK_BLOCK = 8;
const MASK_BLOCK_SHARE = (MASK_BLOCK * MASK_BLOCK) / 2;
const MASK_BLOCKS_X = VB_SCREEN_WIDTH / MASK_BLOCK;
const MASK_BLOCKS_Y = VB_SCREEN_HEIGHT / MASK_BLOCK;

const PIXELS = VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT;

/**
 * Two 8-bit sRGB values mixed half and half in linear light, indexed by
 * `a << 8 | b` — the renderer's blend, done once per pair rather than per
 * pixel. Built on first use.
 */
let halfMix: Uint8Array | undefined;

function mixTable(): Uint8Array {
    if (!halfMix) {
        const linear = new Float64Array(256);
        for (let i = 0; i < 256; i++) {
            const c = i / 255;
            linear[i] = c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
        }
        halfMix = new Uint8Array(256 * 256);
        for (let a = 0; a < 256; a++) {
            for (let b = 0; b < 256; b++) {
                const l = (linear[a] + linear[b]) / 2;
                const c = l <= 0.0031308 ? l * 12.92 : 1.055 * Math.pow(l, 1 / 2.4) - 0.055;
                halfMix[(a << 8) | b] = Math.round(Math.min(1, Math.max(0, c)) * 255);
            }
        }
    }
    return halfMix;
}

/** A frame held here, valid until the next `record`. */
export interface HeldFrame {
    pixels: Uint8Array;
    colorMode: boolean;
}

export class FrameHistory {
    protected current = new Uint8Array(FRAME_BYTES);
    protected before = new Uint8Array(FRAME_BYTES);
    protected earlier = new Uint8Array(FRAME_BYTES);
    protected earliest = new Uint8Array(FRAME_BYTES);
    protected currentColorMode = false;
    protected beforeColorMode = false;
    protected earlierColorMode = false;
    protected earliestColorMode = false;
    protected hasCurrent = false;
    protected hasBefore = false;
    protected hasEarlier = false;
    protected hasEarliest = false;
    /** The current frame as blending shows it; see `blendedCurrent`. */
    protected blended = new Uint8Array(FRAME_BYTES);
    /** Per pixel, bit 0 where the left eye's picture flickers, bit 1 the right's. */
    protected flicker = new Uint8Array(PIXELS);
    protected flickerSpread = new Uint8Array(PIXELS);
    /** Per cell, the same bits where most of it flickers. */
    protected flickerBlocks = new Uint8Array(MASK_BLOCKS_X * MASK_BLOCKS_Y);

    record(pixels: Uint8Array, colorMode: boolean, kind: FrameKind): void {
        if (kind === 'next' && this.hasCurrent) {
            [this.current, this.before, this.earlier, this.earliest] =
                [this.earliest, this.current, this.before, this.earlier];
            this.earliestColorMode = this.earlierColorMode;
            this.hasEarliest = this.hasEarlier;
            this.earlierColorMode = this.beforeColorMode;
            this.hasEarlier = this.hasBefore;
            this.beforeColorMode = this.currentColorMode;
            this.hasBefore = true;
        } else if (kind === 'jump') {
            this.hasBefore = false;
            this.hasEarlier = false;
            this.hasEarliest = false;
        }
        this.current.set(pixels);
        this.currentColorMode = colorMode;
        this.hasCurrent = true;
    }

    /** Copies of the frames before the current one, the most recent first. */
    previous(): Frame[] {
        return this.peekPrevious().map(frame => ({ pixels: frame.pixels.slice().buffer, colorMode: frame.colorMode }));
    }

    /** The frames before the current one, the most recent first, without copying. */
    peekPrevious(): HeldFrame[] {
        const frames: HeldFrame[] = [];
        if (this.hasBefore) {
            frames.push({ pixels: this.before, colorMode: this.beforeColorMode });
            if (this.hasEarlier) {
                frames.push({ pixels: this.earlier, colorMode: this.earlierColorMode });
                if (this.hasEarliest) {
                    frames.push({ pixels: this.earliest, colorMode: this.earliestColorMode });
                }
            }
        }
        return frames;
    }

    /**
     * The current frame mixed with the one before the way the renderer's
     * frame blending shows it, for what reads the picture on this side rather
     * than off the screen: the immersion halo. Without it the halo is made
     * from the raw frame, and anything drawn on alternate frames comes and
     * goes in it while the picture holds it steady.
     *
     * Same rules as the renderer — `full` everywhere, `smart` only where a
     * pixel goes A, B, A in this frame or the one before, widened by
     * MASK_REACH and by the cells that mostly do — with two differences that do
     * not matter to something blurred this far: legacy frames mix each eye's
     * brightness rather than its palette color, and frames in different
     * transports are not mixed at all.
     */
    blendedCurrent(blending: FrameBlending): HeldFrame | undefined {
        if (!this.hasCurrent) {
            return undefined;
        }
        const colorMode = this.currentColorMode;
        const current: HeldFrame = { pixels: this.current, colorMode };
        if (blending === FrameBlending.OFF || !this.hasBefore || this.beforeColorMode !== colorMode) {
            return current;
        }
        const smart = blending === FrameBlending.SMART;
        if (smart && (!this.hasEarlier || this.earlierColorMode !== colorMode)) {
            return current;
        }

        const now = this.current;
        const before = this.before;
        const out = this.blended;
        const bytes = vbFrameBytes(colorMode);
        out.set(now.subarray(0, bytes));
        const mix = mixTable();
        // Where each eye's pixel sits: legacy frames carry the left eye in the
        // red byte and the right in the green; VBC frames the left eye's RGB
        // in the left half of each row and the right eye's in the right.
        const rowStride = (colorMode ? VB_SCREEN_WIDTH * 2 : VB_SCREEN_WIDTH) * 4;
        const rightOffset = colorMode ? VB_SCREEN_WIDTH * 4 : 1;
        const channels = colorMode ? 3 : 1;

        const mask = smart ? this.flickerMask(rowStride, rightOffset, channels) : undefined;
        for (let y = 0; y < VB_SCREEN_HEIGHT; y++) {
            for (let x = 0; x < VB_SCREEN_WIDTH; x++) {
                const bits = mask ? mask[y * VB_SCREEN_WIDTH + x] : 3;
                if (bits === 0) {
                    continue;
                }
                const at = y * rowStride + x * 4;
                for (let eye = 0; eye < 2; eye++) {
                    if ((bits & (1 << eye)) === 0) {
                        continue;
                    }
                    const from = at + (eye === 0 ? 0 : rightOffset);
                    for (let c = 0; c < channels; c++) {
                        out[from + c] = mix[(now[from + c] << 8) | before[from + c]];
                    }
                }
            }
        }
        return { pixels: out, colorMode };
    }

    /** The renderer's RAW_SHADER, BLOCK_SHADER and MASK_SHADER, over the frames held here. */
    protected flickerMask(rowStride: number, rightOffset: number, channels: number): Uint8Array {
        const now = this.current;
        const before = this.before;
        const earlier = this.earlier;
        const earliest = this.hasEarliest && this.earliestColorMode === this.currentColorMode
            ? this.earliest
            : undefined;
        const flicker = this.flicker;
        // A, B, A over three frames, the latest first.
        const alternates = (a: Uint8Array, b: Uint8Array, c: Uint8Array, from: number): boolean => {
            let back = true;
            let change = false;
            for (let i = 0; i < channels; i++) {
                back &&= a[from + i] === c[from + i];
                change ||= a[from + i] !== b[from + i];
            }
            return back && change;
        };
        const flickers = (from: number): boolean => alternates(now, before, earlier, from)
            || (earliest !== undefined && alternates(before, earlier, earliest, from));
        for (let y = 0; y < VB_SCREEN_HEIGHT; y++) {
            for (let x = 0; x < VB_SCREEN_WIDTH; x++) {
                const at = y * rowStride + x * 4;
                flicker[y * VB_SCREEN_WIDTH + x] =
                    (flickers(at) ? 1 : 0) | (flickers(at + rightOffset) ? 2 : 0);
            }
        }

        // The cells where most pixels flicker, before the pixels are widened.
        const blocks = this.flickerBlocks;
        for (let by = 0; by < MASK_BLOCKS_Y; by++) {
            for (let bx = 0; bx < MASK_BLOCKS_X; bx++) {
                let left = 0;
                let right = 0;
                for (let y = by * MASK_BLOCK; y < (by + 1) * MASK_BLOCK; y++) {
                    for (let x = bx * MASK_BLOCK; x < (bx + 1) * MASK_BLOCK; x++) {
                        const bits = flicker[y * VB_SCREEN_WIDTH + x];
                        left += bits & 1;
                        right += bits >> 1;
                    }
                }
                blocks[by * MASK_BLOCKS_X + bx] =
                    (left >= MASK_BLOCK_SHARE ? 1 : 0) | (right >= MASK_BLOCK_SHARE ? 2 : 0);
            }
        }

        // Widened by MASK_REACH on both axes, one axis at a time.
        const spread = this.flickerSpread;
        for (let y = 0; y < VB_SCREEN_HEIGHT; y++) {
            const row = y * VB_SCREEN_WIDTH;
            for (let x = 0; x < VB_SCREEN_WIDTH; x++) {
                let bits = 0;
                const last = Math.min(VB_SCREEN_WIDTH - 1, x + MASK_REACH);
                for (let i = Math.max(0, x - MASK_REACH); i <= last; i++) {
                    bits |= flicker[row + i];
                }
                spread[row + x] = bits;
            }
        }
        for (let y = 0; y < VB_SCREEN_HEIGHT; y++) {
            const last = Math.min(VB_SCREEN_HEIGHT - 1, y + MASK_REACH);
            for (let x = 0; x < VB_SCREEN_WIDTH; x++) {
                let bits = 0;
                for (let i = Math.max(0, y - MASK_REACH); i <= last; i++) {
                    bits |= spread[i * VB_SCREEN_WIDTH + x];
                }
                flicker[y * VB_SCREEN_WIDTH + x] = bits;
            }
        }

        // And the cells that mostly flicker, with the cells around them.
        for (let y = 0; y < VB_SCREEN_HEIGHT; y++) {
            const by = Math.floor(y / MASK_BLOCK);
            for (let x = 0; x < VB_SCREEN_WIDTH; x++) {
                const bx = Math.floor(x / MASK_BLOCK);
                let bits = 0;
                for (let j = Math.max(0, by - 1); j <= Math.min(MASK_BLOCKS_Y - 1, by + 1); j++) {
                    for (let i = Math.max(0, bx - 1); i <= Math.min(MASK_BLOCKS_X - 1, bx + 1); i++) {
                        bits |= blocks[j * MASK_BLOCKS_X + i];
                    }
                }
                flicker[y * VB_SCREEN_WIDTH + x] |= bits;
            }
        }
        return flicker;
    }
}

/**
 * The last few frames a fast-forwarded audio buffer emulated, for blending.
 *
 * Fast forward runs several frames per buffer and shows only the last, so
 * the frames the renderer blends are not consecutive: a sprite drawn on
 * alternate frames is in some shown frames and not in others, at whatever
 * rhythm the speed makes — and blending, which only knows the frames it was
 * shown, flickers along. Held here, the three frames before the shown one go
 * to the renderer ahead of it, and it blends as at normal speed.
 *
 * Only ever frames run back to back: `clear` marks a gap.
 */
export class SkippedFrames {
    protected readonly buffers = [
        new Uint8Array(FRAME_BYTES), new Uint8Array(FRAME_BYTES),
        new Uint8Array(FRAME_BYTES), new Uint8Array(FRAME_BYTES)];
    protected readonly colorModes = [false, false, false, false];
    /** Frames held, at most four; the newest is at `(next + 3) % 4`. */
    protected count = 0;
    protected next = 0;

    hold(pixels: Uint8Array, colorMode: boolean): void {
        this.buffers[this.next].set(pixels);
        this.colorModes[this.next] = colorMode;
        this.next = (this.next + 1) % 4;
        this.count = Math.min(4, this.count + 1);
    }

    clear(): void {
        this.count = 0;
    }

    /**
     * The frames held before the newest, oldest first, and forget them all.
     * The newest is left out: it is the frame about to be shown anyway.
     * Valid until the next `hold`.
     */
    take(): HeldFrame[] {
        const frames: HeldFrame[] = [];
        for (let i = this.count; i > 1; i--) {
            const at = (this.next + 4 - i) % 4;
            frames.push({ pixels: this.buffers[at], colorMode: this.colorModes[at] });
        }
        this.count = 0;
        return frames;
    }
}
