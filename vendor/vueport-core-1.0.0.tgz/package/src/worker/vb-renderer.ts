/**
 * Presentation for one simulation.
 *
 * Legacy VB frames use one eye-packed texture, where red carries the left
 * eye's brightness and green the right eye's. A VBC-capable core instead
 * supplies packed RGB555 (left in R/G, right in B/A). Every display mode is
 * derived from the active transport by the fragment shader below, so switching
 * layouts still never touches emulation.
 *
 * Normally runs on the worker's OffscreenCanvas. Linux Tauri uses the same
 * renderer on an HTMLCanvasElement instead, because WebKitGTK exposes WebGL2
 * on the page but not inside a worker.
 */

import {
    DisplayMode,
    VbEyes,
    VbStereoLayout,
    VB_LEVEL_STOPS,
    VB_LEVELS,
    VB_SCREEN_HEIGHT,
    VB_SCREEN_WIDTH,
} from '../common/vb-constants';
import { duboisMatrices } from './vb-anaglyph';

const VERTEX_SHADER = `#version 300 es
// Fullscreen triangle, generated from the vertex id so no buffers are needed.
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
`;

const FRAGMENT_SHADER = `#version 300 es
precision highp float;

uniform sampler2D uFrame;
// The palette's color for each brightness level. Legacy frames use it before
// every layout is composed, including the two filtered images in Anaglyph.
uniform vec3 uPalette[${VB_LEVELS}];
// The anaglyph tints, used where both eyes share a pixel.
uniform vec3 uAnaglyphLeft;
uniform vec3 uAnaglyphRight;
uniform mat3 uAnaglyphMatrixLeft;
uniform mat3 uAnaglyphMatrixRight;
uniform int uDubois;
uniform vec2 uOutput;
uniform int uLayout;
uniform int uEyes;
uniform int uColorMode;

out vec4 fragColor;

const vec2 SOURCE = vec2(${VB_SCREEN_WIDTH}.0, ${VB_SCREEN_HEIGHT}.0);
const float CYBERSCOPE_HALF = 256.0;
// The eye value that stands for "both eyes at this pixel", i.e. VbEyes.BOTH.
const float ANAGLYPH = ${VbEyes.BOTH}.0;
// Brightnesses the four palette colors are anchored at, see VB_LEVEL_STOPS.
const float STOP1 = ${VB_LEVEL_STOPS[1].toFixed(6)};
const float STOP2 = ${VB_LEVEL_STOPS[2].toFixed(6)};
const float STOP3 = ${VB_LEVEL_STOPS[3].toFixed(6)};

/**
 * The palette color a brightness stands for. Exactly a palette entry at the
 * stops, interpolated in between, and held at the brightest entry above them.
 */
vec3 shade(float brightness) {
    if (brightness <= STOP1) {
        return mix(uPalette[0], uPalette[1], brightness / STOP1);
    }
    if (brightness <= STOP2) {
        return mix(uPalette[1], uPalette[2], (brightness - STOP1) / (STOP2 - STOP1));
    }
    return mix(uPalette[2], uPalette[3], min((brightness - STOP2) / (STOP3 - STOP2), 1.0));
}

/** Decode a little-endian RGB555 word stored in two normalized texture channels. */
vec3 rgb555(float lowChannel, float highChannel) {
    float low = floor(lowChannel * 255.0 + 0.5);
    float high = floor(highChannel * 255.0 + 0.5);
    float word = low + high * 256.0;
    float red = mod(word, 32.0);
    float green = mod(floor(word / 32.0), 32.0);
    float blue = mod(floor(word / 1024.0), 32.0);
    return vec3(red, green, blue) / 31.0;
}

vec3 toLinear(vec3 color) {
    return mix(pow((color + 0.055) / 1.055, vec3(2.4)), color / 12.92,
        lessThanEqual(color, vec3(0.04045)));
}

vec3 toSrgb(vec3 color) {
    return mix(1.055 * pow(color, vec3(1.0 / 2.4)) - 0.055, color * 12.92,
        lessThanEqual(color, vec3(0.0031308)));
}

void main() {
    // Integer pixel coordinates with the origin at the top left, matching the
    // row order the core writes its framebuffer in.
    float px = floor(gl_FragCoord.x);
    float py = floor(uOutput.y - gl_FragCoord.y);

    vec2 src;
    // Which eye this pixel belongs to: 0 the left one, 1 the right one. The
    // split layouts derive it from the position, the overlay from the mode.
    float eye;

    if (uLayout == ${VbStereoLayout.OVERLAY}) {
        src = vec2(px, py);
        eye = float(uEyes);
    } else if (uLayout == ${VbStereoLayout.SIDE_BY_SIDE}) {
        eye = step(SOURCE.x, px);
        src = vec2(px - eye * SOURCE.x, py);
    } else if (uLayout == ${VbStereoLayout.CYBERSCOPE}) {
        eye = step(CYBERSCOPE_HALF, px);
        src = vec2((px - eye * CYBERSCOPE_HALF) * (SOURCE.x / CYBERSCOPE_HALF), py);
    } else if (uLayout == ${VbStereoLayout.HLI}) {
        eye = mod(py, 2.0);
        src = vec2(px, floor(py * 0.5));
    } else {
        eye = mod(px, 2.0);
        src = vec2(floor(px * 0.5), py);
    }

    vec4 texel = texture(uFrame, (floor(src) + 0.5) / SOURCE);

    // First resolve each eye to its real display color. Legacy pixels acquire
    // their selected four-color ramp here; VBC pixels keep their RGB555
    // values. Layout is deliberately applied only afterwards, so Anaglyph is
    // a color-anaglyph of the same eye images the other modes would show.
    vec3 leftColor;
    vec3 rightColor;
    if (uColorMode != 0) {
        // VBC transport packs the left RGB555 word into R/G and right into B/A.
        leftColor = rgb555(texel.r, texel.g);
        rightColor = rgb555(texel.b, texel.a);
    } else {
        leftColor = shade(texel.r);
        rightColor = shade(texel.g);
    }

    vec3 color;
    if (eye >= ANAGLYPH) {
        if (uDubois != 0) {
            // Preserve negative cross-talk compensation until AFTER adding
            // both eyes, then clip to the display gamut and encode once.
            vec3 linear = uAnaglyphMatrixLeft * toLinear(leftColor)
                + uAnaglyphMatrixRight * toLinear(rightColor);
            color = toSrgb(clamp(linear, 0.0, 1.0));
        } else {
            // Uncalibrated/custom filters keep their existing channel masks.
            color = uAnaglyphLeft * leftColor + uAnaglyphRight * rightColor;
        }
    } else {
        color = eye < 0.5 ? leftColor : rightColor;
    }

    fragColor = vec4(min(color, vec3(1.0)), 1.0);
}
`;

/** Split a 0xRRGGBB color into normalized components. */
function toRgb(color: number): [number, number, number] {
    return [
        ((color >> 16) & 0xff) / 255,
        ((color >> 8) & 0xff) / 255,
        (color & 0xff) / 255,
    ];
}

export class VbRenderer {

    protected readonly gl: WebGL2RenderingContext;
    protected readonly texture: WebGLTexture;
    protected readonly uniforms: {
        palette: WebGLUniformLocation | null;
        anaglyphLeft: WebGLUniformLocation | null;
        anaglyphRight: WebGLUniformLocation | null;
        anaglyphMatrixLeft: WebGLUniformLocation | null;
        anaglyphMatrixRight: WebGLUniformLocation | null;
        dubois: WebGLUniformLocation | null;
        output: WebGLUniformLocation | null;
        layout: WebGLUniformLocation | null;
        eyes: WebGLUniformLocation | null;
        colorMode: WebGLUniformLocation | null;
    };

    /** Whether the texture contains a frame that a mode change can redraw. */
    protected hasFrame = false;
    protected lastColorMode = false;

    constructor(
        protected readonly canvas: OffscreenCanvas | HTMLCanvasElement,
        mode: DisplayMode,
    ) {
        // Screenshots read the drawing buffer back after the fact, which is
        // only reliable when it is preserved.
        // The cast is this TypeScript's DOM library, not a doubt about what
        // comes back: it types `OffscreenCanvas#getContext` as returning the
        // whole `OffscreenRenderingContext` union whatever context id is asked
        // for, so the tag has to be restated. Everything below would otherwise
        // be typed against `ImageBitmapRenderingContext`.
        const gl = canvas.getContext('webgl2', {
            alpha: false,
            antialias: false,
            depth: false,
            preserveDrawingBuffer: true,
            stencil: false,
        }) as WebGL2RenderingContext | null;
        if (!gl) {
            throw new Error('Could not acquire a WebGL2 context for the emulator canvas.');
        }
        this.gl = gl;

        const program = this.buildProgram();
        gl.useProgram(program);

        this.uniforms = {
            // An array uniform is set through the location of its first element.
            palette: gl.getUniformLocation(program, 'uPalette[0]'),
            anaglyphLeft: gl.getUniformLocation(program, 'uAnaglyphLeft'),
            anaglyphRight: gl.getUniformLocation(program, 'uAnaglyphRight'),
            anaglyphMatrixLeft: gl.getUniformLocation(program, 'uAnaglyphMatrixLeft'),
            anaglyphMatrixRight: gl.getUniformLocation(program, 'uAnaglyphMatrixRight'),
            dubois: gl.getUniformLocation(program, 'uDubois'),
            output: gl.getUniformLocation(program, 'uOutput'),
            layout: gl.getUniformLocation(program, 'uLayout'),
            eyes: gl.getUniformLocation(program, 'uEyes'),
            colorMode: gl.getUniformLocation(program, 'uColorMode'),
        };

        const texture = gl.createTexture();
        if (!texture) {
            throw new Error('Could not allocate the emulator frame texture.');
        }
        this.texture = texture;
        gl.bindTexture(gl.TEXTURE_2D, texture);
        // The image is presented at integer scales; anything but nearest
        // filtering would blur a display that has no in-between pixels.
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texImage2D(
            gl.TEXTURE_2D, 0, gl.RGBA, VB_SCREEN_WIDTH, VB_SCREEN_HEIGHT, 0,
            gl.RGBA, gl.UNSIGNED_BYTE, null
        );
        gl.uniform1i(gl.getUniformLocation(program, 'uFrame'), 0);

        this.setDisplayMode(mode);
    }

    setDisplayMode(mode: DisplayMode): void {
        const gl = this.gl;
        this.canvas.width = mode.width;
        this.canvas.height = mode.height;
        gl.viewport(0, 0, mode.width, mode.height);

        gl.uniform3fv(this.uniforms.palette, mode.palette.flatMap(toRgb));
        gl.uniform3fv(this.uniforms.anaglyphLeft, toRgb(mode.anaglyph.left));
        gl.uniform3fv(this.uniforms.anaglyphRight, toRgb(mode.anaglyph.right));
        const matrices = duboisMatrices(mode.anaglyph);
        gl.uniform1i(this.uniforms.dubois, matrices ? 1 : 0);
        if (matrices) {
            gl.uniformMatrix3fv(this.uniforms.anaglyphMatrixLeft, false, matrices.left);
            gl.uniformMatrix3fv(this.uniforms.anaglyphMatrixRight, false, matrices.right);
        }
        gl.uniform2f(this.uniforms.output, mode.width, mode.height);
        gl.uniform1i(this.uniforms.layout, mode.layout);
        gl.uniform1i(this.uniforms.eyes, mode.eyes);
        gl.uniform1i(this.uniforms.colorMode, this.lastColorMode ? 1 : 0);

        if (this.hasFrame) {
            this.draw();
        }
    }

    present(pixels: Uint8Array, colorMode = false): void {
        // Do not retain `pixels`: the main-thread path transfers its backing
        // buffer straight back to the worker after this upload, detaching it.
        // The texture is the retained copy needed for redraws and captures.
        this.hasFrame = true;
        this.lastColorMode = colorMode;
        const gl = this.gl;
        gl.uniform1i(this.uniforms.colorMode, colorMode ? 1 : 0);
        gl.texSubImage2D(
            gl.TEXTURE_2D, 0, 0, 0, VB_SCREEN_WIDTH, VB_SCREEN_HEIGHT,
            gl.RGBA, gl.UNSIGNED_BYTE, pixels
        );
        this.draw();
    }

    /**
     * Encode the presented frame as a PNG, optionally at a whole multiple of
     * its own size.
     *
     * The enlargement is a nearest-neighbor blit afterwards rather than a
     * bigger render: the shader works in output pixels and maps each straight
     * onto a source one, so a larger drawing buffer would not be a larger
     * picture but a differently-cut one. Blitting keeps the pixels square and
     * leaves the live path's shader alone.
     */
    async capture(scale = 1): Promise<ArrayBuffer> {
        const times = Math.max(1, Math.floor(scale));
        const enlarged = times > 1
            ? this.createCanvas(this.canvas.width * times, this.canvas.height * times)
            : undefined;
        const context = enlarged?.getContext('2d') as
            CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D | null | undefined;
        if (enlarged && context) {
            context.imageSmoothingEnabled = false;
            context.drawImage(this.canvas, 0, 0, enlarged.width, enlarged.height);
        }
        // No 2D context to enlarge with is not worth failing over: the picture
        // at its own size is a better answer than none.
        const source = enlarged && context ? enlarged : this.canvas;
        let blob: Blob;
        if (typeof OffscreenCanvas !== 'undefined' && source instanceof OffscreenCanvas) {
            blob = await source.convertToBlob({ type: 'image/png' });
        } else {
            blob = await new Promise<Blob>((resolve, reject) =>
                (source as HTMLCanvasElement).toBlob(
                    value => value
                        ? resolve(value)
                        : reject(new Error('Could not encode the frame.')),
                    'image/png',
                ));
        }
        return blob.arrayBuffer();
    }

    protected createCanvas(width: number, height: number): OffscreenCanvas | HTMLCanvasElement {
        if (typeof OffscreenCanvas !== 'undefined' && this.canvas instanceof OffscreenCanvas) {
            return new OffscreenCanvas(width, height);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        return canvas;
    }

    protected draw(): void {
        this.gl.drawArrays(this.gl.TRIANGLES, 0, 3);
    }

    protected buildProgram(): WebGLProgram {
        const gl = this.gl;
        const program = gl.createProgram();
        if (!program) {
            throw new Error('Could not create the emulator shader program.');
        }
        gl.attachShader(program, this.compile(gl.VERTEX_SHADER, VERTEX_SHADER));
        gl.attachShader(program, this.compile(gl.FRAGMENT_SHADER, FRAGMENT_SHADER));
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            throw new Error(`Could not link the emulator shader: ${gl.getProgramInfoLog(program)}`);
        }
        return program;
    }

    protected compile(type: number, source: string): WebGLShader {
        const gl = this.gl;
        const shader = gl.createShader(type);
        if (!shader) {
            throw new Error('Could not create an emulator shader.');
        }
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            throw new Error(`Could not compile the emulator shader: ${gl.getShaderInfoLog(shader)}`);
        }
        return shader;
    }

    dispose(): void {
        this.gl.deleteTexture(this.texture);
        this.hasFrame = false;
        this.lastColorMode = false;
        // The context itself, not just what was allocated inside it. A browser
        // keeps only a small number of WebGL contexts alive at once and
        // force-loses the oldest past that number; dropping the last reference
        // to this one leaves it standing until the collector gets round to the
        // canvas, which may be long after the session that owned it has gone.
        // It matters most where every renderer is a context on the page — the
        // Linux desktop, see the head of this file — because there the live
        // picture is one of the contexts in the running.
        this.gl.getExtension('WEBGL_lose_context')?.loseContext();
    }
}
