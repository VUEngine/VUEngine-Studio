/**
 * Emulator core worker.
 *
 * Owns the WebAssembly core and every simulation in one emulation session, and
 * runs the drive loop. Emulation is clocked by audio consumption: the audio
 * worklet returns emptied sample buffers, and each returned buffer causes
 * exactly VB_CLOCKS_PER_BUFFER clocks to be emulated and the buffer refilled.
 * Video is paced against the audio backlog so that picture and sound stay in
 * step without a separate timer.
 *
 * This module MUST NOT import anything from Theia; it is bundled as a
 * standalone worker entry point.
 */

import {
  VB_AUDIO_BUFFER_COUNT,
  VB_CART_RAM_BASE,
  VB_CLOCKS_PER_BUFFER,
  VB_DEFAULT_DISPLAY_MODE,
  VB_ES_SOUND_PORT,
  VB_EYE_PACKED_LEFT,
  VB_EYE_PACKED_RIGHT,
  VB_FRAME_RATE,
  VB_LINK_CONTROL_PORT,
  VB_LINK_START,
  VB_LINK_TRANSMIT_PORT,
  VB_MAX_IDLE_EMULATE_CALLS,
  VB_MAX_MEMORY_READ,
  VB_SAMPLES_PER_BUFFER,
  VB_SCREEN_HEIGHT,
  VB_SCREEN_WIDTH,
  VB_INTERRUPT_VECTOR_BASE,
  VB_PSW_INTERRUPT_LEVEL_MASK,
  VB_PSW_INTERRUPT_LEVEL_SHIFT,
  VB_TERMINAL_PORT,
  VB_VRAM_BASE,
  VB_VRAM_SIZE,
  VB_VSU_CHANNELS,
  isVbcColorFramebuffer,
  VBC_COLOR_FRAMEBUFFER_BASE,
  VBC_COLOR_FRAMEBUFFER_PAGE_BYTES,
  VB_WRAM_BASE,
  VB_WRAM_SIZE,
  VbBreak,
  VbDataType,
  DisplayMode,
  VbInterrupt,
  vbInterruptExceptionCode,
  VbPsw,
  VbSystemRegister,
  isCartRam,
} from '../common/vb-constants';
import {
  Bootstrap,
  VbCheatWrite,
  ScheduledEdit,
  CommandName,
  VbEvent,
  Params,
  DisassemblyLine,
  ProfileResult,
  Recording,
  Registers,
  Request,
  Response,
  Result,
  SimHandle,
  MAX_SRAM_RUNS,
  StopReason,
  MAX_SRAM_RUN_BYTES,
  MAX_SRAM_STRIDE,
  VideoFrameReturn,
  VsuReading,
} from '../common/vb-protocol';
import { saveRamHighWater } from '../common/emulator-save-state';
import {
  decodeRomKinds,
  VesInstructionKind,
  VesProfileCollector,
} from '../common/emulator-profile';
import { VesLiveProfileCollector, LiveProfileSnapshot } from '../common/emulator-live-profile';
import { ES_SOUND_INIT } from '../common/emulator-essound';
import { applyDelta, createRunScratch, encodeDelta } from './vb-rewind';
import { VbRenderer } from './vb-renderer';
import {
  installVbCallback,
  instantiateWasm,
  releaseVbCallback,
  VB_EXECUTE_CALLBACK_ARITY,
  VB_READ_CALLBACK_ARITY,
  VB_WRITE_CALLBACK_ARITY,
  WasmExports,
} from './vb-wasm';
import { RetroAchievements } from './vb-rcheevos';
import {
  applyVsuMutes,
  calibrateVsuLayout,
  composeVsuMap,
  createVsuMuteState,
  restoreVsuMutes,
  takeVsuLevelWrite,
  vsuLevelWriteChannel,
  VsuLayout,
  VsuMuteState,
} from './vb-vsu-layout';

// Minimal shape of the dedicated worker global, which lib.dom does not type.
interface WorkerScope {
  onmessage: ((event: MessageEvent) => void) | undefined;
  postMessage(message: unknown, transfer?: Transferable[]): void;
}

interface SimState {
  pointer: number;
  renderer?: VbRenderer;
  /** Transfer buffers used when WebGL presentation lives on the DOM thread. */
  mainThread?: { presentation: number; buffers: ArrayBuffer[] };
  /**
   * A second pool of the same, for a video recording on the DOM thread.
   *
   * Independent of `mainThread`: a recording taps a machine that is being
   * presented here as readily as one that is being presented there, so both
   * can be filled from the same frame. See `setVideoTap` in `vb-protocol.ts`.
   */
  videoTap?: { presentation: number; buffers: ArrayBuffer[] };
  // Kept so the renderer can be rebuilt if the display mode arrives first.
  displayMode: DisplayMode;
  // Pointer to the core-owned sample buffer for this simulation.
  samples: number;
  // Cartridge buffers we allocated and are responsible for freeing.
  cartRom: number;
  cartRomSize: number;
  cartRam: number;
  cartRamSize: number;
  /** Last mask handed to the core, which is what a recording writes down. */
  keys: number;
  /** Physical hardware model kept outside snapshots so a load cannot change it. */
  vbcHardware: boolean;
  /**
   * Which end of the link cable this machine is, or 0 when it is on no cable.
   *
   * Only ever used to order the pair — see {@link Worker.orderedSims}.
   */
  linkOrder: number;
}

/**
 * Rewind history, stored as reverse deltas.
 *
 * Storing whole snapshots is hopeless: the state struct is 1.85 MiB but only
 * about 0.2% of it changes per frame, so a 128 MB budget buys barely a second
 * of history. Encoding just the changed runs gets the same budget to minutes.
 *
 * Each entry converts the state at one capture back to the state at the
 * previous one, which is exactly the direction rewind walks, so stepping back
 * is a single XOR pass over the changed bytes and needs no keyframes.
 */
/**
 * A {@link SramRun} while it is still being added to.
 *
 * Two things a finished run does not carry: the values are a plain array,
 * because a run grows a byte at a time and a byte array cannot; and `at` is
 * the address the last touch landed on, which is what the next one is
 * measured against. Both are dropped when the run is handed over.
 */
/**
 * What one simulation is waiting to stop on.
 *
 * Two kinds at once, because they answer to different owners: `points` is the
 * gutter, set and cleared by whoever is reading the disassembly, and `pending`
 * is a single trap laid for one run — stepping over a call, or running to the
 * cursor — which is gone the moment it springs.
 */
interface SimStop {
  /** Armed addresses, as a whole set; see `setBreakpoints`. */
  points: Set<number>;
  /**
   * Instructions to let past before anything may stop.
   *
   * One, always, and for one reason: the callback reports an instruction
   * before it runs, so a machine standing on a breakpoint would stop on it
   * again the instant it was told to carry on, and nothing would ever move.
   */
  grace: number;
  /** A one-shot stop, if something is waiting for one. */
  pending?: { reason: StopReason; at?: number };
}

/**
 * How the disassembler is asked to write its text.
 *
 * The sixteen options `Disassemble` takes, in the order it takes them, from
 * the vocabulary in the core's own `Constants.js`. What they add up to is the
 * notation a Virtual Boy programmer reads: lower-case mnemonics and
 * registers, upper-case hex digits behind `0x`, the destination last the way
 * the assembler writes it, `-8[fp]` rather than `[fp-8]`, and conditions and
 * system registers by name rather than by number.
 */
const DISASSEMBLY_STYLE = [
  0,  // bcondNotation: JOINED, so `be` rather than `b e`
  1,  // conditionCase: LOWER
  0,  // conditionCL: L, the unsigned spelling — `bl` rather than `bc`
  0,  // conditionEZ: E — `be` rather than `bz`
  1,  // conditionNotation: NAMES
  0,  // hexCase: UPPER, for digits that line up with the address column
  0,  // hexNotation: 0X
  0,  // immediateNotation: NONE, so an immediate is just a number
  0,  // memoryNotation: OUTSIDE — `-8[fp]`
  1,  // mnemonicCase: LOWER
  0,  // operandOrder: DEST_LAST
  1,  // programCase: LOWER
  1,  // programNotation: NAMES, so r2 reads as `fp`
  1,  // setfNotation: NAMES
  1,  // systemCase: LOWER
  1,  // systemNotation: NAMES
] as const;

interface GrowingSramRun {
  address: number;
  at: number;
  stride: number;
  values: number[];
  write: boolean;
  type: number;
  pc: number;
}

interface RewindStore {
  enabled: boolean;
  granularity: number;
  budgetBytes: number;
  // State at the newest capture, one per simulation. Deltas are relative to this.
  mirrors: Uint8Array[];
  // entries[n][sim] converts capture n back to capture n-1. Oldest first.
  entries: Uint8Array[][];
  // Total bytes held by entries, against which the budget is enforced.
  bytes: number;
  frames: number;
}

// Interleaved stereo, so two floats per frame.
const MIX_BUFFER_LENGTH = VB_SAMPLES_PER_BUFFER * 2;

/**
 * The VIP's frame repeat register, in the register block at 0x0005f800.
 *
 * Read by the live profiler to know how many pictures the machine takes over
 * one drawing — see `endLiveFrame`. The browser's `VipRegister` enum names the
 * whole block, but that lives on the other side of the worker boundary and
 * nothing else here needs it.
 */
const VIP_FRMCYC = 0x0005f82e;

class Worker {
  /** The read ceiling, which callers reading in windows share. */
  static readonly MAX_MEMORY_WINDOW = VB_MAX_MEMORY_READ;
  /** 256 palettes, one bit each — the width of the framebuffer's palette byte. */
  static readonly DRAWN_PALETTE_SET_BYTES = 32;
  /** One eye's legacy framebuffer page: 384 columns of 256 two-bit pixels. */
  static readonly LEGACY_FRAMEBUFFER_PAGE_BYTES = 0x8000;
  static readonly MAX_DISASSEMBLY_LINES = 512;
  /**
   * The finest the immersion halo could ever want, per axis. Well past what it
   * asks for, and small enough that averaging into it stays a rounding error
   * beside a frame of emulation — at this cap a cell is under two pixels, so
   * the work is bounded by the framebuffer either way.
   */
  static readonly MAX_BACKDROP_CELLS = 192;

  /**
   * Cap on terminal text held between flushes.
   *
   * A program in a tight loop can write to the port far faster than the panel
   * can display it, and the buffer is drained fifty times a second, so this is
   * only ever reached by output nobody could read anyway.
   */
  static readonly MAX_TERMINAL_BYTES = 1 << 16;

  /**
   * Cap on link port bytes held between flushes.
   *
   * Far smaller than the terminal's, because these are forwarded to a device
   * over a serial line that is slower than the game can fill it. A backlog
   * bigger than this is one the pack could never work through in time, and
   * rumble that lags a second behind the game is worse than rumble that
   * skipped what it could not keep up with.
   */
  static readonly MAX_LINK_BYTES = 1 << 10;

  /**
   * Cap on watched pointer values held between flushes. A pointer variable is
   * assigned when something starts, not in a loop, so this is only reached by
   * a program in trouble.
   */
  static readonly MAX_POINTER_WRITES = 64;

  /**
   * Cap on ESSound commands held between flushes. One store starts or stops a
   * track, so a game sends a handful a second at most.
   */
  static readonly MAX_ES_SOUND_COMMANDS = 256;

  /**
   * Wall time one audio buffer covers, and the share of it emulation may use.
   *
   * The worklet plays a buffer in exactly this long, so this is the deadline a
   * fill has to meet. The rest of the slice is for everything else a tick does
   * — mixing, presenting, and the messages either side of it.
   */
  static readonly BUFFER_WALL_MS = 1000 / VB_FRAME_RATE;
  /**
   * The share of that slice emulation may spend, the rest being the margin
   * that keeps the queue ahead of the worklet. Measured on a machine whose raw
   * ceiling was 3x: at this margin fast forward reaches 2.7x and holds a full
   * 50 fps, and widening it further buys speed only by underrunning again.
   */
  static readonly EMULATION_BUDGET = 0.9;
  /** How much a fresh measurement moves the rolling chunk cost. */
  static readonly CHUNK_COST_WEIGHT = 0.1;

  /** How often the achieved speed is reported, in milliseconds. */
  static readonly SPEED_REPORT_MS = 1000;
  /**
   * How far ahead of the current frame input may be booked.
   *
   * A lockstep session runs a handful of frames of delay; anything near this
   * is a peer that has lost the plot, and taking it would be a slow leak.
   */
  static readonly MAX_SCHEDULED_FRAMES = 600;
  /**
   * How often the frame count is reported while under lockstep.
   *
   * Every frame, because anything less forces a session to book further ahead
   * than it wants to: a schedule kept three frames ahead of a loop that only
   * says where it is every fourth frame runs dry between reports, every time,
   * and the game stutters. One more small message per frame is nothing beside
   * the audio buffer the loop already posts on the same schedule.
   */
  static readonly PROGRESS_REPORT_FRAMES = 1;
  /**
   * System registers {@link stateDigest} covers.
   *
   * The architectural ones only. The index space is sparse — 8 to 23 are not
   * registers at all — so hashing every index would hash whatever the core
   * happens to answer for a hole.
   */
  static readonly DIGEST_SYSTEM_REGISTERS = [
    VbSystemRegister.EIPC,
    VbSystemRegister.EIPSW,
    VbSystemRegister.FEPC,
    VbSystemRegister.FEPSW,
    VbSystemRegister.ECR,
    VbSystemRegister.PSW,
    VbSystemRegister.PIR,
    VbSystemRegister.TKCW,
    VbSystemRegister.CHCW,
    VbSystemRegister.ADTRE,
  ];

  protected wasm: WasmExports;
  protected audioPort: MessagePort;

  protected readonly sims = new Map<SimHandle, SimState>();

  // Sample buffers currently held by us rather than by the audio worklet.
  protected readonly audioQueue: Float32Array[] = [];

  protected emulating = false;

  // Emulation rate, where 1 is real time.
  protected speed = 1;
  // Clocks carried over between audio buffers, so slow motion can fall short of a chunk.
  protected pendingClocks = 0;
  /**
   * Rolling wall-clock cost of one emulated chunk, in milliseconds.
   *
   * What `affordableSpeed` divides the buffer's budget by. Smoothed because a
   * single chunk's cost swings with whatever the game happens to be doing, and
   * a speed that chased those swings would be visible as jitter.
   */
  protected chunkCostMs = 0;
  /** Chunks emulated since the last speed report, and when that report was. */
  protected chunksSinceReport = 0;
  protected lastSpeedReport = 0;
  /**
   * Chunks emulated since the ROM was loaded or the machine reset, which is
   * the frame number a debug readout shows. Not reset by pausing: a frame
   * count that started over every time somebody paused would count something
   * nobody asked about.
   */
  protected framesRun = 0;

  /**
   * Controller masks booked against the frames they belong to, by simulation.
   *
   * See `queueKeys` in `vb-protocol.ts`. Entries are dropped as the frames
   * they name go past, so this holds only what is still ahead.
   */
  protected readonly keySchedules = new Map<SimHandle, Map<number, number>>();
  /**
   * Writes booked against the frames they belong to, by simulation.
   *
   * See `queueEdits` in `vb-protocol.ts`. Kept apart from the key schedule
   * rather than folded into it because the two behave differently at a frame
   * nothing was booked for: a mask persists — that is what makes a held
   * button hold — where a write happens once and is done.
   */
  protected readonly editSchedules =
    new Map<SimHandle, Map<number, ScheduledEdit[]>>();
  /** Simulations that must not run past the input they have been booked. */
  protected readonly lockstepSims = new Set<SimHandle>();
  /**
   * Whether the drive loop is currently stopped waiting for one, so that the
   * event fires on the change rather than on every frame it waits.
   */
  protected awaitingInput = false;
  /** Frame count at the last progress report, so they stay spaced out. */
  protected lastProgressReport = 0;
  /**
   * How often each simulation's digest is taken, by simulation.
   *
   * Empty for a solo emulator, which has nothing to compare itself against.
   */
  protected readonly digestPeriods = new Map<SimHandle, number>();

  protected readonly rewind: RewindStore = {
    enabled: false,
    granularity: 1,
    budgetBytes: 0,
    mirrors: [],
    entries: [],
    bytes: 0,
    frames: 0,
  };

  protected readonly runScratch = createRunScratch();

  /**
   * Table slot holding the shared write callback, or 0 before anything has
   * asked to watch writes. One callback serves every simulation and every
   * watcher (terminal capture, VSU capture), since it is handed the
   * simulation pointer and the address and can route on both; a simulation
   * only ever has room for one installed callback at a time (see
   * updateWriteWatch), so watchers cannot each install their own.
   */
  /**
   * A renderer of this worker's own, for screenshots that are not the picture
   * as it is being shown. Built on first use and kept: a WebGL context is
   * expensive to make and a screenshot is not a rare thing.
   */
  protected screenshotRenderer?: VbRenderer;
  protected writeWatchCallbackSlot = 0;
  protected readWatchCallbackSlot = 0;
  // Bytes seen at the terminal port since the last flush, by simulation.
  protected readonly terminalBuffers = new Map<SimHandle, number[]>();
  /**
   * Where this core keeps the VSU's state, once that has been found, or the
   * failure to find it. Undefined until the first readVsu asks.
   *
   * One per core rather than per simulation: every simulation is the same
   * struct. See `vb-vsu-layout.ts`.
   */
  protected vsuLayout?: VsuLayout | Error;
  /**
   * Channels the VSU panel is holding silent, by simulation pointer, and the
   * levels the game gave them.
   *
   * Keyed by pointer rather than handle because the drive loop is what applies
   * them, and it walks simulation states — the same reason the cheats are. An
   * entry exists only while something is actually muted, so a machine nobody
   * has touched costs nothing at all per frame.
   */
  protected readonly vsuMutes = new Map<number, VsuMuteState>();
  /**
   * Which palettes have painted a pixel since the last flush, by simulation, as
   * a 256-bit set. Present only while setDrawnPaletteCapture(true) is in effect
   * for that simulation.
   *
   * A set and not a count: what the color editor asks is whether a palette is
   * live at all, and counting pixels would make a palette that fills the screen
   * look more "on" than one drawing a two-pixel highlight, which is not a
   * distinction anybody is editing colors by.
   */
  protected readonly drawnPalettes = new Map<SimHandle, Uint8Array>();
  /**
   * The address each simulation is following a pointer at, by simulation, and
   * the values written to it since the last flush. Present only while
   * setPointerWatch is in effect for that simulation.
   */
  protected readonly pointerWatches = new Map<SimHandle, number>();

  /**
   * Writes to repeat at every frame break, by simulation pointer — the cheats
   * that are switched on. Keyed by pointer rather than handle because the
   * drive loop, which is what applies them, walks simulation states.
   */
  protected readonly cheats = new Map<number, VbCheatWrite[]>();
  protected readonly pointerWrites = new Map<SimHandle, number[]>();
  // Bytes clocked out of the link port since the last flush, by simulation.
  protected readonly linkBuffers = new Map<SimHandle, number[]>();
  /**
   * Halfwords written to the ESSound port since the last flush, by
   * simulation. Present only while setEsSoundCapture(true) is in effect.
   */
  protected readonly esSoundBuffers = new Map<SimHandle, number[]>();
  /**
   * Runs of touches of the cartridge's save region, by simulation. Present
   * only while a capture of at least one direction is in effect.
   *
   * Gathered here rather than sent on per access: see {@link SramRun}. The
   * values are collected into a plain array while the run is still growing
   * and become a byte array when the run is handed over.
   */
  protected readonly sramBuffers = new Map<SimHandle, GrowingSramRun[]>();
  /**
   * Which directions each simulation's capture asked for. Only present while
   * one or the other is wanted, which is what says a capture is on at all.
   */
  protected readonly sramDirections = new Map<SimHandle, { writes: boolean; reads: boolean }>();
  /**
   * Where each simulation should stop, and what it is waiting for.
   *
   * Present only for a simulation something is watching; the per-instruction
   * callback is installed and taken away with it, because it is the one
   * callback the core runs on every instruction rather than on every access
   * of some kind — about a sixth of the emulation it watches, measured in
   * `tests/breakpoint-probe.mjs`.
   */
  protected readonly stops = new Map<SimHandle, SimStop>();
  /**
   * The stop that has happened and has not been reported yet.
   *
   * Set from inside the core's own callback, which is in the middle of an
   * `Emulate` call and no place to be suspending the worker from. The drain
   * loop sees it on the way out and everything else follows from there.
   */
  protected stopped?: { pointer: SimHandle; address: number; reason: StopReason };
  protected executeCallbackSlot = 0;
  /**
   * One view over the core's memory, for the callbacks that read a byte out
   * of it on every access.
   *
   * Held rather than made each time. The access callbacks are called from
   * inside the emulated CPU — a game reading its save runs them hundreds of
   * thousands of times a second — and a typed array made per call is an
   * allocation per emulated load, which costs more than the emulation it is
   * watching and leaves the collector to clean up after it.
   *
   * The core grows its own memory, which detaches whatever was made over the
   * old buffer, so the buffer is what says whether this is still good.
   */
  protected memoryBytes?: Uint8Array;
  /**
   * Simulations owed an expansion-port interrupt, by pointer.
   *
   * An ESSound cartridge answers the init command with a pulse on /INTCRO, and
   * that pulse is how a ROM finds out the hardware is there at all. Held until
   * the CPU is in a state to take it rather than dropped, since a ROM
   * commonly sends init with interrupts still disabled.
   */
  protected readonly gamePakInterrupts = new Set<number>();
  /**
   * What each simulation last stored in the link port's transmit register, by
   * simulation. Shadowed rather than read back at transmission time because
   * the write watcher is the only thing that sees these registers at all, and
   * a byte is only sent once the control register says so.
   */
  protected readonly linkTransmitBytes = new Map<SimHandle, number>();

  // Scratch allocations in core memory, see #allocateScratch.
  protected clocksPointer = 0;
  protected simsPointer = 0;
  protected simsCapacity = 0;
  protected mixPointer = 0;

  /**
   * The RetroAchievements engine, created once `init` has run. Bound to at
   * most one simulation — the one `raLoadGame` was last called for — never a
   * profile replay's scratch simulation and never a linked peer.
   */
  protected ra: RetroAchievements;
  protected raSimPointer = 0;

  constructor(protected readonly workerScope: WorkerScope) {}

  async bootstrap(bootstrap: Bootstrap): Promise<void> {
    this.audioPort = bootstrap.audioPort;
    this.audioPort.onmessage = event =>
      this.onAudioBuffersReturned(event.data);

    for (let i = 0; i < VB_AUDIO_BUFFER_COUNT; i++) {
      this.audioQueue.push(new Float32Array(MIX_BUFFER_LENGTH));
    }
  }

  async handle<K extends CommandName>(
    command: K,
    params: Params<K>,
  ): Promise<unknown> {
    switch (command) {
      case 'init':
        return this.init(params as Params<'init'>);
      case 'createSim':
        return this.createSim();
      case 'deleteSim':
        return this.deleteSim(params as Params<'deleteSim'>);
      case 'attachCanvas':
        return this.attachCanvas(params as Params<'attachCanvas'>);
      case 'setVideoTap':
        return this.setVideoTap(params as Params<'setVideoTap'>);
      case 'setCartRom':
        return this.setCartRom(params as Params<'setCartRom'>);
      case 'setCartRam':
        return this.setCartRam(params as Params<'setCartRam'>);
      case 'getCartRam':
        return this.getCartRam(params as Params<'getCartRam'>);
      case 'cartRamInfo':
        return this.cartRamInfo(params as Params<'cartRamInfo'>);
      case 'stateSize':
        return this.wasm.vbSizeOf();
      case 'reset':
        return this.reset(params as Params<'reset'>);
      case 'setHardwareMode':
        return this.setHardwareMode(params as Params<'setHardwareMode'>);
      case 'setKeys':
        return this.setKeys(params as Params<'setKeys'>);
      case 'queueKeys':
        return this.queueKeys(params as Params<'queueKeys'>);
      case 'queueEdits':
        return this.queueEdits(params as Params<'queueEdits'>);
      case 'setLockstep':
        return this.setLockstep(params as Params<'setLockstep'>);
      case 'stateDigest':
        return this.stateDigest(params as Params<'stateDigest'>);
      case 'setDigestPeriod':
        return this.setDigestPeriod(params as Params<'setDigestPeriod'>);
      case 'startProfileRecording':
        return this.startProfileRecording(params as Params<'startProfileRecording'>);
      case 'stopProfileRecording':
        return this.stopProfileRecording(params as Params<'stopProfileRecording'>);
      case 'replayProfile':
        return this.replayProfile(params as Params<'replayProfile'>);
      case 'setLiveProfiler':
        return this.setLiveProfiler(params as Params<'setLiveProfiler'>);
      case 'readLiveProfile':
        return this.readLiveProfile(params as Params<'readLiveProfile'>);
      case 'setDisplayMode':
        return this.setDisplayMode(params as Params<'setDisplayMode'>);
      case 'capture':
        return this.capture(params as Params<'capture'>);
      case 'setVolume':
        return this.setVolume(params as Params<'setVolume'>);
      case 'setPanning':
        return this.setPanning(params as Params<'setPanning'>);
      case 'run':
        return this.run();
      case 'suspend':
        return this.suspend();
      case 'saveState':
        return this.saveState(params as Params<'saveState'>);
      case 'loadState':
        return this.loadState(params as Params<'loadState'>);
      case 'setSpeed':
        return this.setSpeed(params as Params<'setSpeed'>);
      case 'stepFrame':
        return this.stepFrame();
      case 'setRewind':
        return this.setRewind(params as Params<'setRewind'>);
      case 'rewindStep':
        return this.rewindStep(params as Params<'rewindStep'>);
      case 'setPeer':
        return this.setPeer(params as Params<'setPeer'>);
      case 'readPixels':
        return this.readPixels(params as Params<'readPixels'>);
      case 'readBackdrop':
        return this.readBackdrop(params as Params<'readBackdrop'>);
      case 'readFrame':
        return this.readFrame(params as Params<'readFrame'>);
      case 'refreshFrame':
        return this.refreshFrame(params as Params<'refreshFrame'>);
      case 'readMemory':
        return this.readMemory(params as Params<'readMemory'>);
      case 'writeMemory':
        return this.writeMemory(params as Params<'writeMemory'>);
      case 'readRegisters':
        return this.readRegisters(params as Params<'readRegisters'>);
      case 'disassemble':
        return this.disassemble(params as Params<'disassemble'>);
      case 'setBreakpoints':
        return this.setBreakpoints(params as Params<'setBreakpoints'>);
      case 'stepInstruction':
        return this.stepInstruction(params as Params<'stepInstruction'>);
      case 'runTo':
        return this.runTo(params as Params<'runTo'>);
      case 'setTerminalCapture':
        return this.setTerminalCapture(
          params as Params<'setTerminalCapture'>,
        );
      case 'setLinkCapture':
        return this.setLinkCapture(params as Params<'setLinkCapture'>);
      case 'setPointerWatch':
        return this.setPointerWatch(params as Params<'setPointerWatch'>);
      case 'setCheats':
        return this.setCheats(params as Params<'setCheats'>);
      case 'setEsSoundCapture':
        return this.setEsSoundCapture(params as Params<'setEsSoundCapture'>);
      case 'setSramCapture':
        return this.setSramCapture(params as Params<'setSramCapture'>);
      case 'readVsu':
        return this.readVsu(params as Params<'readVsu'>);
      case 'setVsuMutes':
        return this.setVsuMutes(params as Params<'setVsuMutes'>);
      case 'setDrawnPaletteCapture':
        return this.setDrawnPaletteCapture(params as Params<'setDrawnPaletteCapture'>);
      case 'takeDrawnPalettes':
        return this.takeDrawnPalettes(params as Params<'takeDrawnPalettes'>);
      case 'raLoginPassword':
        return this.raLoginPassword(params as Params<'raLoginPassword'>);
      case 'raLoginToken':
        return this.raLoginToken(params as Params<'raLoginToken'>);
      case 'raLogout':
        return this.raLogout();
      case 'raLoadGame':
        return this.raLoadGame(params as Params<'raLoadGame'>);
      case 'raUnloadGame':
        return this.raUnloadGame();
      case 'raProvideResponse':
        return this.raProvideResponse(params as Params<'raProvideResponse'>);
      case 'raReset':
        return this.raReset();
      case 'raSetHardcore':
        return this.raSetHardcore(params as Params<'raSetHardcore'>);
      case 'raFetchLeaderboardEntries':
        return this.raFetchLeaderboardEntries(params as Params<'raFetchLeaderboardEntries'>);
      default:
        throw new Error(`Unknown emulator core command: ${command}`);
    }
  }

  // --- Commands -----------------------------------------------------------

  protected async init(params: Params<'init'>): Promise<void> {
    this.wasm = await instantiateWasm(params.wasmUrl);
    this.allocateScratch();
    this.ra = new RetroAchievements(params.rcheevosModuleUrl);
    this.ra.onPush = () => this.flushRetroAchievements();
  }

  protected createSim(): SimHandle {
    const pointer = this.wasm.CreateSim();
    if (pointer === 0) {
      throw new Error('Emulator core could not allocate a simulation.');
    }
    // Legacy VB color is applied by the renderer, so the core composites
    // eye-packed brightness. A VBC-capable core exposes a separate RGB555
    // transport buffer and the renderer switches formats automatically.
    this.wasm.SetAnaglyph(pointer, VB_EYE_PACKED_LEFT, VB_EYE_PACKED_RIGHT);
    this.sims.set(pointer, {
      pointer,
      displayMode: VB_DEFAULT_DISPLAY_MODE,
      samples: this.wasm.GetExtSamples(pointer),
      cartRom: 0,
      cartRomSize: 0,
      cartRam: 0,
      cartRamSize: 0,
      keys: 0,
      vbcHardware: true,
      linkOrder: 0,
    });
    this.refreshSimPointers();
    return pointer;
  }

  /**
   * Release a simulation. The vendored shim's Sim.delete() is an empty stub,
   * so every closed emulator leaked its state struct and cartridge buffers;
   * we free them properly.
   */
  protected deleteSim(params: Params<'deleteSim'>): void {
    const sim = this.requireSim(params.sim);
    if (this.live?.pointer === sim.pointer) {
      this.stopLiveProfiler();
    }
    sim.renderer?.dispose();
    sim.videoTap = undefined;
    if (sim.cartRom !== 0) {
      this.wasm.Realloc(sim.cartRom, 0);
    }
    if (sim.cartRam !== 0) {
      this.wasm.Realloc(sim.cartRam, 0);
    }
    this.wasm.Realloc(sim.pointer, 0);
    if (sim.pointer === this.raSimPointer) {
      this.ra.detach();
      this.raSimPointer = 0;
    }
    this.sims.delete(params.sim);
    this.keySchedules.delete(params.sim);
    this.editSchedules.delete(params.sim);
    this.lockstepSims.delete(params.sim);
    this.digestPeriods.delete(params.sim);
    this.terminalBuffers.delete(params.sim);
    this.drawnPalettes.delete(sim.pointer);
    this.linkBuffers.delete(params.sim);
    this.linkTransmitBytes.delete(params.sim);
    this.pointerWatches.delete(params.sim);
    this.pointerWrites.delete(params.sim);
    this.cheats.delete(sim.pointer);
    // The mutes go with it rather than being released: the simulation the
    // levels would be given back to is about to be freed.
    this.vsuMutes.delete(sim.pointer);
    this.refreshSimPointers();
  }

  protected attachCanvas(params: Params<'attachCanvas'>): void {
    const sim = this.requireSim(params.sim);
    sim.renderer?.dispose();
    sim.renderer = undefined;
    sim.mainThread = undefined;
    if ('canvas' in params) {
      sim.renderer = new VbRenderer(params.canvas, sim.displayMode);
    } else {
      sim.mainThread = params.mainThread;
    }
    this.present(sim);
  }

  /**
   * Start or stop mirroring this machine's frames to the DOM thread.
   *
   * The picture the worker draws is untouched either way — see `setVideoTap`
   * in `vb-protocol.ts`. Stopping drops the pool, so whichever buffers are in
   * flight are simply not taken back.
   */
  protected setVideoTap(params: Params<'setVideoTap'>): void {
    const sim = this.requireSim(params.sim);
    sim.videoTap = params.tap;
  }

  /**
   * Accept a video buffer back after the page has finished with it.
   *
   * Either pool may be the one it came from, and they are told apart by the
   * presentation the page hands back — the same tag that decides whether a
   * buffer is stale, which is what makes a canvas swapped mid-flight safe.
   */
  returnVideoFrame(message: VideoFrameReturn): void {
    const returned = message.videoFrame;
    if (returned.pixels.byteLength !== VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4) {
      return;
    }
    const sim = this.sims.get(returned.sim);
    for (const pool of [sim?.mainThread, sim?.videoTap]) {
      if (pool?.presentation === returned.presentation) {
        pool.buffers.push(returned.pixels);
        return;
      }
    }
  }

  protected setDisplayMode(params: Params<'setDisplayMode'>): void {
    const sim = this.requireSim(params.sim);
    sim.displayMode = params.mode;
    sim.renderer?.setDisplayMode(params.mode);
  }

  /**
   * The presented frame as a PNG, optionally composed to settings of its own.
   *
   * Asked for the mode already on screen at its own size, this is the live
   * renderer's own drawing buffer and costs nothing. Asked for anything else,
   * the frame is drawn again into a renderer this worker keeps for the purpose
   * — never by retuning the live one, which would flicker the picture through
   * the change and resize the canvas out from under the page.
   */
  protected async capture(
    params: Params<'capture'>,
  ): Promise<ArrayBuffer> {
    const sim = this.requireSim(params.sim);
    if (!sim.renderer) {
      throw new Error('The emulator has nothing to capture yet.');
    }
    const scale = Math.max(1, Math.floor(params.scale ?? 1));
    if (!params.mode && scale === 1) {
      return sim.renderer.capture();
    }

    const mode = params.mode ?? sim.displayMode;
    if (!this.screenshotRenderer) {
      this.screenshotRenderer = new VbRenderer(
        new OffscreenCanvas(mode.width, mode.height), mode);
    } else {
      this.screenshotRenderer.setDisplayMode(mode);
    }
    const colorMode = this.isVbcColorOutput(sim);
    if (colorMode) {
      this.wasm.GetColorPixels!(sim.pointer);
    } else {
      this.wasm.GetPixels(sim.pointer);
    }
    this.screenshotRenderer.present(
      new Uint8Array(
        this.wasm.memory.buffer,
        colorMode
          ? this.wasm.GetExtColorPixels!(sim.pointer)
          : this.wasm.GetExtPixels(sim.pointer),
        VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4,
      ),
      colorMode,
    );
    return this.screenshotRenderer.capture(scale);
  }

  protected setCartRom(params: Params<'setCartRom'>): void {
    const sim = this.requireSim(params.sim);
    const previous = sim.cartRom;
    const pointer = this.copyIntoCore(params.rom);
    if (
      this.wasm.vbSetCartROM(sim.pointer, pointer, params.rom.byteLength) !== 0
    ) {
      this.wasm.Realloc(pointer, 0);
      throw new Error(
        'Emulator core rejected the ROM. Its size must be a power of two.',
      );
    }
    if (previous !== 0) {
      this.wasm.Realloc(previous, 0);
    }
    sim.cartRom = pointer;
    sim.cartRomSize = params.rom.byteLength;
    // A different cartridge invalidates any history of the previous one,
    // and starts its frames over.
    this.clearRewind();
    this.framesRun = 0;
    this.forgetSchedules();
  }

  protected setCartRam(params: Params<'setCartRam'>): void {
    const sim = this.requireSim(params.sim);
    const previous = sim.cartRam;
    const pointer = this.copyIntoCore(params.ram);
    if (
      this.wasm.vbSetCartRAM(sim.pointer, pointer, params.ram.byteLength) !== 0
    ) {
      this.wasm.Realloc(pointer, 0);
      throw new Error(
        'Emulator core rejected the save RAM. Its size must be a power of two.',
      );
    }
    if (previous !== 0) {
      this.wasm.Realloc(previous, 0);
    }
    sim.cartRam = pointer;
    sim.cartRamSize = params.ram.byteLength;
  }

  protected getCartRam(params: Params<'getCartRam'>): ArrayBuffer {
    const sim = this.requireSim(params.sim);
    if (sim.cartRam === 0 || sim.cartRamSize === 0) {
      return new ArrayBuffer(0);
    }
    // Clamped rather than trusted: a caller asking for more than there is
    // would otherwise read whatever the core keeps after the buffer.
    const length = params.length === undefined
      ? sim.cartRamSize
      : Math.max(0, Math.min(params.length, sim.cartRamSize));
    return new Uint8Array(
      this.wasm.memory.buffer,
      sim.cartRam,
      length,
    ).slice().buffer;
  }

  /**
   * The save window's size, and how far into it the game has written.
   *
   * The scan walks the untouched tail in the ordinary case, which is a few
   * million word comparisons over a 16 MiB window. That is why this is a
   * question and not an event: it is cheap enough to ask when a save is
   * written or a panel is opened, and far too expensive to ask every tick.
   */
  protected cartRamInfo(params: Params<'cartRamInfo'>): { size: number; used: number } {
    const sim = this.requireSim(params.sim);
    if (sim.cartRam === 0 || sim.cartRamSize === 0) {
      return { size: 0, used: 0 };
    }
    const ram = new Uint8Array(
      this.wasm.memory.buffer,
      sim.cartRam,
      sim.cartRamSize,
    );
    return { size: sim.cartRamSize, used: saveRamHighWater(ram) };
  }

  protected setHardwareMode(params: Params<'setHardwareMode'>): boolean {
    const sim = this.requireSim(params.sim);
    // A Phase-4 binary has VBC hardware permanently present. Keep that bundled
    // binary usable until build-vbc.mjs replaces it: report what the core can
    // actually do, so the UI never claims to be an original VB while the VCU
    // is still visible.
    if (!this.wasm.SetHardwareMode) {
      sim.vbcHardware = true;
      return true;
    }
    sim.vbcHardware = params.vbc;
    this.wasm.SetHardwareMode(sim.pointer, params.vbc ? 1 : 0);
    return sim.vbcHardware;
  }

  protected reset(params: Params<'reset'>): void {
    const sim = this.requireSim(params.sim);
    this.wasm.vbReset(sim.pointer);
    this.rearmLiveProfiler(sim.pointer);
    this.flushAudio();
    this.framesRun = 0;
    this.forgetSchedules();
    if (sim.pointer === this.raSimPointer) {
      this.ra.reset();
      this.flushRetroAchievements();
    }
  }

  /**
   * Discard audio that has been produced but not played yet.
   *
   * The worklet holds up to VB_AUDIO_BUFFER_COUNT filled buffers, and only
   * drains them while the audio context is running — so a machine whose state
   * jumps while suspended has its last fraction of a second of sound waiting to
   * play the moment it resumes, which is heard as the old state briefly playing
   * over the new one. The flush travels the same port as the audio itself, so
   * it lands after everything stale and before anything fresh.
   */
  protected flushAudio(): void {
    this.audioPort.postMessage({ flush: true });
  }

  protected setKeys(params: Params<'setKeys'>): void {
    const sim = this.requireSim(params.sim);
    sim.keys = params.keys;
    this.wasm.vbSetKeys(sim.pointer, params.keys);
  }

  /**
   * Book a controller mask against the frame it belongs to.
   *
   * The handle rather than the pointer is the key: this is scheduling on
   * behalf of whoever is driving the simulation, and it has to work before
   * that frame is anywhere near being emulated.
   */
  protected queueKeys(params: Params<'queueKeys'>): void {
    this.requireSim(params.sim);
    const frame = Math.trunc(params.frame);
    if (frame < this.framesRun) {
      throw new Error(
        `Frame ${frame} has already been emulated; the machine is at ${this.framesRun}.`,
      );
    }
    if (frame > this.framesRun + Worker.MAX_SCHEDULED_FRAMES) {
      throw new Error(
        `Frame ${frame} is more than ${Worker.MAX_SCHEDULED_FRAMES} frames ahead of ${this.framesRun}.`,
      );
    }

    let schedule = this.keySchedules.get(params.sim);
    if (!schedule) {
      schedule = new Map();
      this.keySchedules.set(params.sim, schedule);
    }
    schedule.set(frame, params.keys);
  }

  /**
   * Book writes against the frame they belong to.
   *
   * Bounded and refused exactly as `queueKeys` is, and for the same reasons:
   * see there. Booked edits accumulate rather than replace, so two windows
   * that both aim something at one frame both get their way — and in the same
   * order, because a channel delivers in the order it was sent.
   */
  protected queueEdits(params: Params<'queueEdits'>): void {
    this.requireSim(params.sim);
    const frame = Math.trunc(params.frame);
    if (frame < this.framesRun) {
      throw new Error(
        `Frame ${frame} has already been emulated; the machine is at ${this.framesRun}.`,
      );
    }
    if (frame > this.framesRun + Worker.MAX_SCHEDULED_FRAMES) {
      throw new Error(
        `Frame ${frame} is more than ${Worker.MAX_SCHEDULED_FRAMES} frames ahead of ${this.framesRun}.`,
      );
    }
    if (params.edits.length === 0) {
      return;
    }

    let schedule = this.editSchedules.get(params.sim);
    if (!schedule) {
      schedule = new Map();
      this.editSchedules.set(params.sim, schedule);
    }
    const booked = schedule.get(frame);
    if (booked) {
      booked.push(...params.edits);
    } else {
      schedule.set(frame, [...params.edits]);
    }
  }

  /**
   * Make the writes booked for the frame about to run, and forget the
   * bookings now behind us.
   *
   * Before the frame rather than after, so that a cheat switched on at frame
   * N is in force *for* frame N in both windows — the alternative leaves the
   * two disagreeing about that one frame, which is all a digest needs to see.
   *
   * A frame that was missed is not skipped: anything still booked at or below
   * the current frame is applied on the way past. Under lockstep no frame can
   * be missed at all, but stepping and rewinding both move the count in ways
   * a booking cannot see coming, and a poke that silently never happened
   * would be worse than one that happened a frame late.
   */
  protected applyScheduledEdits(): void {
    if (this.editSchedules.size === 0) {
      return;
    }
    for (const [handle, schedule] of this.editSchedules) {
      const sim = this.sims.get(handle);
      if (!sim) {
        this.editSchedules.delete(handle);
        continue;
      }
      // Oldest first: two writes to one address have to land in the order
      // they were booked, whichever frames they were booked against.
      const due = [...schedule.keys()].filter(frame => frame <= this.framesRun).sort();
      for (const frame of due) {
        for (const edit of schedule.get(frame) ?? []) {
          this.applyEdit(sim, edit);
        }
        schedule.delete(frame);
      }
      if (schedule.size === 0) {
        this.editSchedules.delete(handle);
      }
    }
  }

  /** One booked write, by the same route the unscheduled command takes. */
  protected applyEdit(sim: SimState, edit: ScheduledEdit): void {
    if (edit.kind === 'cheats') {
      if (edit.codes.length > 0) {
        this.cheats.set(sim.pointer, edit.codes);
      } else {
        this.cheats.delete(sim.pointer);
      }
      return;
    }
    for (let i = 0; i < edit.bytes.length; i++) {
      this.wasm.vbWrite(
        sim.pointer,
        (edit.address + i) >>> 0,
        VbDataType.U8,
        edit.bytes[i] & 0xff,
      );
    }
  }

  /**
   * Drop every booking, because the frame numbers they name are about to stop
   * meaning anything.
   *
   * Whoever is driving a lockstep session has to know that happened, so this
   * also clears the waiting state rather than leaving a stale one behind.
   */
  protected forgetSchedules(): void {
    this.keySchedules.clear();
    // Booked writes name frame numbers too, and a poke aimed at frame 200 of
    // a run that is over would land on frame 200 of the next one.
    this.editSchedules.clear();
    // The frame count goes back to zero with them, and the progress report is
    // spaced out by comparing against the last one — so a stale mark from
    // thousands of frames ago would silence it until the count caught up, and
    // whoever is booking input would be left with no idea where the machine
    // is.
    this.lastProgressReport = 0;
    this.reportAwaitingInput(false, []);
  }

  protected setLockstep(params: Params<'setLockstep'>): void {
    this.requireSim(params.sim);
    if (params.enabled) {
      this.lockstepSims.add(params.sim);
    } else {
      this.lockstepSims.delete(params.sim);
      // Nothing is holding for it any more; let the loop notice at once
      // rather than at the next frame it happens to check.
      this.keySchedules.delete(params.sim);
      // Writes booked for a session that has ended have nobody to agree with.
      this.editSchedules.delete(params.sim);
    }
  }

  /**
   * Which simulations under lockstep have nothing booked for this frame.
   *
   * Empty is the answer for every solo session, and the loop pays one empty
   * set lookup for it.
   */
  protected simsMissingInput(): SimHandle[] {
    if (this.lockstepSims.size === 0) {
      return [];
    }
    const missing: SimHandle[] = [];
    for (const handle of this.lockstepSims) {
      if (!this.keySchedules.get(handle)?.has(this.framesRun)) {
        missing.push(handle);
      }
    }
    return missing;
  }

  /**
   * Say how far the machine has got, for whoever is booking input for it.
   *
   * Silent unless something is: a solo emulator has no schedule to keep
   * filled and nobody listening.
   */
  protected reportProgress(): void {
    if (this.lockstepSims.size === 0) {
      return;
    }
    if (this.framesRun - this.lastProgressReport < Worker.PROGRESS_REPORT_FRAMES) {
      return;
    }
    this.lastProgressReport = this.framesRun;
    this.emit({ event: 'progress', payload: { frame: this.framesRun } });
  }

  /** Say that the loop started or stopped waiting, but only on the change. */
  protected reportAwaitingInput(waiting: boolean, sims: SimHandle[]): void {
    if (waiting === this.awaitingInput) {
      return;
    }
    this.awaitingInput = waiting;
    this.emit({
      event: 'awaitingInput',
      payload: { waiting, frame: this.framesRun, sims },
    });
  }

  /**
   * Hand every simulation the mask booked for the frame about to run, and
   * forget the bookings that are now behind us.
   *
   * A frame with nothing booked keeps the mask it already has, which is what
   * makes a held button hold: a schedule only has to carry the changes.
   */
  protected applyScheduledKeys(): void {
    if (this.keySchedules.size === 0) {
      return;
    }
    for (const [handle, schedule] of this.keySchedules) {
      const sim = this.sims.get(handle);
      if (!sim) {
        this.keySchedules.delete(handle);
        continue;
      }
      const keys = schedule.get(this.framesRun);
      if (keys !== undefined) {
        sim.keys = keys;
        this.wasm.vbSetKeys(sim.pointer, keys);
      }
      for (const frame of schedule.keys()) {
        if (frame <= this.framesRun) {
          schedule.delete(frame);
        }
      }
    }
  }

  /**
   * Connect two simulations over the link port.
   *
   * The core walks from one simulation to its peer directly, which is why a
   * linked pair has to share a session: the pointers are only meaningful
   * inside one WebAssembly instance.
   *
   * `order` says which end of the cable the named simulation is, and the peer
   * takes the other end. It is what keeps two windows emulating the same pair
   * — see {@link orderedSims}.
   */
  protected setPeer(params: Params<'setPeer'>): void {
    const sim = this.requireSim(params.sim);
    if (params.peer === 0) {
      const previous = this.wasm.vbGetPeer(sim.pointer);
      this.wasm.vbSetPeer(sim.pointer, 0);
      sim.linkOrder = 0;
      const other = previous === 0 ? undefined : this.sims.get(previous);
      if (other) {
        this.wasm.vbSetPeer(other.pointer, 0);
        other.linkOrder = 0;
      }
      // The order the core is handed the simulations in has just changed, so
      // the history taken under the old one no longer lines up with it.
      this.refreshSimPointers();
      this.clearRewind();
      return;
    }

    const peer = this.requireSim(params.peer);
    if (peer.pointer === sim.pointer) {
      throw new Error('A simulation cannot be linked to itself.');
    }
    this.wasm.vbSetPeer(sim.pointer, peer.pointer);
    this.wasm.vbSetPeer(peer.pointer, sim.pointer);
    sim.linkOrder = params.order === 2 ? 2 : 1;
    peer.linkOrder = sim.linkOrder === 1 ? 2 : 1;
    this.refreshSimPointers();

    // The pair now snapshots as a unit, so any history of them apart is
    // no longer restorable.
    this.clearRewind();
  }

  /**
   * The simulations in the order `Emulate` is handed them.
   *
   * Which is not the order they were created in, and that is the whole point.
   * One `Emulate` call advances a linked pair together, and what it produces
   * depends on the order the pair arrives in: the same two machines, the same
   * cartridge and the same input emulate the cable *differently* the other way
   * round. A window plays its own machine and a mirror of its partner's, so
   * the two windows build their pairs in opposite orders — and within a second
   * of a game actually using the cable they had come apart, which the digest
   * check ended the session over. See `tests/link-order-probe.mjs`.
   *
   * So a pair travels in cable order, which both windows agree on, rather than
   * in the order each of them happened to create its machines. Sorting is
   * stable and every unpaired simulation carries 0, so a session with no cable
   * in it is handed exactly what it always was.
   */
  protected orderedSims(): SimState[] {
    const sims = [...this.sims.values()];
    return sims.some(sim => sim.linkOrder !== 0)
      ? sims.sort((a, b) => a.linkOrder - b.linkOrder)
      : sims;
  }

  protected setVolume(params: Params<'setVolume'>): void {
    this.wasm.SetVolume(this.requireSim(params.sim).pointer, params.volume);
  }

  protected setPanning(params: Params<'setPanning'>): void {
    this.wasm.SetPanning(this.requireSim(params.sim).pointer, params.panning);
  }

  protected run(): void {
    if (this.emulating) {
      return;
    }
    this.emulating = true;
    this.graceAll();
    // Start the speed window here, or the first report after a pause would
    // divide the chunks since resuming by however long the pause lasted.
    this.lastSpeedReport = 0;
    this.chunksSinceReport = 0;
    this.drive();
  }

  protected suspend(): void {
    this.emulating = false;
    // Nothing is being emulated, and a stale rate is worse than none.
    this.emit({
      event: 'speed',
      payload: { framesPerSecond: 0, ratio: 0, requested: this.speed },
    });
  }

  // --- State snapshots ----------------------------------------------------

  /**
   * The whole simulation is one flat struct, so a snapshot is a copy of it.
   * Verified byte-exact on replay, see scripts/savestate-probe.mjs.
   */
  protected snapshot(sim: SimState): ArrayBuffer {
    return new Uint8Array(
      this.wasm.memory.buffer,
      sim.pointer,
      this.wasm.vbSizeOf(),
    ).slice().buffer;
  }

  /**
   * Restore a snapshot, then repair the pointers it embeds.
   *
   * The struct holds three absolute pointers into core memory — cart RAM,
   * cart ROM and the audio sample buffer — which belong to whichever
   * simulation and session produced the snapshot. The setters are pure
   * assignments (the vendored shim, not the core, owns freeing), so
   * re-applying our own is safe. The sample pointer needs no repair here
   * because the drive loop re-arms it before every chunk.
   */
  protected restore(sim: SimState, state: ArrayBuffer): void {
    const size = this.wasm.vbSizeOf();
    if (state.byteLength !== size) {
      throw new Error(
        `This save state is ${state.byteLength} bytes but this emulator core uses ${size}. ` +
          'It was probably made with a different version.',
      );
    }
    this.restoreFrom(sim, new Uint8Array(state));
  }

  protected restoreFrom(sim: SimState, state: Uint8Array): void {
    const size = this.wasm.vbSizeOf();
    new Uint8Array(this.wasm.memory.buffer, sim.pointer, size).set(state);

    if (sim.cartRom !== 0) {
      this.wasm.vbSetCartROM(sim.pointer, sim.cartRom, sim.cartRomSize);
    }
    if (sim.cartRam !== 0) {
      this.wasm.vbSetCartRAM(sim.pointer, sim.cartRam, sim.cartRamSize);
    }
    this.wasm.vbSetSamples(
      sim.pointer,
      sim.samples,
      VbDataType.F32,
      VB_SAMPLES_PER_BUFFER,
    );
    // Save states contain the whole core struct, including Phase-5's hardware
    // model flag. The current emulator selection wins over the state file.
    this.wasm.SetHardwareMode?.(sim.pointer, sim.vbcHardware ? 1 : 0);
    // And including the execute callback, so a state older than the live
    // profiler would switch it off. See `rearmLiveProfiler`.
    this.rearmLiveProfiler(sim.pointer);
    // The write and read watches are in the struct for the same reason and go
    // the same way — measured, see `tests/restore-callback-probe.mjs`. Every
    // capture built on them is silently deaf from here on otherwise, and a
    // rewind step comes through here too, so it is not only a loaded state
    // that does it: the VSU panel's shadow simply stops being told anything,
    // and goes on showing whichever channels it last saw switched on.
    this.updateWriteWatch(sim.pointer);
    this.updateReadWatch(sim.pointer);
  }

  // --- Profile recording ----------------------------------------------------

  /**
   * What is being recorded, if anything.
   *
   * Only one at a time, and only for one simulation: a recording is a
   * developer deliberately capturing a run to profile, not something the
   * emulator does by default.
   */
  protected recording?: {
    pointer: number;
    state: ArrayBuffer;
    chunks: number;
    keys: [number, number][];
    lastMask: number;
  };

  protected startProfileRecording(params: Params<'startProfileRecording'>): void {
    const sim = this.requireSim(params.sim);
    this.recording = {
      pointer: sim.pointer,
      state: this.snapshot(sim),
      chunks: 0,
      // The mask in force at chunk zero, so a replay starts pressing what was
      // being pressed rather than nothing.
      keys: [[0, sim.keys]],
      lastMask: sim.keys,
    };
  }

  protected stopProfileRecording(params: Params<'stopProfileRecording'>): Recording {
    const recording = this.recording;
    this.recording = undefined;
    if (!recording || recording.pointer !== this.requireSim(params.sim).pointer) {
      throw new Error('That simulation is not being recorded.');
    }
    return { state: recording.state, chunks: recording.chunks, keys: recording.keys };
  }

  /**
   * Note what a chunk is about to be emulated with.
   *
   * Called once per chunk, before it runs. Input only ever changes between
   * chunks — `setKeys` arrives as a message and the drive loop is what runs
   * them — so the mask at this point is exactly what the whole chunk saw, and
   * writing down only the changes keeps a long session small.
   */
  protected recordChunk(sims: SimState[]): void {
    const recording = this.recording;
    if (!recording) {
      return;
    }
    const sim = sims.find(candidate => candidate.pointer === recording.pointer);
    if (!sim) {
      // The simulation went away underneath the recording.
      this.recording = undefined;
      return;
    }
    if (sim.keys !== recording.lastMask) {
      recording.keys.push([recording.chunks, sim.keys]);
      recording.lastMask = sim.keys;
    }
    recording.chunks++;
  }

  /**
   * Replay a recording, following every instruction, and return the call tree.
   *
   * On the recording's own simulation, borrowed for the duration: its current
   * state is put aside, the recording is restored over it, the replay runs,
   * and the state is put back. The simulation is stopped throughout, which is
   * fine for an export — the developer asked for a profile and waits a few
   * seconds for it.
   *
   * A scratch simulation would be tidier but is **not faithful**: a state
   * restored into a different simulation executes differently, because the
   * core keeps a copy of the cartridge pointer that `vbSetCartROM` does not
   * reach, and the stale one then reads through a buffer belonging to
   * somewhere else. Restored into the simulation it came from, the pointer is
   * already right and the replay reproduces the run exactly — measured both
   * ways in `tests/emulator/replay-probe.mjs`.
   */
  protected replayProfile(params: Params<'replayProfile'>): ProfileResult {
    const sim = this.requireSim(params.sim);
    const { recording } = params;
    if (recording.state.byteLength !== this.wasm.vbSizeOf()) {
      throw new Error('That recording was made with a different emulator core.');
    }

    const rom = this.u8(sim.cartRom, sim.cartRomSize);
    const kinds = decodeRomKinds(rom);
    // The program counter runs in the cartridge's top-of-memory mirror, so an
    // address has to come back to a ROM offset before it can be looked up.
    const mask = sim.cartRomSize - 1;
    const powerOfTwo = sim.cartRomSize > 0 && (sim.cartRomSize & mask) === 0;
    const collector = new VesProfileCollector();

    const slot = installVbCallback(this.wasm, (unused, address) => {
      const offset = powerOfTwo
        ? (address >>> 0) & mask
        : ((address >>> 0) & 0x00ffffff) % sim.cartRomSize;
      collector.push(address >>> 0, kinds[offset >> 1] as VesInstructionKind);
      return 0;
    }, VB_EXECUTE_CALLBACK_ARITY);

    // What the simulation was doing before it was borrowed, to be put back
    // whatever happens below.
    const borrowed = this.snapshot(sim);
    const keysBefore = sim.keys;
    const started = Date.now();

    try {
      this.restoreFrom(sim, new Uint8Array(recording.state));
      this.wasm.vbSetExecuteCallback(sim.pointer, slot);

      const keys = new Map(recording.keys);
      const sims = this.wasm.Realloc(0, 4);
      const clocks = this.wasm.Realloc(0, 4);
      this.u32(sims, 1)[0] = sim.pointer;
      try {
        for (let chunk = 0; chunk < recording.chunks; chunk++) {
          const pressed = keys.get(chunk);
          if (pressed !== undefined) {
            this.wasm.vbSetKeys(sim.pointer, pressed);
          }
          // Samples are rewound per chunk exactly as the drive loop does, so
          // the core never runs past the end of the buffer it was given.
          this.wasm.vbSetSamples(sim.pointer, sim.samples, VbDataType.F32, VB_SAMPLES_PER_BUFFER);
          if (!this.drainClocks(sims, 1, clocks, VB_CLOCKS_PER_BUFFER, () => undefined)) {
            // The state the recording was made from no longer runs. Better a
            // profile that says so than one that hangs the worker producing it.
            throw new Error(
              `The replay stopped making progress at chunk ${chunk} of ${recording.chunks}.`,
            );
          }
        }
      } finally {
        this.wasm.Realloc(sims, 0);
        this.wasm.Realloc(clocks, 0);
      }
    } finally {
      // Back to whatever this simulation should have had — the live profiler,
      // breakpoints, or nothing — rather than to nothing regardless.
      releaseVbCallback(this.wasm, slot);
      this.updateExecuteWatch(sim.pointer);
      this.restoreFrom(sim, new Uint8Array(borrowed));
      this.wasm.vbSetKeys(sim.pointer, keysBefore);
      // The replay left history describing a run that is being discarded.
      this.clearRewind();
    }

    const nodes = collector.finish();
    return {
      nodes: nodes.map(node => ({
        parent: node.parent,
        address: node.address,
        selfSamples: node.selfSamples,
        totalSamples: node.totalSamples,
      })),
      instructions: collector.sampleCount,
      overflows: collector.overflows,
      resets: collector.resetCount,
      elapsedMs: Date.now() - started,
    };
  }

  // --- Live profiling -------------------------------------------------------

  /**
   * How many frames of history a live profile keeps by default.
   *
   * A hundred frames is two seconds of play: long enough that a peak is a
   * spike in the game rather than one unlucky frame, short enough that a
   * change made in the game shows up in the averages while the developer is
   * still looking at the panel.
   */
  protected static readonly LIVE_PROFILE_WINDOW = 100;

  /** The most history a caller may ask for, so a panel cannot ask for a leak. */
  protected static readonly LIVE_PROFILE_WINDOW_MAX = 1000;

  /**
   * The profile being collected as the game runs, if any.
   *
   * One simulation at a time. Watching two would double a cost that is already
   * the most expensive thing the inspectors can ask for, and there is one
   * panel looking at one machine.
   */
  protected live?: {
    pointer: number;
    /**
     * What to do with one instruction, closed over everything below.
     *
     * A function on the state rather than the callback itself, because the
     * core has one execute callback per simulation and two things want it —
     * see `updateExecuteWatch`. The shared callback calls this; the hot path
     * is still one call and the properties it closes over.
     */
    step(pc: number): void;
    collector: VesLiveProfileCollector;
    /** What every instruction in the cartridge does, decoded once at the start. */
    kinds: Uint8Array;
    romSize: number;
    mask: number;
    powerOfTwo: boolean;
    /**
     * What was left of the clock budget when the last instruction was seen.
     *
     * The difference between this and the word now is what that instruction
     * cost, which is the whole reason the profile is in clocks rather than in
     * instructions counted.
     */
    left: number;
    /**
     * Pictures the VIP takes over one drawing — `FRMCYC` plus one — and how
     * many of them have gone by since the last frame was closed.
     */
    cycle: number;
    pictures: number;
    /**
     * Whether the core reported a frame during the chunk being emulated.
     *
     * A game that has not switched its display on — a boot, a crash, a ROM
     * that never gets that far — never completes a VIP frame, so the break
     * that normally ends a profiled frame never comes and the panel would sit
     * empty for ever. The chunk is a frame's worth of clocks either way, so
     * one is closed at the end of a chunk that saw none.
     */
    framed: boolean;
    /**
     * A view of the core's countdown word.
     *
     * Rebuilt whenever the drive loop hands the callback a new budget, because
     * a heap that has grown detaches every view over the old buffer and this
     * one is read on every instruction — where checking for that would be a
     * per-instruction cost paid for something that happens twice a session.
     */
    clocks: Uint32Array;
  };

  /**
   * Follow every instruction, or stop following them.
   *
   * The callback installed here is the most expensive thing in the worker: it
   * crosses into JavaScript once per emulated instruction. Measured at 1.54x
   * on a loop that calls a subroutine every seventh instruction — which is
   * about as call-heavy as code gets — leaving the core running at three times
   * the speed of the machine it emulates, where it needs one. Affordable, in
   * other words, but only because it is off unless the panel showing the
   * result is on screen. See `tests/live-profile-probe.mjs`.
   */
  protected setLiveProfiler(params: Params<'setLiveProfiler'>): void {
    const sim = this.requireSim(params.sim);
    if (!params.enabled) {
      // Only this machine's profile: a panel switching off the one it was
      // watching must not take down a profile of the other machine of a
      // linked pair that something else has since started.
      if (this.live?.pointer === sim.pointer) {
        this.stopLiveProfiler();
      }
      return;
    }
    if (this.live?.pointer === sim.pointer) {
      return;
    }
    // Only one at a time, and a second request means the panel moved to
    // another machine rather than that it wants both.
    this.stopLiveProfiler();
    if (sim.cartRom === 0 || sim.cartRomSize === 0) {
      throw new Error('There is no cartridge to profile.');
    }

    const window = Math.min(
      Math.max(1, Math.floor(params.window ?? Worker.LIVE_PROFILE_WINDOW)),
      Worker.LIVE_PROFILE_WINDOW_MAX,
    );
    const mask = sim.cartRomSize - 1;
    const live = {
      pointer: sim.pointer,
      step: (unused: number) => { /* replaced below, once `live` exists */ },
      collector: new VesLiveProfileCollector(window),
      kinds: decodeRomKinds(this.u8(sim.cartRom, sim.cartRomSize)),
      romSize: sim.cartRomSize,
      mask,
      powerOfTwo: sim.cartRomSize > 0 && (sim.cartRomSize & mask) === 0,
      left: 0,
      cycle: 1,
      pictures: 0,
      framed: false,
      clocks: this.u32(this.clocksPointer),
    };

    // The hot path of the whole feature, and written like one: everything it
    // needs is a property of the object captured here, and the only call it
    // makes is the collector's own step.
    live.step = (pc: number) => {
      const remaining = live.clocks[0];
      const spent = live.left - remaining;
      live.left = remaining;
      // The program counter runs in the cartridge's top-of-memory mirror, so
      // an address has to come back to a ROM offset before the decoded table
      // can be indexed with it — exactly as the replay does.
      const offset = live.powerOfTwo
        ? pc & live.mask
        : (pc & 0x00ffffff) % live.romSize;
      live.collector.step(pc, live.kinds[offset >> 1] as VesInstructionKind, spent);
    };

    this.live = live;
    this.updateExecuteWatch(sim.pointer);
  }

  protected stopLiveProfiler(): void {
    const live = this.live;
    if (!live) {
      return;
    }
    this.live = undefined;
    // The simulation may already be gone — this also runs from deleteSim —
    // in which case there is nothing left to take the callback off. The
    // callback itself is shared and stays installed if breakpoints still
    // want it, which is what `updateExecuteWatch` decides.
    if (this.sims.has(live.pointer)) {
      this.updateExecuteWatch(live.pointer);
    }
  }

  /**
   * Put the callback back after something has overwritten it.
   *
   * The execute callback lives in the simulation's own struct, so restoring a
   * state that was captured before profiling was switched on silently switches
   * it off again — a rewind step or a loaded save state would leave the panel
   * showing a window that never moves. Measured rather than assumed: an
   * installed callback survives a snapshot taken after it, and is cleared by
   * one taken before it.
   */
  protected rearmLiveProfiler(pointer: number): void {
    this.updateExecuteWatch(pointer);
  }

  // --- Stopping -----------------------------------------------------------

  /**
   * Install or remove the shared per-instruction callback.
   *
   * One callback, two customers: the live profiler wants to be told what each
   * instruction cost, and breakpoints want the chance to refuse one. The core
   * has a single execute callback per simulation, so they cannot each have
   * their own — and whichever installed second would silently switch the
   * other off, which is the bug this exists to make impossible.
   *
   * It is the one callback that runs on every instruction rather than on
   * every access of some kind, so it goes on only while somebody wants it and
   * comes straight off again when nobody does.
   */
  protected updateExecuteWatch(pointer: SimHandle): void {
    const stop = this.stops.get(pointer);
    const wanted = this.live?.pointer === pointer
      || (stop !== undefined && (stop.points.size > 0 || stop.pending !== undefined));
    if (!wanted) {
      this.wasm.vbSetExecuteCallback(pointer, 0);
      return;
    }

    if (this.executeCallbackSlot === 0) {
      this.executeCallbackSlot = installVbCallback(
        this.wasm,
        (watchedSimPointer, address) => {
          const pc = address >>> 0;
          const live = this.live;
          if (live !== undefined && live.pointer === watchedSimPointer) {
            live.step(pc);
          }
          return this.shouldStop(watchedSimPointer, pc) ? 1 : 0;
        },
        VB_EXECUTE_CALLBACK_ARITY,
      );
    }
    this.wasm.vbSetExecuteCallback(pointer, this.executeCallbackSlot);
  }

  /**
   * Whether the machine should stop before running this instruction.
   *
   * Returning true refuses the instruction: the core abandons the `Emulate`
   * call there and then, leaving the program counter on it, so what is
   * reported is an instruction about to run rather than one that just did.
   * Nothing is suspended from in here — that would be suspending the worker
   * from inside the core — so the decision is written down and the drain loop
   * acts on it.
   */
  protected shouldStop(pointer: SimHandle, address: number): boolean {
    const stop = this.stops.get(pointer);
    if (stop === undefined || this.stopped !== undefined) {
      return false;
    }
    if (stop.grace > 0) {
      stop.grace--;
      return false;
    }

    const pending = stop.pending;
    if (pending !== undefined && (pending.at === undefined || pending.at === address)) {
      stop.pending = undefined;
      this.stopped = { pointer, address, reason: pending.reason };
      return true;
    }
    if (stop.points.has(address)) {
      this.stopped = { pointer, address, reason: StopReason.BREAKPOINT };
      return true;
    }
    return false;
  }

  /** The stop record for a simulation, made on first use. */
  protected stopFor(pointer: SimHandle): SimStop {
    let stop = this.stops.get(pointer);
    if (stop === undefined) {
      stop = { points: new Set<number>(), grace: 0 };
      this.stops.set(pointer, stop);
    }
    return stop;
  }

  protected setBreakpoints(params: Params<'setBreakpoints'>): void {
    const sim = this.requireSim(params.sim);
    const stop = this.stopFor(sim.pointer);
    stop.points = new Set(params.addresses.map(address => address >>> 0));
    if (stop.points.size === 0 && stop.pending === undefined) {
      this.stops.delete(sim.pointer);
    }
    this.updateExecuteWatch(sim.pointer);
  }

  protected runTo(params: Params<'runTo'>): void {
    const sim = this.requireSim(params.sim);
    const stop = this.stopFor(sim.pointer);
    stop.pending = { reason: StopReason.CURSOR, at: params.address >>> 0 };
    this.updateExecuteWatch(sim.pointer);
  }

  /**
   * Run one instruction, from a machine that is stopped.
   *
   * Driven from here rather than by starting the drive loop, the way
   * `stepFrame` is: the budget is a frame's worth of clocks, which is far
   * more than any one instruction needs and still bounded for one that turns
   * out to be an interrupt being taken. A machine that somehow does not
   * report a second instruction in all that time is stuck, and says so the
   * same way a stalled one does.
   */
  protected stepInstruction(params: Params<'stepInstruction'>): void {
    const sim = this.requireSim(params.sim);
    const sims = this.orderedSims();
    if (sims.length === 0) {
      return;
    }
    const stop = this.stopFor(sim.pointer);
    stop.pending = { reason: StopReason.STEP };
    // The instruction being stood on is reported before it runs, so one
    // sighting has to go past for the machine to move at all.
    stop.grace = 1;
    this.updateExecuteWatch(sim.pointer);

    this.drainClocks(
      this.simsPointer, sims.length, this.clocksPointer, VB_CLOCKS_PER_BUFFER,
      () => {
        if (this.gamePakInterrupts.size > 0) {
          this.serviceGamePakInterrupts();
        }
      });

    if (this.stopped === undefined) {
      // A frame of clocks without a second instruction is not a step that
      // went wrong, it is a machine that has stopped advancing.
      stop.pending = undefined;
      this.updateExecuteWatch(sim.pointer);
      this.stall();
      return;
    }
    this.settleStop();
    this.presentAll();
  }

  /**
   * Suspend and say where, if the callback refused an instruction.
   *
   * Called wherever a drain has just finished, because that is where it is
   * safe to: inside the callback the core is mid-instruction, and suspending
   * the worker from there would unwind through `Emulate`.
   */
  protected settleStop(): boolean {
    const stopped = this.stopped;
    if (stopped === undefined) {
      return false;
    }
    this.stopped = undefined;
    this.pendingClocks = 0;
    this.suspend();

    // A one-shot that has sprung leaves nothing behind, so the callback comes
    // back off unless breakpoints still want it.
    const stop = this.stops.get(stopped.pointer);
    if (stop !== undefined && stop.points.size === 0 && stop.pending === undefined) {
      this.stops.delete(stopped.pointer);
    }
    this.updateExecuteWatch(stopped.pointer);

    this.emit({
      event: 'stopped',
      payload: {
        sim: stopped.pointer,
        address: stopped.address,
        reason: stopped.reason,
      },
    });
    return true;
  }

  /**
   * Let every stopped machine past the instruction it is standing on.
   *
   * Run from `run()`, because otherwise resuming from a breakpoint would trip
   * over the same breakpoint before anything moved, and the machine would
   * appear frozen with the button doing nothing.
   */
  protected graceAll(): void {
    for (const stop of this.stops.values()) {
      stop.grace = Math.max(stop.grace, 1);
    }
  }

  /**
   * Close a profiled frame, taking what the instruction now running has cost
   * so far with it.
   *
   * A picture is not always a frame. The VIP can be told to draw every second
   * one, or every fourth — `FRMCYC`, which is VUEngine's `__FRAME_CYCLE` and
   * which plenty of games set: Mario's Tennis and Virtual WarZone both do. A
   * game that draws every second picture has two pictures' worth of time to
   * prepare each drawing, and it uses them that way: it works through one and
   * waits through the next. Profiled per picture, that is a timeline of every
   * second bar at zero and a budget line at half the time the game actually
   * has. So the register decides where a frame ends, and the budget the
   * figures are shares of goes up with it.
   *
   * The view is rebuilt here rather than trusted: this runs from the drive
   * loop's between-callback, after work that can allocate in core memory, and
   * a view over a heap that has since grown reads nothing at all.
   *
   * @param force close whatever has accumulated, whatever the register says.
   *     The drive loop does this for a machine that reports no pictures at all
   *     — a boot, a crash, a display that was never switched on.
   */
  protected endLiveFrame(force = false): void {
    const live = this.live;
    if (!live) {
      return;
    }
    live.framed = true;
    if (!force) {
      live.cycle = this.frameCycle(live.pointer);
      if (++live.pictures < live.cycle) {
        // The end of a picture, not of a frame. Nothing is charged and
        // nothing is closed: the clocks stay on `live.left` and reach the
        // collector with the next instruction, or with the picture that does
        // end the frame.
        return;
      }
    }
    live.pictures = 0;
    live.clocks = this.u32(this.clocksPointer);
    const remaining = live.clocks[0];
    live.collector.endFrame(live.left - remaining);
    live.left = remaining;
  }

  /**
   * How many pictures the VIP draws a frame in, from `FRMCYC`.
   *
   * Read every picture rather than once: a game can change it, and a value
   * read before the game has set it would group frames wrongly for as long as
   * the profile lasted. Four bits, and one more than the field — zero means
   * every picture. See `VipRegister.FRMCYC`, which is the panel's name for the
   * same halfword.
   */
  protected frameCycle(pointer: number): number {
    const frmcyc = this.wasm.vbRead(pointer, VIP_FRMCYC, VbDataType.U16);
    return (frmcyc & 0x0f) + 1;
  }

  protected readLiveProfile(
    params: Params<'readLiveProfile'>,
  ): LiveProfileSnapshot | undefined {
    const sim = this.requireSim(params.sim);
    return this.live?.pointer === sim.pointer
      // A frame's worth of clocks is a picture's worth for each picture the
      // VIP takes over a drawing — see `endLiveFrame`.
      ? this.live.collector.snapshot(
        VB_CLOCKS_PER_BUFFER * this.live.cycle, params.pin)
      : undefined;
  }

  // --- Save States -------------------------------------------------

  protected saveState(params: Params<'saveState'>): ArrayBuffer {
    return this.snapshot(this.requireSim(params.sim));
  }

  protected loadState(params: Params<'loadState'>): void {
    const sim = this.requireSim(params.sim);
    this.restore(sim, params.state);
    // Loading lands somewhere unrelated to the rewind history.
    this.clearRewind();
    this.flushAudio();
    this.presentRestored(sim);
    // Whatever the engine had counted — a hit count, a delta memory
    // reference — described the run that was just abandoned for this one.
    if (sim.pointer === this.raSimPointer) {
      this.ra.reset();
      this.flushRetroAchievements();
    }
  }

  // --- Speed and stepping -------------------------------------------------

  protected setSpeed(params: Params<'setSpeed'>): void {
    if (!(params.speed > 0)) {
      throw new Error(
        `Emulation speed must be greater than zero, got ${params.speed}.`,
      );
    }
    this.speed = params.speed;
    this.pendingClocks = 0;
  }

  // Advance one frame while suspended, for frame-by-frame inspection.
  protected stepFrame(): void {
    const sims = this.orderedSims();
    if (sims.length === 0) {
      return;
    }

    const missing = this.simsMissingInput();
    if (missing.length > 0) {
      // Stepping past input that has not arrived would put this machine ahead
      // of its peer just as surely as running would.
      this.reportAwaitingInput(true, missing);
      return;
    }
    this.reportAwaitingInput(false, []);

    this.captureRewindEntry(sims);
    this.applyScheduledKeys();
    this.applyScheduledEdits();

    // A frame is ~400000 clocks; allow a generous margin before giving up
    // so a simulation that never raises the flag cannot spin forever.
    let remaining = VB_CLOCKS_PER_BUFFER * 4;
    let framed = false;
    while (!framed && remaining > 0) {
      const budget = Math.min(remaining, VB_CLOCKS_PER_BUFFER);
      remaining -= budget;
      const advanced = this.drainClocks(
        this.simsPointer, sims.length, this.clocksPointer, budget, () => {
          if (this.gamePakInterrupts.size > 0) {
            this.serviceGamePakInterrupts();
          }
          for (const sim of sims) {
            if (this.wasm.GetBreaks(sim.pointer) & VbBreak.FRAME) {
              this.applyCheats(sim.pointer);
              this.applyVsuMutes(sim.pointer);
              if (sim.pointer === this.raSimPointer) {
                this.ra.doFrame();
              }
              this.wasm.GetPixels(sim.pointer);
              framed = true;
            }
          }
        });
      if (!advanced) {
        // Stepping is done from a suspended emulator, so there is no drive
        // loop to stop — but the machine is just as stuck, and the step that
        // was asked for is not going to happen.
        this.stall();
        break;
      }
    }

    // Counted like any other frame: a schedule keyed on the frame number is
    // only usable if stepping moves that number too.
    if (framed) {
      this.framesRun++;
    }

    this.presentAll();
    this.flushRetroAchievements();
  }

  // --- Rewind -------------------------------------------------------------

  protected setRewind(params: Params<'setRewind'>): void {
    this.rewind.enabled = params.enabled;
    this.rewind.granularity = Math.max(1, Math.floor(params.granularity));
    this.rewind.budgetBytes = Math.max(0, params.budgetBytes);
    this.rewind.frames = 0;
    this.clearRewind();
  }

  // Drop the history. The next capture re-seeds the mirrors.
  protected clearRewind(): void {
    this.rewind.entries = [];
    this.rewind.mirrors = [];
    this.rewind.bytes = 0;
  }

  protected liveState(sim: SimState): Uint8Array {
    return new Uint8Array(
      this.wasm.memory.buffer,
      sim.pointer,
      this.wasm.vbSizeOf(),
    );
  }

  protected captureRewindEntry(sims: SimState[]): void {
    if (
      !this.rewind.enabled ||
      this.rewind.budgetBytes === 0 ||
      sims.length === 0
    ) {
      return;
    }

    // The first capture, or one after the session changed shape, has
    // nothing to diff against and only seeds the mirrors.
    if (this.rewind.mirrors.length !== sims.length) {
      this.rewind.entries = [];
      this.rewind.bytes = 0;
      this.rewind.mirrors = sims.map(sim => this.liveState(sim).slice());
      return;
    }

    const entry: Uint8Array[] = [];
    let added = 0;
    for (let i = 0; i < sims.length; i++) {
      const live = this.liveState(sims[i]);
      const delta = encodeDelta(this.rewind.mirrors[i], live, this.runScratch);
      entry.push(delta);
      added += delta.length;
      this.rewind.mirrors[i].set(live);
    }

    this.rewind.entries.push(entry);
    this.rewind.bytes += added;

    while (
      this.rewind.bytes > this.rewind.budgetBytes &&
      this.rewind.entries.length > 0
    ) {
      const dropped = this.rewind.entries.shift()!;
      for (const delta of dropped) {
        this.rewind.bytes -= delta.length;
      }
    }
  }

  /**
   * Walk the history back by up to `count` entries.
   *
   * Only the state that is landed on reaches the simulations and the screen:
   * the deltas in between are pure XOR passes over the mirrors, so a caller
   * asking for several entries at once pays for one restore and one present
   * rather than that many.
   *
   * Unlike loadState, this does not reset the achievement engine — rewind
   * lands here up to several times a second while held, and resetting that
   * often would be noisy for what it buys. A hit count the engine had already
   * counted for the run being rewound past can therefore read a little stale
   * immediately after; it settles again as soon as normal play resumes and
   * evaluates a few frames. Softcore, and rewind is disabled outright under
   * hardcore, so nothing here is a fairness question — see
   * RETROACHIEVEMENTS_CLIENT in vb-constants.ts.
   */
  protected rewindStep(params: Params<'rewindStep'>): number {
    const sims = this.orderedSims();
    if (this.rewind.mirrors.length !== sims.length) {
      return 0;
    }

    const requested = Math.max(1, Math.floor(params.count ?? 1));
    let applied = 0;
    while (applied < requested && this.rewind.entries.length > 0) {
      const entry = this.rewind.entries.pop()!;
      for (let i = 0; i < sims.length; i++) {
        this.rewind.bytes -= entry[i].length;
        applyDelta(this.rewind.mirrors[i], entry[i]);
      }
      applied++;
    }

    if (applied === 0) {
      return 0;
    }

    for (let i = 0; i < sims.length; i++) {
      this.restoreFrom(sims[i], this.rewind.mirrors[i]);
      this.presentRestored(sims[i]);
    }
    return applied;
  }

  // --- Inspection ---------------------------------------------------------

  /**
   * Read through the CPU's view of memory rather than poking at the state
   * struct, so mirroring, mapped hardware registers and unmapped holes all
   * behave the way the running program sees them.
   */
  /**
   * Copy a rectangle out of the core's composited framebuffer.
   *
   * GetPixels refreshes it from the current VIP state first, so the result is
   * what the simulation would be showing right now rather than whatever was
   * last presented. Requests are clipped to the screen so a caller cannot read
   * past the end of the buffer.
   */
  protected readPixels(params: Params<'readPixels'>): ArrayBuffer {
    const sim = this.requireSim(params.sim);

    const left = Math.max(0, Math.min(params.x, VB_SCREEN_WIDTH));
    const top = Math.max(0, Math.min(params.y, VB_SCREEN_HEIGHT));
    const width = Math.max(0, Math.min(params.width, VB_SCREEN_WIDTH - left));
    const height = Math.max(0, Math.min(params.height, VB_SCREEN_HEIGHT - top));

    const out = new Uint8Array(width * height * 4);
    if (width === 0 || height === 0) {
      return out.buffer;
    }

    this.wasm.GetPixels(sim.pointer);
    const source = new Uint8Array(
      this.wasm.memory.buffer,
      this.wasm.GetExtPixels(sim.pointer),
      VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4,
    );

    for (let row = 0; row < height; row++) {
      const from = ((top + row) * VB_SCREEN_WIDTH + left) * 4;
      out.set(source.subarray(from, from + width * 4), row * width * 4);
    }
    return out.buffer;
  }

  /**
   * Reduce the framebuffer to one value per eye and cell for the immersion
   * halo: brightness in legacy mode, or an actual RGB555 color in VBC mode.
   *
   * Not the arithmetic mean. A Virtual Boy frame is mostly black, so a mean is
   * dominated by the black and a cell holding one bright sprite on an empty
   * background reads as almost dark. Weighting each pixel by the light it
   * contributes (`sum of b squared / sum of b`) reports the brightness of the
   * light *in* the cell instead, which is what a halo wants and what a real
   * Ambilight measures. VBC applies the same principle using the brightest RGB
   * component as the color weight. An empty cell stays black.
   *
   * A few samples per cell rather than every pixel: the answer feeds a wide
   * kernel on the other side that will smooth it anyway. The step is chosen
   * from the cell size, so a fine grid still reads every pixel it has to.
   */
  protected readBackdrop(params: Params<'readBackdrop'>): Result<'readBackdrop'> {
    const sim = this.requireSim(params.sim);
    const max = Worker.MAX_BACKDROP_CELLS;
    const columns = Math.max(1, Math.min(Math.floor(params.columns) || 1, max));
    const rows = Math.max(1, Math.min(Math.floor(params.rows) || 1, max));

    const cells = columns * rows;
    const out = new Uint8Array(cells * 4);
    const colorMode = this.isVbcColorOutput(sim);
    if (colorMode) {
      this.wasm.GetColorPixels!(sim.pointer);
    } else {
      this.wasm.GetPixels(sim.pointer);
    }
    const source = new Uint8Array(
      this.wasm.memory.buffer,
      colorMode
        ? this.wasm.GetExtColorPixels!(sim.pointer)
        : this.wasm.GetExtPixels(sim.pointer),
      VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4,
    );

    const leftSum = new Float64Array(cells);
    const leftLight = new Float64Array(cells);
    const rightSum = new Float64Array(cells);
    const rightLight = new Float64Array(cells);
    // VBC needs a light-weighted color rather than one brightness. Keeping
    // black out of the denominator lets a small lit sprite color its cell,
    // matching the legacy b²/b reduction below.
    const leftRgb = colorMode ? new Float64Array(cells * 3) : undefined;
    const rightRgb = colorMode ? new Float64Array(cells * 3) : undefined;
    // About four samples across a cell on each axis. Rounded rather than
    // floored so a cell a few pixels wide still steps, instead of falling back
    // to reading every pixel of the frame for an answer that cannot use them.
    const step = Math.max(1, Math.min(4, Math.round(
      Math.min(VB_SCREEN_WIDTH / columns, VB_SCREEN_HEIGHT / rows) / 4)));

    for (let y = 0; y < VB_SCREEN_HEIGHT; y += step) {
      const row = Math.min(rows - 1, Math.floor((y * rows) / VB_SCREEN_HEIGHT));
      for (let x = 0; x < VB_SCREEN_WIDTH; x += step) {
        const cell =
          row * columns + Math.min(columns - 1, Math.floor((x * columns) / VB_SCREEN_WIDTH));
        const at = (y * VB_SCREEN_WIDTH + x) * 4;
        if (colorMode) {
          const leftWord = source[at] | (source[at + 1] << 8);
          const rightWord = source[at + 2] | (source[at + 3] << 8);
          const lr = leftWord & 31;
          const lg = (leftWord >> 5) & 31;
          const lb = (leftWord >> 10) & 31;
          const rr = rightWord & 31;
          const rg = (rightWord >> 5) & 31;
          const rb = (rightWord >> 10) & 31;
          const lw = Math.max(lr, lg, lb);
          const rw = Math.max(rr, rg, rb);
          leftLight[cell] += lw;
          rightLight[cell] += rw;
          leftRgb![cell * 3] += lr * lw;
          leftRgb![cell * 3 + 1] += lg * lw;
          leftRgb![cell * 3 + 2] += lb * lw;
          rightRgb![cell * 3] += rr * rw;
          rightRgb![cell * 3 + 1] += rg * rw;
          rightRgb![cell * 3 + 2] += rb * rw;
        } else {
          const l = source[at];
          const r = source[at + 1];
          leftSum[cell] += l;
          leftLight[cell] += l * l;
          rightSum[cell] += r;
          rightLight[cell] += r * r;
        }
      }
    }

    for (let cell = 0; cell < cells; cell++) {
      if (colorMode) {
        const averageWord = (rgb: Float64Array, weight: number) => {
          if (weight === 0) {
            return 0;
          }
          const r = Math.round(rgb[cell * 3] / weight);
          const g = Math.round(rgb[cell * 3 + 1] / weight);
          const b = Math.round(rgb[cell * 3 + 2] / weight);
          return r | (g << 5) | (b << 10);
        };
        const leftWord = averageWord(leftRgb!, leftLight[cell]);
        const rightWord = averageWord(rightRgb!, rightLight[cell]);
        out[cell * 4] = leftWord & 0xff;
        out[cell * 4 + 1] = leftWord >> 8;
        out[cell * 4 + 2] = rightWord & 0xff;
        out[cell * 4 + 3] = rightWord >> 8;
      } else {
        out[cell * 4] = leftSum[cell] > 0 ? Math.round(leftLight[cell] / leftSum[cell]) : 0;
        out[cell * 4 + 1] = rightSum[cell] > 0 ? Math.round(rightLight[cell] / rightSum[cell]) : 0;
        out[cell * 4 + 3] = 0xff;
      }
    }
    return { pixels: out.buffer, colorMode };
  }

  /** A complete packed frame for a screenshot rendered on the DOM thread. */
  protected readFrame(params: Params<'readFrame'>): Result<'readFrame'> {
    const sim = this.requireSim(params.sim);
    const colorMode = this.isVbcColorOutput(sim);
    if (colorMode) {
      this.wasm.GetColorPixels!(sim.pointer);
    } else {
      this.wasm.GetPixels(sim.pointer);
    }
    const source = new Uint8Array(
      this.wasm.memory.buffer,
      colorMode
        ? this.wasm.GetExtColorPixels!(sim.pointer)
        : this.wasm.GetExtPixels(sim.pointer),
      VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4,
    );
    const pixels = new Uint8Array(source.byteLength);
    pixels.set(source);
    return { pixels: pixels.buffer, colorMode };
  }

  /**
   * Show the machine's current video state without advancing it.
   *
   * The same recomposite a restored state gets — see presentRestored, which
   * says why the last composited image would otherwise stand.
   */
  protected refreshFrame(params: Params<'refreshFrame'>): void {
    this.presentRestored(this.requireSim(params.sim));
  }

  protected readMemory(params: Params<'readMemory'>): ArrayBuffer {
    const sim = this.requireSim(params.sim);
    if (params.length > Worker.MAX_MEMORY_WINDOW) {
      // Refused rather than truncated: a short buffer would be read as
      // data by the caller and misinterpreted as corrupt memory.
      throw new Error(
        `Memory read of ${params.length} bytes exceeds the ${Worker.MAX_MEMORY_WINDOW} byte limit.`,
      );
    }
    const length = Math.max(0, params.length);
    const out = new Uint8Array(length);
    for (let i = 0; i < length; i++) {
      out[i] =
        this.wasm.vbRead(
          sim.pointer,
          (params.address + i) >>> 0,
          VbDataType.U8,
        ) & 0xff;
    }
    return out.buffer;
  }

  protected writeMemory(params: Params<'writeMemory'>): void {
    const sim = this.requireSim(params.sim);
    const data = new Uint8Array(params.data);
    for (let i = 0; i < data.length; i++) {
      this.wasm.vbWrite(
        sim.pointer,
        (params.address + i) >>> 0,
        VbDataType.U8,
        data[i],
      );
    }
  }

  /**
   * Hash everything the emulated program can see.
   *
   * Registers first, then the three regions a program can write: VRAM, WRAM,
   * and whatever cartridge RAM this simulation was given. Explicitly *not*
   * the state struct a save state copies — that also carries absolute
   * pointers and an address-hashed cache, both of which differ between two
   * instances of the core that are running identically, so hashing them would
   * report desyncs that are not real. `tests/determinism-probe.mjs` is where
   * that was measured.
   *
   * Read through the core's own bus rather than out of the struct, so this
   * says what the program sees and needs no knowledge of the layout. It costs
   * about fifty thousand reads, which is why this is something a session does
   * every so often rather than every frame.
   */
  protected stateDigest(
    params: Params<'stateDigest'>,
  ): { frame: number; digest: number } {
    return {
      frame: this.framesRun,
      digest: this.digestOf(this.requireSim(params.sim)),
    };
  }

  protected setDigestPeriod(params: Params<'setDigestPeriod'>): void {
    this.requireSim(params.sim);
    const frames = Math.max(0, Math.trunc(params.frames));
    if (frames === 0) {
      this.digestPeriods.delete(params.sim);
    } else {
      this.digestPeriods.set(params.sim, frames);
    }
  }

  /** Take the digests that are due at the frame just finished. */
  protected reportDigests(): void {
    if (this.digestPeriods.size === 0) {
      return;
    }
    for (const [handle, period] of this.digestPeriods) {
      const sim = this.sims.get(handle);
      if (!sim) {
        this.digestPeriods.delete(handle);
        continue;
      }
      if (this.framesRun % period !== 0) {
        continue;
      }
      this.emit({
        event: 'digest',
        payload: { sim: handle, frame: this.framesRun, digest: this.digestOf(sim) },
      });
    }
  }

  /** The digest itself. See `stateDigest` in `vb-protocol.ts` for what is in it. */
  protected digestOf(sim: SimState): number {
    // FNV-1a over 32-bit words. Not a checksum anyone has to trust against an
    // adversary — just a cheap way to notice two machines have parted.
    let digest = 0x811c9dc5;
    const mix = (value: number): void => {
      digest = Math.imul(digest ^ (value >>> 0), 0x01000193) >>> 0;
    };

    mix(this.wasm.vbGetProgramCounter(sim.pointer));
    for (let i = 0; i < 32; i++) {
      mix(this.wasm.vbGetProgramRegister(sim.pointer, i));
    }
    for (const index of Worker.DIGEST_SYSTEM_REGISTERS) {
      mix(this.wasm.vbGetSystemRegister(sim.pointer, index));
    }

    const regions: [number, number][] = [
      [VB_VRAM_BASE, VB_VRAM_SIZE],
      [VB_WRAM_BASE, VB_WRAM_SIZE],
      [VB_CART_RAM_BASE, sim.cartRamSize],
    ];
    for (const [base, length] of regions) {
      for (let at = 0; at < length; at += 4) {
        mix(this.wasm.vbRead(sim.pointer, base + at, VbDataType.S32));
      }
    }

    return digest;
  }

  protected readRegisters(
    params: Params<'readRegisters'>,
  ): Registers {
    const sim = this.requireSim(params.sim);
    const program: number[] = [];
    for (let i = 0; i < 32; i++) {
      program.push(this.wasm.vbGetProgramRegister(sim.pointer, i) >>> 0);
    }

    const system: Record<string, number> = {};
    for (const [name, index] of Object.entries(VbSystemRegister)) {
      if (typeof index === 'number') {
        system[name] = this.wasm.vbGetSystemRegister(sim.pointer, index) >>> 0;
      }
    }

    return {
      pc: this.wasm.vbGetProgramCounter(sim.pointer) >>> 0,
      program,
      system,
    };
  }

  /**
   * Start or stop watching the terminal port.
   *
   * The core has no way to trap a single address, so capturing means a
   * callback on every CPU write — of which a game performs a great many. That
   * is why this is opt-in and driven by whether anything is actually
   * listening, rather than left on.
   */
  protected setTerminalCapture(
    params: Params<'setTerminalCapture'>,
  ): void {
    const sim = this.requireSim(params.sim);
    if (params.enabled) {
      this.terminalBuffers.set(sim.pointer, []);
    } else {
      this.terminalBuffers.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
  }

  /**
   * Start or stop watching the link port.
   *
   * Same cost as terminal capture, and driven the same way: on only while
   * something is listening, which here means only while a rumble pack is
   * plugged in.
   */
  protected setLinkCapture(params: Params<'setLinkCapture'>): void {
    const sim = this.requireSim(params.sim);
    if (params.enabled) {
      this.linkBuffers.set(sim.pointer, []);
    } else {
      this.linkBuffers.delete(sim.pointer);
      this.linkTransmitBytes.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
  }

  /**
   * Start or stop watching the address an ESSound cartridge listens on.
   *
   * Same cost and the same opt-in as the captures above: on only while there
   * is something to play, which the DOM side decides by looking for the audio
   * files beside the ROM.
   */
  protected setEsSoundCapture(params: Params<'setEsSoundCapture'>): void {
    const sim = this.requireSim(params.sim);
    if (params.enabled) {
      this.esSoundBuffers.set(sim.pointer, []);
    } else {
      this.esSoundBuffers.delete(sim.pointer);
    this.gamePakInterrupts.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
  }

  /**
   * Start or stop watching the cartridge's save region.
   *
   * The only capture that turns on both watches, because a save is written and
   * then read back and half of that is not a picture of anything.
   */
  /** The core's memory as bytes, remade only when the core has grown it. */
  protected bytes(): Uint8Array {
    if (this.memoryBytes === undefined || this.memoryBytes.buffer !== this.wasm.memory.buffer) {
      this.memoryBytes = new Uint8Array(this.wasm.memory.buffer);
    }
    return this.memoryBytes;
  }

  protected setSramCapture(params: Params<'setSramCapture'>): void {
    const sim = this.requireSim(params.sim);
    if (params.writes || params.reads) {
      this.sramDirections.set(sim.pointer, { writes: params.writes, reads: params.reads });
      if (!this.sramBuffers.has(sim.pointer)) {
        this.sramBuffers.set(sim.pointer, []);
      }
    } else {
      this.sramDirections.delete(sim.pointer);
      this.sramBuffers.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
    this.updateReadWatch(sim.pointer);
  }

  /**
   * Follow a pointer variable, or stop following one.
   *
   * Rides on the same write watching as the captures above, and is just as
   * opt-in for the same reason.
   */
  protected setPointerWatch(params: Params<'setPointerWatch'>): void {
    const sim = this.requireSim(params.sim);
    const address = params.address >>> 0;
    if (address !== 0) {
      this.pointerWatches.set(sim.pointer, address);
      this.pointerWrites.set(sim.pointer, []);
    } else {
      this.pointerWatches.delete(sim.pointer);
      this.pointerWrites.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
  }

  /**
   * Set the writes to repeat every frame, or stop repeating any.
   *
   * Unlike the captures above this needs no write watching: nothing is being
   * observed, the writes are simply made again after each frame.
   */
  protected setCheats(params: Params<'setCheats'>): void {
    const sim = this.requireSim(params.sim);
    if (params.codes.length > 0) {
      this.cheats.set(sim.pointer, params.codes);
    } else {
      this.cheats.delete(sim.pointer);
    }
  }

  /**
   * Repeat one simulation's cheat writes.
   *
   * A byte at a time, little-endian like the CPU, which is also how
   * writeMemory reaches memory — the core's own vbWrite handles the mirroring
   * and the read-only regions, so a code pointed somewhere unwritable is
   * simply ignored rather than needing checking here.
   */
  protected applyCheats(simPointer: number): void {
    const codes = this.cheats.get(simPointer);
    if (!codes) {
      return;
    }
    for (const code of codes) {
      for (let byte = 0; byte < code.bytes; byte++) {
        this.wasm.vbWrite(
          simPointer,
          (code.address + byte) >>> 0,
          VbDataType.U8,
          (code.value >>> (byte * 8)) & 0xff,
        );
      }
    }
  }

  /**
   * The VSU as it stands, composed from the core's own decoded copy of it,
   * together with how loud its last frame of sound was.
   *
   * Where the core keeps that copy, and why this is not read out of the VSU's
   * address range like every other inspector's memory, is `vb-vsu-layout.ts`;
   * finding it is {@link requireVsuLayout}, which this is the first caller of.
   */
  protected readVsu(params: Params<'readVsu'>): VsuReading {
    const sim = this.requireSim(params.sim);
    const layout = this.requireVsuLayout();
    const map = composeVsuMap(this.wasm, layout, sim.pointer, this.vsuMutes.get(sim.pointer));

    // The machine's own last buffer of sound, which is still sitting in it:
    // one frame, already produced, so the meter costs a pass over it on the
    // polls that ask rather than anything per frame. A machine that is not
    // running has a stale buffer and no output, and reads as silent.
    let peakLeft = 0;
    let peakRight = 0;
    if (this.emulating) {
      const samples = this.f32(sim.samples, VB_SAMPLES_PER_BUFFER * 2);
      for (let i = 0; i < samples.length; i += 2) {
        peakLeft = Math.max(peakLeft, Math.abs(samples[i]));
        peakRight = Math.max(peakRight, Math.abs(samples[i + 1]));
      }
    }
    return { map: map.buffer, peakLeft, peakRight };
  }

  /**
   * Where this core keeps its VSU state, calibrating on the first ask.
   *
   * Calibrating costs a throwaway simulation and a moment of running it, so it
   * happens on demand rather than at startup: nobody who never opens the VSU
   * panel should pay for it. A core it cannot be found in is remembered as the
   * failure it was, so that a panel polling ten times a second does not re-run
   * calibration ten times a second to be told the same thing.
   */
  protected requireVsuLayout(): VsuLayout {
    if (this.vsuLayout === undefined) {
      try {
        this.vsuLayout = calibrateVsuLayout(this.wasm);
      } catch (error) {
        this.vsuLayout = error instanceof Error ? error : new Error(String(error));
      }
    }
    if (this.vsuLayout instanceof Error) {
      throw this.vsuLayout;
    }
    return this.vsuLayout;
  }

  /**
   * Hold channels silent without the game knowing, or let them all sound
   * again.
   *
   * See setVsuMutes in the protocol for why this is the mixer's business and
   * not a write to the VSU. The state is dropped entirely when nothing is
   * muted, which is what keeps the drive loop's check to a map lookup.
   */
  protected setVsuMutes(params: Params<'setVsuMutes'>): void {
    const sim = this.requireSim(params.sim);
    const channels = params.channels & ((1 << VB_VSU_CHANNELS) - 1);
    const state = this.vsuMutes.get(sim.pointer);
    if (channels === 0 && state === undefined) {
      return;
    }
    // Calibrated here as well as in readVsu, so that a core whose VSU cannot
    // be found says so when muting is asked for rather than silently not
    // muting.
    const layout = this.requireVsuLayout();
    const held = state ?? createVsuMuteState();
    // What has just been let out of the mix gets its level back; muting took
    // it away, and nothing else will put it back.
    restoreVsuMutes(this.wasm, layout, sim.pointer, held, held.channels & ~channels);
    held.channels = channels;
    if (channels === 0) {
      this.vsuMutes.delete(sim.pointer);
      this.updateWriteWatch(sim.pointer);
      return;
    }
    this.vsuMutes.set(sim.pointer, held);
    // At once rather than at the next frame break: what the channel is already
    // playing at was written before any of this was asked for, so no write
    // watch will ever carry it past.
    applyVsuMutes(this.wasm, layout, sim.pointer, held);
    this.updateWriteWatch(sim.pointer);
  }

  /** Re-apply the mutes one simulation is under, at a frame break. */
  protected applyVsuMutes(simPointer: number): void {
    const muted = this.vsuMutes.get(simPointer);
    if (muted && this.vsuLayout !== undefined && !(this.vsuLayout instanceof Error)) {
      applyVsuMutes(this.wasm, this.vsuLayout, simPointer, muted);
    }
  }

  /**
   * Start or stop noting which palettes the Color Framebuffer is being painted
   * with. See setDrawnPaletteCapture in the protocol for why nothing that can
   * be polled answers this.
   */
  protected setDrawnPaletteCapture(params: Params<'setDrawnPaletteCapture'>): void {
    const sim = this.requireSim(params.sim);
    if (params.enabled) {
      if (!this.drawnPalettes.has(sim.pointer)) {
        this.drawnPalettes.set(sim.pointer, new Uint8Array(Worker.DRAWN_PALETTE_SET_BYTES));
      }
    } else {
      this.drawnPalettes.delete(sim.pointer);
    }
    this.updateWriteWatch(sim.pointer);
  }

  /**
   * The set since the last call, which this empties, together with every
   * palette the picture is painted with right now. All zero if not enabled.
   * See takeDrawnPalettes in the protocol for why it takes both.
   */
  protected takeDrawnPalettes(params: Params<'takeDrawnPalettes'>): ArrayBuffer {
    const sim = this.requireSim(params.sim);
    const set = this.drawnPalettes.get(sim.pointer);
    if (!set) {
      return new Uint8Array(Worker.DRAWN_PALETTE_SET_BYTES).buffer;
    }
    // Copied before clearing, and copied at all because the result crosses to
    // the DOM thread by transfer — which would detach the live set's memory.
    const taken = set.slice();
    set.fill(0);
    if (this.isVbcColorOutput(sim)) {
      this.addDisplayedPalettes(sim.pointer, taken);
    }
    return taken.buffer;
  }

  /**
   * Add the palettes the left eye's two Color Framebuffer pages are painted
   * with, at every pixel the legacy framebuffer does not leave at shade 0.
   *
   * Both pages, because one is on display while the other is drawn, and which
   * is which changes every frame; in a still scene they agree. Read a word at
   * a time: sixteen legacy pixels are one word of VRAM and four Color Source
   * bytes one word of the aperture, both in columns of 256 rows.
   */
  protected addDisplayedPalettes(simPointer: number, set: Uint8Array): void {
    for (let page = 0; page < 2; page += 1) {
      const legacy = VB_VRAM_BASE + page * Worker.LEGACY_FRAMEBUFFER_PAGE_BYTES;
      const color = VBC_COLOR_FRAMEBUFFER_BASE + page * VBC_COLOR_FRAMEBUFFER_PAGE_BYTES;
      for (let x = 0; x < VB_SCREEN_WIDTH; x += 1) {
        for (let y = 0; y < VB_SCREEN_HEIGHT; y += 16) {
          const shades = this.wasm.vbRead(simPointer, legacy + x * 64 + (y >> 2), VbDataType.S32) >>> 0;
          if (shades === 0) {
            continue;
          }
          for (let quad = 0; quad < 16; quad += 4) {
            const four = (shades >>> (quad * 2)) & 0xff;
            if (four === 0) {
              continue;
            }
            const sources = this.wasm.vbRead(simPointer, color + x * 256 + y + quad, VbDataType.S32) >>> 0;
            for (let pixel = 0; pixel < 4; pixel += 1) {
              if (((four >> (pixel * 2)) & 3) !== 0) {
                const id = (sources >>> (pixel * 8)) & 0xff;
                set[id >> 3] |= 1 << (id & 7);
              }
            }
          }
        }
      }
    }
  }

  // --- RetroAchievements ---------------------------------------------------
  //
  // Every entry point flushes afterwards rather than waiting for the drive
  // loop to get around to it: login and loading happen while the machine is
  // not running yet (`start()` calls raLoadGame before the first run()), and
  // the DOM side should not wait a frame that may never come.

  protected async raLoginPassword(
    params: Params<'raLoginPassword'>,
  ): Promise<Result<'raLoginPassword'>> {
    try {
      return await this.ra.loginPassword(params.username, params.password);
    } finally {
      this.flushRetroAchievements();
    }
  }

  protected async raLoginToken(
    params: Params<'raLoginToken'>,
  ): Promise<Result<'raLoginToken'>> {
    try {
      return await this.ra.loginToken(params.username, params.token);
    } finally {
      this.flushRetroAchievements();
    }
  }

  protected raLogout(): void {
    this.ra.logout();
    this.flushRetroAchievements();
  }

  /**
   * Bind the engine to the simulation asking for a set and start loading it.
   *
   * Rebinding is deliberate rather than additive: RetroAchievements tracks one
   * machine at a time here, so loading a set for a different simulation moves
   * the engine to it, the same way the profiler moves between simulations one
   * at a time.
   */
  protected async raLoadGame(params: Params<'raLoadGame'>): Promise<void> {
    const sim = this.requireSim(params.sim);
    this.raSimPointer = sim.pointer;
    this.ra.attach(this.wasm, sim.pointer);
    try {
      await this.ra.loadGame(params.hash);
    } finally {
      this.flushRetroAchievements();
    }
  }

  protected raUnloadGame(): void {
    this.ra.unloadGame();
    this.flushRetroAchievements();
  }

  protected raProvideResponse(params: Params<'raProvideResponse'>): void {
    this.ra.provideResponse(params.requestId, params.status, params.body);
    this.flushRetroAchievements();
  }

  protected raReset(): void {
    this.ra.reset();
    this.flushRetroAchievements();
  }

  protected raSetHardcore(params: Params<'raSetHardcore'>): void {
    this.ra.setHardcore(params.enabled);
    this.flushRetroAchievements();
  }

  protected async raFetchLeaderboardEntries(
    params: Params<'raFetchLeaderboardEntries'>,
  ): Promise<Result<'raFetchLeaderboardEntries'>> {
    try {
      return await this.ra.fetchLeaderboardEntries(
        params.leaderboardId, params.firstEntry, params.count, params.aroundUser);
    } finally {
      // The server calls this needs answering travel in the same flush.
      this.flushRetroAchievements();
    }
  }

  // Hand over whatever the achievement engine has to say since the last call.
  protected flushRetroAchievements(): void {
    const events = this.ra.takeEvents();
    if (events.length === 0) {
      return;
    }
    this.emit({ event: 'retroAchievements', payload: { events } });
  }

  /**
   * Install the shared write-watching callback on first use, and (re)point a
   * simulation's single callback slot at it for as long as either
   * terminalBuffers or any of the other captures still wants writes for that
   * simulation.
   *
   * The callback returns 0 so the write still happens: this observes rather
   * than stands in for whatever it is watching.
   */
  protected updateWriteWatch(simPointer: number): void {
    const active =
      this.terminalBuffers.has(simPointer) ||
      this.drawnPalettes.has(simPointer) ||
      this.linkBuffers.has(simPointer) ||
      this.esSoundBuffers.has(simPointer) ||
      this.sramDirections.get(simPointer)?.writes === true ||
      this.pointerWatches.has(simPointer) ||
      this.vsuMutes.has(simPointer);
    if (!active) {
      this.wasm.vbSetWriteCallback(simPointer, 0);
      return;
    }

    if (this.writeWatchCallbackSlot === 0) {
      this.writeWatchCallbackSlot = installVbCallback(
        this.wasm,
        (watchedSimPointer, address, type, valuePointer) => {
          const at = address >>> 0;
          // The value is behind a pointer; every write the captures below
          // care about is byte-wide on real hardware, so only the low
          // byte is meaningful regardless of the store's own width. The
          // pointer watch is the exception, and reads all four.
          const byte = this.bytes()[valuePointer];

          if (at === this.pointerWatches.get(watchedSimPointer)) {
            // Narrower stores are not pointer assignments, and reading four
            // bytes of one would report whatever happens to sit beside it.
            if (type === VbDataType.S32) {
              const values = this.pointerWrites.get(watchedSimPointer);
              if (values && values.length < Worker.MAX_POINTER_WRITES) {
                values.push(
                  new DataView(this.wasm.memory.buffer).getUint32(valuePointer, true),
                );
              }
            }
          } else if (isVbcColorFramebuffer(at)) {
            // Second, and not first, although it is far and away the most
            // frequent write watched here — one per drawn pixel. A pointer
            // watch may legitimately be pointed anywhere, region 3 included,
            // and a branch that ran ahead of it would silently swallow it.
            const drawn = this.drawnPalettes.get(watchedSimPointer);
            if (drawn) {
              // The byte on the bus *is* the palette id, so the set fills
              // without anything having to be read back.
              drawn[byte >> 3] |= 1 << (byte & 7);
            }
          } else if (vsuLevelWriteChannel(at) >= 0) {
            // A muted channel's stereo level, on its way to the VSU. The
            // write is let through with its level taken out of it rather
            // than cancelled, because everything else about the write — the
            // bus time it costs, the rest of a wider store — is the
            // machine's business and not the mixer's. See
            // `takeVsuLevelWrite`, which is also where what the game asked
            // for is kept.
            const muted = this.vsuMutes.get(watchedSimPointer);
            if (muted && takeVsuLevelWrite(muted, vsuLevelWriteChannel(at), byte)) {
              // The low byte is the register; a wider store's other bytes
              // land on the padding between VSU registers and are left alone.
              this.bytes()[valuePointer] = 0;
            }
          } else if (at === VB_TERMINAL_PORT) {
            const bytes = this.terminalBuffers.get(watchedSimPointer);
            if (bytes && bytes.length < Worker.MAX_TERMINAL_BYTES) {
              bytes.push(byte);
            }
          } else if (at === VB_LINK_TRANSMIT_PORT) {
            // Stored, not sent: this only says what the next transfer will
            // carry. Tracked unconditionally, so that the byte is already
            // known by the time a start arrives.
            this.linkTransmitBytes.set(watchedSimPointer, byte);
          } else if (
            at === VB_LINK_CONTROL_PORT &&
            (byte & VB_LINK_START) !== 0
          ) {
            const bytes = this.linkBuffers.get(watchedSimPointer);
            if (bytes && bytes.length < Worker.MAX_LINK_BYTES) {
              bytes.push(this.linkTransmitBytes.get(watchedSimPointer) ?? 0);
            }
          } else if (at === VB_ES_SOUND_PORT) {
            // The whole halfword is the command, so unlike the byte-wide
            // ports above this one reads the value itself. A narrower store
            // is not an ESSound command and would report whatever sits beside
            // it, so those are left alone.
            const commands = this.esSoundBuffers.get(watchedSimPointer);
            if (
              commands &&
              commands.length < Worker.MAX_ES_SOUND_COMMANDS &&
              (type === VbDataType.S16 || type === VbDataType.U16)
            ) {
              const command = new DataView(this.wasm.memory.buffer).getUint16(valuePointer, true);
              commands.push(command);
              if (command === ES_SOUND_INIT) {
                // The cartridge's answer to init. Not raised here: this is the
                // middle of a store instruction, and an interrupt is only
                // taken between them.
                this.gamePakInterrupts.add(watchedSimPointer);
              }
            }
          } else if (
            isCartRam(at) &&
            this.sramDirections.get(watchedSimPointer)?.writes === true
          ) {
            this.recordSramAccess(watchedSimPointer, at, byte, true, type);
          }
          return 0;
        },
        VB_WRITE_CALLBACK_ARITY,
      );
    }
    this.wasm.vbSetWriteCallback(simPointer, this.writeWatchCallbackSlot);
  }

  /**
   * Install or remove the read-watching callback.
   *
   * Separate from the write watch because the core keeps the two apart, and
   * because only one capture wants reads at all: writes are how a game says
   * something, reads are only interesting when the question is what a game
   * did with its save.
   *
   * Five arguments where the write callback takes six — the shape is not
   * checked anywhere and a wrong one traps the first time the core calls it,
   * so see `tests/read-callback-probe.mjs` for where that number comes from.
   * The callback returns 0 so the read still happens: this watches the save,
   * it does not answer for it.
   */
  protected updateReadWatch(simPointer: number): void {
    if (this.sramDirections.get(simPointer)?.reads !== true) {
      this.wasm.vbSetReadCallback(simPointer, 0);
      return;
    }

    if (this.readWatchCallbackSlot === 0) {
      this.readWatchCallbackSlot = installVbCallback(
        this.wasm,
        (watchedSimPointer, address, type, valuePointer) => {
          const at = address >>> 0;
          if (isCartRam(at)) {
            this.recordSramAccess(
              watchedSimPointer, at, this.bytes()[valuePointer], false, type);
          }
          return 0;
        },
        VB_READ_CALLBACK_ARITY,
      );
    }
    this.wasm.vbSetReadCallback(simPointer, this.readWatchCallbackSlot);
  }

  /**
   * Note one touch of the save region.
   *
   * The program counter is read here rather than worked out later because here
   * is the only place it is still the instruction that did it — the panel's
   * most useful column, and free everywhere else because save accesses are
   * rare compared to everything else the CPU does.
   */
  protected recordSramAccess(
    simPointer: number,
    address: number,
    value: number,
    write: boolean,
    type: number,
  ): void {
    const runs = this.sramBuffers.get(simPointer);
    if (!runs) {
      return;
    }

    // Only the newest run is ever extended. Two instructions interleaving
    // over the save are two things happening, and a run that could be
    // resumed after something else came in between would say they were one.
    //
    // Everything that can be decided without the program counter is decided
    // first, because reading it is a call into the core and this runs on
    // every access a watched game makes. The step is the other half of the
    // test: the second touch sets the stride, and every one after it has to
    // keep to the same step, so a loop walking the save stays one run and a
    // jump out of it starts another.
    const run = runs[runs.length - 1];
    const step = run === undefined ? 0 : address - run.at;
    const fits =
      run !== undefined &&
      run.write === write &&
      run.type === type &&
      run.values.length < MAX_SRAM_RUN_BYTES &&
      (run.values.length === 1
        ? step >= -MAX_SRAM_STRIDE && step <= MAX_SRAM_STRIDE
        : step === run.stride);

    // Nothing to carry on and nowhere to start: this access is being dropped
    // whatever its program counter is, so it is not worth asking for one.
    if (!fits && runs.length >= MAX_SRAM_RUNS) {
      return;
    }

    const pc = this.wasm.vbGetProgramCounter(simPointer) >>> 0;
    if (fits && run !== undefined && run.pc === pc) {
      if (run.values.length === 1) {
        run.stride = step;
      }
      run.values.push(value);
      run.at = address;
      return;
    }

    if (runs.length >= MAX_SRAM_RUNS) {
      return;
    }
    runs.push({ address, at: address, stride: 0, values: [value], write, type, pc });
  }

  // Hand over whatever the terminal port has produced since the last call.
  protected flushTerminals(): void {
    for (const [handle, bytes] of this.terminalBuffers) {
      if (bytes.length === 0) {
        continue;
      }
      // Chunked so a long burst cannot overflow the argument list.
      let text = '';
      for (let at = 0; at < bytes.length; at += 4096) {
        text += String.fromCharCode(...bytes.slice(at, at + 4096));
      }
      bytes.length = 0;
      this.emit({ event: 'terminal', payload: { sim: handle, text } });
    }
  }

  // Hand over whatever the watched pointer has been assigned since the last call.
  protected flushPointerWrites(): void {
    for (const [handle, values] of this.pointerWrites) {
      if (values.length === 0) {
        continue;
      }
      const address = this.pointerWatches.get(handle) ?? 0;
      this.emit({ event: 'pointerWrite', payload: { sim: handle, address, values: [...values] } });
      values.length = 0;
    }
  }

  /**
   * Take any expansion-port interrupt that is owed and can be taken now.
   *
   * The core has no way to raise one, so this is the V810's own interrupt
   * entry, performed by hand between instructions: save the return state,
   * write the exception code, mask the level and below, and jump to the
   * vector. The conditions for accepting one are the hardware's — not already
   * handling an exception or an NMI, interrupts not disabled, and the level
   * not masked — and a request that cannot be taken yet stays pending rather
   * than being lost, because a ROM often sends ESSound's init before it
   * enables interrupts.
   */
  protected serviceGamePakInterrupts(): void {
    for (const simPointer of this.gamePakInterrupts) {
      const level = VbInterrupt.CRO;
      const psw = this.wasm.vbGetSystemRegister(simPointer, VbSystemRegister.PSW) >>> 0;
      const blocked = (psw & (VbPsw.NP | VbPsw.EP | VbPsw.ID)) !== 0;
      const masked = level < ((psw & VB_PSW_INTERRUPT_LEVEL_MASK) >>> VB_PSW_INTERRUPT_LEVEL_SHIFT);
      if (blocked || masked) {
        continue;
      }

      const ecr = this.wasm.vbGetSystemRegister(simPointer, VbSystemRegister.ECR) >>> 0;
      this.wasm.vbSetSystemRegister(
        simPointer, VbSystemRegister.EIPC, this.wasm.vbGetProgramCounter(simPointer) >>> 0,
      );
      this.wasm.vbSetSystemRegister(simPointer, VbSystemRegister.EIPSW, psw);
      this.wasm.vbSetSystemRegister(
        simPointer, VbSystemRegister.ECR, (ecr & 0xffff0000) | vbInterruptExceptionCode(level),
      );
      // Entry raises the mask to one above this level, which is what the
      // engine's own handler reads back to find the vector it came from.
      const entered = ((psw & ~(VbPsw.AE | VB_PSW_INTERRUPT_LEVEL_MASK))
        | VbPsw.EP | VbPsw.ID | ((level + 1) << VB_PSW_INTERRUPT_LEVEL_SHIFT)) >>> 0;
      this.wasm.vbSetSystemRegister(simPointer, VbSystemRegister.PSW, entered);
      this.wasm.vbSetProgramCounter(simPointer, (VB_INTERRUPT_VECTOR_BASE + (level << 4)) >>> 0);
      this.gamePakInterrupts.delete(simPointer);
    }
  }

  // Hand over whatever the ESSound port has been told since the last call.
  protected flushEsSound(): void {
    for (const [handle, commands] of this.esSoundBuffers) {
      if (commands.length === 0) {
        continue;
      }
      this.emit({ event: 'esSound', payload: { sim: handle, commands: [...commands] } });
      commands.length = 0;
    }
  }

  // Hand over whatever the save region has seen since the last call.
  protected flushSram(): void {
    for (const [handle, runs] of this.sramBuffers) {
      if (runs.length === 0) {
        continue;
      }
      // The bytes become a byte array only here: while a run is growing it is
      // being pushed to, and while it is crossing the wire it is being copied.
      this.emit({
        event: 'sram',
        payload: {
          sim: handle,
          runs: runs.map(run => ({
            address: run.address,
            stride: run.stride,
            values: Uint8Array.from(run.values),
            write: run.write,
            type: run.type,
            pc: run.pc,
          })),
        },
      });
      runs.length = 0;
    }
  }

  // Hand over whatever the link port has sent since the last call.
  protected flushLinks(): void {
    for (const [handle, bytes] of this.linkBuffers) {
      if (bytes.length === 0) {
        continue;
      }
      this.emit({ event: 'link', payload: { sim: handle, bytes: [...bytes] } });
      bytes.length = 0;
    }
  }

  /**
   * Disassemble using the core's own disassembler.
   *
   * Three things about this are not guessable from the exports, and all three
   * were silently wrong before — the panel showed blank mnemonics for years:
   *
   *   - `vbuDisassemble` decodes but writes no text at all; every string slot
   *     it leaves is null. `Disassemble` is the same thing plus the sixteen
   *     options that say how to write the text, and only it produces any.
   *   - The string words in the table are offsets to *pointers*, not to the
   *     text. The upstream wrapper calls that `indirect`, and without it the
   *     mnemonic reads as whatever happens to sit at the wrong address.
   * Both allocations are ours to free.
   *
   * A fourth thing was wrong in the core itself and is fixed there: its
   * `vbuCodeSize` sized a conditional branch at four bytes where its own CPU
   * executes two, which lost the instruction after every branch — a seventh
   * of a real build's listing. The panel still checks for it, because a core
   * built before that fix will produce it and a line that is not an
   * instruction should not be drawn as one; see `annotateDisassembly`.
   */
  protected disassemble(
    params: Params<'disassemble'>,
  ): DisassemblyLine[] {
    const sim = this.requireSim(params.sim);
    const count = Math.max(
      0,
      Math.min(params.count, Worker.MAX_DISASSEMBLY_LINES),
    );

    return this.disassembleBatch(
      sim, params.address >>> 0, count, Math.max(0, Math.floor(params.before ?? 0)));
  }

  /** One call into the core's disassembler, walked as the upstream does. */
  protected disassembleBatch(
    sim: SimState, address: number, count: number, before = 0,
  ): DisassemblyLine[] {
    if (count === 0) {
      return [];
    }
    const dasm = this.wasm.Disassemble(
      ...DISASSEMBLY_STYLE, sim.pointer, address >>> 0, count, before,
    );
    if (dasm === 0) {
      throw new Error(
        `Cannot disassemble at 0x${(address >>> 0).toString(16)}.`,
      );
    }

    const table = this.wasm.Realloc(0, count * 17 * 4);
    this.wasm.GetDasm(table, dasm, count);

    const lines: DisassemblyLine[] = [];
    try {
      const words = this.u32(table, count * 17);
      // The text words are offsets to pointer slots inside the block, so each
      // one is read through, not from.
      const text = (offset: number): string => {
        const pointer = this.u32(dasm + offset, 1)[0];
        return pointer === 0 ? '' : this.readCString(pointer);
      };

      let at = 0;
      for (let line = 0; line < count; line++) {
        const lineAddress = words[at++];
        const codeLength = words[at++];
        const code: number[] = [];
        for (let i = 0; i < codeLength; i++) {
          code.push(words[at++]);
        }
        at += 4 - codeLength;

        const isPC = words[at++] !== 0;
        at++; // the address as text, which we format ourselves
        at += 4; // per-byte text, likewise
        const mnemonic = text(words[at++]);
        const operandCount = words[at++];
        const operands: string[] = [];
        for (let i = 0; i < operandCount; i++) {
          operands.push(text(words[at++]));
        }
        at += 3 - operandCount;

        lines.push({ address: lineAddress, code, isPC, mnemonic, operands });
      }
    } finally {
      this.wasm.Realloc(table, 0);
      this.wasm.Realloc(dasm, 0);
    }

    return lines;
  }

  // Read a NUL-terminated string out of core memory.
  protected readCString(pointer: number): string {
    if (pointer === 0) {
      return '';
    }
    const bytes = new Uint8Array(this.wasm.memory.buffer);
    let end = pointer;
    while (bytes[end] !== 0) {
      end++;
    }
    return new TextDecoder().decode(bytes.subarray(pointer, end));
  }

  // --- Drive loop ---------------------------------------------------------

  protected onAudioBuffersReturned(buffers: ArrayBuffer[]): void {
    // The queue running dry means we could not keep up, so whatever frame
    // is staged is the freshest one we have. Show it rather than hold it.
    if (this.emulating && this.audioQueue.length === 0) {
      this.presentAll();
    }

    for (const buffer of buffers) {
      this.audioQueue.push(new Float32Array(buffer));
    }

    this.drive();
  }

  protected drive(): void {
    if (!this.emulating || this.sims.size === 0) {
      return;
    }

    try {
      while (this.audioQueue.length !== 0) {
        this.emulateOneBuffer();
        if (this.settleStop()) {
          break;
        }
      }
    } catch (error) {
      this.emulating = false;
      this.emit({
        event: 'error',
        payload: {
          message: error instanceof Error ? error.message : String(error),
        },
      });
    } finally {
      // Also on the error path, because what a program printed on its way
      // into trouble is usually the interesting part.
      this.flushTerminals();
      // Before the link bytes, and deliberately: `Rumble::startEffect` stores
      // the spec it was handed before broadcasting anything about it, so
      // flushing in that order is what lets the DOM side attribute a burst to
      // the spec it came from. Two effects started within one tick still
      // arrive as two runs of each, which is as fine-grained as batching gets.
      this.flushPointerWrites();
      // A pack left buzzing by a crashed program would keep buzzing, so what
      // was already sent goes out on that path too.
      this.flushLinks();
      // Likewise a track a crashed program had asked for: the stop it never
      // got round to sending is the one command worth not losing.
      this.flushEsSound();
      // And what a crashed program did with its save, which is often the whole
      // question when it crashed on the way out of one.
      this.flushSram();
      // Unlocks earned on the way into trouble are as real as any other.
      this.flushRetroAchievements();
    }
  }

  /**
   * The speed actually attempted, which is the one asked for until the machine
   * cannot sustain it.
   *
   * Emulation is clocked by the audio: one buffer is produced per call, and the
   * worklet consumes buffers at exactly `VB_FRAME_RATE` a second whatever the
   * speed. A buffer therefore has a fixed slice of wall time to be filled in,
   * and at speed N it must fit N chunks into it.
   *
   * Asking for more than fits does not make emulation any faster — the machine
   * is already flat out — but it does make each buffer take longer, and the
   * display and the audio are both paced by buffers. So an unaffordable ratio
   * costs frame rate and leaves the audio underrunning without buying any
   * speed: at a measured ceiling of 3x, asking for 32x ran the emulation at the
   * same 3x while dropping the picture from 50 fps to under 5. Clamping to what
   * fits keeps the buffers flowing, which keeps both smooth, and the emulation
   * still runs as fast as the machine allows.
   *
   * Only fast forward is clamped. Real time has to stay real time, and slow
   * motion is under 1 to begin with.
   */
  protected affordableSpeed(): number {
    if (this.speed <= 1 || this.chunkCostMs <= 0) {
      return this.speed;
    }
    const budget = Worker.BUFFER_WALL_MS * Worker.EMULATION_BUDGET;
    // Not rounded down to whole chunks: `pendingClocks` carries the remainder
    // between buffers, so a machine good for 2.4 chunks a buffer runs at 2.4x
    // rather than giving up the fraction and running at 2x.
    const affordable = Math.max(1, budget / this.chunkCostMs);
    return Math.min(this.speed, affordable);
  }

  /**
   * Report how fast emulation is actually going, about once a second.
   *
   * Counted rather than calculated: a chunk is one frame of emulated time, so
   * chunks over wall seconds is the achieved rate directly, and it reflects
   * everything in the way — a clamped fast forward, a machine that has fallen
   * behind even at real time, a host that throttled the tab.
   */
  protected reportSpeed(now: number): void {
    if (this.lastSpeedReport === 0) {
      this.lastSpeedReport = now;
      this.chunksSinceReport = 0;
      return;
    }
    const elapsed = now - this.lastSpeedReport;
    if (elapsed < Worker.SPEED_REPORT_MS) {
      return;
    }
    const framesPerSecond = (this.chunksSinceReport * 1000) / elapsed;
    this.lastSpeedReport = now;
    this.chunksSinceReport = 0;
    this.emit({
      event: 'speed',
      payload: {
        framesPerSecond,
        ratio: framesPerSecond / VB_FRAME_RATE,
        requested: this.affordableSpeed(),
      },
    });
  }

  /**
   * Fill one audio buffer, emulating however much time the current speed
   * calls for.
   *
   * Time is only ever emulated in whole chunks, so the core always fills a
   * complete sample buffer and never leaves a stale tail. Fast forward runs
   * several chunks and keeps the last one's audio, which is the usual
   * "one chunk in N" fast-forward sound. Slow motion falls short of a chunk
   * on some buffers and outputs silence for those.
   */
  protected emulateOneBuffer(): void {
    const sims = this.orderedSims();
    this.pendingClocks += VB_CLOCKS_PER_BUFFER * this.affordableSpeed();

    let emulated = false;
    let chunks = 0;
    let stalled = false;
    let waiting: SimHandle[] = [];
    const started = performance.now();
    while (this.pendingClocks >= VB_CLOCKS_PER_BUFFER) {
      waiting = this.simsMissingInput();
      if (waiting.length > 0) {
        // Report from a standstill too, and unconditionally: this is the one
        // moment a session that has fallen behind most needs to hear the
        // frame number, and the spacing rule would swallow it.
        this.lastProgressReport = this.framesRun;
        this.emit({ event: 'progress', payload: { frame: this.framesRun } });
        // The frame is owed, not skipped, so the clock is left unspent. But
        // only one frame's worth of it: a peer that has been away for seconds
        // would otherwise buy a burst of fast forward on its way back, which
        // is the opposite of staying in step.
        this.pendingClocks = Math.min(this.pendingClocks, VB_CLOCKS_PER_BUFFER);
        break;
      }
      this.pendingClocks -= VB_CLOCKS_PER_BUFFER;
      this.applyScheduledKeys();
      this.applyScheduledEdits();
      if (!this.emulateChunk(sims)) {
        stalled = true;
        break;
      }
      this.framesRun++;
      // On the frame boundary, so that two machines asked for the same period
      // take theirs at exactly the same point in the run.
      this.reportDigests();
      chunks++;
      emulated = true;
    }
    this.reportAwaitingInput(waiting.length > 0, waiting);
    this.reportProgress();
    const finished = performance.now();
    if (chunks > 0) {
      const cost = (finished - started) / chunks;
      this.chunkCostMs = this.chunkCostMs === 0
        ? cost
        : this.chunkCostMs * (1 - Worker.CHUNK_COST_WEIGHT)
        + cost * Worker.CHUNK_COST_WEIGHT;
    }
    this.chunksSinceReport += chunks;
    this.reportSpeed(finished);

    const buffer = this.audioQueue.shift()!;
    if (emulated) {
      this.wasm.Mix(this.mixPointer, this.simsPointer, sims.length);
      buffer.set(this.f32(this.mixPointer, MIX_BUFFER_LENGTH));
    } else {
      buffer.fill(0);
    }
    this.audioPort.postMessage(buffer.buffer, [buffer.buffer]);

    // Present once the backlog is down to a single buffer, which is where
    // the staged frame lines up with what is about to be heard.
    if (this.audioQueue.length === 1) {
      this.presentAll();
    }

    // Last, so the buffer above still goes back to the worklet: the audio
    // queue is what drives this loop, and a swallowed buffer would stop it in
    // a way that looks exactly like the hang this is here to prevent.
    if (stalled) {
      this.stall();
    }
  }

  /**
   * Spend a clock budget, and say whether it was spent.
   *
   * `Emulate` takes a budget and returns whenever it has something to report,
   * so draining one means calling it until nothing is left. The catch is that
   * the core can reach a state where it returns having spent *nothing*, for
   * ever — a program that has run off into memory it cannot execute does it,
   * reproducibly, with a linked pair carrying real traffic (see
   * `tests/determinism-probe.mjs`). The loop has no other stopping condition,
   * so without this the worker spins, and the tab with it, silently.
   *
   * `between` runs after every call and is where breaks are collected. The
   * budget is re-read from core memory each time round rather than held in a
   * view, which would go stale if the heap grew underneath it.
   *
   * Returns false when the core stopped making progress, leaving whatever is
   * left of the budget unspent.
   */
  protected drainClocks(
    simsPointer: number,
    count: number,
    clocksPointer: number,
    clocks: number,
    between: () => void,
  ): boolean {
    this.u32(clocksPointer)[0] = clocks;
    if (this.live) {
      // A budget the live profiler has not seen would make the first
      // instruction of the slice look like it cost the whole of the last one.
      this.live.left = clocks;
      this.live.clocks = this.u32(clocksPointer);
    }
    let idle = 0;
    let before = clocks;
    while (this.u32(clocksPointer)[0] !== 0) {
      this.wasm.Emulate(simsPointer, count, clocksPointer);
      const left = this.u32(clocksPointer)[0];
      idle = left === before ? idle + 1 : 0;
      before = left;
      if (idle > VB_MAX_IDLE_EMULATE_CALLS) {
        return false;
      }
      if (this.stopped !== undefined) {
        // The callback refused an instruction, so the clocks left over are
        // not a machine that failed to advance — they are the rest of a slice
        // nobody is going to run. Another Emulate call here would step
        // straight back into the same refusal.
        return true;
      }
      between();
      if (this.live) {
        // `between` is where cheats are applied and frames are staged, and
        // anything that allocates in core memory can move the heap out from
        // under a view. Once per `Emulate` call, not once per instruction.
        this.live.clocks = this.u32(clocksPointer);
      }
    }
    return true;
  }

  /**
   * Give up on a core that is no longer advancing.
   *
   * Suspends rather than carrying on: every further chunk would cost the same
   * fruitless run of calls, and the machine has stopped either way. The event
   * says what happened, so the chrome can offer a reset instead of showing a
   * picture that will never change again.
   */
  protected stall(): void {
    this.pendingClocks = 0;
    this.suspend();
    this.emit({ event: 'stalled', payload: { frames: this.framesRun } });
  }

  /**
   * Emulate one chunk: VB_CLOCKS_PER_BUFFER clocks, one full sample buffer.
   *
   * False when the core stopped advancing, leaving the chunk unfinished.
   */
  protected emulateChunk(sims: SimState[]): boolean {
    this.recordChunk(sims);
    if (this.live) {
      this.live.framed = false;
    }
    // Rewind each simulation's sample write position for this chunk.
    for (const sim of sims) {
      this.wasm.vbSetSamples(
        sim.pointer,
        sim.samples,
        VbDataType.F32,
        VB_SAMPLES_PER_BUFFER,
      );
    }

    const drained = this.drainClocks(
      this.simsPointer, sims.length, this.clocksPointer, VB_CLOCKS_PER_BUFFER, () => {
        if (this.gamePakInterrupts.size > 0) {
          this.serviceGamePakInterrupts();
        }

        let framed = false;
        for (const sim of sims) {
          if (this.wasm.GetBreaks(sim.pointer) & VbBreak.FRAME) {
            framed = true;
            // On the machine's own frame boundary rather than on the chunk's:
            // the two are the same length but not the same moment, and what a
            // profile is describing is the work between two pictures.
            if (this.live?.pointer === sim.pointer) {
              this.endLiveFrame();
            }
            this.applyCheats(sim.pointer);
            this.applyVsuMutes(sim.pointer);
            // Only the simulation RetroAchievements is tracking — never a linked
            // peer, and never the profile replay's scratch simulation, which
            // never reaches this loop at all.
            if (sim.pointer === this.raSimPointer) {
              this.ra.doFrame();
            }
            // With a healthy backlog there is no point staging a frame
            // we would only overwrite before it is ever shown.
            if (this.audioQueue.length <= 2) {
              this.wasm.GetPixels(sim.pointer);
            }
          }
        }

        if (framed && this.rewind.enabled) {
          if (this.rewind.frames % this.rewind.granularity === 0) {
            this.captureRewindEntry(sims);
          }
          this.rewind.frames++;
        }
      });

    // A machine whose display is off completes no VIP frame and so reports no
    // frame break — a boot, a crash, a ROM that never gets that far. A chunk
    // is a frame's worth of clocks regardless, so it stands in for one, and a
    // profile of a game that is not drawing anything still moves. Not while a
    // frame is half gathered, though: a game drawing every second picture has
    // chunks with no picture in them by rights, and closing one there would
    // cut its frame in half.
    if (this.live && !this.live.framed && this.live.pictures === 0) {
      this.endLiveFrame(true);
    }
    return drained;
  }

  protected presentAll(): void {
    for (const sim of this.sims.values()) {
      this.present(sim);
    }
  }

  /** True only when both the VBC core and its RGB transport exports are active. */
  protected isVbcColorOutput(sim: SimState): boolean {
    return this.wasm.GetVideoFormat?.(sim.pointer) === 1
      && this.wasm.GetColorPixels !== undefined
      && this.wasm.GetExtColorPixels !== undefined;
  }

  /**
   * Recomposite the framebuffer from the VIP's current state, then present it.
   *
   * present() shows whatever the core composited last, which the drive loop
   * refreshes at every frame break. A state that was restored rather than
   * emulated has never been through a frame break, so without this the screen
   * keeps showing the frame from before the restore until emulation resumes.
   */
  protected presentRestored(sim: SimState): void {
    this.wasm.GetPixels(sim.pointer);
    this.present(sim);
  }

  protected present(sim: SimState): void {
    if (!sim.renderer && !sim.mainThread && !sim.videoTap) {
      return;
    }
    const colorMode = this.isVbcColorOutput(sim);
    if (colorMode) {
      // The legacy eye-packed buffer remains available to debugger/halo APIs;
      // VBC presentation uses its own packed RGB555 transport buffer.
      this.wasm.GetColorPixels!(sim.pointer);
    }
    const pixels = new Uint8Array(
      this.wasm.memory.buffer,
      colorMode
        ? this.wasm.GetExtColorPixels!(sim.pointer)
        : this.wasm.GetExtPixels(sim.pointer),
      VB_SCREEN_WIDTH * VB_SCREEN_HEIGHT * 4,
    );
    if (sim.renderer) {
      sim.renderer.present(pixels, colorMode);
    } else if (sim.mainThread) {
      this.sendFrame(sim, sim.mainThread, pixels, colorMode);
    }
    if (sim.videoTap) {
      this.sendFrame(sim, sim.videoTap, pixels, colorMode);
    }
  }

  /**
   * Hand one frame to the DOM thread out of a pool of transfer buffers.
   *
   * An empty pool means the DOM thread is still busy with every buffer.
   * Dropping an obsolete video frame keeps emulation and audio moving; the
   * next present uses whichever buffer comes back first.
   */
  protected sendFrame(
    sim: SimState,
    pool: { presentation: number; buffers: ArrayBuffer[] },
    pixels: Uint8Array,
    colorMode: boolean,
  ): void {
    const buffer = pool.buffers.shift();
    if (!buffer) {
      return;
    }
    new Uint8Array(buffer).set(pixels);
    this.emit({
      event: 'frame',
      payload: {
        sim: sim.pointer,
        presentation: pool.presentation,
        pixels: buffer,
        colorMode,
      },
    }, [buffer]);
  }

  // --- Core memory helpers ------------------------------------------------

  /**
   * Views are created on demand rather than cached, because the core grows
   * its own memory and a growth detaches every existing view.
   */
  protected u8(pointer: number, length: number): Uint8Array {
    return new Uint8Array(this.wasm.memory.buffer, pointer, length);
  }

  protected u32(pointer: number, length = 1): Uint32Array {
    return new Uint32Array(this.wasm.memory.buffer, pointer, length);
  }

  protected f32(pointer: number, length: number): Float32Array {
    return new Float32Array(this.wasm.memory.buffer, pointer, length);
  }

  protected allocateScratch(): void {
    this.clocksPointer = this.wasm.Realloc(0, Uint32Array.BYTES_PER_ELEMENT);
    this.mixPointer = this.wasm.Realloc(
      0,
      MIX_BUFFER_LENGTH * Float32Array.BYTES_PER_ELEMENT,
    );
  }

  protected copyIntoCore(data: ArrayBuffer): number {
    const pointer = this.wasm.Realloc(0, data.byteLength);
    if (pointer === 0 && data.byteLength !== 0) {
      throw new Error('Emulator core ran out of memory.');
    }
    new Uint8Array(this.wasm.memory.buffer, pointer, data.byteLength).set(
      new Uint8Array(data),
    );
    return pointer;
  }

  // Keep the core-side pointer array that Emulate() walks in sync.
  protected refreshSimPointers(): void {
    if (this.sims.size > this.simsCapacity) {
      this.simsPointer = this.wasm.Realloc(
        this.simsPointer,
        this.sims.size * Uint32Array.BYTES_PER_ELEMENT,
      );
      this.simsCapacity = this.sims.size;
    }
    if (this.simsCapacity === 0) {
      return;
    }
    const pointers = this.u32(this.simsPointer, this.simsCapacity);
    let index = 0;
    for (const sim of this.orderedSims()) {
      pointers[index++] = sim.pointer;
    }
  }

  protected requireSim(handle: SimHandle): SimState {
    const sim = this.sims.get(handle);
    if (!sim) {
      throw new Error(`No such simulation: ${handle}`);
    }
    return sim;
  }

  protected emit(event: VbEvent, transfer: Transferable[] = []): void {
    this.workerScope.postMessage(event, transfer);
  }
}

// --- Entry point ------------------------------------------------------------

const scope = globalThis as unknown as WorkerScope;
const worker = new Worker(scope);

scope.onmessage = async event => {
  // The very first message carries the port to the audio worklet.
  if ('audioPort' in event.data) {
    await worker.bootstrap(event.data as Bootstrap);
    scope.postMessage({ id: 0 } as Response);
    return;
  }

  if ('videoFrame' in event.data) {
    worker.returnVideoFrame(event.data as VideoFrameReturn);
    return;
  }

  const request = event.data as Request;
  try {
    const result = await worker.handle(request.command, request.params);
    const response: Response = { id: request.id, result };
    // Large raw buffers move rather than copy. Backdrops and complete frames
    // wrap theirs with a format flag, so include that nested buffer as well.
    const transfer = result instanceof ArrayBuffer
      ? [result]
      : request.command === 'readBackdrop' || request.command === 'readFrame'
        ? [(result as Result<'readBackdrop' | 'readFrame'>).pixels]
        : [];
    scope.postMessage(response, transfer);
  } catch (error) {
    scope.postMessage({
      id: request.id,
      error: error instanceof Error ? error.message : String(error),
    } as Response);
  }
};
